#!/usr/bin/env python3
"""AVD v8.0.3 identity coherence + onboarding spine validator (B5; regression R705).

Why this exists. A cold reader following SKILL.md's own instruction path hit, in LM Task 3's
novice walkthrough, three concrete stops: (a) SKILL.md shipped no map and pointed at terms it
never defined ("substantial work", "mode owners", "triggered modules", "the host"); (b) the
assurance-profile list named 3 of the 4 enum values, so a beginner could not know which
string the validator accepts; (c) the version identity was ambiguous - SKILL.md's frontmatter,
the distribution name, and PACKAGE_MANIFEST all carried different labels.

This validator makes the onboarding claims executable:
  * every file SKILL.md's map points at must exist;
  * the assurance profiles SKILL.md documents must equal the schema enum (all four);
  * the tree version must agree across SKILL.md frontmatter, the H1, and release/RELEASE.json;
  * era labels (manifest format, MCP contract epoch) must NOT be silently "corrected" - they
    are distinct identities and the tree records them as such;
  * the Quick Shot / Substantial work test must be stated as a decidable rule.

Proof boundary: proves the onboarding documents agree with each other and with the machine
records they describe. It does NOT prove a beginner can complete a project, that the routing
manifest selects the right modules for a real brief, or that the walkthrough is sufficient -
the beginner-pilot track is still NOT_RUN by the package's own admission.
"""
import io
import json
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent

PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


def load(p):
    return json.loads((ROOT / p).read_text(encoding="utf-8"))


skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
release = load("release/RELEASE.json")
tree_version = release.get("version")

# --- 1. every path SKILL.md's map names must exist ------------------------------------
map_rows = [ln for ln in skill.splitlines() if ln.strip().startswith("|") and "`" in ln]
named = []
for ln in map_rows:
    named.extend(m.group(1) for m in re.finditer(r"`([^`]+\.(?:md|json|py))`", ln))
check(len(named) >= 8, "SKILL_MAP_ROWS", f"SKILL.md carries a where-things-are map ({len(named)} paths)")
missing = [p for p in named if not (ROOT / p).exists()]
check(not missing, "SKILL_MAP_PATHS_EXIST", f"every mapped path exists (missing={missing})")
for required in ("QUICKSTART.md", "rules/CORE_CONTROLLER.md", "rules/RUNTIME.md",
                 "routing/ACTIVE_MODULE_MANIFEST.json", "bootstrap/runtime_load_manifest.json"):
    check(any(required in p for p in named), "SKILL_MAP_COVERS",
          f"the map points at {required}")

# --- 2. assurance profiles: SKILL.md must document the whole schema enum ---------------
enum = load("schemas/ROUTING_CONTRACT.schema.json")["properties"]["assuranceProfile"]["enum"]
doc_section = skill.split("## Assurance profiles", 1)[-1].split("##", 1)[0]
undocumented = [p for p in enum if f"`{p}`" not in doc_section]
check(not undocumented, "ASSURANCE_PROFILES_DOCUMENTED",
      f"all {len(enum)} schema profiles documented in SKILL.md (missing={undocumented})")

# --- 3. version identity coherence ---------------------------------------------------
fm = re.search(r"^version:\s*(\S+)", skill, re.M)
h1 = re.search(r"^#\s*AI Visual Director Production V([\d.]+)", skill, re.M)
check(fm is not None and fm.group(1) == tree_version, "IDENTITY_FRONTMATTER",
      f"SKILL.md frontmatter version {fm.group(1) if fm else None} == tree {tree_version}")
check(h1 is not None and h1.group(1) == tree_version, "IDENTITY_H1",
      f"SKILL.md H1 version {h1.group(1) if h1 else None} == tree {tree_version}")
# v8.1.2 (D3): version-only checking let a RELEASE-LABEL drift ship - the 8.0.4 layer
# bumped every version string and left SKILL.md saying "Release 10" while RELEASE.json said
# "Release 11". Battery slot A surfaced it unprompted. The release label is now checked too.
h1_full = re.search(r"^#\s*AI Visual Director Production V[\d.]+\s*[—-]+\s*(.+)$", skill, re.M)
rel_label = str(release.get("release", ""))
rel_short = re.match(r"(Release\s+\d+)", rel_label)
claimed_short = h1_full.group(1).strip() if h1_full else None
check(claimed_short is not None and rel_short is not None
      and claimed_short == rel_short.group(1), "IDENTITY_RELEASE_LABEL",
      f"SKILL.md H1 release label {claimed_short!r} == RELEASE.json {rel_short.group(1) if rel_short else None!r}")
pkg = load("PACKAGE_MANIFEST.json")
check(pkg.get("schemaVersion") == "7.8.0", "IDENTITY_MANIFEST_FORMAT_LABEL",
      "PACKAGE_MANIFEST.schemaVersion stays the FORMAT label (7.8.0), not the release")
check("not the release" in skill or "NOT the release" in skill, "IDENTITY_FORMAT_LABEL_EXPLAINED",
      "SKILL.md explains that the manifest label is a format version, not the release")
check("MCP contract epoch" in skill, "IDENTITY_MCP_EPOCH_EXPLAINED",
      "SKILL.md explains the MCP contract epoch as a separate identity")
mcp = load("mcp/server/MCP_SERVER_MANIFEST.json")
check(mcp.get("manifest_version") in (tree_version, "8.0.0"), "IDENTITY_MCP_LABEL_KNOWN",
      f"MCP manifest_version {mcp.get('manifest_version')} is a declared contract epoch")

# --- 4. the classification test is decidable, not a vibe ------------------------------
check("## Substantial work or Quick Shot" in skill, "CLASSIFICATION_SECTION_PRESENT",
      "SKILL.md defines the Quick Shot / Substantial work boundary")
cls = skill.split("## Substantial work or Quick Shot", 1)[-1].split("## Canonical generation", 1)[0]
check("three true" in cls or "all three" in cls.lower(), "CLASSIFICATION_DECIDABLE",
      "Quick Shot is stated as an all-conditions test")
check("any one" in cls.lower(), "CLASSIFICATION_SUBSTANTIAL_DECIDABLE",
      "Substantial work is stated as an any-condition test")

# --- 5. the paste boundary is stated on the path a beginner reads --------------------
check("PASTE-BLOCK" in skill and "CONTROLLER-ONLY" in skill, "PASTE_BOUNDARY_ON_PATH",
      "SKILL.md states which region of a prompt envelope is pasted")

# --- 6. the mode owner / selection machinery is discoverable --------------------------
check("PRODUCTION_OWNER" in skill, "MODE_OWNER_POINTER",
      "SKILL.md names the file that maps a mode to its owner")

print(json.dumps({
    "schemaVersion": "8.0.3",
    "validator": "validate_identity_coherence.py",
    "pass": not FAILURES,
    "passed": len(PASSES),
    "failed": len(FAILURES),
    "failures": FAILURES,
    "treeVersion": tree_version,
    "assuranceProfiles": enum,
    "proofBoundary": ("Proves the onboarding documents agree with each other and with the machine records they "
                      "describe. It does NOT prove a beginner can complete a project, that the routing manifest "
                      "selects the right modules for a real brief, or that the walkthrough suffices; the "
                      "beginner-pilot track remains NOT_RUN."),
}, indent=2, ensure_ascii=False))
sys.exit(0 if not FAILURES else 1)