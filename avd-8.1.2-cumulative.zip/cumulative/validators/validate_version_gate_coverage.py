#!/usr/bin/env python3
"""AVD v8.0.3 version-gate coverage validator (A1; regression R698).

Why this exists: before v8.0.3 the tree held SEVEN hand-maintained version tuples across
validate_contract_schema.py, validate_project.py and compile_and_validate.py. They had
drifted: the caller accepted 8.0.x while the callee's audience arm stopped at 7.8.0, so an
8.0.1/8.0.2 contract with an empty audience block validated clean. Two consequences this
validator makes impossible to repeat:

  1. COVERAGE - no validator source may carry a private version tuple. Every accepted
     version must be resolvable through validate_contract_schema.accepted() only.
  2. BEHAVIOUR - the accept-set is exercised, not assumed: an 8.0.3 contract with a broken
     audience block must produce errors; an unknown version must produce a
     version error; the A1 warning-first cadence must hold (missing
     humanReviewRequiredForClaims is a WARNING at 8.0.3 and an ERROR at 8.0.4).

Proof boundary: this proves the version gates agree and the audience arms are reachable at
the current version. It does not prove any child-audience compliance claim, any real
human-review evidence, or that a project is safe for children.
"""
import io
import json
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "validators"))
from validate_contract_schema import (  # noqa: E402
    ACCEPTED, FAMILIES, HARD_AUDIENCE_GATE_FROM, WARNINGS,
    accepted, hard_audience_gate, validate_project_contract, validate_routing_contract,
)

PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


# --- 1. COVERAGE: no private version tuples may survive anywhere in validators/ -------
# A tuple of >=2 version literals is a private copy of the accept-set.
# v8.1.2 (D2): the previous pattern used `-?[a-z]+` for a version suffix, which could NOT
# match a two-segment suffix such as '7.4.2-phase-c'. That single regex defect let
# validate_delivery_package's 7.x-only gate escape the census entirely - a false all-clear.
# The pattern now matches any quoted literal that begins with a digit.
TUPLE_RX = re.compile(r"\(\s*'[0-9][^']*'\s*(?:,\s*'[0-9][^']*'\s*)+\)")
# The single source of truth is exempt by definition, as is this file (it names versions as
# data, not as a gate). Every OTHER validator must resolve versions through accepted().
GUARDED = {"validate_contract_schema.py", "validate_version_gate_coverage.py"}
found = []
for p in sorted((ROOT / "validators").rglob("*.py")):
    if p.name in GUARDED:
        continue
    for m in TUPLE_RX.finditer(p.read_text(encoding="utf-8")):
        lit = m.group(0)
        # a source-text tuple naming >=2 distinct major.minor versions is a version allowlist
        majors = set(re.findall(r"'(\d+\.\d+)", lit))
        if len(majors) >= 2:
            found.append((p.relative_to(ROOT).as_posix(), m.start(), lit[:80]))
for rel, pos, lit in found:
    check(False, "VERSION_GATE_PRIVATE_TUPLE", f"{rel}: private version tuple {lit} (use accepted())")
check(not found, "VERSION_GATE_SINGLE_SOURCE",
      f"no private multi-version tuples outside the accept-set ({len(found)} found)")

# --- 2. The accept-set itself agrees with the declared tree version ------------------
try:
    release = json.loads((ROOT / "release/RELEASE.json").read_text(encoding="utf-8"))
    tree_version = release.get("version")
except Exception as exc:  # fail closed on an unreadable release record
    tree_version = None
    check(False, "RELEASE_UNREADABLE", str(exc))
check(tree_version in ACCEPTED or any(tree_version and tree_version.startswith(f) for f in FAMILIES),
      "ACCEPT_SET_COVERS_TREE", f"declared tree version {tree_version} is accepted by ACCEPTED")
check(accepted(tree_version), "ACCEPTED_TREE_VERSION", f"accepted({tree_version!r}) is True")

# --- 3. BEHAVIOUR: the audience arms must be reachable at the CURRENT version --------
TPL = json.loads((ROOT / "templates/PROJECT_CONTRACT.json").read_text(encoding="utf-8"))


def probe(version, mutate=None):
    c = json.loads(json.dumps(TPL))
    c["schemaVersion"] = version
    c.setdefault("versionMeta", {})["ruleVersion"] = version
    if mutate:
        mutate(c)
    del WARNINGS[:]
    errs = validate_project_contract(c)
    return errs, list(WARNINGS)


# 3a. a well-formed 8.0.3 contract passes
errs, warns = probe("8.0.3")
check(not errs, "AUDIENCE_OK_AT_TREE_VERSION", f"shipped template shape at 8.0.3 has 0 errors (got {len(errs)})")
check(not warns, "AUDIENCE_NO_SPURIOUS_WARNING", f"shipped template shape at 8.0.3 has 0 warnings (got {len(warns)})")

# 3b. the A1 regression: an EMPTY audience block must now FAIL at the tree version.
def break_audience(c):
    c["audience"] = {"type": "", "ageRange": "", "humanReviewRequiredForClaims": True}

errs, _ = probe("8.0.3", break_audience)
paths = {e.get("path") for e in errs}
check("$.audience.type" in paths and "$.audience.ageRange" in paths,
      "A1_REGRESSION_EMPTY_AUDIENCE", f"empty audience.type/ageRange rejected at 8.0.3 (paths={sorted(p for p in paths if p)})")

# 3c. an UNRECOGNISED version is an error, not a silent skip
errs, _ = probe("9.9.9-beta", break_audience)
check(any(e.get("path") == "$.schemaVersion" for e in errs),
      "UNKNOWN_VERSION_IS_ERROR", f"unknown version reported (paths={sorted({e.get('path') for e in errs})})")

# 3d. the warning-first cadence: a missing humanReviewRequiredForClaims is a WARNING at
#     8.0.3 and a hard ERROR at 8.0.4.
def drop_hrr(c):
    c["audience"] = {"type": "CHILDREN", "ageRange": "6-9"}


errs, warns = probe("8.0.3", drop_hrr)
check(not errs and any(w.get("code") == "AUDIENCE_BLOCK_MISSING" for w in warns),
      "CADENCE_WARNING_AT_8_0_3", f"missing humanReviewRequiredForClaims warns at 8.0.3 (errors={len(errs)}, warnings={len(warns)})")
errs, warns = probe("8.0.4", drop_hrr)
check(any(e.get("path") == "$.audience.humanReviewRequiredForClaims" for e in errs),
      "CADENCE_ERROR_AT_8_0_4", f"missing humanReviewRequiredForClaims hard-fails at {HARD_AUDIENCE_GATE_FROM} (errors={len(errs)})")
check(hard_audience_gate("8.0.4") and not hard_audience_gate("8.0.3"),
      "CADENCE_THRESHOLD", f"hard gate starts at {HARD_AUDIENCE_GATE_FROM}")

# 3e. routing contracts: audienceTriggers arm reachable at the tree version
ROUT = json.loads((ROOT / "templates/ROUTING_CONTRACT.json").read_text(encoding="utf-8"))
ROUT["schemaVersion"] = "8.0.3"
ROUT["audienceTriggers"] = []
check(any(e.get("path") == "$.audienceTriggers" for e in validate_routing_contract(ROUT)),
      "ROUTING_TRIGGERS_AT_TREE_VERSION", "empty audienceTriggers rejected at 8.0.3")

# --- 4. The shipped negative fixture must be rejected ---------------------------------
FIX = ROOT / "schemas/examples/negative_tests/contract_8x_missing_audience.json"
check(FIX.is_file(), "A1_FIXTURE_PRESENT", f"{FIX.relative_to(ROOT).as_posix()} exists")
if FIX.is_file():
    obj = json.loads(FIX.read_text(encoding="utf-8"))
    del WARNINGS[:]
    ferrs = validate_project_contract(obj)
    check(bool(ferrs), "A1_FIXTURE_REJECTED", f"fixture produces {len(ferrs)} error(s)")
    check(any(e.get("path", "").startswith("$.audience") for e in ferrs),
          "A1_FIXTURE_AUDIENCE_PATH", f"fixture error paths = {sorted({e.get('path') for e in ferrs})}")

# --- 5. BEHAVIOURAL GATE-FIRING (v8.1.2 / D2) -------------------------------------
# A tuple census is a STATIC proxy. The defect it missed (D1) was behavioural: the gate was
# present, looked like an allowlist, and simply returned early at the current version - so the
# validator reported success while inspecting nothing. Counting tuples can never see that.
#
# This section EXECUTES each version-gated validator against a probe that MUST produce a
# specific error when the gate actually fires. If the gate is skipping, the probe returns no
# error and the check fails. This is what would have caught D1 on the day it was written.
GATE_PROBES = [
    {
        "module": "validate_delivery_package",
        "call": "validate_package",
        # packageRequired with no package_root must raise PACKAGE_DIRECTORY_REQUIRED.
        # Before the D1 fix this returned [] at 8.0.x because the gate skipped the call.
        "build": lambda v: (
            {"schemaVersion": v, "projectId": "PROBE", "packageRequired": True,
             "deliveryPolicy": {}, "deliveryMode": "SINGLE_PASS_BLUEPRINT"},
            {"statusMetadata": {"maturity": "PLAN_PASS", "media": "NOT_GENERATED"}},
        ),
        "kwargs": {"package_root": None},
        "expect": "PACKAGE_DIRECTORY_REQUIRED",
    },
]

fired, not_fired = [], []
for probe in GATE_PROBES:
    try:
        mod = __import__(probe["module"])
        fn = getattr(mod, probe["call"])
    except Exception as exc:
        check(False, "GATE_PROBE_IMPORT", f"{probe['module']}: import failed ({exc})")
        continue
    contract, output = probe["build"](tree_version)
    try:
        errs = fn(contract, output, **probe["kwargs"])
    except Exception as exc:
        check(False, "GATE_PROBE_RAISED", f"{probe['module']}: raised {type(exc).__name__}: {exc}")
        continue
    codes = {e.get("code") for e in errs} if isinstance(errs, list) else set()
    if probe["expect"] in codes:
        fired.append(probe["module"])
        check(True, "GATE_FIRES",
              f"{probe['module']}: gate fires at {tree_version} (probe produced {probe['expect']})")
    else:
        not_fired.append(probe["module"])
        check(False, "GATE_DOES_NOT_FIRE",
              f"{probe['module']}: gate did NOT fire at {tree_version} - the validator returned "
              f"{sorted(codes) or 'no errors'} for a probe that must yield {probe['expect']}. "
              f"A silently-skipping gate reports success while inspecting nothing.")

# A behavioural census also needs a floor: at least one gated validator must be probed,
# or this section silently degrades to a no-op exactly like the defect it hunts.
check(len(GATE_PROBES) >= 1, "GATE_PROBES_PRESENT",
      f"{len(GATE_PROBES)} behavioural gate probe(s) registered ({fired} firing, {not_fired} not)")

print(json.dumps({
    "schemaVersion": "8.1.2",
    "validator": "validate_version_gate_coverage.py",
    "pass": not FAILURES,
    "passed": len(PASSES),
    "failed": len(FAILURES),
    "failures": FAILURES,
    "treeVersion": tree_version,
    "acceptedCount": len(ACCEPTED),
    "hardAudienceGateFrom": HARD_AUDIENCE_GATE_FROM,
    "gateProbesFiring": fired,
    "gateProbesNotFiring": not_fired,
    "proofBoundary": ("Proves the tree's version gates agree, the child-audience/claims arms are reachable at the "
                      "declared version with the A1 cadence, AND that each registered version-gated validator "
                      "actually executes its checks at the current version rather than skipping. It does not "
                      "prove child-audience compliance, real human-review evidence, or that any project is safe "
                      "for children; and a probe only covers a validator someone registered here."),
}, indent=2, ensure_ascii=False))
sys.exit(0 if not FAILURES else 1)