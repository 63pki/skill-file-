#!/usr/bin/env python3
"""AVD v8.0.0 state-layer validator (dependency-free, fail-closed).

Validates:
  1. The five artifact schemas + _avd_defs + PRODUCTION_STATE manifest parse and
     satisfy structural rules (no network resolution; intra-repo refs only).
  2. Example instances under schemas/examples/ conform (hand-rolled checks mirroring
     the schema constraints - the tree's validators are dependency-free by doctrine).
  3. Negative fixtures under schemas/examples/negative_tests/ FAIL as expected.
  4. Embedded AVD:STATE markers parse; duplicate markers in one host fail.
  5. X14: promotionEligible is false everywhere it appears; digests honor
     computed/uncomputed discipline.

Exit code 0 = all pass; 1 = any failure. UTF-8 everywhere.
"""
from pathlib import Path
import hashlib
import json
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

# v8.1.2 (BL2): the declared tree version, read once at module scope so validators that need
# it (validate_handoff) use the same source as the label sweep. Read from the release record,
# never hardcoded, so it cannot drift from the tree it validates.
try:
    TREE_VERSION = json.loads((ROOT / "release/RELEASE.json").read_text(encoding="utf-8")).get("version")
except Exception:
    TREE_VERSION = None

FAILURES = []
PASSES = []


def check(condition, code, detail):
    if condition:
        PASSES.append(f"{code}: {detail}")
    else:
        FAILURES.append(f"{code}: {detail}")
    return condition


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


SEMVER = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
# D-9: a computed digest may never be a placeholder. All-zero and all-f are the
# canonical null-hash placeholders (the pre-binding genesis convention uses all-zero
# in boundArtifactSha256, a DIFFERENT field); a digest claiming digestStatus
# "computed" with either string is a fabricated measurement, not a hash.
SHA256 = re.compile(r"^(?!0{64}$)(?!f{64}$)[0-9a-f]{64}$")
MARKER = re.compile(
    r"<!-- AVD:STATE id=([0-9a-zA-Z-]{4,24}) schema=([^ ]+) version=([^ ]+) "
    r"artifact=([^ ]+) path=([^ ]+) sha256=((?!0{64}$)(?!f{64}$)[0-9a-f]{64}|UNCOMPUTED) -->"
)
# Loose prefix finder: catches AVD:STATE comment openings that failed the full grammar,
# so a malformed marker fails loudly instead of silently not-matching (F-2 live proof).
MARKER_LOOSE = re.compile(r"<!--\s*AVD:STATE\bid=")
BOUND_HASH = re.compile(r"\A[0-9a-f]{64}\Z")  # v8.1.2: \A..\Z, not ^..$ - in Python `$` also matches just
# BEFORE a trailing newline, so a 64-hex claim with "\n" appended PASSED the old pattern
# (found by external review, reproduced, then killed by a drill). fullmatch() is equivalent; this
# keeps existing call sites unchanged.
APPROVAL_ROLES = None  # lazy-loaded from the shipped role registry (tree-local)
DAG_APPROVERS = None   # lazy-loaded from the shipped gate-DAG requiredApprovals table


def _approval_roles():
    """F-1b: load the role registry - the same JSON the schema's roleApprovals[].role enum mirrors."""
    global APPROVAL_ROLES
    if APPROVAL_ROLES is None:
        reg = load_json(ROOT / "release/APPROVAL_ROLE_REGISTRY.json")
        APPROVAL_ROLES = {
            "roles": set(reg.get("roles", {}).keys()),
            "roleScope": {k: set(v.get("scope", [])) for k, v in reg.get("roles", {}).items()},
            "roleDefs": reg.get("roles", {}),
            "vetoClasses": set(reg.get("authority_doctrine", {}).get("vetoClasses", [])) | {"NONE"},
            "decisions": {"APPROVED", "REJECTED", "CONDITIONAL", "ABSTAINED", "PENDING"},
        }
    return APPROVAL_ROLES


def _dag_approver_roles():
    """F-1b: load the DAG's requiredApprovals table: gateId -> set of approverRoles."""
    global DAG_APPROVERS
    if DAG_APPROVERS is None:
        dag = load_json(ROOT / "rules/detailed/35_gate_dag_v800.json")
        DAG_APPROVERS = {e.get("gateId"): set(e.get("approverRoles", []))
                         for e in dag.get("requiredApprovals", [])}
    return DAG_APPROVERS


def validate_marker_comment(text, host_rel):
    """F-2 wiring: make the docstring's promise #4 real. Parse embedded AVD:STATE
    comment markers out of host files, run validate_marker on each parsed dict,
    and fail on duplicates/malformed-in-loose-prefix cases.
    Returns the count of valid markers found (used in the battery output)."""
    count = 0
    seen_ids = set()
    # Per-marker sweep over HTML comments whose body IS an AVD:STATE marker.
    for m in re.finditer(r"<!--(.*?)-->", text, re.S):
        body = m.group(1).strip()
        # A marker comment body starts with the AVD:STATE token. A JSON/string
        # value that merely *mentions* "AVD:STATE markers" in prose is not a marker
        # instance and must not be grammar-checked.
        if not body.startswith("AVD:STATE"):
            continue
        # A grammar template or documented regex (e.g. the const strings in
        # PRODUCTION_STATE.schema.json: "id=<markerId> ..." and "AVD:STATE .* -->")
        # is grammar documentation, not an instance assertion. Both are exempt from
        # the instance grammar. A concrete instance carries id=<value> with no
        # placeholders and no regex metacharacters.
        if "=<" in body or ".*" in body:
            continue
        count += 1
        fm = MARKER.fullmatch("<!-- " + body + " -->")
        if not fm:
            check(False, "STATE_MARKER_GRAMMAR", f"{host_rel}: AVD:STATE comment fails the tightened grammar (post-D-9)")
            continue
        mid, schema, ver, artifact, path, dgst = fm.groups()
        if mid in seen_ids:
            check(False, "STATE_MARKER_DUPLICATE", f"{host_rel}: duplicate marker id {mid}")
            continue
        seen_ids.add(mid)
        parsed = {
            "schemaVersion": ver, "markerId": f"AVD-STATE-{mid}" if not mid.startswith("AVD-STATE-") else mid,
            "schemaId": schema, "artifactId": artifact, "path": path,
        }
        validate_marker(parsed, f"{host_rel}::{mid}")
        if dgst != "UNCOMPUTED":
            # a computed marker digest must be recomputable from the referenced artifact
            target = (ROOT / path)
            if path.startswith("schemas/") and target.is_file():
                actual = hashlib.sha256(target.read_bytes()).hexdigest()
                check(actual == dgst, "STATE_MARKER_DIGEST", f"{host_rel}::{mid}: sha256= must recompute from {path}")
            # markers whose path does not resolve in-tree keep their digest unverified -
            # no silent pass (the UNCOMPUTED form exists precisely for that honesty case).
    return count


FILENAME = re.compile(
    r"^[A-Za-z0-9._-]+_[A-Za-z0-9._-]+_[A-Za-z0-9._-]+_[A-Za-z0-9._-]+_v[0-9]+_(PASS|REVISE|BLOCK|DRAFT|RETIRED)\.[a-z0-9]+$"
)
GATES = {"R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"}
STATUSES = {"PASS", "REVISE", "BLOCK", "NO-SHIP", "N/A", "PENDING"}
CATALOG = {
    "concept-rewrite", "logic-map", "style-tile", "model-sheet",
    "neutral-keyframe", "short-motion-proof", "scratch-vo-timing", "editor-mockup",
}
POLICY = {
    "nativeVideoCeiling": "720p",
    "aboveCeilingPolicy": "upscaled-platform-neutral-finishing-handoff-flagged-R0-R1",
    "maxSequentialConversationalEditsPerClip": 3,
    "oneVariableRepairBudget": 2,
    "finalSlotReserved": True,
}


def validate_policy_constants(obj, where):
    pc = obj.get("policyConstants")
    if not isinstance(pc, dict):
        return check(False, "STATE_POLICY_MISSING", f"{where}: policyConstants object missing")
    ok = True
    for k, v in POLICY.items():
        if pc.get(k) != v:
            ok = check(False, "STATE_POLICY_VALUE", f"{where}.policyConstants.{k} = {pc.get(k)!r}, expected {v!r}") and ok
    return ok


def validate_digest(obj, where):
    # D-9: SHA256 above rejects all-zero/all-f placeholders when digestStatus is
    # "computed" - a claimed measurement must be a real hash, never a null value.
    d = obj.get("digest")
    if not isinstance(d, dict):
        return check(False, "STATE_DIGEST_MISSING", f"{where}: digest object missing")
    # D-14b: the label names the exact stdlib form digests cover (sorted-keys
    # compact UTF-8), not RFC 8785/JCS - the tree never implemented JCS.
    ok = d.get("digestAlgorithm") == "sha256" and d.get("canonicalization") == "JSON-SORTED-KEYS-UTF8"
    status = d.get("digestStatus")
    arm = ""
    if status == "computed":
        ok = bool(SHA256.match(str(d.get("digest", "")))) and ok
        # v8.0.2 (F-2a): a computed digest must recompute, not merely look like one.
        # Binding: the artifact's tree-relative path, carried as artifactPath on the
        # carrier object (receipt/asset-entry). It must resolve to a readable file,
        # and sha256(bytes) must equal the claim. An unbound computed claim fails
        # closed (adjudication 2026-09-30: the pre-8.0.2 layer passed any well-formed
        # 64-hex, making "computed" format-only).
        ap = obj.get("artifactPath") or ""
        if not isinstance(ap, str) or not ap.strip():
            ok = False
            arm = " [unbound: no artifactPath]"
        else:
            target = (ROOT / ap) if not Path(ap).is_absolute() else Path(ap)
            if not target.is_file():
                ok = False
                arm = f" [unbound: {ap} missing]"
            else:
                actual = hashlib.sha256(target.read_bytes()).hexdigest()
                ok = (actual == str(d.get("digest", ""))) and ok
                arm = " [recompute:match]" if actual == str(d.get("digest", "")) else " [recompute:mismatch]"
    elif status == "uncomputed":
        ok = "digest" not in d and ok
    else:
        ok = False
    return check(ok, "STATE_DIGEST_INVALID", f"{where}: digest {json.dumps(d)[:120]}{arm}")


def validate_marker(m, where):
    ok = SEMVER.match(m.get("schemaVersion", "")) is not None
    ok = m.get("markerId", "").startswith("AVD-STATE-") and ok
    ok = bool(m.get("schemaId")) and bool(m.get("artifactId")) and bool(m.get("path")) and ok
    return check(ok, "STATE_MARKER_INVALID", f"{where}: marker {json.dumps(m)[:120]}")


def validate_gate_receipt(r, where):
    ok = r.get("gate") in GATES
    ok = r.get("status") in STATUSES and ok
    if r.get("status") == "N/A" and not str(r.get("naReason", "")).strip():
        ok = False
    ok = validate_policy_constants(r, where) and ok
    ok = validate_digest(r.get("artifactRequired", {}), f"{where}.artifactRequired") and ok
    ok = r.get("promotionEligible") is False and ok
    ok = r.get("promotionEligibleInfluence") == "NONE" and ok
    ra = r.get("roleApprovals")
    if isinstance(ra, list) and ra:
        ok = bool(str(r.get("approvedBy", "")).strip()) and ok
        # v8.0.2 F-1: the approval layer declared in the schema here becomes executable.
        ap = _approval_roles()
        roles = ap["roles"]
        dag_rosters = _dag_approver_roles()
        seen = set()
        absolute_vetoes = 0
        for i, a in enumerate(ra):
            ok = isinstance(a, dict) and ok
            role = a.get("role")
            ok = bool(role in roles) and ok                      # registry role enum
            ok = role not in seen and ok                          # role distinctness per receipt
            seen.add(role)
            ok = (a.get("decision") in ap["decisions"]) and ok
            vc = a.get("vetoClass")
            if vc is not None:
                ok = (vc in ap["vetoClasses"]) and ok
                # the veto hierarchy is typed: a role may only wield the veto class the
                # registry assigns it (a creative veto is not a legal veto).
                role_def = ap["roleDefs"].get(role)
                if isinstance(role_def, dict) and role_def.get("vetoClass") is not None:
                    ok = (vc == role_def.get("vetoClass")) and ok
            if a.get("decision") in {"APPROVED", "REJECTED", "CONDITIONAL"} and not a.get("evidenceRefs"):
                ok = False
            if a.get("timeoutPolicy") != "DEFAULT-DENY":
                ok = False
            bas = a.get("boundArtifactSha256")
            ok = (isinstance(bas, list) and bool(bas)
                  and all(isinstance(h, str) and BOUND_HASH.match(h) for h in bas)) and ok
            # minor d: CONDITIONAL decisions carry open conditions (or the entry is malformed)
            if a.get("decision") == "CONDITIONAL":
                conds = a.get("conditions")
                ok = (isinstance(conds, list) and bool(conds)
                      and all(isinstance(x, str) and x.strip() for x in conds)) and ok
            if a.get("decision") == "REJECTED" and isinstance(vc, str) and vc.startswith("ABSOLUTE_"):
                absolute_vetoes += 1
            # F-1b: role label scope per gate — the DAG requiredApprovals table defines
            # which roles may sign which gate; registry role scope lists allowed gates.
            scope = ap["roleScope"].get(role, set())
            if isinstance(role, str) and scope:
                ok = (r.get("gate") in scope) and ok
            roster = dag_rosters.get(str(r.get("gate")))
            if roster:
                ok = (role in roster) and ok
        # the two-ABSOLUTE rule, encoded in the registry, here becomes arithmetic:
        if absolute_vetoes >= 2:
            ok = (r.get("status") == "BLOCK") and ok
        # minor d (receipt side): R8 cannot close with a CONDITIONAL approval hanging
        # open conditions (openConditionPolicy from the DAG, executed at receipt level)
        if r.get("gate") == "R8" and r.get("status") == "PASS":
            for a in ra:
                if a.get("decision") == "CONDITIONAL" and a.get("conditions"):
                    ok = False
    # over-budget video ledger: an explicit request beyond policy caps is a hard fail
    vl = r.get("videoLedgerOverBudget") or r.get("videoLedger")
    if isinstance(vl, dict):
        if vl.get("chainDepth", 0) > 3 or vl.get("repairsUsed", 0) > 2 or vl.get("fourthEditRequested"):
            ok = False
    return check(ok, "STATE_RECEIPT_INVALID", f"{where}: gate receipt violations")


def validate_asset_entry(a, where):
    # v8.1.2: arms[] names WHICH condition failed, so a negative fixture can be verified as
    # failing for its intended reason rather than merely "some" failure.
    arms = []
    ok = a.get("status") in {"PASS", "REVISE", "BLOCK", "DRAFT", "RETIRED"}
    if not ok:
        arms.append("status-enum")
    name_ok = FILENAME.match(str(a.get("filename", ""))) is not None
    ok = name_ok and ok
    if not name_ok:
        arms.append("filename-pattern")
    ok = validate_digest(a, where) and ok
    ok = validate_policy_constants(a, where) and ok
    if a.get("assetClass") == "video":
        vl = a.get("videoLedger")
        v_ok = isinstance(vl, dict) and vl.get("chainDepth", 99) <= 3 and vl.get("repairsUsed", 99) <= 2
        ok = v_ok and ok
        if not v_ok:
            arms.append("video-ledger-cap")
    # v8.0.3 (A2a): rule 19's asset-tracker table names rights status, cost/attempts, owner
    # and next action. additionalProperties:false used to make those columns unrepresentable,
    # so a PASS row could carry no rights or cost record at all. A PASS-status row must now
    # declare all four, and uncleared/blocked rights contradict a PASS (rule 21).
    if a.get("status") == "PASS":
        rights_ok = str(a.get("rightsStatus", "")).strip() in {"cleared", "restricted"}
        ok = rights_ok and ok
        if not rights_ok:
            arms.append("rights-vs-pass")
        for field, tag in (("costAttempts", "cost-attempts"), ("owner", "owner"), ("nextAction", "next-action")):
            present = a.get(field)
            good = isinstance(present, dict) if field == "costAttempts" else str(present or "").strip() != ""
            ok = good and ok
            if not good:
                arms.append(tag)
        ca = a.get("costAttempts") if isinstance(a.get("costAttempts"), dict) else {}
        ca_ok = isinstance(ca.get("attempts"), int) and isinstance(ca.get("computeCents"), int)
        ok = ca_ok and ok
        if not ca_ok:
            arms.append("cost-attempt-integers")
    promo_ok = a.get("promotionEligible") is False
    ok = promo_ok and ok
    if not promo_ok:
        arms.append("promotion-eligible")
    return check(ok, "STATE_ASSET_INVALID",
                 f"{where}: asset entry violations; arms={','.join(arms) or 'none'}")


def validate_contract_audience(obj, where):
    """v8.1.2: drive the contract-schema audience arm (A1) so its negative fixture is executed.
    The 8.0.3 file shipped unregistered — the completeness reconciliation caught it."""
    from validate_contract_schema import validate_project_contract
    errs = validate_project_contract(obj)
    paths = {e.get("path") for e in errs}
    if any(str(p).startswith("$.audience") for p in paths):
        check(False, "CONTRACT_SCHEMA_ERROR", f"{where}: audience arm fired ({sorted(p for p in paths if p)})")
    else:
        check(True, "CONTRACT_AUDIANCE_ARM_RAN", f"{where}: audience arm did not fire ({sorted(p for p in paths)})")


def validate_package_decl(obj, where):
    """v8.1.2 (D1): exercise the delivery-package gate directly so its negative fixture can be
    driven by this battery. The gate is the shared accept-set; an unrecognised version must be
    an ERROR (PACKAGE_VERSION_UNSUPPORTED), never a silent skip."""
    from validate_delivery_package import validate_package
    errs = validate_package(obj, {"statusMetadata": {"maturity": "PLAN_PASS",
                                                    "media": "NOT_GENERATED"}},
                            package_root=None)
    if any(e.get("code") == "PACKAGE_VERSION_UNSUPPORTED" for e in errs):
        check(False, "PACKAGE_VERSION_UNSUPPORTED", f"{where}: package gate flagged the version")
    else:
        check(True, "PACKAGE_GATE_RAN", f"{where}: package gate accepted the version ({len(errs)} finding(s))")


def validate_handoff(h, where):
    # v8.1.2 (BL2): this function checked 5 of the schema's 11 required fields. marker,
    # schemaVersion, projectId, sessionId and promotionEligibleInfluence were declared by the
    # schema and NEVER enforced, so an unverified handoff packet passed as checked - the exact
    # failure mode the operator's queue rule names. Every required field is now enforced here.
    ok = bool(str(h.get("producerVersion", "")).strip())
    ok = h.get("executionProfile") in {"FULL", "CONTROLLED", "INSUFFICIENT"} and ok
    # versionMeta is checked by shape (its fields carry the real rules, so delegate)
    vm = h.get("versionMeta")
    ok = isinstance(vm, dict) and str(vm.get("ruleVersion", "")).strip() != "" and ok
    # marker: the embedded-state marker must be present and self-identifying
    mk = h.get("marker")
    ok = isinstance(mk, dict) and bool(str(mk.get("markerId", "")).strip()) and ok
    # schemaVersion must agree with the tree, or a stale handoff passes as current
    ok = str(h.get("schemaVersion", "")).strip() == TREE_VERSION and ok
    # projectId and sessionId: a handoff without an identity is not a handoff
    ok = bool(str(h.get("projectId", "")).strip()) and ok
    ok = bool(str(h.get("sessionId", "")).strip()) and ok
    # promotionEligibleInfluence must be EXPLICITLY NONE - a default would let an absent field
    # pass, which is the defect BL2 exists to close (caught by the non-vacuity proof).
    ok = "promotionEligibleInfluence" in h and str(h.get("promotionEligibleInfluence")).upper() == "NONE" and ok
    re_ok = set(h.get("resetExempt", [])) <= {"approvalState", "versionMeta", "dagState", "assetLedger", "evidenceChain"}
    ok = re_ok and ok
    if "approvalState" in h.get("resetExempt", []) and h.get("approvalState") is None:
        ok = False
    ok = validate_policy_constants(h, where) and ok
    ok = h.get("promotionEligible") is False and ok
    return check(ok, "STATE_HANDOFF_INVALID", f"{where}: handoff packet violations")


def locked_model_ids():
    """Locked models resolve from the guide registry (v8.0.3 / B6), never a literal tuple."""
    try:
        reg = json.loads((ROOT / "mcp/model_guides/LOCKED_MODELS.json").read_text(encoding="utf-8"))
        return {m.get("modelId") for m in reg.get("lockedModels", [])}
    except Exception:
        return set()


def validate_switch(s, where):
    models = locked_model_ids()
    ok = s.get("fromModel") in models
    ok = s.get("toModel") in models and ok
    ok = s.get("executionProfileAfter") == "CONTROLLED" and ok
    vl = s.get("videoLedger", {})
    ok = vl.get("recomputed") is True and ok
    ok = vl.get("chainDepth", 99) <= 3 and ok
    ok = vl.get("repairsUsed", 99) <= 2 and ok
    ok = validate_policy_constants(s, where) and ok
    ok = s.get("promotionEligible") is False and ok
    return check(ok, "STATE_SWITCH_INVALID", f"{where}: model switch packet violations")


def validate_diagnostic(d, where):
    ok = d.get("catalogItem") in CATALOG
    ok = d.get("costTier") in {"LOW", "MED", "HIGH"} and ok
    ok = d.get("promotable") is False and ok
    ok = d.get("gateDecisionAuthority") == "QUALITATIVE_ONLY" and ok
    bl = d.get("budgetLedger", {})
    ok = bl.get("deliveryBudgetTouched") is False and ok
    for i, sr in enumerate(d.get("signalReadings", []) or []):
        if sr.get("authorityClass") != "C_PERCEPTUAL_PROVISIONAL":
            ok = False
        if sr.get("calibrationStatus") != "CALIBRATION_REQUIRED":
            ok = False
        if sr.get("value") is not None and not sr.get("evidenceRefs"):
            ok = False
    ok = validate_policy_constants(d, where) and ok
    ok = d.get("promotionEligible") is False and ok
    return check(ok, "STATE_DIAGNOSTIC_INVALID", f"{where}: diagnostic result violations")


def main():
    # 1. Schemas parse and are structurally sound
    schema_files = [
        "schemas/artifacts/_avd_defs.schema.json",
        "schemas/artifacts/GATE_RECEIPT.schema.json",
        "schemas/artifacts/ASSET_TRACKER_ENTRY.schema.json",
        "schemas/artifacts/HANDOFF_PACKET.schema.json",
        "schemas/artifacts/MODEL_SWITCH_PACKET.schema.json",
        "schemas/artifacts/DIAGNOSTIC_RESULT.schema.json",
        "schemas/PRODUCTION_STATE.schema.json",
    ]
    for sf in schema_files:
        p = ROOT / sf
        if not p.exists():
            check(False, "STATE_SCHEMA_MISSING", sf)
            continue
        try:
            s = load_json(p)
            check(s.get("$schema", "").endswith("2020-12/schema"), "STATE_SCHEMA_DRAFT", f"{sf}: $schema must be 2020-12")
            check("$id" in s, "STATE_SCHEMA_ID", f"{sf}: $id present")
        except Exception as ex:
            check(False, "STATE_SCHEMA_PARSE", f"{sf}: {ex}")

    # no network resolution: refs must be local
    for sf in schema_files:
        p = ROOT / sf
        if not p.exists():
            continue
        text = p.read_text(encoding="utf-8")
        for m in re.finditer(r'"\$ref"\s*:\s*"([^"]+)"', text):
            ref = m.group(1)
            check(not ref.startswith(("http://", "https://")), "STATE_REF_EXTERNAL", f"{sf}: external ref {ref}")

    # 2. Manifest integrity
    try:
        man = load_json(ROOT / "schemas/PRODUCTION_STATE.schema.json")
        arts = man["properties"]["artifactSchemas"]["properties"]
        for k, v in arts.items():
            check((ROOT / v["const"]).exists(), "STATE_MANIFEST_PATH", f"artifactSchemas.{k} -> {v['const']}")
        ccs = man["properties"]["composedContractSchemas"]["properties"]
        for k, v in ccs.items():
            check((ROOT / v["properties"]["path"]["const"]).exists(), "STATE_MANIFEST_CONTRACT", f"composedContractSchemas.{k}")
        check(man["properties"]["promotionLane"]["const"] == "withheld-in-8.0.0", "STATE_LANE", "promotionLane withheld")
    except Exception as ex:
        check(False, "STATE_MANIFEST_INVALID", f"PRODUCTION_STATE.schema.json: {ex}")

    # 3. Positive examples conform
    exdir = ROOT / "schemas/examples"
    validators = {
        "gate-receipt.example.json": validate_gate_receipt,
        "asset-tracker-entry.example.json": validate_asset_entry,
        "handoff-packet.example.json": validate_handoff,
        "model-switch-packet.example.json": validate_switch,
        "diagnostic-result.example.json": validate_diagnostic,
    }
    if exdir.exists():
        for fn, val in validators.items():
            p = exdir / fn
            if not p.exists():
                check(False, "STATE_EXAMPLE_MISSING", fn)
                continue
            try:
                obj = load_json(p)
                check(SEMVER.match(str(obj.get("schemaVersion", ""))) is not None, "STATE_EXAMPLE_VERSION", fn)
                val(obj, fn)
            except Exception as ex:
                check(False, "STATE_EXAMPLE_PARSE", f"{fn}: {ex}")

    # 4. Negative fixtures must FAIL the right check
    negdir = ROOT / "schemas/examples/negative_tests"
    expected_fail = {
        "receipt_over_budget.json": "budget",
        "receipt_score_no_evidence.json": "evidence",
        "switch_hardcoded_cap.json": "cap",
        "asset_bad_name.json": "name",
        "handoff_not_self_describing.json": "producer",
        "digest_placeholder_zero.json": "digest",
        "digest_placeholder_ff.json": "digest",
        # F-1 receipt-overlay fixtures (shipped 8.0.2; registered here in 8.0.3 - see the
        # 8.0.3 ledger entry: 8.0.2 shipped these files but nothing executed them, so the
        # 8.0.2 claim "rejected as designed by the fixture battery" was not backed by a run)
        "receipt_unregistered_role.json": "role-registry",
        "receipt_duplicate_role.json": "role-distinctness",
        "receipt_role_out_of_scope.json": "role-scope",
        "receipt_two_absolute_vetoes_stay_pass.json": "veto-aggregation",
        "receipt_r8_conditional_open_pass.json": "r8-conditional",
        # A2a: a PASS row whose rights are uncleared contradicts rule 21
        "asset_pass_uncleared_rights.json": "rights-vs-pass",
    }
    # 4. Negative fixtures must FAIL THE RIGHT CHECK (v8.1.2 / M3)
    #
    # The v8.0.3 loop had two defects, both found by external review and reproduced here:
    #   (a) it GLOBBED the directory, so a fixture that was never registered was never run and
    #       never reported - "7 of 8 ran" looked identical to "all 8 ran";
    #   (b) it asserted `after > before`, i.e. THAT SOMETHING failed - so a fixture broken for an
    #       unrelated reason still counted as a pass.
    # Now: a REGISTERED map is the source of truth; every registered fixture must exist, must be
    # executed, and must be rejected FOR ITS OWN REASON (the expected check ID must appear in
    # the failure text). Any fixture file on disk that is not registered is reported, not ignored.
    negdir = ROOT / "schemas/examples/negative_tests"
    # fixture file -> (validator callable, expected reason token)
    NEG_REGISTRY = {
        "receipt_over_budget.json": (validate_gate_receipt, "STATE_RECEIPT_INVALID"),
        "receipt_score_no_evidence.json": (validate_gate_receipt, "STATE_RECEIPT_INVALID"),
        "switch_hardcoded_cap.json": (validate_switch, "STATE_SWITCH_INVALID"),
        "asset_bad_name.json": (validate_asset_entry, "arms=filename-pattern"),
        "handoff_not_self_describing.json": (validate_handoff, "STATE_HANDOFF_INVALID"),
        "digest_placeholder_zero.json": (validate_digest, "STATE_DIGEST_INVALID"),
        "digest_placeholder_ff.json": (validate_digest, "STATE_DIGEST_INVALID"),
        "receipt_unregistered_role.json": (validate_gate_receipt, "STATE_RECEIPT_INVALID"),
        "receipt_duplicate_role.json": (validate_gate_receipt, "STATE_RECEIPT_INVALID"),
        "receipt_role_out_of_scope.json": (validate_gate_receipt, "STATE_RECEIPT_INVALID"),
        "receipt_two_absolute_vetoes_stay_pass.json": (validate_gate_receipt, "STATE_RECEIPT_INVALID"),
        "receipt_r8_conditional_open_pass.json": (validate_gate_receipt, "STATE_RECEIPT_INVALID"),
        "asset_pass_uncleared_rights.json": (validate_asset_entry, "arms=rights-vs-pass"),
        "package_unsupported_version.json": (validate_package_decl, "PACKAGE_VERSION_UNSUPPORTED"),
        "contract_8x_missing_audience.json": (validate_contract_audience, "CONTRACT_SCHEMA_ERROR"),
    }
    if negdir.exists():
        expected_names = set(NEG_REGISTRY)
        on_disk = {p.name for p in negdir.glob("*.json")}

        # (a) completeness in both directions
        for missing in sorted(expected_names - on_disk):
            check(False, "STATE_NEG_FIXTURE_MISSING",
                  f"registered fixture {missing} does not exist - it would never run")
        for unregistered in sorted(on_disk - expected_names):
            check(False, "STATE_NEG_FIXTURE_UNREGISTERED",
                  f"{unregistered} is on disk but not in NEG_REGISTRY - it would never be executed")

        for name in sorted(expected_names & on_disk):
            fn = negdir / name
            vf, reason = NEG_REGISTRY[name]
            try:
                obj = load_json(fn)
            except Exception as ex:
                check(False, "STATE_NEG_PARSE", f"{name}: {ex}")
                continue
            before = len(FAILURES)
            vf(obj, name)
            after = len(FAILURES)
            if after <= before:
                check(False, "STATE_NEG_MUST_FAIL", f"{name}: expected violation, fixture passed")
                continue
            # (b) right reason: the failure text must name the check this fixture targets
            produced = [f for f in FAILURES[before:after] if reason in f]
            if produced:
                # pop the produced failure so negatives don't poison the tally
                FAILURES.pop(before + FAILURES[before:after].index(produced[0]))
                PASSES.append(f"STATE_NEG_EXPECTED_FAIL: {name} rejected as designed ({reason})")
            else:
                # Remove the fixture's own (wrong-reason) failures FIRST, then record the
                # finding. Recording first and clearing after would erase our own result -
                # a check that deletes its own output is the silent-pass shape we are fixing.
                del FAILURES[before:]
                check(False, "STATE_NEG_WRONG_REASON",
                      f"{name}: failed, but not for {reason!r} - it failed for another reason, "
                      f"which is not evidence that the intended rule works")

    # 5. Canary: the stale canary must declare 7.4.0 and stay in the tree.
    #    Canary declares 7.4.0 BY DESIGN - a canary that matches the tree version
    #    has been repaired and is a defect.
    canary = ROOT / "test/canary/stale_version_template.json"
    if canary.exists():
        c = load_json(canary)
        check(c.get("schemaVersion") == "7.4.0", "STATE_CANARY_VERSION", "canary must stay stale at 7.4.0 (repaired canary = defect)")
        check(c.get("canaryContract", {}).get("expectedDeclaredVersion") == "7.4.0", "STATE_CANARY_CONTRACT", "canary contract intact")
        # v8.0.2 (minor b): the contract is read, not merely declared. expectedTreeVersion
        # must track the live release version, and every baseline reference the contract
        # names as a concrete file must exist. (A contract entry that is prose — e.g.
        # "validators/... candidate set" — names a sweep, not a file, and is not a path check.)
        release = load_json(ROOT / "release/RELEASE.json")
        cur_ver = release.get("version")
        check(c.get("canaryContract", {}).get("expectedTreeVersion") == cur_ver,
              "STATE_CANARY_CONTRACT_VERSION",
              f"canaryContract.expectedTreeVersion {c.get('canaryContract', {}).get('expectedTreeVersion')!r} == release version {cur_ver!r}")
        for ref in c.get("canaryContract", {}).get("mustNeverAppearIn", []):
            ref = str(ref)
            if ref.endswith(".json") and "/" in ref:
                check((ROOT / ref).exists(), "STATE_CANARY_CONTRACT_PATH",
                      f"canary contract names existing baseline file: {ref}")

    # 5b. v8.0.2 (F-2b): the tightened MARKER grammar is now live code - sweep every
    #     text host in the tree for an embedded AVD:STATE comment marker, parse it per
    #     the grammar, fail on malformed grammar or duplicate markerId, and recompute
    #     any bound digest claim. (Currently zero markers ship - the sweep documents
    #     and encodes that enforcement, replacing the dead regex + never-called
    #     validate_marker with a wired arm. Proof of life: it fails on bad hosts.)
    marker_hosts = []
    for sd in ("templates", "schemas", "rules", "adapters", "mcp", "bootstrap", "profiles", "routing", "dev"):
        base = ROOT / sd
        if base.is_dir():
            marker_hosts.extend(p for p in base.rglob("*") if p.is_file() and p.suffix in (".md", ".txt", ".json"))
    roots_root = [p for p in ROOT.glob("*.md") if p.is_file()]
    marker_hosts.extend(roots_root)
    markers_found = 0
    for host in sorted(marker_hosts):
        try:
            text = host.read_text(encoding="utf-8")
        except Exception:
            continue
        markers_found += validate_marker_comment(text, host.relative_to(ROOT).as_posix())
    check(True, "STATE_MARKER_SWEEP", f"marker sweep ran: 0+ markers legal by grammar; live count = {markers_found}")

    # Marker grammar negative battery (in-memory probes; the empty tree sweep above
    # would otherwise prove nothing).
    good = "<!-- AVD:STATE id=P-X01 schema=S-1 version=8.0.2 artifact=A-1 path=templates/X.md sha256=UNCOMPUTED -->"
    bad_dup = good + "\n" + good
    bad_grammar = "<!-- AVD:STATE id=P-X02 schema=S-1 version=8.0.2 artifact=A-1 path=templates/X.md sha256=0000000000000000000000000000000000000000000000000000000000000000 -->"
    before = len(FAILURES)
    validate_marker_comment(good, "probe/good")
    check(len(FAILURES) == before, "STATE_MARKER_PROBE_GOOD", "well-formed marker probe parses clean")
    before = len(FAILURES)
    validate_marker_comment(bad_dup, "probe/duplicate")
    check(len(FAILURES) > before, "STATE_MARKER_PROBE_DUP", "duplicate marker probe fails as designed")
    while len(FAILURES) > before:
        FAILURES.pop()
    before = len(FAILURES)
    validate_marker_comment(bad_grammar, "probe/null-hash")
    check(len(FAILURES) > before, "STATE_MARKER_PROBE_GRAMMAR", "null-hash marker fails the tightened grammar")
    while len(FAILURES) > before:
        FAILURES.pop()

    # 6. Tree-wide stale-label sweep (R651-class): every shipped JSON under templates/,
    #    schemas/, validators/, dev/ with a line-2 schemaVersion must declare the tree
    #    version. EXEMPT: the canary (immutable fixture) and release/ historical
    #    records (baseline files are era records; rewriting their labels would
    #    falsify history - the retired-names-as-provenance doctrine).
    tree_version = TREE_VERSION
    if not tree_version:
        check(False, "TREE_VERSION_UNREADABLE", "release/RELEASE.json could not be read for the tree version")
    sweep_dirs = ["templates", "schemas", "validators", "dev", "rules"]
    for sd in sweep_dirs:
        base = ROOT / sd
        if not base.exists():
            continue
        for p in base.rglob("*.json"):
            if p == canary:
                continue
            try:
                first = p.read_text(encoding="utf-8").splitlines()
            except Exception:
                continue
            if len(first) >= 2 and "schemaVersion" in first[1]:
                m = re.search(r'"schemaVersion"\s*:\s*"([^"]+)"', first[1])
                if m and m.group(1) != tree_version:
                    # versionMeta migratedFrom may explain a stale label only when the
                    # label was repaired in place (line 2 already bumped). Line-2 stale
                    # labels are hard failures.
                    check(False, "STATE_STALE_LABEL", f"{p.relative_to(ROOT)}: line-2 schemaVersion {m.group(1)} != {tree_version}")

    print(json.dumps({
        "schemaVersion": "8.1.2",
        "validator": "validate_state_serialization.py",
        "pass": not FAILURES,
        "passed": len(PASSES),
        "failed": len(FAILURES),
        "failures": FAILURES,
    }, indent=2, ensure_ascii=False))
    sys.exit(0 if not FAILURES else 1)


if __name__ == "__main__":
    main()
