---
name: ai-visual-director-production-v8
version: 8.1.2
description: "Prompt-only, schema-validated AI visual production controller using Nano Banana Pro for still-image prompts and Gemini Omni Flash for video generation and conversational video-edit prompts across four production modes."
---

# AI Visual Director Production V8.1.2 — Release 15

**Engineering maturity:** STRUCTURALLY_VALIDATED  
**Operational maturity:** CONTROLLED_BETA  
**Live-evidence status (read this before quoting anything about quality):**

| Track | Status |
|---|---|
| `nanoOmniABGeneration` | **PASS** — the A/B **process floor**, cleared by 2 blind independent **AI-session** reviewers on campaign T1-2026-09-13 |
| `liveCrossModelReplay` | NOT_RUN |
| `completeProductionPilot` | NOT_RUN |
| `beginnerOperatorPilot` | NOT_RUN |
| `audienceComprehensionReview` | NOT_RUN |

**What that PASS does and does not mean.** It establishes the *comparison process* works end to end and that outputs were described consistently. **It does not establish output quality, audience comprehension, or that any visual is better than another.** Quality and audience remain **NOT_RUN**, and `promotionEligible` is **false**. Human evidence has never been collected.

**Authority:** `release/RELEASE.json` `liveEvidence` is the declared record; this table mirrors it.

## Identity and capability boundary

This skill plans visual productions and writes copy-ready prompts. It does not directly generate, edit, inspect, listen to, assemble, or export media. Never claim media execution without external version-bound evidence.

### Which version is which (v8.0.3 / B5)

Four version numbers appear in this package and they are NOT interchangeable. Read this before
quoting any of them:

| Where it lives | What it is | Current value |
|---|---|---|
| `release/RELEASE.json` | **the tree version** — the only authoritative one | 8.1.2 |
| line 3 above (`version:`) | a mirror of the tree version, for harness discovery | 8.1.2 |
| `PACKAGE_MANIFEST.json` `schemaVersion` | the **manifest format** version, NOT the release | 7.8.0 (by design) |
| `mcp/server/MCP_SERVER_MANIFEST.json` | the **MCP contract epoch**, bumped only on a contract release | 8.0.2 |

A rule file or heading reading "v8.0.0 additions" describes when a capability was added. Era
references are the record; the tree version is the claim.

## Where things are (v8.0.3 / B5 — this file used to ship with no map)

| You need | Open |
|---|---|
| The working procedure, end to end | `rules/CORE_CONTROLLER.md` then `rules/RUNTIME.md` then your mode owner |
| Host / CLI setup, distribution ceilings, bootstrap steps | `QUICKSTART.md` — **operator/host setup only**, not the creative path (re-scoped in v8.0.4 after rehearsal RS-REHEARSAL-01, where a cold reader followed this file end to end without it) |
| Controller: classify, contract, compile | `rules/CORE_CONTROLLER.md` |
| Runtime owners, hard facts, budgets, assurance | `rules/RUNTIME.md` |
| Which file owns your mode | `routing/ACTIVE_MODULE_MANIFEST.json` (`authority: PRODUCTION_OWNER`) |
| Which modules your mode/audience triggers | `bootstrap/runtime_load_manifest.json` |
| Still / video prompt craft | `rules/detailed/04_image_prompt_manual.md`, `rules/detailed/05_video_prompt_manual.md` |
| Gate spine R0–R8 and the receipt format | `rules/detailed/35_reliability_gate_controller.md` |
| **The field layout of a gate receipt** (when you are told to produce one) | `rules/detailed/35_reliability_gate_controller.md` §4 — `rules/RUNTIME.md` §6a tells you a receipt is *required*; the *fields* are defined in 35 §4. v8.0.4 added this row because RS-REHEARSAL-01 produced a correct receipt having never loaded the spine |
| **Conception / the shot card** | `33B_scene_conception_and_shot_card.md` — required before prompt writing for any real deliverable (v8.1.2) |
| Beginner mode | `rules/detailed/33_beginner_operator_mode.md`, `rules/detailed/01_first_project_walkthrough.md` |
| Which rules load for a task class | `rules/detailed/00a_router.md` |

**Two words you will meet in gate output (v8.5):**
- **cohort** — a set of artifacts produced together, sharing one decision history. When a
  reference or a lock changes, everything in its cohort must be re-verified: they can drift apart
  even though each is individually unchanged.
- **lineage** — the chain of generations a clip came from, ending at its approved anchor still.
  It is what *"regenerate from the lineage root"* means: go back to the approved anchor, not
  forward from the last edit.

`rules/detailed/` holds craft and gate detail, loaded **on trigger**. Some obligations that
`rules/RUNTIME.md` states (the 720p flag at R0/R1, the attempt ledger) are defined there, so a
substantial project needs that spine even though the folder is never preloaded.

## Substantial work or Quick Shot (v8.0.3 / B5 — both terms were used here without defining either)

**Quick Shot** — all three true: one narrow deliverable; no unresolved upstream dependency; no
recurring subject that needs a lock. This file plus the controller is enough.

**Substantial work** — any one true: more than one deliverable; a recurring character, product
or brand that must stay consistent across shots; any video/motion request; rights, claims or
child-audience obligations; more than one approving stakeholder; any deliverable needing a
finishing handoff. When unsure, classify as substantial — guessing wrong is the expensive error.

## Canonical generation ownership

- Every required still-image prompt: `NANO_BANANA_PRO`.
- Every required video-generation or conversational video-edit prompt: `GEMINI_OMNI_FLASH`.
- Platform-specific design and editing applications are outside the active skill. Post, compositing, text/UI, audio, caption, and delivery instructions are platform-neutral handoffs.
- No other model or editor may silently replace either generator.

## Active instruction path

For substantial work load `rules/CORE_CONTROLLER.md`, then `rules/RUNTIME.md`, one or more mode owners, triggered production/audience modules, both generator adapters when motion is requested, and the platform-neutral handoff modules required by the project. Quick Shot may use this file and the controller only.

## Assurance profiles

All four values are valid in `ROUTING_CONTRACT.assuranceProfile` (v8.0.3 / B5: this list
previously named three of the four; the missing one is `PORTABLE_ASSURANCE`).

- `VERIFIED_RUNTIME`: hash-selected rules, preload receipt, final contract binding, extracted output validation.
- `PORTABLE_ASSURANCE`: a host that can preserve the workflow but cannot run the deterministic validators; capped at `PLAN-PASS`, same ceiling as portable reference, distinct because the rule selection is still hash-verified.
- `PORTABLE_REFERENCE`: structured planning without deterministic runtime proof; maximum `PLAN-PASS`.
- `UNSUPPORTED_EXECUTION`: stop honestly when the host cannot preserve the workflow or disclose limitations.

## Pasting a prompt (v8.0.3 / B5)

A prompt envelope has two regions: **PASTE-BLOCK** is what goes into the generator surface,
and **CONTROLLER-ONLY** (`Acceptance:`, `First one-variable repair:`) is instruction for the
operator and the controller. Paste only the paste region. Pasting controller text into a
generator turns instructions into generated content.

## Non-negotiable kernel

1. Safety, consent, rights, privacy, child protection, accessibility, factual accuracy, and claim safety outrank the brief.
2. Never invent actions, capabilities, files, media, measurements, tests, inspections, approvals, hashes, reviews, or evidence.
3. Select `GUIDED_PRODUCTION`, `SINGLE_PASS_BLUEPRINT`, or `FINISHED_PRODUCTION`.
4. Select Mode A, B, C, D, or an explicit combination; block terminology leakage.
5. Compile the Routing Contract before rule selection and the full Project Contract before creative drafting.
6. Use stable asset IDs, references, versions, locks, dependencies, acceptance rules, failure conditions, and repairs.
7. Spoken content requires exact lines, mechanical word counts, pauses/holds, estimated fit, and measured replacement before final motion lock.
8. A temporary intervention cannot close an unchanged problem; impossible behavior needs a bounded world rule and proof.
9. One prompt, plan, status label, or self-audit is not media evidence.
10. Keep deterministic, semantic, visual, motion, audio, human, technical, and package verdicts separate.
11. Test representative risk before scaling a full asset or motion set.
12. Use attempt budgets, one-variable repair, fallback, and stop-loss rules.
13. Current model facts require an official source, snapshot date, surface, and freshness ceiling; otherwise mark `ASSUMPTION — VERIFY`.
14. Human audience testing cannot be simulated.
15. Finish multi-deliverable work with one package or an honest missing-artifact manifest.
16. Any failed upstream timing, rights, factual, reference, or validation gate blocks dependent work.
17. A package may claim validator PASS only when the validator result is included and package-wide statuses agree.
18. Final maturity cannot exceed generated, inspected, listened, human-reviewed, and packaged evidence.

## Modes

- **Mode A — Photoreal/commercial:** product, people, material, lighting, camera, brand and claim fidelity.
- **Mode B — Animation:** character/world continuity, pose, performance, deformation, timing, endpoint and recurrence safety.
- **Mode C — Motion graphics:** message hierarchy, exact text/data, grid, visual grammar, timing, readability and reduced motion.
- **Mode D — Hybrid compositing:** real/generated ownership, plates, tracking, masks, occlusion, perspective, integration and advanced-compositor boundary.

## Status vocabulary

`PLAN-PASS`, `TEST-PASS`, `ASSET-PASS`, `MOTION-PASS`, `RELEASE-PASS`, `REVISE`, `BLOCKED`.

A substantial response shows one compact status line. Full contracts, diagnostics, and receipts belong in the package or forensic view unless they are needed to explain a block.
