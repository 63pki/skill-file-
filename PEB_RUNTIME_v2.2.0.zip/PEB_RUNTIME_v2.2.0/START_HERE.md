# PEB RUNTIME v2.2.0 — START HERE

**Active master: `05_master_prompt/PRO_EDITOR_BRAIN_v4.2.md`.**
This user-requested creative-workflow build supersedes v2.1.1 navigation and its
freeze-for-pilot state for SYSTEM DEVELOPMENT only. No paused campaign resumes.
No package grants uploads, spending, installs, account actions or publication.

## Use
1. Read the active v4.2 master prompt with the current brief and source footage.
2. Follow `NEXT_CAMPAIGN_STARTUP.md` once. Ask only consequential missing questions.
3. Route relevant methods through `07_creative_workflow/ROUTING.md` and the existing
   `SKILL_INDEX.md`. Apply/reuse a method or state the concrete fallback; do not
   merely list skill names. Read only needed depth.
4. Keep the existing project-record/evidence-contract workflow for hash-bound
   export reviews and publish gates. The new optional creative sidecar links
   research → decisions; it does not replace delivery governance.

## Precedence
1. Current authorized brief/explicit decisions, within truthfulness/rights/evidence boundaries.
2. Active v4.2 master prompt, including relevant-method and contextual AV rules.
3. New routed methods (`07_creative_workflow/`) and existing playbook/reference modules.
4. Older masters, prior release reports/manifests, continuation documents, debriefs
   and prior campaign approvals: historical only, never next-action instructions.

The v4.1/v4.0 files and frozen core are preserved byte-identically. Their former
ACTIVE/FROZEN labels describe prior releases and do not override this entry point.
Root manifest `MANIFEST_RUNTIME_v2.2.0.json` describes this package; every older
manifest/verification is historical, not a claim about this updated tree.

## Runtime, archive and standalone use
This is the updated lightweight runtime. Ordinary workflow methods and offline
checks need no archive. The existing `PEB_ARCHIVE_REFERENCE_v2.1.1.zip` remains
unchanged and optional; its original hash/path map stays in `ARCHIVE_POINTER.md`.
Old versions and campaign evidence in that archive are not live instructions.
No new archive needs downloading. If ZIPs are unsupported, use the loose v4.2 MD
with brief and footage: it embeds the methods, but cannot provide packaged Python
helpers or install capabilities by itself. Report unavailable tools honestly.

## What's implemented versus unverified
- Methods: research, reference analysis, hook/story, art direction, AV inspection.
- Code: decision/evidence-link checker; static phone-layout preview; bounded AV-job
  wrapper reusing the SAME NVIDIA adapter. No second VLM installed.
- Tests: see `07_creative_workflow/status/BUILD_REPORT.md` for final counts/scopes.
- Live NVIDIA comprehension/current availability remains NOT_CHECKED in this build;
  inherited live fixture remains INCOMPLETE_NOT_PASSED. No key is packaged.
- Editorial effectiveness and audience response remain unproven until an authorized
  campaign pilot and real feedback/analytics. Offline tests cannot establish them.

Run all packaged test files using `python <test-file.py>`. New tests are under
`07_creative_workflow/tests/`; inherited suites remain in their original locations.
Optional layout tests need Pillow and an explicit installed font. Local media
integration needs real ffmpeg/ffprobe; neither dependency is silently installed.
