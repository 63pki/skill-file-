# Current routing update — v2.2.0

Active prompt: `05_master_prompt/PRO_EDITOR_BRAIN_v4.2.md` (supersedes the v4.1
ACTIVE reference in the preserved index below). New relevant methods and code:
`07_creative_workflow/ROUTING.md`. Consult matching methods at triggered stages;
apply/reuse or record the exact fallback. The table below still locates existing
skills/implementations; their historical capability statuses do not automatically
upgrade. No existing SKILL.md was edited. Older test counts describe prior builds.

# SKILL INDEX — PEB runtime v2.1.1 (navigation aid, not new rules)

How to use: identify the task from the brief and the footage, pick the
resources below that match, and read only those. Routing, not installation —
see `01_preserved_system/PEB_PORTABLE_v1.1.1/02_registry/SKILL_REGISTRY_v1.1.md`
("Routing, not installation") for the selection and recording discipline
(`ROUTING: primary=...; specialists=...; none_reason=...`; zero skills is
valid). "Archive" = same relative path inside
`PEB_ARCHIVE_REFERENCE_v2.1.1.zip` (SHA-256 in `ARCHIVE_POINTER.md`).

Types: **executable** = runnable code; **technique guide** = method text;
**reference example** = material to inspect, not to execute; **template** =
fill-in record; **test** = offline verification.

## Always read first

| Resource | Type | Path | When | Dependencies | Status |
|---|---|---|---|---|---|
| Active master prompt | instructions | `05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md` | every job | none | ACTIVE (v4.1 + §3 diagnostic clarification; v4.0 preserved below SUPERSEDED banner in same folder) |
| START_HERE.md | entry point | root | once per session | none | ACTIVE |
| NEXT_CAMPAIGN_STARTUP.md | workflow | root | new campaign bootstrap | none | ACTIVE (v2.1.1) |

## Craft methods (technique guides)

| Resource | Path | When | Dependencies | Status |
|---|---|---|---|---|
| Intentional Editing Methods v1.2 | `06_system_improvement/02_playbook/INTENTIONAL_EDITING_METHODS_v1.2.md` | treatment options, failure tests, brand-removal counterfactual diagnostic | none | ACTIVE; v1.1/v1.0 in same folder are superseded |
| Frozen core v3.1.1 (feel engine, tiers, recipes, campaign-profile schema) | `01_preserved_system/PEB_PORTABLE_v1.1.1/01_master_prompt/` | deeper reference when rank-3 detail is needed | none | PRESERVED byte-identical; reference depth, never overrides rank 2 |
| Frozen-core catalogs routing | `01_preserved_system/PEB_PORTABLE_v1.1.1/02_registry/SKILL_REGISTRY_v1.1.md` (+ v1.0, `PEB_v3.2_MODULE_TOOL_REGISTRY.md`, `PAPER_ROUTING_TESTS_v0.9.md`, link lists) | selecting specialists; reuse discipline | none | ACTIVE routing docs; statuses inside are historical unless re-verified |

## Executable implementations (run when relevant)

| Resource | Path | When | Dependencies | Status |
|---|---|---|---|---|
| Record validator (evidence contract) | `06_system_improvement/04_components/evidence_contract.py` | validating evidence records in a project record | Python 3 stdlib | TESTED offline (see 07_status/BUILD_RESULT_v2.1.md) |
| Probe inspector | `06_system_improvement/04_components/inspect_probe.py` | reading/validating probe JSON identity | Python 3 stdlib; ffprobe for real probes (identity UNPINNED) | TESTED offline on synthetic probes |
| Packaged test suite (8 files) | `06_system_improvement/06_tests/test_record_governance.py`, `test_evidence_contract.py`, `test_probe_inspection.py`, `test_review_and_scope_gates.py`, `test_standalone_prompt.py`, `test_diagnostic_clarification.py`, `04_vision_stages/tests/test_contracts.py`, `04_vision_stages/tests/test_creative_gate.py` | verifying records, gates, prompt guards, vision contracts, creative gate | Python 3 stdlib only; fixtures in `04_vision_stages/fixtures/` (kept in runtime) | TESTED offline in this split — results in `VERIFICATION_AND_CHANGES_v2.1.1.md` |
| External AV-model tools (optional) | `02_nvidia/tools/analyze_av.py`, `02_nvidia/evidence/NVIDIA_P02_ANALYSIS_HANDOFF/client.py`, `02_nvidia/evidence/NVIDIA_P02_ANALYSIS_HANDOFF/check_audio.py` | only IF a campaign authorizes external AV analysis AND a key is provisioned | API key (NOT packaged) + explicit authorization | UNTESTED in this environment; protocol in `02_nvidia/USAGE_AND_VERIFICATION.md` |
| Frozen-core components | `01_preserved_system/PEB_PORTABLE_v1.1.1/05_components/` | historical reference implementations | varies | PRESERVED; audit only, not re-verified here |

## Templates (fill-in records)

| Resource | Path | When | Status |
|---|---|---|---|
| Project record template v2.0 | `06_system_improvement/05_templates/PROJECT_RECORD_TEMPLATE_v2.0.json` | fresh project record for every campaign | ACTIVE; `PROJECT_RECORD_TEMPLATE.json` (v1) superseded |
| Record guide v2.1 | `06_system_improvement/05_templates/RECORD_GUIDE_v2.1.md` | how to fill hash-bound review rows + verdict publish gates | ACTIVE; `RECORD_GUIDE.md` and `RECORD_GUIDE_v2.0.md` superseded |

## Catalogs and resources (technique guides + reference examples)

| Resource | Type | Path | When | Dependencies | Status |
|---|---|---|---|---|---|
| Caption library v2 | technique guide | `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | captions, titles, labels by role (SR-40) | none to read; a compositor to render | TEXT HERE; visual samples → Archive |
| Effects & captions spec v2 (+schema) | parameter spec | same folder, `EFFECTS_AND_CAPTIONS_SPEC_v2.json` (+ `EFFECTS_AND_CAPTIONS_SPEC_v2.schema.json`) | parameters after treatment chosen (SR-41) | compositor; audio entries need authorized assets | HERE; entries are not executable adapters |
| 20 motion styles | reference examples + executable render scripts | `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/` (per style, e.g. `claude-motion-styles-20/motion-pixel-art/SKILL.md`, `.../motion-pixel-art/template.html`, `.../motion-pixel-art/render.py`) | stylized motion reference (SR-42) | per-style Python deps stated in each render.py; not feature-tested here | Code/templates HERE; `preview.jpg` ×20, `PREVIEW-all-20-styles.mp4` → Archive (optional visual reference) |
| Pastel-indigo motion graphics | technique guide | `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | pastel explainer motion (SR-43) | none to read | HERE (text only; author-claimed recipes, re-token explicitly) |
| Malayalam reel editing | technique guide | `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | Malayalam text/shaping workflow (SR-44) | font glyph coverage check | HERE (strip foreign environment instructions) |
| SaaS animation course | reference example (copyrighted) | **Archive**: `01_preserved_system/.../SaaS-Animation-Videos-with-Claude.pdf` | storyboard craft reference (SR-45) | PDF reader | ARCHIVE ONLY; no reproduction rights implied |
| New resources card | routing card | `01_preserved_system/PEB_PORTABLE_v1.1.1/02_registry/NEW_RESOURCES_2.md` | motion timing/choreography (SR-46), NullMotion reference | none | HERE |

## Optional depth modules (not needed for ordinary editing)

| Resource | Path | Notes |
|---|---|---|
| Vision stages module | `04_vision_stages/01_master_prompt/PEB_VISION_STAGES_v1.0.md` (+ `tests/`, `fixtures/`, records) | optional V1/V2/V3 vision-evidence workflow; offline fixtures and contract tests HERE; real-VLM use is approval-gated; fixture status INCOMPLETE_NOT_PASSED (truthful). Past-analysis media → Archive |
| NVIDIA usage protocol | `02_nvidia/USAGE_AND_VERIFICATION.md` | external AV-model verification protocol; key provisioning pending; referenced analysis media → Archive |
| Debriefs A/B + adoption matrix | `06_system_improvement/03_evidence/` | evidence basis of the creative lessons; do not execute; evidence images → Archive |

## Archive-resident (optional; same relative paths in `PEB_ARCHIVE_REFERENCE_v2.1.1.zip`)

- `03_current_project/**` — RexTrix history, paused (evidence only).
- `04_vision_stages/reference_review/**` — past-analysis media + decode logs.
- Catalog media: `claude-motion-styles-20` previews + preview reel, `SaaS-Animation-Videos-with-Claude.pdf`.
- Superseded release records: older manifests/verifications, `CHANGE_REPORT_v2.0.md`, `START_HERE_v1.3.2_HISTORY.md`, nested `PRO_EDITOR_BRAIN_v3.1.1_TEST.zip` + `upload/*.zip`.

Navigation checks for representative tasks (dialogue editing, captions,
reframing, authorized narration/graphics treatment) are recorded in
`VERIFICATION_AND_CHANGES_v2.1.1.md`. Passing navigation is a locating check,
not a creative-quality result.
