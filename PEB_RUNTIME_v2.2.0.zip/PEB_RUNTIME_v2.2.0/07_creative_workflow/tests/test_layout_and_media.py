import importlib.util,json,os,shutil,subprocess,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
layout=load('layout_preview_test',ROOT/'07_creative_workflow/components/layout_preview.py')
av=load('av_workflow_test',ROOT/'07_creative_workflow/components/av_workflow.py')
try:
 from PIL import Image
 HAS_PIL=True
except ImportError:HAS_PIL=False
FONT=None
if shutil.which('fc-match'):
 v=subprocess.check_output(['fc-match','-f','%{file}','Liberation Sans'],text=True).strip()
 if Path(v).is_file():FONT=Path(v)
@unittest.skipUnless(HAS_PIL and FONT,'Pillow + an explicit installed font required; no installation performed')
class LayoutTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.b=Path(self.t.name);Image.new('RGB',(640,360),'#208ac0').save(self.b/'frame.png')
 def tearDown(self):self.t.cleanup()
 def test_landscape_not_zoom_cropped(self):
  r=layout.render(self.b/'frame.png',self.b/'out.png',FONT,'A deliberate frame')
  self.assertEqual(r['contained_size'],[960,540]);self.assertEqual(r['phone_size'],[360,640]);self.assertEqual(Image.open(self.b/'out.png').size,(1080,1920))
 def test_editorial_square_panel(self):self.assertEqual(layout.render(self.b/'frame.png',self.b/'out.png',FONT,'Editorial frame','editorial_panel')['profile'],'editorial_panel')
 def test_portrait_keeps_composition(self):
  Image.new('RGB',(360,640),'#208ac0').save(self.b/'frame.png');r=layout.render(self.b/'frame.png',self.b/'out.png',FONT,'','full_bleed');self.assertEqual(r['contained_size'],[1080,1920])
 def test_missing_font_no_silent_fallback(self):
  with self.assertRaises(ValueError):layout.render(self.b/'frame.png',self.b/'out.png',self.b/'missing.ttf')
 def test_overlong_word_fails(self):
  with self.assertRaises(ValueError):layout.render(self.b/'frame.png',self.b/'out.png',FONT,'W'*100)
 def test_text_overflow_fails(self):
  with self.assertRaises(ValueError):layout.render(self.b/'frame.png',self.b/'out.png',FONT,'many lines '*100)
 def test_original_preserved_no_overwrite(self):
  layout.render(self.b/'frame.png',self.b/'out.png',FONT)
  with self.assertRaises(FileExistsError):layout.render(self.b/'frame.png',self.b/'out.png',FONT)
 def test_invalid_phone_geometry_fails(self):
  with self.assertRaises(ValueError):layout.render(self.b/'frame.png',self.b/'out.png',FONT,phone_width=0)
@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'real ffmpeg/ffprobe required for local fixture; no install')
class LocalMediaIntegration(unittest.TestCase):
 def test_actual_proxy_and_shared_budget_with_injected_transport(self):
  import datetime as dt
  with tempfile.TemporaryDirectory() as t:
   b=Path(t);source=b/'source.mp4'
   cmd=['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=320x180:r=30:d=4','-f','lavfi','-i','sine=frequency=440:sample_rate=16000:duration=4','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-shortest','-y',str(source)]
   subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=60)
   source_hash=av.sha(source)
   approval={'upload_authorized':True,'authority':'OFFLINE FIXTURE ONLY','scope':'synthetic AV fixture','terms_license_basis':'locally generated color/tone','endpoint':av.ENDPOINT,'model':av.MODEL,'expires':(dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=1)).isoformat(),'max_attempts_per_call':2,'max_http_requests':2,'allowed_source_sha256':[source_hash]}
   job={'schema_version':'1.0','mode':'pre_edit','source_path':'source.mp4','source_sha256':source_hash,'source_duration_seconds':4,'coverage_purpose':'local extraction/proxy plumbing only; no real speech test','approval_path':'approval.json','segments':[{'id':'sample','start':1,'end':3,'questions':[{'id':'action','question':'Describe visible content and sound.'}]}]}
   (b/'approval.json').write_text(json.dumps(approval));(b/'job.json').write_text(json.dumps(job));requests=[]
   class Response:
    status=200;headers={}
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def read(self):return json.dumps({'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'observations':[{'start':0,'end':1,'visible':'mock observation, not model evidence','audio':'mock tone report'}],'checks':[{'id':'action','finding':'supported','evidence':'mock response for plumbing only','start':0,'end':1}],'gaps':['No live model or speech comprehension tested.']})}}]}).encode()
   class Opener:
    def open(self,request,timeout):
     obj=json.loads(request.data);requests.append(obj);return Response()
   adapter=load('real_packaged_adapter_for_offline_transport',ROOT/'04_vision_stages/05_components/vlm_scan.py')
   with patch.dict(os.environ,{'NVIDIA_API_KEY':'offline-placeholder-not-a-credential'}),patch.object(adapter.urllib.request,'build_opener',return_value=Opener()):
    receipt=av.execute(b/'job.json',b/'run',scan=adapter.scan)
   self.assertEqual(receipt['status'],'model_returned',receipt.get('reason'));self.assertFalse(receipt['live_accuracy_verified'])
   self.assertEqual(len(requests),1);content=requests[0]['messages'][1]['content'];self.assertIn('video_url',[x['type'] for x in content]);self.assertIn('audio_url',[x['type'] for x in content])
   artifact=json.loads((b/'run/sample/artifact.json').read_text());self.assertEqual(artifact['status'],'model_returned');self.assertTrue(artifact['coverage']['audio_present'])
   self.assertFalse(artifact['coverage']['embedded_mp4_audio_tested']);self.assertLessEqual(abs(artifact['input']['proxy_duration']-artifact['input']['wav_duration']),.1)
   ledger=json.loads((b/'run/derived_approval.budget.json').read_text());self.assertEqual(ledger['http_requests_reserved'],1)
   for f in (b/'run').rglob('*.json'):self.assertNotIn('offline-placeholder',f.read_text())
if __name__=='__main__':unittest.main()
