import copy,datetime as dt,hashlib,importlib.util,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2]
def load(name):
 s=importlib.util.spec_from_file_location(name,ROOT/'07_creative_workflow/components'/f'{name}.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
wc=load('workflow_check');av=load('av_workflow')
class RecordTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.b=Path(self.t.name)
  for f in ['decision.md','preview.png','out.mp4']:(self.b/f).write_bytes(b'fixture')
  self.pack={'campaign_id':'campaign','sources':[{'id':'source','locator':'source.mp4','accessed_at':'2026-01-01','scope':'known local fixture'}],'claims':[],'reference_cards':[]}
  (self.b/'pack.json').write_text(json.dumps(self.pack))
  self.r={'schema_version':'1.0','campaign_id':'campaign','new_campaign':True,'triggered_stages':['campaign_intelligence','audiovisual_inspection','hook_story','art_direction','export_review'],'stage_routes':[{'stage':s,'state':'applied','method':'bounded test method','evidence':'fixture record','decision':'use observed contrast','artifact':'decision.md'} for s in ['campaign_intelligence','hook_story','art_direction','export_review']]+[{'stage':'audiovisual_inspection','state':'unavailable','reason':'no authorized AV route'}],'intelligence_pack':'pack.json','hook_candidates':[{'id':'h','picture':'actual visible action','sound':'original sound','words':'','words_reason':'visual-only opening','promise':'visible change','payoff':'reaction','brand_role':'permitted attribution','source_ids':['source']}],'selected_hook_id':'h','layout':{'profile':'contained','rationale':'preserve geography','text_roles':['subtitles'],'phone_preview':'preview.png','limitations':['motion untested']},'av_evidence':[{'id':'av1','status':'not_checked','reason':'no authorized route'}],'consumption':[],'export_reviews':[{'output_path':'out.mp4','sha256':wc.sha(self.b/'out.mp4'),'method':'local fixture review','scope':'scoped sample','evidence':'decision.md','verdict':'provisional_draft'}]}
 def tearDown(self):self.t.cleanup()
 def check(self):return wc.validate(self.r,self.b,'delivery')
 def savepack(self): (self.b/'pack.json').write_text(json.dumps(self.pack))
 def test_minimal_scene_led_record(self):self.assertEqual(self.check(),[])
 def test_no_key_can_be_honest_fallback(self):self.assertEqual(self.check(),[])
 def test_missing_route_fails(self):self.r['stage_routes'].pop();self.assertTrue(self.check())
 def test_skill_name_without_decision_fails(self):self.r['stage_routes'][0]['decision']='';self.assertTrue(self.check())
 def test_missing_evidence_artifact_fails(self):self.r['stage_routes'][0]['artifact']='missing';self.assertTrue(self.check())
 def test_duplicate_route_fails(self):self.r['stage_routes'].append(self.r['stage_routes'][0]);self.assertTrue(self.check())
 def test_reasonless_fallback_fails(self):self.r['stage_routes'][-1]['reason']='';self.assertTrue(self.check())
 def test_no_actual_export_cannot_deliver(self):self.r['export_reviews']=[];self.assertTrue(self.check())
 def test_changed_export_hash_fails(self):(self.b/'out.mp4').write_bytes(b'changed');self.assertTrue(self.check())
 def test_arbitrary_verdict_fails(self):self.r['export_reviews'][0]['verdict']='viral';self.assertTrue(self.check())
 def test_unknown_claim_source_fails(self):self.pack['claims']=[{'status':'supported','source_ids':['invented']}];self.savepack();self.assertTrue(self.check())
 def test_unknown_claim_with_limit_is_legal(self):self.pack['claims']=[{'status':'unknown','source_ids':[],'limitation':'no source'}];self.savepack();self.assertEqual(self.check(),[])
 def test_claim_without_evidence_fails(self):self.pack['claims']=[{'status':'supported','source_ids':[]}];self.savepack();self.assertTrue(self.check())
 def test_hook_unknown_source_fails(self):self.r['hook_candidates'][0]['source_ids']=['invented'];self.assertTrue(self.check())
 def test_visual_hook_without_reason_fails(self):self.r['hook_candidates'][0]['words_reason']='';self.assertTrue(self.check())
 def test_wrong_selected_hook_fails(self):self.r['selected_hook_id']='wrong';self.assertTrue(self.check())
 def test_no_phone_preview_fails(self):self.r['layout']['phone_preview']='missing';self.assertTrue(self.check())
 def test_reference_without_trigger_fails(self):self.pack['reference_cards']=[{'source_id':'source'}];self.savepack();self.assertTrue(self.check())
 def test_unconsumed_av_fails(self):
  (self.b/'av.json').write_text(json.dumps({'status':'model_returned','input':{'sha256':'x'},'invocation':{'tool':'fake'}}));self.r['av_evidence']=[{'id':'av1','status':'model_returned','artifact':'av.json'}];self.assertTrue(self.check())
 def test_av_finding_can_be_rejected_with_trace(self):
  (self.b/'av.json').write_text(json.dumps({'status':'model_returned','input':{'sha256':'x'},'invocation':{'tool':'fake'}}));self.r['av_evidence']=[{'id':'av1','status':'model_returned','artifact':'av.json'}];self.r['consumption']=[{'evidence_id':'av1','decision':'reject uncorroborated emotion inference','resulting_artifact':'decision.md'}];self.assertEqual(self.check(),[])
 def test_pass_not_valid_model_evidence(self):self.r['av_evidence'][0]['status']='pass';self.assertTrue(self.check())
 def test_delivery_review_not_applicable_fails(self):self.r['stage_routes'][3]={'stage':'export_review','state':'not_applicable','reason':'skip'};self.assertTrue(self.check())
 def test_plan_does_not_require_render(self):self.r['export_reviews']=[];self.assertEqual(wc.validate(self.r,self.b,'plan'),[])
 def test_omit_required_triggers_fails(self):self.r['triggered_stages']=[];self.assertTrue(self.check())
class AVTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.b=Path(self.t.name);(self.b/'source.mp4').write_bytes(b'offline fake source')
  self.j={'schema_version':'1.0','mode':'pre_edit','source_path':'source.mp4','source_sha256':av.sha(self.b/'source.mp4'),'source_duration_seconds':100,'coverage_purpose':'meaningful candidate with handles','approval_path':'approval.json','segments':[{'id':'s','start':20,'end':30,'questions':[{'id':'action','question':'Describe actual action.'},{'id':'response','question':'What follows?'}]}]}
  self.a={'upload_authorized':True,'authority':'test authority, no live permission','scope':'offline fixture only','terms_license_basis':'synthetic fixture','endpoint':av.ENDPOINT,'model':av.MODEL,'expires':(dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=1)).isoformat(),'max_attempts_per_call':2,'max_http_requests':2,'allowed_source_sha256':[self.j['source_sha256']]}
 def tearDown(self):self.t.cleanup()
 def validate(self):return av.validate_job(self.j,self.a,self.b)
 def save(self):(self.b/'job.json').write_text(json.dumps(self.j));(self.b/'approval.json').write_text(json.dumps(self.a))
 def goodanswer(self):return {'status':'model_returned','coverage':{'duration_seconds':10},'structured_answer':{'observations':[{'start':1,'end':2,'visible':'square moves'}],'checks':[{'id':'action','finding':'supported','evidence':'visible motion','start':1,'end':2},{'id':'response','finding':'uncertain','evidence':'not resolved'}],'gaps':['response uncertain']}}
 def test_valid_job(self):self.assertEqual(self.validate(),[])
 def test_expired(self):self.a['expires']='2000-01-01T00:00:00Z';self.assertTrue(self.validate())
 def test_missing_timezone(self):self.a['expires']='2099-01-01';self.assertTrue(self.validate())
 def test_arbitrary_endpoint_blocked(self):self.a['endpoint']='https://example.com';self.assertTrue(self.validate())
 def test_wrong_source_hash(self):self.j['source_sha256']='a'*64;self.assertTrue(self.validate())
 def test_empty_source_allowlist_blocked(self):self.a['allowed_source_sha256']=[];self.assertTrue(self.validate())
 def test_third_attempt_blocked(self):self.a['max_attempts_per_call']=3;self.assertTrue(self.validate())
 def test_no_budget(self):self.a['max_http_requests']=0;self.assertTrue(self.validate())
 def test_no_upload_authorization(self):self.a['upload_authorized']=False;self.assertTrue(self.validate())
 def test_extra_credential_field_blocked(self):self.a['token']='placeholder';self.assertTrue(self.validate())
 def test_long_segment_blocked(self):self.j['segments'][0].update(start=0,end=61);self.assertTrue(self.validate())
 def test_impossible_interval(self):self.j['segments'][0]['end']=101;self.assertTrue(self.validate())
 def test_duplicate_question(self):self.j['segments'][0]['questions'].append(self.j['segments'][0]['questions'][0]);self.assertTrue(self.validate())
 def test_nan_time(self):self.j['segments'][0]['end']=float('nan');self.assertTrue(self.validate())
 def test_missing_credential_no_prepare_no_request(self):
  self.save()
  def forbidden(*args,**kwargs):self.fail('must not prepare or call network')
  with patch.dict(os.environ,{},clear=True):r=av.execute(self.b/'job.json',self.b/'out',scan=forbidden,prepare=forbidden,probe=forbidden)
  self.assertEqual(r['status'],'not_checked');self.assertIn('no_authentication_attempt',r['reason'])
 def test_identified_answers_not_accuracy_pass(self):
  x=av.assess_answer(self.goodanswer(),self.j['segments'][0]['questions'],20);self.assertTrue(x['usable']);self.assertFalse(x['accuracy_verified']);self.assertEqual(x['source_time_estimates'][0]['source_start_estimate'],21)
 def test_missing_response_rejected(self):
  a=self.goodanswer();a['structured_answer']['checks'].pop();self.assertFalse(av.assess_answer(a,self.j['segments'][0]['questions'])['usable'])
 def test_impossible_model_timestamp(self):
  a=self.goodanswer();a['structured_answer']['observations'][0]['end']=99;self.assertFalse(av.assess_answer(a,self.j['segments'][0]['questions'])['usable'])
 def test_model_nan_time(self):
  a=self.goodanswer();a['structured_answer']['checks'][0]['start']=float('nan');self.assertFalse(av.assess_answer(a,self.j['segments'][0]['questions'])['usable'])
 def test_partial_source_coverage_is_honest(self):
  c=av.coverage(self.j['segments'],100);self.assertEqual(c['covered_seconds'],10);self.assertFalse(c['entire_source_selected']);self.assertFalse(c['full_frame_visual_review'])
 def test_overlapping_coverage_not_double_counted(self):self.assertEqual(av.coverage([{'start':0,'end':10},{'start':8,'end':20}],100)['covered_seconds'],20)
 def test_existing_adapter_reused_in_mock_orchestration(self):
  self.save();calls=[]
  def prep(src,s,out):out.write_bytes(b'prepared fake fixture')
  def probe(src):return {'format':{'duration':'100'},'streams':[{'codec_type':'video'},{'codec_type':'audio'}]}
  def scan(f,mode,q,out,approval,**kwargs):
   calls.append((mode,q,json.loads(approval.read_text()),kwargs));out.mkdir();a=self.goodanswer();(out/'artifact.json').write_text(json.dumps(a));return a
  with patch.dict(os.environ,{'NVIDIA_API_KEY':'offline-placeholder-not-a-credential'}):r=av.execute(self.b/'job.json',self.b/'out',scan=scan,prepare=prep,probe=probe)
  self.assertEqual(r['status'],'model_returned');self.assertEqual(len(calls),1);self.assertIn('response:',calls[0][1]);self.assertEqual(calls[0][2]['max_http_requests'],2);self.assertEqual(calls[0][3]['max_attempts'],2)
  self.assertNotIn('offline-placeholder',json.dumps(r))
 def test_credential_cannot_be_embedded_in_question(self):
  self.j['segments'][0]['questions'][0]['question']='do not transmit offline-placeholder-not-a-credential';self.save()
  def forbidden(*args,**kwargs):self.fail('credential-bearing job must stop before processing')
  with patch.dict(os.environ,{'NVIDIA_API_KEY':'offline-placeholder-not-a-credential'}):r=av.execute(self.b/'job.json',self.b/'out',scan=forbidden,prepare=forbidden,probe=forbidden)
  self.assertIn('credential_detected',r['reason']);self.assertNotIn('offline-placeholder',(self.b/'out/workflow_receipt.json').read_text())
 def test_batch_budget_cannot_reset_with_new_output(self):
  self.save();count,path=av.reserve_batch_budget(self.b/'approval.json',self.a,1);self.assertEqual(count,2)
  with self.assertRaises(ValueError):av.reserve_batch_budget(self.b/'approval.json',self.a,1)
 def test_changed_approval_cannot_reuse_existing_ledger(self):
  self.save();av.reserve_batch_budget(self.b/'approval.json',self.a,1)
  self.a['max_http_requests']=3;self.save()
  with self.assertRaises(ValueError):av.reserve_batch_budget(self.b/'approval.json',self.a,1)
 def test_duplicate_model_answers_rejected(self):
  a=self.goodanswer();a['structured_answer']['checks'].append(a['structured_answer']['checks'][0]);self.assertFalse(av.assess_answer(a,self.j['segments'][0]['questions'])['usable'])
class ActivePromptTests(unittest.TestCase):
 def test_routes_point_to_skills(self):
  for name in ['campaign-intelligence','reference-analysis','hook-story','art-direction','audiovisual-inspection']:self.assertTrue((ROOT/'07_creative_workflow/skills'/name/'SKILL.md').is_file())
 def test_active_methods_and_no_viral_promise(self):
  s=' '.join((ROOT/'05_master_prompt/PRO_EDITOR_BRAIN_v4.2.md').read_text().split())
  for token in ['## 1A.','## 1B.','## 2A.','## 3A.','## 4A.','## 6A.','not automatic rejection rules','source-compatible','ask the user once','continuous picture AND','Do not modify master','current SHA-256'] :self.assertIn(token,s)
 def test_inherited_scene_led_counterexample_kept(self):
  s=' '.join((ROOT/'05_master_prompt/PRO_EDITOR_BRAIN_v4.2.md').read_text().split());self.assertIn('A strong self-contained scene is valid',s);self.assertIn('rather than forcing an app demonstration or additional narration',s)
if __name__=='__main__':unittest.main()
