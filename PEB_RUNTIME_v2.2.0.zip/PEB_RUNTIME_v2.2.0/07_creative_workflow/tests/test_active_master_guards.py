"""Retarget existing standalone/diagnostic regression suites to the NEW active MD."""
import importlib.util,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def load_tests(loader,tests,pattern):
 suite=unittest.TestSuite()
 for name,variable in [('test_standalone_prompt','PROMPT'),('test_diagnostic_clarification','P')]:
  s=importlib.util.spec_from_file_location('active_'+name,ROOT/'06_system_improvement/06_tests'/f'{name}.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
  setattr(m,variable,ROOT/'05_master_prompt/PRO_EDITOR_BRAIN_v4.2.md');suite.addTests(loader.loadTestsFromModule(m))
 return suite
if __name__=='__main__':unittest.main()
