# Sidecar field guide

Templates are incomplete on purpose. No fabricated example is an approved record.
Existing project record/evidence contract remains the delivery authority.

Sources: `{id, locator, accessed_at, scope}`. Locator may be a public URL or a local
file. Add title, quotation, date, metric capture and limitations where useful.
Claims: `{id, statement, status, source_ids, limitation}`; status is `supported`,
`brand_assertion`, `hypothesis`, or `unknown`. Non-unknown claims need source IDs.
Audience evidence: `{source_id, observation}`; hypotheses remain separate.
Reference cards: `{id, source_id, inspection_scope, opening, beat_map, mechanism,
transfer_conditions, do_not_copy, limitations, metrics_context}`. Inspection scope
is `continuous_av`, `model_av`, `sampled_frames`, or `text_only`; all have limits.

Routes: `{stage, state, method, evidence, decision, artifact, reason}`.
Applied/reused require a real method, evidence, a specific decision and an existing
artifact. Other states require a reason. Available methods are not automatically
approved implementations. Add extra specialists as needed; do not force all skills.

Hook candidates: `{id, picture, sound, words, words_reason, promise, payoff,
brand_role, source_ids}`. Words can be empty if the reason is explicit. A candidate
may truthfully explain that a brand is only in permitted attribution/ending.
Layout: `{profile, rationale, text_roles, phone_preview, limitations}`.
AV evidence: `{id, status, artifact, reason}`. `model_returned` means provisional
usable model evidence, not a production QC pass. `not_checked` requires a reason.
Consumption: `{evidence_id, decision, resulting_artifact}` records whether an AV
finding changed or was rejected from a decision. Reusing evidence still needs a trace.
Export reviews: `{output_path, sha256, method, scope, evidence, verdict}`; verifier
checks the actual bytes. Never replace the existing richer publish-gate reviews
with this sidecar. For pre-render checking use `--phase plan`; delivery requires
at least one current-file review. Evidence paths are relative to the sidecar or
absolute, never invented display labels. Source records must link to real inputs.
