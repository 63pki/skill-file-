#!/usr/bin/env python3
"""Validate routing, links and current-file review identity, never taste or truth."""
import argparse, datetime, hashlib, json
from pathlib import Path
STAGES={'campaign_intelligence','reference_analysis','audiovisual_inspection','hook_story','art_direction','export_review'}
STATES={'applied','reused','not_applicable','unavailable'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def validate(record,base,phase='plan'):
 errors=[];base=Path(base)
 def err(s): errors.append(s)
 def file(value,label):
  if not isinstance(value,str) or not value.strip():err(label+': missing path');return None
  p=base/value
  if not p.is_file():err(label+': file missing');return None
  return p
 def text(value):return isinstance(value,str) and bool(value.strip())
 if record.get('schema_version')!='1.0':err('schema_version must be 1.0')
 if not text(record.get('campaign_id')) or record.get('campaign_id')=='REPLACE':err('campaign_id required')
 stages=record.get('triggered_stages',[])
 if not isinstance(stages,list) or not all(isinstance(x,str) for x in stages):return errors+['triggered_stages must be a list of strings']
 if len(stages)!=len(set(stages)):err('duplicate triggered stage')
 required={'audiovisual_inspection','hook_story','art_direction'}
 if record.get('new_campaign',True):required.add('campaign_intelligence')
 if phase=='delivery':required.add('export_review')
 if not required.issubset(set(stages)):err('required stage triggers missing: '+','.join(sorted(required-set(stages))))
 routes=record.get('stage_routes',[]);seen={}
 if not isinstance(routes,list):return errors+['stage_routes must be a list']
 for r in routes:
  if not isinstance(r,dict):err('route must be an object');continue
  stage=r.get('stage')
  if stage not in STAGES:err('unknown stage');continue
  if stage in seen:err('duplicate route '+stage)
  seen[stage]=r
  if r.get('state') not in STATES:err('invalid route state '+stage);continue
  if r['state'] in ('applied','reused'):
   for field in ('method','evidence','decision'):
    if not text(r.get(field)):err(stage+': missing '+field)
   file(r.get('artifact'),stage+' artifact')
  elif not text(r.get('reason')):err(stage+': missing fallback reason')
  if stage=='export_review' and phase=='delivery' and r['state'] in ('unavailable','not_applicable'):err('delivery requires an actual-export review, not a route exemption')
 for stage in stages:
  if stage not in STAGES:err('unknown triggered stage '+stage)
  elif stage not in seen:err('missing route '+stage)
 pack=None
 if record.get('intelligence_pack'):
  f=file(record['intelligence_pack'],'intelligence pack')
  if f:
   try:pack=json.loads(f.read_text())
   except (ValueError,OSError):err('intelligence pack unreadable JSON')
 elif seen.get('campaign_intelligence',{}).get('state') in ('applied','reused'):err('intelligence_pack required for applied/reused research')
 source_ids=set()
 if pack is not None:
  if not isinstance(pack,dict):err('intelligence pack must be an object');pack={}
  if pack.get('campaign_id')!=record.get('campaign_id'):err('intelligence campaign mismatch')
  sources=pack.get('sources',[])
  if not isinstance(sources,list):err('sources must be a list');sources=[]
  for s in sources:
   if not isinstance(s,dict):err('source must be an object');continue
   sid=s.get('id')
   if not text(sid) or sid in source_ids:err('missing/duplicate source id')
   else:source_ids.add(sid)
   for field in ('locator','accessed_at','scope'):
    if not text(s.get(field)):err('source '+str(sid)+': missing '+field)
   if text(s.get('accessed_at')):
    try:datetime.datetime.fromisoformat(s['accessed_at'].replace('Z','+00:00'))
    except ValueError:err('source access date invalid')
  claims=pack.get('claims',[])
  for c in claims:
   if not isinstance(c,dict):err('claim must be an object');continue
   if c.get('status') not in ('supported','brand_assertion','hypothesis','unknown'):err('invalid claim status')
   ids=c.get('source_ids',[])
   if not isinstance(ids,list) or not all(isinstance(x,str) for x in ids):err('claim source_ids must be strings');continue
   if c.get('status') not in ('unknown','hypothesis') and not ids:err('claim missing evidence source IDs')
   if not set(ids).issubset(source_ids):err('claim references unknown source')
   if c.get('status') in ('unknown','hypothesis') and not text(c.get('limitation')):err('uncertain claim needs limitation')
  for a in pack.get('audience_evidence',[]):
   if not isinstance(a,dict) or a.get('source_id') not in source_ids:err('audience evidence has unknown source')
  for c in pack.get('reference_cards',[]):
   if not isinstance(c,dict):err('reference card must be an object');continue
   if c.get('source_id') not in source_ids:err('reference card has unknown source')
   for field in ('opening','beat_map','mechanism','transfer_conditions','do_not_copy','limitations','metrics_context'):
    if not c.get(field):err('reference card missing '+field)
   if c.get('inspection_scope') not in ('continuous_av','model_av','sampled_frames','text_only'):err('invalid reference inspection_scope')
  if pack.get('reference_cards') and 'reference_analysis' not in stages:err('references used without reference-analysis trigger')
 candidates=record.get('hook_candidates',[]);ids=set()
 for c in candidates:
  if not isinstance(c,dict):err('hook must be an object');continue
  if not text(c.get('id')) or c.get('id') in ids:err('missing/duplicate hook id')
  else:ids.add(c['id'])
  for field in ('picture','sound','promise','payoff','brand_role'):
   if not text(c.get(field)):err('hook missing '+field)
  if not text(c.get('words')) and not text(c.get('words_reason')):err('visual-only hook needs words_reason')
  src=c.get('source_ids',[])
  if not isinstance(src,list) or not src or not all(isinstance(x,str) for x in src) or not set(src).issubset(source_ids):err('hook requires known evidence source IDs')
 if seen.get('hook_story',{}).get('state') in ('applied','reused') and record.get('selected_hook_id') not in ids:err('selected hook does not exist')
 layout=record.get('layout')
 if seen.get('art_direction',{}).get('state') in ('applied','reused'):
  if not isinstance(layout,dict):err('layout decision missing')
  else:
   for field in ('profile','rationale','text_roles','limitations'):
    if not layout.get(field):err('layout missing '+field)
   file(layout.get('phone_preview'),'phone preview')
 av_ids=set();returned=set()
 for a in record.get('av_evidence',[]):
  if not isinstance(a,dict):err('AV entry must be an object');continue
  aid=a.get('id')
  if not text(aid) or aid in av_ids:err('missing/duplicate AV id')
  else:av_ids.add(aid)
  if a.get('status')=='not_checked':
   if not text(a.get('reason')):err('AV fallback needs reason')
  elif a.get('status')=='model_returned':
   f=file(a.get('artifact'),'AV artifact')
   if f:
    try:
     obj=json.loads(f.read_text())
     if obj.get('status')!='model_returned' or not obj.get('input') or not obj.get('invocation'):err('AV artifact lacks usable reproducibility evidence')
     else:returned.add(aid)
    except (ValueError,OSError):err('AV artifact unreadable')
  else:err('invalid AV status; model evidence cannot be called pass')
 consumed=set()
 for c in record.get('consumption',[]):
  if not isinstance(c,dict):err('consumption must be an object');continue
  if c.get('evidence_id') not in av_ids:err('consumption references unknown AV evidence')
  if not text(c.get('decision')):err('consumption decision missing')
  file(c.get('resulting_artifact'),'consumption result');consumed.add(c.get('evidence_id'))
 if returned-consumed:err('usable AV evidence saved but not consumed')
 if seen.get('audiovisual_inspection',{}).get('state') in ('applied','reused') and not returned:err('applied AV route has no usable linked AV evidence')
 reviews=record.get('export_reviews',[])
 if phase=='delivery' and not reviews:err('delivery requires current-file export review')
 for r in reviews:
  if not isinstance(r,dict):err('review must be an object');continue
  f=file(r.get('output_path'),'reviewed output')
  if f and r.get('sha256')!=sha(f):err('review hash mismatch')
  for field in ('method','scope','evidence'):
   if not text(r.get(field)):err('review missing '+field)
  if r.get('verdict') not in ('approved','hold','revise','provisional_draft'):err('invalid review verdict')
 return errors

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('record',type=Path);p.add_argument('--phase',choices=['plan','delivery'],default='plan');a=p.parse_args()
 try:errors=validate(json.loads(a.record.read_text()),a.record.parent,a.phase)
 except (ValueError,TypeError,KeyError,OSError) as e:errors=['malformed/unreadable record: '+type(e).__name__]
 print(json.dumps({'structure_valid':not errors,'errors':errors,'scope':'structure, evidence links, decision trace and current-file identity only; not truth, rights, creative quality or release approval'},indent=2));return 1 if errors else 0
if __name__=='__main__':raise SystemExit(main())
