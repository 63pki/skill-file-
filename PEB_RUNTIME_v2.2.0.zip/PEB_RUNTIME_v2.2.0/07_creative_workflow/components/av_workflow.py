#!/usr/bin/env python3
"""Contextual AV-job wrapper. Reuses the packaged NVIDIA adapter; no second client."""
import argparse, datetime as dt, hashlib, importlib.util, json, math, os, re, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
ADAPTER=ROOT/'04_vision_stages/05_components/vlm_scan.py'
ENDPOINT='https://integrate.api.nvidia.com/v1/chat/completions'
MODEL='nvidia/nemotron-3-nano-omni-30b-a3b-reasoning'
MODES={'pre_edit','caption_check','post_render_qc'}
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def number(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)
def expiry_valid(s):
 try:
  t=dt.datetime.fromisoformat(s.replace('Z','+00:00'))
  return t.tzinfo is not None and t>dt.datetime.now(dt.timezone.utc)
 except (ValueError,TypeError,AttributeError):return False

def validate_job(job,approval,base):
 errors=[];base=Path(base)
 if job.get('schema_version')!='1.0':errors.append('schema_version')
 if job.get('mode') not in MODES:errors.append('unsupported_mode')
 source=base/str(job.get('source_path',''))
 if not source.is_file():errors.append('source_missing')
 expected=job.get('source_sha256','')
 if not isinstance(expected,str) or not re.fullmatch('[a-f0-9]{64}',expected):errors.append('source_hash_invalid')
 elif source.is_file() and sha(source)!=expected:errors.append('source_hash_mismatch')
 dur=job.get('source_duration_seconds')
 if not number(dur) or dur<=0:errors.append('duration_invalid')
 if not isinstance(job.get('coverage_purpose'),str) or not job['coverage_purpose'].strip():errors.append('coverage_purpose_required')
 if approval.get('upload_authorized') is not True:errors.append('upload_not_authorized')
 allowed_fields={'upload_authorized','authority','scope','terms_license_basis','endpoint','model','expires','max_attempts_per_call','max_http_requests','allowed_source_sha256'}
 if set(approval)-allowed_fields:errors.append('unexpected_approval_fields')
 for f in ('authority','scope','terms_license_basis'):
  v=approval.get(f)
  if not isinstance(v,str) or not v.strip() or 'REPLACE' in v:errors.append('approval_'+f+'_required')
 if approval.get('endpoint')!=ENDPOINT:errors.append('endpoint_not_supported')
 if approval.get('model')!=MODEL:errors.append('model_not_supported_by_exercised_route')
 if not expiry_valid(approval.get('expires')):errors.append('approval_expired_or_undated')
 if not isinstance(approval.get('allowed_source_sha256'),list) or expected not in approval.get('allowed_source_sha256',[]):errors.append('source_not_authorized')
 budget=approval.get('max_http_requests');attempts=approval.get('max_attempts_per_call')
 if not isinstance(budget,int) or isinstance(budget,bool) or budget<1:errors.append('request_budget_required')
 if not isinstance(attempts,int) or isinstance(attempts,bool) or not 1<=attempts<=2:errors.append('attempt_bound_1_to_2')
 segs=job.get('segments');seen=set();total=0
 if not isinstance(segs,list) or not 1<=len(segs)<=20:return errors+['segments_count_bound_1_to_20']
 if isinstance(budget,int) and budget<len(segs):errors.append('budget_below_one_attempt_per_segment')
 for s in segs:
  if not isinstance(s,dict):errors.append('segment_not_object');continue
  sid=s.get('id')
  if not isinstance(sid,str) or not re.fullmatch('[A-Za-z0-9_-]{1,64}',sid) or sid in seen:errors.append('segment_id_invalid_or_duplicate')
  else:seen.add(sid)
  a,b=s.get('start'),s.get('end')
  if not number(a) or not number(b) or not number(dur) or not 0<=a<b<=dur or b-a>60:errors.append('segment_time_invalid_or_over_60_seconds')
  else:total+=b-a
  qs=s.get('questions');qids=set()
  if not isinstance(qs,list) or not 1<=len(qs)<=12:errors.append('question_count_bound');continue
  for q in qs:
   if not isinstance(q,dict):errors.append('question_not_object');continue
   qi=q.get('id');qt=q.get('question')
   if not isinstance(qi,str) or not re.fullmatch('[A-Za-z0-9_-]{1,64}',qi) or qi in qids:errors.append('question_id_invalid_or_duplicate')
   else:qids.add(qi)
   if not isinstance(qt,str) or not qt.strip() or len(qt)>4000:errors.append('question_text_invalid')
 if total>600:errors.append('job_coverage_over_600_seconds_split_with_explicit_budget')
 return errors

def assess_answer(artifact,questions,offset=0):
 """Question coverage and numeric bounds only; semantic accuracy still unverified."""
 issues=[];mapped=[];expected={q['id'] for q in questions}
 if artifact.get('status')!='model_returned':return {'usable':False,'issues':['adapter_not_model_returned'],'source_time_estimates':[],'accuracy_verified':False}
 obj=artifact.get('structured_answer') or {};checks=obj.get('checks',[])
 if not isinstance(checks,list):checks=[];issues.append('checks_not_list')
 answered=[]
 for c in checks:
  if not isinstance(c,dict):issues.append('check_not_object');continue
  answered.append(c.get('id'))
  if c.get('finding') not in ('supported','contradicted','uncertain','not_applicable') or not c.get('evidence'):issues.append('invalid_check')
 missing=expected-set(x for x in answered if isinstance(x,str))
 if missing:issues.append('unanswered_question_ids:'+','.join(sorted(missing)))
 if len(answered)!=len(set(x for x in answered if isinstance(x,str))):issues.append('duplicate_check_ids')
 duration=artifact.get('coverage',{}).get('duration_seconds')
 for row in (obj.get('observations') or [])+checks:
  if not isinstance(row,dict):issues.append('row_not_object');continue
  if 'start' in row or 'end' in row:
   a,b=row.get('start'),row.get('end')
   if not number(a) or not number(b) or not number(duration) or not 0<=a<=b<=duration+.05:issues.append('invalid_or_impossible_time');continue
   mapped.append({'id':row.get('id'),'source_start_estimate':offset+a,'source_end_estimate':offset+b,'frame_exact':False,'speech_safe':False})
 return {'usable':not issues,'issues':issues,'source_time_estimates':mapped,'accuracy_verified':False,'semantic_review_required':True,'note':'answered IDs are not proof of correct or complete speech/action interpretation'}

def coverage(segments,duration):
 ranges=sorted((s['start'],s['end']) for s in segments);merged=[]
 for a,b in ranges:
  if merged and a<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],b)
  else:merged.append([a,b])
 total=sum(b-a for a,b in merged)
 return {'selected_intervals':merged,'covered_seconds':total,'source_duration_seconds':duration,'entire_source_selected':len(merged)==1 and merged[0][0]==0 and merged[0][1]==duration,'provider_internal_sampling':'unknown','full_frame_visual_review':False,'continuous_human_listening':False}

def reserve_batch_budget(approval_path,approval,segment_count):
 """Fail-closed reservation shared across new output directories/jobs.
 Reserve up to the per-job retry ceiling; unused reservations are not auto-refunded.
 """
 import fcntl
 ledger_path=Path(approval_path).with_suffix('.workflow_budget.json')
 fingerprint=sha(approval_path)
 with open(ledger_path,'a+') as f:
  fcntl.flock(f,fcntl.LOCK_EX);f.seek(0);prior=f.read()
  ledger=json.loads(prior) if prior else {'approval_sha256':fingerprint,'reserved_upper_bound':0}
  if ledger.get('approval_sha256')!=fingerprint:raise ValueError('approval_changed_use_new_authority_record')
  free=approval['max_http_requests']-ledger['reserved_upper_bound']
  if free<segment_count:raise ValueError('batch_request_budget_exhausted')
  reservation=min(free,segment_count*approval['max_attempts_per_call'])
  ledger['reserved_upper_bound']+=reservation;f.seek(0);f.truncate();json.dump(ledger,f);f.flush();os.fsync(f.fileno());fcntl.flock(f,fcntl.LOCK_UN)
 return reservation,str(ledger_path)

def execute(job_path,out,*,scan=None,prepare=None,probe=None):
 job_path=Path(job_path).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=False)
 receipt={'status':'not_checked','reason':None,'source':{},'coverage':{},'segments':[],'input':{},'invocation':{'tool':'av_workflow.py','job_path':str(job_path),'output_path':str(out)},'live_accuracy_verified':False}
 def finish(reason=None):
  if reason:receipt['reason']=reason
  text=json.dumps(receipt,indent=2,allow_nan=False)
  configured_key=os.environ.get('NVIDIA_API_KEY','').strip()
  if configured_key:text=text.replace(configured_key,'[REDACTED]')
  (out/'workflow_receipt.json').write_text(text+'\n');return receipt
 try:
  job=json.loads(job_path.read_text());approval_path=job_path.parent/str(job.get('approval_path',''));approval=json.loads(approval_path.read_text())
  errors=validate_job(job,approval,job_path.parent)
  if errors:return finish(';'.join(errors))
  configured_key=os.environ.get('NVIDIA_API_KEY','').strip()
  if configured_key and (configured_key in json.dumps(job) or configured_key in json.dumps(approval)):
   return finish('credential_detected_in_job_or_approval_remove_before_request')
  source=job_path.parent/job['source_path'];receipt['source']={'path':str(source),'sha256':job['source_sha256']};receipt['input']=receipt['source'].copy();receipt['coverage']=coverage(job['segments'],job['source_duration_seconds'])
  # No extraction or request when credential missing. Never persist credential values.
  if not os.environ.get('NVIDIA_API_KEY','').strip():return finish('credential_unavailable_no_authentication_attempt; ask_user_once_for_NVIDIA_API_KEY_when_route_needed')
  if probe is None:
   def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)]))
  info=probe(source);actual=float(info['format']['duration'])
  if not math.isfinite(actual) or abs(actual-job['source_duration_seconds'])>.1:return finish('source_duration_disagreement_probe_again')
  if not any(x.get('codec_type')=='video' for x in info['streams']):return finish('video_required')
  receipt['audio_stream_present']=any(x.get('codec_type')=='audio' for x in info['streams'])
  if prepare is None:
   def prepare(src,s,target):
    cmd=['ffmpeg','-v','error','-threads','2','-ss',str(s['start']),'-i',str(src),'-t',str(s['end']-s['start']),'-map','0:v:0','-map','0:a:0?','-c:v','libx264','-threads','2','-preset','veryfast','-crf','23','-c:a','aac','-avoid_negative_ts','make_zero','-y',str(target)]
    subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=180)
  reservation,ledger_path=reserve_batch_budget(approval_path,approval,len(job['segments']))
  receipt['batch_budget']={'ledger':ledger_path,'reserved_http_upper_bound':reservation,'unused_reservations_automatically_refunded':False}
  prepared=[]
  for s in job['segments']:
   f=out/(s['id']+'.mp4');prepare(source,s,f);prepared.append((s,f))
  child=dict(approval);child['max_http_requests']=reservation;child['allowed_source_sha256']=[sha(f) for _,f in prepared];child['parent_source_sha256']=job['source_sha256'];child['parent_approval_sha256']=sha(approval_path)
  child_path=out/'derived_approval.json';child_path.write_text(json.dumps(child,indent=2)+'\n')
  if scan is None:
   spec=importlib.util.spec_from_file_location('peb_existing_av_adapter',ADAPTER);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);scan=mod.scan
  for s,f in prepared:
   if not expiry_valid(approval['expires']):return finish('approval_expired_during_job')
   question='Answer each listed question ID exactly once in checks, using uncertain if unresolved. Do not repeat another answer as a substitute.\n'+'\n'.join(q['id']+': '+q['question'] for q in s['questions'])
   artifact=scan(f,job['mode'],question,out/s['id'],child_path,max_attempts=approval['max_attempts_per_call'])
   assessment=assess_answer(artifact,s['questions'],s['start'])
   receipt['segments'].append({'id':s['id'],'source_interval':[s['start'],s['end']],'prepared_sha256':sha(f),'artifact':str(out/s['id']/'artifact.json'),'assessment':assessment})
  if receipt['segments'] and all(x['assessment']['usable'] for x in receipt['segments']):receipt['status']='model_returned';receipt['reason']='provisional_model_evidence_semantic_review_required'
  else:receipt['status']='needs_review';receipt['reason']='one_or_more_segments_unanswered_invalid_or_unavailable'
  return finish()
 except ValueError as e:
  # Only our known, non-secret diagnostic strings may be surfaced.
  known={'approval_changed_use_new_authority_record','batch_request_budget_exhausted'}
  return finish(str(e) if str(e) in known else 'execution_error:ValueError')
 except Exception as e:
  # Only exception types; provider errors might contain credentials or request material.
  return finish('execution_error:'+type(e).__name__)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--job',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args()
 try:r=execute(a.job,a.out)
 except FileExistsError:print(json.dumps({'status':'not_checked','reason':'output_exists_use_new_directory'}));return 2
 print(json.dumps({'status':r['status'],'reason':r['reason']}));return 0 if r['status']=='model_returned' else 2
if __name__=='__main__':raise SystemExit(main())
