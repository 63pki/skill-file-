#!/usr/bin/env python3
"""Static layout/phone preview only. Requires Pillow; no video or audio validation."""
import argparse,json
from pathlib import Path
PROFILES=Path(__file__).resolve().parents[1]/'templates/layout_profiles.json'
def wrap(text,font,width,draw):
 lines=[];line=''
 for word in text.split():
  if draw.textlength(word,font=font)>width:raise ValueError('word_exceeds_text_box')
  candidate=(line+' '+word).strip()
  if draw.textlength(candidate,font=font)<=width:line=candidate
  else:lines.append(line);line=word
 if line:lines.append(line)
 return lines

def render(frame,out,font_path,headline='',profile='contained_landscape',phone_width=360,*,profiles_path=PROFILES):
 from PIL import Image,ImageDraw,ImageFont,ImageOps
 if phone_width<120 or phone_width>1080:raise ValueError('phone_width_out_of_bound')
 settings=json.loads(Path(profiles_path).read_text());cfg=settings['profiles'][profile]
 font_path=Path(font_path)
 if not font_path.is_file():raise ValueError('font_missing_no_silent_fallback')
 out=Path(out)
 if out.exists() or out.with_name(out.stem+'_phone.png').exists():raise FileExistsError('use_new_output_paths')
 W,H=cfg['canvas'];x,y,w,h=cfg['panel'];tx,ty,tw,th=cfg['text_box']
 for a,b,c,d in [(x,y,w,h),(tx,ty,tw,th)]:
  if min(a,b)<0 or min(c,d)<=0 or a+c>W or b+d>H:raise ValueError('profile_bounds_invalid')
 radius=cfg['radius'];border=cfg['border']
 if radius<0 or radius>min(w,h)/2 or border<0 or border>min(w,h)/4:raise ValueError('invalid_radius_or_border')
 canvas=Image.new('RGB',(W,H),cfg['background']);source=Image.open(frame).convert('RGB')
 panel=Image.new('RGB',(w,h),cfg['background']);fit=ImageOps.contain(source,(w,h),Image.Resampling.LANCZOS);panel.paste(fit,((w-fit.width)//2,(h-fit.height)//2))
 mask=Image.new('L',(w,h));ImageDraw.Draw(mask).rounded_rectangle((0,0,w-1,h-1),radius=radius,fill=255)
 canvas.paste(panel,(x,y),mask)
 draw=ImageDraw.Draw(canvas)
 if border:draw.rounded_rectangle((x,y,x+w-1,y+h-1),radius=radius,outline=cfg['accent'],width=border)
 font=ImageFont.truetype(str(font_path),cfg['font_size']);lines=wrap(headline,font,tw,draw)
 ascent,descent=font.getmetrics();line_height=ascent+descent+8
 if len(lines)*line_height>th:raise ValueError('headline_exceeds_text_box_reduce_copy_or_change_layout')
 bg=canvas.getpixel((0,0));color='#f6f4ef' if sum(bg)<384 else '#191919'
 for i,line in enumerate(lines):draw.text((tx,ty+i*line_height),line,font=font,fill=color)
 out.parent.mkdir(parents=True,exist_ok=True);canvas.save(out)
 phone=out.with_name(out.stem+'_phone.png');canvas.resize((phone_width,round(H*phone_width/W)),Image.Resampling.LANCZOS).save(phone)
 evidence={'scope':'static mockup; motion, source text readability, platform UI and audio not verified','profile':profile,'canvas':[W,H],'panel':[x,y,w,h],'source_size':list(source.size),'contained_size':list(fit.size),'crop_policy':'contain; panel corner mask/border may obscure edge pixels, inspect essential content','font_path':str(font_path),'font_size':cfg['font_size'],'headline_lines':lines,'phone_size':[phone_width,round(H*phone_width/W)]}
 out.with_suffix('.layout.json').write_text(json.dumps(evidence,indent=2)+'\n');return evidence

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--frame',required=True,type=Path);p.add_argument('--out',required=True,type=Path);p.add_argument('--font',required=True,type=Path);p.add_argument('--headline',default='');p.add_argument('--profile',default='contained_landscape',choices=['contained_landscape','full_bleed','editorial_panel']);p.add_argument('--phone-width',default=360,type=int);a=p.parse_args()
 try:r=render(a.frame,a.out,a.font,a.headline,a.profile,a.phone_width)
 except (ValueError,OSError,KeyError,ImportError) as e:print(json.dumps({'status':'not_checked','reason':str(e)}));return 2
 print(json.dumps(r));return 0
if __name__=='__main__':raise SystemExit(main())
