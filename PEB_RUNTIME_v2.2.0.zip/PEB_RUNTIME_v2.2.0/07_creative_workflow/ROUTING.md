# Active creative-workflow routing — PEB v2.2.0

The master prompt v4.2 embeds all decision rules for standalone use. In this
package, select the method below when triggered; do not read everything first.
`applied`, `reused`, `not_applicable` and `unavailable` are route states.
A skill name without an evidence → decision → artifact trace is insufficient.

| Stage | Trigger | Skill path (relative to this directory) | Expected result |
|---|---|---|---|
| campaign_intelligence | new/materially changed campaign | skills/campaign-intelligence/SKILL.md | compact intelligence pack or scoped fallback |
| reference_analysis | a reference influences the treatment | skills/reference-analysis/SKILL.md | functional reference cards; real coverage |
| audiovisual_inspection | temporal source/review meaning | skills/audiovisual-inspection/SKILL.md | AV artifacts or explicit missing coverage |
| hook_story | opening/concept selection | skills/hook-story/SKILL.md | picture/sound/words/promise/payoff decision |
| art_direction | composition/text/motion selection | skills/art-direction/SKILL.md | source-suitable layout and preview |
| export_review | every deliverable | master prompt §6/§6A + existing evidence contract | current-hash review, statuses separate |

Use `templates/creative_workflow.json` as an optional sidecar to the existing
project record: add its path to project notes/artifact index. Do NOT replace the
existing hash-bound review record with this simpler routing sidecar.
Validate sidecar structure with `python 07_creative_workflow/components/workflow_check.py project/creative_workflow.json`.
This catches missing links/decisions; it does not determine creative quality.

NVIDIA is the fallback when no suitable approved AV route exists, or when selected
by the project. Other approved routes can supply the same evidence contract.
No blanket upload approval or required cloud spend is created by this package.
Optional specialists (captions, motion, multilingual shaping, etc.) retain their
existing registry status. Do not replace them just because a new skill exists.
