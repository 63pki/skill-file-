# Live AV feature test — NOT EXECUTED BY THIS BUILD

Current result: NOT_CHECKED; do not change inherited INCOMPLETE_NOT_PASSED to a
pass based on unit tests or mocked transport. No key/provider calls were needed
for this system-development build.

Before the route supplies verified production QC, prepare authorized short
fixtures with an independent oracle (not included in the model's prompt):
1. Known visible action with time landmarks (e.g. blue square right then stop).
2. Known clean speech with an interpretation-changing qualifier, including its
   complete following response. Use authorized speech/recording and measured
   timings; never call a synthetic tone a speech test.
3. A deliberately false authored caption (e.g. RED CIRCLE LEFT over blue square
   moving right). Ask neutral agreement questions rather than revealing the trap.
4. A silent/no-speech case. The model must not invent dialogue.
5. A final rendered short with identified opening and required text; distinguish
   actual recognition from word-safe/frame-exact/creative conclusions.

Run <=60s contextual segments through the existing adapter with real upload/cost
approval and per-batch budget. Preserve source hashes, prompt/questions, final
answers, receipts, local timing oracle and an honest evaluation of EACH case.
Set timing tolerance before evaluation based on the fixture/question. Do not
ignore a failed negative case because positives passed. Mark partial failures
and restrict the usable capability accordingly; no fake comprehensive pass.

This build exercises local extraction, resized silent MP4 + WAV preparation and
request assembly with INJECTED transport only. That validates plumbing, not live
model recognition, speech, sound identity, emotion or provider availability.
