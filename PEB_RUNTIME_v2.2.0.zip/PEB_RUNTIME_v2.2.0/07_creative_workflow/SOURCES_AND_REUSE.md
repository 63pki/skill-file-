# Provenance and reuse

These new method documents and helper implementations are original PEB build
material synthesized from the supplied review and project lessons. No external
repository was installed or wholesale copied. Existing packaged skills and the
original NVIDIA adapter remain byte-identical. No key, model weights, fonts or
third-party media were added.

Research inspirations previously inspected (not dependency declarations):
- https://github.com/Ootto-AI/claude-content-skills — audience/brief/reference methods.
- https://github.com/artemnovitckii/content-skills — specific, natural hook/story writing.
- supplied mrpaidsocial snapshot — functional reference analysis and scoped review;
  no LICENSE found in supplied snapshot, so no redistribution of its implementation.
- https://github.com/digitalsamba/claude-code-video-toolkit — optional composition ideas.
- https://github.com/browser-use/video-use/tree/43cfc566833548093455c9d4a46bd69913b7e552
  — transcript/EDL/timeline lessons; no imported code and no forced Scribe dependency.

Catalog links and author claims are not installed capabilities or performance
proof. Verify license/terms before later integrating any external code/media.
