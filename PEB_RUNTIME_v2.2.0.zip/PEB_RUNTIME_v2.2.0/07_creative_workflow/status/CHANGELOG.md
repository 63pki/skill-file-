# v2.2.0 — user-requested creative-workflow build

Added v4.2 active standalone master and five routed original methods. Added compact
research/creative/AV/layout templates, a structural evidence-to-decision checker,
a static panel/phone preview helper and a contextual AV-job wrapper reusing the
existing client. Added 72 new/retargeted offline tests and synthetic layout fixtures.
Updated exactly four root navigation/status files. Existing skills, validators,
frozen-core files and AV adapter preserved. No credentials or vendor dependencies.

Not adopted: universal effects/VO/demo requirements, causal viral-template claims,
new providers, automatic skill mutation or any resumed campaign/publication.
