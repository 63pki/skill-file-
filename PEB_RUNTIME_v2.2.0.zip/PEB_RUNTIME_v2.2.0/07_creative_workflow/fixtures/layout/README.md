# Local static fixtures, not campaign creative

Original generated geometry and source text; three sample compositions and
360px phone previews. These exercise contain/mask/border/font/text geometry,
not source selection, video motion, speech, aesthetics, platform UI or engagement.
Full-bleed preserves this landscape fixture by containment, showing the explicit
tradeoff rather than secretly cropping. Treat each profile as adjustable defaults.
The font path in metadata identifies this build environment, not a portable font
installation. No font file is redistributed.
