# Reused NVIDIA route: contextual wrapper

1. Reconcile upload/cost/media rights once. Fill `templates/av_approval.json` in the
project directory from real authority. It defaults to NO approval. Expiry must have
a timezone, allowed source hashes must be explicit, and HTTP budget includes retries.
2. Fill `templates/av_job.json`: one actual source hash/duration, selected contiguous
intervals (each <=60 seconds), identified neutral questions and existing approval.
Coverage may be partial; do not claim the whole source was seen. Handles and
adjacent/overlapping intervals preserve context. No automatic source selection.
3. If the route is needed and the runtime key is absent, ask once for NVIDIA_API_KEY.
Use a supported credential method; do not fabricate one. Do not put the key in job,
approval, prompts, package or reports. Credential availability is NOT media approval.
4. Run `python 07_creative_workflow/components/av_workflow.py --job PROJECT/av_job.json --out PROJECT/av_run_01`.
A missing key exits with a scoped not_checked receipt before encoding/network.
5. Wrapper calls the EXISTING `04_vision_stages/05_components/vlm_scan.py`, not a new
model client. It uses silent video + matching WAV, one shared request-budget ledger,
no redirects to arbitrary endpoints, <=2 attempts per logical call. This build does
not verify the current model's availability. No new provider substitution.
6. Read both final model evidence and wrapper semantic flags. Each asked question
must have an identified answer or explicit gap. Omitted answers, repeated dialogue,
impossible timestamps and uncertainty are not passes. Source-time maps are model
estimates, not certified speech boundaries. Record consumption in the sidecar.
7. An offline contract/fixture test does not promote the model. Existing live fixture
status remains INCOMPLETE_NOT_PASSED; targeted live action/speech/qualification/
false-caption/silence checks remain needed before verified production QC use.

The wrapper preserves the existing adapter's proxy and final-answer artifacts;
never bundle project-media artifacts into the shared runtime. An interrupted
network attempt may have consumed budget; do not reset ledgers to repeat it.

Budget integrity: the original approval's sibling `.workflow_budget.json` reserves
a conservative per-job HTTP upper bound, shared across new output directories.
The reused adapter also enforces that reservation in its derived ledger. Do not
reset either ledger to retry a job. Unused reservations are not auto-refunded;
reconcile receipts before an explicitly authorized budget extension. Recorded
approval files compile existing authority—they do not require asking again for
media/cost actions the user already authorized.
