---
name: peb-reference-analysis
description: Learn mechanisms from a relevant permitted reference, not a rigid template.
---

# PEB reference-analysis — v1.0

Authority: active master prompt and current authorized brief. These are original
PEB methods, not imported external skill instructions. Read only when triggered.
Do not alter shared skills during a campaign.

# Functional reference analysis

1. Choose references relevant to the actual audience, source type and campaign objective, including ordinary comparisons. Use the campaign intelligence method for evidence and metrics limits.
2. Inspect authorized picture and corresponding audio. An audiovisual proxy submission does not prove the provider reviewed every frame; identify scope and gaps.
3. Map first picture/sound/words, changing information, payoff/reaction and CTA. Record source times as estimates until checked.
4. Separate text registers (speech, title, evidence, brand/legal), panel geometry, motivated detail views, motion and sound functions. Do not infer tempo or sound identity from a spectrogram alone.
5. For each device record function, required material, what transfers, what does not, rights boundaries and failure conditions. Do not match cuts per second mechanically.
6. Offer source-compatible opportunities. If our footage cannot deliver the premise, reject that adaptation rather than fabricate evidence.


## Concrete handoff

Output reference cards in `campaign_intelligence.json`; link the audiovisual artifacts when used. One useful reference is preferable to a large uninspected list. Do not download protected media through unsupported routes.
