---
name: peb-art-direction
description: Choose or change composition, caption hierarchy, graphics or motion.
---

# PEB art-direction — v1.0

Authority: active master prompt and current authorized brief. These are original
PEB methods, not imported external skill instructions. Read only when triggered.
Do not alter shared skills during a campaign.

## 4A. Art direction: compose the frame, do not default to zoom-fill

Choose a coherent composition appropriate to the source: full-bleed portrait;
contained landscape within vertical; editorial media panel; justified
comparison; or actual product/UI evidence. Preserve meaningful geography,
faces, actions and source text. A landscape source need not be aggressively
cropped to fill 9:16. Square or rounded panels, text above/below, negative space
and restrained brand-color outlines are valid options—not mandatory decoration.
Do not always blur-pad, always zoom, or turn every empty area into another label.
Use an actual installed renderer, available licensed fonts and exact dimensions.

Distinguish speech subtitles, opening/editorial headlines, labels/evidence
annotations, and CTA/legal. Assign hierarchy and avoid competing duplicate
hero/subtitle blocks. Ordinary subtitles intentionally repeat speech for
accessibility; that is not automatically redundant design. Preserve negations,
qualifiers and authorized baked-in subtitles. Before adding more, inspect what
already exists. Rebuild source subtitles only when authorized and verified.

Use measured typography profiles, not universal pixel prescriptions. For a
1080×1920 mockup, dialogue around 44–60 raster/CSS-equivalent pixels and short
headlines around 56–80 can be starting points for some fonts; they are not
platform rules, accessibility guarantees or interchangeable ASS FontSize units.
Judge rendered glyph height, weight, contrast, line length, duration, script and
viewer context. Phrase-based grouping and one/two lines are sensible defaults,
not compulsory word counts. Small text is not inherently premium; hierarchy,
spacing, alignment and restrained, purposeful motion matter more.

A full-width 16:9 picture on a 1080-wide canvas is about 608 high; at 360-wide
phone preview it is only about 203 high. An inset panel shrinks it further.
Preserving the full scene can make baked-in subtitles/UI unreadable. Check that
tradeoff and choose an authorized caption rebuild or motivated detail view if
needed. A smaller panel with unreadable evidence is not a premium solution.

Check actual platform UI masks/current guidance and shot-specific exclusions;
no universal y-coordinate proves safety. Declare media bounds, text boxes,
font/weight, line breaks, max width, anchors, margins, corner radius and border
when applicable. Protect faces, source text, UI and mandatory elements through
motion, not only at a resting frame. Rounded corners need a real mask; ASS box
styles alone are not rounded geometry. Verify font loading and fallback glyphs.

Effects serve attention, explanation, contrast or emotion. Plan a reason for a
zoom, graphic, sound accent, transition or hold. Match brand tone; allow quiet
cuts and linear motion when appropriate. Do not infer that cubic easing, gold
serifs, thick outlines or constant SFX universally look professional. Inspect a
phone-size opening/layout preview, then review motion and sound on the exact
export. A still mockup is layout evidence, not a completed editing capability.

## Concrete handoff

Use `layout_profiles.json` as adjustable mockup defaults, not requirements. `components/layout_preview.py` makes a static local PNG from a supplied frame; it is not a video editor and does not verify readable motion, audio or platform UI masks. Pass the actual licensed font path. Run the selected compositor's representative motion fixture before calling that implementation tested.

Output layout choice, text roles, phone-size evidence and known tradeoffs in `creative_workflow.json`.
