---
name: peb-audiovisual-inspection
description: Understand temporal source/reference meaning or review a consequential final sequence.
---

# PEB audiovisual-inspection — v1.0

Authority: active master prompt and current authorized brief. These are original
PEB methods, not imported external skill instructions. Read only when triggered.
Do not alter shared skills during a campaign.

## 2A. Contextual audiovisual inspection, not random-frame selection

For meaningful candidate sequences, use a capable authorized audiovisual route
as the normal analysis method when available. Supply continuous picture AND its
corresponding audio, with preceding setup and following response sufficient to
understand meaning. Do not choose from transcription alone and use random
frames merely to decorate that choice. For long material, maintain contiguous,
bounded segment coverage and source/output time mapping; inspect promising
windows with handles. A scout sampling pass is labeled partial and cannot
approve an unseen sequence. Do not upload entire libraries automatically.

Use the approved NVIDIA route when no other suitable approved AV route exists
or the project selects it. Historical candidate model:
`nvidia/nemotron-3-nano-omni-30b-a3b-reasoning` at the NVIDIA integrate endpoint;
its current availability/interface must be checked, not assumed from its name.
The exercised request design supplies resized silent MP4 plus complete aligned
WAV in the SAME message. This is not proof of embedded-MP4 soundtrack ingestion.
Do not substitute image-only analysis and claim sound was understood.

If the selected route is needed and NVIDIA_API_KEY is absent, ask the user once
for the NVIDIA API key and use the credential-entry/configuration method the
environment actually supports. Never claim a nonexistent secret setter or
request a new external runner by default. A key alone is not media-upload,
cost or publication approval. Keep credentials out of deliverables, prompts,
logs and shared packages. Missing credentials mean no authentication attempt;
HTTP 500 is not evidence of an invalid key. Preserve separate transport, auth,
parse and semantic outcomes. Max two attempts per logical call; retries count
against the batch budget. Do not fall back to a new provider without authority.

Ask neutral, identified questions: literal action and dialogue; referents and
qualifications; setup/development/reveal/response; uncertainty; on-screen text;
proposed cut risks; and requested caption agreement. Capture model, invocation,
input hash, interval/audio coverage, prompt, selected final answer, request
status and consumed findings. Save final evidence, not internal reasoning or
raw request payloads. Check answers actually address each question; flag
repeated dialogue, impossible times, omissions and contradictions. A model
cannot certify its own correctness or experience/feel a film as a human does.

Keep the existing capability ladder. Before production QC passes rely on this
route, exercise known action, an audiovisual qualification, a planted false
caption and silent/no-speech behavior. Offline contracts/mocks do not pass a
live model fixture. Unexercised output can be provisional evidence, never a
verified capability. Inspect local frame boundaries and use an appropriate
listening/audio-aware check for speech completeness. If the model contradicts
itself, stop the loop and isolate the consequential span. If no AV route is
usable, document exact gaps, continue unaffected work, and hold only decisions
or delivery requirements that genuinely depend on missing evidence.

## Concrete handoff

Reuse `04_vision_stages/05_components/vlm_scan.py` through `components/av_workflow.py`; no second video model is installed. The wrapper validates project approval and input intervals, prepares bounded contiguous segments, asks identified questions, checks response coverage and maps model-relative times to source seconds. It does NOT certify speech-safe boundaries.

CLI: `python 07_creative_workflow/components/av_workflow.py --job project/av_job.json --out project/av_run_01`

Read job/approval templates and `AV_RUN_GUIDE.md`. No key argument exists. Ask once when needed; runtime key, upload/cost scope and provider availability are distinct. No live feature-test result is supplied by this build.
