---
name: peb-hook-story
description: Develop an opening before choosing a headline or caption preset.
---

# PEB hook-story — v1.0

Authority: active master prompt and current authorized brief. These are original
PEB methods, not imported external skill instructions. Read only when triggered.
Do not alter shared skills during a campaign.

## 3A. Hook and story development joins picture, sound and words

Use the intelligence pack and actual source meaning to develop the opening.
Record: viewer relevance; first picture/action; first sound/spoken phrase;
necessary authored words; promise; source-supported payoff; truthful brand role.
An opening can work without text, speech, a question or an information gap.
Directly showing a result is valid when the remaining interest is how/why,
character, consequence or pleasure—not every payoff must be hidden.

Where creative exploration is useful, develop a few materially different angles
(e.g. discovery, contrast, consequence, specific observation, demonstration or
character tension), not ten synonyms for one headline. Compare each against
what the material can deliver and what a stranger can understand. Avoid generic
hype, borrowed first-person testimony, fake urgency, invented statistics and
forced pain-point/you/contrast formulas. Do not copy a supposedly proven hook
structure by only swapping power words. No arbitrary taste score establishes
quality. Reuse a strong approved opening when alternatives add no real value.

Write in the audience/brand's evidenced register. Separate spoken script from
written overlays. Prefer concrete detail, intelligible language and natural
rhythm; review wording in context without pretending to have listened. Do not
flatten every sentence, ban normal vocabulary, force BUT/THEREFORE connectors,
write constant trailer VO or narrate everything already visible. A factual
qualifier stays even if it makes the line less punchy. Check the finished body
still delivers the opening's promise. CTA is not the story's payoff.

The editor may reject a researched format that does not suit the footage; state
the reason briefly. Choose scene-led, interpretive, comparison, demonstration or
another justified route. No minimum number of graphics, effects, skills or cuts
makes a concept original. Original contribution may be selection, compression,
comparison, interpretation, information order or restraint, as the brief permits.

## Concrete handoff

Output one or a few candidates in `creative_workflow.json`. Every candidate links actual source/evidence and names picture, sound, words, promise, payoff and brand role. Mark the selected candidate; record why. A visual-only hook can leave words empty with a reason. Test the result in context; schema completeness is not taste scoring.
