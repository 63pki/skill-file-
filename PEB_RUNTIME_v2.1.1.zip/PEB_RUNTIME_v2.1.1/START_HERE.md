# PEB EDITORIAL SYSTEM v2.1.1 — START HERE (single entry point)

You are holding a consolidated, self-contained editing system. RexTrix is
**paused**: nothing here authorizes a render, upload, provider call or
publication. This package is for system use and the next authorized campaign.

**Release state: FROZEN for the first authorized pilot.** Further creative
changes follow observed editing behavior from that pilot — not another
speculative rewrite.

## Runtime + archive split (this package)
This ZIP is the **runtime half** of the v2.1.1 packaging split
(`PEB_RUNTIME_v2.1.1`). Ordinary editing — dialogue, captions, reframing,
authorized narration/graphics treatment — needs **only this package**: the
active master prompt, playbook and registries, catalog text/code, offline
test fixtures, templates and governance records are all here. Heavy media,
RexTrix history, past-analysis media and superseded release records live in
the companion **`PEB_ARCHIVE_REFERENCE_v2.1.1.zip`** (optional reference;
SHA-256 and accounting in `ARCHIVE_POINTER.md`). Both packages keep the
baseline's relative paths, so any path referenced by a runtime document but
not present here resolves in the archive at the same relative path; the
documents with archive-resident references are listed in `ARCHIVE_POINTER.md`.
Pick what to read per task via `SKILL_INDEX.md` (paths, dependencies,
capability status); do not read everything first. All packaged tests run
**without** the archive; results: `VERIFICATION_AND_CHANGES_v2.1.1.md`.

## Diagnostic clarification patch
The active prompt remains at `05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md`;
its §3 now explicitly makes headline/brand removal diagnostic, not an automatic
rejection rule. Scene-led entertainment and truthful story spotlights remain
eligible; no compulsory app demonstration or additional narration is introduced.
This active wording supersedes the older restrictive paragraph. Use
`MANIFEST_v2.1.1.json` and `PACKAGE_VERIFICATION_v2.1.1.json` for this release;
older manifests/verification records are historical snapshots, not checks of
the patched tree. See `06_system_improvement/07_status/PATCH_REPORT_v2.1.1.md`.

## What to read, in what order

1. **`05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md`** — the active, standalone
   master prompt. It is the only instruction document an editing agent needs,
   together with the campaign brief and footage. It also lists exactly which
   packaged tools are optional. (v4.1 = v4.0 plus the review hash-binding and
   verdict publish-gate rules in §6 and the campaign-brief boundary sentence
   in §1; the v4.0 file is preserved below a SUPERSEDED banner.)
2. `NEXT_CAMPAIGN_STARTUP.md` (root) — the seven-step bootstrap that gets a
   new campaign's editing agent working without another architecture
   discussion.
3. When relevant, consult (optional reference, not required reading):
   - `06_system_improvement/02_playbook/INTENTIONAL_EDITING_METHODS_v1.2.md` —
     technique options with failure tests, retired measurement methods, and
     the brand-removal counterfactual diagnostic (v1.2 = v1.1 + one line).
   - `01_preserved_system/PEB_PORTABLE_v1.1.1/01_master_prompt/` — frozen core
     v3.1.1: reference depth on feel engine, tiers, recipes, campaign-profile
     schema.
   - `04_vision_stages/01_master_prompt/PEB_VISION_STAGES_v1.0.md` — the
     optional V1/V2/V3 vision-evidence workflow and its honest fixture status.
   - `06_system_improvement/05_templates/RECORD_GUIDE_v2.1.md` — the compact
     project record (hash-bound review rows, verdict publish gates).

## Precedence (unambiguous)

| Rank | Authority | Notes |
|---|---|---|
| 1 | Current campaign brief + explicit operator decisions | With recorded scope; overrides everything below |
| 2 | `05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md` | Active decision rules; where it conflicts with any older doc, it wins |
| 3 | Playbook v1.2, frozen core, vision module | Reference detail; never contradicts rank 2 into effect |
| 4 | Everything else (continuation docs, reviews, ledgers, debriefs) | Historical evidence; do not execute |

Documents marked with a `> **HISTORICAL / SUPERSEDED / ABSORBED**` banner are
preserved unaltered below the banner. Do not follow their instructions; they
include expired render approvals and stale next actions. One historical rule
is superseded by name in this release: the universal brand-removal rejection
line in `00_continuation/CREATIVE_TREATMENT_GATE_v1.0.md` — brand removal is a
counterfactual diagnostic (playbook v1.2, master prompt §3), never an
automatic rejection rule. The full reconciliation record is
`06_system_improvement/07_status/PATCH_REPORT_v2.1.md`.

## Start once; do not restart the old project

1. Read the v4.1 master prompt and this file. That is the whole orientation.
2. For a new campaign, follow `NEXT_CAMPAIGN_STARTUP.md`: establish the
   current brief's effective requirements, evidence and authorization; build
   the requirements table in a fresh project record
   (`06_system_improvement/05_templates/PROJECT_RECORD_TEMPLATE_v2.0.json`,
   guide v2.1).
3. Reuse approved source records, treatments and tested implementations where
   they genuinely fit; do not redo research to fill paperwork.
4. Do not inherit RexTrix's numbers, original-audio policy, VO exceptions,
   end-card rules or old approvals. Its history (including
   `03_current_project/`) is evidence only — see
   `03_current_project/HISTORICAL_README.md`.

## Package map

- `05_master_prompt/` — the standalone v4.1 master prompt (active); v4.0
  preserved below a SUPERSEDED banner.
- `06_system_improvement/` — active layer: playbook v1.2, evidence (debriefs
  A/B + adoption decisions), components (record validator v2.1, probe
  inspector), templates (record v2.0 schema, guide v2.1), tests, build status,
  and `06_system_improvement/07_status/PATCH_REPORT_v2.1.md` (the
  branch-reconciliation and bounded-patch record).
- `01_preserved_system/PEB_PORTABLE_v1.1.1/` — frozen core, byte-identical,
  auditable historical baseline (hash-manifested).
- `02_nvidia/` — optional external AV-model usage, verification protocol,
  sanitized evidence.
- `03_current_project/` — RexTrix history (paused) — **moved to the archive**
  (same relative path in `PEB_ARCHIVE_REFERENCE_v2.1.1.zip`).
- `04_vision_stages/` — optional V1/V2/V3 vision-evidence module; fixture
  status INCOMPLETE_NOT_PASSED is preserved truthfully.
- `00_continuation/` — historical continuation docs (bannered).
- Root delivery docs: `CAPABILITY_STATUS.md`, `NEXT_CAMPAIGN_STARTUP.md`, the
  current `MANIFEST_v2.1.1.json` / `PACKAGE_VERIFICATION_v2.1.1.json`, plus
  this split's `SKILL_INDEX.md`, `ARCHIVE_POINTER.md`,
  `MANIFEST_RUNTIME_v2.1.1.json` and `VERIFICATION_AND_CHANGES_v2.1.1.md`.
  Superseded release records (older manifests/verifications,
  `CHANGE_REPORT_v2.0.md`, `START_HERE_v1.3.2_HISTORY.md`) are **moved to the
  archive**.

No API credential is included anywhere in this package (or the archive). Run
the packaged tests with: `python 06_system_improvement/06_tests/<test>.py`
(and `python 04_vision_stages/tests/test_contracts.py`) — all run without the
archive; this split's verified results are in
`VERIFICATION_AND_CHANGES_v2.1.1.md`, and
`06_system_improvement/07_status/BUILD_RESULT_v2.1.md` records what the
baseline tested and what it did not.
