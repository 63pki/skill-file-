# ARCHIVE_POINTER — pairing record for the v2.1.1 packaging split

The companion package to this runtime is:

| Archive | Size (bytes) | SHA-256 |
|---|---|---|
| `PEB_ARCHIVE_REFERENCE_v2.1.1.zip` | 24,354,113 | `38d63fcd42e8402131b79e164dc7bf2fb1e5c8658a6b3a08b91f6f56d356731f` |

The archive is **optional reference material**. Ordinary editing, the packaged
tests and new-campaign startup do not require it. Its internal README
(`README_ARCHIVE.md`, inside the archive) states exactly what it contains and
why; its files are listed in `MANIFEST_ARCHIVE_v2.1.1.json` (inside the
archive).

## What lives in the archive (124 files, 27,601,097 bytes uncompressed)

| Rule | Contents | Files | Bytes |
|---|---|---|---|
| A1 | `04_vision_stages/reference_review/**` — past-analysis media + decode logs | 28 | 7,888,060 |
| A2 | media/binaries elsewhere: catalog previews + preview reel, copyrighted reference PDF, RexTrix review JPGs, superseded nested ZIPs | 41 | 18,827,895 |
| A3 | `03_current_project/**` — RexTrix history, paused campaign (evidence only) | 39 | 234,406 |
| A4 | superseded release records: manifests/verifications v1.2–v2.1, `CHANGE_REPORT_v2.0.md`, `START_HERE_v1.3.2_HISTORY.md` | 16 | 650,736 |

The vision offline test fixtures (`04_vision_stages/fixtures/**`) are **not**
in the archive; they stay in this runtime so every packaged test runs without
the archive.

## How cross-package references resolve

Both packages preserve the baseline's relative paths. If a document in this
runtime references a path that is not present here, that path exists in the
archive at the same relative path. Runtime documents that reference
archive-resident paths (all explained, none silent) are enumerated in
`VERIFICATION_AND_CHANGES_v2.1.1.md` §"Cross-package references". No internal
reference inside any skill or instruction file was rewritten to perform this
split; routing is handled by this pointer and `SKILL_INDEX.md`.

## Integrity

- Every original file in this runtime is byte-identical to its baseline
  counterpart, except `START_HERE.md` (extended with the split section — old
  text preserved, changes recorded in the verification report). Full
  machine-verified accounting: `VERIFICATION_AND_CHANGES_v2.1.1.md`.
- Neither package contains the other; the only nested ZIPs are the
  pre-existing superseded release archives inside the archive.
- No credentials in either package (pattern-scanned).
