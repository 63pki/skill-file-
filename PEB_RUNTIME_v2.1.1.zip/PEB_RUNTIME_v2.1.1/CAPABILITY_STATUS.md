# Capability status — v2.0 (four separate conclusions)

| Layer | Status | Evidence |
|---|---|---|
| **Technical validation** | TESTED (scoped, offline) | 79/79 unit tests pass in this build: record contract v2 (51), probe identity/fixtures (5), vision contracts (12), historical creative gate (6), standalone-prompt guard (6). Full v1.4.0 manifest re-verified 523/523; frozen core byte-identity re-checked in v2.0 packaging; credential scan 0 hits. Scope: structures, identities and record honesty — never media quality. |
| **Editorial judgment** | DOCUMENTED, not performance-tested | The v4.0 prompt, playbook v1.1 and 14 regression cases encode the debriefs' creative lessons (idea before template, headline-removal counterfactual, actual-export review, vary-or-omit, exception expiry). Whether a fresh agent *behaves* better is unproven until the first authorized pilot is observed. Structural checks deliberately do not score taste. |
| **Campaign clearance** | NONE | No current campaign is active. RexTrix stays paused; its requirements/approvals are historical. Any next campaign needs a fresh brief reconciliation, requirements table and authorizations (startup instruction step 1). No rights, language, claims or channel checks have been run for any future work. |
| **Actual audience performance** | UNKNOWN | No matched post-level analytics exist for any delivered clip. No view, retention or reach claim is made or supportable. Performance becomes knowable only after separately authorized publication plus real analytics. |

## Capability limits that remain genuinely open (stated, not hidden)

- **Word-safe speech boundaries**: no packaged tool verifies them. Model
  timestamps are estimates; the honest workflow (frames for picture edges,
  authorized audio-aware routes for speech, uncertainty labeled) is in v4.0 §2.
- **Final-mix ducking verification**: no method on record without stems;
  recipes are "built-as" claims (v4.0 §9).
- **External AV-model perception**: embedded-MP4 soundtrack ingestion untested;
  the aligned silent-video+WAV route is the historically exercised input;
  fixture INCOMPLETE_NOT_PASSED; timestamps unreliable (evidence on record).
- **ffprobe identity**: unpinned; scoped features tested, not provenance.

## What would change each status

- Editorial judgment → TESTED: first authorized campaign pilot reviewed
  against the startup instruction's steps, with the record's review entries
  compared against independent observation.
- Campaign clearance → TESTED: a fresh brief reconciled and its mandatory
  requirements actually verified on an output.
- Performance → TESTED: separately authorized publication with matched
  analytics, pre-registered hypothesis, real denominators.
