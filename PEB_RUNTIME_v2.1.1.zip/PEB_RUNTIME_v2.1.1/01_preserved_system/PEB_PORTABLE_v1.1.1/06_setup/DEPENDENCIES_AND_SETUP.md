> HISTORICAL BASELINE / NOT ACTIVE STARTUP GUIDANCE. See START_HERE.md and the v1.1 registry, inventory and status ledger. Prior probe claims are inherited, not current-machine verification. Local relative references may describe the original workspace.

# DEPENDENCIES AND SETUP (v1.0, 2026-10-28)

**Compliance:** this document records how to set the environment up. NOTHING in it was installed or executed while packaging. Every install remains gated by the TOOL_REGISTRY 8-step install gate (`../02_registry/PEB_v3.2_MODULE_TOOL_REGISTRY.md` §3: need → match → license → approval → telemetry-off → pin → smoke test → after-action). No tool is installed by default; nothing installs mid-campaign without a pattern-amendment ruling.

## 1. Toolchain tiers (see TOOL_REGISTRY for full cards)

| Tier | Tool | Status in this project | Install class |
|---|---|---|---|
| T0 | FFmpeg + ffprobe | **Production-proven** (frozen chain: conform, `-c copy` concat seams, loudnorm two-pass + alimiter + ebur128, H.264/AAC encode, blackdetect/freezedetect, frame extraction, hashing, metadata hygiene) | FREE-OPEN — system package |
| T1 | faster-whisper (small int8; base fallback) | **Production** (word-timestamp ASR; timestamps are estimates, never claim ground truth) | FREE-OPEN — pip |
| T2 | Pillow + CairoSVG | **Production-proven** (static cards/overlays; no timeline, no motion) | FREE-OPEN — pip |
| T3 | HyperFrames (HeyGen) — pinned **0.8.207** | **Probe-verified 9/9** (frame grid, CRF control, ProRes 4444 alpha, determinism ×3, audio routing, font-fallback lint). The ONE primary production motion-graphics renderer. Requires Node.js ≥ 22 + bundled Chromium + FFmpeg. Apache-2.0, no account, local-only path free. | FREE-OPEN — pin version; smoke test = 1 s fixture 1080×1920@30000/1001 |
| T4 | Remotion | **GATED** — license (free ≤3-person orgs; 4+ employees = Company License, $100/mo floor). NOT installed. | FREE-CLAUSED — operator written approval BEFORE install |
| T5 | Tesseract by Mirage (tsrct) | **GATED** — proprietary freemium; ≥$1M-revenue "Covered Business" clause; telemetry ON by default; integer-fps only; Linux bundle lacks H.264 encoder. NOT installed. | FREE-CLAUSED — approval + probe required |
| T6 | Tesseract OCR (classic — NOT T5; name collision) | **Card + smoke spec** (banned-claim intake sweep: OCR N sampled frames → grep banned vocabulary; "no hits" ≠ "no claims") | FREE-OPEN — pin at install |
| T7 | InVideo MCP | Report-only; only if exposed and authorized | ACCOUNT/CLOUD — default OFF |

## 2. Install commands (TEXT ONLY — do not run without a ruling)

```bash
# T0 — FFmpeg / ffprobe (system package manager)
sudo apt-get install -y ffmpeg        # or: brew install ffmpeg

# T1 — ASR
pip install faster-whisper

# T2 — static graphics
pip install pillow cairosvg

# T6 — OCR intake sweep
sudo apt-get install -y tesseract-ocr  # or: brew install tesseract

# T3 — motion-graphics compositor (pin 0.8.207; follow the TOOL_REGISTRY T3 card
#      for the exact package/install surface — verify against the live repo docs
#      at install time; smoke test BEFORE first production use)
#      Node.js >= 22 required. Cloud/MCP/Studio paths stay OFF (account class).
```

T4/T5/T7: **no commands on file as approved** — they stay uninstalled until the license/approval gates clear (TOOL_REGISTRY §4 clause texts must be quoted to the operator when asking).

## 3. Fonts (check before any text-bearing render)

- **Malayalam lanes (M2):** verify a Malayalam-capable font BEFORE rendering: `fc-list :lang=ml` (Manjari / Noto Sans Malayalam class). Never put Malayalam in serif/mono stacks; conjuncts need taller mask padding (see `../04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md`).
- **Current campaign placeholder:** DejaVu (disclosed placeholder in the RexTrix pilot — a campaign font decision is still pending with the operator).
- **Catalog-referenced fonts** (Instrument Serif, JetBrains Mono, Lora, Montserrat/Anton/Bebas): Google-Fonts-class; NOT bundled with the catalogs — license re-read happens at adoption per standing G3; T3's font-fetch/cache behavior applies.
- Preview/symbol fallbacks for chart PNGs: Noto Sans SC + DejaVu Sans per-glyph fallback pattern (project plotting convention).

## 4. Python environment for the components (`../05_components/`)

- `../05_components/make_sheets.py` / `../05_components/make_sheet2.py`: Pillow (DejaVu font paths assumed present).
- `../05_components/verify_pack_equivalence.py`, `../05_components/verify_operator_input_v1.py`, `../05_components/v31_regression_audit.py`, `../05_components/v3_regression_audit.py`: Python 3 stdlib only (hashlib, zipfile, pathlib, re, json).
- `../05_components/pilot28_verify.py`: stdlib + FFmpeg/ffprobe on PATH (subprocess).
- Shell components (the four qc_ probe scripts and `../05_components/run_asr.sh`): bash + FFmpeg/ffprobe + `rg` (ripgrep) + the T1 transcription provider call pattern used at the time (adapt to the campaign's authorized ASR route).

## 5. Environment notes carried over from production

- Program loudness stays in the FFmpeg chain (loudnorm two-pass + alimiter + ebur128 with XR-4 corrections: identical targets/preprocessing across passes; `adelay=3S` is SAMPLES not ms; impulse latency test mandatory). Do NOT duplicate loudness in T3.
- QC is fail-closed (XR-3): a gate that cannot measure FAILS, with negative fixtures in the set.
- Determinism contract for any render path (inventory row 11): no wall-clock timers, no uncontrolled randomness, no uncontrolled network fetches inside a composition.
- Campaign freeze: the live RexTrix v1 run completes on its frozen FFmpeg chain; new tools activate only at the next brief reconciliation, installs happen under the gate BEFORE first render, versions pinned in the project manifest.
