SCOUT CORRECTION NOTES — for the AI that writes campaign briefs
================================================================
Issued 2026-10-27 after master-intake verification of the first real brief
(CAMPAIGN_BRIEF_RexTrix). Attach these notes to the scout AI together with
SCOUT_campaign_brief_prompt_v2.txt (v2 supersedes v1 — the same rules are baked into it).
If you only get the v1 prompt, these notes win on every conflict.

TO: the campaign scout / brief-writing AI
WHAT THIS IS: corrections from the first production run. Six defects were found at intake
verification. Study them, then apply the standing rules on EVERY future brief.

WHAT YOU DID RIGHT (keep doing)
-------------------------------
- source_ref on every requirement; class tags everywhere; MISSING marking instead of guessing;
  operator notes fenced in section 9; operator evidence labeled as non-campaign documents;
  and you DECLARED your paraphrase deviation instead of hiding it. That structure is why the
  brief was salvageable at intake instead of rejected outright.

THE SIX CORRECTIONS
-------------------

CR-1 — A default must never sit below enforced practice
WHAT HAPPENED: you proposed a ">=3.5 s" end-card default. The enforced historical floor was
4.0 s (a delivery had already been rejected at exactly 4.0 s — zero margin), and the operator
standard is 4.0 s + 0.5 s margin.
WHY IT IS A DEFECT: a weaker default silently re-creates a known rejection class. The master
prompt would have followed your number legally, because defaults are what it falls back on.
STANDING RULE: before proposing ANY default, check it against (a) rejection / enforcement
evidence and (b) measurements of accepted deliveries. Defaults may be equal or STRONGER than
proven practice — never weaker.

CR-2 — Enforcement evidence + no written rule => AMENDMENT REQUIRED, not an optional default
WHAT HAPPENED: the end-card and language rules were clearly enforced (2026-10-23 rejections)
but absent from the written rules doc, so you filed them as open questions with defaults.
The master treats defaults as optional BY DESIGN (that is its honesty layer working as
intended), so it could have legally shipped rejectable clips.
STANDING RULE: when operator evidence proves a rule is enforced but no written source states
it, emit a dedicated block titled "AMENDMENT REQUIRED" containing: the rule, the evidence,
proposed mandatory wording, and the sentence "operator must confirm class: mandatory before
attach". Never let an enforced rule rest on a default.

CR-3 — Paraphrase => ATTACH NOTE with a verbatim-read directive
WHAT HAPPENED: you paraphrased the rules doc and declared it (good), but nothing ordered the
master to read the contamination-critical sections verbatim, so paraphrase residue could leak
into the claims ledger and banned list.
STANDING RULE: whenever ANY part of the brief paraphrases the source doc, add an "ATTACH NOTE"
at the top naming the sections that feed the claims ledger / banned list / end-card definition
/ CTA wording, and ordering the master to read those sections verbatim before intake.
Contamination-critical strings (banned lists, end-card definition, CTA wording) are always
verbatim or MISSING — never paraphrased in depth.

CR-4 — Every MISSING gets an explicit fallback or an explicit "no fallback"
WHAT HAPPENED: technical specs (resolution / fps / container / runtime) were missing from the
campaign docs; some landed as bare questions without the operator-standard cross-ref next to
them, leaving the master to bridge the gap itself.
STANDING RULE: for every MISSING fact, write either
  `operator_default: <value> (source: <who set it>)`
or
  `no fallback — operator must supply`.
Never leave a MISSING bare, and never invent a value to fill one.

CR-5 — Operator evidence is labeled, every time (promoted to a standing rule)
WHAT HAPPENED: you correctly labeled the rejection records as non-campaign documents. Keep it.
STANDING RULE: every citation of operator evidence carries "NOT a campaign document", and it
never fills a campaign-rule slot. Its requirements enter the brief only through the amendment
path (CR-2) — evidence justifies, the operator authorizes.

CR-6 — Amendments are integrated, not lost
WHAT HAPPENED: a pre-attach amendment was issued after your report; the final brief still
carried the affected items as unresolved questions, as if the amendment did not exist. Intake
verification had to re-issue it matched to your numbers.
STANDING RULE: when an amendment exists, integrate it into the brief BEFORE emitting the final
version, or carry a "PENDING AMENDMENT" block with the exact paste text and the question IDs
it closes. The final brief and the amendment state must never disagree.

PRE-FLIGHT SELF-CHECK (run before emitting any brief)
-----------------------------------------------------
1.  Every requirement has source_ref + class (m/p).
2.  Every default checked against rejection evidence and accepted-delivery measurements (CR-1).
3.  Every enforced-but-unwritten rule has an AMENDMENT REQUIRED block (CR-2).
4.  Every paraphrased section is covered by the ATTACH NOTE (CR-3).
5.  Every MISSING has operator_default or "no fallback — operator must supply" (CR-4).
6.  Operator evidence labeled "NOT a campaign document" everywhere it appears (CR-5).
7.  Amendment state integrated or explicitly pending with paste text (CR-6).
8.  Banned lists / end-card definition / CTA wording verbatim or MISSING.
9.  Section 9 fenced as NOT editing requirements.
10. Status line honest: READY_FOR_MASTER_INTAKE only if 1–9 all pass; otherwise BLOCKED with
    the reason.

HOW TO USE THIS FILE
--------------------
- Option 1 (recommended): attach SCOUT_campaign_brief_prompt_v2.txt — corrections are baked in.
- Option 2: attach the v1 prompt plus this file; this file wins on every conflict.
