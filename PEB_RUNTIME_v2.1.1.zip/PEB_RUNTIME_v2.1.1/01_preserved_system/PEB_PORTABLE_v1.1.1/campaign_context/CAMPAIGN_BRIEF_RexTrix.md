# CAMPAIGN BRIEF — RexTrix
# Master-intake edition v1.0 (2026-10-27) — consolidated from the scout's verified brief,
# with pre-attach amendment v2 applied and the one intake-verification correction applied.

source_platform: Content Rewards (Whop) — campaign page verified by scout 2026-10-22/23
reconciled_against:
  - RexTrix campaign rules doc §§1–10 (scout full read 2026-10-26; source text is full authority)
  - Campaign page on Content Rewards (verified 2026-10-22/23)
  - Supplied assets Drive (see §6 link register)
  - Operator evidence — 2026-10-23 rejection records (NOT a campaign document; see §7.2)
  - Operator campaign input, RexTrix profile (2026-10) — operator-supplied standards
status: VERIFIED_READY_FOR_MASTER_INTAKE — amendment v2 applied 2026-10-27 per operator
  instruction in the operator thread; the operator may amend any entry by editing this brief.

>> ATTACH NOTE — THE MASTER PROMPT MUST READ THIS BEFORE INTAKE <<
The scout's brief paraphrases the rules doc (declared deviation, accepted 2026-10-27 under
condition). This brief is an INDEX: classes and source_refs below route the master; the source
document enforces. Before compiling the claims ledger and banned list, read these sections of
the rules doc VERBATIM: §2 (claims/positioning language) · §4 (banned content) · §5 (end-card
definition) · §8 (CTA wording).
If the rules doc is unreachable in this run, treat banned_claims, the end-card definition and
CTA wording exactly as written here — never paraphrase them further, never extend them from
memory or imagination.

## 1. CAMPAIGN VALUES
- brand / product: RexTrix — "AI-generated Games & Stories" (AI-generated playable games +
  serialized AI dramas) — source: operator campaign input §1 — class: m
- objective: app installs via the account bio link (onelink, live from day 1, see §6) —
  source: operator campaign input §1 — class: m
- audience: US-weighted (posting account must hold 40%+ US audience — §7.1) — class: m
- viewer_value: can't-believe-it's-AI entertainment with playable-game proof — class: p
- primary_mechanics (current campaign examples emphasize): C story-plot-twists and
  D creation-process (prompt → result) — source: campaign page examples, scout verified
  2026-10-22/23 — class: p
- optional_mechanics (approved format menu): A can't-believe-AI-made-this · B gameplay
  challenge · E POV reactions · F before/after · G trend riding — source: operator campaign
  input §8 — class: p
- platform_targets: TikTok @rextrix_ai_studio · Instagram @rextrix_ai_info · X @RextrixAI ·
  YouTube "RexTrix AI" · Facebook "RexTrix.AI"; primary: YouTube Shorts — source: operator
  campaign input §1 — class: p (confirm the current account set on the campaign page before
  the first post)

## 2. DELIVERY REQUIREMENTS
The campaign documents specify NONE of the technical delivery values below — all were MISSING
in the scout's brief (Q-IDs follow the scout's numbering). The operator standard is the
fallback everywhere; it matches all 10 accepted RexTrix deliveries of 2026-10 (ffprobe-verified).
- resolution: MISSING (Q1) — operator_default: 1080×1920 (9:16) — class: operator_default
- fps: MISSING (Q2) — operator_default: constant 30 fps — class: operator_default
- runtime: MISSING (Q6) — operator_default: 15–25 s mini-arc band (proven delivery class ≈22 s);
  no campaign minimum/maximum on record — class: operator_default
- language_rule: English-only spoken speech AND English-only burned-in text — MANDATORY.
  (Q4 CLOSED by amendment v2 — was an open question with a default, which the master would
  have treated as optional by design.) Enforcement evidence: 2026-10-23 rejections —
  non-English speech was rejected even with English paraphrase captions; captions do NOT
  rescue non-English source speech — source: amendment v2 (2026-10-27) + operator evidence
  (NOT a campaign document) — class: m
- container / codec: MISSING (Q5) — operator_default: MP4 H.264 High yuv420p + AAC 48 kHz
  stereo — class: operator_default
- burned-in accessibility captions: not required by any campaign document (Q7) — class: p.
  Deliberately preference-class so a wordless visual treatment stays legal (FRT); if the
  operator ever confirms captions mandatory, the master must be told in writing.

## 3. BRANDING AND CTA
- end card: REQUIRED on every delivery. Definition (verbatim intent — do not paraphrase
  further): RexTrix LOGO GRAPHIC + wording "Download the app — link in bio".
  Minimum hold: ≥ 4.5 s measured on the encoded delivery (4.0 s enforced floor + 0.5 s margin).
  (Q3 CLOSED by amendment v2. The scout's proposed ≥3.5 s default was corrected at intake
  verification 2026-10-27: it sat below the enforced 4.0 s floor and would have re-created the
  Clip-16 rejection class — a delivery measured at exactly 4.0 s against a 4 s rule is a
  zero-margin, at-risk edge.)
  Sources: operator evidence 2026-10-23 (text-only wording like "Link in bio / to try RexTrix"
  was REJECTED — logo graphic + explicit "Download the app" wording is required) + amendment
  v2 (2026-10-27); margin lineage P-V1 and appendix §A.1 margin_seconds 0.5 — class: m
- mandatory_inclusions:
  - Caption mentions "RexTrix", ideally in the first 3–4 words — source: operator campaign
    input §2 — class: m
  - Clear RexTrix connection in every video: app UI visible, real gameplay, verbal mention,
    or on-screen text — source: operator campaign input §2 — class: m
- cta_rules (Q8 CLOSED by amendment v2):
  - Every video carries a verbal or on-screen CTA telling viewers to click the link in bio —
    source: operator campaign input §2 — class: m
  - Approved wording: "Download the app — link in bio" (end card); "click the link in bio"
    (spoken / on-screen) — source: amendment v2 (2026-10-27), aligned with rules doc §8 via
    the ATTACH NOTE — class: m
  - Approved destination: the account bio link only (single onelink destination, §6) — class: m
  - Max CTA requests per clip: the end card + at most one earlier mention — class: p
    (taste guard; master-side §15)

## 4. BANNED
- banned_claims (never display — same status as fabricated content; verify against rules doc
  §4 via the ATTACH NOTE):
  - "every game free"
  - "unlimited generations"
  - "earn real money"
  - any invented feature or capability the app does not have
  - edited screenshots, fabricated analytics, manipulated engagement (fraud → removal)
  Source: rules doc §4 via scout read 2026-10-26 + operator campaign input §3 — class: m
- claims ledger (seed — extend only with evidence from the source doc):
  | id | wording | status | allowed on-screen wording |
  | R-01 | "AI-generated games & stories" | approved (client positioning) | as stated |
  | R-02 | "Type an idea → get a playable game" | approved IF real gameplay shown proving it | as stated |
  | R-03 | specific game/show titles (e.g., Live Paranormal: Sacred Heart Asylum, Panda BoBo, The Phoenix Throne, ZEROED, NULL ANGEL) | approved per asset | asset title only |
  | R-04 | pricing, generation limits, rewards | NOT verified | do not display |
  Source: operator campaign input §7 — class: m for the do-not-display rows

## 5. OWNER MANDATES
(Only mandates stated in writing live here, with class and source_ref. Anything merely
"felt" to be wanted goes to §8 as a question, never here.)
- mandate: end card on every delivery, per §3 definition and hold — class: m — source_ref:
  operator amendment v2 (2026-10-27), backed by 2026-10-23 enforcement evidence
- mandate: English-only speech and burned-in text, per §2 — class: m — source_ref: operator
  amendment v2 (2026-10-27), backed by 2026-10-23 enforcement evidence
- mandate: original audio only — keep each asset's ORIGINAL audio; no external music, no
  voiceover. Campaign materials are silent on audio licensing; this is the safe fallback and
  an operator mandate (Q9 default) — class: m — source_ref: operator campaign input §4
- mandate: verify each asset's content and quality before building on it; a supplied asset is
  not automatically usable — class: m — source_ref: operator campaign input §4 (matches the
  master's per-asset evidence floor, CORE §7.1)
- mandate: landscape sources get blurred-pad or QC-passed tracking crop only — never slice
  faces or text — class: m — source_ref: operator campaign input §8
- preferences (same source, operator campaign input §8): hook-first opening (strongest visual
  in first 3 s, one hook line max) · 15–25 s mini-arc (setup → escalation → payoff) · burned-in
  text kept in the top ~78% of frame — class: p

## 6. ASSETS AND SOURCES
- link register:
  - Supplied assets Drive — role: raw footage / game captures — access: checked by scout
    2026-10 — notes: some sources are 640×360 upscales (soft main image); the per-asset
    minimal evidence floor (CORE §7.1) and degraded-source disclosure (P-V3) apply
  - Bio link: https://rextrix.onelink.me/nJbb/dbj5fov3 — role: approved CTA destination —
    status: live from day 1 — source: operator campaign input §1
  - Logo file: MISSING as a confirmed asset — provenance unconfirmed (the rextrix.ai wordmark
    could not be verified from a homepage fetch) — the operator must supply the transparent
    PNG before any end-card render — class: m (blocker for the end card)
  - Fonts / colors: MISSING — the module may propose and the operator approves
- rights statement: official RexTrix material only — the supplied assets Drive or RexTrix's
  own socials; no stock footage, no other games, no third-party content — source: operator
  campaign input §4 + rules doc rights section — class: m

## 7. SUBMISSION AND OPERATOR CHECKLIST
7.1 Submission (operator executes — not the editing agent):
- Post publicly on the target platform, then submit the post URL on the campaign page within
  30 minutes of posting (older posts are rejected) — sources: rules doc (scout read
  2026-10-26) AND operator evidence of consistent practice — dual-source — class: m
- After 24 h: screen-record the post's analytics (views, reach, audience) and send it to the
  campaign support chat — review does not start without it — class: m
- Keep the post public through the campaign + review period — class: m
- Posting account must hold 40%+ US audience; post at US prime time; seed the first hour with
  US viewers — class: m
7.2 Operator evidence — NOT campaign documents:
- The 2026-10-23 rejection records prove enforcement of the end-card and language rules. They
  are evidence, not written campaign rules; their requirements enter this brief only through
  amendment v2 (§3, §5). Never cite them as campaign-document sources; never let them fill a
  campaign-rule slot directly.

## 8. UNRESOLVED QUESTIONS
(Closed by amendment v2, kept for audit: Q3 end-card → §3 · Q4 language → §2 · Q8 CTA wording
→ §3. Open items follow; each states the default currently in force.)
- Q1 resolution — why it matters: no campaign spec — default in force: 1080×1920
- Q2 fps — why: no campaign spec — default in force: constant 30 fps
- Q5 container/codec — why: no campaign spec — default in force: MP4 H.264 yuv420p + AAC 48 kHz
- Q6 runtime — why: no campaign min/max on record — default in force: 15–25 s band
- Q7 burned-in captions — why: not required by any campaign document — default in force:
  preference, not mandatory (keeps wordless treatments legal)
- Q9 audio licensing beyond the original-audio fallback — why: campaign silent — default in
  force: original audio only, no external music/VO
- LOGO ASSET (blocker, not a default): the operator must supply the transparent logo PNG
  before any end-card render; provenance confirmation remains open.

## 9. OPERATOR NOTES — NOT EDITING REQUIREMENTS
(The master prompt must ignore this section; it is for the human only.)
- Reward terms: caps at $200 / $300 per the campaign page (scout verified 2026-10-22/23);
  re-check the page for current per-tier terms before each batch.
- Competition / deadline pressure: check the campaign page leaderboard before planning batch
  size; the scout's ranking rationale is in the scout's report.
- Selection rationale: RexTrix passed all five scout gates (rights / written rules / real
  rewards / source quality / low risk). Residual risks: soft 640×360 sources (managed by
  CORE §7.1 + P-V3 disclosure), watermark motion-check on dark scenes (clips 05/06/09 class),
  and the logo-asset blocker in §6.
- End-card timing note: new renders must clear ≥4.5 s hold on the encoded file — the ten
  accepted 2026-10 deliveries measured exactly 4.0 s (zero margin, at-risk edge).

## VERIFICATION RECORD (master-intake verification, 2026-10-27)
- Structure verified against CORE §3 intake + appendix §A schema: source_ref on every
  requirement, class tags, MISSING marking, operator-evidence labeling, fenced operator notes.
- One correction applied: Q3 end-card default ≥3.5 s → ≥4.5 s (4.0 s floor + 0.5 s margin;
  P-V1 lineage; Clip-16 measured exactly 4.0 s against the 4 s rule).
- Pre-attach amendment v2 applied inline: end-card and language rules promoted to MANDATORY
  (were open questions with defaults); CTA wording closed.
- Paraphrase deviation accepted under condition: the ATTACH NOTE verbatim-read directive is
  included and names rules-doc §2/§4/§5/§8.
- Profile dry-run compile: language_gate, end_card, mandatory_inclusions, banned claims,
  cta_rules, operator steps, platform targets, owner mandates — all compile cleanly; captions
  remain preference-class so wordless treatments stay legal.
- Remaining opens: Q1/Q2/Q5/Q6/Q7/Q9 with defaults; logo asset = operator blocker.
