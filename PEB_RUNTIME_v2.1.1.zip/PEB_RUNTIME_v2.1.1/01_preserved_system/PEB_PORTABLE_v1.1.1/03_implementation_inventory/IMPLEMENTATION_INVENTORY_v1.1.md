# Implementation Inventory v1.1 — evidence-corrected candidate

Check before building, but do not pretend a pattern is a portable component. Reuse/adapt when fit; new bounded implementation is allowed for an evidenced gap. No "never rebuild" rule or exclusive concat architecture.
No source probe reports T3/T4/T5 were included. Prior results remain inherited claims. All new-environment feature tests are pending. Builder tests cover package structure and its own helper logic only.

| ID | Need | Supplied implementation | Evidence | Required verification |
|---|---|---|---|---|
| IM-01 | Cuts/conform/concat | Pattern only; no portable cut/encode CLI supplied | Historical production claim; no source probe artifacts | Frame-exact cuts, source bounds, seam/audio behavior; stream-copy only for compatible streams; single-pass valid |
| IM-02 | Program loudness | Legacy qc_loudness.sh measures; it is NOT a portable normalization chain | Historical claim; normalization implementation/impulse fixture not delivered | Measure encoded true peak/loudness; test latency/preprocessing; no fixed loudness universal platform rule |
| IM-03 | Encoding | FFmpeg recipe/policy, not portable encoder package | Historical claim only | Exact codecs, frame grid, duration, decode and synchronization |
| IM-04 | Static graphics | Templates/patterns, no general card API | Historical claim; no current test | Actual layout, glyphs, brand/source evidence |
| IM-05 | Animated graphics | 20 HTML template examples + reference renderer; HyperFrames route documented | No rendering in this build; old probe reports missing | Selected template deterministic seeks, alpha, fonts, timing; no automatic adapter claim |
| IM-06 | Transcription | Legacy run_asr.sh invokes z-ai asr, NOT faster-whisper; provider route nonportable | Static source inspection; original T1 mapping not demonstrated | Approved local/provider implementation, data/privacy, model assets, timestamp uncertainty |
| IM-07 | Claim/OCR sweep | Known-card fixture remains specification only | Not feature-tested | Known-positive and known-negative text plus manual frame review; no-hit is not clearance |
| IM-08 | QC measurement | Legacy scripts + new portable media inspection helper | New helper syntax/unit tests only; no media/backend executed | Full decode when feasible, frame timestamps, end conditions and audio review; partial checks labeled |
| IM-09 | Metadata hygiene | Example FFmpeg remux command | No current backend test | Inspect actual tags; no distribution claims |
| IM-10 | Audio transforms | Recipes, not blanket campaign permission | No current feature tests | Original provenance does not excuse changed meaning, clipped words or unauthorized retiming |
| IM-11 | Deterministic rendering | Contract + HTML examples | Author/historical claims; no runtime evidence here | Out-of-order repeated seeks under exact environment; no uncontrolled clock/randomness/network |
| IM-12 | Alpha intermediates | Historical HyperFrames/codec recipe | Original per-pixel probe absent | Decoded alpha behavior on target platform, not extension alone |
| IM-13 | Styled captions | 41+24 catalogs; legacy ASS sketches, six design recipes | No caption renderer verified by builder | Selected real language text, shaping, contrast, overlaps and cut/retime mapping |

Raw source components are retained in archive/legacy_components, with their original hard-coded paths; do not execute them as turnkey tools. See the new components map for exact static limitations. JSON companion contains project approval/test status fields for each row.
