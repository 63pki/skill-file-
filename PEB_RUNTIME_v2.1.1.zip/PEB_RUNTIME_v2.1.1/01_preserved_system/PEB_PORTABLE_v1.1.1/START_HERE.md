# START HERE — Pro Editor Brain portable v1.1.1 (reviewed candidate, corrections applied)

This is an improvement of the existing PEB system, not a fresh master prompt and NOT an approved autonomous production system. Independent architect review verdict: APPROVE WITH TARGETED CORRECTIONS (07_status/BUILDER_CANDIDATE_v1.1_ARCHITECT_REVIEW.md); corrections C1-C3 and the archive-comparison clarification are applied in this v1.1.1 packaging. No campaign, production or installation permission is inherited.

## Read first
1. [Fresh-session instructions](FRESH_SESSION_INSTRUCTIONS.md) — what to attach, read order, on-demand loading.
2. [Status](07_status/STATUS_LEDGER_v1.1.md).
3. [Existing core with limited integration preface](01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md).
4. [Skill Registry](02_registry/SKILL_REGISTRY_v1.1.md) and [Implementation Inventory](03_implementation_inventory/IMPLEMENTATION_INVENTORY_v1.1.md).
5. [Setup](06_setup/DEPENDENCIES_AND_SETUP_v1.1.md), only when a capability is needed.
Read the three core modules on task trigger, not the entire archive. The core's original v3.1.1 tests/claims are historical. Use the active status ledger for this package.

## Fresh editing session
Attach this ZIP and the NEW campaign brief (which may contain guidelines/Drive/raw-asset links). Ask for intake and a pilot plan first. Save the brief and needed linked evidence; verify access/permissions rather than asking the user to retype accessible sources. Do not activate RexTrix files under campaign_context by default. Example values and historical original-audio/end-card/fps freezes are not universal rules.
Check reusable components before rebuilding, but do not mistake hard-coded scripts or spec-only fixtures for working integrations. Choose one primary workflow/compositor and only relevant specialist references. No suitable skill, clean cut or no added treatment are valid. Ambitious motion/explanation is also valid when meaning and permissions justify it.
Local/source snapshot does not mean installed; installed does not mean tested; approved does not prove a feature. Verify necessary features in this environment after review authorization. No render before approved pilot plan. No unsupervised batches or publishing.

## Resource locations
- [Catalog guidance](04_catalogs_and_resources/CATALOG_GUIDANCE_v1.1.md).
- [Two new repositories](02_registry/NEW_RESOURCES_2.md).
- [Components map](05_components/COMPONENTS_MAP_v1.1.md).
- [Project record](09_project_templates/PROJECT_RECORD_TEMPLATE.json) and [resume template](09_project_templates/RESUME_TEMPLATE.md).
- [Change log](07_status/CHANGELOG_v1.1.md), [decisions](07_status/PENDING_RULINGS_v1.1.md), [review request](07_status/ARCHITECT_REVIEW_REQUEST.md) and [architect review verdict](07_status/BUILDER_CANDIDATE_v1.1_ARCHITECT_REVIEW.md).
- Original reports and source-era files remain in archive; never mandatory startup reading or authority for a different campaign.

## Optional package-only verification
`python 05_components/verify_package.py --root .`
This builder-written stdlib validator checks navigation, manifest hashes, parsed inventory and preserved IDs across all four catalog keys (style_id, effect_id, sfx_id, library_id); it does not execute vendor/legacy code or render. See the generated validation report for actual results and test limits. Source-vendor nested ZIPs are reference material, not auto-extracted/installed.
