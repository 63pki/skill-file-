# Fresh-session instructions — PEB portable v1.1.1

How to open a NEW editing session with this package. Reading needs no tool
installs. Historical RexTrix material in this package is example history, not
your campaign.

## What the user attaches to the fresh session
1. This package (ZIP or extracted folder) — the portable system.
2. The NEW campaign brief for the CURRENT campaign: goals, audience, platform,
   assets/Drive links, constraints. If a brief is not attached yet, ask for it
   and stop creative work until it arrives.
3. Authorized source material for a pilot (start with ONE clip) and any
   access/permission details needed to reach linked assets.

## What the editing agent reads first (in order)
1. [START_HERE.md](START_HERE.md) — scope and authority limits.
2. [Status ledger v1.1](07_status/STATUS_LEDGER_v1.1.md) — what is and is not established.
3. [Active master prompt](01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md) — original v3.1.1 body plus the reviewed integration preface.
4. [Skill Registry v1.1](02_registry/SKILL_REGISTRY_v1.1.md) and [Implementation Inventory v1.1](03_implementation_inventory/IMPLEMENTATION_INVENTORY_v1.1.md).
5. [Pending rulings v1.1](07_status/PENDING_RULINGS_v1.1.md) — held rulings and approval boundary.

## What loads only when needed
- Master-prompt modules ([GRAPHICS](01_master_prompt/PEB_v3.1_MODULE_GRAPHICS.md),
  [MOTION PIPELINES](01_master_prompt/PEB_v3.1_MODULE_MOTION_PIPELINES.md),
  [APPENDIX](01_master_prompt/PEB_v3.1_APPENDIX_REFERENCE.md)) — on task trigger, not at startup.
- [Catalog guidance](04_catalogs_and_resources/CATALOG_GUIDANCE_v1.1.md) and the caption/effect/style catalogs — when selecting treatments.
- [External references](02_registry/NEW_RESOURCES_2.md) (LottieFiles motion-design skill, NullMotion) — reference only; their house rules are NOT release gates; asset rights stay separate from code licenses.
- [Setup](06_setup/DEPENDENCIES_AND_SETUP_v1.1.md) — only when a capability is actually needed.
- [Project record](09_project_templates/PROJECT_RECORD_TEMPLATE.json) and [resume](09_project_templates/RESUME_TEMPLATE.md) — when the project starts.
- `archive/` and `campaign_context/` — historical; read only to answer history questions; never default guidance.

## Non-negotiables for the fresh session
- Reconcile against the CURRENT brief. Historical RexTrix requirements (audio
  policy, end-card duration, fps freezes, banned words, platform restrictions)
  are examples, never defaults.
- Verify access to linked assets yourself; do not ask the user to retype what
  is already reachable.
- Record resource routing before creative work (see the opening message below).
- Propose a single-clip pilot and get operator approval BEFORE any production
  rendering, batching, installing or publishing.
- Document checks (including this package's validation report) are not media
  quality, rights clearance or production readiness.

## Copyable fresh-session opening message

```text
You are starting a fresh editing session with the PEB portable v1.1.1 package
(the extracted PEB_PORTABLE_v1.1.1 folder or its ZIP). Work through ALL five
steps before any creative or production work, then report back:

1. READ ORDER. Read START_HERE.md, then 07_status/STATUS_LEDGER_v1.1.md, then
   the active master prompt 01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md
   (original v3.1.1 body + reviewed integration preface), then
   02_registry/SKILL_REGISTRY_v1.1.md and
   03_implementation_inventory/IMPLEMENTATION_INVENTORY_v1.1.md. Load the
   master-prompt modules only when a task triggers them.

2. CURRENT-BRIEF RECONCILIATION. My CURRENT campaign brief is attached (if not,
   ask for it and stop). List every point where the package's defaults,
   recipes or historical examples conflict with this brief. Treat all
   historical RexTrix campaign values (audio policy, end-cards, fps, banned
   words, platform limits) as history only — they are NOT defaults for my
   campaign. The current brief wins wherever they differ.

3. ACCESS CHECKS. List which of my brief's linked assets/sources you can
   actually reach, and what is blocked or missing permissions. Do not ask me to
   retype anything you can already read. Flag anything that needs my
   authorization before use (including third-party media/music).

4. RESOURCE ROUTING. From the v1.1 registry and inventory, produce a routing
   record: ROUTING: primary=<chosen compositor/workflow>;
   specialists=<optional references>; none_reason=<if none chosen>. State what
   is actually implemented vs recipe-only, and which catalog entries (if any)
   the pilot would exercise.

5. PROPOSED PILOT (no production yet). Propose ONE single-clip pilot cut:
   the caption/effect treatment it exercises, the compositor path, what
   inspect_media.py will and will not establish, and the four review statuses
   you will fill in the project record. Do NOT render, batch, install tools,
   execute archived or supplier scripts, or publish anything before I approve
   this pilot plan.

Reply with: reconciliation report, access-check results, routing record, and
the proposed pilot plan.
```
