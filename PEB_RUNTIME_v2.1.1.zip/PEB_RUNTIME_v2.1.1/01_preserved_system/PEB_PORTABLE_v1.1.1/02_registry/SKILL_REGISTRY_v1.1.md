# Skill Registry v1.1 — builder review candidate

Status: documentation integration candidate, not production or campaign approval. Existing stable SR IDs preserved; baseline v1.0 is retained. Campaign examples are inactive unless reconciled with the current brief.

## Routing, not installation
Read the brief and inspect enough source material to identify a real task. Check the implementation inventory, then select one primary workflow at a time and justified specialists. Record `ROUTING: primary=...; specialists=...; none_reason=...`. Zero skills is valid. Change route when evidence changes. No numeric maximum on skills, mandatory phase citations or automatic demotion.
For an actual reuse, record component/section used, decision changed, adaptation and required check. Referencing a URL is not reuse of an implementation. Where no component fits, log the specific gap before authoring a bounded one.

## Evidence and permissions — separate axes
For each selected resource record: local availability, review depth, adaptation state, installed version, feature-test evidence and current-project authorization. These can overlap; approval is not a technical test. Rights: repository license may cover a skill file unless an exception applies; check code, text, assets and dependency/service terms separately. Missing rights are unresolved, not solved by calling an activity reference use. No blanket reproduction/adaptation permission is implied.
Current technical execution statuses are NOT established by this registry. Source tool probe artifacts are absent; repeat needed fixtures in the target environment. No rendering or installation occurred in this build.

## Catalog — body references are on demand
| IDs | Scope / trigger | Status / body location |
|---|---|---|
| SR-01,02,03 | HyperFrames authoring, CLI and block registry when chosen compositor | Historical candidates; exact bodies not bundled; pin and retrieve official version-matched instructions before use; local feature tests pending |
| SR-04 | Media-use adaptation | Fork design only, no executable fork exists; audio/visual/provider rights assessed separately |
| SR-10 | Herk short-form craft | Historical document review; body not resident; retrieve/pin before substantive adaptation; do not inherit generation/provider/approval shortcuts |
| SR-11 | Pluviobyte motion direction | Scope to purposeful designed segments; no universal motion-first doctrine; body retrieval and applicable rights check needed |
| SR-20,21,22 | Flick / official Remotion / cross-renderer idea | Not installed or tested by builder. Confirm exact tool terms and needed features; do not import historical pricing as current fact |
| SR-23..26 | Mirage tsrct specialist guidance | Historical gated candidates, not OCR; verify license/features only when triggered |
| SR-27 | Figma assistance | Proposed integration only; no verified tool binding |
| SR-40 | Speech captions, titles, labels and evidence graphics by role | [Caption library](../04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md); no style rendered here |
| SR-41 | Parameters after a treatment is chosen | [Effects spec](../04_catalogs_and_resources/Captions_and_Effects_v2/EFFECTS_AND_CAPTIONS_SPEC_v2.json); entries are not executable adapters; audio entries need authorized assets |
| SR-42 | Brand-appropriate stylized motion | [20-style material](../04_catalogs_and_resources/claude-motion-styles-20/README.md); template/code references only; no backend feature-tested; shared render.py is an alternative reference, not a universally banned path |
| SR-43 | Pastel explainer motion if suited to brand | [Style guide](../04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md); author-claimed recipes not reproduced; re-token explicitly if needed |
| SR-44 | Malayalam text/shaping and keyword workflow | [Language guide](../04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md); strip foreign environment instructions; preserve language; font glyph coverage and shaping tests, not blanket serif/mono exclusions |
| SR-45 | SaaS storyboard/reference craft | [Course PDF](../04_catalogs_and_resources/SaaS-Animation-Videos-with-Claude.pdf); copyrighted reference, no implied reproduction rights or provider authorization |
| SR-46 | Motion timing, choreography and emotional staging | [New resources card](NEW_RESOURCES_2.md); MIT text/adjacent references resident; optional defaults; no runtime tests |
| RF-NullMotion | Authorized reference/draft comparison | [New resources card](NEW_RESOURCES_2.md); app/reference, no SKILL.md found; implementation not adopted |

## Priority consultation, not a permanent parking lot
Cinetic: concept/branding/finishing gap. Product Launch Motion: product-specific visual narrative; inspect current vs legacy route separately. Video Demo: genuine product demonstration/capture. Cinematic Shot: motivated UI camera. Barty-Bart: motion B-roll. Open Design: selected UI/motion/reference templates. These are inherited research candidates: do not label code usable before source, terms, interface and needed feature are checked. Current compositor difference is not proof of irrelevance.

## Supporting catalog and dependencies
OpenMontage edit/understand/FFmpeg; 6missedcalls utilities; frame/OCR analysis; Baoyu transcript; MiniMax interpretation; Michaelgold structured extraction; ClaudeAnimationBase/pdoom implementation references. Exact links remain in the 20 and 26 link files. App-specific execution requires actual matching tools; useful concepts do not make those tools available.
GSAP, Matter.js, p5.brush, shadercn/TypeGPU, Hairline, Evil Buttons, Cube Motion, Oil Motion and Motion Canvas remain differentiated dependencies/supporting skills/engines, not interchangeable drop-ins. Enforce deterministic output states, font readiness, seeded randomness, controlled network and validated GPU/alpha as relevant, not a mandatory custom adapter for every library.
Vanta means itsjwill/vanta, the prior AI video-app reference; do not confuse it with a similarly named background library.
Onetake: inherited PolyForm Noncommercial restriction; resolve before paid campaign adoption. Guizang: inspect AGPL code and separately labeled assets under actual use; not an automatic blanket prohibition. Hosted generation: provider availability, privacy, costs, source rights and campaign permissions are separate decisions.

## Coverage and usage
Original [60+2 repository inventory](ALL_REPOSITORIES_62.txt), [20 links](SHORTLIST_DIRECT_SKILL_LINKS_20.txt), [26 links](CONDITIONAL_DIRECT_SKILL_LINKS_26.txt). Counts overlap; repositories, skills, cards and tested operations are different units.
Track not-needed / selected-used / selected-unnecessary / attempted-failed / superseded. Do not penalize rare specialist use. Four house topics (loudness, claim sweep, seams, delivery QC) are check responsibilities, not completed implementations merely because named.
