# PAPER-ROUTING TESTS — v0.9 (SKILL REGISTRY PROTOTYPE acceptance tests)

**Method:** three hypothetical briefs routed ON PAPER through the prototype registry + implementation inventory. No rendering, no installs, no core changes. A test passes if the registry rules produce a sensible routing record WITHOUT adding bureaucracy and WITHOUT forcing skill theater.

---

## TEST A — MATCH path (motion-graphics trigger)

**Fixture brief:** "Two A/B animated end-card variants, client X product, 9:16, 30 fps grid, original audio only, H.264 delivery, approval gates per campaign."

**Walkthrough:**
1. Reconciliation: brief fields → animated end card (motion trigger), 9:16, fps grid, audio policy, gates.
2. Inventory check (#4): static end cards are PROVEN — the *animated* qualifier is the trigger that justifies T3.
3. Routing decision:
```
ROUTING: primary=none (workflow = frozen chain per core) · specialists=[SR-01 hyperframes-core (EXEC), SR-03 registry blocks (EXEC), SR-11 ai-motion-director (REF, card-segments only)] · none-reason=—
```
4. SR-11 loaded REFERENCE-only (license uncleared) — fine: craft thesis citable, no execution needed.
5. Renderer binding: T3 via TOOL_REGISTRY card; SR-01 render contract; SR-02 available for ops.

**Corrections exercised:** #7 (reference vs executable split works), #8 (inventory consulted BEFORE any build decision).
**PASS criteria:** routing line exists; no card forced beyond triggers; renderer binds to T3 only.
**RESULT: PASS** — three-line record, zero new mandatory fields, creative choices (block selection, motion thesis) left open.

---

## TEST B — PARTIAL + REROUTE path (craft mismatch on real material)

**Fixture brief:** "Tighten an 8-minute talking-head interview to a 90-second reel. Keep original audio. Footage already has burned-in captions. 9:16."

**Walkthrough:**
1. Routing (initial):
```
ROUTING: primary=SR-10 herk-short-form-edit (REF) · specialists=[] · none-reason=—
```
2. Evidence in pre-scan: SR-10's caption lane assumes CREATING captions; material has burned-in captions (double-caption risk). Its music/SFX lane conflicts with original-audio provenance. Hook/loop/first-3-seconds structure still fits.
3. Reroute on evidence:
```
REROUTE: evidence=burned-in captions + audio provenance → SR-10 demoted to structure-only use (hook gate, open loops); caption/music lanes struck · switch=house conform chain drives workflow · outcome=pending render
```
4. Inventory consulted for cut-point support: T1 word timestamps (estimates — not ground truth); audio transform row (#10): any retime/atempo is chain-legal and provenance-neutral, but brief doesn't need it — not used.

**Corrections exercised:** #1 (evidence-based rerouting), #2 (one REROUTE line, not per-phase citations), #3 (n/a here), #4 (provenance vs transform kept distinct: burn-in conflict is a *layer* issue, music ban is a *provenance* issue — different rejections, different reasons).
**PASS criteria:** reroute logged with evidence; no silent lane-creep; structure guidance retained.
**RESULT: PASS** — registry absorbed a mismatched skill without abandoning its useful half.

---

## TEST C — NONE path + inventory-first (loudness batch)

**Fixture brief:** "Normalize 12 client sources to platform loudness target; produce per-source QC evidence; no picture edits."

**Walkthrough:**
1. Routing scan: no card covers loudness (craft cards are edit-craft; renderer cards are T3-bound; CATALOG is reference-only).
2. Honest no-match declared:
```
ROUTING: primary=none · specialists=[] · none-reason=no card covers loudness QC — inventory row #2 owns it
```
3. Inventory row #2: loudnorm two-pass + alimiter + ebur128, XR-4 corrections mandatory (impulse latency test on new environment). Zero skills loaded.
4. Gap log: "future house card `loudness-chain` pending core patches" → feeds §8 after-action.

**Corrections exercised:** #1 (NONE is first-class), #2 (no citations demanded — none possible), #8 (inventory-first honored — the agent does NOT rebuild loudness from a community skill or fresh filter experimentation).
**PASS criteria:** no skill theater; XR-4 surfaced; gap logged for the future house card.
**RESULT: PASS** — the registry's most important property: it sends the agent to tested components, not to the skill pile.

---

## Verdict

3/3 paper tests pass. The mechanism produces one routing line per project, absorbs mismatches via logged reroutes, and routes "no skill" cases to the implementation inventory. Ready for operator review; runtime use still requires the core patch decision (see PROPOSED_CORE_PATCHES_MINIMAL_v0.9) — separately, and not applied.
