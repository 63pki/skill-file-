# Two additions, not two verified editing tools

## SR-46 — LottieFiles motion-design
Pinned commit: f9a8a041b85185ee4881b3471d3415e939aac772.
Source: https://github.com/LottieFiles/motion-design-skill/blob/f9a8a041b85185ee4881b3471d3415e939aac772/skills/motion-design/SKILL.md
MIT license text and 16 adjacent Markdown references stored with the exact skill document.
Directly read: root skill, README and LICENSE. Adjacent reference documents preserved but not all substantively reviewed.
Trigger: a selected motion beat needs emotional intent, staging, timing, easing or multi-element choreography. Not a general footage editor, Lottie exporter or installed renderer.
Local body: ../08_external_references/LottieFiles__motion-design-skill/files/skills/motion-design/SKILL.md
Read only selected relevant references. UI-response timing tables are illustrative, not universal film timings. Do NOT inherit always-three-layers, never-linear, never-opacity-only, one-third quotas, universal personality categories, or mandatory stagger limits as release gates. Linear camera drift or opacity-only fades may be appropriate. No ambient motion is required. Source timing, legibility, reduced motion, meaningful pauses and campaign evidence take precedence. Convert interactions into deterministic frame-time states if implementing for video. No runtime tests performed.

## RF-NullMotion — reference-breakdown app
Pinned commit: ee25af6244fe911588f3fdb27b13c47fefc1a7ed.
Source: https://github.com/blixvip/NullMotion/tree/ee25af6244fe911588f3fdb27b13c47fefc1a7ed
Directly read: README, package.json and MIT LICENSE; recursive tree checked, no SKILL.md found.
Local README: ../08_external_references/blixvip__NullMotion/files/README.md
Trigger: study or pitch rough motion sections beside an authorized finished reference. This is not the separate hosted Null Studio clipping/editor product.
Documented (not independently tested): Node >=22 server, browser preview, WebCodecs/requestVideoFrameCallback export in Chrome/Edge, FFmpeg/Python supporting import tasks. No package installed or app executed; implementation source not reviewed. The README's no-dropped-frames and frame-sync assurances are vendor claims, not this package's tests. MIT code license does not establish rights to shipped films, music or third-party sample assets. Do not package those examples for commercial reuse. Retrieved material here is documentation only; local README image links may point to unbundled upstream assets.

Counts: 62 repositories in combined inventory; original 20+26 direct-link lists unchanged. Only Lottie adds a newly verified skill path. NullMotion is a reference app, not an extra skill count.
