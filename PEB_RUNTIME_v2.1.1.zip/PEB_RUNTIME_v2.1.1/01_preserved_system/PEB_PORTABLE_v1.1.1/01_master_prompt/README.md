# PRO EDITOR BRAIN — File Manifest (current test version: v3.1.1-TEST, frozen 2026-10-26)

## Attach to a campaign run (the prompt itself)

| File | Role | When to attach |
|---|---|---|
| `PRO_EDITOR_BRAIN_v3.1_CORE.md` | **THE MASTER PROMPT** — self-sufficient for intake, editing, QC, delivery | Always, first |
| `PEB_v3.1_MODULE_GRAPHICS.md` | Motion-graphics design engine (taxonomy, choreography, archetypes, QC) | When the edit involves any graphic, title, annotation, comparison, or endboard |
| `PEB_v3.1_MODULE_MOTION_PIPELINES.md` | Keyframe animation, stabilization, background removal, layered compositing | When the edit needs those pipelines |
| `PEB_v3.1_APPENDIX_REFERENCE.md` | Campaign-profile schema, example profile, signal sidecar, rhythm tables, encode pattern, disclosure templates | At intake (profile compilation) and render/QC |

Simplest full test: attach all four + campaign brief + authorized source footage + brand assets (logo/fonts, if required). Minimum smoke test: CORE alone.

## Campaign pipeline files (scout side — not attached to the master prompt)

| File | Role | When to use |
|---|---|---|
| `CAMPAIGN_BRIEF_RexTrix.md` | **READY-TO-ATTACH brief** — verified master-intake edition (2026-10-27): amendment v2 applied (end-card ≥4.5 s + English-only mandatory, CTA wording closed), ATTACH NOTE for verbatim reads, open items Q1/Q2/Q5/Q6/Q7/Q9 with defaults | Attach to the master prompt INSTEAD of writing a new brief; logo PNG still needed from operator (§6 blocker) |
| `SCOUT_campaign_brief_prompt_v2.txt` | Updated scout prompt (supersedes v1) — adds defaults-floor, AMENDMENT REQUIRED block, ATTACH NOTE rule, explicit MISSING fallbacks, pre-flight self-check | Paste into the scout AI for every future campaign |
| `SCOUT_CORRECTION_NOTES.md` | The six corrections from the first real brief run (CR-1..CR-6) + self-check, addressed to the brief-writing AI | Attach alongside the v2 prompt, or with v1 if v2 is unavailable (notes win on conflict) |

## You supply per campaign (not in this folder)

- The current campaign brief (links/requirements). For RexTrix, use `CAMPAIGN_BRIEF_RexTrix.md` above. Note: the RexTrix example profile in the appendix is INACTIVE by design — the prompt compiles the active profile from YOUR brief and marks each value confirmed / amended / unconfirmed.
- Clean, authorized source material (originals, not prior renders).
- Owner answers for any "mandate" that must be enforced as mandatory.

## Internal QA / audit trail — do NOT attach to a campaign run

- `v31_regression_audit.py` — document-level regression audit (102 checks). Run after any edit to the four prompt files.
- `V3.1.1_TEST_CORRECTIONS.md` — the five corrections applied at freeze, with exact before/after passages and the audit's stated scope.
- `PEB_v3.1.1_PAPER_TESTS.md` — FRT paper traces (3/3 PASS at document level).
- `PEB_v3.1.1_PILOT_PLANS.md` — three pilot plans; no render until operator approval.
- Older versions kept for history: `PRO_EDITOR_BRAIN_v2_consolidated.md`, `PRO_EDITOR_BRAIN_v2.1_video_patches.md`, `PRO_EDITOR_BRAIN_v3.md`, `PRO_EDITOR_BRAIN_v3_appendix.md`, `V3_EXTERNAL_REVIEW_verdict_and_actions.md`, `V3_integration_map.md`, `V3_REVIEW_user_prompt_vs_goals.md`, `V3_improvement_roadmap.md`, `REXTRIX_10clip_review.md`, `REXTRIX_campaign_input.md`, `PRO_EDITOR_BRAIN_v2_patches.md`, `CONSULT_*.txt`.

## Evidence ladder (what "ready" means)

Document checks (102/102) → paper tests (3/3) → pilot review (you watch and listen to the exact delivered files) → audience evidence. The audit count is not production approval.
