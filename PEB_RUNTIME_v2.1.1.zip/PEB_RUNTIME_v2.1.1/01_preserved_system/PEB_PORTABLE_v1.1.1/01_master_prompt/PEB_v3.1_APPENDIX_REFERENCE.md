PEB v3.1.1-TEST — APPENDIX REFERENCE (load on demand)
Reference material for PRO_EDITOR_BRAIN_v3.1_CORE.md. Load only the section you need; nothing here
overrides the core's precedence. Rule IDs match the core and modules. Graphic taxonomy, choreography
tables, and the archetype library live in PEB_v3.1_MODULE_GRAPHICS.md (§G1/G3/G6).

A. CAMPAIGN PROFILE CONTRACT (schema for CORE §3) — FIXED: owner mandates are per-campaign data
=====================================================================
schema_version: creative-profile/1.1
campaign: {objective, audience, viewer_value, primary_mechanics: [], optional_mechanics: [],
  optimization_mode: mechanics_not_outcome_prediction}
delivery: {resolution: [1080,1920], runtime_seconds: {min, max}, language_rule,
  output_fps, source_manifest_ref}
owner_mandates: [ FREE-FORM LIST SUPPLIED BY THE OWNER PER CAMPAIGN — never schema defaults.
  Each entry: {mandate, class: mandatory|preference, source: brief/owner,
  source_ref: exact brief section, or "unconfirmed"} ]
  # mandatory = satisfy or obtain an authorized amendment; otherwise block the affected delivery.
  # preference = attempt-first, deviate with a logged reason. A logged deviation never authorizes
  # breaking a mandatory entry (CORE §4). A mandate without a current source_ref stays unconfirmed
  # and is never treated as mandatory.
hook_policy: {evaluation_window_seconds: 3, channels_used_scoring: true,
  silence_open: {allowed: true, meaningful_audio_entry_by_seconds: 0.6}, text_max_words_default: 8}
  # No universal channel list and no universal score floor: if the owner mandates channel/score
  # requirements, they appear in owner_mandates above with their class (mandatory|preference) and
  # are executed per CORE §4/§8.
teaser_policy: {structure_menu: [peak_preview, chronological_context_first, result_first_process,
  uninterrupted_scene, mystery_question],  # selection from evidence; no structure is universal (CORE §6.2)
  preview_seconds_reference: [0.4, 1.25], payoff_complete_fraction_reference: [0.70, 0.85],
  payoff_hold_reference_seconds: 1.0}  # references = Tier 3 diagnostics for the peak-preview structure
compliance_gates: {registry_ref, required_gate_refs: [claims_verification, banned_claim, honesty,
  rights_and_source_eligibility, campaign_and_platform], on_unresolved_hard_conflict: block_and_report}
language_gate: {rule, burned_in_text_included: true, instrumental_path: report_not_verified}
end_card: {required: bool, definition, minimum_hold_seconds, measurement: encoded_file,
  margin_seconds, margin_rationale}  # floor + margin are profile values with recorded rationale (CORE §12)
mandatory_inclusions: []   # from the brief
banned_claims: []          # from the brief (classes + examples)
post_publish_operator_steps: []   # e.g., URL submission window, 24h analytics capture, audience checks
cta_rules: {max_requests_per_clip: 1, allowed_actions, approved_destinations_ref,
  placement: after_primary_payoff, prohibit_withholding_promised_answer: true}
taste_anchors: {rubric_ref: taste/1.0, minimum_score_note: "Tier 3 diagnostic — uncalibrated prior
  until validated via CORE §16.2; never a release gate by itself",
  weights: {story_clarity: 25, source_fit: 20, restraint: 15, rhythm: 15, readability: 15, brand_fit: 10}}
brand: {approved_tokens_ref, hard_requirements, flexible_dimensions, prohibited_associations}
banned_patterns: [{id, match, severity: hard|review|preference, reason, fallback}]
variety_budget: {axis_caps: {hook_family: 0.25, opening_beat: 0.25, pacing_curve: 0.30,
  graphic_archetype: 0.35, ending_treatment: 0.30, audio_strategy: 0.35},
  exact_signature_cap: 0.10, normalized_entropy_reference: 0.70,   # Tier 3 diagnostic
  allocation: {established_methods: 0.70, adjacent_variations: 0.20, new_method_candidates: 0.10}}
platform_targets: [{platform, placement, safe_area_ref, audio_delivery_ref, caption_delivery,
  analytics_mapping_ref}]
Every field carries enforcement: hard | floor | default | diagnostic. Missing facts stay missing.

A.1 REXTRIX PROFILE INSTANCE (worked example — INACTIVE until reconciled with the supplied brief)
---------------------------------------------------------------------
Status: EXAMPLE DATA, NOT AN ACTIVE PROFILE. The values below (4.0 s end-card floor, 0.5 s margin,
logo-plus-action-wording definition, audience requirement, attributed owner mandates) are NOT
authoritative merely because they appear here — past exchanges have produced conflicting
interpretations of some CTA requirements. Activation rule: at intake, reconcile every value against
the SUPPLIED brief (CORE §3 requirement matrix) and mark it confirmed / amended / unconfirmed with a
current source reference; any attributed "owner mandate" without a current source reference stays
UNCONFIRMED and is never treated as mandatory. Never copy this instance into an active campaign
without that reconciliation.

owner_mandates (attributed to the RexTrix owner — UNCONFIRMED until source-verified):
  - mechanics_led_every_clip
  - strong_visual_audio_text_hook  (three channels evaluated attempt-first; wordless openings legal
    when the source supplies the hook — deviation logged)
  - strongest_supported_moment_selection
  - real_peak_first  (attempt-first; §6.2 menu equally available on evidence)
  - continuous_method_discovery
language_gate: {rule: "English only (spoken + burned-in)", instrumental_path: report_not_verified}
end_card: {required: true,
  definition: "actual RexTrix logo graphic AND wording instructing the required viewer action
    (e.g., 'Download the RexTrix app — link in bio'); brand-name-only wording does not satisfy",
  minimum_hold_seconds: 4.0, measurement: encoded_file,
  margin_seconds: 0.5, margin_rationale: "Clip 16 measured exactly 4.0 s against the 4 s rule —
    zero tolerance against platform trims/preview cropping; margin is recorded production policy,
    never a substitute for exact measurement (both recorded)"}
mandatory_inclusions: [logo end card, CTA wording, caption mention, bio-link note in description draft]
banned_claims: ["free", "unlimited", "earn" classes per campaign input R-01..R-04 ledger]
post_publish_operator_steps: [submit post URL within required window, record + send 24h analytics,
  verify posting-account audience requirement (40% US)]
delivery: {language_rule: "English", output_fps: 30, runtime_seconds: {min: 15, max: 40}}

B. SIGNAL SIDECAR + EXTRACTION PARAMETERS (CORE §7.1 full stack)
=====================================================================
Sidecar: {clip_id, fps, frame_count, cpu_ms, degraded: [],
 words: [{id, text, start_frame, end_frame, logprob, uncertainty_frames, snap_ms}],
 vad: [{start_frame, end_frame, speech_prob}],
 breaths: [{start_frame, end_frame, confidence, followed_by_word_id}],
 music: {bpm, beat_confidence, downbeat_confidence, beat_frames[], downbeat_frames[], asset_time_offset_ms},
 envelopes: {hop_frames, speech_env[], music_env[], rms_norm[], overlap, separation_quality},
 motion: [{frame, mean, p95}],
 shots: [{id, in_frame, out_frame, boundary_conf, scale, face_height_ratio, gaze, complexity, text_density}],
 silence: [{class, start_frame, end_frame, db}]}
Signals below their gate are logged and ignored (anchor contract CORE §7.1). Never invent a
frame-accurate edge from a low-confidence timestamp.
Extraction parameters: words/VAD — faster-whisper small int8 (base fallback), word_timestamps=True,
condition_on_previous_text=False, 16 kHz mono WAV; RMS-onset snap 60 ms lookback. Breath — 2–5 kHz
band RMS vs full-band in VAD gaps; 3–10 f length; next word ≤12 f. Beat/downbeat — librosa
beat_track + onset strength on the music asset (or no-vocals stem); fold BPM 70–160; 4-phase
low-band-energy downbeat heuristic (madmom optional, verify availability). Dialogue/music — mid/side
+ HPSS + VAD mask; Demucs two-stem only when overlap flagged AND >40 s budget remains, else
separation_quality="low" (no ducking from proxy curves). Motion — 360×640 @8 fps grayscale proxy,
absdiff mean + p95; Farneback flow only within ±4 proxy frames of an ambiguous candidate cut.
Shots/faces — PySceneDetect ContentDetector (start threshold 27, calibrate) cross-checked with FFmpeg
scene scores; faces via verified detector on ≤5 fps proxy samples; scale by face-height ratio
(advisory). Complexity — Canny edge ratio + luma entropy; text proxy via morphological line density;
OCR only when triggered. Budget [SIG-2]: ≤120 s CPU per 20 s clip on one core; degrade in order
gaze → OCR → face sampling (0.5 s intervals); never drop words/VAD/silence; never fabricate a signal.

C. RHYTHM REFERENCE TABLES (CORE §7.2; UNCALIBRATED PRIORS — Tier 3 diagnostics)
=====================================================================
Shot lengths by energy (p10 / p50 / p90 seconds, hard min, hard max, shots per 15 s / 40 s):
- Low (luxury, testimony, quiet emotion): 1.0 / 2.2 / 4.0, min 0.70, max 6.0, 5–8 / 12–18
- Medium: 0.55 / 1.4 / 2.8, min 0.40, max 4.5, 8–12 / 18–28
- High (hype, action, music drive): 0.33 / 0.70 / 1.6, min 0.27, max 2.8, 12–18 / 28–45
CV bands: low 0.35–0.65, medium 0.40–0.75, high 0.45–0.85.
GUARD: all ASL/CV/autocorrelation statistics are computed only for pieces with ≥4 shots; below that
they are reported "n too small" and the piece is judged on meaning and word integrity (CORE §7.2).
High energy reference: ≤2 impact flashes of 4–6 f per spot; ≥1 shot ≥42 f per 8 s.
Shot-scale classes (advisory, by face_height/frame_height): ECU >0.40, CU 0.26–0.40, MCU 0.16–0.26,
MS 0.09–0.16, WS <0.09, no face → insert/wide.

D. FEEL SPEC SCHEMA (CORE §7.6) — written before the first cut; ≤16 KB; 3–12 beats
=====================================================================
{clip_id, fps, dur_ms, lead: dialogue|action|music|hybrid, energy_profile, pace_template,
 music: {asset, offset_ms, bpm, grid_conf, downbeat_conf, sections: [{t_ms, type}]},
 beats: [{id, role: hook|setup|escalation|turn|payoff|button, start_ms, end_ms, energy,
   pace_class: hold|slow|medium|fast|burst, asl_ms: [min, max],
   anchor: {type: downbeat|grid_beat|word_onset|phrase_end|breath|action_apex|motion_settle|
     reveal|free, ref, frame, tol_f},
   emphasis: [{kind: punch_step|punch_push|caption_hl|sfx|dip, frame, params}],   // ≤1 per beat
   hold: {planned, min_ms, max_ms, why: "<signal-cited rationale, non-null>"},
   audio: {lead, split: none|J|L, split_f, sfx_budget, silence_ms, duck_db},
   caption: {density, hl_words[]}, conf}],
 budgets: {max_sfx, max_punch, max_convergence: 3, min_breaths_kept_ratio: 0.4},
 qc_actuals: {asl_ms, cv, longest_over_asl, anchor_hit_rate, late_window_hits, midword_cuts,
   half_breaths, jl_ratio, sfx_per_cut, punch_motivated, emotion_r, peak_err_ms, range,
   tells: [], flags: []}}
Filled from the RENDERED timeline after export; both plan and qc_actuals stored.

E. FINAL ENCODE PATTERN + FRAME-TRUTH FIXTURE (CORE §13)
=====================================================================
Encode (canonical BT.709-OETF full-range RGB frames + exact-length PCM):
ffmpeg -framerate 30 -start_number 0 -i 'comp/%06d.png' -i mix.wav \
  -map 0:v:0 -map 1:a:0 \
  -vf "scale=w=iw:h=ih:in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p" \
  -c:v libx264 -preset medium -crf 18 -fps_mode:v passthrough \
  -color_primaries bt709 -color_trc bt709 -colorspace bt709 -color_range tv \
  -c:a aac -b:a 192k -ar 48000 -ac 2 -movflags +faststart final.mp4
(Working composite already carries the BT.709 encoding transfer per the CORE color contract; the
scale step here is matrix+range only. sRGB-tagged sources are converted on ingest, never relabeled.)
Frame-truth fixture: 120 frames with large visible frame numbers + machine-readable B/W frame-ID
blocks (several redundant locations, including inside an opaque subject-shaped region); known
translation/rotation, a cut, duplicated frames, a retimed interval; oracle mattes with known moving
boundaries; a graphic on frames 37–60; a key authored at 1250 ms (expected frame 38 at 30 fps,
half-up); audio correlation markers at sample indices matching frames 37, 61, 100. Probe:
ffprobe -v error -select_streams v:0 -show_frames -show_entries frame=pts,best_effort_timestamp
-of json final.mp4 (read the stream time base separately; judge PTS, not packet order — B-frames
reorder decode). Acceptance: count exactly 120; PTS×tb = n/30 ∀n; source selection matches the map;
overlay on 37–60 only; matte/RGB registration zero offset; pre-AAC markers ≤1 sample; final AAC ≤1 ms,
no accumulating drift; priming/tail padding measured and recorded.

F. CAPABILITY QC GATE TABLES (MODULE MOTION PIPELINES full reference)
=====================================================================
Keyframes: round-trip serialize/reload/independent-evaluate error ≤1e-6 (scalar), ≤0.01 px
(position/crop); fiducial rectangle corners/pivot recovered ≤0.5 px / 0.1° / 0.1%; endpoint behavior
exact (no accidental endpoint frame); overshoot evaluated on ALL frames + audio samples against
bounds_policy; visibility intervals zero off-by-one on decoded fixtures; baked PCM vs independent
gain/pan computation ≤1e-6 (reference float), sample count exact.
Stabilization: ≥30 background tracks spanning ≥6 of 9 grid cells, ≥70% inliers (else not_checked);
residual HF RMS ≤2 px tripod / ≤4 px walking, ≥40% reduction when input >3 px; edge wobble p95 ≤3 px,
≤0.5 px worse than input; row-binned jello RMSE ≤2.5 px, increase ≤0.5 px; crop ≤8% pass / 8–12% warn
/ >12% fail (per-edge ≤4%; walking may reach 20%/6% only with approval); validity plate zero invalid
pixels +2 px margin; drift p95 ≤2% per dimension, peak ≤4%; subject bbox inside [6%,94%]×[8%,88%];
critical composition never clipped.
Segmentation: alpha numeric (exact dims/count, finite 0–1, no gamma on masks); temporal boundary
flicker p95 ≤0.08, max ≤0.15 (5 px bands around current + warped-previous 0.5 contours); interior
instability mean ≤0.01 (8 px eroded); matte breathing p95 ≤3%, no unexplained single-frame jump >10%;
halo ≤2 px over >10% of contour; coverage ≥60% of boundary with valid correspondence else
not_checked; reference masks (if annotated) opaque IoU ≥0.97, boundary F1 ≥0.90 at 3 px.
Compositing: alpha oracle within ±2 code values (±1 reference path); transparent-RGB hygiene (RGB=0
where α=0); original reconstruction ≤2/255/channel; depth-order proof (subject wins α≥0.98, graphic
visible α≤0.02, error ≤2/255); contact-shadow attachment ≤5 px / direction ≤15°; reflection none
above plane; grade match median ΔE00 ≤3, p95 ≤6 — never from arbitrary averages. Evidence for every
pass; not_checked when measurement did not occur; never relax thresholds automatically — record
calibrated exceptions and their approval.

F.1 STABILIZATION PARAMETER TABLE + COMMANDS
---------------------------------------------------------------------
Shot class | Detect (shakiness/accuracy/stepsize) | Transform smoothing | maxshift | maxangle | zoom
Tripod micro-jitter | 3 / 12 / 6 | 15–30 | 12 | 0.005 (~0.29°) | 0–2%
Walking / handheld | 7 / 12 / 6 | 10–20 | 48 | 0.025 (~1.43°) | 2–6%
Whip-pan | skip by default (approved experiment: detect 4/12/4) | 2–4 | 12 | 0.005 | 0–2%
Strong parallax | skip or very mild (5/15/6) | 3–6 | 16 | 0.008 | 0–3%
ffmpeg -i shot.mkv -map 0:v:0 -an -vf "vidstabdetect=shakiness=7:accuracy=12:stepsize=6:\
result=shot.trf" -f null -
ffmpeg -i shot.mkv -map 0:v:0 -an -vf "vidstabtransform=input=shot.trf:smoothing=12:\
maxshift=48:maxangle=0.025:optzoom=0:zoom=4:crop=black:interpol=bicubic" -c:v ffv1 \
-level 3 -g 1 stabilized.mkv
Scale pixel-valued limits with the stabilization input dimensions. Validity plate: re-run
vidstabtransform on an all-white plate with the SAME saved transforms/params — black or interpolated
boundaries reveal invalid support. Area loss from zoom z: 1 − 1/(1+z/100)².
Deshake fallback (verify options locally): deshake=rx=16:ry=16:edge=blank. Crop-and-track fallback:
fixed-size crop following a σ≈8-frame smoothed trajectory; export crop matrices.

G. FAILURE DISCLOSURE TEMPLATES (CORE §17) — replace bracketed fields with measured facts
=====================================================================
Keyframes — best: "Keyframes: rendered from the approved animation specification; numerical,
visual-timing, and audio-automation checks passed."
Keyframes — acceptable: "Keyframes: [feature] was replaced with [replacement] because [reason].
Timing checks passed. Plan change approved under [approval ID]."
Keyframes — minimal: "Keyframes: continuous animation reduced to [static poses/cuts/fades]. The
requested motion is not present. Plan change approved under [approval ID]."
Keyframes — skip: "Keyframes: not applied because [reason]. Requested animated elements were
[removed/replaced]. [Approval statement or delivery blocked]."
Stabilization — best: "Stabilization: applied with [engine]; incremental crop loss [value]%. Motion,
border, and composition checks passed."
Stabilization — acceptable: "Stabilization: limited [deshake/translation tracking] used. Rotation,
parallax, and rolling-shutter correction are not claimed. Plan change approved under [approval ID]."
Stabilization — minimal: "Stabilization: no motion correction; fixed reframe only. Handheld movement
remains. Plan change approved under [approval ID]."
Stabilization — skip: "Stabilization: skipped because [reason]. Shot [retained as handheld/replaced].
[Approval statement or delivery blocked]."
Background removal — best: "Background removal: applied with [model/export]; sampled edge and
temporal-consistency checks passed."
Background removal — acceptable: "Background removal: [reduced-resolution/propagated] mattes rather
than the requested method. Edge and temporal checks passed. Plan change approved under [approval ID]."
Background removal — minimal: "Background removal: limited to [still/freeze-frame range]. Continuous
moving-subject extraction is not present. Plan change approved under [approval ID]."
Background removal — skip: "Background removal: not applied because [reason]. Original background
retained; behind-subject effects [removed/replanned]. [Approval statement or delivery blocked]."
Compositing — best: "Compositing: graphics occluded by verified subject mattes; depth-order and
applicable grounding/color checks passed."
Compositing — acceptable: "Compositing: [shadow/reflection/lighting/depth feature] omitted or
simplified because [reason]. Plan change approved under [approval ID]."
Compositing — minimal: "Compositing: graphics moved to [placement]; they are not behind the subject.
Plan change approved under [approval ID]."
Compositing — skip: "Compositing: requested layered effect not applied because [reason].
[Replacement treatment]. [Approval statement or delivery blocked]."

H. GRAPHIC MOMENT-CLASS TAXONOMY + CHOREOGRAPHY + ARCHETYPES
=====================================================================
Moved into PEB_v3.1_MODULE_GRAPHICS.md (self-contained by design): class table with ideal durations
and placements (§G1), element timing table (§G3), archetype library A01–A12 with instance contract
and fallbacks (§G6). Load that module for any graphics task.
