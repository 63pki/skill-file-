PEB v3.1.1-TEST — MODULE: ANIMATION KEYFRAMES, STABILIZATION, BACKGROUND REMOVAL, LAYERED COMPOSITING
[Attach when animating transforms, stabilizing, removing backgrounds, or compositing layered /
behind-subject effects. Tiers follow CORE §4. Time contracts: CORE §13.]

M1. ANIMATION KEYFRAME ENGINE [KF-1..8]

One authoritative evaluator. FFmpeg expressions are an optimization target for a validated subset —
never a second interpretation of the animation specification [KF-1].

Layer schema (full JSON contract: appendix §H): layers carry id, kind, asset, [start,end) frame
interval, pivot, and tracks — position, scale, rotation, opacity, crop, volume, pan. Keyframes are
{time (frame or ms), value, interpolation}; interpolation ∈ {linear; cubic_bezier(x1,y1,x2,y2);
smoothstep(3|5|7); damped_spring(mass, stiffness, damping, initial_velocity)} with the spring solved
analytically. The ease on a key applies to the interval ENDING at the next key; before the first and
after the last key, hold the endpoint value; visibility intervals are [start, end).

TIME DOMAINS [KF-3, T2-fix — one contract, no forks]: VISUAL keys are normalized to integer output
frames BEFORE evaluation (half-up: frame = floor(t_ms × F/1000 + 0.5)); duplicate key times after
rounding are validation errors; a snap distance >0.25 frame is a logged warning. AUDIO keys (volume,
pan) resolve to SAMPLE indices per the CORE §13 audio time contract: sample_index = round(t_s × 48000)
on the single 48 kHz output epoch, computed cumulatively — never per-frame multiplication except when
48000/F is an integer (1600/frame at 30 fps). The frame grid and the sample grid meet only at
declared sync events verified on decoded output. Evaluate visuals at integer frames with exact
rational progress u; preserve fractional positions until rasterization; sample output pixels at their
centers. Rotation is unwrapped (350→370, not 350→10). Transform order: source crop → translate
cropped pivot to origin → scale → rotate → translate to output position → opacity → composite [KF-4].
bounds_policy (error|clamp) evaluated on every rendered frame and audio sample, including overshoot;
deliberate offscreen entry/exit per the approved plan is not a bounds failure. Springs are endpoint-
normalized [KF-5]; an unsettled spring at segment end is a logged warning plus a snap at the next key
— never a silent jump.

GAIN DOMAIN [KF-6, T3-fix — one domain]: volume automation is stored and interpolated as LINEAR
gain (matches sample-multiplication rendering and equal-power pan math; project ceiling 4.0 unless
approved). Human-authored dB values are converted on ingest (linear = 10^(dB/20)) and may be reported
in dB, but the automation domain, storage, and interpolation are linear throughout — the CORE/appendix
pair must never disagree again. Equal-power pan for mono (θ=(pan+1)·π/4); stereo balance preserves
both channels. ≥5 ms authored ramps wherever an edit would create a discontinuity. Evaluate audio
automation at sample times, sample-accurate in Python (envelope × signal); frame-quantized automation
paths (sendcmd-driven volume) are never the primary; do not invent `volume=eval=sample`. Render the
automated mix to float PCM with an exact sample count (CORE §13 total-sample contract).

Render paths [KF-7..8]: primary = Python evaluator → rasterized/staged assets → compositor → FFmpeg
encode; validated FFmpeg expression subset (translation, opacity) allowed with disclosure; baked PNG
sequences only for genuinely changing geometry. Never use zoompan for production transforms (its
counters/duration behavior are not the frame contract; alpha not guaranteed). On any FFmpeg overlay
used for graphics, force the RGB format family and explicit alpha= [KF-8] — never let overlay default
to yuv420 chroma blending. Prefer -filter_complex_script over enormous inline graphs (verify support).

M2. STABILIZATION [STAB-1..6]

Decision tree: (1) Is the movement intentional? Whip-pan transitions, action POV, documentary
urgency, deliberate handheld → retain by default. Product detail, architecture, talking heads,
readable demonstrations → stabilization often helps. (2) Is the defect mostly global camera motion?
Translation/rotation with coherent background → candidate; rolling-shutter skew, severe parallax,
moving foreground dominance → global stabilization may worsen it. (3) Crop/composition margin around
faces, hands, product, text? No margin → milder correction or none. (4) Measurable? Insufficient
texture or background tracks → mark gates not_checked; do not claim success.

Probe at runtime (ffmpeg -filters; -h filter=vidstabdetect/vidstabtransform) [STAB-2]: absent → do
not claim stabilization. Never stabilize across a cut; never detect on non-identical frame sequences.
Skip when already stable (high-frequency residual RMS <1.5 px). Never stabilize jello/rolling-shutter
(RS index >2 px) or whip pans by default. Stabilize continuous shots BEFORE nonlinear retiming;
detection and transform must receive identical frame counts, order, geometry, and preprocessing.

Parameters (conservative defaults; full table + commands: appendix §I): tripod/micro-jitter —
shakiness 3, accuracy 12, stepsize 6, smoothing 15–30, maxshift 12, maxangle 0.005, explicit zoom
0–2%; walking/handheld — shakiness 7, accuracy 12, stepsize 6, smoothing 10–20, maxshift 48, maxangle
0.025, zoom 2–6%. Prefer optzoom=0 + an explicit tested zoom + crop=black so the crop cost is
auditable [STAB-3]; optzoom=2 (adaptive) is rejected as a default (visible breathing); never use
crop=keep to pass QC (it can smear previous-frame content over invalid borders). Measure exposed
borders with the validity-plate method (same transforms, white plate) [STAB-4] — black regions reveal
invalid support.

Gates [STAB-5, T2 technical]: residual HF RMS ≤2 px (tripod) / ≤4 px (walking) AND ≥40% reduction
when input >3 px; edge wobble p95 ≤3 px and ≤0.5 px worse than input; rolling-shutter row residual
RMSE ≤2.5 px, increase ≤0.5 px; crop loss ≤8% area pass / 8–12% warn / >12% fail (per-edge ≤4%);
zero exposed invalid pixels +2 px margin; subject drift p95 ≤2% of each dimension, peak ≤4%; never
push a detected face/subject bbox outside [6%,94%]×[8%,88%]; critical composition (face/hands/product
safe polygon) never clipped.

Fallback ladder [STAB-6, T0 disclosure]: (1) verified two-pass vidstab with measured crop/artifact
QC; (2) deshake for modest global shake (translation-only — disclosed, does not satisfy a
"stabilized" brief alone); (3) Python crop-and-track: fixed-size crop following a smoothed
trajectory, crop matrices exported for QC; (4) retain handheld motion or substitute an approved shot,
disclosed. One retry per rung with documented secondary parameters, then step down. Reject exposed
borders, increased wobble, or unsafe composition even when average shake improves.

M3. BACKGROUND REMOVAL [BG-1..8]

Model families and reality: rembg U²-Net (simple subjects, ~320 px input), IS-Net (higher detail,
heavier), SAM-class (prompted selection of one-of-several; a binary object mask is not optical alpha;
video propagation requires a complete tested adapter), BiRefNet-class (high-detail stills; CPU-heavy),
RVM-class (temporally coherent human foreground). Do not promise removal based on a package name —
the operative question is whether THIS checkpoint, export, provider, and adapter work here.

Model manifest + proof before any cutout promise [BG-1, T0]: exact model/export/adapter + weights
hash; runtime and providers (get_providers() lists configured providers, not what actually ran);
input/output contract; smoke test on ≥16 consecutive real frames including difficult edges (p50/p95
ms, peak RSS, finite outputs, polarity, state reset); mattes rendered over black/white/checkerboard;
a longer consecutive window benchmarked before accepting the budget. Record the license: GPL-3.0
models (RVM-class) are blocked for client campaign work (allowed_in_plan=false) unless the operator
approves the license implication in writing [BG-2].

Per-shot selection [BG-3]: continuous human motion → recurrent model, sequential order, reset state
at cuts and discontinuous time maps; static product/stationary subject → per-frame model (static
matte only if measured motion is negligible); several people, one subject → detector + association +
prompted selection with re-prompt when motion-compensated mask IoU <0.80 or area changes >15% without
supporting motion; hero still → high-detail model + edge review. Default geometry: stabilize first,
build the final retimed CFR shot, then segment those canonical frames (never retime RGB and alpha
independently [T0]); matte reuse is legal only with identical temporal selection and spatial warps.

Refusals [BG-4]: motion blur that becomes a hard silhouette, genuine transparency (glass, veils,
smoke), fur/hair on cluttered backgrounds, edge-hugging subjects, tiny subjects — record the refusal
reason; every cutout shot ships with a pre-approved no-cutout layout fallback in the plan.

Temporal consistency [BG-5]: prefer the model's own temporal mechanism; otherwise motion-compensated
filtering (λ 0.15–0.35) only where motion confidence ≥0.8 and forward/backward consistency ≤2 px,
with no cut/occlusion/track switch; static-pixel median/EMA only where |ΔY| <8/255. Never average
unaligned masks (trailing silhouettes that score "stable" while visibly wrong).

Refinement [BG-6..7]: ONE refine pass — erode 0.5–2 px + feather σ≈1.5–3; guided filter only if
verified; alpha matting/trimap only with a verified solver; edge-color decontamination from predicted
foreground or reliable old background only. Keep alpha soft (float/gray16) through the chain; never
binarize for delivery. A second QC fail skips the cutout entirely.

Gates [BG-8, T2]: temporal boundary flicker p95 ≤0.08 (max ≤0.15); interior instability mean ≤0.01
(eroded 8 px); matte breathing p95 ≤3%; halo/fringe ≤2 px over >10% of reviewed contour; zero
critical anatomy deletions; no unexplained holes ≥8 px; measurement coverage ≥60% of boundary (else
not_checked). Motion-compensated metrics are proxies — a consistently wrong mask can pass; hair,
transparency, and motion-blur boundaries require sampled visual review (≥12 frames/shot, ≥ every
0.5 s, first/last, cuts, worst-metric frames; full-resolution crops of hair, hands, shoulders). Do
not ship a cutout when critical identity/anatomy is damaged or background-colored fringes are
conspicuous [T0] — the safe fallback is the original background with a different graphic treatment.

M4. LAYERED COMPOSITING [COMP-1..5]

Depth contract: explicit stable z-order — plate → behind-graphic (z≈10, behind:[subject]) → optional
shadow/reflection → subject layer (z≈20, matte) → foreground graphics/captions (z≈100). No ambiguous
z ties; graphics go behind a subject ONLY with a QC-passed matte [T0]; captions composite AFTER the
subject and are never hidden by it.

Original-background identity [COMP-2, T0]: B = over(behind_graphic, original_frame); C =
over(subject, B) — removing the graphic must reconstruct the original within quantization. Never move
the cutout off its original plate position while the person remains in the plate (duplicate/ghost
subject); repositioning requires a verified clean plate or removal capability, which is not assumed.

Grounding [COMP-3, T2 defaults]: contact shadow only when a visible ground/contact plane exists
(lower ~28% of the subject bbox, blur 2–6 px, opacity 0.10–0.35, attached to a tracked contact point);
cast shadows and reflections default OFF (stylized approximations, never inferred physical lighting;
reflection only on an established reflective surface, alpha 0.08–0.18 fading over 80–240 px); light
wrap default OFF (1–3 px inward edge band, strength 0.02–0.10, only when justified — never grow the
silhouette); edge matching corrects identifiable old-background spill using the model's foreground
RGB; grade matching moves the synthetic graphic toward the footage, clamped (≤±6 L*), protecting skin
— never the reverse, and never onto graphic backgrounds; if the original background and contact
shadow remain, preserve them (adding a second shadow usually un-grounds the subject).

Architecture [COMP-4, T2]: staged immutable intermediates, never one mega filter_complex — canonical
frames/lossless video; one-channel alpha sequences; static sprite caches; per-frame animation tables;
optional graphics-only RGBA; final opaque frames streamed to the encoder. Segmentation can be rerun
without rerendering captions; every mask, transform, and depth relationship is inspectable; failed
stages resume independently. Bounded 2–4 frame working queues (a 1080×1920 float32 RGBA frame ≈33 MB;
never hold a full clip in RAM); stream frames; peak RAM <4 GB; mezzanine FFV1 or x264-qp0 (never raw
RGBA sequences; ProRes only for disposable scratch, labeled). Extrapolate ETA from the first 2–4
processed frames: if the projected wall clock exceeds the budget (default 10 min/clip), degrade the
plan BEFORE the full render. One heavy stage at a time; recurrent matte models stay sequential even
when cores are idle.

Caches [COMP-5]: key by content hash + canonical params + tool/model hashes — never filename or
mtime; recurrent matte keys must include temporal history; cache-write = temp → verify count/dims/
hashes → manifest+QC → atomic rename; a failed-QC entry is a miss; never promote a partial artifact.

M5. CAPABILITY QC (when this module is loaded; full tables: appendix §K)

Keyframes [T2]: serialization round-trip error ≤1e-6 (scalar), ≤0.01 px (position/crop); fiducial
rectangle corners/pivot recovered ≤0.5 px / 0.1° / 0.1%; endpoint behavior exact; overshoot evaluated
on ALL frames + audio samples against bounds_policy; visibility intervals zero off-by-one on decoded
fixtures; baked PCM vs independent gain/pan computation ≤1e-6 (reference float), sample count exact.
Segmentation [T2]: alpha numeric (exact dims/count, finite 0–1, no gamma on masks); reference masks
(if annotated) opaque IoU ≥0.97, boundary F1 ≥0.90 at 3 px. Compositing [T0/T2]: alpha oracle within
±2 code values (50% red over black ≈ (128,0,0); over white ≈ (255,128,128)); transparent-RGB hygiene
(RGB=0 where α=0); original reconstruction ≤2/255/channel; depth-order proof on sampled frames
(subject wins where α≥0.98, graphic visible where α≤0.02, error ≤2/255); contact-shadow attachment
≤5 px. Every capability gate reports pass / pass_with_warning / fail / not_checked with the measured
value and method — not_checked always carries a reason and is never a pass; never relax thresholds
automatically — record calibrated exceptions and their approval.
