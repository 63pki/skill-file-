PEB v3.1.1-TEST — MODULE: MOTION GRAPHICS DESIGN ENGINE
[Attach when designing or QC-ing any graphic, title, annotation, comparison, or endboard
composition. Tiers follow CORE §4: [T0] laws, [T1] profile, [T2] defaults, [T3] diagnostics.]

The engine sits above the recipes, layout mathematics, timing system, and QC gates:
evidence → communication job → composition graph → layout candidates → campaign allocation → render.
A graphic is not the default output — "leave the footage alone" is a selectable, valid result [MG-1].

G1. MOMENT CLASSES AND EVIDENCE [MG-2..8]

Classify the communication job BEFORE choosing an archetype or animation; a class is not a visual
treatment (STAT can compile to an annotation, a calibrated ruler, or plain type). Classes (durations
include entrance+exit; taxonomy table below): HOOK title, CONTEXT setter, STAT quantitative claim,
STEP process/sequence, EMPHASIS semantic emphasis, CALLOUT referent annotation, COMPARE comparison,
QUOTE attributed quotation, STAMP location/time, TRANSITION structural transition, IDENTITY
person/product ID, CTA action instruction. Count caps [T2]: ≤3 moments/15 s, ≤5/25 s, ≤7/40 s;
HOOK-class only inside 0–3 s; CTA only inside the end-card gate.

Class | Purpose | Ideal duration | Preferred placement
HOOK hook title | establish the clip's question/tension/promised subject | 1.2–2.8 s | U/M field, opposite subject
CONTEXT context setter | explain what viewers are seeing before details arrive | 1.8–4.0 s | U, L, or side rail
STAT quantitative claim | make a sourced quantity/unit/result legible | 2.0–4.5 s | stable U/M near referent
STEP process/sequence | explain order, dependency, current operation | 1.2–2.8 s/step; 2.5–5.5 s diagram | side rail or U, away from hands
EMPHASIS semantic emphasis | direct attention to one supported word/phrase | 0.7–1.6 s | attached to caption/title geometry
CALLOUT referent annotation | identify a specific object/feature/component | 1.2–3.2 s | target-relative, label in nearby free space
COMPARE comparison | expose an actual difference between equivalents | 2.8–5.5 s | two aligned zones or one matrix
QUOTE attributed quotation | preserve a distinctive statement + speaker | 2.4–5.0 s | opposite speaker; U/L if face allows
STAMP location/time | establish where/when | 1.2–2.6 s | available corner or short rail
TRANSITION structural | explain a genuine chapter/state change | 0.2–0.6 s seam (+ reading time for any title) | along a verified cut boundary
IDENTITY person/product ID | resolve who / which version | 1.6–3.2 s | rail beside subject, not centered
CTA action instruction | one approved next action | 2.0–4.0 s (end-card gates govern) | endboard or action rail
Placement fields (U x72–1008 y144–560; M y560–1280; L y1280–1760; rails x72–360 / 720–1008) are
SEARCH REGIONS — intersect with live safe masks, caption reservations, subject protection.
High-risk classes (STAT/COMPARE/QUOTE/STAMP/IDENTITY) need p ≥0.98–0.995 or verified sources.

Evidence ledger [T0]: every displayed factual token (numbers, names, dates, quotations, annotations)
resolves to an evidence record {kind: transcript_span | visible_text | verified_metadata |
approved_campaign_instruction | tracked_object; source span/hash; critical tokens; verification
status; confidence}. Confidence is calibrated or human-verified — never an LLM's self-reported score;
unavailable confidence is unknown, not 0.99 [MG-4].

Precision routing [MG-5, re-tiered 3.7-fix]: high-risk classes (STAT, COMPARE, QUOTE, STAMP,
IDENTITY) require p ≥0.98–0.995 on critical tokens or verified sources. Until class precision is
validated on held-out material, an UNRESOLVED high-risk token routes to: (i) a simpler treatment that
omits that token, or (ii) a REVIEW draft. Both are legal deliverable states (CORE §17); a
render-queue entry requires resolved evidence. Unknown or ambiguous candidates never enter the render
queue as-is [MG-6].

Binary blockers override any score and mean OMIT, never render-with-disclaimer [MG-7, T0]: no source
ref; read-time impossible; caption text in the overlapping window ≥0.82 similar to the graphic
string; unsafe region; face/occupancy data missing for CENTER placements or callouts; derived claim;
place or time inferred from pixels (skyline, daylight, wardrobe — never); shot unknown. Never infer
place, time, price, or statistics from image content; do not convert spelled-out numbers to digits
without a unit-tested normalizer; veto a number claim preceded by an epistemic hedge ("about/maybe/
almost") unless the exact value is verified [MG-8].

Copy transformations [T0]: verbatim; or deletion of whole words from span ends only (never
paraphrase); quotes allow punctuation normalization only, ellipsis marks any omission that does not
change meaning; campaign instructions may authorize action/destination/identity/logo but never
silently become evidence for a product-performance claim.

G2. ALLOCATION AND COMPOSITION [MG-9..13]

Information gain: 3 connects word to target / exposes supported relationship / organizes ≥2 facts;
2 resolves who/what/where, makes a quantity usable; 1 repeats for attention (≤1 per 10 s, never a
duplicate full caption); 0 decoration → omit. Density [T2]: optional graphics active-time union ≤45%
of runtime (excluding mandatory endboards); ≤min(7, ⌊non-endboard seconds / 3⌋) primary moments; ≥12
graphic-free frames between unrelated primary moments; one primary graphic group at a time + at most
one supporting label; a graphic never appears >6 frames before its supporting utterance or visible
referent (except an approved opening excerpt).

Composition: build a small semantic graph per accepted moment (primary_message, supporting_fact,
referent, attribution, action; edges identifies/quantifies/precedes/contrasts_with/attributed_to) and
choose up to 3 compatible composition grammars (identify→leader annotation; quantify→metric label/
calibrated ruler; sequence→process rail; contrast→comparison matrix; attribute→quote bracket; orient→
premise rail; act→action endboard). Generate candidates (≤3 grammars × 3 persistent free regions ×
widths 4/6/8/12 cols × ≤2 alignments × ≤2 densities); eliminate illegal candidates with the existing
bounds/collision/safe-area/timing machinery — safety and evidence are hard constraints, not weights.
Rank survivors S = 0.45·(G/3) + 0.25·R + 0.20·F + 0.10·V (R = readability: min(x-height/12, 1) ×
min(contrast_p05/7, 1); F = 1 − saliency occlusion; V = novelty vs the last five primary moments);
novelty decides only between candidates within 0.05 excluding novelty [MG-12, T3].

Variety [MG-13, T3]: variation tuple {archetype, layout, alignment, entrance, density, accent usage,
width, sequence}. No complete tuple repeat within the preceding 4 clips (unless the only valid
option); primary archetype ≤35% of a rolling 12-clip window; ≥2 changed dimensions between adjacent
primary moments when communication and readability stay equivalent; never vary font family, brand
color, or easing merely to diversify; deterministic seed = hash(campaign_id + clip_id + moment_id);
record every waived repetition constraint. These quotas describe decisions and are reported, not
enforced by blocking.

G3. CHOREOGRAPHY [MG-14..18]

Element timing at 30 fps (choreography table below): entrances 3–12 f by element class; exits 2–8 f;
sibling stagger 2–5 f (≤3 siblings, travel ≤24 px); backplates lead text by 0–2 f and remain until all
supported text exits — never expose text for one frame without its contrast surface. Easing:
entrance/settle [0.22, 1, 0.36, 1]; exit/accelerate [0.40, 0, 1, 1]; neutral reposition [0.40, 0,
0.20, 1]. The renderer must solve Bx(u)=t then evaluate By(u) — never substitute time directly into
By. Overshoot [T2 + T6-fix]: default none; where the approved motion vocabulary permits it: scale
overshoot ≤1.03, settle ≤4 f, ≤1 focal event per clip, never on data position, measurements, or
tracking endpoints. (CORE §14 recipe A's 110% display-type entrance is the single documented
exception.)

Element class | Entrance | Exit | Stagger | Min readable hold
Hook/headline block | 6–10 f | 4–6 f | support +3–4 f | 30 f + reading math
Context/body block | 6–8 f | 4–6 f | label leads body +2–4 f | 42 f
Number + unit | 6–10 f | 4–6 f | unit ≤2 f after number | 45 f
Process nodes | 6–8 f/node | 4–6 f | 3–5 f (total ≤12 f) | 30 f per read step
Emphasis underline/bracket | 3–5 f | 2–4 f | none | 15 f
Leader callout | line 4–6 f, label 4–6 f | 3–4 f | label +2–4 f after line | 30 f
Comparison rows | 8–12 f/group | 4–6 f | 3–4 f/row | 60 f + reading math
Quote + attribution | 6–10 f | 4–6 f | attribution +3–4 f | 60 f + reading math
Location/time slug | 4–6 f | 3–4 f | ≤2 f | 30 f
Identity folio | 5–8 f | 3–4 f | role +2–3 f | 36 f
Transition geometry | 4–8 f/side | in seam | none | no text credit during seam
CTA/endboard | 8–12 f (system ≤16 f) | 0 at program end, else 4–6 f | 3–4 f | 60 f + decision time
Reading rates: label 3.5, headline 3.0, context/quote/identity/CTA 2.5, comparison/technical 2.0
words/s. Hold floors: kinetic/shutter 14 f; ≤4-word badge/slate/callout 30 f; stat/quote/versus 45 f.

Reading time (authoritative, from the formula) [T0 — comprehension protection]: H_required =
max(H_floor, ceil(30·(W/r + 0.25 + 0.35N + 0.35P + A))) where W = all words the viewer must read,
r ∈ {3.5 short label, 3.0 headline, 2.5 context/quote/identity/CTA, 2.0 comparison/technical} words/s,
N = distinct numbers, P = attention switches, A = 0.5 s for a decision CTA. A frame counts toward
reading only when opacity ≥0.95, text fully revealed, movement ≤1 px/frame, scale within 1% of
settled, contrast/collision checks pass. Alternative MODE_SYNC for speech-locked graphics: full
opacity ≥ max(12 f, the speech span), entrance done at speech start, exit starts 4 f after speech
end. If the copy cannot fit: shorten through a verified meaning-preserving deletion, extend the
window, simplify the composition, or omit — never accelerate the entrance or shrink below minimums.
Reveal final factual values; never animate through invented intermediate values; no count-ups except
from a verified source value with approved treatment.

Exit discipline [MG-16/17]: shot-specific graphics reach zero alpha by cut−2; carry across a cut only
with explicit carry_through, same semantic referent, valid placement both sides (≤1 cut); tracked
graphics reinitialize the target track at cuts (never extrapolate across); a quote never crosses to
another speaker; endboard holds the complete composition on the final frame (no accidental black
tail); transition geometry declares its cut-relative lifecycle (no orphan geometry). An entrance never
starts in [cut−12, cut−1]; an exit never completes in [cut+1, cut+12].

Sound [MG-18, T2]: anchor the main visual arrival/target contact/state change ±1 f; if alignment
uncertainty exceeds 2 f use a phrase-boundary fade instead of a sharp accent; ≤1 graphic SFX per 45
frames; the SFX id must exist in the campaign vocabulary, else silence; no SFX when a transcript word
overlaps [t−0.1, t+0.2] s; none on routine exits, labels, captions, identity folios.

G4. ASSET PIPELINE AND RENDERING [MG-19..21]

Routing: A = SVG→CairoSVG (geometry only, never text) → 2× alpha PNG → Lanczos down → FFmpeg overlay
(primary for designed typography, rules, logos, diagrams); B = FFmpeg drawtext/drawbox (plain labels,
debug, diagnostics; Latin-only without verified shaping); C = Python-rendered alpha PNG sequences
(complex synchronized transforms, masks, path reveals, tracked groups — cache static artwork and
animate it; per-frame rendering only for properties that genuinely change). A rendering plan may use
only capabilities confirmed in the startup manifest (ffmpeg -filters, -h filter=..., Pillow
FreeType/RAQM support, font files/hashes/licenses/glyph coverage).

Text shaping [MG-20, T0]: shape and measure the complete line with the same engine that renders it;
rasterize text with Pillow, never CairoSVG; if libraqm is unavailable, omit any string containing
codepoints above U+00FF rather than risk broken shaping; pin variable fonts to verified static
instances; check glyph coverage before rendering (no tofu, no silent substitution); account for
negative bearings, ascenders/descenders, italic overhang; use only the approved campaign fallback
font or request review.

Alpha and color [MG-21]: render artwork at 2× (3× only for fine diagonals failing phone preview);
RGBA straight alpha; premultiply before filtering/geometric resampling, unpremultiply before writing;
RGB=0 where alpha=0; transparent padding ≥3σ for shadows; resample every animated frame from the
original cached artwork, never from the preceding frame; composite in RGB (BT.709 primaries + BT.709
encoding transfer per the CORE color contract — sRGB-tagged artwork is converted on ingest, never
relabeled; display gamma such as BT.1886 γ 2.4 is a viewing assumption, never a working-space
encoding), convert once to yuv420p BT.709 limited-range at delivery (never fade type in YUV).

G5. ANTI-SLOP FOR GRAPHICS [MG-22, T3 diagnostics + T2 defaults]

Twelve checks feeding QC: (1) identical full entrance signature on ≥80% of moments (assign mechanics
by function: leader→label, header→rows, rule→context, direct fade for identity); (2) everything
centered (non-endboard centered >20% when side/rail layouts are valid); (3) gradients on >25% of
non-hero moments or two gradient focal groups at once; (4) overshoot on every object / scale >1.03 /
data or track positions overshooting; (5) decorative layers with no semantic role (≤1
non-informational guide per primary group); (6) graphic repeats the subtitles (>3 words ≥80% overlap
with simultaneous caption wording); (7) typography drift (unapproved font hash, synthesized weight,
essential text below minimums); (8) everything in a box (backplates on >60% of moments when unboxed
text passes contrast); (9) false quantitative theater (unsourced count-ups, bar position off the
declared scale >2%, comparison without common baseline); (10) nothing stops moving (movement >1 px/f
during >10% of the reading hold); (11) label wobble (target-relative error p95 >8 px or jitter >2 px
RMS on a stable target); (12) a tick/whoosh on every operation (SFX caps above; sound only the
primary reveal/state change). Defaults [T2]: shadow, glow, gradient, glass OFF except where an
existing recipe explicitly requires them; icons only from the brief's icon map; no all-caps reading
text (caps only for ≤18-character labels); full-frame dim ≤0.25 opacity for ≤12 frames. Detect
repeated mechanisms and unsupported decoration, never introduce arbitrary variation just to silence
a detector.

G6. ARCHETYPES AND RECIPES [MG-23]

The starter library A01–A12 (instance contract + library below): editorial margin
headline (A01), scene-premise sidecar (A02), calibrated marker ruler (A03), connected process rail
(A04), semantic underline/bracket (A05), tracked elbow annotation (A06), aligned comparison matrix
(A07), attributed quote bracket (A08), locator/time slug (A09), cut-bridging chapter rail (A10),
identity folio (A11), product/action split endboard (A12). Instantiate an archetype only from a
proposed moment of the mapped class — never add graphics to fill time; clamp parameters once, then
use the archetype's reduced-motion fallback or omit; populate copy and data through validated
references, not free-form generation. The five CORE §14 recipes (GRADIENT HERO WORD, GLASSMORPHIC
SPEC CARD, ANGLED KINETIC WORD CLUSTER, ROOM/PROGRESS COUNTER BADGE, CLOSING STAMP) remain callable
members: route number claims, word clusters, ongoing progress, brand seals, and closing stamps to
them; never re-implement them inside the archetypes. A closing stamp and a CTA lockup do not coexist
unless the brief permits and collision checks pass.

Shared instance contract: archetype_id | moment_id | evidence_refs (1–16, resolve to approved
records) | start_frame | duration_frames (from reading time + footage) | bounds_px (solver-generated,
pass geometry gates) | alignment (auto|left|right|center) | density (low|medium|high,
grammar-restricted) | accent_role (none|rule|target|primary|selected_row) | reduced_motion | params
(archetype-specific). Materialize defaults before validation; local frame 0 = archetype start; all
*_ref fields resolve to approved evidence/copy/asset records — never free-form generation slots.
- A01 Editorial margin headline — headline beside a structural rule; 2–6 words ≤2 lines; optional
  source-backed kicker; span 6–10 columns; the rule is alignment, not decoration.
  Fallback: static; omit if premise unsupported.
- A02 Scene-premise sidecar — category label + premise ≤8 words, rule-separated; side opposite the
  action; never obscure hands for a tidy rail. Fallback: one static line.
- A03 Calibrated marker ruler — axis, 2–5 ticks, one final-value marker, unit + scope;
  marker = (value−min)/(max−min) on a finite, sourced domain; never invent a domain; required scope
  qualifier must display. Fallback: plain value + unit.
- A04 Connected process rail — 2–4 nodes ≤3 words each on a path; no progress % or badge;
  highlight_current only with source-linked step timing. Fallback: static ordered diagram.
- A05 Semantic underline/bracket — attaches to measured word boxes of an existing caption/title;
  1–3 target words; never estimate word positions from character counts.
- A06 Tracked elbow annotation — leader to a tracked target, one elbow, label ≤5 words; offset
  preference loses to endpoint identity; drop to a static label only if the referent is unambiguous.
  Fallback: static label.
- A07 Aligned comparison matrix — 2 labeled columns × 1–3 aligned rows, ≤12 words; validate
  comparability row by row; no winner decoration without a separate approved conclusion.
- A08 Attributed quote bracket — quote block + restrained mark + attached attribution ≤12 quote
  words; attribution stays attached through the hold. Fallback: static exact quote.
- A09 Locator/time slug — compact rule-led location and/or time; ≥1 verified field; reformatted time
  preserves timezone + precision. Fallback: verified field only.
- A10 Cut-bridging chapter rail — rule traverses a REAL cut + verified topic/process change; label
  only with a sourced next-topic; bridges only that cut; no label → pre+post frames.
  Fallback: clean cut; omit label.
- A11 Identity folio — verified name/model + optional role/version in a stable rail, 3–6 columns;
  role/version never inferred from appearance; not attached to facial motion.
  Fallback: static verified identity; omit unknown fields.
- A12 Product/action split endboard — protected product zone + action/destination zone; logo
  integrated; ONE action; destination only from approved records (never invent shortened URLs/handles);
  existing end-card gates are authoritative; if mandatory, escalate — never silently omit.
  Fallback: static approved endboard.

G7. GRAPHICS QC (binds when this module is loaded; tiers per CORE §15)

Tier 0/T2 gates: 100% of factual text/data resolves to evidence (else block); essential content zero
hard-mask intersection with ≥12 px clearance, ≥24 px from protected facial features, ≥16 px from
essential product/logo detail, ≥24 px caption separation, zero unintended text overlap (declared
relationships only); reading hold ≥ H_required; phone-size test at 360×640 with essential text ≥16 px
nominal and measured x-height ≥8 px; stroke core ≥1.25 px; contrast p05 ≥4.5:1 essential (7:1 target;
3:1 only for ≥96 px approved-bold ≤4-word noncritical display — critical numbers, CTA, attribution
stay 4.5:1), measured on composited hold frames at 1080 AND ~390 px width, evaluated throughout the
hold and on the final H.264 decode (4:2:0 damages thin colored strokes; a shadow is never the sole
contrast solution); typography integrity (approved font hashes, full glyph coverage, no substitution);
alpha integrity (fixtures within tolerance; no fringes on black/white/saturated tests); output
integrity per CORE §13.

Tier 3 diagnostics: tracking median error ≤4 px / p95 ≤8 px / no >2 f dropout during holds; batch
consistency statistics; cut lifecycle timings per MG-16/17 reported against bands.

Frame-family review: start boundary ±1, mid-entrance, first fully-readable frame, each stagger
arrival ±1, extrema + minimum-clearance frame, minimum-contrast/busiest/max-track-error frames, hold
first/mid/last, exit start ±1 + last nonzero + first zero-alpha, C−2..C+2 for every adjacent cut,
first and final encoded frames — deduplicated, additional sheets rather than dropped extrema. When no
legal layout exists, delete lower-priority optional graphics in order: platform exclusions/mandatory
gates → essential captions/legal → faces/product protection → primary explanatory graphic →
secondary annotation → decoration.
