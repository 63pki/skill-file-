# PROPOSED CORE PATCHES — MINIMAL SET (v0.9, SEPARATE — NOT APPLIED)

**Constraint honored:** the existing master prompt and frozen chain are untouched. This file proposes the smallest change set that would make the SKILL REGISTRY prototype functional in a real campaign. Nothing here is applied; each item awaits explicit operator approval.

## P1 — REQUIRED (the only functional patch)

**Location:** the brief-reconciliation step of the master prompt.
**Proposed insert (one sentence):**
> "Consult the SKILL REGISTRY routing table and the Implementation Inventory; declare the routing in one line in the project record (primary / specialists / none + reason), and check the inventory before planning any component build."

**Why it's needed:** without it, the registry exists but nothing obliges the agent to consult it (the anti-fresh-start problem, in its minimal form). This single sentence is the entire enforcement mechanism: a declared routing line + an inventory-first habit. No gates, no fail-closed machinery, no new fields beyond the one line.

## P2 — VERIFY-ONLY (likely no patch needed)

**Check:** whether the master prompt's existing guidance-authority language (currently expressed for vendor tool guidance in the TOOL_REGISTRY directive: "technical guidance, NEVER authority over the campaign brief") already covers community skills generically.
**If yes:** no patch. **If no:** optional insert in the same section:
> "Attached skills — vendor or community — are technical guidance. The campaign brief (aspect, fps grid, audio policy, approval gates, rights) outranks them all."

## P3 — OPTIONAL (clarity, prevents future misrouting)

**Location:** the audio policy section.
**Proposed insert (one sentence):**
> "The original-audio policy is a provenance rule — no added music, voiceover, or SFX from any external or generated source; conform transforms of the original audio itself (retime, atempo, fades, delays, loudness) are chain operations and do not change provenance."

**Why optional:** the frozen chain already performs these transforms, so practice is unchanged; the line only prevents an agent from over-reading "original audio only" as "no audio operations" (the exact confusion corrected in the skill audit). Insert if the operator wants the distinction explicit.

## Explicitly NOT proposed (deliberate non-changes)

- **No demotion machinery in core** — usage/failure categories live in the registry; the operator moves cards (correction #6).
- **No per-phase citation requirements** — one-line reuse evidence only, when real (correction #2).
- **No skill bodies in the prompt** — routing table stays in the attach module; progressive disclosure preserved.
- **No new gates or QC fields** — routing declaration is the only addition (success criterion: no added bureaucracy).

## Set summary

| Patch | Status | Size |
|---|---|---|
| P1 routing + inventory consultation | REQUIRED | 1 sentence |
| P2 authority-language coverage | VERIFY-ONLY | 0–1 sentence |
| P3 audio provenance vs transform | OPTIONAL | 1 sentence |

**Smallest functional set = P1 alone.** P2/P3 are hygiene. All three together add under three sentences to the prompt.
