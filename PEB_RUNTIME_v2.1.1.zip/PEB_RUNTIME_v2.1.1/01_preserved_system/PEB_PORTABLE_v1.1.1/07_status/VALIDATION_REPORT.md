# Validation report — builder v1.1.1 (reviewed candidate + applied corrections)

## Structural checks performed in this build (documents and packaging only)
- Input ZIP CRC checks pass; source archives 178 and 174 files; SHA-256 receipts in 07_status/INPUT_ARCHIVES_RECEIPT.json.
- Package validator (05_components/verify_package.py): 374 checks, all passed, covering:
  - navigation: all 22 ACTIVE_NAVIGATION files exist; all local Markdown links in active documents resolve inside the package;
  - repository lists: 62/20/26 unique entries; every linked repository is a member of the 62-list;
  - catalogs: counts 24/45/8/41 exact; ID uniqueness enforced and passing for ALL FOUR keys (style_id, effect_id, sfx_id, library_id) — correction C1 applied; the 8 sfx_id and 41 library_id values are now actually checked (previously skipped);
  - preservation: the original v3.1.1 core body is byte-identical after the marker; all 6 preserved catalog/module hashes match;
  - manifest: exact file-set parity (247/247, 0 missing/0 extra) and every SHA-256 recomputes (results in PACKAGE_VALIDATION.json).
- Unit tests: 10 passed — 7 media-helper tests with MOCKED ffprobe responses plus 3 new ID-key regression tests (sfx_id/library_id key selection, duplicate detection).
- Negative fixtures: 5/5 detected (missing resume template, wrong repository count, modified preserved catalog, duplicate sfx_id, duplicate library_id). These are package-validator tests, not media quality tests.
- Baseline snapshot complete (C2): 10 snapshot files under archive/baseline_v1.0/, now including the pre-edit TOOL_REGISTRY original; the active tool registry equals banner + original.
- Historical banners (C3): all seven superseded documents in active-tree positions carry the HISTORICAL BASELINE banner; byte-identical originals remain in archive/baseline_v1.0/.
- ARCHIVE_COMPARISON.json clarified: the 171-file shared-handoff-subtree comparison is kept separate from the complete-ZIP-contents comparison (export 178 = 171 shared + 7 extras; handoff 174 = 171 shared + 3 loose root files). Subtree equality is not presented as whole-archive equivalence.

## Media/runtime verification NOT performed (explicitly out of scope)
No supplier script executed. No media rendered, decoded, listened to, continuously watched or transcribed. No package installed, no provider called, no private media uploaded, no publishing action performed. Navigation checking covers ACTIVE_NAVIGATION files only — not every historical prose path, vendor README image or upstream website. No full JSON-Schema-engine validation claimed. These document checks do NOT establish renderer compatibility, creative quality, rights clearance, project approval or production readiness. Pre-activation gate unchanged: the architect's pilot plan (07_status/BUILDER_CANDIDATE_v1.1_ARCHITECT_REVIEW.md §5) — mechanical re-check (this report), fresh-session boot test, then an operator-approved single-clip pilot — remains required.
