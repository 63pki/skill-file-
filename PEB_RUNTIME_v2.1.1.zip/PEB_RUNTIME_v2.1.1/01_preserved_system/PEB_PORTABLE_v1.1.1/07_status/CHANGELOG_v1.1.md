# Builder changes, v1.0 -> v1.1 review candidate
1. Original input archives preserved and hashed; independent CRC check. Source files copied; baseline originals snapshotted for edited docs.
2. Existing core BODY preserved, 7-point integration preface added (routing, campaign authority, audio/meaning, treatment freedom, evidence, compositor choice, pilot-first). Not a new master-prompt rewrite or production approval.
3. Active registry v1.1 consolidates candidate routing, preserves SR IDs, adds SR-46 Lottie and RF-NullMotion reference. Original lists retained and combined 62-repo list added. New commit-pinned MIT documents stored with source receipts.
4. Evidence-corrected inventory separates supplied scripts, recipes and contracts from portable implementations. Original probe evidence absence explicit. Legacy scripts archived unexecuted, because all contain old absolute paths; provider z-ai mismatch documented.
5. Caption/effects bodies preserved unchanged; no style/FX renumbering. Same-language fallback, context-sensitive emphasis and renderer-independent adaptation selection recorded.
6. Startup made campaign-neutral. RexTrix context is historical, not a new brief. Status, setup, project record/resume and independent-review brief added; review remains pending.
7. New stdlib package validator and media-inspection helper are bounded utilities, not a new render/edit engine. Their tests concern helper logic/package integrity only. Supplier scripts never executed.
8. Original source audit/report contradictions are retained as historical evidence, not rewritten wholesale. Active guidance corrects readiness, audio, rights, renderer exclusivity and script portability. No original 80/80 or Git claim independently revalidated.

## v1.1.1 — Post-review corrections (this packaging)

Basis: independent architect review verdict "APPROVE WITH TARGETED CORRECTIONS" (07_status/BUILDER_CANDIDATE_v1.1_ARCHITECT_REVIEW.md). Bounded corrections only — no new architecture, repositories, installs or rendering.

1. C1 — validator ID-key fix: sfx_id and library_id added to the catalog uniqueness checks (05_components/verify_package.py); uniqueness is now enforced for all four catalog arrays; regression tests added so duplicate sfx_id/library_id values are detected.
2. C2 — baseline snapshot completed: the pre-edit original of 02_registry/PEB_v3.2_MODULE_TOOL_REGISTRY.md (byte-identical to the system-export original, SHA-256 0afab46a8de60dd5a4078d594c5dd95d3bb552178d45b393fea6750660d84523) is preserved at archive/baseline_v1.0/02_registry/PEB_v3.2_MODULE_TOOL_REGISTRY.md; the active copy equals banner + original.
3. C3 — historical banners: the four superseded campaign-scoped documents (07_status/STATUS_LEDGER.md, 07_status/PENDING_RULINGS.md, 04_catalogs_and_resources/CATALOG_GUIDANCE_v1.0.md, 06_setup/DEPENDENCIES_AND_SETUP.md) now carry the same HISTORICAL BASELINE banner as the other three superseded docs; byte-identical originals remain in archive/baseline_v1.0/.
4. ARCHIVE_COMPARISON.json clarified: the 171-file comparison covers only the handoff subtree shared by both source ZIPs; complete ZIP contents differ (export 178 = 171 shared + 7 extras; handoff 174 = 171 shared + 3 loose root files). Subtree equality is not whole-archive equivalence.
5. Fresh-session onboarding added: FRESH_SESSION_INSTRUCTIONS.md (attach list, read order, on-demand loading) with a copyable opening message requiring current-brief reconciliation, access checks, a routing record and an approved single-clip pilot before any production.
6. Core untouched: 01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md keeps the original v3.1.1 body plus the reviewed integration preface. PRO_EDITOR_BRAIN_v3.2_CORE.md and ATTACH_WITH_MASTER_PROMPT_TOOL_REGISTRY_v3.2.2.md are NOT part of this package; their integration remains pending separate reconciliation.
7. Regenerated: PACKAGE_MANIFEST.json (v1.1.1), 07_status/PACKAGE_VALIDATION.json, 07_status/VALIDATION_REPORT.md (structural checks explicitly separated from media/runtime verification), the unit-test record, and negative fixtures (two new duplicate-ID fixtures).
