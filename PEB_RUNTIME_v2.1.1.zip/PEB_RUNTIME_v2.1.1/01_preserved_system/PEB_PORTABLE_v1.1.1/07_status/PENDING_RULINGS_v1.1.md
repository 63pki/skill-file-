# Review and approval boundary
This v1.1 package is a builder integration candidate. It does not label earlier held proposals as previously approved. Minimal routing, authority, treatment and evidence corrections are incorporated into the candidate for explicit review; original v3.1.1 body is unchanged apart from the documented integration preface. Supplied production history remains historical and campaign-specific.

Before production: approve or amend the candidate; provide the new campaign brief; establish current asset access/permissions; verify only needed tools/features; approve the pilot treatment and rendering phase. No account/install/provider action authorized by packaging.

Open implementation gaps: actual styled-caption backend fixtures, complete loudness/latency fixture, OCR known-card fixture, selected deterministic template path and authorized capture workflow if the campaign needs one. These are not all prerequisites for every edit. Scope based on need.
New repositories are added as guidance/reference only. Resolve specific asset permissions separately from MIT code/text license. Do not use NullMotion third-party films/music as campaign assets without authorization.

## v1.1.1 status addendum
- Architect review of the v1.1 candidate: APPROVE WITH TARGETED CORRECTIONS; corrections applied. Approval covers the candidate as a review-integration only (review §6); all previously held rulings remain held.
- PRO_EDITOR_BRAIN_v3.2_CORE.md and ATTACH_WITH_MASTER_PROMPT_TOOL_REGISTRY_v3.2.2.md are NOT included or activated in this package; their integration remains pending separate reconciliation and is not implied by anything here.
