> HISTORICAL BASELINE / NOT ACTIVE STARTUP GUIDANCE. See START_HERE.md and the v1.1 registry, inventory and status ledger. Prior probe claims are inherited, not current-machine verification. Local relative references may describe the original workspace.

# STATUS LEDGER — Tested / Untested / Gated (explicit, v1.0, 2026-10-28)

**Model:** the four capability states of TOOL_REGISTRY §1a — DOCUMENTED → INSTALLED → FEATURE-TESTED → APPROVED-FOR-PROJECT. Only FEATURE-TESTED and APPROVED-FOR-PROJECT may appear in QC tables as verified. A package list, vendor promise, or another agent's environment never upgrades a state. Application to a registry is NOT campaign approval.

## 1. TOOLS

| Tool | State | Evidence |
|---|---|---|
| T0 FFmpeg/ffprobe | FEATURE-TESTED + production-proven + campaign-approved (RexTrix v1) | Frozen-chain production record; 10-clip review; clip-28 pilot independently re-measured |
| T1 faster-whisper (small int8) | FEATURE-TESTED + production | RexTrix transcripts (01–10 + re-runs); word timestamps = estimates |
| T2 Pillow/CairoSVG | FEATURE-TESTED + production-proven | Static cards / contact sheets (make_sheets.py et al.) |
| T3 HyperFrames 0.8.207 | FEATURE-TESTED (probe 9/9: exact frame grid, CRF monotonic, ProRes 4444 alpha, byte-identical determinism ×3, audio routing enforced, frame-accurate ingest, font-fallback + check lint) — NOT yet campaign-approved for a delivered render via the registry path | T3 tool probe; T5-PROBE-1 report lineage |
| T4 Remotion | GATED (license: free ≤3-person orgs; 4+ = Company License) — NOT installed | TOOL_REGISTRY §4 verified clause texts |
| T5 tsrct (Tesseract by Mirage) | GATED (proprietary freemium, $1M Covered-Business clause, telemetry default-ON) — NOT installed; unprobed features stay unverified | TOOL_REGISTRY T5 card |
| T6 Tesseract OCR (classic) | DOCUMENTED + card + smoke spec (known-card fixture) — intake-sweep gate queued for next campaign start | TOOL_REGISTRY T6 card |
| T7 InVideo MCP | Report-only | core §1 language |
| T3 `check` browser phase on NEW machines | NOT verified — re-verify before trusting "0 issues" | Inventory known-NOT-verified list |

## 2. IMPLEMENTATION INVENTORY (12 tested components — the build-before-check list)

1. Cuts/conform/concat (frame-drop de-interpolation; per-segment render → `-c copy` seam) — production scale
2. Program loudness (loudnorm two-pass + alimiter + ebur128; XR-4 corrections mandatory reading)
3. Encode (H.264/AAC, CRF-disciplined; presets from project manifest only)
4. Static graphics/end cards (T0 drawtext/overlay + T2) — SOLVED, do not re-solve
5. Animated cards/motion graphics (T3 pinned 0.8.207, probe 9/9; segment render → FFmpeg concat; integer 30 fps on the n/30 grid)
6. Transcription (T1; timestamps = estimates)
7. On-screen-text sweep (T6 OCR pattern; "no hits" ≠ "no claims")
8. QC measurement (blackdetect/freezedetect/ebur128/hashing/frame extraction; XR-3 fail-closed)
9. Metadata hygiene (`-map_metadata -1 -c copy`)
10. Audio transforms on original audio (atempo/afade/adelay — provenance-neutral conform ops)
11. Deterministic rendering contract (no Date.now/Math.random/wall-clock/uncontrolled fetch)
12. Alpha intermediates (ProRes 4444 via T3, yuva444p12le; QC gates pix_fmt)

**Held proposal (NOT applied):** P-R3 would add row 13 (styled captions: T3 pipeline probe-verified BUT styled-caption compositions NOT feature-tested; libass available, NOT feature-tested). Until ruled, treat styled captions as untested everywhere.

## 3. SKILL REGISTRY (`../02_registry/SKILL_REGISTRY_v1.0.md`)

- **Numbered cards:** 20 (SR-01…04 renderer · SR-10/11 craft · SR-20…27 park · SR-40…45 style/effect catalog, applied 2026-10-28)
- **EXEC-eligible:** SR-01/02/03 (only AFTER pin SHA + first-use fixture) and SR-04 (after fork review). Zero are currently EXECUTABLE-HERE — no skill body is stored locally; none has ever executed here.
- **Skill bodies feature-tested: ZERO. Campaign-approved cards: ZERO.**
- **REFERENCE-ONLY:** all craft, catalog, priority-reference, library-index, and style/effect cards (licensing unverified per §6 for all community material)
- **PARK:** SR-20/21/22 (T4 ruling) · SR-23…26 (T5) · SR-27 (Figma expansion)
- **BLOCKED:** Onetake, Guizang (rights); OpenChatCut, FableCut, FireRed, Diffusion Studio, hypit, openshorts (missing verified capability — craft still citable); provider pipelines (provider + provenance dimensions, recorded separately)
- **CLOSED 2026-10-28:** video-frames @steipete (logged rejection — duplicates measured T0 capability); itsjwill/vanta reclassified OUT of the library index (engine/app class, T4+provider+campaign gated)
- **Paper tests:** 3/3 PASS (`../02_registry/PAPER_ROUTING_TESTS_v0.9.md`)

## 4. CATALOGS AND RESOURCES (`../04_catalogs_and_resources/`)

| Resource | Structurally verified | Runtime-tested | Notes |
|---|---|---|---|
| CAPTION_LIBRARY_v2 (41 styles + governance) | YES (counts, IDs, hashes, chain of custody) | NO | Author validation = structure only |
| EFFECTS_AND_CAPTIONS_SPEC_v2 (24+45+8+41+6+8) | YES | NO | `runtime_rendering_performed: false` |
| 20-style pack (templates) | YES (incl. 80/80 zip↔loose equivalence) | NO | render.py = retained reference; T3 adapter MISSING (G1) |
| Pastel-indigo guide | YES (read) | NO | Recipes 1–6 author-claimed only |
| Malayalam workflow | YES (read) | NO | Strip env-specific instructions; same-language fallback rule |
| SaaS PDF | YES (hashed, read in full as supplied text) | n/a | Reference-only; T4/provider-gated stack |
| SFX family (8 IDs) | YES | NO | Default-INACTIVE (provenance + authorization) |

## 5. MASTER PROMPT

- **v3.1.1 TEST FREEZE (2026-10-26), document-level:** regression audit 102/102 checks PASS; FRT paper tests 3/3 PASS; three pilot plans on file; **clip-28 pilot rendered and independently verified (measured + visual)** — evidence ladder: document checks → paper tests → FRT → pilot measured → audience evidence PENDING.
- **NOT cleared for an unsupervised production run** — the freeze is a TEST version; operator approval gates every render batch.

## 6. CAMPAIGN (RexTrix) — state at packaging

- Brief: verified master-intake edition (`../campaign_context/CAMPAIGN_BRIEF_RexTrix.md`); amendment v2 applied; open items Q1/Q2/Q5/Q6/Q7/Q9 with defaults.
- Pilot clip-28: PASSED independent verification. Sub-batch A (21,22,23,26,27,29): rendered + QC'd 6/6 hard gates as reported, NOT yet approved; B/C/D unlock conditions in the review round files (archived).
- Release candidates still blocked on: R4(a)/(b) logo decision, font sign-off, rights grant (operator-side decisions — see archived review rounds R4 and R5 in `../archive/`).
- Historical production record: `../archive/` (10-clip review, pilot review, run-1 + R2–R5 review rounds).

## 7. NOTHING-UP-ITS-SLEEVE LIST

No tool was installed for this package. No archive code was executed (copying + hashing only). No provider was called. No frame was rendered. No master-prompt character was changed. The only applied changes anywhere: the operator-approved catalog/reference additions inside the standalone registry document, plus the six corrections in the two current reports.
