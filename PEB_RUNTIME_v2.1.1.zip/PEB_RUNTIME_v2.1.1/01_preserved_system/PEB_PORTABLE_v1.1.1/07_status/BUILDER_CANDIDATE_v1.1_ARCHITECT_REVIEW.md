# Independent Architect Review — PEB_PORTABLE_v1.1 (builder candidate)

- Reviewed by: PEB system architect (originator of the v1.0 export baseline)
- Input: `upload/PEB_PORTABLE_v1.1_REVIEW.zip` (246 files) + `upload/ARCHITECT_REVIEW_REQUEST.md`
- Baseline used for comparison: my shipped `PEB_SYSTEM_EXPORT_v1.0` (178-file rebuild) and `HANDOFF_PACKAGE_PEB_RexTrix_v1.0` (171-file package)
- Method: direct inspection only. **No candidate/supplier/builder code was executed.** All mechanical checks were re-run with my own scripts (`scripts/review_candidate_compare.py`, `scripts/review_candidate_verify.py`). ZIP safety-checked (no path traversal entries).
- Review authorization scope: package/system review only. This review is NOT production, campaign, or media authorization.

## VERDICT: APPROVE WITH TARGETED CORRECTIONS

No blocking defects. The candidate preserves the system faithfully, documents evidence honestly, and correctly neutralizes every risk pattern named in the review request. Three small, mechanical corrections (C1–C3 below) should land before activation; none blocks a fresh session from starting correctly, and none changes system content.

---

## 1. Blocking defects

**None found.** Every integrity, preservation, routing, and authority claim in `07_status/CHANGELOG_v1.1.md` and the navigation set was independently re-verified true (details §3).

## 2. Targeted corrections (apply before activation)

### C1 — Validator silently skips ID-uniqueness for two catalogs (error)
- Evidence: `05_components/verify_package.py:29` — idkey candidate list is `['style_id','effect_id','sound_id','catalog_id','id']`. The real keys are `sfx_id` (sound_effects) and `library_id` (caption_library_catalog), so `idkey` resolves to `None` and the uniqueness check is skipped for both arrays. `07_status/VALIDATION_REPORT.md` phrases the claim as "unique IDs **where declared**", which stays technically honest, but the intent (check all four arrays) is not achieved.
- Independent recompute: the data itself is correct — 8 unique `sfx_id`, 41 unique `library_id`, counts 24/45/8/41 all exact. This is a checker gap, not a data defect.
- Minimal patch: `05_components/verify_package.py:29`
  `['style_id','effect_id','sfx_id','sound_id','catalog_id','library_id','id']`
  then re-run the validator and regenerate `07_status/PACKAGE_VALIDATION.json`.

### C2 — Baseline snapshot misses the pre-edit TOOL_REGISTRY original (error, completeness)
- Evidence: `archive/baseline_v1.0/` contains 9 snapshot docs, but the build script `07_status/build_candidate.py.txt` (snapshot list) omits `02_registry/PEB_v3.2_MODULE_TOOL_REGISTRY.md`, which WAS edited (2-line banner added; my diff confirms +255 B, purely additive). The original body remains fully recoverable (banner states "body follows"; verified additive-only) and survives in my baseline export, but the candidate's snapshot set is incomplete relative to its own "baseline originals snapshotted for edited docs" claim (`CHANGELOG_v1.1.md:2`).
- Minimal patch: copy the pre-edit original into `archive/baseline_v1.0/02_registry/PEB_v3.2_MODULE_TOOL_REGISTRY.md` and add it to `PACKAGE_MANIFEST.json` (regenerate hashes), or extend the snapshot list if rebuilding.

### C3 — Four superseded siblings sit in the active tree without the historical banner (hygiene recommendation)
- Evidence: `07_status/STATUS_LEDGER.md`, `07_status/PENDING_RULINGS.md`, `04_catalogs_and_resources/CATALOG_GUIDANCE_v1.0.md`, `06_setup/DEPENDENCIES_AND_SETUP.md` are byte-identical to the campaign-scoped originals and remain in active-tree positions beside their v1.1 successors, while the other three superseded docs (`SKILL_REGISTRY_v1.0.md`, `PEB_v3.2_MODULE_TOOL_REGISTRY.md`, `IMPLEMENTATION_INVENTORY_v0.9.md`) received the "HISTORICAL BASELINE / NOT ACTIVE STARTUP GUIDANCE" banner. `START_HERE.md` and `07_status/ACTIVE_NAVIGATION.json` route only to the v1.1 docs, so a compliant reader is unambiguous — but a wandering session could open the stale campaign-scoped `STATUS_LEDGER.md` un-warned.
- Minimal patch: apply the same 2-line banner used on the other three docs (or move them to `archive/`), then regenerate the manifest.

Classification: C1 and C2 are errors; C3 is a reasoned recommendation (inconsistent banner policy, not misinformation). Everything else observed is taste and left to the builder.

## 3. Independently verified claims (all PASS)

1. **Core preservation** — `01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md` differs from my baseline by exactly ONE diff hunk: the 15-line integration preface ending at the "ORIGINAL v3.1.1 BODY (unchanged):" marker. Body after the marker is byte-identical to my baseline original. The preface's 7 points exist and say what the changelog claims.
2. **Preface content vs the seven attention items** — all seven are explicitly neutralized in the preface and active docs (evidence in §4).
3. **Baseline snapshot** — all 9 files under `archive/baseline_v1.0/` are byte-identical to my shipped originals.
4. **Preserved corpus** — 161 active files + 13 legacy scripts (`archive/legacy_components/`) + 9 snapshots + my 2 export notes (`archive/EXPORT_README.md`, `archive/EXPORT_APPROVAL_STATE.md`) are all byte-identical to my baseline. Nothing was silently altered or dropped.
5. **Legacy scripts honestly demoted** — all 12 supplied scripts + old COMPONENTS_MAP archived unexecuted; the absolute-path finding and the z-ai finding are both true (`archive/legacy_components/run_asr.sh:16` literally calls `z-ai asr -f …`, not faster-whisper).
6. **List fidelity** — `02_registry/ALL_REPOSITORIES_62.txt` = the operator's 60 (verbatim set, zero missing/zero altered) + exactly `LottieFiles/motion-design-skill` and `blixvip/NullMotion`; the 20- and 26-link files are identical sets to the operator originals.
7. **Manifest and hashes** — `PACKAGE_MANIFEST.json`: exact file-set parity (244/244, 0 missing/0 extra) and every SHA-256 recomputes correctly. `07_status/INPUT_ARCHIVES_RECEIPT.json` hashes match my two actually-shipped zips (export 178-file rebuild + handoff 174 files).
8. **Catalogs** — caption_styles 24 / video_effects 45 / sound_effects 8 / caption_library_catalog 41, counts exact, all IDs unique (recomputed).
9. **Local references** — 100 markdown links checked across ALL active docs: 0 broken, 0 escaping the package root. The only unresolved references live in historical/vendor material, which the builder's scope disclaimer covers precisely: 41 = the documented never-delivered caption previews in the preserved `Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` (a pre-existing, transparency-listed gap), 3 = unbundled upstream NullMotion README assets, 2 = regex false-positives on Python code inside vendor SKILL.mds. Zero broken links in any ACTIVE_NAVIGATION doc.
10. **Security** — pattern scan over all candidate text files: no credentials, keys, or tokens.
11. **Fresh-session realism** — ACTIVE_NAVIGATION's 20 files all exist; STATUS_LEDGER "Not established" section lists everything untested; `09_project_templates/PROJECT_RECORD_TEMPLATE.json` defaults to `not_checked`/`not_granted`/`pending`; no lockfile fabricated (`06_setup/builder_dependencies.json`: stdlib-only claims, true for the validator).
12. **Builder utilities bounded** — `verify_package.py`/`inspect_media.py` code-reviewed statically: read-only, subprocess arg-array with timeout, refuses overwrite, explicit "not_checked" fields, "metadata success is not a media-quality or release pass". Builder build/inspection scripts retained with `.txt` suffix (execution-disabled) — good transparency.

## 4. The seven attention items — all correctly handled

1. **Narrative ambition vs restraint** — preface point 4: restraint is valid AND "restraint is not a ban on ambitious design"; pilot point 7: "a source excerpt + caption + logo is not automatically a sufficient creative treatment." Both failure directions guarded.
2. **Old campaign constraints becoming global** — preface point 2 names them precisely: "No historical RexTrix values, tool freezes, audience constraints, end-card duration, banned words, audio policy or platform restrictions become universal campaign defaults." `CATALOG_GUIDANCE_v1.1.md` repeats it operationally.
3. **Layer-order/concat/audio transformations as universal laws** — inventory v1.1 header: "No 'never rebuild' rule or exclusive concat architecture"; IM-02: "no fixed loudness universal platform rule"; IM-10: "Recipes, not blanket campaign permission"; registry: "no mandatory custom adapter for every library"; preface point 6: "Do not force every HTML template through an unbuilt adapter."
4. **Absent probe evidence** — `IMPLEMENTATION_INVENTORY_v1.1.md:4`: "No source probe reports T3/T4/T5 were included. Prior results remain inherited claims." Status ledger "Not established" reiterates. Probe claims are nowhere renewed as current facts.
5. **Legacy z-ai calls mistaken for local ASR** — IM-06: "Legacy run_asr.sh invokes z-ai asr, NOT faster-whisper; provider route nonportable" — verified against the actual script (line 16). Status ledger and COMPONENTS_MAP_v1.1 repeat the warning.
6. **Lottie house rules overriding campaign intent** — verified the Lottie SKILL.md really contains the house rules ("Never linear for spatial movement":264, "Never opacity-only":265, "Always three motion layers":267, stagger "<500ms":227, "1/3 Rule":32, personality archetypes:41/70). `NEW_RESOURCES_2.md:10` explicitly bars inheriting them as release gates — "Linear camera drift or opacity-only fades may be appropriate… campaign evidence take precedence." Registry SR-46 marks it "optional defaults; no runtime tests."
7. **NullMotion mistaken for a clipping editor or soundtrack clearance** — verified from the bundled README/package.json/tree: it is a reference-breakdown viewer (finished ad over HyperFrames drafts, exported as MP4), correctly scoped as "Authorized reference/draft comparison… not the separate hosted Null Studio clipping/editor product." Tree evidence (172 entries) confirms no SKILL.md. `PENDING_RULINGS_v1.1.md`: "Do not use NullMotion third-party films/music as campaign assets without authorization" — MIT code license correctly NOT treated as media/soundtrack clearance.

Also verified: no checksum/paper-test/parse claim anywhere promotes itself to creative-quality evidence (preface point 5 is explicit: "checksums, document audits and successful renders do not establish editorial quality").

## 5. Small pilot verification plan (post-correction, pre-activation)

1. **Mechanical re-check (no media)**: apply C1 (+C2, C3), re-run the candidate validator and my independent verifier; expected all-green including `sfx_id`/`library_id` uniqueness. Re-verify manifest exact-set parity.
2. **Fresh-session boot test**: extract in a clean directory; follow `START_HERE.md` read order only; confirm no step requires RexTrix context, legacy scripts, or network; produce the `ROUTING: primary=…; specialists=…; none_reason=…` record per registry v1.1.
3. **Single-clip pilot (requires operator-approved NEW brief + authorized source clip)**: pick ONE real caption need → select one CAP/FX catalog entry → one chosen compositor → render ONE pilot cut → `inspect_media.py` (metadata + SHA-256, explicitly not a QC pass) → human review filling the four separated statuses (technical / campaign / creative / performance) in PROJECT_RECORD_TEMPLATE.json → hold for operator approval. No batch, no publish, no installs during the pilot beyond the one exercised path. Fixtures: create only those the exercised features actually need (e.g., known-card OCR fixture only if OCR is used).

## 6. Approval boundary (per PENDING_RULINGS_v1.1)

This approval covers the **candidate package as a review-integration**: preserved baseline + preface + v1.1 active docs + bounded utilities + two new reference repos. It does NOT approve production rendering, any campaign, media rights, spending, publishing, or activation of the RexTrix campaign context. All previously held rulings remain held.
