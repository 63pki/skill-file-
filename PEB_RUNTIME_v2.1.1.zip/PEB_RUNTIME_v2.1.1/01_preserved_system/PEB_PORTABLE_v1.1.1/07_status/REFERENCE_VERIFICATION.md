# REFERENCE VERIFICATION — local references resolve inside the package (2026-10-28)

Checker: `scripts/build_package_manifest_and_verify_refs.py check` (this workspace) — markdown links + backtick path-like strings; STRICT pass over the package's own navigation docs, INFORMATIONAL pass over byte-exact project documents and vendor bodies (their references point at the original project tree by design and are preserved unedited).

**STRICT pass: 8 navigation docs scanned — 0 broken, 0 escaping the package root, 2 explained exclusions, 9 intentional remote/descriptive mentions, 0 missing docs.**


## Explained exclusions (intentional, documented)

| Doc | Reference | Reason |
|---|---|---|
| `START_HERE.md` | `upload-to-claude/` | intentionally excluded from the package: per-style zips are verified byte-identical duplicates (80/80 SHA-256) of the included loose dirs; see START_HERE §6 and 07_status/evidence/pack_equivalence_result.json |
| `04_catalogs_and_resources/CATALOG_GUIDANCE_v1.0.md` | `upload-to-claude/` | intentionally excluded from the package: per-style zips are verified byte-identical duplicates (80/80 SHA-256) of the included loose dirs; see START_HERE §6 and 07_status/evidence/pack_equivalence_result.json |

## Intentional mentions (documented — remote or descriptive, not package references)

| Doc | Mention | Why it is not a package reference |
|---|---|---|
| `02_registry/SKILL_REGISTRY_v1.0.md` | `SKILL.md` | generic vendor skill-body filename (video-frames closure note); actual bodies exist per style dir in 04_catalogs_and_resources/ |
| `02_registry/SKILL_REGISTRY_v1.0.md` | `github.com/steipete/clawdis` | remote repository identifier (no scheme), cited as source of the rejected video-frames skill |
| `02_registry/SKILL_REGISTRY_v1.0.md` | `itsjwill/vanta` | repository slug of the reclassified engine (no local body; deliberately not in the package) |
| `02_registry/SKILL_REGISTRY_v1.0.md` | `plugins/_official/video-templates/frame-liquid-bg-hero/SKILL.md` | remote repository path tail (open-design template example) |
| `02_registry/SKILL_REGISTRY_v1.0.md` | `scripts/frame.sh` | file inside the inspected remote steipete/video-frames skill (not shipped here; the skill was rejected) |
| `02_registry/SKILL_REGISTRY_v1.0.md` | `skills/cinematic-shot/SKILL.md` | remote repository path tail (1weiho/cinematic-shot shortlist link) |
| `02_registry/SKILL_REGISTRY_v1.0.md` | `skills/cinetic/SKILL.md` | remote repository path tail cited by the PRIORITY REFERENCE block (Leonxlnx/cinetic shortlist link) |
| `02_registry/SKILL_REGISTRY_v1.0.md` | `skills/motion-broll/SKILL.md` | remote repository path tail (barty-bart/motion-graphics shortlist link) |
| `02_registry/SKILL_REGISTRY_v1.0.md` | `skills/motion-design/SKILL.md` | remote repository path tail (nexu-io/open-design shortlist link) |

**Result: PASS — every reference in the package's navigation documents resolves to a file inside the package, or is a documented explained-exclusion / intentional mention.**

## Informational pass (byte-exact project docs + vendor bodies): 221 unresolved references — expected

These documents are versioned records or vendor material copied unedited; their path citations refer to the original project tree (`/home/z/my-project/...`), where they do resolve. Listed for transparency; not failures. The strongest evidence artifacts are mirrored inside the package (`07_status/evidence/`, `05_components/`).

| Doc | Reference (resolves in original project tree) |
|---|---|
| `01_master_prompt/README.md` | `CAMPAIGN_BRIEF_RexTrix.md` |
| `01_master_prompt/README.md` | `CONSULT_*.txt` |
| `01_master_prompt/README.md` | `PEB_v3.1.1_PAPER_TESTS.md` |
| `01_master_prompt/README.md` | `PEB_v3.1.1_PILOT_PLANS.md` |
| `01_master_prompt/README.md` | `PRO_EDITOR_BRAIN_v2.1_video_patches.md` |
| `01_master_prompt/README.md` | `PRO_EDITOR_BRAIN_v2_consolidated.md` |
| `01_master_prompt/README.md` | `PRO_EDITOR_BRAIN_v2_patches.md` |
| `01_master_prompt/README.md` | `PRO_EDITOR_BRAIN_v3.md` |
| `01_master_prompt/README.md` | `PRO_EDITOR_BRAIN_v3_appendix.md` |
| `01_master_prompt/README.md` | `REXTRIX_10clip_review.md` |
| `01_master_prompt/README.md` | `REXTRIX_campaign_input.md` |
| `01_master_prompt/README.md` | `SCOUT_CORRECTION_NOTES.md` |
| `01_master_prompt/README.md` | `SCOUT_campaign_brief_prompt_v2.txt` |
| `01_master_prompt/README.md` | `V3.1.1_TEST_CORRECTIONS.md` |
| `01_master_prompt/README.md` | `V3_EXTERNAL_REVIEW_verdict_and_actions.md` |
| `01_master_prompt/README.md` | `V3_REVIEW_user_prompt_vs_goals.md` |
| `01_master_prompt/README.md` | `V3_improvement_roadmap.md` |
| `01_master_prompt/README.md` | `V3_integration_map.md` |
| `01_master_prompt/README.md` | `v31_regression_audit.py` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `caption_styles_raw.mp4` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `fontsize=34:fontcolor=black:box=1:boxcolor=white:boxborderw=12:x=(w-text_w)/2:y=180` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `fontsize=72:fontcolor=#FF7A00:borderw=3:x=(w-text_w)/2:y=300` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/01_keyword_pop_cyan.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/02_keyword_pop_purple.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/03_gold_serif_luxe.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/04_neon_glow.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/05_outline_stroke.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/06_white_cyan_mix.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/07_stat_highlight.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/08_portfolio_card.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/09_tiktok_pill.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/10_yellow_marker.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/11_script_serif_mix.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/12_collegiate_outline.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/13_magenta_mix.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/14_thin_lowercase.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/15_label_tag.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/16_lime_keyword.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/17_dark_pill.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/18_red_keyword.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/19_minimal_left.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/20_gold_script.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/21_stat_box.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/22_beast_block.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/23_underline_sweep.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/24_sticker_pop.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/25_ink_noir.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/26_blush_gradient.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/27_comic_shake.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/28_terminal_type.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/29_ribbon_banner.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/30_news_lower_third.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/31_bubble_bounce.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/32_karaoke_fill.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/33_glitch_rgb_split.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/34_gradient_pop.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/35_3d_shadow_stack.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/36_wave_in.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/37_zoom_punch.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/38_outlined_fill_swap.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/39_bracket_frame.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/40_emoji_word_swap.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `previews/41_vhs_retro_stamp.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `styles_v2_mobile.mp4` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `styles_v3_18s.mp4` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | `styles_v4_2min.mp4` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `caption_styles_raw.mp4` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `fontsize=34:fontcolor=black:box=1:boxcolor=white:boxborderw=12:x=(w-text_w)/2:y=180` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `fontsize=72:fontcolor=#FF7A00:borderw=3:x=(w-text_w)/2:y=300` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/01_keyword_pop_cyan.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/02_keyword_pop_purple.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/03_gold_serif_luxe.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/04_neon_glow.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/05_outline_stroke.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/06_white_cyan_mix.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/07_stat_highlight.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/08_portfolio_card.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/09_tiktok_pill.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/10_yellow_marker.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/11_script_serif_mix.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/12_collegiate_outline.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/13_magenta_mix.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/14_thin_lowercase.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/15_label_tag.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/16_lime_keyword.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/17_dark_pill.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/18_red_keyword.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/19_minimal_left.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/20_gold_script.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/21_stat_box.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/22_beast_block.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/23_underline_sweep.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/24_sticker_pop.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/25_ink_noir.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/26_blush_gradient.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/27_comic_shake.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/28_terminal_type.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/29_ribbon_banner.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/30_news_lower_third.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/31_bubble_bounce.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/32_karaoke_fill.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/33_glitch_rgb_split.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/34_gradient_pop.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/35_3d_shadow_stack.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/36_wave_in.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/37_zoom_punch.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/38_outlined_fill_swap.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/39_bracket_frame.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/40_emoji_word_swap.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `previews/41_vhs_retro_stamp.jpg` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `styles_v2_mobile.mp4` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `styles_v3_18s.mp4` |
| `04_catalogs_and_resources/Captions_and_Effects_v2/originals/CAPTION_LIBRARY.md` | `styles_v4_2min.mp4` |
| `04_catalogs_and_resources/claude-motion-styles-20/README.md` | `.claude/skills/` |
| `04_catalogs_and_resources/claude-motion-styles-20/README.md` | `~/.claude/skills/` |
| `04_catalogs_and_resources/claude-motion-styles-20/motion-halftone/SKILL.md` | `U/110` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `/accounts/login/` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `/mnt/user-data/outputs` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `assets/mix.wav` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `data-start/data-duration/data-track-index` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `farshan_claude_skill_reel.mp4` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `fps=1/2,scale=200:-1,tile=8x4` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `gsap-lite.js` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `phrases.json` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `project/fonts/` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `reel/` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `reel/assets/reels.jpg` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `reel/index.html` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `reel/vendor/gsap.min.js` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `render_fallback.py` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `script.txt` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `timeline/to/fromTo/set` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `tool-results/…jpg` |
| `04_catalogs_and_resources/malayalam-pastel-reel-edit/SKILL.md` | `~/Movies/claude-motion-demo/` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `asr.py` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `data-start/data-duration/data-track-index` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `display/visibility` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `edit.json` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `gsap.min.js` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `keep.json` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `package/dist/gsap.min.js` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `project/` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `project/assets/aroll.mp4` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `project/fonts/` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `project/index.html` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `project/vendor/` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `render_fallback.py` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `storyboard.md` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `voice_cut.wav` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `voice_cut16.wav` |
| `04_catalogs_and_resources/pastel-indigo-motion-graphics/SKILL.md` | `words_cut.json` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `/SKILL.md` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `COVERAGE_RECONCILIATION_v2.0.md` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `HANDOFF_PACKAGE_PEB_RexTrix_v1.0/` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `SKILL_REGISTRY_PROTOTYPE_v0.9.md` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `SKILL_REGISTRY_v1.0.md` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `WEB_UI_VIDEO_ROUTING_CORRECTION.md` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `download/OPERATOR_INPUT_2026-10-28/` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `make_sheet2.py` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `make_sheets.py` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `qc_frames.sh` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `scripts/extract_video.py` |
| `07_status/COVERAGE_RECONCILIATION_v2.1.md` | `scripts/verify_operator_input_v1.py` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `CAPTION_LIBRARY_v2.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `COVERAGE_RECONCILIATION_v2.0.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `EFFECTS_AND_CAPTIONS_SPEC_v2.json` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `EFFECTS_AND_CAPTIONS_SPEC_v2.schema.json` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `FILE_MANIFEST.json` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `HANDOFF_PACKAGE_PEB_RexTrix_v1.0/` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `IMPLEMENTATION_INVENTORY_v0.9.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `PREVIEW-all-20-styles.jpg` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `PREVIEW-all-20-styles.mp4` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `README.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `RESOURCE_INTEGRATION_REPORT_v1.0.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `RESOURCE_INTEGRATION_REPORT_v1.1.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `REVISION_NOTES.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `SKILL_REGISTRY_PROTOTYPE_v0.9.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `SKILL_REGISTRY_v1.0.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `VALIDATION_REPORT.json` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `WEB_UI_VIDEO_ROUTING_CORRECTION.md` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `caption_styles_raw.mp4` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `claude-motion-styles-20.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `download/PRO_EDITOR_BRAIN_v3.1.1_TEST.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `gallery.html` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `malayalam-pastel-reel-edit.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-art-deco.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-ascii-art.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-bauhaus.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-blueprint.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-clay-3d.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-comic-book.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-glassmorphism.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-gradient-mesh.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-halftone.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-holographic.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-isometric.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-kinetic-type.zip` |
| `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` | `motion-liquid-morph.zip` |

(+21 more)
