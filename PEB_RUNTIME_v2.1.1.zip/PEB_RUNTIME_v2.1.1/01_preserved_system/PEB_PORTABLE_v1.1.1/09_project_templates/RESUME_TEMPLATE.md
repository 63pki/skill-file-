# Resume record
- Current authorized phase:
- Package/revision:
- Brief and linked rules saved at (with source/version):
- Source assets saved at + hashes + access/rights status:
- Current routing / treatment / primary compositor:
- Existing implementation reused or specific gap:
- EDL / source-to-output map / claims ledger locations:
- Exact completed checks + evidence files:
- Human audiovisual checks pending:
- Next bounded step:
- Blockers / decisions awaiting user:
Never replace missing inputs with memory. Persist received campaign inputs before interpreting. Do not store credentials in handoffs.
