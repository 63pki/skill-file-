---
name: "malayalam-pastel-reel-edit"
description: "Edit Farshan's Malayalam talking-head clip into a 9:16 pastel-indigo motion reel in HyperFrames, with Malayalam keyword subtitles timed from his script, profile inserts, SFX and a comment CTA."
---

# Malayalam pastel-indigo reel edit (HyperFrames)

Turns a raw Malayalam talking-head clip plus its script into a finished 1080x1920 Instagram reel in the pastel-indigo style: cream canvas with drifting pastel blobs, editorial serif with indigo italic accents, indigo cards, pastel tiles, mono HUD, springy masked-word motion and indigo tile wipes. English headlines carry the idea; **Malayalam keywords** (the spoken word that carries the meaning) appear as big captions or chips at their moment. First built for the 26 s "Claude skill" reel (`farshan_claude_skill_reel.mp4`) — its composition is the template below.

## Inputs

- The clip (usually 4K vertical, one continuous take, lav mic).
- The Malayalam script, which is the timing source. No speech recogniser is needed.
- Optional: an insert to show (his Instagram reels tab @farshanedits, a screenshot or a screen recording), and the CTA comment keyword (e.g. "SKILL").

Ask one AskUserQuestion round only for what's missing and matters: the insert source (browser capture vs his screenshot), the CTA keyword if the script has none, and fonts if the real files aren't available. Default to 9:16. Otherwise decide and state assumptions in the final message.

## Style (vertical)

All tokens live in the template's `:root`. Keep them; never invent colours.
- Cream `#ECE6DD`, ink `#15122A`, indigo `#5536EE` (the only accent), butter `#EED9A0` (italics on indigo), highlight `#EFD98F`, pastels lav `#BCAEEA` · peach `#F0B89A` · mint `#A9D8BF` · sun `#EED68E` · sky `#A9C4EE`; blobs lav top-left, peach top-right, mint bottom-left, butter bottom-right.
- Serif (Instrument Serif; stand-in Lora) for English headlines 104–200px. One or two italic indigo words per line. Statements end in an indigo period dot that pops in last.
- Mono (JetBrains Mono; stand-in DejaVu Sans Mono) for kickers (22px, uppercase, spaced), chips and the HUD.
- HUD: top-left `CLAUDE ✦ EDIT REEL '26`, top-right `0N / 06 — chapter`, bottom-left `edited by claude · html · gsap`, bottom-right running timecode, 6px indigo progress bar. It turns white over footage.
- Motion: every word rises out of its own mask (`yPercent 115→0`, `back.out(1.5)`, 0.7 s) on its spoken word. Cards spring in tilted (`back.out(1.7)`). Pops use `back.out(2.2–3.5)`. Exits are fast (0.3 s, `power3.in`, blur). Nothing sits static: footage drifts 1.0→1.06, tiles bob, blobs drift.

## Malayalam keyword rules

- **Keywords, not full subtitles.** About half the beats get one: the word or short phrase that carries the meaning (എഡിറ്റർ ഇല്ല, സിമ്പിൾ, രണ്ടേ സ്റ്റെപ്പിൽ, ഒരു മെത്തേഡ്, എല്ലാം ക്ലൗഡ്, അത്രേയുള്ളൂ, DM ചെയ്തു തരാം).
- **Over footage (OVER):** a big white Malayalam caption, `.cap.ml`, 96–110px, FreeSans bold. The payoff word sits in the butter highlight box (`.hi` + `hilite()`), with a white mono kicker giving the English gist above ("NO EDITOR?", "INCLUDING THIS ONE", "HONESTLY").
- **Graphics scenes (FULL/CARD):** the English headline leads, and the Malayalam keyword sits under it as a pill chip, `.chip.mlc`, 34–40px, in sun or indigo. Or it opens the scene as the big word and then slides out as the English headline arrives (`slotOut(…,{y:-170})`).
- **Negation:** for "no X" or "without X", show X in Malayalam and draw an indigo strike through it (എഡിറ്റർ ഇല്ല, കോംപ്ലിക്കേഷൻ), then the English counter-line ("don't *stop.*", "just *two* steps.").
- English loanwords spoken in Malayalam script are written in English on screen when they're brand names (ക്ലൗഡ് → "Claude"). In keyword chips, keep the Malayalam.
- Fix obvious script typos in on-screen text (ചെയ്തതരാം → ചെയ്തു തരാം) and list each fix in the final message.
- Malayalam needs taller masks. The template's `.ml .w` padding (.18em top, .32em bottom) stops clipped vowel signs. Never put Malayalam in the serif or mono stack.
- Font: check `fc-list :lang=ml`. FreeSans and FreeSerif cover Malayalam and shape conjuncts correctly in Chromium. Prefer Manjari or Noto Sans Malayalam woff2 files in `project/fonts/` when you have them (add an `@font-face`). Render a test line (എഡിറ്റർ ഇല്ല · അത്രേയുള്ളൂ · സ്റ്റെപ്പിൽ) and look at it before building.

## Beat pattern (from the first reel — adapt to each script)

| beat | layout | recipe |
|---|---|---|
| hook (0–2.5 s) | OVER | Malayalam problem keyword + strike → English counter-line with highlight + sparkle → **tile wipe** |
| the promise | FULL | indigo card: "one *simple* / *trick.*" + Malayalam line inside + sun chip ("ഞാൻ പറഞ്ഞു തരാം ↓") |
| context | CARD | speaker drops in as a tilted card in the lower half; Malayalam word above → English headline + pastel reel tiles → **tile wipe** |
| the offer | FULL | strike the complication word, "just *two* steps." + indigo chip + 01/02 tiles |
| proof | OVER → phone | "ഈ വീഡിയോ അടക്കം" caption, then speaker shrinks to a small sticker card while the **profile phone insert** springs in; "one *method*." + chip → **tile wipe** |
| what it does | FULL | 3 icon tiles + labels on each spoken item, "*Claude*." + chip |
| reassurance | OVER | "വളരെ സിമ്പിൾ" in highlight + sparkle |
| how-to | CARD | paper chat card above the speaker card: numbered rows appear on each step (open / upload with a progress bar / skill command typing), "*done.*" pops, chip "അത്രേയുള്ളൂ" |
| CTA | OVER | Malayalam desire line → white comment pill types “KEYWORD” with caret, indigo arrow pulses, chip "ഞാൻ DM ചെയ്തു തരാം ✉", sparkles |

Rules: a visual change every ≤ 2.5 s. The speaker is on screen (OVER/CARD/sticker) for ≥ 40% of the runtime. Chapters (5–6) feed the HUD counter. Keep captions inside y 1150–1560 and nothing important in the top 200px or bottom 300px (Instagram UI).

## Workflow

Use a task list. Work in the scratchpad (`reel/` = project). When finished, deliver to chat and to `~/Movies/claude-motion-demo/` if that folder is connected.

1. **Inspect.** `ffprobe` the clip. Make a contact sheet (`fps=1/2,scale=200:-1,tile=8x4`). Find the face position and set `#aroll{object-position}` (his low-angle 4K takes: `50% 34%`).
2. **Footage.** `ffmpeg -i src.mp4 -vf "scale=1080:1920,fps=30" -an -c:v libx264 -crf 18 -g 15 -pix_fmt yuv420p reel/assets/aroll.mp4`. Keep the whole take when the speech is continuous. Only if there are retakes or dead air, cut them first with trim/concat (keep 0.15–0.25 s gaps) and work on the cut.
3. **Timing.** Extract audio: `ffmpeg -i src.mp4 -vn -ac 1 -ar 16000 a16.wav`. Save the script to `script.txt`, one sentence per line or with normal punctuation. Run `python3 align.py a16.wav script.txt phrases.json`, which prints each phrase with per-word estimated times. Expect ±0.2–0.3 s. Low-energy stretches are often quiet speech, not silence. If a stretch matters, check the lips with a mouth crop strip (`ffmpeg -ss A -t D -i src.mp4 -vf "fps=5,crop=700:450:X:Y,scale=200:-1,tile=13x1"`). Land each keyword on its word time; put card and scene changes in the deepest pauses.
4. **Storyboard.** One line per beat: time range, layout, recipe, English headline (italic word marked), Malayalam keyword and its form (caption, chip or strike), transition. Check pacing and speaker share.
5. **Insert (profile reels tab).** Load the `anthropic-skills:built-in-browser` skill. Open `https://www.instagram.com/farshanedits/reels/` with `preview_start` (`request_access` for instagram.com if asked). If it shows "Profile isn't available" or a login wall, navigate to `/accounts/login/` and ask him to log in himself (Cmd+Shift+B shows the pane; never type passwords). Then `resize_window` preset `mobile`, reload, wait 4 s, and take a full-scale screenshot. The image is saved under the session's `tool-results/…jpg`. Crop off the "Use the app" banner (`crop=662:1282:0:0` at 750x1624), save it to `reel/assets/reels.jpg`, then `resize_window` preset `desktop`. If the pane stops redrawing after a scroll, use the first capture rather than retrying. His screenshot or recording works the same way (a recording becomes a muted `<video class="clip">` inside the phone `.scr`).
6. **Build.** Copy the template to `reel/index.html`. Set `data-duration` in 4 places (edit, aroll, mix, timeline pad uses DUR). Fill `SCENES` and `DARK`. Rewrite scenes s1–s9 and the BEATS block from the storyboard, timed from `phrases.json`. Rules: `.clip` + `data-start/data-duration/data-track-index` on every scene; hide masked words only via the one-time `gsap.set(qa('.wi'),{yPercent:115})`, never with CSS transforms; elements that animate in carry `.in`; use `immediateRender:false` on fromTo; deterministic only (seeded `rnd()`); never tween `display` on a clip.
7. **Snapshot check.** `python3 render_fallback.py reel snap/x 30 t1,t2,…` with one time per beat (or `npx hyperframes snapshot`). Look at every frame: Malayalam clipping, captions running off the edge (keep lines under ~880px; split into two lines), overlaps, HUD, face framing. Fix, then re-snapshot the changed beats.
8. **Sound.** `python3 sfx.py sfx.json DUR`, using: whoosh -24 dB on tile wipes, -28 on card moves and returns; swipe -27 on strikes; pop -28 on tiles, chips, dots and rows; small pops -33 for staggered tiles; ticks -34/-35 every 0.055–0.07 s while typing; thump -22/-23 on the payoff word ("*Claude*." and "*done.*"). Mix with the commands below (target -14 LUFS, ≤ -1.5 dBTP). Music only if he asks.
9. **Render.** Use the HyperFrames CLI if it's installed (`npx hyperframes lint`, `render --quality high`). Otherwise run `render_fallback.py` in the background (`nohup … &`) and poll with `sleep`. It renders about 1 frame/s at 1080x1920, so ~25 min for 26 s, and muxes `assets/mix.wav` itself. Never `pkill -f render.py` from a command line that also contains that string; it kills your own shell.
10. **Verify and deliver.** Run `ffprobe` (video + audio streams, duration), make a 1 fps contact sheet, pull 4 full-res frames, check loudness. Keep the file under 30 MB (re-encode with 2-pass x264 if needed). Send it with `SendUserFile`, then `device_commit_files` with the returned `fileUuid` to `~/Movies/claude-motion-demo/<name>.mp4` (a `stagedPath` outside `/mnt/user-data/outputs` is rejected).
11. **Final message.** A beat table (time · what's on screen, Malayalam keywords in bold), then notes: timing is estimated from the script, any spelling fixes, stand-in fonts if used, anything a transition briefly covers. Offer one re-render round.

## When GSAP or the fonts can't be downloaded

npm, GitHub and PyPI are often blocked in both the cloud workspace and the desktop VM. If `npm pack gsap @fontsource/instrument-serif @fontsource/jetbrains-mono` fails:
- Write `gsap-lite.js` (below) to `reel/vendor/gsap.min.js`. It's a seek-driven subset covering `timeline/to/fromTo/set`, stagger (number or `{each,from}`), eases power/expo/sine/back/circ, `gsap.set` baselines, CSS props, plain-object tweens with `onUpdate`, and `"+="` values. Use only those features. When real GSAP is available, it drops in unchanged.
- The CSS stacks fall back to Lora / DejaVu Sans Mono / FreeSans automatically. Tell him they're stand-ins. If he drops the real woff2 files into the folder, they're picked up by the `@font-face` rules.

## Template: `reel/index.html` (the first reel, rendered and checked)

```html
<!doctype html>
<html><head><meta charset="utf-8">
<style>
@font-face{font-family:IS;src:url(fonts/instrument-serif-latin-400-normal.woff2);font-style:normal}
@font-face{font-family:IS;src:url(fonts/instrument-serif-latin-400-italic.woff2);font-style:italic}
@font-face{font-family:JB;src:url(fonts/jetbrains-mono-latin-500-normal.woff2);font-weight:500}
:root{
  --cream:#ECE6DD; --ink:#15122A; --mute:#8C86A0;
  --indigo:#5536EE; --indigo-hi:#7A63F2; --indigo-lo:#4327DB; --butter:#EED9A0; --hilite:#EFD98F;
  --lav:#BCAEEA; --peach:#F0B89A; --mint:#A9D8BF; --sun:#EED68E; --sky:#A9C4EE; --code:#130F25;
  --b-lav:#A28DEB; --b-peach:#EC9E7E; --b-mint:#9ACDB3; --b-sun:#E9CB86;
  --serif:IS,'Instrument Serif',Lora,'Liberation Serif',serif; --mono:JB,'JetBrains Mono','DejaVu Sans Mono',monospace;
  --ml:'Manjari','Noto Sans Malayalam',FreeSans,sans-serif;
}
html,body{margin:0;background:var(--cream)}
#edit{position:relative;width:1080px;height:1920px;overflow:hidden;background:var(--cream);color:var(--ink);font-family:var(--serif);-webkit-font-smoothing:antialiased}
#bg{position:absolute;inset:-10%;z-index:0}
.blob{position:absolute;border-radius:50%;filter:blur(140px);opacity:.95}
#bl1{left:-12%;top:-8%;width:80%;height:46%;background:var(--b-lav)}
#bl2{right:-16%;top:-6%;width:70%;height:40%;background:var(--b-peach)}
#bl3{left:-16%;bottom:-8%;width:74%;height:42%;background:var(--b-mint)}
#bl4{right:-16%;bottom:-10%;width:76%;height:44%;background:var(--b-sun)}
#bl5{left:14%;top:32%;width:72%;height:36%;background:var(--cream);filter:blur(120px)}
#grain{position:absolute;inset:0;z-index:8;pointer-events:none;opacity:.07;mix-blend-mode:multiply}
#cam{position:absolute;left:0;top:0;width:1080px;height:1920px;overflow:hidden;z-index:2;border-radius:0;transform-origin:50% 50%;
  box-shadow:0 50px 90px -40px rgba(45,25,140,.55),0 10px 30px rgba(21,18,42,.18)}
#camz{position:absolute;inset:0}
#aroll{width:100%;height:100%;object-fit:cover;object-position:50% 34%;display:block}
.scene{position:absolute;inset:0;z-index:3;overflow:visible}
.ab{position:absolute}.in{opacity:0}
.kick{font:500 22px var(--mono);letter-spacing:.3em;text-transform:uppercase;color:var(--indigo)}
.hl{font-family:var(--serif);font-weight:400;font-size:130px;line-height:.98;letter-spacing:-.012em;color:var(--ink);white-space:nowrap}
.hl.md{font-size:104px}.hl.xl{font-size:180px}
.it{font-style:italic;color:var(--indigo)}
.w{display:inline-block;overflow:hidden;vertical-align:bottom;padding:.06em .04em .16em;margin:-.06em -.04em -.16em}
.wi{display:inline-block;will-change:transform}
.ml{font-family:var(--ml);font-weight:700;letter-spacing:0;line-height:1.25;white-space:nowrap}
.ml .w{padding:.18em .04em .32em;margin:-.18em -.04em -.32em}
.pdot{display:inline-block;width:.15em;height:.15em;border-radius:50%;background:var(--indigo);margin-left:.03em;vertical-align:.02em}
.strike{position:absolute;left:-3%;right:-3%;top:52%;height:12px;border-radius:8px;background:var(--indigo);transform-origin:0 50%;transform:rotate(-3deg) scaleX(0)}
.icard{position:absolute;border-radius:36px;background:linear-gradient(135deg,var(--indigo-hi) 0%,var(--indigo) 42%,var(--indigo-lo) 100%);
  box-shadow:0 50px 90px -30px rgba(67,39,219,.6),0 10px 24px rgba(21,18,42,.12);color:#fff;overflow:hidden}
.icard .hl{color:#fff}.icard .it{color:var(--butter)}
.micro{position:absolute;font:500 16px var(--mono);letter-spacing:.32em;text-transform:uppercase;color:rgba(255,255,255,.45)}
.pcard{position:absolute;border-radius:36px;background:#F7F2EA;box-shadow:0 50px 90px -40px rgba(21,18,42,.4),0 8px 20px rgba(21,18,42,.08)}
.chip{display:inline-block;padding:12px 24px;border-radius:16px;background:var(--ink);color:#fff;font:500 22px var(--mono);letter-spacing:.05em;white-space:nowrap}
.chip.up{text-transform:uppercase;letter-spacing:.2em;font-size:19px;border-radius:999px;padding:12px 28px}
.chip.ind{background:var(--indigo)}.chip.sun{background:var(--sun);color:var(--ink)}
.chip.mlc{font:700 40px var(--ml);letter-spacing:0;padding:10px 30px 14px;border-radius:999px}
.tile{position:absolute;border-radius:34px;display:grid;place-items:center;box-shadow:0 22px 34px -18px rgba(21,18,42,.35),inset 0 1px 0 rgba(255,255,255,.55)}
.ln{fill:none;stroke:var(--ink);stroke-width:3.2;stroke-linecap:round;stroke-linejoin:round}
.shade{position:absolute;inset:0;background:linear-gradient(0deg,rgba(14,8,40,.82) 0%,rgba(14,8,40,.5) 30%,rgba(14,8,40,0) 52%)}
.cap{position:absolute;left:80px;font-family:var(--serif);font-size:120px;line-height:1;color:#fff;white-space:nowrap;text-shadow:0 4px 30px rgba(0,0,0,.35)}
.cap.ml{font-family:var(--ml);font-size:104px;line-height:1.2}
.cap .it{color:#fff}
.hi{position:relative;z-index:0;display:inline-block;padding:0 .14em;color:var(--ink)!important;text-shadow:none}
.hi::before{content:'';position:absolute;inset:.1em -.02em .04em;background:var(--hilite);border-radius:16px;z-index:-1;transform-origin:0 50%;transform:scaleX(var(--hx,1))}
.cap:not(.ml) .hi{font-style:italic}
.spark{position:absolute;width:64px;height:64px}
#hud{position:absolute;inset:0;z-index:9;pointer-events:none;font:500 18px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:rgba(21,18,42,.78)}
#hud.dark{color:rgba(255,255,255,.85)}
#hud .c{position:absolute}
#hud .tl{left:56px;top:64px}#hud .tr{right:56px;top:64px;text-transform:none;letter-spacing:.08em}
#hud .bl{left:56px;bottom:58px;text-transform:none;letter-spacing:.06em}#hud .br{right:56px;bottom:58px;letter-spacing:.08em}
#hud .dia{color:var(--indigo)}
#prog{position:absolute;left:0;bottom:0;height:6px;width:0;background:var(--indigo)}
#prog::after{content:'';position:absolute;right:-7px;top:-4px;width:14px;height:14px;border-radius:50%;background:var(--indigo)}
#wipe{position:absolute;inset:0;z-index:7;pointer-events:none;opacity:0}
#wipe .wt{position:absolute;border-radius:34px;background:linear-gradient(135deg,var(--indigo-hi),var(--indigo) 50%,var(--indigo-lo));transform:scale(0)}
/* phone */
.phone{position:absolute;border-radius:70px;background:#0E0B1C;padding:16px;box-shadow:0 60px 100px -40px rgba(45,25,140,.6),0 12px 30px rgba(21,18,42,.25)}
.phone .scr{position:relative;width:100%;height:100%;border-radius:56px;overflow:hidden;background:#fff}
.phone .scr img{position:absolute;left:0;top:30px;width:100%;display:block;transform-origin:50% 72%}
.phone .notch{position:absolute;left:50%;top:30px;width:150px;height:40px;margin-left:-75px;border-radius:30px;background:#0E0B1C;z-index:2}
/* step rows */
.row{position:absolute;left:56px;display:flex;align-items:center;gap:26px}
.num{width:76px;height:76px;border-radius:50%;background:var(--indigo);color:#fff;display:grid;place-items:center;font:500 24px var(--mono)}
.file{display:flex;align-items:center;gap:16px;padding:14px 22px;border-radius:20px;background:#fff;box-shadow:0 10px 24px -14px rgba(21,18,42,.4);font:500 22px var(--mono)}
.bar{position:relative;width:170px;height:10px;border-radius:6px;background:rgba(21,18,42,.1);overflow:hidden}
.bar i{position:absolute;inset:0;background:var(--indigo);transform-origin:0 50%;transform:scaleX(0)}
.pill{position:absolute;left:80px;width:920px;height:132px;border-radius:999px;background:#fff;box-shadow:0 30px 60px -24px rgba(0,0,0,.5);display:flex;align-items:center;padding:0 22px;box-sizing:border-box;gap:22px}
.av{width:78px;height:78px;border-radius:50%;background:linear-gradient(135deg,var(--peach),var(--lav))}
.go{margin-left:auto;width:88px;height:88px;border-radius:50%;background:var(--indigo);display:grid;place-items:center}
.caret{display:inline-block;width:5px;height:64px;background:var(--indigo);vertical-align:middle;margin-left:6px}
</style></head>
<body>
<div id="edit" data-composition-id="edit" data-start="0" data-width="1080" data-height="1920" data-duration="26.1">
  <div id="bg"><div class="blob" id="bl1"></div><div class="blob" id="bl2"></div><div class="blob" id="bl3"></div><div class="blob" id="bl4"></div><div class="blob" id="bl5"></div></div>

  <div id="cam"><div id="camz">
    <video id="aroll" class="clip" data-start="0" data-duration="26.1" data-track-index="0" src="assets/aroll.mp4" muted playsinline></video>
  </div></div>

  <!-- S1 hook (OVER) -->
  <div class="clip scene" id="s1" data-start="0" data-duration="2.3" data-track-index="2">
    <div class="shade"></div>
    <div class="ab kick in" id="s1k" style="left:84px;top:1170px;color:rgba(255,255,255,.75)">no editor?</div>
    <div class="cap ml" style="top:1215px"><span style="position:relative;display:inline-block"><span class="w"><span class="wi">എഡിറ്റർ</span></span> <span class="w"><span class="wi">ഇല്ല</span></span><span class="strike" id="s1s"></span></span></div>
    <div class="cap" style="top:1390px"><span class="w"><span class="wi">don't</span></span> <span class="hi" id="s1h" style="--hx:0"><span class="w"><span class="wi">stop.</span></span></span></div>
    <svg class="spark in" id="s1sp" viewBox="0 0 40 40" style="left:640px;top:1360px"><path d="M20 2 C21 14 26 19 38 20 C26 21 21 26 20 38 C19 26 14 21 2 20 C14 19 19 14 20 2Z" fill="#EFD98F"/></svg>
  </div>

  <!-- S2 the trick (FULL, indigo card) -->
  <div class="clip scene" id="s2" data-start="2.2" data-duration="1.9" data-track-index="3">
    <div class="icard in" id="s2c" style="left:70px;top:500px;width:940px;height:800px">
      <div class="micro" style="right:50px;top:46px">kinetic type</div>
      <div class="micro" style="left:60px;bottom:46px">02 / the trick</div>
      <div class="ab hl md" style="left:70px;top:130px"><span class="w"><span class="wi">one</span></span> <span class="w"><span class="wi it">simple</span></span></div>
      <div class="ab hl" style="left:70px;top:260px;font-size:200px"><span class="w"><span class="wi it">trick.</span></span></div>
      <div class="ab ml" style="left:72px;top:520px;font-size:58px;color:rgba(255,255,255,.88)"><span class="w"><span class="wi">സിമ്പിൾ</span></span> <span class="w"><span class="wi">ഒരു</span></span> <span class="w"><span class="wi">പരിപാടി</span></span></div>
    </div>
    <div class="ab chip sun mlc in" id="s2c2" style="left:0;right:0;margin:auto;width:max-content;top:1350px">ഞാൻ പറഞ്ഞു തരാം ↓</div>
  </div>

  <!-- S3 instagram (CARD) -->
  <div class="clip scene" id="s3" data-start="4.0" data-duration="2.7" data-track-index="2">
    <div class="ab kick in" id="s3k" style="left:84px;top:250px">open instagram right now</div>
    <div class="ab ml it" id="s3ml" style="left:80px;top:300px;font-size:100px;color:var(--indigo)"><span class="w"><span class="wi">ഇൻസ്റ്റാഗ്രാം</span></span></div>
    <div class="ab hl md" id="s3h1" style="left:80px;top:300px"><span class="w"><span class="wi">it's</span></span> <span class="w"><span class="wi">all</span></span> <span class="w"><span class="wi it">motion</span></span></div>
    <div class="ab hl md" id="s3h2" style="left:80px;top:410px"><span class="w"><span class="wi">graphics</span></span><span class="pdot in" id="s3d"></span></div>
    <div id="s3r"></div>
  </div>

  <!-- S4 two steps (FULL) -->
  <div class="clip scene" id="s4" data-start="6.6" data-duration="3.5" data-track-index="3">
    <div class="ab kick in" id="s4k" style="left:0;right:0;text-align:center;top:420px">zero complication</div>
    <div class="ab ml" style="left:0;right:0;text-align:center;top:460px;font-size:92px;color:var(--ink)"><span style="position:relative;display:inline-block"><span class="w"><span class="wi">കോംപ്ലിക്കേഷൻ</span></span><span class="strike" id="s4s"></span></span></div>
    <div class="ab hl" style="left:0;right:0;text-align:center;top:680px"><span class="w"><span class="wi">just</span></span> <span class="w"><span class="wi it">two</span></span> <span class="w"><span class="wi">steps</span></span><span class="pdot in" id="s4d"></span></div>
    <div class="ab chip ind mlc in" id="s4c" style="left:0;right:0;margin:auto;width:max-content;top:850px">രണ്ടേ സ്റ്റെപ്പിൽ</div>
    <div class="tile in" id="s4t1" style="left:150px;top:1060px;width:350px;height:330px;background:var(--lav)"><span class="hl it" style="font-size:190px">01</span></div>
    <div class="tile in" id="s4t2" style="left:580px;top:1060px;width:350px;height:330px;background:var(--peach)"><span class="hl it" style="font-size:190px">02</span></div>
  </div>

  <!-- S5a this video too (OVER) -->
  <div class="clip scene" id="s5a" data-start="9.8" data-duration="1.5" data-track-index="2">
    <div class="shade"></div>
    <div class="ab kick in" id="s5k" style="left:84px;top:1240px;color:rgba(255,255,255,.75)">including this one</div>
    <div class="cap ml" style="top:1290px"><span class="w"><span class="wi">ഈ</span></span> <span class="hi" id="s5h" style="--hx:0"><span class="w"><span class="wi">വീഡിയോ</span></span></span> <span class="w"><span class="wi">അടക്കം</span></span></div>
  </div>

  <!-- S5b my profile (phone) -->
  <div class="clip scene" id="s5b" data-start="11.1" data-duration="3.1" data-track-index="3">
    <div class="ab kick in" id="s5bk" style="left:84px;top:240px">every reel on my profile</div>
    <div class="phone in" id="ph" style="left:452px;top:300px;width:560px;height:1160px"><div class="notch"></div><div class="scr"><img id="phimg" src="assets/reels.jpg"></div></div>
    <div class="ab chip ind up in" id="phhl" style="left:520px;top:1490px">@farshanedits · reels</div>
    <div class="ab hl md" style="left:70px;top:420px;line-height:1.02"><span class="w"><span class="wi">one</span></span></div>
    <div class="ab hl md" style="left:70px;top:530px"><span class="w"><span class="wi it">method</span></span><span class="pdot in" id="s5d"></span></div>
    <div class="ab chip ind mlc in" id="s5c" style="left:70px;top:700px;font-size:34px">ഒരു മെത്തേഡ്</div>
  </div>

  <!-- S6 all Claude (FULL) -->
  <div class="clip scene" id="s6" data-start="14.1" data-duration="2.3" data-track-index="2">
    <div class="tile in" id="t1" style="left:110px;top:400px;width:210px;height:196px;background:var(--lav)"><svg viewBox="0 0 54 54" width="84" height="84"><path class="ln" d="M14 16a5 5 0 1 0 0 .1M14 38a5 5 0 1 0 0 .1M18 19l22 18M18 35l22-18"/></svg></div>
    <div class="ab hl md" style="left:370px;top:430px"><span class="w"><span class="wi">full</span></span> <span class="w"><span class="wi it">cuts</span></span></div>
    <div class="tile in" id="t2" style="left:110px;top:640px;width:210px;height:196px;background:var(--mint)"><svg viewBox="0 0 54 54" width="84" height="84"><path class="ln" d="M12 42 C 22 42 22 12 42 12"/><circle cx="12" cy="42" r="3.5" fill="#15122A"/><circle cx="42" cy="12" r="3.5" fill="#5536EE"/></svg></div>
    <div class="ab hl md" style="left:370px;top:670px"><span class="w"><span class="wi it">motion</span></span> <span class="w"><span class="wi">gfx</span></span></div>
    <div class="tile in" id="t3" style="left:110px;top:880px;width:210px;height:196px;background:var(--sun)"><svg viewBox="0 0 54 54" width="84" height="84"><path class="ln" d="M10 27h4M18 18v18M24 12v30M30 18v18M36 22v10M42 27h3"/></svg></div>
    <div class="ab hl md" style="left:370px;top:910px"><span class="w"><span class="wi">sound</span></span> <span class="w"><span class="wi it">fx</span></span></div>
    <div class="ab kick in" id="s6k" style="left:0;right:0;text-align:center;top:1190px">all of it</div>
    <div class="ab hl xl" style="left:0;right:0;text-align:center;top:1220px;font-style:italic"><span class="w"><span class="wi">Claude</span></span><span class="pdot in" id="s6d"></span></div>
    <div class="ab chip sun mlc in" id="s6c" style="left:0;right:0;margin:auto;width:max-content;top:1450px">എല്ലാം ക്ലൗഡ്</div>
  </div>

  <!-- S7 very simple (OVER) -->
  <div class="clip scene" id="s7" data-start="16.2" data-duration="1.3" data-track-index="3">
    <div class="shade"></div>
    <div class="ab kick in" id="s7k" style="left:84px;top:1250px;color:rgba(255,255,255,.75)">honestly</div>
    <div class="cap ml" style="top:1300px"><span class="w"><span class="wi">വളരെ</span></span> <span class="hi" id="s7h" style="--hx:0"><span class="w"><span class="wi">സിമ്പിൾ</span></span></span></div>
    <svg class="spark in" id="s7sp" viewBox="0 0 40 40" style="left:880px;top:1270px"><path d="M20 2 C21 14 26 19 38 20 C26 21 21 26 20 38 C19 26 14 21 2 20 C14 19 19 14 20 2Z" fill="#EFD98F"/></svg>
  </div>

  <!-- S8 the steps (CARD + chat card) -->
  <div class="clip scene" id="s8" data-start="17.3" data-duration="4.0" data-track-index="2">
    <div class="pcard in" id="s8p" style="left:70px;top:190px;width:940px;height:770px">
      <div class="ab" style="left:56px;top:46px;display:flex;align-items:center;gap:16px"><span style="color:var(--indigo);font-size:40px">✦</span><span class="hl" style="font-size:58px">Claude</span></div>
      <div class="micro" style="right:56px;top:66px;color:rgba(21,18,42,.4)">new chat</div>
      <div class="row in" id="r1" style="top:170px"><div class="num">01</div><span class="hl" style="font-size:84px">open <span class="it">Claude</span></span></div>
      <div class="row in" id="r2" style="top:330px"><div class="num">02</div><span class="hl" style="font-size:84px">upload</span><div class="file"><span style="color:var(--indigo)">▶</span>2.mp4<div class="bar"><i id="r2b"></i></div></div></div>
      <div class="row in" id="r3" style="top:490px"><div class="num">03</div><span class="hl" style="font-size:84px">skill</span><span class="chip" id="r3t" style="font-size:24px">/</span></div>
      <div class="ab hl it in" id="s8done" style="right:60px;top:600px;font-size:150px">done<span class="pdot"></span></div>
    </div>
    <div class="ab chip sun mlc in" id="s8c" style="left:90px;top:900px">അത്രേയുള്ളൂ</div>
  </div>

  <!-- S9 your turn (OVER + comment CTA) -->
  <div class="clip scene" id="s9" data-start="21.1" data-duration="5.0" data-track-index="3">
    <div class="shade"></div>
    <div class="ab kick in" id="s9k" style="left:84px;top:1150px;color:rgba(255,255,255,.75)">want this style?</div>
    <div class="cap ml" id="s9l1" style="top:1195px;font-size:96px"><span class="w"><span class="wi">ഹൈ-എൻഡ്</span></span></div>
    <div class="cap ml" id="s9l2" style="top:1330px;font-size:96px"><span class="hi" id="s9h" style="--hx:0"><span class="w"><span class="wi">മോഷൻ</span></span></span> <span class="w"><span class="wi">ഗ്രാഫിക്സ്</span></span></div>
    <div class="ab chip sun mlc in" id="s9dm" style="left:84px;top:1180px">ഞാൻ DM ചെയ്തു തരാം ✉</div>
    <div class="pill in" id="s9p" style="top:1300px"><div class="av"></div><span style="font:500 26px var(--mono);color:#9A94AE">comment</span><span class="hl it" style="font-size:78px;color:var(--indigo)" id="s9t"></span><span class="caret" id="s9c"></span><div class="go" id="s9go"><svg viewBox="0 0 40 40" width="40" height="40"><path d="M10 20h20M22 12l8 8-8 8" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg></div></div>
    <div class="ab kick in" id="s9k2" style="left:0;right:0;text-align:center;top:1470px;color:rgba(255,255,255,.8)">comment "skill" ↓ i'll dm you</div>
    <svg class="spark in" id="s9sp1" viewBox="0 0 40 40" style="left:40px;top:1250px"><path d="M20 2 C21 14 26 19 38 20 C26 21 21 26 20 38 C19 26 14 21 2 20 C14 19 19 14 20 2Z" fill="#EFD98F"/></svg>
    <svg class="spark in" id="s9sp2" viewBox="0 0 40 40" style="left:960px;top:1420px"><path d="M20 2 C21 14 26 19 38 20 C26 21 21 26 20 38 C19 26 14 21 2 20 C14 19 19 14 20 2Z" fill="#fff"/></svg>
  </div>

  <div id="wipe"></div>
  <svg id="grain" width="1080" height="1920"><filter id="gn"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="7"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0"/></filter><rect width="100%" height="100%" filter="url(#gn)"/></svg>
  <div id="hud">
    <div class="c tl">Claude <span class="dia">✦</span> edit reel '26</div>
    <div class="c tr" id="hudScene">01 / 06 — the hook</div>
    <div class="c bl">edited by claude · html · gsap</div>
    <div class="c br" id="hudTc">00:00:00 · 30 fps</div>
    <div id="prog"></div>
  </div>
  <audio id="mix" data-start="0" data-duration="26.1" data-track-index="9" src="assets/mix.wav"></audio>

<script src="vendor/gsap.min.js"></script>
<script>
const DUR=parseFloat(document.getElementById('edit').dataset.duration);
const q=s=>document.querySelector(s), qa=(s,r=document)=>[...r.querySelectorAll(s)];
const tl=gsap.timeline({paused:true});
const IR={immediateRender:false};
const E={o:'expo.out',i:'power3.in',io:'expo.inOut',spring:'back.out(1.7)'};
gsap.set(qa('.wi'),{yPercent:115});
let _s=11;const rnd=()=>(_s=(_s*16807)%2147483647)/2147483647;
// ---- primitives ----
const slot=(sel,t,o={})=>tl.fromTo(typeof sel==='string'?qa(sel):sel,{yPercent:115,rotation:o.rot??5},{yPercent:0,rotation:0,duration:o.d??0.7,ease:o.ease??'back.out(1.5)',stagger:o.st??0.06,...IR},t);
const slotOut=(sel,t,o={})=>tl.to(typeof sel==='string'?qa(sel):sel,{yPercent:o.y??-115,duration:o.d??0.32,ease:E.i,stagger:o.st??0.03},t);
const fadeIn=(el,t,o={})=>tl.fromTo(el,{opacity:0,y:o.y??14,filter:`blur(${o.b??8}px)`},{opacity:1,y:0,filter:'blur(0px)',duration:o.d??0.5,ease:E.o,...IR},t);
const fadeOut=(el,t,o={})=>tl.to(el,{opacity:0,filter:`blur(${o.b??10}px)`,y:o.y??-10,duration:o.d??0.3,ease:E.i},t);
const pop=(el,t,o={})=>tl.fromTo(el,{opacity:0,scale:o.s??0,rotation:o.r??0},{opacity:1,scale:1,rotation:0,duration:o.d??0.55,ease:o.ease??'back.out(2.2)',stagger:o.st??0,...IR},t);
const cardIn=(el,t,o={})=>tl.fromTo(el,{opacity:0,scale:o.s??0.62,y:o.y??80,rotation:o.r0??-7,filter:'blur(10px)'},{opacity:1,scale:1,y:0,rotation:o.r1??0,filter:'blur(0px)',duration:o.d??0.8,ease:E.spring,...IR},t);
const cardOut=(el,t,o={})=>tl.to(el,{opacity:0,scale:o.s??0.9,y:o.y??-60,x:o.x??0,rotation:o.r??3,filter:'blur(12px)',duration:o.d??0.36,ease:E.i},t);
const strike=(el,t,d=0.38)=>tl.fromTo(el,{scaleX:0,rotation:-3},{scaleX:1,rotation:-3,duration:d,ease:'power3.out',...IR},t);
const hilite=(el,t,d=0.35)=>{el=q(el);const o={v:0};tl.fromTo(o,{v:0},{v:1,duration:d,ease:'power3.out',onUpdate:()=>el.style.setProperty('--hx',o.v),...IR},t)};
const twinkle=(el,t)=>{pop(el,t,{r:-90,d:0.6});tl.to(el,{scale:0.75,duration:0.5,ease:'sine.inOut'},t+0.65);tl.to(el,{scale:1,duration:0.5,ease:'sine.inOut'},t+1.15)};
const typeOn=(el,t,text,cps=22)=>{el=q(el);const o={n:0};tl.fromTo(o,{n:0},{n:text.length,duration:text.length/cps,ease:'none',onUpdate:()=>{el.textContent=text.slice(0,Math.round(o.n))},...IR},t)};
const sceneOut=(el,t)=>tl.to(el,{opacity:0,filter:'blur(14px)',scale:1.04,duration:0.32,ease:E.i},t);
const W=s=>qa(s+' .wi');
// ---- camera ----
const CAM={
  full :{left:0, top:0,   width:1080,height:1920,borderRadius:0, rotation:0},
  cardB:{left:70,top:1010,width:940, height:720, borderRadius:36,rotation:-2},
  small:{left:60,top:1100,width:360, height:470, borderRadius:30,rotation:-4},
};
const camTo=(t,m,d=0.85)=>tl.to('#cam',{...CAM[m],duration:d,ease:E.io},t);
const camSet=(t,m)=>tl.set('#cam',{...CAM[m]},t);
const camBack=(t)=>{camSet(t,'full');tl.fromTo('#cam',{opacity:0,scale:1.12,filter:'blur(16px)'},{opacity:1,scale:1,filter:'blur(0px)',duration:0.55,ease:E.o,...IR},t)};
const camZoom=(t0,t1,z0,z1)=>tl.fromTo('#camz',{scale:z0},{scale:z1,duration:t1-t0,ease:'none',...IR},t0);
// ---- tile wipe ----
(()=>{const C=5,R=8,g=14,w=(1080-g*(C+1))/C,h=(1920-g*(R+1))/R,wp=q('#wipe');
  for(let r=0;r<R;r++)for(let c=0;c<C;c++){const d=document.createElement('div');d.className='wt';
    d.style.cssText=`left:${g+c*(w+g)}px;top:${g+r*(h+g)}px;width:${w}px;height:${h}px`;d.dataset.k=rnd().toFixed(4);wp.appendChild(d);}})();
const tileWipe=(t)=>{tl.set('#wipe',{opacity:1},t); tl.set('#wipe',{opacity:0},t+1.05);
  qa('#wipe .wt').forEach(el=>{const k=+el.dataset.k;
    tl.fromTo(el,{scale:0,rotation:-12},{scale:1.04,rotation:0,duration:0.34,ease:'back.out(1.3)',...IR},t+k*0.18);
    tl.to(el,{scale:0,rotation:10,duration:0.3,ease:'power3.in'},t+0.56+k*0.18);});
  return t+0.52;};
// ---- HUD + background driver ----
const SCENES=[[0,'01 / 06 — the hook'],[2.25,'02 / 06 — the trick'],[6.62,'03 / 06 — two steps'],[9.85,'04 / 06 — the proof'],[17.3,'05 / 06 — the steps'],[21.15,'06 / 06 — your turn']];
const DARK=[[0,2.25],[9.85,11.15],[16.25,17.5],[21.15,99]];
const pad=n=>String(Math.floor(n)).padStart(2,'0');
const drv={t:0};
tl.fromTo(drv,{t:0},{t:DUR,duration:DUR,ease:'none',...IR,onUpdate:()=>{const t=drv.t;
  q('#prog').style.width=(t/DUR*100)+'%';
  q('#hudTc').textContent=`${pad(t/60)}:${pad(t%60)}:${pad((t%1)*30)} · 30 fps`;
  let lab=SCENES[0][1];for(const [s,l] of SCENES)if(t>=s)lab=l;q('#hudScene').textContent=lab;
  q('#hud').classList.toggle('dark',DARK.some(([a,b])=>t>=a&&t<b));
  [['#bl1',40,30,.11],['#bl2',-50,35,.09],['#bl3',35,-40,.08],['#bl4',-45,-30,.1]].forEach(([s,ax,ay,f],i)=>{q(s).style.transform=`translate(${Math.sin(t*f*6.28+i)*ax}px,${Math.cos(t*f*6.28+i*2)*ay}px) scale(${1+Math.sin(t*f*3+i)*.05})`});
}},0);

// ================= BEATS (times from the script alignment) =================
// S1 hook 0–2.25: "എഡിറ്റർ ഇല്ല എന്ന് പറഞ്ഞിട്ട് | നിങ്ങൾ ആരും വീഡിയോ ചെയ്യാതിരിക്കേണ്ട"
camZoom(0,2.3,1.0,1.06);
fadeIn('#s1k',0.05);
slot(W('#s1 .cap.ml'),0.1,{st:0.2});
strike('#s1s',0.95);
slot(qa('#s1 .cap')[1].querySelectorAll(':scope > .w .wi'),1.2);
hilite('#s1h',1.45); slot('#s1h .wi',1.5,{ease:'back.out(2)'}); twinkle('#s1sp',1.6);
const sw1=tileWipe(1.73);                       // covered at 2.25
tl.set('#cam',{opacity:0},sw1);
// S2 trick 2.25–4.0: "സിമ്പിൾ ഒരു പരിപാടി വന്നിട്ടുണ്ട് | ഞാൻ പറഞ്ഞു തരാം"
cardIn('#s2c',2.27,{r0:-4,s:0.85,y:40});
slot(W('#s2c .hl.md'),2.4,{st:0.12});
slot([qa('#s2c .hl')[1].querySelector('.wi')],2.75,{rot:0,ease:'back.out(1.8)'});
slot(W('#s2c .ml'),2.55,{st:0.18,rot:0});
pop('#s2c2',3.3,{s:0.5});
cardOut('#s2c',3.85,{x:-80,r:-4}); fadeOut('#s2c2',3.85);
// S3 instagram 4.0–6.6 (speaker card) : "ഇൻസ്റ്റാഗ്രാം ഇപ്പോൾ തുറന്നാൽ | മൊത്തം മോഷൻ ഗ്രാഫിക്സിന്റെ വീഡിയോ ആണ്"
camSet(3.9,'cardB'); tl.set('#cam',{opacity:0},3.9); cardIn('#cam',3.95,{r0:-9,r1:-2,s:0.7,y:140});
camZoom(3.95,6.6,1.0,1.05);
fadeIn('#s3k',4.1); slot(W('#s3ml'),4.15,{rot:0});
slotOut(W('#s3ml'),5.2,{y:-170});
slot(W('#s3h1'),5.35,{st:0.15}); slot(W('#s3h2'),5.95); pop('#s3d',6.25,{ease:'back.out(3)'});
(()=>{const r=q('#s3r');const cols=['--lav','--peach','--mint','--sun','--sky'];
  for(let i=0;i<5;i++){const d=document.createElement('div');d.className='tile in';
    d.style.cssText=`left:${80+i*190}px;top:${640+(i%2)*40}px;width:160px;height:250px;border-radius:26px;background:var(${cols[i]})`;
    d.innerHTML='<svg viewBox="0 0 40 40" width="44" height="44"><path d="M14 10 L30 20 L14 30Z" fill="#15122A"/></svg>';r.appendChild(d);}})();
pop(qa('#s3r .tile'),5.4,{s:0.3,r:-10,st:0.06,d:0.6});
tl.to(qa('#s3r .tile'),{y:-22,duration:1.2,ease:'sine.inOut',stagger:{each:0.06,from:'center'}},5.9);
const sw2=tileWipe(6.1);                        // covered at 6.62
tl.set('#cam',{opacity:0},sw2);
// S4 two steps 6.62–9.85: "ഒരു കോംപ്ലിക്കേഷനും ഇല്ലാതെ | രണ്ടേ സ്റ്റെപ്പിൽ | അത് എങ്ങനെ ചെയ്യണം എന്ന് ഞാൻ പറഞ്ഞു തരാം"
fadeIn('#s4k',6.8); slot(W('#s4 .ml'),6.95,{rot:0}); strike('#s4s',7.5);
slot(qa('#s4 .hl')[0].querySelectorAll('.wi'),7.9,{st:0.14}); pop('#s4d',8.35,{ease:'back.out(3)'});
pop('#s4c',8.0,{s:0.5});
pop('#s4t1',8.55,{s:0.3,r:-14,d:0.65}); pop('#s4t2',8.85,{s:0.3,r:14,d:0.65});
tl.to(['#s4t1','#s4t2'],{y:-20,duration:0.9,ease:'sine.inOut',stagger:0.15},9.0);
sceneOut('#s4',9.6);
// S5a 9.85–11.15 (OVER): "സോ, നിങ്ങൾ ഈ കാണുന്ന വീഡിയോ അടക്കം"
camBack(9.75); camZoom(9.75,11.15,1.12,1.0);
fadeIn('#s5k',10.0);
slot(qa('#s5a .cap')[0].querySelectorAll(':scope > .w .wi')[0],10.3);
hilite('#s5h',10.45); slot('#s5h .wi',10.5,{ease:'back.out(2)'});
slot(qa('#s5a .cap')[0].querySelectorAll(':scope > .w .wi')[1],10.8);
fadeOut(['#s5k','#s5a .cap','#s5a .shade'],11.05);
// S5b 11.15–14.1: "എന്റെ പ്രൊഫൈലിലെ എല്ലാ വീഡിയോക്കും | ഞാൻ ചെയ്തത് ഈ ഒരു മെത്തേഡ് വെച്ചിട്ടാണ്"
camTo(11.1,'small',0.8);
cardIn('#ph',11.2,{r0:8,r1:2,s:0.7,y:160}); fadeIn('#s5bk',11.3);
tl.fromTo('#phimg',{scale:1},{scale:1.32,duration:2.4,ease:'power2.inOut',...IR},11.7);
pop('#phhl',12.0,{s:0.6,ease:'back.out(2.4)'});
slot([qa('#s5b .hl')[0].querySelector('.wi')],12.45);
slot([qa('#s5b .hl')[1].querySelector('.wi')],12.75,{rot:0,ease:'back.out(1.8)'}); pop('#s5d',13.2,{ease:'back.out(3)'});
pop('#s5c',13.3,{s:0.5});
const sw3=tileWipe(13.63);                      // covered at 14.15
tl.set('#cam',{opacity:0},sw3);
// S6 14.15–16.3: "ഫുൾ കട്സും | മോഷൻ ഗ്രാഫിക്സും | സൗണ്ട് എഫക്ട്സും | എല്ലാം ക്ലൗഡ് ആണ്"
const R6=qa('#s6 .hl.md');
pop('#t1',14.2,{s:0.3,r:-12}); slot(R6[0].querySelectorAll('.wi'),14.25,{st:0.1});
pop('#t2',14.75,{s:0.3,r:12}); slot(R6[1].querySelectorAll('.wi'),14.8,{st:0.1});
pop('#t3',15.35,{s:0.3,r:-12}); slot(R6[2].querySelectorAll('.wi'),15.4,{st:0.1});
fadeIn('#s6k',15.75); slot(qa('#s6 .hl.xl .wi'),15.85,{d:0.8,rot:6,ease:'back.out(1.4)'}); pop('#s6d',16.05,{ease:'back.out(3.5)'});
pop('#s6c',15.95,{s:0.5});
sceneOut('#s6',16.25);
// S7 16.3–17.45 (OVER): "സോ, സംഭവം വളരെ സിമ്പിൾ ആണ്"
camBack(16.2); camZoom(16.2,17.45,1.1,1.0);
fadeIn('#s7k',16.35);
slot(qa('#s7 .cap')[0].querySelectorAll(':scope > .w .wi'),16.6);
hilite('#s7h',16.8); slot('#s7h .wi',16.85,{ease:'back.out(2)'}); twinkle('#s7sp',16.95);
fadeOut(['#s7k','#s7 .cap','#s7 .shade','#s7sp'],17.3);
// S8 17.45–21.15: "ക്ലൗഡ് ഓപ്പൺ ചെയ്യുക | നിങ്ങളുടെ വീഡിയോ അപ്‌ലോഡ് ചെയ്യുക | സ്കിൽ സെലക്ട് ചെയ്യുക | ഡൺ | അത്രേയുള്ളൂ"
camTo(17.3,'cardB',0.8);
cardIn('#s8p',17.35,{r0:-5,s:0.8,y:-60});
fadeIn('#r1',17.5,{x:0,y:30,b:10});
fadeIn('#r2',18.6,{y:30}); tl.fromTo('#r2b',{scaleX:0},{scaleX:1,duration:0.9,ease:'power2.inOut',...IR},18.8);
fadeIn('#r3',19.75,{y:30}); typeOn('#r3t',19.9,'/pastel-indigo-motion',30);
pop('#s8done',20.6,{s:0.4,r:-8,ease:'back.out(2.4)'});
pop('#s8c',20.75,{s:0.5});
cardOut('#s8p',21.0,{y:-80}); fadeOut('#s8c',21.0);
// S9 21.15–26.1 (OVER): "ഇതുപോലത്തെ ഹൈ-എൻഡ് മോഷൻ ഗ്രാഫിക്സിന്റെ സ്കിൽ വേണമെന്നുണ്ടെങ്കിൽ | സ്കിൽ എന്ന് കമന്റ് ചെയ്യുക | ഞാൻ ഡിഎം ചെയ്തതരാം"
camTo(21.1,'full',0.75); camZoom(21.85,26.1,1.0,1.07);
fadeIn('#s9k',21.4);
slot(qa('#s9l1 .wi'),21.75); hilite('#s9h',22.0); slot('#s9h .wi',22.05,{ease:'back.out(2)'});
slot(qa('#s9l2 > .w .wi'),22.35);
fadeOut(['#s9k','#s9l1','#s9l2'],23.45);
cardIn('#s9p',23.55,{r0:-3,s:0.85,y:50});
typeOn('#s9t',23.85,'“SKILL”',14);
tl.fromTo('#s9c',{opacity:1},{opacity:0,duration:0.25,ease:'none',...IR},24.6); tl.to('#s9c',{opacity:1,duration:0.01},24.85); tl.to('#s9c',{opacity:0,duration:0.01},25.1); tl.to('#s9c',{opacity:1,duration:0.01},25.35);tl.to('#s9c',{opacity:0,duration:0.01},25.6);
pop('#s9go',24.35,{s:0.4,ease:'back.out(3)'}); tl.to('#s9go',{scale:1.12,duration:0.35,ease:'sine.inOut'},24.95); tl.to('#s9go',{scale:1,duration:0.35,ease:'sine.inOut'},25.3);
pop('#s9dm',24.75,{s:0.5,r:-6}); fadeIn('#s9k2',24.9);
twinkle('#s9sp1',24.5); twinkle('#s9sp2',24.8);

tl.set({}, {}, DUR);
window.__timelines=window.__timelines||{}; window.__timelines.edit=tl;
window.hfSeek=t=>{qa('.clip').forEach(el=>{if(el.tagName==='VIDEO')return;const s=+el.dataset.start,d=+el.dataset.duration;el.style.display=(t>=s&&t<s+d)?'':'none'});tl.seek(t,false)};
</script>
</div>
</body></html>
```

## Scripts (write into the working folder)

### align.py — script-to-audio timing (no ASR)
```python
# python3 align.py <audio 16k mono wav> <script.txt> <out phrases.json>
# Times a spoken script without speech recognition (works for Malayalam, English, Manglish).
# Sentences end at . ? ! or a new line; phrases split further at , or |.
# Pass 1 snaps sentence ends to the deepest pauses; pass 2 spreads phrases inside each sentence
# by syllable count and snaps them to nearby small pauses. Expect +-0.2 s; check by ear/lips.
import wave, json, sys, re, unicodedata, numpy as np
w=wave.open(sys.argv[1]); sr=w.getframerate(); a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16)/32768.0
if w.getnchannels()>1: a=a.reshape(-1,w.getnchannels()).mean(1)
H=int(sr*0.025); E=np.array([20*np.log10(np.sqrt(np.mean(a[i:i+H]**2))+1e-9) for i in range(0,len(a)-H,H)]); T=np.arange(len(E))*0.025
noise=np.percentile(E,3); loud=E>noise+15                       # speech = 15 dB over room tone
t0=T[np.argmax(loud)]; t1=T[len(loud)-1-np.argmax(loud[::-1])]+0.025
lvl=np.percentile(E[loud],50)
P=[(T[i],lvl-E[i]) for i in range(2,len(E)-2) if E[i]<lvl-12 and E[i]<=E[i-1] and E[i]<=E[i+1] and t0+0.2<T[i]<t1-0.2]
# onsets: quiet stretch followed by a jump of 10+ dB (a new sentence that starts without a clean pause)
for i in range(8,len(E)-4):
    pre=E[i-8:i].mean(); jump=E[i:i+4].max()-pre
    if pre<lvl-4 and jump>10 and t0+0.2<T[i]<t1-0.2: P.append((T[i],jump*0.7))
def syl(s):
    n=0
    for i,c in enumerate(s):
        if unicodedata.category(c)=='Lo' and not (i+1<len(s) and s[i+1]=='്'): n+=1   # Indic: consonant clusters count once
    n+=len(re.findall(r'[aeiouy]+',s.lower()))                                          # Latin words
    return max(1,n)
def split(s,pat):
    out=[]
    for p in [p.strip() for p in re.split(pat,s) if p.strip()]:
        if out and len(out[-1].replace(' ',''))<=3: out[-1]+=' '+p                       # merge tiny phrases ("so") into the next
        else: out.append(p)
    return out
def place(items,a,b,win,depth_w):
    # sequential: estimate each boundary from the remaining syllables after the last snapped one, then snap it
    n=[sum(syl(x) for x in it) if isinstance(it,list) else syl(it) for it in items]
    B=[a]
    for k in range(len(n)-1):
        est=B[-1]+(b-B[-1])*n[k]/sum(n[k:])
        c=[(abs(t-est)-depth_w*d,t) for t,d in P if abs(t-est)<win and B[-1]+0.3<t<b-0.3]
        B.append(min(c)[1] if c else est)
    return B+[b]
text=open(sys.argv[2]).read()
sents=[split(s,r'[,|]+') for s in split(text,r'[.?!\n]+')]
SB=place(sents,t0,t1,1.2,0.03)                                   # pass 1: sentences, wide window, prefer deep pauses
out=[]
for k,ph in enumerate(sents):
    PB=place(ph,SB[k],SB[k+1],0.4,0.01) if len(ph)>1 else [SB[k],SB[k+1]]
    for j,p in enumerate(ph):
        ws=p.split(); n=[syl(x) for x in ws]; c=np.concatenate([[0],np.cumsum(n)])/sum(n); a0,a1=PB[j],PB[j+1]
        out.append({'s':k,'t0':round(a0,2),'t1':round(a1,2),'text':p,
                    'words':[{'w':x,'t':round(a0+c[i]*(a1-a0),2)} for i,x in enumerate(ws)]})
json.dump(out,open(sys.argv[3],'w'),ensure_ascii=False,indent=1)
for o in out: print(f"{o['s']:2d} {o['t0']:6.2f}-{o['t1']:6.2f}  "+'  '.join(f"{w['w']}@{w['t']}" for w in o['words']))
```
On the first reel this landed every sentence boundary within ~0.3 s of hand timing.

### sfx.py — synthesized SFX bed
```python
# python3 sfx.py sfx.json DUR -> sfx.wav ; events [[t,"whoosh|pop|tick|thump|swipe",dB],...]
import numpy as np, json, sys
from scipy import signal
from scipy.io import wavfile
SR=48000; rng=np.random.default_rng(7); DUR=float(sys.argv[2])
def env(n,a,tau): t=np.arange(n)/SR; return np.where(t<a,(t/a)**2,np.exp(-(t-a)/tau))
def filt(x,k,f,o=2): return signal.sosfilt(signal.butter(o,f,btype=k,fs=SR,output='sos'),x)
def nm(x): return x/(np.max(np.abs(x))+1e-9)
def st(y,p=0): return np.stack([y*(1-p),y*(1+p)],1)
def whoosh(dur=0.36,f0=450,f1=3000,peak=0.6):
    n=int(dur*SR); x=rng.standard_normal(n+4096); f,t,Z=signal.stft(x,SR,nperseg=1024,noverlap=768)
    fc=f0*(f1/f0)**np.clip(t/dur,0,1); M=np.exp(-0.5*(np.log(np.maximum(f[:,None],1)/fc[None,:])/0.45)**2)
    _,y=signal.istft(Z*M,SR,nperseg=1024,noverlap=768); y=y[:n]; u=np.arange(n)/n
    y=nm(y*np.where(u<peak,(u/peak)**2.2,np.exp(-(u-peak)/0.12))); p=np.linspace(-.3,.3,n); return np.stack([y*(1-p),y*(1+p)],1)*.8
def pop(f0=700,f1=320,dur=0.1):
    n=int(dur*SR); t=np.arange(n)/SR; f=f1+(f0-f1)*np.exp(-t/0.016)
    return st(nm(filt(np.sin(2*np.pi*np.cumsum(f)/SR)*env(n,0.002,0.026),'low',6000)))
def tick(dur=0.05):
    n=int(dur*SR); return st(nm(filt(rng.standard_normal(n),'band',[2500,8000])*env(n,0.0005,0.006)))
def thump(dur=0.35):
    n=int(dur*SR); t=np.arange(n)/SR; f=46+60*np.exp(-t/0.03)
    return st(nm(np.sin(2*np.pi*np.cumsum(f)/SR)*env(n,0.003,0.09)))
def swipe(dur=0.2):
    n=int(dur*SR); return st(nm(filt(rng.standard_normal(n),'band',[1800,7000])*np.sin(np.pi*np.arange(n)/n)**2))
G=dict(whoosh=whoosh,pop=pop,tick=tick,thump=thump,swipe=swipe)
N=int(DUR*SR); out=np.zeros((N+SR,2))
for t,k,db,*kw in json.load(open(sys.argv[1])):
    x=G[k](**(kw[0] if kw else {})); x=x/np.max(np.abs(x))*10**(db/20); i=int(t*SR); out[i:i+len(x)]+=x[:len(out)-i]
wavfile.write('sfx.wav',SR,out[:N].astype(np.float32))
```

Mix (voice compressed and normalised to -14 LUFS, SFX under it):
```bash
ffmpeg -y -i src.mp4 -vn -ac 2 -ar 48000 voice.wav
ffmpeg -y -i voice.wav -af "highpass=f=70,acompressor=threshold=-24dB:ratio=2.2:attack=8:release=140:makeup=2" -ar 48000 v1.wav
X=$(ffmpeg -i v1.wav -af loudnorm=print_format=summary -f null - 2>&1 | grep "Input Integrated" | awk '{print $3}')
ffmpeg -y -i v1.wav -af "volume=$(python3 -c "print(-14-($X)+0.2)")dB,alimiter=limit=0.82:level=disabled" -ar 48000 vp.wav
ffmpeg -y -i vp.wav -i sfx.wav -filter_complex "[0:a][1:a]amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.84:level=disabled[a]" -map "[a]" -ar 48000 reel/assets/mix.wav
```

### render_fallback.py
```python
# python3 render_fallback.py <project> <out.mp4> [fps] [t1,t2,...]
# Renders project/index.html frame by frame with Playwright (when the HyperFrames CLI is unavailable).
# With a time list it writes snapshots <out>_<t>.jpg instead of a video. Muxes assets/mix.wav if present.
import sys, re, subprocess, pathlib
from playwright.sync_api import sync_playwright
P=pathlib.Path(sys.argv[1]).resolve(); OUT=sys.argv[2]; FPS=int(sys.argv[3]) if len(sys.argv)>3 else 30
html=open(P/'index.html').read()
D=float(re.search(r'id="edit"[^>]*data-duration="([\d.]+)"',html).group(1))
W=int(re.search(r'data-width="(\d+)"',html).group(1)); H=int(re.search(r'data-height="(\d+)"',html).group(1))
fr=P/'_frames'; fr.mkdir(exist_ok=True); [f.unlink() for f in fr.glob('*.jpg')]
subprocess.run(['ffmpeg','-v','error','-y','-i',str(P/'assets/aroll.mp4'),'-vf',f'fps={FPS}','-q:v','2',str(fr/'%05d.jpg')],check=True)
nf=len(list(fr.glob('*.jpg'))); snaps=[float(x) for x in sys.argv[4].split(',')] if len(sys.argv)>4 else None
mix=P/'assets/mix.wav'
cmd=['ffmpeg','-v','error','-y','-f','image2pipe','-framerate',str(FPS),'-i','-']+(['-i',str(mix),'-map','0:v','-map','1:a','-c:a','aac','-b:a','192k','-shortest'] if mix.exists() else [])+['-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',OUT]
enc=None if snaps else subprocess.Popen(cmd,stdin=subprocess.PIPE)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--allow-file-access-from-files']); pg=b.new_page(viewport={'width':W,'height':H})
    pg.goto((P/'index.html').as_uri()); pg.evaluate("document.fonts.ready")
    pg.evaluate("""()=>{const v=document.getElementById('aroll');const im=document.createElement('img');im.id='fb';
      im.style.cssText='width:100%;height:100%;object-fit:cover;display:block;object-position:'+getComputedStyle(v).objectPosition;v.after(im);v.style.display='none'}""")
    times=snaps or [n/FPS for n in range(int(round(D*FPS)))]
    for i,t in enumerate(times):
        f=fr/f'{min(int(t*FPS)+1,nf):05d}.jpg'
        pg.evaluate("async([t,u])=>{const im=document.getElementById('fb');im.src=u;await im.decode();hfSeek(t)}",[t,f.as_uri()])
        img=pg.screenshot(type='jpeg',quality=92)
        if snaps: open(f'{OUT}_{t:05.2f}.jpg','wb').write(img)
        else: enc.stdin.write(img)
        if not snaps and i%150==0: print(i,'/',len(times),flush=True)
    b.close()
if enc: enc.stdin.close(); enc.wait()
print('done',OUT)
```

### gsap-lite.js (only when real GSAP cannot be downloaded; save as vendor/gsap.min.js)
```js
/* gsap-lite: seek-driven GSAP subset for offline renders. Real gsap.min.js drops in unchanged. */
(function(){
const TR={x:0,y:0,xPercent:0,yPercent:0,rotation:0,scale:1,scaleX:1,scaleY:1,skewX:0};
function parseEase(e){
  if(typeof e==='function')return e; e=e||'power1.out'; if(e==='none'||e==='linear')return t=>t;
  const m=e.match(/^(\w+)\.(in|out|inOut)(?:\(([\d.]+)\))?$/)||e.match(/^(\w+)$/);
  const n=m[1],dir=m[2]||'out',arg=m[3]?parseFloat(m[3]):undefined;
  let fin;
  if(/^power(\d)$/.test(n)){const p=+n.slice(5)+1;fin=t=>Math.pow(t,p);}
  else if(n==='expo')fin=t=>t===0?0:Math.pow(2,10*(t-1));
  else if(n==='sine')fin=t=>1-Math.cos(t*Math.PI/2);
  else if(n==='circ')fin=t=>1-Math.sqrt(1-t*t);
  else if(n==='back'){const s=arg??1.70158;fin=t=>t*t*((s+1)*t-s);}
  else if(n==='elastic'){fin=t=>t===0||t===1?t:-Math.pow(2,10*(t-1))*Math.sin((t-1.075)*2*Math.PI/0.3);}
  else fin=t=>t*t;
  if(dir==='in')return fin; if(dir==='out')return t=>1-fin(1-t);
  return t=>t<.5?fin(t*2)/2:1-fin((1-t)*2)/2;
}
const hex=s=>{const m=s.match(/^#([0-9a-f]{6})$/i);if(!m)return s;const v=parseInt(m[1],16);return `rgb(${v>>16},${v>>8&255},${v&255})`};
const NUM=/-?\d*\.?\d+(e-?\d+)?/gi;
function lerp(a,b,p){
  if(typeof b==='number'){return (typeof a==='number'?a:parseFloat(a)||0)+(b-(typeof a==='number'?a:parseFloat(a)||0))*p;}
  b=hex(String(b));a=hex(String(a==null?b:a));const an=(a.match(NUM)||[]).map(Number);let i=0;
  return b.replace(NUM,v=>{const s=an[i++];return s===undefined?v:String(s+(+v-s)*p)});
}
function targets(t){if(Array.isArray(t))return t.flatMap(x=>typeof x==='string'?[...document.querySelectorAll(x)]:[x]);if(typeof t==='string')return [...document.querySelectorAll(t)];if(t instanceof Element||!t.length&&typeof t==='object'&&!(t instanceof NodeList))return [t];return [...t];}
const SKIP=new Set(['duration','ease','stagger','immediateRender','onUpdate','delay','svgOrigin','transformOrigin']);
function initial(el,p){
  if(!(el instanceof Element))return el[p];
  if(p in TR)return TR[p];
  const cs=getComputedStyle(el);
  if(p==='filter')return cs.filter==='none'?'blur(0px)':cs.filter;
  if(p==='clipPath')return cs.clipPath==='none'?'inset(0% 0% 0% 0%)':cs.clipPath;
  if(p==='opacity')return parseFloat(cs.opacity);
  if(p==='strokeDashoffset')return parseFloat(cs.strokeDashoffset)||0;
  const v=cs[p]; const f=parseFloat(v); return isNaN(f)?v:f;
}
const st=new Map(); // el -> {transform state}
const baseSet=new Map(); // el -> props from gsap.set (restored before every seek)
function apply(el,p,v){
  if(!(el instanceof Element)){el[p]=v;return;}
  if(p in TR){let s=st.get(el);if(!s){s={...TR};st.set(el,s);}s[p]=v;
    el.style.transform=`translate(${s.x}px,${s.y}px) translate(${s.xPercent}%,${s.yPercent}%) rotate(${s.rotation}deg) skewX(${s.skewX}deg) scale(${s.scale*s.scaleX},${s.scale*s.scaleY})`;return;}
  if(p==='opacity'||p==='strokeDashoffset'||p==='zIndex'){el.style[p]=v;return;}
  if(typeof v==='number'&&p!=='opacity'){el.style[p]=v+'px';return;}
  el.style[p]=v;
}
function Timeline(o){this.tw=[];this.o=o||{};this._t=0;}
Timeline.prototype._add=function(t,from,to,pos,isSet){
  const els=targets(t);const stg=to.stagger;let each=0,mode='start';
  if(typeof stg==='number')each=stg;else if(stg){each=stg.each||0;mode=stg.from||'start';}
  const n=els.length;
  els.forEach((el,i)=>{
    let k=i; if(mode==='center')k=Math.abs(i-(n-1)/2); else if(mode==='end')k=n-1-i;
    else if(mode==='random'){k=((i*7919+13)%n);} else if(typeof mode==='number')k=Math.abs(i-mode);
    const tw={el,start:(pos??this.dur())+(to.delay||0)+k*each,d:isSet?0:(to.duration??0.5),ease:parseEase(to.ease),from:{},to:{},ir:to.immediateRender!==false&&!!from,onUpdate:to.onUpdate,idx:this.tw.length};
    for(const p in to){if(SKIP.has(p))continue;let v=to[p];if(typeof v==='function')v=v(i,el);tw.to[p]=v;}
    if(from)for(const p in from){let v=from[p];if(typeof v==='function')v=v(i,el);tw.from[p]=v;}
    for(const p in tw.to){if(!tw.base)tw.base={};tw.base[p]=initial(el,p);}
    if(to.transformOrigin&&el.style)el.style.transformOrigin=to.transformOrigin;
    this.tw.push(tw);
  });
  return this;
};
Timeline.prototype.dur=function(){return this.tw.reduce((m,t)=>Math.max(m,t.start+t.d),0)};
Timeline.prototype.duration=function(){return this.dur()};
Timeline.prototype.to=function(t,v,pos){return this._add(t,null,v,pos)};
Timeline.prototype.fromTo=function(t,f,v,pos){return this._add(t,f,v,pos)};
Timeline.prototype.from=function(t,f,pos){const to={};return this._add(t,f,Object.assign(to,{duration:f.duration,ease:f.ease,stagger:f.stagger}),pos)};
Timeline.prototype.set=function(t,v,pos){if(t&&typeof t==='object'&&!(t instanceof Element)&&!Object.keys(t).length&&!t.length)return this;return this._add(t,null,Object.assign({},v,{duration:0}),pos,true)};
Timeline.prototype.add=function(){return this};
Timeline.prototype.time=function(){return this._t};
Timeline.prototype.pause=function(){return this};
Timeline.prototype.seek=function(T){
  this._t=T;
  for(const tw of this.tw){if(tw.el instanceof Element){tw.el.style.transform='';for(const p in tw.to)if(!(p in TR))tw.el.style[p]='';}}st.clear();for(const [el,v] of baseSet)for(const p in v)apply(el,p,v[p]);
  // group by el+prop
  const groups=new Map();
  for(const tw of this.tw){for(const p in tw.to){const key=tw.el;let g=groups.get(key);if(!g){g=new Map();groups.set(key,g);}let a=g.get(p);if(!a){a=[];g.set(p,a);}a.push(tw);}}
  const calls=[];
  for(const [el,g] of groups){for(const [p,arr] of g){
    arr.sort((a,b)=>a.start-b.start||a.idx-b.idx);
    const valAt=(k,time)=>{ // value produced by tween k at time
      const tw=arr[k];const prev=k>0?valEnd(k-1,tw.start):(tw.base?tw.base[p]:0);
      const from=(p in tw.from)?tw.from[p]:prev;let to=tw.to[p];
      if(typeof to==='string'&&/^[+-]=/.test(to))to=(parseFloat(prev)||0)+parseFloat(to.replace('=',''));
      const pr=tw.d<=0?(time>=tw.start?1:0):Math.min(1,Math.max(0,(time-tw.start)/tw.d));
      return lerp(from,to,tw.ease(pr));
    };
    const valEnd=(k,time)=>valAt(k,Math.min(time,arr[k].start+arr[k].d));
    let last=-1;for(let k=0;k<arr.length;k++)if(arr[k].start<=T+1e-9)last=k;
    let v;
    if(last>=0)v=valAt(last,T);
    else{const f=arr.find(t=>t.ir&&(p in t.from));v=f?f.from[p]:(el instanceof Element?undefined:(arr[0].base?arr[0].base[p]:undefined));}
    if(v!==undefined)apply(el,p,v);
    if(last>=0&&arr[last].onUpdate)calls.push(arr[last].onUpdate);
  }}
  [...new Set(calls)].forEach(f=>f());
  return this;
};
Timeline.prototype.progress=function(){return this._t/this.dur()};
window.gsap={timeline:o=>new Timeline(o),set:(t,v)=>targets(t).forEach(el=>{baseSet.set(el,Object.assign(baseSet.get(el)||{},v));for(const p in v)apply(el,p,v[p])}),utils:{}};
})();
```