---
name: pastel-indigo-motion-graphics
description: Build HyperFrames motion graphics in the pastel-gradient, indigo-card, editorial-serif style: masked word slots, tile wipes, tilted speaker cards, mono HUD. Use for talking-head edits, explainers and motion pieces.
---

# Pastel indigo motion graphics (HyperFrames)

Recreates the look of the reference "edited 100% with Claude" reel: a warm cream canvas with four big blurred pastel blobs, an editorial condensed serif with indigo italic accent words, saturated indigo hero cards with butter-yellow italics, pastel tool tiles, a tiny monospace HUD around the frame, and springy masked-word motion. Speaker footage lives in the same composition, cutting between full-frame (with designed captions) and a tilted rounded card floating on the gradient.

Reference analysed: 46 s, 16:9 graphics panel, 8 chapters ("01 / 08 — the hook"), a new visual every 1–2.5 s, 23 distinct scene types, never a static frame.

## Style contract

**Canvas**: 1920x1080 by default (that is the reference). For a 9:16 reel use 1080x1920 with the same rules, see "Vertical adaptation".

**Palette** (CSS tokens in the template — do not invent new colours)
| token | hex | use |
|---|---|---|
| `--cream` | `#ECE6DD` | canvas base, behind the blobs |
| `--ink` | `#15122A` | roman headline words, icons, ink chips |
| `--indigo` | `#5536EE` | THE accent: italic words, period dots, strikes, rings, cards, progress bar |
| `--indigo-hi` / `--indigo-lo` | `#7A63F2` / `#4327DB` | card gradient top-left → bottom-right |
| `--butter` | `#EED9A0` | italic words on indigo cards |
| `--hilite` | `#EFD98F` | highlight box behind an italic word in over-footage captions; sparkles |
| `--lav` `--peach` `--mint` `--sun` `--sky` | `#BCAEEA` `#F0B89A` `#A9D8BF` `#EED68E` `#A9C4EE` | pastel tiles, timeline bars, swatches, sticky notes, alternate card fills |
| `--code` | `#130F25` | dark code/terminal cards |
| blobs | `#A28DEB` lav (top-left) · `#EC9E7E` peach (top-right) · `#9ACDB3` mint (bottom-left) · `#E9CB86` butter (bottom-right) | 150px blur, slow drift, never removed |

Over footage, darken with a left/bottom indigo-black gradient (`.shade`) — never a flat black box.

**Type**
- Serif: **Instrument Serif** (regular + italic) for every headline and caption. Size 104–170px (cards 104/170, single hero words 220px). Line-height .98. Roman words in ink; the 1–2 words that carry the meaning in *italic indigo* ("professional-*grade* editing", "way *cheaper*", "*talk* to Claude"). On indigo cards: roman white, italic butter.
- End statements with an indigo **period dot** (`.pdot`, a 0.15em circle) that pops in last: "Claude●", "editing●".
- Mono: **JetBrains Mono** 500 for everything small: kickers, HUD, chips, micro-labels, code. Uppercase, letter-spacing .16–.34em.
- **Kicker**: the spoken lead-in sits above the headline as a 15px indigo mono uppercase line ("PROPER", "IT IS", "WAY CHEAPER THAN GENERATING TOOLS", "STEP 01 — REFERENCES").
- Contrast device: strike the old idea with a thick indigo line ("~~noob-level work~~", "~~generating every pixel~~"), then say the new one.

**HUD frame (always on)**, 13px mono, 44px inset:
- top-left `PROJECT ✦ TITLE '26` (indigo ✦), top-right `03 / 08 — pixels vs code` (chapter counter + lowercase chapter name), bottom-left `edited by … · html · gsap · canvas`, bottom-right running timecode `00:03:58 · 60 fps`.
- 4px indigo progress bar along the bottom edge with a dot head.
- The HUD turns white over footage (`#hud.dark`).

**Components**
- `.icard` indigo hero card: radius 28, indigo gradient, deep indigo shadow, three faint mono micro-labels in the corners ("KINETIC TYPE", "MASKED SPRING SLOT", "02 / WORDS").
- `.pcard` paper card `#F7F2EA` (chat UI, reference cards, clock face).
- `.tile` pastel tool tiles 150x140, radius 26, line icons (stroke 3.2 ink, one indigo fill accent per icon).
- `.chip` ink pill (mono, white) for prompts/labels like "change the color ↵", `.chip.up` uppercase pill, `.chip.ind` indigo pill for timecodes/status, `.chip.sun` butter "SAVED ✓".
- Speaker card: footage in a rounded rect (radius 26–30), tilted -3…+3°, big soft indigo-tinted shadow, a 4-point sparkle on one corner, tiny mono label under it ("● THE BEST PART").
- Sparkles: 4-point stars in `--hilite`/indigo/peach that twinkle near the emphasis.
- Subtle film grain over everything (SVG turbulence at 7% multiply).

## Motion language

Everything is spring-and-mask. Use GSAP eases exactly as listed.
- **Masked spring slot** (default for every word): each word sits in its own `overflow:hidden` mask and rises `yPercent 115→0`, `rotation 5→0`, 0.7 s, `back.out(1.5)`, stagger 0.06. Words land **on the spoken word**. Italic accent words use `back.out(1.8)`, no rotation.
- **Cards**: `scale .62→1`, `y 80→0`, `rotation -7→final tilt`, `blur 10→0`, 0.8 s, `back.out(1.7)`. Exit: `scale .9`, `y -60`, `blur 12`, 0.38 s, `power3.in`.
- **Pops** (tiles, dots, buttons, chips): `scale 0→1`, `back.out(2.2)`; period dots `back.out(3–3.5)`; tiles staggered 0.035 from start with `rotation -10→0`.
- **Draw-ons** (rings, bezier curves, strikes, underlines): stroke-dash or `scaleX 0→1` from the left, `power2.inOut`/`power3.out`, 0.4–1.2 s.
- **Counters** count while their ring draws and land on the spoken number.
- **Idle life**: nothing sits still — blobs drift (sine, 8–11 s periods), tiles bob ±16px, footage slowly scales 1.0→1.06, timecode runs.
- **Typing**: prompt chips and input fields type at ~22 chars/s with a block caret.
- Exits are fast (0.3–0.38 s, `power3.in`, blur) — entrances are slow and springy.

## Transitions

| name | when | how |
|---|---|---|
| `tileWipe(t)` | chapter changes, footage ↔ graphics | 8x5 grid of indigo rounded tiles springs in (seeded random order, 0.18 s spread), frame fully covered at `t+0.52` (swap scenes there), tiles shrink away with a 10° twist |
| card shrink / grow | full-frame speaker ↔ speaker card | `camTo(t,'cardL'|'cardR'|'small'|'full')`, 0.85 s `expo.inOut`, radius and tilt animate with it; the gradient shows behind |
| card in / out | speaker card arriving into a graphics scene | `cardIn('#cam',t,{r0:9,r1:2.5})` — the card drops in tilted and settles |
| blur fade | between two typographic scenes | outgoing scene `opacity 0, blur 14, scale 1.04`, 0.35 s; next scene words slot in |
| whip | quick lateral swap | out x -260 blur 18, in from +260 |
| colour swap | "change the colour" beats | a pastel panel wipes across an indigo card from the right (`clipPath inset`) while a swatch ring hops to the new colour |
| particle dissolve | revealing/hiding a key word | the word breaks into ~1,200 seeded dots that swirl into a sphere (canvas, driven by a progress object) |

## Recipe library

Each recipe = markup (inside a `.clip.scene`) + timeline calls. Times are absolute; use `T(i)` (word start) when working from a transcript. The **template already contains tested versions of recipes 1–6**; recipes 7–18 are sketches built from the same primitives — snapshot them before trusting the timing.

1. **over-caption** (footage full frame) — `.shade` + kicker + 1–2 lines of white serif `.cap`; the italic payoff word sits in a `.hi` butter highlight box (`hilite()` grows it, then the word slots in) with a twinkling sparkle. "the power / of *Claude.*", "and the *crazy* part…".
2. **hero-card** — `.icard` 1460x720; small roman line ("AI can finally do") then one or two 170px butter italic lines ("*high-level* / *editing.*"), each a slot on its word.
3. **tool-grid** — 4x3 pastel `.tile`s with line icons pop in, then headline above slots in word by word, period dot last; tiles bob.
4. **strike-contrast** (with speaker card) — kicker "LIKE, NOT ANY", ink words slot in, indigo `.strike` lines draw across each, a peach `×` button pops, a pale chip "BASIC CUTS · NO POLISH".
5. **countdown-ring** — 400px ring (ink 12% track, indigo 9px arc) draws while the number counts to the spoken value; "IN JUST" kicker inside, italic indigo unit ("min"), indigo timecode chip below.
6. **sign-off word** — kicker + one 220px italic ink word + indigo period dot + ink uppercase chip ("BECAUSE IT'S WAY CHEAPER").
7. **timeline-bars** — 4 tracks of rounded pastel bars (indigo main track, lav/sky overlay track, mint audio track with tick texture, peach/sun lower track) grow `scaleX` from the left staggered; a thin ink playhead with a dot head sweeps across.
8. **bezier-ease** — an SVG cubic curve (indigo 4px) draws from bottom-left to top-right; two ink handle lines with hollow end circles; an indigo dot rides the curve (`MotionPath`-free: tween a progress object and place the dot with `path.getPointAtLength`); an ink chip "EASE · IN-OUT · CURVE" pops at the end. Headline: "premium *motion graphics*".
9. **cost-bars** — baseline rule; a short indigo bar with "$" and a tall peach bar with diagonal hatching (`repeating-linear-gradient(45deg,…)`) and "$$$$" grow from the baseline; mono labels under each; an ink chip "LIVE DIFFERENCE" points at the tall bar. Headline "way *cheaper*●".
10. **pixel-grid** — a dense grid of tiny pastel squares with every 3rd indigo fills in row by row (stagger ~0.004), a mono counter "PIXEL 1,254,120 / 2,073,600 · RENDERING…" ticks under it, then the headline "generating *every pixel*" gets struck through.
11. **code-card** — `--code` card with traffic-light dots (peach/butter/mint), filename micro-label, line numbers, GSAP code typing in mono (strings butter, numbers peach); a butter sticky note card swings in beside it with the payoff ("way *cheaper*●").
12. **reference-cards** — 4 paper cards (gradient swatch, "Aa*g*" type specimen, 6 colour dots, bezier curve) fan in with tilts, then snap into an aligned row inside a frosted tray; a padlock button pops below with an indigo chip "AESTHETIC LOCKED". Headline "to *lock* the aesthetic●".
13. **chat-prompt** — `.pcard` chat window with an input "message claude…" and indigo send dot; an ink prompt chip types "generate the keyframes for scene 03" then flies up; keyframe thumbnails (mini versions of earlier scenes) slide in along a dotted track with indigo diamond keyframe markers.
14. **colour-swap** (speaker card left, indigo card right "I make things / *move.*") — ink chip types "change the color ↵"; a peach panel wipes across the card (`clipPath: inset(0 0 0 100%)→inset(0)`), text turns ink, swatch dots under the card show the selection ring hopping; then "make the font bigger ↵" and the italic word scales 1→1.45 with `back.out(1.6)`.
15. **clock-spin** — paper clock face with ticks; hands spin several turns (`rotation:'+=1440'`, `power2.inOut`) with 3 ghost-trail copies at 35/20/10% opacity; ink chip "04:35:22 SPENT" counts. Headline "hours in *editing*" then fades grey as the next idea arrives.
16. **particle-word** — canvas; seeded particles start on the glyph pixels of a word (sample by drawing the word to an offscreen canvas) and lerp to points on a rotating sphere; drive with `tl.fromTo(o,{p:0},{p:1,onUpdate:draw})`. Reverse it to form a word out of dust.
17. **save-badge** (over footage) — dark glass square top-right with a bookmark outline; it fills indigo with a pop, a sparkle bursts, butter chip "SAVED ✓" slides out; caption "I'm sharing / *the process*".
18. **comment-cta** (end, over footage) — white pill input with pastel avatar dot, types `comment "AI"` with caret, indigo round arrow button pulses; mono line under it "IF YOU WANT MY PROCESS ↓"; sparkles either side.

Choosing recipes by what is said: a claim → hero-card; a list of skills/tools → tool-grid; "not X" → strike-contrast; a number or duration → countdown-ring or clock-spin; money/cost → cost-bars; process steps → reference-cards / chat-prompt / timeline-bars; "motion/animation" → bezier-ease; a name or punchline → sign-off word or particle-word; call to action → save-badge or comment-cta.

## Layout rules

- Three layouts: **OVER** (footage full frame + over-caption), **CARD** (speaker in a tilted card, graphics beside it on the gradient), **FULL** (graphics only on the gradient).
- Speaker visible (OVER or CARD) ≥ 40% of runtime; FULL stretches ≤ 6 s before the face returns.
- One idea per scene, 1.5–3 s each. Text left-aligned at x≈140–420 or centred; never more than ~6 words of headline on screen.
- Keep 120px clear of the HUD corners; nothing important under the bottom 80px.
- Hide jump cuts under FULL scenes or tile wipes.

**Vertical adaptation (1080x1920)**: same tokens and motion; headline sizes ×0.8; cards full-width (x 60–1020); speaker card sits in the lower half (top ≈ 1000) with graphics above; HUD at 56px inset; keep content inside y 220–1560 for Instagram UI.

**Before/after post format (optional)**: to mimic the reference post, render the 16:9 edit, then stack it with the raw clip on a black 1080x1920 canvas with labels "Opus 5.5" / "Original" (`ffmpeg … vstack` with pads); only when the user asks for the comparison layout.

## Requirements and environment

- HyperFrames CLI needs Node 22+, FFmpeg and headless Chrome; run it as `npx hyperframes …`. If the HyperFrames skills are installed (`npx skills add heygen-com/hyperframes`), read `hyperframes-core` and `hyperframes-cli` first — they win on composition rules.
- Assets (no CDNs inside the composition):
  - GSAP: `npm pack gsap` → `package/dist/gsap.min.js` → `project/vendor/`
  - Fonts: `npm pack @fontsource/instrument-serif @fontsource/jetbrains-mono` → copy `instrument-serif-latin-400-normal.woff2`, `instrument-serif-latin-400-italic.woff2`, `jetbrains-mono-latin-400-normal.woff2`, `jetbrains-mono-latin-500-normal.woff2` → `project/fonts/`
- **Blocked registries**: some sandboxes (cloud and the desktop VM) refuse npm, GitHub and PyPI. Then ask the user to put `gsap.min.js` (gsap.com) and the four font files (Google Fonts: Instrument Serif, JetBrains Mono) into the project folder, or to run the build from their own terminal. Do not substitute other fonts silently — the condensed serif is the look. For a quick internal preview only, the fallback stack (Lora/Liberation Serif) is acceptable if you say so.
- Python for transcripts/SFX: `pip install --break-system-packages sherpa-onnx soundfile numpy scipy`. Playwright only for `render_fallback.py`.
- HeyGen HyperFrames MCP `compose` makes hosted projects only — use it only if the user wants a HeyGen project link; it won't cut their footage.
- `SendUserFile` caps at 30 MB: deliver a compressed copy.

## Workflow

Use a task list. Work in `<folder>/<name>/` with the composition in `project/`. Ask only when blocked (brand name for the HUD, chapter names if unclear); otherwise state assumptions in the final message.

0. **Setup** — `mkdir -p project/{assets,fonts,vendor}`; fetch GSAP + fonts (above); `npx hyperframes doctor`.
1. **Inspect** — `ffprobe`; contact sheet `ffmpeg -i SRC -vf "fps=1/2,scale=240:-1,tile=6x4" -frames:v 1 contact.jpg`; set `#aroll` `object-position` for the face.
2. **Transcribe** — `ffmpeg -i SRC -vn -ac 1 -ar 16000 a16.wav && python3 asr.py a16.wav words.json` (or `npx hyperframes transcribe`). Fix names/numbers.
3. **Tighten** — cut fillers, false starts and gaps > 0.3 s into `keep.json` `[[s0,s1],…]`; `python3 cut.py SRC` → `project/assets/aroll.mp4`, `voice_cut.wav`, `edit.json`; re-run `asr.py` on `voice_cut16.wav` → `words_cut.json`.
4. **Storyboard** — split into 5–8 chapters (these feed the HUD counter) and 1.5–3 s beats. For each beat: layout (OVER/CARD/FULL), recipe, the words that slot in, which word is italic indigo, transition in. Write it to `storyboard.md` as one line per beat and sanity-check pacing (a visual change every ≤ 2.5 s).
5. **Build** — copy the template to `project/index.html`; set `data-duration` (3 places) to `edit.json` dur; fill `SCENES` (chapter labels + start times) and `DARK` (OVER ranges) in the HUD driver; replace the example scenes/beats with one `.clip.scene` per beat; time every slot to `T(i)`.
   Rules (hyperframes-core): timed elements use `class="clip"` + `data-start/data-duration/data-track-index`; never tween `display/visibility` on a clip; one paused timeline at `window.__timelines.edit`; deterministic only (seeded `rnd()`, no `Math.random`, timers or network); elements that animate in start hidden (`.in` = opacity 0 in CSS; masked words via the one-time `gsap.set(qa('.wi'),{yPercent:115})` — never a CSS transform on `.wi`, GSAP would add it to `yPercent` and the words would never land) and tweens use `immediateRender:false`.
6. **Check** — `npx hyperframes lint`; `npx hyperframes snapshot --at …` one time per beat (look at every frame: legibility, overlap, HUD clear, face framing); `npx hyperframes render --quality draft`; contact sheet at 2 fps; compare against the style contract (palette only from tokens, one italic accent per line, period dots, HUD running, no static frame > 1.2 s). Fix and re-render `--quality high`. Without the CLI: `python3 render_fallback.py project final.mp4`.
7. **Sound** — SFX events `[[t,"whoosh|pop|tick|thump|swipe",dB],…]`: soft whoosh -26 dB on tile wipes and card moves, pop -28 on tiles/dots/chips, tick -31 for typing and clock, thump -24 on the punch line; ~0.6 events/s. `python3 sfx.py sfx.json`, mix to -14 LUFS (voice compressed, SFX under), put in `<audio id="mix">`. Music only if asked/supplied, ~18 dB under voice.
8. **Deliver** — check 1 fps sheet + 4 full-res frames, first frame shows the hook, key motions within 0.08 s of their word, loudness. Deliver a < 30 MB copy, commit the master to the user's folder if connected. Final message: duration before/after, beat list one line each, guessed words to confirm.

## Template: `project/index.html`

Rendered and checked frame by frame when the skill was written (through `render_fallback.py`, with a GSAP-compatible stand-in and fallback fonts because npm was blocked), so on the first real HyperFrames render, snapshot every beat before trusting it. The scenes `s1`–`s6` and the `BEATS` block are a worked example — replace them with your storyboard; keep the CSS, primitives, camera, transitions and HUD driver.

```html
<!doctype html>
<html><head><meta charset="utf-8">
<style>
@font-face{font-family:IS;src:url(fonts/instrument-serif-latin-400-normal.woff2);font-style:normal}
@font-face{font-family:IS;src:url(fonts/instrument-serif-latin-400-italic.woff2);font-style:italic}
@font-face{font-family:JB;src:url(fonts/jetbrains-mono-latin-400-normal.woff2);font-weight:400}
@font-face{font-family:JB;src:url(fonts/jetbrains-mono-latin-500-normal.woff2);font-weight:500}
:root{
  --cream:#ECE6DD; --ink:#15122A; --mute:#8C86A0;
  --indigo:#5536EE; --indigo-hi:#7A63F2; --indigo-lo:#4327DB; --butter:#EED9A0; --hilite:#EFD98F;
  --lav:#BCAEEA; --peach:#F0B89A; --mint:#A9D8BF; --sun:#EED68E; --sky:#A9C4EE; --code:#130F25;
  --b-lav:#A28DEB; --b-peach:#EC9E7E; --b-mint:#9ACDB3; --b-sun:#E9CB86;
  --serif:IS,'Instrument Serif',Lora,'Liberation Serif',serif; --mono:JB,'JetBrains Mono','DejaVu Sans Mono',monospace;
}
html,body{margin:0;background:var(--cream)}
#edit{position:relative;width:1920px;height:1080px;overflow:hidden;background:var(--cream);color:var(--ink);font-family:var(--serif);-webkit-font-smoothing:antialiased}
/* ---------- living gradient background ---------- */
#bg{position:absolute;inset:-10%;z-index:0}
.blob{position:absolute;border-radius:50%;filter:blur(150px);opacity:.95}
#bl1{left:-6%;top:-14%;width:58%;height:68%;background:var(--b-lav)}
#bl2{right:-8%;top:-12%;width:50%;height:62%;background:var(--b-peach)}
#bl3{left:-10%;bottom:-16%;width:52%;height:58%;background:var(--b-mint)}
#bl4{right:-8%;bottom:-18%;width:54%;height:60%;background:var(--b-sun)}
#bl5{left:30%;top:28%;width:44%;height:46%;background:var(--cream);filter:blur(120px)}
#grain{position:absolute;inset:0;z-index:8;pointer-events:none;opacity:.07;mix-blend-mode:multiply}
/* ---------- speaker camera ---------- */
#cam{position:absolute;left:0;top:0;width:1920px;height:1080px;overflow:hidden;z-index:2;border-radius:0;transform-origin:50% 50%;
  box-shadow:0 50px 90px -40px rgba(45,25,140,.55),0 10px 30px rgba(21,18,42,.18)}
#camz{position:absolute;inset:0}
#aroll{width:100%;height:100%;object-fit:cover;object-position:50% 35%;display:block}
.camlabel{position:absolute;font:500 12px var(--mono);letter-spacing:.28em;text-transform:uppercase;color:var(--indigo);z-index:2}
/* ---------- scenes ---------- */
.scene{position:absolute;inset:0;z-index:3;overflow:visible}
.ab{position:absolute}.in{opacity:0}
.kick{font:500 15px var(--mono);letter-spacing:.32em;text-transform:uppercase;color:var(--indigo)}
.hl{font-family:var(--serif);font-weight:400;font-size:136px;line-height:.98;letter-spacing:-.012em;color:var(--ink);white-space:nowrap}
.hl.xl{font-size:220px}.hl.md{font-size:104px}.hl.sm{font-size:76px}
.it{font-style:italic;color:var(--indigo)}
.w{display:inline-block;overflow:hidden;vertical-align:bottom;padding:.06em .04em .16em;margin:-.06em -.04em -.16em}
.wi{display:inline-block;will-change:transform}
.pdot{display:inline-block;width:.15em;height:.15em;border-radius:50%;background:var(--indigo);margin-left:.03em;vertical-align:.02em}
.strike{position:absolute;left:-2%;right:-2%;top:56%;height:7px;border-radius:6px;background:var(--indigo);transform-origin:0 50%;transform:rotate(-2.5deg) scaleX(0)}
/* indigo hero card */
.icard{position:absolute;border-radius:28px;background:linear-gradient(135deg,var(--indigo-hi) 0%,var(--indigo) 42%,var(--indigo-lo) 100%);
  box-shadow:0 40px 80px -30px rgba(67,39,219,.6),0 10px 24px rgba(21,18,42,.12);color:#fff;overflow:hidden}
.icard .hl{color:#fff}.icard .it{color:var(--butter)}
.micro{position:absolute;font:500 12px var(--mono);letter-spacing:.34em;text-transform:uppercase;color:rgba(255,255,255,.42)}
.pcard{position:absolute;border-radius:28px;background:#F7F2EA;box-shadow:0 40px 80px -36px rgba(21,18,42,.35),0 8px 20px rgba(21,18,42,.08)}
/* chips */
.chip{display:inline-block;padding:9px 18px;border-radius:12px;background:var(--ink);color:#fff;font:500 15px var(--mono);letter-spacing:.06em;white-space:nowrap}
.chip.up{text-transform:uppercase;letter-spacing:.22em;font-size:13px;border-radius:999px;padding:8px 20px}
.chip.ind{background:var(--indigo)}.chip.sun{background:var(--sun);color:var(--ink)}
/* pastel tiles */
.tile{position:absolute;width:150px;height:140px;border-radius:26px;display:grid;place-items:center;
  box-shadow:0 18px 30px -16px rgba(21,18,42,.35),inset 0 1px 0 rgba(255,255,255,.55)}
.tile svg{width:54px;height:54px}
.ln{fill:none;stroke:var(--ink);stroke-width:3.2;stroke-linecap:round;stroke-linejoin:round}
.lni{fill:none;stroke:var(--indigo);stroke-width:5;stroke-linecap:round;stroke-linejoin:round}
/* round "x" / action buttons */
.rbtn{position:absolute;width:76px;height:76px;border-radius:50%;background:var(--peach);display:grid;place-items:center;box-shadow:0 14px 26px -12px rgba(21,18,42,.4)}
/* over-footage captions */
.shade{position:absolute;inset:0;background:linear-gradient(90deg,rgba(14,8,40,.72) 0%,rgba(14,8,40,.25) 45%,rgba(14,8,40,0) 70%),linear-gradient(0deg,rgba(14,8,40,.55),rgba(14,8,40,0) 45%)}
.cap{position:absolute;font-family:var(--serif);font-size:120px;line-height:1;color:#fff;white-space:nowrap;text-shadow:0 4px 30px rgba(0,0,0,.35)}
.cap .it{color:#fff}
.hi{position:relative;z-index:0;display:inline-block;padding:0 .14em;color:var(--ink)!important;font-style:italic;text-shadow:none}
.hi::before{content:'';position:absolute;inset:.08em -.02em .02em;background:var(--hilite);border-radius:12px;z-index:-1;transform-origin:0 50%;transform:scaleX(var(--hx,1))}
.spark{position:absolute;width:44px;height:44px}
/* HUD */
#hud{position:absolute;inset:0;z-index:9;pointer-events:none;font:500 13px var(--mono);letter-spacing:.16em;text-transform:uppercase;color:rgba(21,18,42,.78)}
#hud.dark{color:rgba(255,255,255,.82)}
#hud .c{position:absolute}
#hud .tl{left:44px;top:38px}#hud .tr{right:44px;top:38px;text-transform:none;letter-spacing:.1em}
#hud .bl{left:44px;bottom:36px;text-transform:none;letter-spacing:.08em}#hud .br{right:44px;bottom:36px;letter-spacing:.1em}
#hud .dia{color:var(--indigo)}
#prog{position:absolute;left:0;bottom:0;height:4px;width:0;background:var(--indigo)}
#prog::after{content:'';position:absolute;right:-5px;top:-3px;width:10px;height:10px;border-radius:50%;background:var(--indigo)}
/* tile wipe */
#wipe{position:absolute;inset:0;z-index:7;pointer-events:none;opacity:0}
#wipe .wt{position:absolute;border-radius:30px;background:linear-gradient(135deg,var(--indigo-hi),var(--indigo) 50%,var(--indigo-lo));transform:scale(0)}
</style></head>
<body>
<div id="edit" data-composition-id="edit" data-start="0" data-width="1920" data-height="1080" data-duration="13">
  <div id="bg"><div class="blob" id="bl1"></div><div class="blob" id="bl2"></div><div class="blob" id="bl3"></div><div class="blob" id="bl4"></div><div class="blob" id="bl5"></div></div>

  <div id="cam"><div id="camz">
    <video id="aroll" class="clip" data-start="0" data-duration="13" data-track-index="0" src="assets/aroll.mp4" muted playsinline></video>
  </div></div>

  <!-- S1 over-footage caption -->
  <div class="clip scene" id="s1" data-start="0" data-duration="2.3" data-track-index="2">
    <div class="shade"></div>
    <div class="ab kick in" id="s1k" style="left:150px;top:600px;color:rgba(255,255,255,.7)">guys, this is</div>
    <div class="cap" style="left:150px;top:650px"><span class="w"><span class="wi">the</span></span> <span class="w"><span class="wi">power</span></span></div>
    <div class="cap" style="left:150px;top:770px"><span class="w"><span class="wi it">of</span></span> <span class="hi" id="s1h" style="--hx:0"><span class="w"><span class="wi">Claude.</span></span></span></div>
    <svg class="spark in" id="s1sp" viewBox="0 0 40 40" style="left:760px;top:740px"><path d="M20 2 C21 14 26 19 38 20 C26 21 21 26 20 38 C19 26 14 21 2 20 C14 19 19 14 20 2Z" fill="#EFD98F"/></svg>
  </div>

  <!-- S2 indigo hero card -->
  <div class="clip scene" id="s2" data-start="2.0" data-duration="2.9" data-track-index="3">
    <div class="icard in" id="s2c" style="left:230px;top:190px;width:1460px;height:720px">
      <div class="micro" style="right:60px;top:50px">kinetic type</div>
      <div class="micro" style="left:80px;bottom:50px">masked spring slot</div>
      <div class="micro" style="right:60px;bottom:50px">02 / words</div>
      <div class="ab hl md" style="left:96px;top:120px"><span class="w"><span class="wi">AI</span></span> <span class="w"><span class="wi">can</span></span> <span class="w"><span class="wi">finally</span></span> <span class="w"><span class="wi">do</span></span></div>
      <div class="ab hl" style="left:96px;top:250px;font-size:170px"><span class="w"><span class="wi it">high-level</span></span></div>
      <div class="ab hl" style="left:96px;top:410px;font-size:170px"><span class="w"><span class="wi it">editing.</span></span></div>
    </div>
  </div>

  <!-- S3 pastel tool grid + headline -->
  <div class="clip scene" id="s3" data-start="4.7" data-duration="2.6" data-track-index="2">
    <div class="ab kick in" id="s3k" style="left:420px;top:150px">proper</div>
    <div class="ab hl md" id="s3h" style="left:410px;top:180px"><span class="w"><span class="wi">professional-</span></span><span class="w"><span class="wi it">grade</span></span> <span class="w"><span class="wi">editing</span></span><span class="pdot in" id="s3d"></span></div>
    <div id="s3g"></div>
  </div>

  <!-- S4 speaker card + strike -->
  <div class="clip scene" id="s4" data-start="7.2" data-duration="2.4" data-track-index="3">
    <div class="ab kick in" id="s4k" style="left:150px;top:330px">like, not any</div>
    <div class="ab hl md" style="left:140px;top:370px"><span style="position:relative;display:inline-block"><span class="w"><span class="wi">noob-level</span></span><span class="strike" id="s4s1"></span></span></div>
    <div class="ab hl md" style="left:140px;top:480px"><span style="position:relative;display:inline-block"><span class="w"><span class="wi">work</span></span><span class="strike" id="s4s2"></span></span></div>
    <div class="rbtn in" id="s4x" style="left:520px;top:640px"><svg viewBox="0 0 40 40" width="30" height="30"><path class="ln" d="M10 10 L30 30 M30 10 L10 30"/></svg></div>
    <div class="ab chip up in" id="s4c" style="left:150px;top:780px;background:rgba(255,255,255,.7);color:var(--ink)">basic cuts · no polish</div>
  </div>

  <!-- S5 countdown ring -->
  <div class="clip scene" id="s5" data-start="9.5" data-duration="1.9" data-track-index="2">
    <svg class="ab in" id="s5r" viewBox="0 0 400 400" style="left:760px;top:190px;width:400px;height:400px">
      <circle cx="200" cy="200" r="180" fill="none" stroke="rgba(21,18,42,.12)" stroke-width="6"/>
      <circle id="s5a" cx="200" cy="200" r="180" fill="none" stroke="#5536EE" stroke-width="9" stroke-linecap="round" transform="rotate(-90 200 200)"/>
    </svg>
    <div class="ab kick in" id="s5k" style="left:0;right:0;top:300px;text-align:center">in just</div>
    <div class="ab hl in" id="s5n" style="left:0;right:0;top:318px;text-align:center;font-size:150px"><span id="s5v">0</span><span class="it" style="font-size:.4em;margin-left:.08em">min</span></div>
    <div class="ab chip ind up in" id="s5c" style="left:0;right:0;margin:auto;width:max-content;top:650px">00:20:00 · real time</div>
  </div>

  <!-- S6 sign-off word -->
  <div class="clip scene" id="s6" data-start="11.3" data-duration="1.7" data-track-index="3">
    <div class="ab kick in" id="s6k" style="left:0;right:0;top:380px;text-align:center">so we're using</div>
    <div class="ab hl xl" style="left:0;right:0;top:420px;text-align:center;font-style:italic"><span class="w"><span class="wi">Claude</span></span><span class="pdot in" id="s6d"></span></div>
    <div class="ab chip up in" id="s6c" style="left:0;right:0;margin:auto;width:max-content;top:690px">because it's way cheaper</div>
  </div>

  <div id="wipe"></div>
  <svg id="grain" width="1920" height="1080"><filter id="gn"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="7"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0"/></filter><rect width="100%" height="100%" filter="url(#gn)"/></svg>
  <div id="hud">
    <div class="c tl">Claude <span class="dia">✦</span> edit reel '26</div>
    <div class="c tr" id="hudScene">01 / 06 — the hook</div>
    <div class="c bl">edited by claude · html · gsap · canvas</div>
    <div class="c br" id="hudTc">00:00:00 · 60 fps</div>
    <div id="prog"></div>
  </div>

<script src="vendor/gsap.min.js"></script>
<script>
const DUR=parseFloat(document.getElementById('edit').dataset.duration);
const q=s=>document.querySelector(s), qa=(s,r=document)=>[...r.querySelectorAll(s)];
const tl=gsap.timeline({paused:true});
const IR={immediateRender:false};
const E={o:'expo.out',i:'power3.in',io:'expo.inOut',spring:'back.out(1.7)',soft:'power3.out'};
// hidden start state for every masked word (set once, outside the timeline; do NOT hide .wi with a CSS transform)
gsap.set(qa('.wi'),{yPercent:115});
// seeded rng (deterministic)
let _s=11;const rnd=()=>(_s=(_s*16807)%2147483647)/2147483647;

// ================= PRIMITIVES (t = absolute seconds) =================
// masked spring slot: words rise out of their own mask
const slot=(sel,t,o={})=>tl.fromTo(typeof sel==='string'?qa(sel):sel,{yPercent:115,rotation:o.rot??5},{yPercent:0,rotation:0,duration:o.d??0.7,ease:o.ease??'back.out(1.5)',stagger:o.st??0.06,...IR},t);
const slotOut=(sel,t,o={})=>tl.to(typeof sel==='string'?qa(sel):sel,{yPercent:-115,duration:o.d??0.35,ease:E.i,stagger:o.st??0.03},t);
const fadeIn=(el,t,o={})=>tl.fromTo(el,{opacity:0,y:o.y??14,filter:`blur(${o.b??8}px)`},{opacity:1,y:0,filter:'blur(0px)',duration:o.d??0.5,ease:E.o,...IR},t);
const fadeOut=(el,t,o={})=>tl.to(el,{opacity:0,filter:`blur(${o.b??10}px)`,y:o.y??-10,duration:o.d??0.3,ease:E.i},t);
const pop=(el,t,o={})=>tl.fromTo(el,{opacity:0,scale:o.s??0,rotation:o.r??0},{opacity:1,scale:1,rotation:0,duration:o.d??0.55,ease:o.ease??'back.out(2.2)',stagger:o.st??0,...IR},t);
const cardIn=(el,t,o={})=>tl.fromTo(el,{opacity:0,scale:o.s??0.62,y:o.y??80,rotation:o.r0??-7,filter:'blur(10px)'},{opacity:1,scale:1,y:0,rotation:o.r1??0,filter:'blur(0px)',duration:o.d??0.8,ease:E.spring,...IR},t);
const cardOut=(el,t,o={})=>tl.to(el,{opacity:0,scale:o.s??0.9,y:o.y??-60,x:o.x??0,rotation:o.r??3,filter:'blur(12px)',duration:o.d??0.38,ease:E.i},t);
const strike=(el,t,d=0.38)=>tl.fromTo(el,{scaleX:0,rotation:-2.5},{scaleX:1,rotation:-2.5,duration:d,ease:'power3.out',...IR},t);
const draw=(el,t,d=0.7,ease='power2.inOut')=>{el=typeof el==='string'?q(el):el;const L=el.getTotalLength();el.style.strokeDasharray=L;el.style.strokeDashoffset=L;tl.fromTo(el,{strokeDashoffset:L},{strokeDashoffset:0,duration:d,ease,...IR},t)};
const count=(el,t,a,b,d)=>{el=typeof el==='string'?q(el):el;const o={v:a};el.textContent=a;tl.fromTo(o,{v:a},{v:b,duration:d,ease:'power2.out',onUpdate:()=>{el.textContent=Math.round(o.v)},...IR},t)};
const hilite=(el,t,d=0.35)=>{el=typeof el==='string'?q(el):el;const o={v:0};tl.fromTo(o,{v:0},{v:1,duration:d,ease:'power3.out',onUpdate:()=>el.style.setProperty('--hx',o.v),...IR},t)};
const twinkle=(el,t)=>{pop(el,t,{r:-90,d:0.6});tl.to(el,{scale:0.75,duration:0.5,ease:'sine.inOut'},t+0.65);tl.to(el,{scale:1,duration:0.5,ease:'sine.inOut'},t+1.15)};

// ================= CAMERA (speaker footage) =================
const CAM={
  full :{left:0,  top:0,  width:1920,height:1080,borderRadius:0, rotation:0},
  cardL:{left:150,top:230,width:820, height:600, borderRadius:30,rotation:-3},
  cardR:{left:1000,top:210,width:780,height:600, borderRadius:30,rotation:2.5},
  small:{left:120,top:300,width:560, height:440, borderRadius:26,rotation:-2},
};
const camTo=(t,m,d=0.85)=>tl.to('#cam',{...CAM[m],duration:d,ease:E.io},t);
const camSet=(t,m)=>tl.set('#cam',{...CAM[m]},t);
const camZoom=(t0,t1,z0,z1)=>tl.fromTo('#camz',{scale:z0},{scale:z1,duration:t1-t0,ease:'none',...IR},t0);

// ================= TRANSITIONS =================
// tile wipe: indigo rounded tiles cover the frame, scene swaps under them, tiles scatter away
(()=>{const C=8,R=5,g=14,w=(1920-g*(C+1))/C,h=(1080-g*(R+1))/R,wp=q('#wipe');
  for(let r=0;r<R;r++)for(let c=0;c<C;c++){const d=document.createElement('div');d.className='wt';
    d.style.cssText=`left:${g+c*(w+g)}px;top:${g+r*(h+g)}px;width:${w}px;height:${h}px`;d.dataset.k=rnd().toFixed(4);wp.appendChild(d);}})();
const tileWipe=(t)=>{const T=qa('#wipe .wt');
  tl.set('#wipe',{opacity:1},t); tl.set('#wipe',{opacity:0},t+1.05);
  T.forEach(el=>{const k=+el.dataset.k;
    tl.fromTo(el,{scale:0,rotation:-12},{scale:1.04,rotation:0,duration:0.34,ease:'back.out(1.3)',...IR},t+k*0.18);
    tl.to(el,{scale:0,rotation:10,duration:0.3,ease:'power3.in'},t+0.56+k*0.18);});
  return t+0.52;   // swap scenes at this time (frame fully covered)
};
const whip=(out,inn,t,dx=1)=>{tl.to(out,{x:-260*dx,opacity:0,filter:'blur(18px)',duration:0.32,ease:E.i},t);
  tl.fromTo(inn,{x:260*dx,opacity:0,filter:'blur(18px)'},{x:0,opacity:1,filter:'blur(0px)',duration:0.5,ease:E.o,...IR},t+0.12)};

// ================= HUD + living background (one deterministic driver) =================
const SCENES=[[0,'01 / 06 — the hook'],[2.2,'02 / 06 — the claim'],[4.7,'03 / 06 — pro-grade'],[7.2,'04 / 06 — the contrast'],[9.5,'05 / 06 — the proof'],[11.3,'06 / 06 — the tool']];
const DARK=[[0,2.2]];
const pad=n=>String(Math.floor(n)).padStart(2,'0');
const drv={t:0};
tl.fromTo(drv,{t:0},{t:DUR,duration:DUR,ease:'none',...IR,onUpdate:()=>{const t=drv.t;
  q('#prog').style.width=(t/DUR*100)+'%';
  q('#hudTc').textContent=`${pad(t/60)}:${pad(t%60)}:${pad((t%1)*60)} · 60 fps`;
  let lab=SCENES[0][1];for(const [s,l] of SCENES)if(t>=s)lab=l;q('#hudScene').textContent=lab;
  q('#hud').classList.toggle('dark',DARK.some(([a,b])=>t>=a&&t<b));
  const B=[['#bl1',40,30,.11],['#bl2',-50,35,.09],['#bl3',35,-40,.08],['#bl4',-45,-30,.1]];
  B.forEach(([s,ax,ay,f],i)=>{q(s).style.transform=`translate(${Math.sin(t*f*6.28+i)*ax}px,${Math.cos(t*f*6.28+i*2)*ay}px) scale(${1+Math.sin(t*f*3+i)*.05})`});
}},0);

// ================= BEATS (demo) =================
// S1 over footage
camZoom(0,2.3,1.0,1.06);
fadeIn('#s1k',0.15);
slot(qa('#s1 .cap')[0].querySelectorAll('.wi'),0.3);
slot(qa('#s1 .cap')[1].querySelectorAll(':scope > .w .wi'),0.85);
hilite('#s1h',1.1); slot('#s1h .wi',1.15,{ease:'back.out(2)'});
twinkle('#s1sp',1.35);
// -> tile wipe into S2
const sw1=tileWipe(1.75);
tl.set('#cam',{opacity:0},sw1);
cardIn('#s2c',sw1+0.05,{r0:-4,s:0.85,y:40});
slot('#s2c .hl.md .wi',sw1+0.35);
slot(qa('#s2c .hl')[1].querySelectorAll('.wi'),sw1+0.95,{rot:0,ease:'back.out(1.8)'});
slot(qa('#s2c .hl')[2].querySelectorAll('.wi'),sw1+1.35,{rot:0,ease:'back.out(1.8)'});
cardOut('#s2c',4.55,{x:-120,r:-4});
// S3 tiles
(()=>{const g=q('#s3g');const cols=['--lav','--peach','--mint','--sun','--sky','--lav','--peach','--mint','--sun','--sky','--lav','--peach'];
  const icons=['<path class="ln" d="M14 16a5 5 0 1 0 0 .1M14 38a5 5 0 1 0 0 .1M18 19l22 18M18 35l22-18"/>','<path d="M27 8 L40 27 L27 46 L14 27Z" fill="#5536EE"/>',
   '<circle class="ln" cx="27" cy="27" r="14"/><path class="ln" d="M27 8v10M27 36v10M8 27h10M36 27h10"/><circle cx="27" cy="27" r="4" fill="#5536EE"/>','<path class="ln" d="M10 27h4M18 18v18M24 12v30M30 18v18M36 22v10M42 27h3"/>',
   '<path class="ln" d="M27 10 L45 20 L27 30 L9 20Z M9 28 L27 38 L45 28"/>','<path class="ln" d="M14 12h26M27 12v32"/>','<circle class="ln" cx="23" cy="23" r="11"/><path class="ln" d="M31 31l11 11M23 18v10M18 23h10"/>',
   '<rect class="ln" x="11" y="11" width="32" height="32" rx="6"/><circle cx="27" cy="27" r="7" fill="#5536EE"/>','<path class="ln" d="M12 36a15 15 0 0 1 30 0M27 36l7-8"/>','<path class="ln" d="M12 42 C 22 42 22 12 42 12"/><circle cx="12" cy="42" r="3.5" fill="#15122A"/><circle cx="42" cy="12" r="3.5" fill="#15122A"/>',
   '<rect class="ln" x="8" y="16" width="26" height="22" rx="5"/><path class="ln" d="M34 24l12-7v20l-12-7"/>','<path class="ln" d="M27 10v34M10 27h34"/><circle cx="27" cy="27" r="3" fill="#5536EE"/>'];
  icons.forEach((ic,i)=>{const d=document.createElement('div');d.className='tile in';const c=i%4,r=Math.floor(i/4);
    d.style.cssText=`left:${636+c*172}px;top:${400+r*162}px;background:var(${cols[i]})`;d.innerHTML=`<svg viewBox="0 0 54 54">${ic}</svg>`;g.appendChild(d);});})();
pop(qa('#s3g .tile'),4.75,{s:0.3,r:-10,st:0.035,d:0.6});
fadeIn('#s3k',5.15); slot('#s3h .wi',5.3,{st:0.12}); pop('#s3d',6.0,{ease:'back.out(3)'});
tl.to(qa('#s3g .tile'),{y:-16,duration:2.2,ease:'sine.inOut',stagger:{each:0.04,from:'center'}},5.4);
tl.to('#s3',{opacity:0,filter:'blur(14px)',scale:1.04,duration:0.35,ease:E.i},7.0);
// S4 speaker card enters from the right
camSet(7.0,'cardR'); tl.set('#cam',{opacity:0},7.0);
cardIn('#cam',7.15,{r0:9,r1:2.5,s:0.7,y:120});
fadeIn('#s4k',7.35); slot('#s4 .wi',7.5,{st:0.25});
strike('#s4s1',8.05); strike('#s4s2',8.35); pop('#s4x',8.45,{r:-90}); fadeIn('#s4c',8.6);
camZoom(7.2,9.6,1.0,1.05);
cardOut('#s4 .hl',9.35,{y:-30}); fadeOut(['#s4k','#s4x','#s4c'],9.35);
cardOut('#cam',9.35,{x:300,r:8,s:0.8});
// S5 ring
pop('#s5r',9.55,{s:0.6,d:0.7,ease:'back.out(1.6)'}); draw('#s5a',9.6,1.2,'power2.out');
fadeIn('#s5k',9.6);
fadeIn('#s5n',9.7,{b:14}); count('#s5v',9.7,0,20,1.1); pop('#s5c',10.5,{s:0.6});
tl.to('#s5',{opacity:0,scale:0.92,filter:'blur(12px)',duration:0.32,ease:E.i},11.15);
// S6 sign-off
fadeIn('#s6k',11.35); slot('#s6 .wi',11.45,{d:0.85,rot:6,ease:'back.out(1.4)'}); pop('#s6d',11.95,{ease:'back.out(3.5)'}); pop('#s6c',12.15,{s:0.5});

tl.set({}, {}, DUR);
window.__timelines=window.__timelines||{}; window.__timelines.edit=tl;
window.hfSeek=t=>{qa('.clip').forEach(el=>{if(el.tagName==='VIDEO')return;const s=+el.dataset.start,d=+el.dataset.duration;el.style.display=(t>=s&&t<s+d)?'':'none'});tl.seek(t,false)};
</script>
</div>
</body></html>
```

## Scripts (write into the working folder)

### asr.py
```python
# python3 asr.py <16k mono wav> <out.json>  -> [{"w":word,"s":start}]
# model: curl -sSL https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8.tar.bz2 | tar xj -C ~/models
import sherpa_onnx, soundfile as sf, json, sys, os
d=os.path.expanduser('~/models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8/')
rec=sherpa_onnx.OfflineRecognizer.from_transducer(encoder=d+'encoder.int8.onnx',decoder=d+'decoder.int8.onnx',joiner=d+'joiner.int8.onnx',tokens=d+'tokens.txt',model_type='nemo_transducer',num_threads=2)
a,sr=sf.read(sys.argv[1],dtype='float32'); s=rec.create_stream(); s.accept_waveform(sr,a); rec.decode_stream(s); r=s.result
W=[];cur=None
for tok,t in zip(r.tokens,r.timestamps):
    if tok.startswith(' ') or cur is None:
        if cur: W.append(cur)
        cur={'w':tok.strip(),'s':round(t,2)}
    else: cur['w']+=tok
if cur: W.append(cur)
json.dump(W,open(sys.argv[2],'w')); print(' '.join(f"{i}:{w['w']}@{w['s']}" for i,w in enumerate(W)))
```

### cut.py
```python
# python3 cut.py SRC [W H]   (keep.json = [[s0,s1],...] source seconds) -> project/assets/aroll.mp4, voice_cut.wav, voice_cut16.wav, edit.json
import json, sys, subprocess, os
SRC=sys.argv[1]; W=int(sys.argv[2]) if len(sys.argv)>2 else 1920; H=int(sys.argv[3]) if len(sys.argv)>3 else 1080; FPS=30
os.makedirs('project/assets',exist_ok=True)
K=[(round(a*FPS)/FPS,round(b*FPS)/FPS) for a,b in json.load(open('keep.json'))]
fc=[]; segs=[]; o=0
for i,(a,b) in enumerate(K):
    d=b-a; segs.append({'src0':a,'src1':b,'out0':round(o,3),'out1':round(o+d,3)}); o+=d
    fc.append(f"[0:v]trim={a}:{b},setpts=PTS-STARTPTS,fps={FPS}[v{i}]")
    fc.append(f"[0:a]atrim={a}:{b},asetpts=PTS-STARTPTS,afade=t=in:d=0.012,afade=t=out:st={d-0.012:.3f}:d=0.012[a{i}]")
n=len(K); fc.append(''.join(f"[v{i}][a{i}]" for i in range(n))+f"concat=n={n}:v=1:a=1[vc][a]")
fc.append(f"[vc]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}[v]")
subprocess.run(['ffmpeg','-v','error','-y','-i',SRC,'-filter_complex',';'.join(fc),'-map','[v]','-map','[a]',
  '-c:v','libx264','-crf','17','-preset','medium','-g','15','-keyint_min','15','-sc_threshold','0','-pix_fmt','yuv420p',
  '-c:a','aac','-b:a','192k','-movflags','+faststart','project/assets/aroll.mp4'],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i','project/assets/aroll.mp4','-vn','-ac','2','-ar','48000','voice_cut.wav'],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i','voice_cut.wav','-ac','1','-ar','16000','voice_cut16.wav'],check=True)
json.dump({'segs':segs,'dur':round(o,3)},open('edit.json','w'),indent=1); print('dur',round(o,2),'segments',n)
```
Note: the card layouts crop the footage again with `object-fit:cover`, so keep the face near the centre-top (`object-position`).

### sfx.py
```python
# python3 sfx.py sfx.json -> sfx.wav ; events [[t,"whoosh|pop|tick|thump|swipe",dB],...]
import numpy as np, soundfile as sf, json, sys
from scipy import signal
SR=48000; rng=np.random.default_rng(7); DUR=json.load(open('edit.json'))['dur']
def env(n,a,tau): t=np.arange(n)/SR; return np.where(t<a,(t/a)**2,np.exp(-(t-a)/tau))
def filt(x,k,f,o=2): return signal.sosfilt(signal.butter(o,f,btype=k,fs=SR,output='sos'),x)
def nm(x): return x/(np.max(np.abs(x))+1e-9)
def st(y,p=0): return np.stack([y*(1-p),y*(1+p)],1)
def whoosh(dur=0.36,f0=450,f1=3000,peak=0.6):
    n=int(dur*SR); x=rng.standard_normal(n+4096); f,t,Z=signal.stft(x,SR,nperseg=1024,noverlap=768)
    fc=f0*(f1/f0)**np.clip(t/dur,0,1); M=np.exp(-0.5*(np.log(np.maximum(f[:,None],1)/fc[None,:])/0.45)**2)
    _,y=signal.istft(Z*M,SR,nperseg=1024,noverlap=768); y=y[:n]; u=np.arange(n)/n
    y=nm(y*np.where(u<peak,(u/peak)**2.2,np.exp(-(u-peak)/0.12))); p=np.linspace(-.3,.3,n); return np.stack([y*(1-p),y*(1+p)],1)*.8
def pop(f0=700,f1=320,dur=0.1):
    n=int(dur*SR); t=np.arange(n)/SR; f=f1+(f0-f1)*np.exp(-t/0.016)
    return st(nm(filt(np.sin(2*np.pi*np.cumsum(f)/SR)*env(n,0.002,0.026),'low',6000)))
def tick(dur=0.05):
    n=int(dur*SR); return st(nm(filt(rng.standard_normal(n),'band',[2500,8000])*env(n,0.0005,0.006)))
def thump(dur=0.35):
    n=int(dur*SR); t=np.arange(n)/SR; f=46+60*np.exp(-t/0.03)
    return st(nm(np.sin(2*np.pi*np.cumsum(f)/SR)*env(n,0.003,0.09)))
def swipe(dur=0.2):
    n=int(dur*SR); return st(nm(filt(rng.standard_normal(n),'band',[1800,7000])*np.sin(np.pi*np.arange(n)/n)**2))
G=dict(whoosh=whoosh,pop=pop,tick=tick,thump=thump,swipe=swipe)
N=int(DUR*SR); out=np.zeros((N+SR,2))
for t,k,db,*kw in json.load(open(sys.argv[1])):
    x=G[k](**(kw[0] if kw else {})); x=x/np.max(np.abs(x))*10**(db/20); i=int(t*SR); out[i:i+len(x)]+=x[:len(out)-i]
sf.write('sfx.wav',out[:N].astype(np.float32),SR,subtype='FLOAT')
```
Mix (target -14 LUFS, -1.5 dBTP):
```bash
ffmpeg -y -i voice_cut.wav -af "highpass=f=70,acompressor=threshold=-24dB:ratio=2.2:attack=8:release=140:makeup=2" -ar 48000 v1.wav
ffmpeg -i v1.wav -af loudnorm=print_format=summary -f null - 2>&1 | grep "Input Integrated"   # X
ffmpeg -y -i v1.wav -af "volume=$(python3 -c 'print(-14-(X)+0.2)')dB,alimiter=limit=0.82:level=disabled" -ar 48000 vp.wav
ffmpeg -y -i vp.wav -i sfx.wav -filter_complex "[0:a][1:a]amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.84:level=disabled[a]" -map "[a]" -ar 48000 project/assets/mix.wav
```
Then add `<audio id="mix" data-start="0" data-duration="DUR" data-track-index="9" src="assets/mix.wav"></audio>` inside `#edit`.

### render_fallback.py (only when the HyperFrames CLI is unavailable)
```python
# python3 render_fallback.py project out.mp4 [fps] [t1,t2,... -> snapshots out.mp4_<t>.jpg instead of a video]
import sys, re, subprocess, pathlib
from playwright.sync_api import sync_playwright
P=pathlib.Path(sys.argv[1]).resolve(); OUT=sys.argv[2]; FPS=int(sys.argv[3]) if len(sys.argv)>3 else 30
html=open(P/'index.html').read()
D=float(re.search(r'id="edit"[^>]*data-duration="([\d.]+)"',html).group(1))
W=int(re.search(r'data-width="(\d+)"',html).group(1)); H=int(re.search(r'data-height="(\d+)"',html).group(1))
fr=P/'_frames'; fr.mkdir(exist_ok=True); [f.unlink() for f in fr.glob('*.jpg')]
subprocess.run(['ffmpeg','-v','error','-y','-i',str(P/'assets/aroll.mp4'),'-vf',f'fps={FPS}','-q:v','2',str(fr/'%05d.jpg')],check=True)
nf=len(list(fr.glob('*.jpg'))); snaps=[float(x) for x in sys.argv[4].split(',')] if len(sys.argv)>4 else None
mix=P/'assets/mix.wav'
cmd=['ffmpeg','-v','error','-y','-f','image2pipe','-framerate',str(FPS),'-i','-']+(['-i',str(mix),'-map','0:v','-map','1:a','-c:a','aac','-b:a','192k','-shortest'] if mix.exists() else [])+['-c:v','libx264','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',OUT]
enc=None if snaps else subprocess.Popen(cmd,stdin=subprocess.PIPE)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--allow-file-access-from-files']); pg=b.new_page(viewport={'width':W,'height':H})
    pg.goto((P/'index.html').as_uri()); pg.evaluate("document.fonts.ready")
    pg.evaluate("""()=>{const v=document.getElementById('aroll');const im=document.createElement('img');im.id='fb';
      im.style.cssText='width:100%;height:100%;object-fit:cover;display:block;object-position:'+getComputedStyle(v).objectPosition;v.after(im);v.style.display='none'}""")
    for t in (snaps or [n/FPS for n in range(int(round(D*FPS)))]):
        f=fr/f'{min(int(t*FPS)+1,nf):05d}.jpg'
        pg.evaluate("async([t,u])=>{const im=document.getElementById('fb');im.src=u;await im.decode();hfSeek(t)}",[t,f.as_uri()])
        img=pg.screenshot(type='jpeg',quality=92)
        if snaps: open(f'{OUT}_{t:05.2f}.jpg','wb').write(img)
        else: enc.stdin.write(img)
    b.close()
if enc: enc.stdin.close(); enc.wait()
```
It renders ~1–2 frames/s; snapshot mode (`… out 30 0.6,2.4,5.0`) is the fast way to check beats.
