# Revision notes — existing libraries improved, not replaced

## Changes
- Preserved all 41 Markdown styles, all 24 original JSON caption IDs, 45 effect IDs and 8 sound IDs. No original resource was deleted.
- Kept exact original files in originals/. Preserve these as evidence; do not treat them as new production instructions.
- Added a separate CAP01–CAP41 catalog. The two old libraries use different numbering; no false crosswalk was invented.
- Added narrative-purpose selection, role separation, source/claim checks, optional SFX, caption timing and multilingual/accessibility rules.
- Removed universal-safe-zone authority from arbitrary coordinates; declared canvas references, anchors, font-unit uncertainty and animated bounds.
- Corrected known Markdown ASS cyan/VHS color mistakes, rounded-box claim, cursor blink-loop claim and slice-displacement claim.
- Original JSON command snippets are retained in legacy_examples and explicitly deprecated as executable instructions. This is safer than presenting incomplete sketches as tested adapters.
- Kept web/UI skills as supporting video resources and Matter.js/p5.brush/GSAP as dependencies. Evil Buttons' registry-documentation skill is distinguished from its reusable visual components.
- Added deterministic web-to-video, physics, GPU, font/media readiness, transparency, audio and fallback contracts.
- Added six renderer-independent motion design recipes; they are design contracts, NOT new working renderer implementations.
- Added separate technical/campaign/creative/performance status and explicit unknown-evidence handling.

## Validation
See VALIDATION_REPORT.json for actual structural/preservation/schema checks. Source videos were not rewatched; motion/audio rendering and licensing of every external asset were not tested. No views/quality guarantees are made.

## Compatibility
The JSON is version 2.0.0. Original arrays and IDs remain, but command fields are deliberately deprecated and new fields added. Test or migrate any existing consumer; do not silently replace a production file and assume compatibility. The supplied schema validates the reference document, not a complete executable timeline or renderer.

## Adoption
Use CAPTION_LIBRARY_v2.md as the human guide and EFFECTS_AND_CAPTIONS_SPEC_v2.json as the structured reference. Attach only the selected style/operation to an edit. Current campaign requirements override all library defaults. Back up the existing project, then smoke-test a representative caption and planned graphic in the exact installed renderer before scaling.
