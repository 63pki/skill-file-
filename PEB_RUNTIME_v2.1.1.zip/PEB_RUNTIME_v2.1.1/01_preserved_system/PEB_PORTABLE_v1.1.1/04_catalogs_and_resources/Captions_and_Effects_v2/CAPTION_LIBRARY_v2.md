# Caption Style Library — v2

This is a revision of your existing 41-style library, not a replacement style pack.
Original visual descriptions and numbering are retained below. New production contracts
separate what a style looks like from what is actually supported and tested.

## Read first: authority and evidence

- The current campaign brief, permissions, truthful source meaning and accessibility come first.
- A style is a creative option, never a requirement to add motion, music, narration or a headline.
- Original source recordings and previews were not reopened in this revision. Historical “verified” notes are not new verification; all backend implementations remain untested here.
- Styles 01–41 use machine IDs CAP01–CAP41. These are NOT the same IDs as the older JSON's 24 caption_styles. The revised JSON includes a separate caption_library_catalog; no false 1:1 crosswalk is assumed.
- No preset guarantees retention or views. Quiet, readable captions can be the right finished design; elaborate graphics must add communication value.

## Production selection: choose a job, not decoration

| Job | Good starting choices | Production decision |
|---|---|---|
| Dialogue readability | 09, 17, 19, 30 | Phrase-level grouping; preserve meaningful pauses and source subtitles |
| One justified emphasis | 01, 02, 06, 16, 18, 37 | Keep phrase context readable; do not pop every word |
| Calm/luxury narrative | 03, 11, 19, 20 | Actual font/contrast checks; no forced gold or serif if the brand differs |
| Explanatory number/claim | 07, 15, 21, 39 | Approved claim, units, qualifier, date and source required |
| UI/product demonstration | 15, 17, 21, 30 | Preserve the actual interface; simulate only clearly labeled/approved reconstructions |
| Stylized graphic insert | 04, 24, 27, 28, 33–36, 41 | Treat as supporting graphics, not automatically as speech-caption styles |
| Accessibility-first baseline | 09, 17, 19 | Use readable contrast, actual script shaping and an accurate transcript/sidecar |

These are recommendations, not an eligibility score or fixed runtime recipe.

## Caption versus title versus demonstration

A speech caption represents what was said. A hook/title adds an editorial statement and needs source support.
A UI label describes an action/state. A diagram or stat card is evidence-bearing graphics, not “just captions.”
Do not put the same phrase in a giant hero layer and a competing subtitle layer. If source subtitles are baked in,
inspect them first; preserve, reframe, or replace only as authorized. Do not hide negations/qualifiers to make text punchier.
Emoji may supplement speech; an accessible transcript must keep meaningful spoken words.

## Timing and geometry contract

- Use rational project fps and output integer frames; intervals are [start, end_exclusive).
- Map source transcript/word timings through actual cuts and speed changes. ASR times are estimates.
- Phrase at semantic boundaries, not arbitrary word counts. Review reading load at phone size.
- The illustrative 1080×1920 canvas is configurable. Older JSON entries refer to 720×1280 coordinates; scale those as references, not font-metric truth.
- Declare anchor and actual text bounds. CSS px, ASS FontSize and a legacy “pt” label are not interchangeable.
- Use current platform UI masks and per-shot face/product/source-text exclusions. No universal y-coordinate proves safety.
- Inspect all frames of overshoot, rotation, glow and shake for bounds—not only the resting frame.
- For multilingual content, validate shaping, bidi, punctuation, segmentation, fallback glyphs and emoji in the exact renderer.

## Web/UI resources are allowed—through a video adapter

Web UI can be excellent video material: cards, cursor-led demonstrations, shader backgrounds, line drawings and procedural graphics.
Remotion/HyperFrames can render compatible implementations, not arbitrary code without adaptation.
Mirage tsrct can use supported native layers/imported assets, not run arbitrary React/DOM code natively.

For every web-derived effect:
1. Convert pointer/hover/drag/scroll inputs to an explicit time-indexed event/state sequence.
2. Seek using output frame time; avoid live requestAnimationFrame clocks, Date.now, uncontrolled randomness or network-dependent state.
3. Fix viewport/pixel ratio, fonts, asset versions and color/alpha policy. Wait for fonts/media/GPU completion.
4. For physics/cumulative drawing, reset and replay deterministic steps or use validated checkpoints. Test out-of-order frame seeking.
5. Verify actual WebGPU/WebGL/WAAPI support in the headless backend. A normal browser preview is not sufficient.
6. Render a tiny representative fixture before scaling. Keep a simpler supported fallback.

Keep Cube Motion, Oil Motion, ShaderCN/TypeGPU and Hairline as supporting resources where appropriate.
Keep Evil Buttons' visual components as assets; its inspected docs/registry maintenance skill is not an editing skill.
Matter.js, p5.brush and GSAP remain useful dependencies even without their own editing SKILL.md.
The JSON web_ui_resources array contains direct sources and adaptation limits.

## Correct implementation distinctions

- ASS colors use BGR order: #00D7FF cyan becomes style color &H00FFD700 and override \1c&HFFD700&. #E8E4D8 becomes &H00D8E4E8.
- ASS BorderStyle=3 provides a rectangular box, not rounded corners. BorderStyle=1 + BackColour is not a rounded pill. Use a tested rounded shape/mask behind text for true rounded geometry.
- A shadow is not a true soft neon glow. A flat color is not a gradient fill. Label simplified fallbacks honestly.
- A single \fad does not loop a cursor blink. Schedule repeated opacity events or a frame-derived cursor state.
- \frx is a 3D rotation, not horizontal slice displacement. RGB/glitch slices need actual layered masks/offsets or a supported shader.
- Typewriter animation is optional for designed UI/code text; it may obstruct ordinary speech captions. Readable final text is the priority.
- Karaoke sweep requires shaped word geometry and correct timing; changing a whole word's color is a valid simpler fallback, not a true progressive fill.
- Perpetual jitter/flicker, one-word-only reading, and mandatory SFX are style choices—not rules. Provide a reduced-motion/static alternative.
- Preview paths are historical references; this download does not include the original preview images.

## Backend test and handoff

The original ASS/drawtext strings below are legacy sketches, not tested commands. Some are incomplete or require assets.
Implement the selected treatment with the actual installed backend and fonts; validate escaping, units, timing and layout.
Do not inject untrusted text into shell commands. Preserve local assets and a reproducible project/EDL.

Before release: technical decode/geometry/sync checks; campaign rights/claims/brand checks; actual motion review;
and listening where available. Missing evidence is NOT_CHECKED, not PASS. Keep audience performance separate.

## Legacy visual catalog (preserved, with corrected technical notes)

The following original look/best-for/placement descriptions are style-local starting points.
A legacy “never,” “always,” duration, safe-zone claim, or predicted retention benefit does not override the contracts above.


Source: user's screen recording `caption_styles_raw.mp4` (5:00, captured 2026-10-17).
Purpose: pick a style per video type instead of rebuilding captions from scratch.
Each style has a preview, the look spec, best-for tags, a complete instruction
set (Motion — how words should move; Words on screen — how many stay visible;
Placement — where it sits, with safe zones; Don'ts — what ruins the style),
a footage-verification flag, and an unvalidated FFmpeg/ASS starting sketch.

**Honesty note (2026-10-18):** the four source videos are screen recordings of
*static* Pinterest pins — no caption motion is observable in them (the one
playing pin was scrubbed, never played). So every **Motion** field is *inferred
performance direction*, not measured timing; treat any timing figures as
suggested starting points, to be tuned against real playing footage.
**Words on screen** and **Placement** were verified against the footage where
the flag says so. Styles 22–41 come from web research and do not appear in
the source videos.

Presets use ASS subtitle styles (for kinetic word-by-word captions via
`subtitles=clip.ass`) and drawtext params (for static hooks). Colors are
`&HAABBGGRR`. Base font on this machine: DejaVu Sans Bold (swap for
Montserrat ExtraBold / Anton / Bebas when available).

---

## 01 — Keyword Pop Cyan

**v2 authoring ID:** `CAP01` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
**Implementation checks:** true_gradient_requires_supported_masked_fill_or_asset.
Historical preview reference: `previews/01_keyword_pop_cyan.jpg` (image not bundled).
- **Look:** small white sentence, one KEYWORD in large bold cyan (#00D7FF-ish),
  centered mid-frame. Keyword scales up with a pop.
- **Animation:** word-by-word reveal; keyword pops + color-flips on its beat.
- **Best for:** talking-head explainers, marketing/business, feature callouts.
- **Motion:** Words appear one at a time, synced to speech (a beat apart). The keyword scales from 60% to 100% with a quick overshoot pop and flips white to cyan exactly on its spoken beat, then holds.
- **Words on screen:** Full short sentence on screen (5-9 words); exactly ONE keyword per sentence gets the cyan pop.
- **Placement:** Centered mid-frame (y about 40-55% of frame height). Keep the bottom edge above y=1500 on 1080x1920 (Shorts UI zone).
- **Don'ts:** Don't pop more than one keyword per sentence - it kills the emphasis. Don't use cyan over bright sky/water footage without the black stroke. Don't run sentences past 10 words.
- **Historical evidence note (not reverified in v2):** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: KW-Cyan,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,40,1`
  keyword override: `{\1c&HFFD700&\fs80}` on the keyword.
- **Legacy drawtext sketch — implementation untested:** `fontsize=64:fontcolor=#00D7FF:borderw=3`

## 02 — Keyword Pop Purple

**v2 authoring ID:** `CAP02` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
**Implementation checks:** true_gradient_requires_supported_masked_fill_or_asset.
Historical preview reference: `previews/02_keyword_pop_purple.jpg` (image not bundled).
- **Look:** same mechanic as 01 but keyword in bold purple/magenta gradient.
- **Animation:** word-by-word; keyword punches in larger.
- **Best for:** bold claims, numbers ("9 years"), contrarian hooks.
- **Motion:** Word-by-word reveal like 01; the keyword punches in at ~130% size with a hard pop on its beat.
- **Words on screen:** 2+ words per pin observed; one keyword only — longer 5-9 word sentences not evidenced in footage.
- **Placement:** Centered mid-frame; same safe zone as 01.
- **Don'ts:** Don't use for soft or emotional topics - purple reads aggressive. Don't place over red/pink backgrounds (color vibration). One keyword only.
- **Historical evidence note (not reverified in v2):** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: KW-Purple,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,40,1`
  keyword override: `{\1c&H00C832C8&\fs80}`
- **Legacy drawtext sketch — implementation untested:** `fontsize=64:fontcolor=#C832C8:borderw=3`

## 03 — Gold Serif Luxe

**v2 authoring ID:** `CAP03` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** font_and_contrast_review.
Historical preview reference: `previews/03_gold_serif_luxe.jpg` (image not bundled).
- **Look:** elegant gold serif (think Playfair/Bodoni), sentence case, slight
  letterspacing, no stroke — floats over dark footage.
- **Animation:** slow fade/word reveal; calm, premium pacing.
- **Best for:** finance, luxury, cinematic drama, "billion dollar" energy.
- **Motion:** Words fade in one by one, slow (slowly, roughly a beat apart), no bounce - calm reveal. The full line holds briefly, then fades out.
- **Words on screen:** One elegant line, 4-8 words, sentence case.
- **Placement:** Center or upper-center, over dark or empty background. Never over faces.
- **Don'ts:** Don't use on bright or busy footage - gold washes out. Don't add stroke (kills the luxe feel). Don't use for comedy or memes.
- **Historical evidence note (not reverified in v2):** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: Gold-Serif,DejaVu Serif Bold,58,&H0034C8F0,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,30,30,60,1`
  (gold ≈ #F0C834 → ASS `&H0034C8F0`)
- **Legacy drawtext sketch — implementation untested:** `fontfile=DejaVuSerif-Bold.ttf:fontsize=58:fontcolor=#F0C834`

## 04 — Neon Glow

**v2 authoring ID:** `CAP04` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** motion_or_flash_review, reduced_motion_required.
Historical preview reference: `previews/04_neon_glow.jpg` (image not bundled).
- **Look:** warm orange neon-sign glow on dark background, soft outer glow,
  slightly condensed bold sans.
- **Animation:** flicker-in like a real sign; holds steady.
- **Best for:** nightlife, gaming, energetic hooks, Spanish/party content.
- **Motion:** Words flicker in like a sign powering on (2-3 quick opacity blinks), then hold with a soft pulsing glow. Exit with a quick fade.
- **Words on screen:** 1-5 words max - short punchy phrases only.
- **Placement:** Center frame, over dark areas. Glow needs darkness to read.
- **Don'ts:** Don't use on bright footage. Don't exceed 5 words - glow becomes mush. Don't use thin fonts.
- **Historical evidence note (not reverified in v2):** ⚠ needs human review — preview shows no caption text; style not located in footage.
- **Legacy ASS sketch — implementation untested:**
  `Style: Neon,DejaVu Sans Bold,66,&H00007AFF,&H000000FF,&H000A1AFF,&H00000000,-1,0,0,0,100,100,0,0,1,1.5,6,5,30,30,40,1`
  (orange #FF7A00 → ASS `&H00007AFF`; glow via Shadow=6)
- **Legacy drawtext sketch — implementation untested:** `fontsize=66:fontcolor=#FF7A00:shadowcolor=#FF7A00:shadowx=0:shadowy=0` (+ borderw=1)

## 05 — Outline Stroke

**v2 authoring ID:** `CAP05` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/05_outline_stroke.jpg` (image not bundled).
- **Look:** huge hollow letters — white outline, transparent fill — bottom
  third, overlaps subject.
- **Animation:** slides/pops per word; fill flashes on beat words.
- **Best for:** sporty edits, hype moments, single-word emphasis.
- **Motion:** Words slide up from below with a slight overshoot, staying hollow the whole time. No fill change.
- **Words on screen:** 1-4 big words; the outline scales with the size.
- **Placement:** Center or lower-center; works over mid-tone footage.
- **Don'ts:** Don't use small text - outline eats legibility under ~60px. Don't use on very busy backgrounds. For the hollow-to-fill variant see 38.
- **Historical evidence note (not reverified in v2):** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: Outline,DejaVu Sans Bold,96,&H00FFFFFF,&H000000FF,&H00FFFFFF,&H00000000,-1,0,0,0,100,100,0,0,3,3,0,2,20,20,30,1`
  (BorderStyle=3 = opaque box off, hollow look via Outline=3 + transparent fill trick:
  use `PrimaryColour=&H00000000` transparent + `OutlineColour=&H00FFFFFF`)
- **Legacy drawtext sketch — implementation untested:** fill transparent isn't direct — use `fontcolor=white:borderw=4` at
  large size, or render text PNG mask for true hollow.

## 06 — White/Cyan Mix

**v2 authoring ID:** `CAP06` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
Historical preview reference: `previews/06_white_cyan_mix.jpg` (image not bundled).
- **Look:** full sentence in white bold, the punch words switch to cyan
  mid-sentence ("doesn't build"). Two-tone emphasis.
- **Animation:** word-by-word; color flips on the punch words.
- **Best for:** argumentative takes, before/after, myth-busting.
- **Motion:** Two-tone sentence: white words appear steadily, cyan keywords pop on their beats.
- **Words on screen:** 6-10 words; 1-2 cyan keywords max.
- **Placement:** Lower-center, above the safe-zone line.
- **Don'ts:** Don't turn more than 2 words cyan. Don't park it high - this style lives low.
- **Historical evidence note (not reverified in v2):** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:** same base as 01; punch-word override `{\1c&H00D7FF&}`.
- **Legacy drawtext sketch — implementation untested:** base `fontcolor=white:borderw=3`, punch line separate call in cyan.

## 07 — Stat Highlight

**v2 authoring ID:** `CAP07` · role `data_callout` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/07_stat_highlight.jpg` (image not bundled).
- **Look:** stat/number in bold orange on near-black, compact, upper area —
  scoreboard energy.
- **Animation:** counts up or slams in with impact shake.
- **Best for:** stats, records, "X years", money numbers.
- **Motion:** The number counts up (0 to target quickly) while the highlight box wipes in behind it left-to-right.
- **Words on screen:** Number + 1-3 word label.
- **Placement:** Center frame, large.
- **Don'ts:** Don't use for non-numeric claims. Don't shrink the number - it's the hero.
- **Historical evidence note (not reverified in v2):** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: Stat,DejaVu Sans Bold,72,&H00007AFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,3,1,8,30,30,30,1`
- **Legacy drawtext sketch — implementation untested:** `fontsize=72:fontcolor=#FF7A00:borderw=3:x=(w-text_w)/2:y=300`

## 08 — Portfolio Card

**v2 authoring ID:** `CAP08` · role `editorial_title` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/08_portfolio_card.jpg` (image not bundled).
- **Look:** not a caption — a framed card layout: title top ("our work"),
  video inset, handle bottom. Cream background.
- **Animation:** n/a (layout template).
- **Best for:** end cards, "more like this" outros, client showcases.
- **Motion:** The card slides up from the bottom, text fades in inside it; it holds like a lower-third ident.
- **Words on screen:** Name/title: 2-6 words, plus a one-line subtitle.
- **Placement:** Bottom-left or bottom-center, above the safe zone.
- **Don'ts:** Don't use mid-video - it's an intro/outro card. Don't animate it word-by-word.
- **Historical evidence note (not reverified in v2):** ⚠ needs human review — preview shows a keyword-pop talking-head pin, not a card layout; entry unverified.
- **Legacy ASS sketch — implementation untested:** n/a — layout template, not a subtitle style.
- **Legacy drawtext sketch — implementation untested:** compose in ffmpeg: `color=c=cream:s=1080x1920` background +
  `overlay` the scaled video inset + `drawtext` title/handle.

---

## How to use (revised)
1. Select the narrative/readability job and check the campaign audio, brand and subtitle requirements.
2. Choose one compatible style or no added text. Read the v2 contracts first.
3. Use the matching CAPxx entry in the revised JSON; do not assume it maps to an old numbered JSON style.
4. Resolve text, source-to-output timing, fonts, layout and exclusions for the actual shot.
5. Implement in one verified backend; old command sketches are not a ready-to-run guarantee.
6. Test playback, phone-scale readability, accessibility and the final encoded output. Record unknown checks honestly.

## To add a style
Drop a preview in `previews/`, append a section in this file with the same
fields. Source videos: `caption_styles_raw.mp4` (5:00), `styles_v2_mobile.mp4`
(0:59), `styles_v3_18s.mp4` (0:18), `styles_v4_2min.mp4` (1:57).

---

## 09 — TikTok Pill

**v2 authoring ID:** `CAP09` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** rounded_mask_or_shape_compositor.
Historical preview reference: `previews/09_tiktok_pill.jpg` (image not bundled).
- **Look:** white medium-weight sentence on a solid black rounded pill,
  centered mid-frame. The classic auto-caption look.
- **Animation:** word-by-word inside the pill; pill resizes per phrase.
- **Best for:** talking head, explainers, any dialogue-heavy clip — maximum readability, zero distraction.
- **Motion:** The pill pops in together with the word (scale 80 to 100%), holds for the phrase, pops out.
- **Words on screen:** 2-7 words observed; a 7-word pill renders cleanly — the length limit is softer than stated.
- **Placement:** Lower-center, above the safe zone.
- **Don'ts:** Don't stack two pills at once. Don't use long sentences - the pill stretches awkwardly.
- **Historical evidence note (not reverified in v2):** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: Pill,DejaVu Sans Bold,54,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,30,30,60,1`
  (Neither BorderStyle=1 nor BorderStyle=3 makes a rounded pill. Use a tested
  rounded shape/mask layer behind the text; BorderStyle=3 is rectangular.)
- **Legacy drawtext sketch — implementation untested:** `fontsize=54:fontcolor=white:box=1:boxcolor=black:boxborderw=18`

## 10 — Yellow Marker Highlight

**v2 authoring ID:** `CAP10` · role `speech_caption` · motion `MOTION_HIGHLIGHT_SWEEP` · runtime status `not_tested`.
Historical preview reference: `previews/10_yellow_marker.jpg` (image not bundled).
- **Look:** huge condensed word in blue/black on a full-bleed yellow (#FFEB00)
  panel — highlighter energy, takes over the frame.
- **Animation:** slams in with a hard cut; holds.
- **Best for:** warnings, "STOP" moments, pattern interrupts, hooks that need a visual slap.
- **Motion:** The keyword appears in white first, then the yellow marker swipes behind it left-to-right (quickly).
- **Words on screen:** Full sentence of 5-9 words; 1-2 highlighted keywords.
- **Placement:** Center or lower-center.
- **Don'ts:** Don't highlight whole sentences. Don't use yellow text on the yellow highlight.
- **Historical evidence note (not reverified in v2):** ⚠ needs human review — preview shows blue block text on solid yellow ("STOP" pin), not a marker swipe; entry unverified. Same pin resembles style 22's layout.
- **Legacy ASS sketch — implementation untested:**
  `Style: Marker,DejaVu Sans Bold,110,&H00FF0000,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,30,30,20,1`
  over a yellow full-frame color clip (`color=c=0xFFEB00:s=1080x1920`).
- **Legacy drawtext sketch — implementation untested:** on yellow bg — `fontsize=110:fontcolor=#0000FF:borderw=0`

## 11 — Script + Serif Mix

**v2 authoring ID:** `CAP11` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** font_and_contrast_review.
Historical preview reference: `previews/11_script_serif_mix.jpg` (image not bundled).
- **Look:** elegant script word (flowing italic) paired with bold serif caps
  ("Samira" script over "PODCAST" serif). Feminine, premium.
- **Animation:** script writes on; serif fades up beneath.
- **Best for:** podcasts, branding, fashion/beauty, creator intros.
- **Motion:** The script word writes on with a stroke reveal (about a second), then the serif line fades in beneath it.
- **Words on screen:** 1 script word + 4-7 serif words.
- **Placement:** Center, over clean background.
- **Don'ts:** Don't use two script words together. Don't rush the write-on under 800ms.
- **Historical evidence note (not reverified in v2):** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: ScriptMix,DejaVu Serif Italic,72,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2,1,5,30,30,50,1`
  (no script font on box — approximate script with Serif Italic)
- **Legacy drawtext sketch — implementation untested:** `fontfile=DejaVuSerif-Italic.ttf:fontsize=72:fontcolor=white:borderw=2`

## 12 — Collegiate Outline

**v2 authoring ID:** `CAP12` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/12_collegiate_outline.jpg` (image not bundled).
- **Look:** varsity/college block letters, white fill with dark outline,
  slight arch — "TREND" energy.
- **Animation:** letter-by-letter drop-in with bounce.
- **Best for:** sport, streetwear, hype, trend-jacking hooks.
- **Motion:** Words slam in with a tiny shake; the arched varsity feel comes from wide letterspacing.
- **Words on screen:** 1-3 words, ALL CAPS.
- **Placement:** Upper-center (like a jersey chest print).
- **Don'ts:** Don't use lowercase - kills the look. Don't use on formal or luxury content.
- **Historical evidence note (not reverified in v2):** ⚠ needs human review — preview shows ransom-cutout letters ("TreNd"), not varsity outline; entry unverified.
- **Legacy ASS sketch — implementation untested:**
  `Style: Collegiate,DejaVu Sans Bold,90,&H00FFFFFF,&H000000FF,&H64000000,&H00000000,-1,0,0,0,100,100,0,0,1,4,0,5,30,30,40,1`
- **Legacy drawtext sketch — implementation untested:** `fontsize=90:fontcolor=white:borderw=5:bordercolor=black`

## 13 — Magenta Mix

**v2 authoring ID:** `CAP13` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
Historical preview reference: `previews/13_magenta_mix.jpg` (image not bundled).
- **Look:** stacked lines mixing thin sans ("MAKE LIFE YOUR") with big
  magenta/pink italic serif ("Masterpiece"). Editorial, magazine feel.
- **Animation:** lines stagger in; magenta word scales up last.
- **Best for:** motivational, lifestyle, glow-up content.
- **Motion:** Word-by-word like 01; the magenta keyword pops on its beat.
- **Words on screen:** 5-9 words; one keyword.
- **Placement:** Centered mid-frame.
- **Don'ts:** Don't use over pink/red footage. One keyword only.
- **Historical evidence note (not reverified in v2):** ⚠ needs human review — preview shows no magenta text; style not located in footage.
- **Legacy ASS sketch — implementation untested:**
  `Style: MagentaMix,DejaVu Serif BoldItalic,80,&H00802AC8,&H000000FF,&H00000000,&HAA000000,0,0,0,0,100,100,0,0,1,2,1,5,30,30,50,1`
  (magenta #C82AA0 → ASS `&H00802AC8`)
- **Legacy drawtext sketch — implementation untested:** `fontfile=DejaVuSerif-BoldItalic.ttf:fontsize=80:fontcolor=#C82AA0:borderw=2`

## 14 — Thin Lowercase Stack

**v2 authoring ID:** `CAP14` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/14_thin_lowercase.jpg` (image not bundled).
- **Look:** thin/light lowercase sans, stacked 2-3 lines, small, quiet —
  "filming content ideas". Anti-hype, aesthetic.
- **Animation:** soft fade per line.
- **Best for:** vlogs, BTS, aesthetic montages, soft storytelling.
- **Motion:** Lines fade in one by one, slow, no bounce - quiet and airy.
- **Words on screen:** 2-4 short stacked lines, 1-3 words each, all lowercase.
- **Placement:** Center or left-center with lots of breathing room.
- **Don'ts:** Don't use all caps (destroys the aesthetic). Don't crowd it - it needs negative space.
- **Historical evidence note (not reverified in v2):** ⚠ needs human review — preview shows only search UI, no caption; style not located in footage.
- **Legacy ASS sketch — implementation untested:**
  `Style: ThinStack,DejaVu Sans,44,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,0,0,0,0,100,100,0,0,1,1.5,0,5,40,40,80,1`
- **Legacy drawtext sketch — implementation untested:** `fontsize=44:fontcolor=white:borderw=1` (DejaVu Sans has no
  light weight — closest available)

## 15 — Label Tag

**v2 authoring ID:** `CAP15` · role `ui_label` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** rounded_mask_or_shape_compositor.
Historical preview reference: `previews/15_label_tag.jpg` (image not bundled).
- **Look:** tiny black bold-condensed caps on a white rounded label
  ("STATIC SHOT"), top area — like a camera UI tag.
- **Animation:** pops in once, holds as a persistent tag.
- **Best for:** shot labels, series tags ("EP 3", "POV"), tech callouts.
- **Motion:** The tag slides in from the side together with its word; holds like a sticker label.
- **Words on screen:** 1-3 words per tag.
- **Placement:** Near the subject it labels (face, product).
- **Don'ts:** Don't cover faces with the tag. Don't put more than 2 tags on screen.
- **Historical evidence note (not reverified in v2):** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: LabelTag,DejaVu Sans Bold,34,&H00000000,&H000000FF,&H00000000,&H00FFFFFF,-1,0,0,0,100,100,0,0,1,0,0,8,30,30,30,1`
- **Legacy drawtext sketch — implementation untested:** `fontsize=34:fontcolor=black:box=1:boxcolor=white:boxborderw=12:x=(w-text_w)/2:y=180`

## 16 — Lime Keyword Pop

**v2 authoring ID:** `CAP16` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
Historical preview reference: `previews/16_lime_keyword.jpg` (image not bundled).
- **Look:** small white lead-in ("to", "even if") + KEYWORD in huge bold
  lime/neon green (#BFFF00). Electric, can't-miss.
- **Animation:** keyword slams in on the beat; lead-in stays small.
- **Best for:** money talk, results, bold promises, high-energy hooks.
- **Motion:** Word-by-word like 01; the lime keyword slams in with high energy.
- **Words on screen:** 4-7 words; one LARGE lime keyword + small white context words.
- **Placement:** Centered mid-frame.
- **Don'ts:** Don't use over green footage. Lime means high energy - not for calm topics.
- **Historical evidence note (not reverified in v2):** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: Lime,DejaVu Sans Bold,60,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,50,1`
  keyword override: `{\1c&H0000FFBF&\fs92}` (lime #BFFF00 → ASS `&H0000FFBF`)
- **Legacy drawtext sketch — implementation untested:** keyword `fontsize=92:fontcolor=#BFFF00:borderw=3`

## 17 — Dark Pill

**v2 authoring ID:** `CAP17` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** rounded_mask_or_shape_compositor.
Historical preview reference: `previews/17_dark_pill.jpg` (image not bundled).
- **Look:** white text on a dark red/maroon (#7A1F1F) rounded pill with a
  small warning icon — alert/answer style.
- **Animation:** slides in from side; holds as Q&A card.
- **Best for:** FAQs, "what to say?", objections, quiz hooks.
- **Motion:** The pill fades/slides in with the text; calm hold, no bounce.
- **Words on screen:** 3-7 words.
- **Placement:** Lower-center, above the safe zone.
- **Don'ts:** Stacking two pills is demonstrated in the source footage itself — allowed, not forbidden. Don't use on dark footage (pill disappears).
- **Historical evidence note (not reverified in v2):** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: DarkPill,DejaVu Sans Bold,46,&H00FFFFFF,&H000000FF,&H00000000,&H001F1F7A,-1,0,0,0,100,100,0,0,1,0,0,5,30,30,60,1`
  (maroon #7A1F1F → ASS `&H001F1F7A`)
- **Legacy drawtext sketch — implementation untested:** `fontsize=46:fontcolor=white:box=1:boxcolor=#7A1F1F:boxborderw=16`

---

## 18 — Red Keyword Pop

**v2 authoring ID:** `CAP18` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
Historical preview reference: `previews/18_red_keyword.jpg` (image not bundled).
- **Look:** keyword in bold red (#E02020) mid-sentence, rest white — alarm
  energy ("Fail your business").
- **Animation:** red word slams in; rest types normally.
- **Best for:** warnings, mistakes, contrarian takes, "don't do X".
- **Motion:** Word-by-word like 01; the red keyword slams in with urgency.
- **Words on screen:** 1-4 words; one red keyword.
- **Placement:** Centered mid-frame.
- **Don'ts:** Don't use for positive news - red reads as warning. Don't use over red backgrounds.
- **Historical evidence note (not reverified in v2):** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:** base white Bold 60; keyword override `{\1c&H002020E0&\fs78}`
  (red #E02020 → ASS `&H002020E0`).
- **Legacy drawtext sketch — implementation untested:** keyword `fontsize=78:fontcolor=#E02020:borderw=3`

## 19 — Minimal Left

**v2 authoring ID:** `CAP19` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/19_minimal_left.jpg` (image not bundled).
- **Look:** clean white medium text, left-aligned, stacked short lines
  ("Build it Right. / Scale it Smart."). Quiet confidence.
- **Animation:** lines fade in one by one.
- **Best for:** brand statements, minimal explainers, premium tech.
- **Motion:** Lines fade in one by one, left-aligned, slow and confident.
- **Words on screen:** 2-3 stacked lines, 2-4 words each.
- **Placement:** Left third, vertically centered.
- **Don'ts:** Don't center it. Don't add stroke or shadow - keep it clean.
- **Historical evidence note (not reverified in v2):** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **Legacy ASS sketch — implementation untested:**
  `Style: MinLeft,DejaVu Sans,50,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,0,0,0,0,100,100,0,0,1,1.5,0,1,60,40,80,1`
- **Legacy drawtext sketch — implementation untested:** `fontsize=50:fontcolor=white:borderw=2:x=60:y=900`

## 20 — Gold Script

**v2 authoring ID:** `CAP20` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** font_and_contrast_review.
Historical preview reference: `previews/20_gold_script.jpg` (image not bundled).
- **Look:** flowing gold script word ("congrats") — celebration, premium.
- **Animation:** writes on with a flourish.
- **Best for:** wins, milestones, congratulations, luxury moments.
- **Motion:** A single word writes on with a flourish (about a second), then holds.
- **Words on screen:** ONE word only.
- **Placement:** Center, over clean background.
- **Don'ts:** Don't use for full sentences. Don't set it small - script needs size to stay legible.
- **Historical evidence note (not reverified in v2):** ⚠ needs human review — one sighting shows 3 script words vs entry's "ONE word only"; single sighting, unverified.
- **Legacy ASS sketch — implementation untested:**
  `Style: GoldScript,DejaVu Serif Italic,84,&H0034C8F0,&H000000FF,&H00000000,&HAA000000,0,0,0,0,100,100,0,0,1,1.5,0,5,30,30,50,1`
- **Legacy drawtext sketch — implementation untested:** `fontfile=DejaVuSerif-Italic.ttf:fontsize=84:fontcolor=#F0C834:borderw=2`

## 21 — Stat Box

**v2 authoring ID:** `CAP21` · role `data_callout` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/21_stat_box.jpg` (image not bundled).
- **Look:** big white condensed number ("9/10") with a yellow highlight box
  behind it + small label ("times"). Scoreboard pop.
- **Animation:** number counts up, box wipes in behind.
- **Best for:** stats, ratios, results, social proof.
- **Motion:** The number counts up while the yellow box wipes in behind it.
- **Words on screen:** Number + 1-2 word label.
- **Placement:** Center, large.
- **Don'ts:** Don't use the box without a number. Don't shrink it - scale is the point.
- **Historical evidence note (not reverified in v2):** ⚠ needs human review — preview shows a podcast clip with no stat box; style not located in footage.
- **Legacy ASS sketch — implementation untested:**
  `Style: StatBox,DejaVu Sans Bold,88,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,0,5,30,30,40,1`
  + yellow box drawn behind via `box=1:boxcolor=#FFEB00:boxborderw=14` on the
  number only.
- **Legacy drawtext sketch — implementation untested:** number `fontsize=88:fontcolor=white:box=1:boxcolor=#FFEB00:boxborderw=14:borderw=2`

---

## 22 — Beast Block

**v2 authoring ID:** `CAP22` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
**Implementation checks:** rounded_mask_or_shape_compositor.
Historical preview reference: `previews/22_beast_block.jpg` (image not bundled).
- **Look:** MrBeast-style — ONE word at a time, white bold all-caps centered
  inside a solid colored block (classic blue #1E90FF; swap block color per
  brand). No sentence context — pure word punches.
- **Animation:** each word swaps in with a scale-pop; emphasis words punch
  bigger.
- **Best for:** challenges, giveaways, high-energy hooks, kid/family hype.
- **Motion:** ONE word at a time, each scale-pops in (0 to 110% to 100% quickly), then hard-cuts to the next word. No sentence context on screen.
- **Words on screen:** Exactly 1 word on screen at a time.
- **Placement:** Dead center, large.
- **Don'ts:** Don't show full sentences. Don't pace it slow - this is rapid fire. Don't use serif fonts.
- **Historical evidence note (not reverified in v2):** uncertain — one near-match pin (yellow block, blue "STOP" text) with reversed colors vs the signature; not confirmed.
- **Legacy ASS sketch — implementation untested:**
  `Style: Beast,DejaVu Sans Bold,88,&H00FFFFFF,&H000000FF,&H00000000,&H00FF901E,-1,0,0,0,100,100,0,0,3,0,0,5,30,30,60,1`
  (BorderStyle=3 = opaque box in BackColour; blue #1E90FF → ASS `&H00FF901E`).
- **Legacy drawtext sketch — implementation untested:** `fontsize=88:fontcolor=white:box=1:boxcolor=#1E90FF:boxborderw=20`

## 23 — Underline Sweep

**v2 authoring ID:** `CAP23` · role `speech_caption` · motion `MOTION_HIGHLIGHT_SWEEP` · runtime status `not_tested`.
Historical preview reference: `previews/23_underline_sweep.jpg` (image not bundled).
- **Look:** bold white all-caps sentence; the ACTIVE word gets a thick red
  (#FF2D2D) underline that draws itself left-to-right beneath it.
- **Animation:** underline sweeps under each spoken word; words pop slightly.
- **Best for:** hot takes, rants, debates, "drop everything" hooks.
- **Motion:** The sentence sits static while a thick red underline draws itself left-to-right under each spoken word (word by word).
- **Words on screen:** Full sentence, 6-10 words.
- **Placement:** Center or lower-center.
- **Don'ts:** Don't underline every word - only the active one. Don't use over red backgrounds.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:** base
  `Style: HotTake,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,3,1.5,5,30,30,50,1`
  active-word override: `{\1c&H002D2DFF&\u1}` (red #FF2D2D → ASS
  `&H002D2DFF`; `\u1` = underline; sweep approximated with fade-in).
- **Legacy drawtext sketch — implementation untested:** base `fontsize=64:fontcolor=white:borderw=3` + underline via
  `drawbox=x=...:y=...:w=text_w:h=10:color=#FF2D2D` timed per word.

## 24 — Sticker Pop

**v2 authoring ID:** `CAP24` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
**Implementation checks:** rounded_mask_or_shape_compositor.
Historical preview reference: `previews/24_sticker_pop.jpg` (image not bundled).
- **Look:** die-cut sticker — bold colored text (hot pink #FF4785) with a
  THICK white sticker border, slight tilt (-4°), soft drop shadow. Sits
  tilted over the footage like a slapped-on sticker.
- **Animation:** slaps in with rotation overshoot, settles tilted; holds.
- **Best for:** memes, casual vlogs, Gen-Z humor, reaction clips.
- **Motion:** Slaps in with a rotation overshoot and lands tilted (-4 degrees); holds tilted like a real sticker.
- **Words on screen:** 1-4 words.
- **Placement:** Anywhere with open space, tilted over the footage.
- **Don'ts:** Don't keep it straight - the tilt is the look. Don't use for formal content.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Sticker,DejaVu Sans Bold,72,&H008547FF,&H000000FF,&H00FFFFFF,&HAA000000,-1,0,0,0,100,100,0,-4,1,8,3,5,30,30,60,1`
  (pink #FF4785 → ASS `&H008547FF`; Outline=8 in white = sticker edge;
  Angle=-4 tilt).
- **Legacy drawtext sketch — implementation untested:** `fontsize=72:fontcolor=#FF4785:borderw=10:bordercolor=white`
  (+ shadow via `shadowcolor=black@0.5:shadowx=4:shadowy=4`).

## 25 — Ink Noir

**v2 authoring ID:** `CAP25` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** font_and_contrast_review.
Historical preview reference: `previews/25_ink_noir.jpg` (image not bundled).
- **Look:** heavy ink serif, off-white (#F5F0E8), WIDE letterspacing, no
  stroke — gothic editorial floating over dark footage.
- **Animation:** slow fade-up like a film title; calm, ominous pacing.
- **Best for:** true crime, dark aesthetics, cinematic monologues, moody storytelling.
- **Motion:** Slow fade-up like a film title (slowly), wide letterspacing, holds in stillness.
- **Words on screen:** 2-6 words.
- **Placement:** Center, over dark footage only.
- **Don'ts:** Don't rush it. Don't use on bright footage. Don't add stroke.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Noir,DejaVu Serif Bold,64,&H00E8F0F5,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,6,0,1,1.5,2,5,30,30,60,1`
  (off-white #F5F0E8 → ASS `&H00E8F0F5`; Spacing=6 = wide tracking).
- **Legacy drawtext sketch — implementation untested:** `fontfile=DejaVuSerif-Bold.ttf:fontsize=64:fontcolor=#F5F0E8`
  (drawtext has no letterspacing — insert hair spaces between letters).

## 26 — Blush Gradient

**v2 authoring ID:** `CAP26` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** font_and_contrast_review, true_gradient_requires_supported_masked_fill_or_asset.
Historical preview reference: `previews/26_blush_gradient.jpg` (image not bundled).
- **Look:** bold sans with a soft pink-to-peach GRADIENT fill (#FF9EBB →
  #FFC8A2), thin white stroke — dreamy, feminine.
- **Animation:** words blur/fade in softly, one by one.
- **Best for:** beauty, skincare, GRWM, romance, soft lifestyle.
- **Motion:** Words blur/fade in softly one by one, gentle and dreamy.
- **Words on screen:** 2-6 words.
- **Placement:** Center, over soft backgrounds.
- **Don'ts:** Don't use for aggressive content. True gradient fill needs PNG render - flat pink is the fallback.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Blush,DejaVu Sans Bold,64,&H00BB9EFF,&H000000FF,&H00FFFFFF,&HAA000000,-1,0,0,0,100,100,0,0,1,1.5,2,5,30,30,60,1`
  (flat pink #FF9EBB → ASS `&H00BB9EFF` — ASS has no gradient fill; for a
  true gradient, render text as PNG and overlay).
- **Legacy drawtext sketch — implementation untested:** `fontsize=64:fontcolor=#FF9EBB:borderw=2:bordercolor=white`
  (flat approx; true gradient needs PNG text render).

## 27 — Comic Shake

**v2 authoring ID:** `CAP27` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
**Implementation checks:** motion_or_flash_review, reduced_motion_required.
Historical preview reference: `previews/27_comic_shake.jpg` (image not bundled).
- **Look:** loud comic-book letters — white bold with THICK black outline,
  slight per-word rotation, action energy. Irregular, in-your-face.
- **Animation:** words slam in with a shake/wobble; emphasis words land
  bigger.
- **Best for:** gaming fails, pranks, chaotic edits, meme compilations.
- **Motion:** Words slam in with a shake/wobble (2-3 frames of jitter); emphasis words land bigger.
- **Words on screen:** 1-5 loud words.
- **Placement:** Center, huge.
- **Don'ts:** Don't use small text. Don't use for calm topics. Keep the rotation subtle or it reads as broken.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Comic,DejaVu Sans Bold,80,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,5,2,5,30,30,40,1`
  (Outline=5 thick black; per-word rotation via `{\frz8}` / `{\frz-8}`
  overrides alternating).
- **Legacy drawtext sketch — implementation untested:** `fontsize=80:fontcolor=white:borderw=6:bordercolor=black`
  (rotation needs a `rotate` filter pass per word — batch in the build
  script).

## 28 — Terminal Type

**v2 authoring ID:** `CAP28` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** typewriter_is_not_default_speech_caption, no_wall_clock_blink.
Historical preview reference: `previews/28_terminal_type.jpg` (image not bundled).
- **Look:** hacker terminal — monospace bold, phosphor green (#00FF88) on
  near-black, with a blinking BLOCK CURSOR (█) trailing the text.
- **Animation:** types letter-by-letter; cursor blinks at the end of each
  phrase.
- **Best for:** coding, tech explainers, AI news, finance "system" memes, dev humor.
- **Motion:** Types letter-by-letter (rapidly) with a blinking block cursor trailing behind.
- **Words on screen:** Short lines, 3-10 words, monospace only.
- **Placement:** Left or center, over dark background.
- **Don'ts:** Don't use proportional fonts. Don't skip the cursor - it's the signature.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Terminal,DejaVu Sans Mono Bold,52,&H0088FF00,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,40,40,80,1`
  (green #00FF88 → ASS `&H0088FF00`). Cursor: append `█` with
  frame-derived or repeated timed opacity events; a single `\fad` is not a blink loop.
- **Legacy drawtext sketch — implementation untested:** `fontfile=DejaVuSansMono-Bold.ttf:fontsize=52:fontcolor=#00FF88`
  (cursor: append "█" and toggle via enable blinking).

## 29 — Ribbon Banner

**v2 authoring ID:** `CAP29` · role `editorial_title` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** rounded_mask_or_shape_compositor.
Historical preview reference: `previews/29_ribbon_banner.jpg` (image not bundled).
- **Look:** elegant serif caps on a deep-red (#A31621) ribbon banner with a
  dark red shadow — award-ceremony energy. Sits upper-third.
- **Animation:** ribbon unfurls/slides in from the left; text fades on after.
- **Best for:** announcements, winners, launches, reveals, "tonight" hooks.
- **Motion:** The ribbon slides in from the left; the text fades on a beat later.
- **Words on screen:** 1-4 words, all caps.
- **Placement:** Upper third.
- **Don'ts:** Don't use mid-sentence. Don't use without the banner box.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Ribbon,DejaVu Serif Bold,54,&H00FFFFFF,&H000000FF,&H00000000,&H002116A3,-1,0,0,0,100,100,0,0,3,0,2,8,30,30,80,1`
  (BorderStyle=3 opaque box; maroon #A31621 → ASS `&H002116A3`. True folded
  ribbon ends need a PNG banner — box is the flat approx.)
- **Legacy drawtext sketch — implementation untested:** `fontfile=DejaVuSerif-Bold.ttf:fontsize=54:fontcolor=white:box=1:boxcolor=#A31621:boxborderw=16`

## 30 — News Lower Third

**v2 authoring ID:** `CAP30` · role `editorial_title` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/30_news_lower_third.jpg` (image not bundled).
- **Look:** broadcast lower-third — white bold name/title on a dark
  semi-transparent bar, bottom-left, with a RED (#E10600) accent strip on
  the left edge; smaller caps subtitle beneath.
- **Animation:** accent strip wipes in first, bar slides in from left.
- **Best for:** interviews, expert clips, testimonials, introductions.
- **Motion:** The red accent strip wipes in first, then the bar slides in from the left carrying the name.
- **Words on screen:** Name (2-4 words) + subtitle (3-6 words).
- **Placement:** Bottom-left, above the safe zone.
- **Don'ts:** Don't center it. Don't use for non-person intros.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:** two styles —
  `Style: NewsMain,DejaVu Sans Bold,48,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,0,0,1,60,40,120,1`
  (Alignment=1 bottom-left)
  `Style: NewsSub,DejaVu Sans,32,&H00CCCCCC,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,0,0,1,60,40,70,1`
  Accent strip: burn `drawbox=x=60:y=1230:w=14:h=130:color=#E10600`.
- **Legacy drawtext sketch — implementation untested:** main `fontsize=48:fontcolor=white:box=1:boxcolor=black@0.75:boxborderw=20:x=90:y=1250`
  + accent `drawbox=x=60:y=1230:w=14:h=150:color=#E10600:t=fill`.

## 31 — Bubble Bounce

**v2 authoring ID:** `CAP31` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/31_bubble_bounce.jpg` (image not bundled).
- **Look:** rounded fat letterforms (Fredoka/Baloo vibe), white fill with a
  pastel-purple (#B38CD9) outline — friendly, bouncy, cheerful.
- **Animation:** each word bounces in with squash-and-stretch; holds with a
  gentle wobble.
- **Best for:** kids content, baking, cute pets, cheerful lifestyle, upbeat hooks.
- **Motion:** Each word bounces in with squash-and-stretch, then holds with a gentle wobble.
- **Words on screen:** 2-6 cheerful words.
- **Placement:** Center or lower-center.
- **Don'ts:** Don't use for serious topics. Needs rounded fonts - DejaVu is only an approximation.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Bubble,DejaVu Sans Bold,72,&H00FFFFFF,&H000000FF,&H00D98CB3,&HAA000000,-1,0,0,0,100,100,0,0,1,4,2,5,30,30,60,1`
  (pastel purple #B38CD9 → ASS `&H00D98CB3`; no rounded font on box —
  DejaVu Sans Bold is the closest; swap Fredoka/Baloo when available).
- **Legacy drawtext sketch — implementation untested:** `fontsize=72:fontcolor=white:borderw=5:bordercolor=#B38CD9`

---

## 32 — Karaoke Fill

**v2 authoring ID:** `CAP32` · role `speech_caption` · motion `MOTION_HIGHLIGHT_SWEEP` · runtime status `not_tested`.
Historical preview reference: `previews/32_karaoke_fill.jpg` (image not bundled).
- **Look:** the FULL sentence sits visible in muted gray-white; as each word
  is spoken it FILLS with bright yellow (#FFD500) left-to-right, like a
  karaoke machine. Readers can read ahead; the highlight travels.
- **Animation:** highlight sweeps word to word; spoken words stay lit.
- **Best for:** educational, talking-head explainers, podcasts — read-ahead readability; audience effect untested.
- **Motion:** The full sentence is visible in gray; each spoken word fills yellow left-to-right as it's said. Viewers read ahead of the speech.
- **Words on screen:** Full sentence, 6-12 words.
- **Placement:** Lower-center, above the safe zone.
- **Don'ts:** Don't hide the upcoming words - the read-ahead is the point. Don't use for single-word punches.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Karaoke,DejaVu Sans Bold,60,&H00B8B8B8,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2,1,5,30,30,60,1`
  active-word override per word: `{\1c&H0000D5FF&}` (yellow #FFD500 → ASS
  `&H0000D5FF`). True sweep fill needs `\kf` karaoke timing tags per word.
- **Legacy drawtext sketch — implementation untested:** base `fontsize=60:fontcolor=#B8B8B8:borderw=2`; active word
  separate call `fontcolor=#FFD500` timed per word.

## 33 — Glitch RGB Split

**v2 authoring ID:** `CAP33` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** motion_or_flash_review, reduced_motion_required.
Historical preview reference: `previews/33_glitch_rgb_split.jpg` (image not bundled).
- **Look:** white bold text with red (#FF0033)
  and cyan (#00E5FF) offset copies behind it, plus occasional horizontal
  slice displacement. Cyberpunk/digital-error energy.
- **Animation:** glitch bursts on the beat (2-3 frames of split + slice),
  settles clean between bursts.
- **Best for:** gaming, tech/AI news, edits with beat drops, cyberpunk aesthetics.
- **Motion:** Clean most of the time; on the beat, 2-3 frames of RGB split plus slice displacement, then it snaps clean again.
- **Words on screen:** 1-4 words.
- **Placement:** Center, large.
- **Don'ts:** Don't glitch constantly - bursts only. Don't use for calm content.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:** three layered Dialogue lines, same timing —
  red: `Style: GlitchR,DejaVu Sans Bold,80,&H003300FF,...` offset `\pos` -6px,
  cyan: offset +6px, white on top. (red #FF0033 → ASS `&H003300FF`;
  cyan #00E5FF → ASS `&H00FFE500`). Slice displacement needs a crop/shuffle
  filter pass — use actual slice masks/offsets; \frx rotates in 3D and does not implement slice displacement.
- **Legacy drawtext sketch — implementation untested:** white `fontsize=80:borderw=3` + two shadow copies:
  `shadowcolor=#FF0033:shadowx=-6:shadowy=0` layered with a second
  `shadowcolor=#00E5FF:shadowx=6` pass.

## 34 — Gradient Pop

**v2 authoring ID:** `CAP34` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
**Implementation checks:** font_and_contrast_review, true_gradient_requires_supported_masked_fill_or_asset.
Historical preview reference: `previews/34_gradient_pop.jpg` (image not bundled).
- **Look:** bold words with a hot pink-to-orange gradient fill and white
  stroke, bouncing in one by one. Hype/energy aesthetic.
- **Animation:** per-word bounce + scale pop, staggered.
- **Best for:** hype reels, product launches, fitness, party/giveaway hooks.
- **Motion:** Each word bounces in with a scale pop, staggered.
- **Words on screen:** 2-5 hype words.
- **Placement:** Center, large.
- **Don'ts:** Don't use more than 5 words. True gradient needs PNG render.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: GradPop,DejaVu Sans Bold,76,&H00625EFF,&H000000FF,&H00FFFFFF,&HAA000000,-1,0,0,0,100,100,0,0,1,3,1,5,30,30,40,1`
  (flat mid-gradient #FF5E62 → ASS `&H00625EFF` — ASS has no gradient fill;
  true gradient needs PNG text render). Per-word scale via `{\fscx130\fscy130}`
  overrides on emphasis words.
- **Legacy drawtext sketch — implementation untested:** `fontsize=76:fontcolor=#FF5E62:borderw=3:bordercolor=white`
  (flat approx; true gradient = PNG overlay).

## 35 — 3D Shadow Stack

**v2 authoring ID:** `CAP35` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
**Implementation checks:** font_and_contrast_review.
Historical preview reference: `previews/35_3d_shadow_stack.jpg` (image not bundled).
- **Look:** thick white bold letters with a DEEP extruded hard shadow
  (solid black, offset down-right ~10px, no blur) — chunky 3D pop-art depth.
- **Animation:** slams in flat, shadow "catches up" a frame later.
- **Best for:** comedy, sports highlights, bold statements, thumbnail-style hooks.
- **Motion:** Slams in flat; the hard offset shadow catches up one frame later. Holds static.
- **Words on screen:** 1-4 chunky words.
- **Placement:** Center, huge.
- **Don'ts:** Don't blur the shadow - the hard edge is the look. Don't use thin fonts.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Shadow3D,DejaVu Sans Bold,84,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,4,0,5,30,30,40,1`
  with `\shad10` + `ShadowColour=&H00000000` (hard, unblurred). Blur=0 keeps
  the edge crisp.
- **Legacy drawtext sketch — implementation untested:** `fontsize=84:fontcolor=white:shadowcolor=black:shadowx=10:shadowy=10`
  (drawtext shadow is soft — for hard edge, render text twice: black offset
  copy first, white on top).

## 36 — Wave In

**v2 authoring ID:** `CAP36` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** motion_or_flash_review, reduced_motion_required.
Historical preview reference: `previews/36_wave_in.jpg` (image not bundled).
- **Look:** white bold sentence where each LETTER rides a sine wave —
  letters bob up and down in sequence, like a stadium wave through the text.
- **Animation:** continuous gentle wave loop while the line is on screen;
  settles flat on exit.
- **Best for:** playful hooks, music/dance clips, cheerful announcements, lyric captions.
- **Motion:** Letters bob in a sine-wave sequence and keep a gentle looping wave while on screen.
- **Words on screen:** 1-4 playful words.
- **Placement:** Center.
- **Don'ts:** Don't use for long sentences (the wave gets seasick). Don't use for serious topics.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Wave,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,50,1`
  per-letter overrides: `{\frz6\fry-4}` alternating phase — true sine needs
  per-frame `\pos` Y offsets; approximate with 3-phase rotation cycle.
- **Legacy drawtext sketch — implementation untested:** static only `fontsize=64:fontcolor=white:borderw=3` (wave
  motion needs per-letter filter passes — batch in build script).

## 37 — Zoom Punch

**v2 authoring ID:** `CAP37` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
**Implementation checks:** motion_or_flash_review, reduced_motion_required.
Historical preview reference: `previews/37_zoom_punch.jpg` (image not bundled).
- **Look:** a quiet small sentence holds on screen; on the beat, ONE emphasis word detonates from small to huge yellow (#FFD500), dominating the frame.
- **Animation:** setup line sits static; the punch word scale-explodes on the beat, holds, cuts.
- **Best for:** punchlines, plot twists, "but..." reveals, comedic emphasis.
- **Motion:** A quiet small sentence holds; the emphasis word detonates from small to huge on the beat and holds briefly.
- **Words on screen:** Setup sentence of 4-8 small words + exactly 1 punch word.
- **Placement:** The punch word goes dead center.
- **Don'ts:** Don't punch more than one word. Don't skip the quiet setup — the contrast is the joke.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: ZoomPunch,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,40,1`
  punch-word override on the beat: `{\fs130\1c&H0000D5FF&}` (yellow #FFD500 → ASS `&H0000D5FF`).
- **Legacy drawtext sketch — implementation untested:** punch word `fontsize=130:fontcolor=#FFD500:borderw=4` centered,
  timed to the beat.

## 38 — Outlined Fill Swap

**v2 authoring ID:** `CAP38` · role `speech_caption` · motion `MOTION_KEYWORD_EMPHASIS` · runtime status `not_tested`.
Historical preview reference: `previews/38_outlined_fill_swap.jpg` (image not bundled).
- **Look:** the keyword held as hollow white outline; on the beat it
  snap-fills to solid white. Reveal/answer energy.
- **Animation:** hollow hold → snap-fill on beat → holds solid.
- **Best for:** reveals, answers to questions, before/after, "the truth is…" moments.
- **Motion:** The keyword sits hollow; on its spoken beat it snaps to solid fill instantly.
- **Words on screen:** 1 keyword inside a short sentence.
- **Placement:** Centered.
- **Don'ts:** Don't fill gradually - the snap is the moment. Don't use small text (hollow is unreadable under ~70px).
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:** hollow base
  `Style: HollowFill,DejaVu Sans Bold,80,&H00000000,&H000000FF,&H00FFFFFF,&H00000000,-1,0,0,0,100,100,0,0,1,3,0,5,30,30,40,1`
  (PrimaryColour transparent `&H00000000` + white Outline=3). Fill moment:
  override `{\1c&H00FFFFFF&\alpha&H00&}` on the beat word.
- **Legacy drawtext sketch — implementation untested:** hollow via matching fill: `fontsize=76:fontcolor=0x141414:borderw=3:bordercolor=white`
  (fill = background color, border = the visible outline). Fill moment: second
  `drawtext` pass with `fontcolor=white` on the beat word.

## 39 — Bracket Frame

**v2 authoring ID:** `CAP39` · role `editorial_title` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
Historical preview reference: `previews/39_bracket_frame.jpg` (image not bundled).
- **Look:** white bold caption framed by animated CORNER BRACKETS — four
  L-shaped corners (⌐ ¬ style) in accent color (#00D7FF) that draw themselves
  around the text. HUD/targeting energy.
- **Animation:** corners wipe in from each corner, text fades up inside.
- **Best for:** tech reviews, "target acquired" hooks, gaming, spec callouts.
- **Motion:** Four cyan corner brackets wipe in from the corners; the text fades up inside them.
- **Words on screen:** 2-6 words.
- **Placement:** Center, with the brackets framing the text block.
- **Don'ts:** Don't use without the brackets. Don't crowd the text against the bracket edges.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: Bracket,DejaVu Sans Bold,60,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,50,1`
  brackets: wrap line as `{\1c&H00D7FF&}┌{\1c&H00FFFFFF&} text {\1c&H00D7FF&}┘`
  (cyan #00D7FF → ASS `&H00D7FF`; full corner Ls need border drawing —
  approximate with unicode corners or drawbox passes).
- **Legacy drawtext sketch — implementation untested:** text `fontsize=60:fontcolor=white:borderw=3` +
  `drawbox` L-corners in #00D7FF at the four corners of the text block.

## 40 — Emoji Word Swap

**v2 authoring ID:** `CAP40` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** emoji_cannot_replace_accessible_spoken_meaning.
Historical preview reference: `previews/40_emoji_word_swap.jpg` (image not bundled).
- **Look:** normal white bold caption — but key nouns are SWAPPED for emoji
  inline (🔥 💰 🚀), oversized relative to text. Hormozi-creator signature.
- **Animation:** emoji pops in bigger than the word it replaced, with a
  little bounce.
- **Best for:** business/money talk, motivational, Gen-Z finance, hype captions.
- **Motion:** The emoji pops in oversized with a bounce, replacing the noun it stands for.
- **Words on screen:** Normal sentence with 1-2 emoji swaps max.
- **Placement:** Inline, centered.
- **Don'ts:** Don't swap more than 2 words - it becomes unreadable. Needs a color emoji font or PNG.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: EmojiSwap,DejaVu Sans Bold,60,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,50,1`
  emoji override: `{\fs84}` on the emoji token (font must include color emoji
  — DejaVu lacks it; use Noto Color Emoji if installed, else PNG overlay).
- **Legacy drawtext sketch — implementation untested:** `fontsize=60:fontcolor=white:borderw=3`; emoji via
  `fontfile=NotoColorEmoji.ttf:fontsize=84` layered at word position
  (measure with text_w or burn as separate timed call).

## 41 — VHS Retro Stamp

**v2 authoring ID:** `CAP41` · role `speech_caption` · motion `MOTION_PHRASE_FADE` · runtime status `not_tested`.
**Implementation checks:** motion_or_flash_review, reduced_motion_required.
Historical preview reference: `previews/41_vhs_retro_stamp.jpg` (image not bundled).
- **Look:** off-white monospace caption with VHS artifacts — slight chromatic
  fringe, subtle scanlines, and a camcorder timestamp ("PM 09:41") + "PLAY ▶"
  in the corner. Nostalgic lo-fi.
- **Animation:** text jitters ±1px continuously; occasional tracking-line
  roll.
- **Best for:** throwbacks, 90s/00s nostalgia, skate clips, lo-fi vlogs, "found footage" hooks.
- **Motion:** Text jitters plus/minus 1px continuously with an occasional tracking-line roll. The timestamp sits static top-left.
- **Words on screen:** Short phrases, 2-6 words, monospace.
- **Placement:** Center; timestamp top-left, PLAY indicator top-right.
- **Don'ts:** Don't overdo the jitter (it gets nauseating). Scanlines go via overlay, not baked into the font.
- **Historical evidence note (not reverified in v2):** not present in the four source videos — mechanics from web research only.
- **Legacy ASS sketch — implementation untested:**
  `Style: VHS,DejaVu Sans Mono Bold,54,&H00D8E4E8,&H000000FF,&H00808080,&H00000000,-1,0,0,0,100,100,0,0,1,1,0,5,40,40,80,1`
  (off-white #E8E4D8 → ASS `&H00D8E4E8`; gray fringe via Outline). Timestamp:
  separate style top-left `{\fs36}` "PM 09:41". Scanlines = overlay pattern
  (ffmpeg `drawgrid` or PNG).
- **Legacy drawtext sketch — implementation untested:** `fontfile=DejaVuSansMono-Bold.ttf:fontsize=54:fontcolor=#E8E4D8`
  + timestamp `fontsize=36:x=40:y=40:text='PM 09:41'` + scanlines via
  `drawgrid=w=iw:h=4:t=2:c=black@0.15`.
