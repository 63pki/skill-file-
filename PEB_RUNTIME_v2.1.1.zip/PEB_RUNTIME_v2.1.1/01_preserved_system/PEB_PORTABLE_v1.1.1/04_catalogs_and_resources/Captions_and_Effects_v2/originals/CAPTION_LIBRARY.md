# Caption Style Library

Source: user's screen recording `caption_styles_raw.mp4` (5:00, captured 2026-10-17).
Purpose: pick a style per video type instead of rebuilding captions from scratch.
Each style has a preview, the look spec, best-for tags, a complete instruction
set (Motion — how words should move; Words on screen — how many stay visible;
Placement — where it sits, with safe zones; Don'ts — what ruins the style),
a footage-verification flag, and an ffmpeg-ready preset.

**Honesty note (2026-10-18):** the four source videos are screen recordings of
*static* Pinterest pins — no caption motion is observable in them (the one
playing pin was scrubbed, never played). So every **Motion** field is *inferred
performance direction*, not measured timing; treat any timing figures as
suggested starting points, to be tuned against real playing footage.
**Words on screen** and **Placement** were verified against the footage where
the flag says so. Styles 22–41 come from web research and do not appear in
the source videos.

Presets use ASS subtitle styles (for kinetic word-by-word captions via
`subtitles=clip.ass`) and drawtext params (for static hooks). Colors are
`&HAABBGGRR`. Base font on this machine: DejaVu Sans Bold (swap for
Montserrat ExtraBold / Anton / Bebas when available).

---

## 01 — Keyword Pop Cyan
![preview](previews/01_keyword_pop_cyan.jpg)
- **Look:** small white sentence, one KEYWORD in large bold cyan (#00D7FF-ish),
  centered mid-frame. Keyword scales up with a pop.
- **Animation:** word-by-word reveal; keyword pops + color-flips on its beat.
- **Best for:** talking-head explainers, marketing/business, feature callouts.
- **Motion:** Words appear one at a time, synced to speech (a beat apart). The keyword scales from 60% to 100% with a quick overshoot pop and flips white to cyan exactly on its spoken beat, then holds.
- **Words on screen:** Full short sentence on screen (5-9 words); exactly ONE keyword per sentence gets the cyan pop.
- **Placement:** Centered mid-frame (y about 40-55% of frame height). Keep the bottom edge above y=1500 on 1080x1920 (Shorts UI zone).
- **Don'ts:** Don't pop more than one keyword per sentence - it kills the emphasis. Don't use cyan over bright sky/water footage without the black stroke. Don't run sentences past 10 words.
- **Footage:** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: KW-Cyan,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,40,1`
  keyword override: `{\1c&H00D7FF&\fs80}` on the keyword.
- **drawtext:** `fontsize=64:fontcolor=#00D7FF:borderw=3`

## 02 — Keyword Pop Purple
![preview](previews/02_keyword_pop_purple.jpg)
- **Look:** same mechanic as 01 but keyword in bold purple/magenta gradient.
- **Animation:** word-by-word; keyword punches in larger.
- **Best for:** bold claims, numbers ("9 years"), contrarian hooks.
- **Motion:** Word-by-word reveal like 01; the keyword punches in at ~130% size with a hard pop on its beat.
- **Words on screen:** 2+ words per pin observed; one keyword only — longer 5-9 word sentences not evidenced in footage.
- **Placement:** Centered mid-frame; same safe zone as 01.
- **Don'ts:** Don't use for soft or emotional topics - purple reads aggressive. Don't place over red/pink backgrounds (color vibration). One keyword only.
- **Footage:** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: KW-Purple,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,40,1`
  keyword override: `{\1c&H00C832C8&\fs80}`
- **drawtext:** `fontsize=64:fontcolor=#C832C8:borderw=3`

## 03 — Gold Serif Luxe
![preview](previews/03_gold_serif_luxe.jpg)
- **Look:** elegant gold serif (think Playfair/Bodoni), sentence case, slight
  letterspacing, no stroke — floats over dark footage.
- **Animation:** slow fade/word reveal; calm, premium pacing.
- **Best for:** finance, luxury, cinematic drama, "billion dollar" energy.
- **Motion:** Words fade in one by one, slow (slowly, roughly a beat apart), no bounce - calm reveal. The full line holds briefly, then fades out.
- **Words on screen:** One elegant line, 4-8 words, sentence case.
- **Placement:** Center or upper-center, over dark or empty background. Never over faces.
- **Don'ts:** Don't use on bright or busy footage - gold washes out. Don't add stroke (kills the luxe feel). Don't use for comedy or memes.
- **Footage:** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: Gold-Serif,DejaVu Serif Bold,58,&H0034C8F0,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,30,30,60,1`
  (gold ≈ #F0C834 → ASS `&H0034C8F0`)
- **drawtext:** `fontfile=DejaVuSerif-Bold.ttf:fontsize=58:fontcolor=#F0C834`

## 04 — Neon Glow
![preview](previews/04_neon_glow.jpg)
- **Look:** warm orange neon-sign glow on dark background, soft outer glow,
  slightly condensed bold sans.
- **Animation:** flicker-in like a real sign; holds steady.
- **Best for:** nightlife, gaming, energetic hooks, Spanish/party content.
- **Motion:** Words flicker in like a sign powering on (2-3 quick opacity blinks), then hold with a soft pulsing glow. Exit with a quick fade.
- **Words on screen:** 1-5 words max - short punchy phrases only.
- **Placement:** Center frame, over dark areas. Glow needs darkness to read.
- **Don'ts:** Don't use on bright footage. Don't exceed 5 words - glow becomes mush. Don't use thin fonts.
- **Footage:** ⚠ needs human review — preview shows no caption text; style not located in footage.
- **ASS preset:**
  `Style: Neon,DejaVu Sans Bold,66,&H00007AFF,&H000000FF,&H000A1AFF,&H00000000,-1,0,0,0,100,100,0,0,1,1.5,6,5,30,30,40,1`
  (orange #FF7A00 → ASS `&H00007AFF`; glow via Shadow=6)
- **drawtext:** `fontsize=66:fontcolor=#FF7A00:shadowcolor=#FF7A00:shadowx=0:shadowy=0` (+ borderw=1)

## 05 — Outline Stroke
![preview](previews/05_outline_stroke.jpg)
- **Look:** huge hollow letters — white outline, transparent fill — bottom
  third, overlaps subject.
- **Animation:** slides/pops per word; fill flashes on beat words.
- **Best for:** sporty edits, hype moments, single-word emphasis.
- **Motion:** Words slide up from below with a slight overshoot, staying hollow the whole time. No fill change.
- **Words on screen:** 1-4 big words; the outline scales with the size.
- **Placement:** Center or lower-center; works over mid-tone footage.
- **Don'ts:** Don't use small text - outline eats legibility under ~60px. Don't use on very busy backgrounds. For the hollow-to-fill variant see 38.
- **Footage:** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: Outline,DejaVu Sans Bold,96,&H00FFFFFF,&H000000FF,&H00FFFFFF,&H00000000,-1,0,0,0,100,100,0,0,3,3,0,2,20,20,30,1`
  (BorderStyle=3 = opaque box off, hollow look via Outline=3 + transparent fill trick:
  use `PrimaryColour=&H00000000` transparent + `OutlineColour=&H00FFFFFF`)
- **drawtext:** fill transparent isn't direct — use `fontcolor=white:borderw=4` at
  large size, or render text PNG mask for true hollow.

## 06 — White/Cyan Mix
![preview](previews/06_white_cyan_mix.jpg)
- **Look:** full sentence in white bold, the punch words switch to cyan
  mid-sentence ("doesn't build"). Two-tone emphasis.
- **Animation:** word-by-word; color flips on the punch words.
- **Best for:** argumentative takes, before/after, myth-busting.
- **Motion:** Two-tone sentence: white words appear steadily, cyan keywords pop on their beats.
- **Words on screen:** 6-10 words; 1-2 cyan keywords max.
- **Placement:** Lower-center, above the safe-zone line.
- **Don'ts:** Don't turn more than 2 words cyan. Don't park it high - this style lives low.
- **Footage:** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **ASS preset:** same base as 01; punch-word override `{\1c&H00D7FF&}`.
- **drawtext:** base `fontcolor=white:borderw=3`, punch line separate call in cyan.

## 07 — Stat Highlight
![preview](previews/07_stat_highlight.jpg)
- **Look:** stat/number in bold orange on near-black, compact, upper area —
  scoreboard energy.
- **Animation:** counts up or slams in with impact shake.
- **Best for:** stats, records, "X years", money numbers.
- **Motion:** The number counts up (0 to target quickly) while the highlight box wipes in behind it left-to-right.
- **Words on screen:** Number + 1-3 word label.
- **Placement:** Center frame, large.
- **Don'ts:** Don't use for non-numeric claims. Don't shrink the number - it's the hero.
- **Footage:** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: Stat,DejaVu Sans Bold,72,&H00007AFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,3,1,8,30,30,30,1`
- **drawtext:** `fontsize=72:fontcolor=#FF7A00:borderw=3:x=(w-text_w)/2:y=300`

## 08 — Portfolio Card
![preview](previews/08_portfolio_card.jpg)
- **Look:** not a caption — a framed card layout: title top ("our work"),
  video inset, handle bottom. Cream background.
- **Animation:** n/a (layout template).
- **Best for:** end cards, "more like this" outros, client showcases.
- **Motion:** The card slides up from the bottom, text fades in inside it; it holds like a lower-third ident.
- **Words on screen:** Name/title: 2-6 words, plus a one-line subtitle.
- **Placement:** Bottom-left or bottom-center, above the safe zone.
- **Don'ts:** Don't use mid-video - it's an intro/outro card. Don't animate it word-by-word.
- **Footage:** ⚠ needs human review — preview shows a keyword-pop talking-head pin, not a card layout; entry unverified.
- **ASS preset:** n/a — layout template, not a subtitle style.
- **drawtext:** compose in ffmpeg: `color=c=cream:s=1080x1920` background +
  `overlay` the scaled video inset + `drawtext` title/handle.

---

## How to use
1. Pick style by video type (see Best for).
2. For kinetic captions: write an `.ass` with the Style + per-word timing,
   burn with `-vf "ass=clip.ass"`.
3. For static hooks: use the drawtext line.
4. Keep all text inside y 300–1450 on 1080x1920, clear of the bottom 320px.

## To add a style
Drop a preview in `previews/`, append a section in this file with the same
fields. Source videos: `caption_styles_raw.mp4` (5:00), `styles_v2_mobile.mp4`
(0:59), `styles_v3_18s.mp4` (0:18), `styles_v4_2min.mp4` (1:57).

---

## 09 — TikTok Pill
![preview](previews/09_tiktok_pill.jpg)
- **Look:** white medium-weight sentence on a solid black rounded pill,
  centered mid-frame. The classic auto-caption look.
- **Animation:** word-by-word inside the pill; pill resizes per phrase.
- **Best for:** talking head, explainers, any dialogue-heavy clip — maximum readability, zero distraction.
- **Motion:** The pill pops in together with the word (scale 80 to 100%), holds for the phrase, pops out.
- **Words on screen:** 2-7 words observed; a 7-word pill renders cleanly — the length limit is softer than stated.
- **Placement:** Lower-center, above the safe zone.
- **Don'ts:** Don't stack two pills at once. Don't use long sentences - the pill stretches awkwardly.
- **Footage:** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: Pill,DejaVu Sans Bold,54,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,30,30,60,1`
  (BorderStyle=1 + BackColour opaque black gives the pill bar; for rounded
  look use BorderStyle=3 box with padding — approximate with Outline=0,
  BackColour=&H00000000)
- **drawtext:** `fontsize=54:fontcolor=white:box=1:boxcolor=black:boxborderw=18`

## 10 — Yellow Marker Highlight
![preview](previews/10_yellow_marker.jpg)
- **Look:** huge condensed word in blue/black on a full-bleed yellow (#FFEB00)
  panel — highlighter energy, takes over the frame.
- **Animation:** slams in with a hard cut; holds.
- **Best for:** warnings, "STOP" moments, pattern interrupts, hooks that need a visual slap.
- **Motion:** The keyword appears in white first, then the yellow marker swipes behind it left-to-right (quickly).
- **Words on screen:** Full sentence of 5-9 words; 1-2 highlighted keywords.
- **Placement:** Center or lower-center.
- **Don'ts:** Don't highlight whole sentences. Don't use yellow text on the yellow highlight.
- **Footage:** ⚠ needs human review — preview shows blue block text on solid yellow ("STOP" pin), not a marker swipe; entry unverified. Same pin resembles style 22's layout.
- **ASS preset:**
  `Style: Marker,DejaVu Sans Bold,110,&H00FF0000,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,30,30,20,1`
  over a yellow full-frame color clip (`color=c=0xFFEB00:s=1080x1920`).
- **drawtext:** on yellow bg — `fontsize=110:fontcolor=#0000FF:borderw=0`

## 11 — Script + Serif Mix
![preview](previews/11_script_serif_mix.jpg)
- **Look:** elegant script word (flowing italic) paired with bold serif caps
  ("Samira" script over "PODCAST" serif). Feminine, premium.
- **Animation:** script writes on; serif fades up beneath.
- **Best for:** podcasts, branding, fashion/beauty, creator intros.
- **Motion:** The script word writes on with a stroke reveal (about a second), then the serif line fades in beneath it.
- **Words on screen:** 1 script word + 4-7 serif words.
- **Placement:** Center, over clean background.
- **Don'ts:** Don't use two script words together. Don't rush the write-on under 800ms.
- **Footage:** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: ScriptMix,DejaVu Serif Italic,72,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2,1,5,30,30,50,1`
  (no script font on box — approximate script with Serif Italic)
- **drawtext:** `fontfile=DejaVuSerif-Italic.ttf:fontsize=72:fontcolor=white:borderw=2`

## 12 — Collegiate Outline
![preview](previews/12_collegiate_outline.jpg)
- **Look:** varsity/college block letters, white fill with dark outline,
  slight arch — "TREND" energy.
- **Animation:** letter-by-letter drop-in with bounce.
- **Best for:** sport, streetwear, hype, trend-jacking hooks.
- **Motion:** Words slam in with a tiny shake; the arched varsity feel comes from wide letterspacing.
- **Words on screen:** 1-3 words, ALL CAPS.
- **Placement:** Upper-center (like a jersey chest print).
- **Don'ts:** Don't use lowercase - kills the look. Don't use on formal or luxury content.
- **Footage:** ⚠ needs human review — preview shows ransom-cutout letters ("TreNd"), not varsity outline; entry unverified.
- **ASS preset:**
  `Style: Collegiate,DejaVu Sans Bold,90,&H00FFFFFF,&H000000FF,&H64000000,&H00000000,-1,0,0,0,100,100,0,0,1,4,0,5,30,30,40,1`
- **drawtext:** `fontsize=90:fontcolor=white:borderw=5:bordercolor=black`

## 13 — Magenta Mix
![preview](previews/13_magenta_mix.jpg)
- **Look:** stacked lines mixing thin sans ("MAKE LIFE YOUR") with big
  magenta/pink italic serif ("Masterpiece"). Editorial, magazine feel.
- **Animation:** lines stagger in; magenta word scales up last.
- **Best for:** motivational, lifestyle, glow-up content.
- **Motion:** Word-by-word like 01; the magenta keyword pops on its beat.
- **Words on screen:** 5-9 words; one keyword.
- **Placement:** Centered mid-frame.
- **Don'ts:** Don't use over pink/red footage. One keyword only.
- **Footage:** ⚠ needs human review — preview shows no magenta text; style not located in footage.
- **ASS preset:**
  `Style: MagentaMix,DejaVu Serif BoldItalic,80,&H00802AC8,&H000000FF,&H00000000,&HAA000000,0,0,0,0,100,100,0,0,1,2,1,5,30,30,50,1`
  (magenta #C82AA0 → ASS `&H00802AC8`)
- **drawtext:** `fontfile=DejaVuSerif-BoldItalic.ttf:fontsize=80:fontcolor=#C82AA0:borderw=2`

## 14 — Thin Lowercase Stack
![preview](previews/14_thin_lowercase.jpg)
- **Look:** thin/light lowercase sans, stacked 2-3 lines, small, quiet —
  "filming content ideas". Anti-hype, aesthetic.
- **Animation:** soft fade per line.
- **Best for:** vlogs, BTS, aesthetic montages, soft storytelling.
- **Motion:** Lines fade in one by one, slow, no bounce - quiet and airy.
- **Words on screen:** 2-4 short stacked lines, 1-3 words each, all lowercase.
- **Placement:** Center or left-center with lots of breathing room.
- **Don'ts:** Don't use all caps (destroys the aesthetic). Don't crowd it - it needs negative space.
- **Footage:** ⚠ needs human review — preview shows only search UI, no caption; style not located in footage.
- **ASS preset:**
  `Style: ThinStack,DejaVu Sans,44,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,0,0,0,0,100,100,0,0,1,1.5,0,5,40,40,80,1`
- **drawtext:** `fontsize=44:fontcolor=white:borderw=1` (DejaVu Sans has no
  light weight — closest available)

## 15 — Label Tag
![preview](previews/15_label_tag.jpg)
- **Look:** tiny black bold-condensed caps on a white rounded label
  ("STATIC SHOT"), top area — like a camera UI tag.
- **Animation:** pops in once, holds as a persistent tag.
- **Best for:** shot labels, series tags ("EP 3", "POV"), tech callouts.
- **Motion:** The tag slides in from the side together with its word; holds like a sticker label.
- **Words on screen:** 1-3 words per tag.
- **Placement:** Near the subject it labels (face, product).
- **Don'ts:** Don't cover faces with the tag. Don't put more than 2 tags on screen.
- **Footage:** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: LabelTag,DejaVu Sans Bold,34,&H00000000,&H000000FF,&H00000000,&H00FFFFFF,-1,0,0,0,100,100,0,0,1,0,0,8,30,30,30,1`
- **drawtext:** `fontsize=34:fontcolor=black:box=1:boxcolor=white:boxborderw=12:x=(w-text_w)/2:y=180`

## 16 — Lime Keyword Pop
![preview](previews/16_lime_keyword.jpg)
- **Look:** small white lead-in ("to", "even if") + KEYWORD in huge bold
  lime/neon green (#BFFF00). Electric, can't-miss.
- **Animation:** keyword slams in on the beat; lead-in stays small.
- **Best for:** money talk, results, bold promises, high-energy hooks.
- **Motion:** Word-by-word like 01; the lime keyword slams in with high energy.
- **Words on screen:** 4-7 words; one LARGE lime keyword + small white context words.
- **Placement:** Centered mid-frame.
- **Don'ts:** Don't use over green footage. Lime means high energy - not for calm topics.
- **Footage:** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: Lime,DejaVu Sans Bold,60,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,50,1`
  keyword override: `{\1c&H0000FFBF&\fs92}` (lime #BFFF00 → ASS `&H0000FFBF`)
- **drawtext:** keyword `fontsize=92:fontcolor=#BFFF00:borderw=3`

## 17 — Dark Pill
![preview](previews/17_dark_pill.jpg)
- **Look:** white text on a dark red/maroon (#7A1F1F) rounded pill with a
  small warning icon — alert/answer style.
- **Animation:** slides in from side; holds as Q&A card.
- **Best for:** FAQs, "what to say?", objections, quiz hooks.
- **Motion:** The pill fades/slides in with the text; calm hold, no bounce.
- **Words on screen:** 3-7 words.
- **Placement:** Lower-center, above the safe zone.
- **Don'ts:** Stacking two pills is demonstrated in the source footage itself — allowed, not forbidden. Don't use on dark footage (pill disappears).
- **Footage:** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: DarkPill,DejaVu Sans Bold,46,&H00FFFFFF,&H000000FF,&H00000000,&H001F1F7A,-1,0,0,0,100,100,0,0,1,0,0,5,30,30,60,1`
  (maroon #7A1F1F → ASS `&H001F1F7A`)
- **drawtext:** `fontsize=46:fontcolor=white:box=1:boxcolor=#7A1F1F:boxborderw=16`

---

## 18 — Red Keyword Pop
![preview](previews/18_red_keyword.jpg)
- **Look:** keyword in bold red (#E02020) mid-sentence, rest white — alarm
  energy ("Fail your business").
- **Animation:** red word slams in; rest types normally.
- **Best for:** warnings, mistakes, contrarian takes, "don't do X".
- **Motion:** Word-by-word like 01; the red keyword slams in with urgency.
- **Words on screen:** 1-4 words; one red keyword.
- **Placement:** Centered mid-frame.
- **Don'ts:** Don't use for positive news - red reads as warning. Don't use over red backgrounds.
- **Footage:** verified in the source videos — field corrected against footage (Motion is inferred direction; see honesty note).
- **ASS preset:** base white Bold 60; keyword override `{\1c&H002020E0&\fs78}`
  (red #E02020 → ASS `&H002020E0`).
- **drawtext:** keyword `fontsize=78:fontcolor=#E02020:borderw=3`

## 19 — Minimal Left
![preview](previews/19_minimal_left.jpg)
- **Look:** clean white medium text, left-aligned, stacked short lines
  ("Build it Right. / Scale it Smart."). Quiet confidence.
- **Animation:** lines fade in one by one.
- **Best for:** brand statements, minimal explainers, premium tech.
- **Motion:** Lines fade in one by one, left-aligned, slow and confident.
- **Words on screen:** 2-3 stacked lines, 2-4 words each.
- **Placement:** Left third, vertically centered.
- **Don'ts:** Don't center it. Don't add stroke or shadow - keep it clean.
- **Footage:** verified in the source videos — fields confirmed against footage (Motion is inferred direction; see honesty note).
- **ASS preset:**
  `Style: MinLeft,DejaVu Sans,50,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,0,0,0,0,100,100,0,0,1,1.5,0,1,60,40,80,1`
- **drawtext:** `fontsize=50:fontcolor=white:borderw=2:x=60:y=900`

## 20 — Gold Script
![preview](previews/20_gold_script.jpg)
- **Look:** flowing gold script word ("congrats") — celebration, premium.
- **Animation:** writes on with a flourish.
- **Best for:** wins, milestones, congratulations, luxury moments.
- **Motion:** A single word writes on with a flourish (about a second), then holds.
- **Words on screen:** ONE word only.
- **Placement:** Center, over clean background.
- **Don'ts:** Don't use for full sentences. Don't set it small - script needs size to stay legible.
- **Footage:** ⚠ needs human review — one sighting shows 3 script words vs entry's "ONE word only"; single sighting, unverified.
- **ASS preset:**
  `Style: GoldScript,DejaVu Serif Italic,84,&H0034C8F0,&H000000FF,&H00000000,&HAA000000,0,0,0,0,100,100,0,0,1,1.5,0,5,30,30,50,1`
- **drawtext:** `fontfile=DejaVuSerif-Italic.ttf:fontsize=84:fontcolor=#F0C834:borderw=2`

## 21 — Stat Box
![preview](previews/21_stat_box.jpg)
- **Look:** big white condensed number ("9/10") with a yellow highlight box
  behind it + small label ("times"). Scoreboard pop.
- **Animation:** number counts up, box wipes in behind.
- **Best for:** stats, ratios, results, social proof.
- **Motion:** The number counts up while the yellow box wipes in behind it.
- **Words on screen:** Number + 1-2 word label.
- **Placement:** Center, large.
- **Don'ts:** Don't use the box without a number. Don't shrink it - scale is the point.
- **Footage:** ⚠ needs human review — preview shows a podcast clip with no stat box; style not located in footage.
- **ASS preset:**
  `Style: StatBox,DejaVu Sans Bold,88,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,0,5,30,30,40,1`
  + yellow box drawn behind via `box=1:boxcolor=#FFEB00:boxborderw=14` on the
  number only.
- **drawtext:** number `fontsize=88:fontcolor=white:box=1:boxcolor=#FFEB00:boxborderw=14:borderw=2`

---

## 22 — Beast Block
![preview](previews/22_beast_block.jpg)
- **Look:** MrBeast-style — ONE word at a time, white bold all-caps centered
  inside a solid colored block (classic blue #1E90FF; swap block color per
  brand). No sentence context — pure word punches.
- **Animation:** each word swaps in with a scale-pop; emphasis words punch
  bigger.
- **Best for:** challenges, giveaways, high-energy hooks, kid/family hype.
- **Motion:** ONE word at a time, each scale-pops in (0 to 110% to 100% quickly), then hard-cuts to the next word. No sentence context on screen.
- **Words on screen:** Exactly 1 word on screen at a time.
- **Placement:** Dead center, large.
- **Don'ts:** Don't show full sentences. Don't pace it slow - this is rapid fire. Don't use serif fonts.
- **Footage:** uncertain — one near-match pin (yellow block, blue "STOP" text) with reversed colors vs the signature; not confirmed.
- **ASS preset:**
  `Style: Beast,DejaVu Sans Bold,88,&H00FFFFFF,&H000000FF,&H00000000,&H00FF901E,-1,0,0,0,100,100,0,0,3,0,0,5,30,30,60,1`
  (BorderStyle=3 = opaque box in BackColour; blue #1E90FF → ASS `&H00FF901E`).
- **drawtext:** `fontsize=88:fontcolor=white:box=1:boxcolor=#1E90FF:boxborderw=20`

## 23 — Underline Sweep
![preview](previews/23_underline_sweep.jpg)
- **Look:** bold white all-caps sentence; the ACTIVE word gets a thick red
  (#FF2D2D) underline that draws itself left-to-right beneath it.
- **Animation:** underline sweeps under each spoken word; words pop slightly.
- **Best for:** hot takes, rants, debates, "drop everything" hooks.
- **Motion:** The sentence sits static while a thick red underline draws itself left-to-right under each spoken word (word by word).
- **Words on screen:** Full sentence, 6-10 words.
- **Placement:** Center or lower-center.
- **Don'ts:** Don't underline every word - only the active one. Don't use over red backgrounds.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:** base
  `Style: HotTake,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,3,1.5,5,30,30,50,1`
  active-word override: `{\1c&H002D2DFF&\u1}` (red #FF2D2D → ASS
  `&H002D2DFF`; `\u1` = underline; sweep approximated with fade-in).
- **drawtext:** base `fontsize=64:fontcolor=white:borderw=3` + underline via
  `drawbox=x=...:y=...:w=text_w:h=10:color=#FF2D2D` timed per word.

## 24 — Sticker Pop
![preview](previews/24_sticker_pop.jpg)
- **Look:** die-cut sticker — bold colored text (hot pink #FF4785) with a
  THICK white sticker border, slight tilt (-4°), soft drop shadow. Sits
  tilted over the footage like a slapped-on sticker.
- **Animation:** slaps in with rotation overshoot, settles tilted; holds.
- **Best for:** memes, casual vlogs, Gen-Z humor, reaction clips.
- **Motion:** Slaps in with a rotation overshoot and lands tilted (-4 degrees); holds tilted like a real sticker.
- **Words on screen:** 1-4 words.
- **Placement:** Anywhere with open space, tilted over the footage.
- **Don'ts:** Don't keep it straight - the tilt is the look. Don't use for formal content.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Sticker,DejaVu Sans Bold,72,&H008547FF,&H000000FF,&H00FFFFFF,&HAA000000,-1,0,0,0,100,100,0,-4,1,8,3,5,30,30,60,1`
  (pink #FF4785 → ASS `&H008547FF`; Outline=8 in white = sticker edge;
  Angle=-4 tilt).
- **drawtext:** `fontsize=72:fontcolor=#FF4785:borderw=10:bordercolor=white`
  (+ shadow via `shadowcolor=black@0.5:shadowx=4:shadowy=4`).

## 25 — Ink Noir
![preview](previews/25_ink_noir.jpg)
- **Look:** heavy ink serif, off-white (#F5F0E8), WIDE letterspacing, no
  stroke — gothic editorial floating over dark footage.
- **Animation:** slow fade-up like a film title; calm, ominous pacing.
- **Best for:** true crime, dark aesthetics, cinematic monologues, moody storytelling.
- **Motion:** Slow fade-up like a film title (slowly), wide letterspacing, holds in stillness.
- **Words on screen:** 2-6 words.
- **Placement:** Center, over dark footage only.
- **Don'ts:** Don't rush it. Don't use on bright footage. Don't add stroke.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Noir,DejaVu Serif Bold,64,&H00E8F0F5,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,6,0,1,1.5,2,5,30,30,60,1`
  (off-white #F5F0E8 → ASS `&H00E8F0F5`; Spacing=6 = wide tracking).
- **drawtext:** `fontfile=DejaVuSerif-Bold.ttf:fontsize=64:fontcolor=#F5F0E8`
  (drawtext has no letterspacing — insert hair spaces between letters).

## 26 — Blush Gradient
![preview](previews/26_blush_gradient.jpg)
- **Look:** bold sans with a soft pink-to-peach GRADIENT fill (#FF9EBB →
  #FFC8A2), thin white stroke — dreamy, feminine.
- **Animation:** words blur/fade in softly, one by one.
- **Best for:** beauty, skincare, GRWM, romance, soft lifestyle.
- **Motion:** Words blur/fade in softly one by one, gentle and dreamy.
- **Words on screen:** 2-6 words.
- **Placement:** Center, over soft backgrounds.
- **Don'ts:** Don't use for aggressive content. True gradient fill needs PNG render - flat pink is the fallback.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Blush,DejaVu Sans Bold,64,&H00BB9EFF,&H000000FF,&H00FFFFFF,&HAA000000,-1,0,0,0,100,100,0,0,1,1.5,2,5,30,30,60,1`
  (flat pink #FF9EBB → ASS `&H00BB9EFF` — ASS has no gradient fill; for a
  true gradient, render text as PNG and overlay).
- **drawtext:** `fontsize=64:fontcolor=#FF9EBB:borderw=2:bordercolor=white`
  (flat approx; true gradient needs PNG text render).

## 27 — Comic Shake
![preview](previews/27_comic_shake.jpg)
- **Look:** loud comic-book letters — white bold with THICK black outline,
  slight per-word rotation, action energy. Irregular, in-your-face.
- **Animation:** words slam in with a shake/wobble; emphasis words land
  bigger.
- **Best for:** gaming fails, pranks, chaotic edits, meme compilations.
- **Motion:** Words slam in with a shake/wobble (2-3 frames of jitter); emphasis words land bigger.
- **Words on screen:** 1-5 loud words.
- **Placement:** Center, huge.
- **Don'ts:** Don't use small text. Don't use for calm topics. Keep the rotation subtle or it reads as broken.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Comic,DejaVu Sans Bold,80,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,5,2,5,30,30,40,1`
  (Outline=5 thick black; per-word rotation via `{\frz8}` / `{\frz-8}`
  overrides alternating).
- **drawtext:** `fontsize=80:fontcolor=white:borderw=6:bordercolor=black`
  (rotation needs a `rotate` filter pass per word — batch in the build
  script).

## 28 — Terminal Type
![preview](previews/28_terminal_type.jpg)
- **Look:** hacker terminal — monospace bold, phosphor green (#00FF88) on
  near-black, with a blinking BLOCK CURSOR (█) trailing the text.
- **Animation:** types letter-by-letter; cursor blinks at the end of each
  phrase.
- **Best for:** coding, tech explainers, AI news, finance "system" memes, dev humor.
- **Motion:** Types letter-by-letter (rapidly) with a blinking block cursor trailing behind.
- **Words on screen:** Short lines, 3-10 words, monospace only.
- **Placement:** Left or center, over dark background.
- **Don'ts:** Don't use proportional fonts. Don't skip the cursor - it's the signature.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Terminal,DejaVu Sans Mono Bold,52,&H0088FF00,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,40,40,80,1`
  (green #00FF88 → ASS `&H0088FF00`). Cursor: append `█` with
  `{\fad(200,200)}` blink loop, or burn cursor as separate timed event.
- **drawtext:** `fontfile=DejaVuSansMono-Bold.ttf:fontsize=52:fontcolor=#00FF88`
  (cursor: append "█" and toggle via enable blinking).

## 29 — Ribbon Banner
![preview](previews/29_ribbon_banner.jpg)
- **Look:** elegant serif caps on a deep-red (#A31621) ribbon banner with a
  dark red shadow — award-ceremony energy. Sits upper-third.
- **Animation:** ribbon unfurls/slides in from the left; text fades on after.
- **Best for:** announcements, winners, launches, reveals, "tonight" hooks.
- **Motion:** The ribbon slides in from the left; the text fades on a beat later.
- **Words on screen:** 1-4 words, all caps.
- **Placement:** Upper third.
- **Don'ts:** Don't use mid-sentence. Don't use without the banner box.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Ribbon,DejaVu Serif Bold,54,&H00FFFFFF,&H000000FF,&H00000000,&H002116A3,-1,0,0,0,100,100,0,0,3,0,2,8,30,30,80,1`
  (BorderStyle=3 opaque box; maroon #A31621 → ASS `&H002116A3`. True folded
  ribbon ends need a PNG banner — box is the flat approx.)
- **drawtext:** `fontfile=DejaVuSerif-Bold.ttf:fontsize=54:fontcolor=white:box=1:boxcolor=#A31621:boxborderw=16`

## 30 — News Lower Third
![preview](previews/30_news_lower_third.jpg)
- **Look:** broadcast lower-third — white bold name/title on a dark
  semi-transparent bar, bottom-left, with a RED (#E10600) accent strip on
  the left edge; smaller caps subtitle beneath.
- **Animation:** accent strip wipes in first, bar slides in from left.
- **Best for:** interviews, expert clips, testimonials, introductions.
- **Motion:** The red accent strip wipes in first, then the bar slides in from the left carrying the name.
- **Words on screen:** Name (2-4 words) + subtitle (3-6 words).
- **Placement:** Bottom-left, above the safe zone.
- **Don'ts:** Don't center it. Don't use for non-person intros.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:** two styles —
  `Style: NewsMain,DejaVu Sans Bold,48,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,0,0,1,60,40,120,1`
  (Alignment=1 bottom-left)
  `Style: NewsSub,DejaVu Sans,32,&H00CCCCCC,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,0,0,1,60,40,70,1`
  Accent strip: burn `drawbox=x=60:y=1230:w=14:h=130:color=#E10600`.
- **drawtext:** main `fontsize=48:fontcolor=white:box=1:boxcolor=black@0.75:boxborderw=20:x=90:y=1250`
  + accent `drawbox=x=60:y=1230:w=14:h=150:color=#E10600:t=fill`.

## 31 — Bubble Bounce
![preview](previews/31_bubble_bounce.jpg)
- **Look:** rounded fat letterforms (Fredoka/Baloo vibe), white fill with a
  pastel-purple (#B38CD9) outline — friendly, bouncy, cheerful.
- **Animation:** each word bounces in with squash-and-stretch; holds with a
  gentle wobble.
- **Best for:** kids content, baking, cute pets, cheerful lifestyle, upbeat hooks.
- **Motion:** Each word bounces in with squash-and-stretch, then holds with a gentle wobble.
- **Words on screen:** 2-6 cheerful words.
- **Placement:** Center or lower-center.
- **Don'ts:** Don't use for serious topics. Needs rounded fonts - DejaVu is only an approximation.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Bubble,DejaVu Sans Bold,72,&H00FFFFFF,&H000000FF,&H00D98CB3,&HAA000000,-1,0,0,0,100,100,0,0,1,4,2,5,30,30,60,1`
  (pastel purple #B38CD9 → ASS `&H00D98CB3`; no rounded font on box —
  DejaVu Sans Bold is the closest; swap Fredoka/Baloo when available).
- **drawtext:** `fontsize=72:fontcolor=white:borderw=5:bordercolor=#B38CD9`

---

## 32 — Karaoke Fill
![preview](previews/32_karaoke_fill.jpg)
- **Look:** the FULL sentence sits visible in muted gray-white; as each word
  is spoken it FILLS with bright yellow (#FFD500) left-to-right, like a
  karaoke machine. Readers can read ahead; the highlight travels.
- **Animation:** highlight sweeps word to word; spoken words stay lit.
- **Best for:** educational, talking-head explainers, podcasts — maximum readability + retention.
- **Motion:** The full sentence is visible in gray; each spoken word fills yellow left-to-right as it's said. Viewers read ahead of the speech.
- **Words on screen:** Full sentence, 6-12 words.
- **Placement:** Lower-center, above the safe zone.
- **Don'ts:** Don't hide the upcoming words - the read-ahead is the point. Don't use for single-word punches.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Karaoke,DejaVu Sans Bold,60,&H00B8B8B8,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2,1,5,30,30,60,1`
  active-word override per word: `{\1c&H0000D5FF&}` (yellow #FFD500 → ASS
  `&H0000D5FF`). True sweep fill needs `\kf` karaoke timing tags per word.
- **drawtext:** base `fontsize=60:fontcolor=#B8B8B8:borderw=2`; active word
  separate call `fontcolor=#FFD500` timed per word.

## 33 — Glitch RGB Split
![preview](previews/33_glitch_rgb_split.jpg)
- **Look:** white bold text with red (#FF0033)
  and cyan (#00E5FF) offset copies behind it, plus occasional horizontal
  slice displacement. Cyberpunk/digital-error energy.
- **Animation:** glitch bursts on the beat (2-3 frames of split + slice),
  settles clean between bursts.
- **Best for:** gaming, tech/AI news, edits with beat drops, cyberpunk aesthetics.
- **Motion:** Clean most of the time; on the beat, 2-3 frames of RGB split plus slice displacement, then it snaps clean again.
- **Words on screen:** 1-4 words.
- **Placement:** Center, large.
- **Don'ts:** Don't glitch constantly - bursts only. Don't use for calm content.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:** three layered Dialogue lines, same timing —
  red: `Style: GlitchR,DejaVu Sans Bold,80,&H003300FF,...` offset `\pos` -6px,
  cyan: offset +6px, white on top. (red #FF0033 → ASS `&H003300FF`;
  cyan #00E5FF → ASS `&H00FFE500`). Slice displacement needs a crop/shuffle
  filter pass — approximate with `\frx` jitter overrides.
- **drawtext:** white `fontsize=80:borderw=3` + two shadow copies:
  `shadowcolor=#FF0033:shadowx=-6:shadowy=0` layered with a second
  `shadowcolor=#00E5FF:shadowx=6` pass.

## 34 — Gradient Pop
![preview](previews/34_gradient_pop.jpg)
- **Look:** bold words with a hot pink-to-orange gradient fill and white
  stroke, bouncing in one by one. Hype/energy aesthetic.
- **Animation:** per-word bounce + scale pop, staggered.
- **Best for:** hype reels, product launches, fitness, party/giveaway hooks.
- **Motion:** Each word bounces in with a scale pop, staggered.
- **Words on screen:** 2-5 hype words.
- **Placement:** Center, large.
- **Don'ts:** Don't use more than 5 words. True gradient needs PNG render.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: GradPop,DejaVu Sans Bold,76,&H00625EFF,&H000000FF,&H00FFFFFF,&HAA000000,-1,0,0,0,100,100,0,0,1,3,1,5,30,30,40,1`
  (flat mid-gradient #FF5E62 → ASS `&H00625EFF` — ASS has no gradient fill;
  true gradient needs PNG text render). Per-word scale via `{\fscx130\fscy130}`
  overrides on emphasis words.
- **drawtext:** `fontsize=76:fontcolor=#FF5E62:borderw=3:bordercolor=white`
  (flat approx; true gradient = PNG overlay).

## 35 — 3D Shadow Stack
![preview](previews/35_3d_shadow_stack.jpg)
- **Look:** thick white bold letters with a DEEP extruded hard shadow
  (solid black, offset down-right ~10px, no blur) — chunky 3D pop-art depth.
- **Animation:** slams in flat, shadow "catches up" a frame later.
- **Best for:** comedy, sports highlights, bold statements, thumbnail-style hooks.
- **Motion:** Slams in flat; the hard offset shadow catches up one frame later. Holds static.
- **Words on screen:** 1-4 chunky words.
- **Placement:** Center, huge.
- **Don'ts:** Don't blur the shadow - the hard edge is the look. Don't use thin fonts.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Shadow3D,DejaVu Sans Bold,84,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,4,0,5,30,30,40,1`
  with `\shad10` + `ShadowColour=&H00000000` (hard, unblurred). Blur=0 keeps
  the edge crisp.
- **drawtext:** `fontsize=84:fontcolor=white:shadowcolor=black:shadowx=10:shadowy=10`
  (drawtext shadow is soft — for hard edge, render text twice: black offset
  copy first, white on top).

## 36 — Wave In
![preview](previews/36_wave_in.jpg)
- **Look:** white bold sentence where each LETTER rides a sine wave —
  letters bob up and down in sequence, like a stadium wave through the text.
- **Animation:** continuous gentle wave loop while the line is on screen;
  settles flat on exit.
- **Best for:** playful hooks, music/dance clips, cheerful announcements, lyric captions.
- **Motion:** Letters bob in a sine-wave sequence and keep a gentle looping wave while on screen.
- **Words on screen:** 1-4 playful words.
- **Placement:** Center.
- **Don'ts:** Don't use for long sentences (the wave gets seasick). Don't use for serious topics.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Wave,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,50,1`
  per-letter overrides: `{\frz6\fry-4}` alternating phase — true sine needs
  per-frame `\pos` Y offsets; approximate with 3-phase rotation cycle.
- **drawtext:** static only `fontsize=64:fontcolor=white:borderw=3` (wave
  motion needs per-letter filter passes — batch in build script).

## 37 — Zoom Punch
![preview](previews/37_zoom_punch.jpg)
- **Look:** a quiet small sentence holds on screen; on the beat, ONE emphasis word detonates from small to huge yellow (#FFD500), dominating the frame.
- **Animation:** setup line sits static; the punch word scale-explodes on the beat, holds, cuts.
- **Best for:** punchlines, plot twists, "but..." reveals, comedic emphasis.
- **Motion:** A quiet small sentence holds; the emphasis word detonates from small to huge on the beat and holds briefly.
- **Words on screen:** Setup sentence of 4-8 small words + exactly 1 punch word.
- **Placement:** The punch word goes dead center.
- **Don'ts:** Don't punch more than one word. Don't skip the quiet setup — the contrast is the joke.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: ZoomPunch,DejaVu Sans Bold,64,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,40,1`
  punch-word override on the beat: `{\fs130\1c&H0000D5FF&}` (yellow #FFD500 → ASS `&H0000D5FF`).
- **drawtext:** punch word `fontsize=130:fontcolor=#FFD500:borderw=4` centered,
  timed to the beat.

## 38 — Outlined Fill Swap
![preview](previews/38_outlined_fill_swap.jpg)
- **Look:** the keyword held as hollow white outline; on the beat it
  snap-fills to solid white. Reveal/answer energy.
- **Animation:** hollow hold → snap-fill on beat → holds solid.
- **Best for:** reveals, answers to questions, before/after, "the truth is…" moments.
- **Motion:** The keyword sits hollow; on its spoken beat it snaps to solid fill instantly.
- **Words on screen:** 1 keyword inside a short sentence.
- **Placement:** Centered.
- **Don'ts:** Don't fill gradually - the snap is the moment. Don't use small text (hollow is unreadable under ~70px).
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:** hollow base
  `Style: HollowFill,DejaVu Sans Bold,80,&H00000000,&H000000FF,&H00FFFFFF,&H00000000,-1,0,0,0,100,100,0,0,1,3,0,5,30,30,40,1`
  (PrimaryColour transparent `&H00000000` + white Outline=3). Fill moment:
  override `{\1c&H00FFFFFF&\alpha&H00&}` on the beat word.
- **drawtext:** hollow via matching fill: `fontsize=76:fontcolor=0x141414:borderw=3:bordercolor=white`
  (fill = background color, border = the visible outline). Fill moment: second
  `drawtext` pass with `fontcolor=white` on the beat word.

## 39 — Bracket Frame
![preview](previews/39_bracket_frame.jpg)
- **Look:** white bold caption framed by animated CORNER BRACKETS — four
  L-shaped corners (⌐ ¬ style) in accent color (#00D7FF) that draw themselves
  around the text. HUD/targeting energy.
- **Animation:** corners wipe in from each corner, text fades up inside.
- **Best for:** tech reviews, "target acquired" hooks, gaming, spec callouts.
- **Motion:** Four cyan corner brackets wipe in from the corners; the text fades up inside them.
- **Words on screen:** 2-6 words.
- **Placement:** Center, with the brackets framing the text block.
- **Don'ts:** Don't use without the brackets. Don't crowd the text against the bracket edges.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: Bracket,DejaVu Sans Bold,60,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,50,1`
  brackets: wrap line as `{\1c&H00D7FF&}┌{\1c&H00FFFFFF&} text {\1c&H00D7FF&}┘`
  (cyan #00D7FF → ASS `&H00D7FF`; full corner Ls need border drawing —
  approximate with unicode corners or drawbox passes).
- **drawtext:** text `fontsize=60:fontcolor=white:borderw=3` +
  `drawbox` L-corners in #00D7FF at the four corners of the text block.

## 40 — Emoji Word Swap
![preview](previews/40_emoji_word_swap.jpg)
- **Look:** normal white bold caption — but key nouns are SWAPPED for emoji
  inline (🔥 💰 🚀), oversized relative to text. Hormozi-creator signature.
- **Animation:** emoji pops in bigger than the word it replaced, with a
  little bounce.
- **Best for:** business/money talk, motivational, Gen-Z finance, hype captions.
- **Motion:** The emoji pops in oversized with a bounce, replacing the noun it stands for.
- **Words on screen:** Normal sentence with 1-2 emoji swaps max.
- **Placement:** Inline, centered.
- **Don'ts:** Don't swap more than 2 words - it becomes unreadable. Needs a color emoji font or PNG.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: EmojiSwap,DejaVu Sans Bold,60,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,2.5,1.5,5,30,30,50,1`
  emoji override: `{\fs84}` on the emoji token (font must include color emoji
  — DejaVu lacks it; use Noto Color Emoji if installed, else PNG overlay).
- **drawtext:** `fontsize=60:fontcolor=white:borderw=3`; emoji via
  `fontfile=NotoColorEmoji.ttf:fontsize=84` layered at word position
  (measure with text_w or burn as separate timed call).

## 41 — VHS Retro Stamp
![preview](previews/41_vhs_retro_stamp.jpg)
- **Look:** off-white monospace caption with VHS artifacts — slight chromatic
  fringe, subtle scanlines, and a camcorder timestamp ("PM 09:41") + "PLAY ▶"
  in the corner. Nostalgic lo-fi.
- **Animation:** text jitters ±1px continuously; occasional tracking-line
  roll.
- **Best for:** throwbacks, 90s/00s nostalgia, skate clips, lo-fi vlogs, "found footage" hooks.
- **Motion:** Text jitters plus/minus 1px continuously with an occasional tracking-line roll. The timestamp sits static top-left.
- **Words on screen:** Short phrases, 2-6 words, monospace.
- **Placement:** Center; timestamp top-left, PLAY indicator top-right.
- **Don'ts:** Don't overdo the jitter (it gets nauseating). Scanlines go via overlay, not baked into the font.
- **Footage:** not present in the four source videos — mechanics from web research only.
- **ASS preset:**
  `Style: VHS,DejaVu Sans Mono Bold,54,&H00E8E4D8,&H000000FF,&H00808080,&H00000000,-1,0,0,0,100,100,0,0,1,1,0,5,40,40,80,1`
  (off-white #E8E4D8 → ASS `&H00D8E4E8`; gray fringe via Outline). Timestamp:
  separate style top-left `{\fs36}` "PM 09:41". Scanlines = overlay pattern
  (ffmpeg `drawgrid` or PNG).
- **drawtext:** `fontfile=DejaVuSansMono-Bold.ttf:fontsize=54:fontcolor=#E8E4D8`
  + timestamp `fontsize=36:x=40:y=40:text='PM 09:41'` + scanlines via
  `drawgrid=w=iw:h=4:t=2:c=black@0.15`.
