# Web/UI resources retained for video production

Correction: the former skills-only filter was too narrow for a broader video-production resource index. A library can be useful without being a skill; a skill can be real but limited to development/maintenance. Keep those distinctions.

## cube-motion — supporting_skill
https://github.com/danielwh2/cube-motion
Skill: https://github.com/danielwh2/cube-motion/blob/main/skills/cube-motion/SKILL.md
UI entrances, exits, morphs and reveals
Replace scroll/intersection triggers and wall-clock playback with an explicitly seekable event/state sequence; validate WAAPI sampling in the chosen renderer.

## oil-motion — specialized_asset_skill
https://github.com/oil-oil/oil-motion
Skill: https://github.com/oil-oil/oil-motion/blob/main/SKILL.md
Prepare existing video/frame-sequence assets and interaction-driven motion resources
The skill explicitly is not a standalone finished-film editor. Reuse asset/timeline preparation; map interaction progress to output time. Do not invoke generation services without authorization.

## shadercn-typegpu — supporting_shader_skill
https://github.com/shadcn-labs/shadercn
Skill: https://github.com/shadcn-labs/shadercn/blob/main/.agents/skills/typegpu/SKILL.md
TypeGPU-based shader authoring when a planned graphic needs it
Validate WebGPU adapter, build plugin, shader completion and deterministic frame reads in the actual headless environment. Raw WGSL/WebGL is not the same API.

## hairline — supporting_skill
https://github.com/lucasmarkes/hairline
Skill: https://github.com/lucasmarkes/hairline/blob/main/skills/hairline-create/SKILL.md
Isometric line-figure assets and animated diagrams
Drive the existing figure engine with scripted pointer/state inputs if supported. If the engine cannot seek, export a reproducible asset or use a supported implementation; do not assume direct renderer integration.

## evil-buttons — component_asset_library
https://github.com/radiumcoders/evil-buttons
No relevant video-authoring skill verified here; retain as a component/library dependency.
Animated React button/components as controlled UI graphics
The inspected evil-button-docs skill maintains documentation/registry wiring, not video production. Keep the visual components as an asset dependency; do not load that maintenance skill for an edit.

## matter-js — dependency_not_skill
https://github.com/liabru/matter-js
No relevant video-authoring skill verified here; retain as a component/library dependency.
Designed physics-based graphic motion
Fixed timestep, initialized state and seeded inputs; reset/replay from a known state for seeks. No real-time engine loop in frame rendering.

## p5-brush — dependency_not_skill
https://github.com/acamposuribe/p5.brush
No relevant video-authoring skill verified here; retain as a component/library dependency.
Procedural drawing and brush textures
Seed all relevant random generators, reset/replay cumulative drawing and lock canvas dimensions/pixel density.

## gsap — dependency_not_skill
https://github.com/greensock/GSAP
No relevant video-authoring skill verified here; retain as a component/library dependency.
Timeline-driven DOM/SVG/canvas motion
Use a paused timeline explicitly sought to the requested output time; replace ScrollTrigger/pointer dependencies with a known progress curve or state schedule.

## Can the tools render it?
Yes, compatible HTML/CSS/SVG/Canvas/React/WebGL/WebGPU content can become video through a verified browser renderer or exported assets. Not all JavaScript is seekable, not every headless browser supports every GPU feature, and native compositors do not execute arbitrary web code. No installation or rendering was performed in this revision.
