# EDITING AGENT REVIEW — ROUND 2 (RULINGS APPLIED + PILOT APPROVAL)
Reviewed: 2026-10-27 · Follow-up to EDITING_AGENT_RUN1_REVIEW.md
Verdict: ALL FOUR RULINGS VERIFIED APPLIED. Pilot plan APPROVED by architect review.
The render-unlock line is the OPERATOR's to send (pilot gate, CORE line ~393).

## 1. COMPLIANCE VERIFICATION (round 1 rulings)

R1 APPLIED - CORRECT. Gate tables now contain only what can reject a submission
(end-card hold, language, Tier-0 honesty/claims); fps 60 / runtimes / loudness drift
moved to a deviations table. Relabeling without remeasuring is the right move - the
4.033 s / 3.000 s values stand.

R2 APPLIED - CORRECT, AND THE QUARANTINE IS FORMALLY ACCEPTED. The 30-file 5 s-card
rebuild rendered before the review arrived is quarantined at
`preruling_rebuild_NOT_FOR_DELIVERY/`, withdrawn as a deliverable, measurements
carried forward. This is the honest handling of a gate violation: disclose, quarantine,
do not dress up. Formal status (P3 below) keeps it quarantined until the new card
pattern passes human review.

R3 CONFIRMED - CORRECT. The +2.3 dB -> +1.2 dBTP clipping math was independently
re-measured, and the batch-wide finding (3 clips pushed over the true-peak gate by
normalization alone, Clip 18 at +1.2 dBTP) upgrades the limiter from precaution to
mandatory chain element. That is the correct systemic conclusion: limiter in EVERY
re-norm chain, not case-by-case.

R4 CORRECTLY HELD. Approved string recorded as the profile's approved_string; delivered
wording logged as a deviation (substantively compliant, not the approved string);
wordmark-vs-logo-graphic left to the operator. Release remains blocked pending the
operator's (a)/(b) decision - the review-draft pilot is not a release, so it may proceed
under the disclosure assumption (see P1).

BRIEF AMENDMENTS COMPILED - CORRECT. Link register filled with actually-found Drive IDs;
CTA counting rule entered as operator amendment v3 with the stricter reading preserved
as an option.

FRAME CHECKS - CLASSIFICATIONS ACCEPTED:
- Clip 09 (11.33-12.87 s) and Clip 08 (10.96-11.90 s): DEFECT class confirmed - hard
  black insert, no luma ramp, speech continuing underneath, caption floating over black.
  These are body defects, not source fades.
- Clip 17 (13.77-14.97 s): source outro fade, legitimate in the source, but it produces
  a double ending before the card - craft issue, operator choice (P2).
- Clip 07: held shot in a music-video source - not a defect. Accepted.
- Evidence strip on file: `black_windows_strip.png` - good practice; keep evidence
  artifacts attached to classifications.

FRT PAPER TEST - OBLIGATION CLOSED. All three protected treatments AVAILABLE with no
waiver against the reconciled profile. This closes the Task-8 campaign-start open item.
The recorded re-run triggers are correct and must stand, especially: if captions ever
become mandatory, FRT case (b) must be re-traced and would be recorded unavailable -
which is exactly why captions stay preference-class in the brief.

## 2. ROUND-2 RULINGS

P1 - PILOT PLAN APPROVED (architect side). The FIX_PLAN_clip28_pilot.md assumptions are
sound: approved CTA string; derived logo mark WITH provenance disclosure - acceptable
FOR THE LABELED REVIEW DRAFT only (a review draft is a legal deliverable state; the
release blocker stands until the operator answers R4); 30 fps by frame-drop (approved
de-interpolation); loudnorm two-pass -> alimiter -> ebur128 re-measure on the re-encoded
file; 5.000 s card (comfortable margin over the 4.5 s gate). Two technical notes:
- alimiter limit=0.75 is a -2.5 dBFS ceiling - more conservative than the -1.0 dBTP spec,
  which is correct here: it leaves headroom for codec-induced peak overshoot at encode.
  Watch the final integrated loudness after limiting; if it lands more than 1.5 LU below
  the -14 target, iterate the loudnorm target once and re-measure (the re-norm rule).
- Deliverable status MUST be the labeled review_draft with QC table, card frames, and
  disclosure block, as planned - not a batch, not a release candidate.

P2 - SUBMISSION EXCLUSIONS (defect and banned-claim handling).
- Clips 08, 09: EXCLUDED from submission batches. Body defects (hard black inserts with
  speech continuing) cannot be fixed in-pipeline without the masters. Do not submit
  known-defect bodies hoping the card fix compensates - rejection risk and honesty both.
- Clip 25: EXCLUDED. The on-screen "STREAM FREE" card is a burned-in pricing/availability
  claim - the R-04 class ("pricing, generation limits, rewards - NOT verified - do not
  display"). Masking a full-screen card is not a legitimate fix. Re-cut only from a master
  without the card; otherwise the clip stays out.
- Clip 17: OPERATOR CHOICE between (i) exclude from the first batch, or (ii) accept the
  double ending as a logged craft deviation. Default recommendation: exclude from batch 1;
  revisit only if a master allows a trim-into-card re-cut.
- Clip 24: the exclusion rationale must be self-contained - add its specific defect
  classification to the QC table footnote (it was used for method demos; that is not a
  defect class). Every excluded clip gets one line: clip | reason | missing input needed
  to fix (e.g., "master without burned-in card").
- These five live in a "NEEDS MASTER" list with the named missing input; they do not
  silently rotate back into batches.

P3 - QUARANTINE STATUS FORMALIZED. `preruling_rebuild_NOT_FOR_DELIVERY/` remains
quarantined until the amended card pattern passes human audiovisual review. After batch-
pattern approval: either re-render under the approved pattern (preferred - clean
provenance) or archive the quarantine as method evidence. Never promote quarantined
renders in place; the pilot must come from the approved plan, not from the pre-ruling set.

P4 - FRT CLOSURE RECORDED. Mark the Task-8 open item closed in the project record:
"FRT re-run at campaign start against the reconciled profile - DONE, 3/3 AVAILABLE."
Re-run triggers stand as recorded.

P5 - BATCH COMPOSITION RULE (going forward). A clip is a submission candidate only if:
(1) it passes the three gates after the approved card fix; (2) no burned-in banned-claim
class in the picture; (3) no unfixable body defect; (4) deviations logged. Keep batches
small enough to inspect; stop a repeated defective pattern before making more (CORE
pilot-gate language applies to batches, not just pilots).

## 3. WHAT UNLOCKS WHAT
- NOW: operator sends the one-line pilot approval (exact text below) -> agent renders
  clip 28 as review_draft.
- AFTER PILOT REVIEW (human watch/listen): batch-pattern approval -> re-render under the
  approved pattern -> first batch from P5-eligible clips.
- BEFORE ANY RELEASE CANDIDATE: operator answers R4 - (a) supply the official transparent
  PNG, or (b) written confirmation that the derived mark is the official logo.
- ANY TIME: master files for clips 08/09/17/24/25 would convert the NEEDS-MASTER list
  into re-cuts.

## 4. OPERATOR APPROVAL LINE (paste to the editing agent)
"Approved: render the clip 28 pilot exactly per FIX_PLAN_clip28_pilot.md - approved CTA
string; derived logo mark with provenance disclosure (review draft only, not a release
candidate); 30 fps by frame-drop conform; loudnorm two-pass + alimiter in chain; 5.000 s
card. Deliver as labeled review_draft with QC table, card frames, and disclosure block.
Exclusions per Round 2 P2 apply to all batches."
