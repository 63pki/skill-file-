# RESOURCE INTEGRATION REPORT — Captions & Effects Libraries into PEB + Skill Registry (v1.0, 2026-10-28)

**Role:** architect / resource reviewer. **Compliance:** no campaign video edited, no renders, no package installs, no archive code executed (extraction + parsing + hashing only), no providers called, no media uploaded, nothing published. Existing master prompt and frozen chain untouched. **STOP CONDITION honored:** report + proposed patches only.

**Method:** Phase-1 inventory (archive listing → extraction to inspection area → hashing → structural verification) → Phase-2 preservation analysis → Phase-3 technical honesty spot-checks → Phases 4–7 integration design. Every count below was independently verified, not taken from the libraries' own reports.

---

## 1. EXECUTIVE VERDICT

**Useful (integrate):**
- **The v2 governance layer is the most valuable part of the whole delivery.** CAPTION_LIBRARY_v2's authority/evidence rules, selection-by-job table, caption-vs-title-vs-demonstration distinction, timing/geometry contract, and corrected ASS notes are production-grade craft governance that matches our registry discipline almost line-for-line (its statuses are literally documented/installed/feature_tested/approved_for_project — the same four states as TOOL_REGISTRY §1).
- **Pastel-indigo style guide (HyperFrames-native)** — directly compatible with our verified T3 renderer; contains a complete style contract, motion language, and an honest internal tier ("recipes 1–6 tested in template; 7–18 are sketches").
- **Malayalam workflow's script-shaping knowledge** — real accessibility value: Malayalam conjunct shaping, taller mask padding, font verification via `fc-list :lang=ml`, "never put Malayalam in serif/mono stacks."
- **20-style pack templates** — deterministic `renderFrame(t)` contract, zero CDN dependencies, seeded randomness, alpha export paths; well-engineered as *template material* for T3.

**Redundant (do not duplicate):**
- The 20-pack's `render.py` (Playwright → ffmpeg) is a **second web-to-video path** — our §6 category rule already assigns motion-graphics compositing to T3. The templates are reusable; the renderer is not.
- 20 identical `render.py` copies (byte-identical ×20) — one shared script, not 20 implementations.
- The v2 libraries' SFX linkage per style is inert under our audio provenance policy until separately authorized.

**Unverified (treat as reference only):**
- Every visual outcome: no rendering performed by the library authors (their own report: `render_test_status: not_performed`) and none by us. All "tested in template" claims inside the packs are vendor/self-claimed, not feature-tested in our environment.
- Motion fields in the legacy caption catalog: source videos were **static Pinterest pins** (library's own honesty note) — all Motion fields are inferred direction, not measured timing.
- All 45 FX / 41 CAP / 24 caption JSON implementations: structurally present, execution unproven. A parsed recipe is not a renderer.

**Should remain inactive:**
- All legacy ASS/drawtext command sketches (explicitly deprecated; kept as history in `legacy_examples`).
- SFX family (8 IDs) and any audio-addition lane — provenance gate, needs separate authorization.
- PDF guide's executable stack (Remotion + ElevenLabs): T4 license gate + provider gate. Its *craft patterns* are referenceable now.

## 2. RESOURCE INVENTORY (grounded in actual files; hashes verified)

**Declared vs actual packaging:** the brief's "Editing_Resources_Recovered.zip" arrived as **three separate zips** (`claude-motion-styles-20.zip`, `malayalam-pastel-reel-edit.zip`, `pastel-indigo-motion-graphics.zip`). Content matches the description; packaging does not. No file was assumed from its name — all verified by extraction.

### 2.1 Captions_and_Effects_v2.zip — 9 files, all 8 manifest SHA256 verified OK
| Path | Type | Verified facts |
|---|---|---|
| `CAPTION_LIBRARY_v2.md` (68,590 B) | style reference + governance | 51 `##` headings = 10 governance sections + **41 styles (01–41)** with machine IDs CAP01–CAP41. Corrected ASS notes present verbatim (BGR order, BorderStyle=3 = rect not rounded, shadow≠glow, `\fad`≠blink loop, `\frx`≠slice). Legacy catalog preserved with honesty note (static-pin sources; styles 22–41 from web research) |
| `EFFECTS_AND_CAPTIONS_SPEC_v2.json` (275,679 B) | schema-structured reference | Independently confirmed: **24 caption_styles + 45 video_effects + 8 sound_effects + 41 catalog (CAP01–CAP41) + 6 motion_recipes + 8 web_ui_resources**, all ID sets unique. `revision.source_sha256` = preserved v1 original's hash (chain of custody intact). `runtime_rendering_performed: false`. `ffmpeg_visual_effect_filter` fields replaced by deprecation pointers; originals retained in `legacy_examples` |
| `EFFECTS_AND_CAPTIONS_SPEC_v2.schema.json` | schema | Draft 2020-12; validates structure incl. `implementation_status: const "not_tested"` on catalog entries. Parse-checked; **not a runtime/render contract** (their report says the same) |
| `FILE_MANIFEST.json` | manifest | 8/8 SHA256 independently re-computed and matched |
| `REVISION_NOTES.md` / `VALIDATION_REPORT.json` | provenance/history | Scope honestly limited to structure/preservation/references; render + source-recording review explicitly `not_performed` |
| `WEB_UI_VIDEO_ROUTING_CORRECTION.md` | routing policy | 8 web/UI resources with per-resource adapter limits (cube-motion, oil-motion, shadercn/TypeGPU, hairline, evil-buttons, matter-js, p5.brush, gsap) |
| `originals/CAPTION_LIBRARY.md` + `originals/EFFECTS_AND_CAPTIONS_SPEC.json` | preserved originals | v1 claims confirmed present UNcorrected (e.g., line 180 rounded-pill-from-BorderStyle=1 claim) — related-but-different variant of v2, retained as evidence, not production instructions |

**Duplicate relationships:** originals ≠ duplicates of v2 (they are the preserved, uncorrected predecessors). No exact duplicate files inside this zip.

### 2.2 claude-motion-styles-20.zip — 84 files
- 20 style dirs (particles, liquid-morph, holographic, neon-glow, wireframe-3d, glassmorphism, kinetic-type, isometric, clay-3d, ascii-art, gradient-mesh, comic-book, split-flap, retro-vhs, halftone, bauhaus, pixel-art, blueprint, art-deco, neo-brutalism), each: `SKILL.md` (unique) + `template.html` (unique) + `preview.jpg` (unique) + `render.py` — **all 20 render.py byte-identical** (md5 e67b868f…): one shared Playwright+Chromium frame-stepping renderer (`window.renderFrame(t)`, fonts.ready wait, MP4 / ProRes 4444-alpha MOV / VP9-alpha WebM / PNG still).
- Plus `gallery.html`, `README.md`, `PREVIEW-all-20-styles.jpg` (158 KB), `PREVIEW-all-20-styles.mp4` (7.3 MB).
- **License:** README grant only — "free to use, remix and share, including client work; don't resell the pack as-is." **No LICENSE file.** Claims "no external libraries or CDNs," "deterministic (seeded randomness)" — consistent with the renderFrame contract I read; not runtime-verified here.

### 2.3 malayalam-pastel-reel-edit.zip — 1 file
`SKILL.md` (680 lines): end-to-end HyperFrames reel workflow (ffprobe → contact sheet → conform → script-based alignment ±0.2–0.3 s → authoring rules → snapshot QC → SFX mix → loudness → delivery). **Authoring-environment-specific instructions embedded** (SendUserFile, device_commit_files, `~/Movies/claude-motion-demo/`, built-in-browser skill, AskUserQuestion) — must be stripped before any reuse. Embeds a full template HTML + `gsap-lite` fallback. **No license statement** (appears to be operator's own recovered project material — confirm at adoption).

### 2.4 pastel-indigo-motion-graphics.zip — 1 file
`SKILL.md` (530 lines): HyperFrames-native style contract (tokens, Instrument Serif/JetBrains Mono, HUD, masked-spring motion, 7 named transitions, recipe library with honest tested-vs-sketch tiers, vertical adaptation). **No license statement** (same provenance note as 2.3).

### 2.5 SaaS-Animation-Videos-with-Claude.pdf — 1 file (content extracted in-session)
Vendor course guide (Mateen Alvi, © course material): Claude Code + Remotion 4 + ElevenLabs + ffmpeg workflow for SaaS promo videos. Craft patterns of value: reference-video frame breakdown before building, check-frames-before-render, storyboard-first approval gates, word-timing-driven animation, vertical re-layout rules (nothing in bottom 15%), loudness −14 LUFS / −1 dBTP, a real troubleshooting table. Executable stack = Remotion (T4-gated) + ElevenLabs (provider gate) + music/SFX lanes (provenance gate). **Reference-only.**

### 2.6 Missing files / unresolved references
- **`upload-to-claude/` folder** referenced by the 20-pack README ("upload the zips from the upload-to-claude/ folder") — **not present in the archive.**
- **Legacy preview images** for the caption catalog — explicitly not included (v2 MD line 77).
- **Source videos** (`caption_styles_raw.mp4`, batch sources v1/v6/v9…) — not included; all source-reference fields are historical notes, not re-verifiable evidence.
- **No LICENSE files** in any zip (README grant for the 20-pack; the two SKILL packs and caption libraries have none — provenance suggests operator's own recovered material; confirm at adoption).
- Fonts referenced (Instrument Serif, JetBrains Mono, Manjari, Noto Sans Malayalam, Montserrat/Anton/Bebas) — not bundled; T3's font-fetch/cache behavior applies.

## 3. INTEGRATION MAP (four-way, reusing existing artifacts — no new registries)

**A. Skill Registry** → gains ONE new layer, **STYLE/EFFECT CATALOG (on-demand reference)**, cards SR-40…SR-45 (patch P-R1 below). These cards hold triggers/risk/license/fallback — never the style bodies. Style bodies stay in the attached files, loaded per selected treatment.

**B. Style/Effect Catalog** → `CAPTION_LIBRARY_v2.md` (human guide) + `EFFECTS_AND_CAPTIONS_SPEC_v2.json` (structured reference) become the catalog bodies; the 20-pack templates and pastel-indigo guide become renderer-ready treatment sources; the PDF becomes craft-pattern reference.

**C. Implementation Inventory** → gains rows: web-to-video deterministic path = **T3 verified** (HyperFrames); ASS/libass path = **available via FFmpeg, NOT feature-tested in our chain**; static caption via T0/T2 = proven; script-shaping check for non-Latin scripts = new checklist item. The 20-pack's Playwright renderer is listed as **category-conflicting, do not adopt** (T3 owns the category).

**D. Project Record** → existing fields suffice: routing line, REUSE lines, plus one new optional line `TREATMENT: <style/ref | none> · renderer <T3|FFmpeg-libass|T2> · checks <…>` when a treatment is selected. "No added treatment" is recorded exactly like a selection.

### Phase-5 routing table (per resource family)

| Family | Trigger (editorial need) | Suitable content | Unsuitable | Required inputs | Renderer | Implementation | Accessibility risks | Rights | Fallback | Verification needed |
|---|---|---|---|---|---|---|---|---|---|---|
| Speech captions (CAP, dialogue roles 09/17/19/30) | Clarify dialogue, noisy audio, accessibility baseline | Talking-head, interviews | Reaction beats where faces carry meaning; every-word popping | Word timings (T1, estimates) + transcript sidecar | T3 text or FFmpeg libass | Recipe contracts; no tested renderer | Contrast, reading load, script shaping, safe areas | Text = spoken words only; no rewrites hiding negations | Static clean caption | Fixture render + human frame review |
| Emphasis/keyword styles (01/02/06/16/18/37…) | One justified emphasis per the selection gate | Keyword moments | More than one per beat | Approved claim/word | T3 | Motion recipes (design contracts) | Overshoot bounds, gradient fill support | — | Plain bold color word | Bounds inspection incl. overshoot frames |
| Stat/claim cards (07/15/21/39) | Communicate a verified result | Approved numbers only | Unverified claims | Source + date + units | T2/T3 | Static cards proven | Units, qualifier visibility | Banned-claim gate applies | Plain text card | Claim check + readability |
| FX transitions/graphics (45 FX) | Hook, section change, comparison | High-energy openers | Quiet reveals; documentation tone | Source action supporting it | T3 (web-class) or FFmpeg (simple) | Legacy sketches deprecated → new T3 compositions needed | Flash risks (QC flash_review) | — | Hard cut | Flash/strobe review + fixture |
| 20-style pack (templates) | Ambitious motion treatment that improves communication | Brand-appropriate stylized segments | When style ≠ brand or overwhelms meaning | Text + palette params | **T3 via adapter** (not Playwright path) | template.html → T3 composition mapping (adapter missing) | Fonts (system fallbacks), bounds | Pack grant: use/remix OK, no pack resale | Simpler style | Determinism seek test + fixture |
| Pastel-indigo style | Explainer/talking-head with designed graphics | 16:9 or 9:16 explainers | Brands whose palette conflicts (tokens must NOT be reinvented — or re-tokened deliberately) | Speaker footage + script | T3 (native fit) | Recipes 1–6 claimed tested in template — re-verify | HUD clutter on small screens, serif legibility | Fonts via T3 fetch; freeze set | Reduced-motion variant | Snapshot QC per beat |
| Malayalam workflow | Multilingual (Malayalam) keyword captions | Malayalam talking-head | Full-subtitle volume (it teaches keywords, not walls) | Script as timing source (±0.2–0.3 s) | T3 | Template embedded; env instructions stripped | Conjunct shaping, mask height, font verification | — | English-only keywords | `fc-list :lang=ml` + render test line first |
| SFX family (8 IDs) | — | — | **Default inactive** | Authorized asset files + operator ruling | FFmpeg amix/alimiter path exists | Provenance gate: new audio needs authorization | Mix balance, −14 LUFS chain stays ours | Audio provenance policy | No SFX | Loudness + listen check when authorized |
| PDF guide patterns | SaaS/product promo structure | Product demos | Its specific stack | Logo, real clips/screens | T3 equivalent | Check-frames + storyboard-first patterns reusable | Vertical safe areas | Never-invent-numbers rule aligns with ours | — | — |

## 4. MINIMAL PATCHES (exact text; nothing applied)

**P-R1 — Registry prototype patch (REQUIRED for this integration):** insert into `SKILL_REGISTRY_PROTOTYPE_v0.9.md` after the CRAFT LAYER block:

```
**STYLE/EFFECT CATALOG LAYER (on-demand reference — bodies stay in attached files)**
- `SR-40 caption-library-v2` — 41 CAP styles + governance contracts. Content: REF. Trigger: caption/treatment selection at plan time. Licensing: operator's own material (verify at adoption). Renderer bindings: T3 text (untested), FFmpeg libass (available, NOT feature-tested). Fallback: clean static caption.
- `SR-41 effects-spec-v2` — structured reference: 24 caption + 45 FX + 8 SFX entries, contracts, minimal_project_instance. Content: REF. Trigger: parameter lookup after SR-40 selection. SFX entries INACTIVE (provenance gate).
- `SR-42 motion-styles-20` — 20 deterministic HTML templates. Content: REF→EXEC via T3 adapter (missing — bounded adaptation). Trigger: stylized motion segment justified by selection gate. Restriction: pack's Playwright render.py NOT used (T3 owns the category). License: README grant, no LICENSE file.
- `SR-43 pastel-indigo-style` — HyperFrames-native style contract + recipes. Content: REF (recipes 1–6 claimed tested in template — re-verify on first use). Trigger: explainer/talking-head designed-graphics segments.
- `SR-44 malayalam-pastel-workflow` — multilingual keyword-caption workflow + script-shaping knowledge. Content: REF. Override: strip authoring-env instructions (SendUserFile/device_commit/etc.); SFX lane gated by audio provenance policy.
- `SR-45 saas-animation-guide` — course PDF craft patterns (reference breakdown, check-frames, vertical re-layout, troubleshooting table). Content: REF. Its Remotion/ElevenLabs/music lanes: T4/provider/provenance gated — never executable here by default.
```

**P-R2 — Registry §2 routing addition (one sentence):** after the MATCH/PARTIAL/NONE outcomes add:
> "Treatment selection is a separate, later decision: consult the Style/Effect Catalog only when a communication need exists; `no added treatment`, `clean cut`, and `held shot` are valid selections recorded like any other."

**P-R3 — Implementation Inventory patch (one row):** append to `IMPLEMENTATION_INVENTORY_v0.9.md`:
> `| 13 | Styled captions / text effects | T3 text compositions (verified renderer); FFmpeg libass path available but NOT feature-tested in our chain | Inventory row 12 + T3 probe | New caption backends require a fixture before reliance; 20-pack render.py not adopted (category conflict) |`

**P-M1 — Master prompt patch (OPTIONAL, one sentence; complements P1):** in the plan/visual-selection step:
> "Visual treatments are chosen from the on-demand Style/Effect Catalog only when they improve communication; no treatment is mandatory and restraint is recorded as a decision."

**Explicitly NOT patched:** the frozen chain, the four-state status model, the audio policy text (P3 from the earlier patches file already covers provenance-vs-transform), the QC gate, and nothing about peak-first/hooks/music/cut-rhythm — none of these libraries' style defaults become rules (see §7).

---

## 5. PROPOSED CATALOG/CARD FIELDS (reuse-first)

**Reused unchanged** — registry §4 card format: `ID · title · layer · content level (REF|EXEC) · trigger · overrides · licensing (REPO/FILE/ASSET/DEP) · status · pinned SHA · usage/failure record`.

**One necessary addition for STYLE CATALOG cards only** (4 fields, all serving routing — not bureaucracy):
`renderer_binding · treatment_family · accessibility_risks · fallback`

**Why these four:** renderer_binding prevents the §6 category conflict class (the 20-pack lesson); treatment_family is the catalog's own role enum (speech_caption / hook_title / ui_label / evidence_graphic / transition); accessibility_risks and fallback are required by the v2 libraries' own contracts (contrast/shaping/flash; reduced-motion and static alternatives) — we would otherwise have to derive them per selection anyway.

**Rejected additions:** per-style sub-cards (41 CAP cards would bloat the registry — the catalog INDEX stays one card, bodies on demand); a crosswalk field between CAP## and legacy JSON IDs (the libraries deliberately provide `legacy_spec_style_id: null` — we preserve that honesty); any "tested" flag vocabulary beyond the existing four states.

## 6. REUSE & ADAPTATION BACKLOG (ranked by editorial value, not visual complexity)

**Tier 1 — Ready references (use now, zero adaptation):**
1. `CAPTION_LIBRARY_v2` governance sections (authority/evidence, selection-by-job, caption-vs-title, timing/geometry contract) — adopt as the catalog's standing rules. *Value: prevents an entire class of caption errors.*
2. Pastel-indigo style guide — T3-native explainer style. *Value: complete designed-graphics language for talking-head segments.*
3. Malayalam script-shaping rules + font verification procedure. *Value: makes multilingual captions safe.*
4. PDF craft patterns: reference breakdown before building; check-frames before render; one-message timestamped feedback; vertical re-layout. *Value: workflow hygiene independent of its stack.*

**Tier 2 — Candidate implementations (bounded adaptation, fixture before reliance):**
5. 20-pack templates → T3 compositions. Missing adapter: map `renderFrame(t)` contract → HyperFrames clip/timeline model; verify seek determinism + font behavior in T3. Start with kinetic-type, split-flap, blueprint (most communication-relevant).
6. Accessibility-first caption styles (CAP 09/17/19) → first fixture through ONE renderer path (recommend T3 text first; libass second) with contrast + reading-load + bounds checks.
7. JSON `minimal_project_instance` → caption sidecar format for the project record (it already defines required project/word-event fields).
8. Pastel-indigo recipes 7–18 (sketches) → snapshot + verify timing before trust, per the pack's own instruction.

**Tier 3 — Blocked resources (remain inactive):**
9. SFX family (8 IDs) + every pack's music/SFX lanes — audio provenance gate; needs operator authorization + asset files we don't hold.
10. PDF's Remotion + ElevenLabs stack — T4 license gate + provider gate.
11. All legacy ASS/drawtext sketches — deprecated by the library itself; history only.
12. 20-pack `render.py` as a renderer — category conflict with T3 (templates remain usable).

**Tier 4 — Missing adapters (build only on a real trigger, per inventory-first rule):**
13. JSON word-timing → T3 composition timing adapter.
14. libass caption path fixture (only if T3 text proves insufficient for volume captioning).
15. Style→recipe crosswalk — deliberately NONE exists; do not invent one.

## 7. THREE PAPER TESTS (no rendering)

**TEST 1 — Dialogue/comedy where timing and reactions matter.**
Constraint: original audio only; comedic timing lives in faces and pauses. → Need: clarify occasionally overlapping dialogue WITHOUT stomping reaction beats. → Selection: phrase-level clean caption (CAP 09/17/19 class), NO emphasis styles on punchlines (the laugh must land untouched); captions duck out entirely during held reaction shots. → Reuse: CAPTION_LIBRARY selection-by-job row 1 + timing contract ("preserve meaningful pauses"); T3 text path. → Limitation: word timings from T1 are estimates — comedy beats need manual boundary confirmation against the waveform. → Checks: reading-load at phone size, caption-free reaction windows verified frame-by-frame, sidecar transcript kept for accessibility, bounds inspection. `TREATMENT: CAP09-class clean caption · renderer T3-text · no-emphasis-during-reactions recorded`.

**TEST 2 — Product/UI demonstration requiring purposeful motion.**
Constraint: real interface only (no invented UI); banned-claim gate active. → Need: direct attention to the one action that proves the claim. → Selection: cursor-led highlight + one stat card (CAP 07/21 class) with source+date+units; PDF's check-frames pattern for the demo segment; 20-pack NOT selected (brand mismatch + adapter cost for one segment). → Reuse: inventory rows 4–5 (static cards proven; T3 verified); PDF storyboarding pattern. → Limitation: none of the library entries is a tested renderer — the stat card must be built as a new small T3 composition from the recipe contract (new code justified: "no tested component renders styled stat cards yet" — inventory-first rule satisfied). → Checks: claim approval before render, flash review n/a, safe-area for platform UI, final-frame readability.

**TEST 3 — Wordless reveal/transformation where restraint may be strongest.**
Constraint: transformation reads visually; voiceover absent by design; original ambient audio only. → Need: none that text or added motion improves — the transformation IS the message. → Selection: **NO ADDED TREATMENT** — clean cut into the reveal, held shot, no caption, no effect (valid selection per P-R2; also the v2 libraries' own `no_effect_is_mandatory: true` and the selection gate's "what does the viewer understand better than with a clean cut" question). → Reuse: nothing loaded — zero skill bodies, zero style bodies; routing line records the restraint decision. → Limitation: none claimed. → Checks: exposure/continuity QC through the existing chain only. This test exists to prove the registry doesn't force resource theater.

## 8. HONEST STATUS

| Level | Scope |
|---|---|
| **Inspected (read)** | Every file in all four zips' key surfaces: v2 MD (governance fully + legacy-catalog sample + honesty notes), v2 JSON (structure, counts, policy sections, representative entries of every array), schema, manifest, revision notes, validation report, routing correction; 20-pack README + full render.py + structure of all 20 dirs; both SKILL.md packs (opening sections + targeted greps); PDF (full provided text) |
| **Structurally checked (independently re-computed)** | 8/8 manifest SHA256 match; counts 24/45/8/41/6/8; ID uniqueness all four sets; CAP01–CAP41 span; 20× identical render.py (md5); v1-originals relationship (uncorrected claims confirmed present); chain of custody (`revision.source_sha256` = preserved original hash); absence of LICENSE files; `upload-to-claude/` missing |
| **NOT runtime-tested** | Any render, any template execution, determinism-under-seek of the 20-pack in T3, libass rendering of any ASS sketch, font shaping (Malayalam conjuncts) in our environment, `gsap-lite` behavior, loudness paths from the packs |
| **NOT audiovisually reviewed** | The packs' preview JPG/MP4 files (vendor evidence, not watched as QC), source recordings (not provided), caption timing against real speech |
| **Evidence status of library claims** | "Tested in template" (pastel-indigo recipes 1–6, 20-pack determinism) = author claims, plausible per code reading, UNVERIFIED here. Their own validation scope = structure/preservation only. Everything carries `not_tested`/`design_contract_not_executable` markers honestly |

**Not verified, stated plainly:** I did not watch any video, render any frame, run any validator beyond JSON parsing, or verify third-party font licenses (Instrument Serif/JetBrains Mono/etc. are Google-Fonts-class but license re-read happens at adoption per standing G3). The catalogs' historical "verified against footage" flags apply to static frames only, per the libraries' own notes.

---

**STOP CONDITION:** report and patches complete. No master-prompt text changed, no adapters implemented, no production started. Awaiting operator ruling on P-R1/P-R2/P-R3 (registry+inventory) and P-M1 (optional prompt sentence).
