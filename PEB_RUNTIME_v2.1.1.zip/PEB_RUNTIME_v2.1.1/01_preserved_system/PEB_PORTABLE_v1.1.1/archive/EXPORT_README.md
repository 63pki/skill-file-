# EXPORT README — PEB / RexTrix system export for an independent builder (v1.0, 2026-10-28; rebuilt same day for delivery size — see §7)

This ZIP is a **path-preserving, no-rewrites export** of the Pro Editor Brain (PEB) video-editing system for the RexTrix campaign, as it exists on 2026-10-28. Nothing was rewritten, improved, installed, or rendered to produce it. System files are byte-exact copies; the only new files are this README and `EXPORT_APPROVAL_STATE.md`.

**The export is NOT claimed complete** — see "Missing referenced files" below for what the shipped documents reference but this export cannot provide.

## 1. Layout

```
PEB_SYSTEM_EXPORT_v1.0/
├── EXPORT_README.md                     ← you are here (contents + missing-files summary)
├── EXPORT_APPROVAL_STATE.md              ← approved-applied / approved-not-applied / proposed-only / superseded / unresolved
├── HANDOFF_PACKAGE_PEB_RexTrix_v1.0/     ← the system core, VERBATIM (171 files; internal references verified:
│                                           START_HERE.md → reading order, frozen chain, approved-vs-held snapshot;
│                                           PACKAGE_MANIFEST.md → per-file SHA-256 for integrity checks)
│   ├── 01_master_prompt/                 core (v3.1.1 TEST FREEZE) + 3 modules + README manifest
│   ├── 02_registry/                      SKILL_REGISTRY_v1.0 + TOOL_REGISTRY (T0–T7) + PAPER_ROUTING_TESTS (3/3 PASS)
│   ├── 03_implementation_inventory/      12 tested components + known-NOT-verified list
│   ├── 04_catalogs_and_resources/        CATALOG_GUIDANCE + Captions_and_Effects_v2 + 20-style pack (loose)
│   │                                     + pastel-indigo + malayalam SKILL.md + SaaS PDF
│   ├── 05_components/                    12 reusable scripts + COMPONENTS_MAP
│   ├── 06_setup/                         DEPENDENCIES_AND_SETUP (text-only commands)
│   ├── 07_status/                        STATUS_LEDGER + PENDING_RULINGS + current reports + evidence/
│   ├── campaign_context/                 RexTrix brief + scout prompt v2 + correction notes
│   └── archive/                          39 historical files (NOT startup reading) incl. OPERATOR_INPUT_2026-10-28/
└── extras/                               ← items outside the package, mirrored under their workspace-relative paths
    ├── download/SKILL_REGISTRY_PROTOTYPE_v0.9.md    (registry ancestor, superseded by SKILL_REGISTRY_v1.0)
    ├── upload/Captions_and_Effects_v2.zip           (caption/effects v2 bundle — as delivered, 9 text files)
    ├── upload/malayalam-pastel-reel-edit.zip         (pack = SKILL.md only)
    ├── upload/pastel-indigo-motion-graphics.zip      (pack = SKILL.md only)
    └── scripts/build_package_manifest_and_verify_refs.py   (reference/manifest checker cited by 07_status/REFERENCE_VERIFICATION.md)
```

The package folder is self-contained: its navigation documents were reference-verified (STRICT pass — 0 broken internal references). Byte-exact project documents and vendor bodies additionally carry ~221 path mentions pointing at the ORIGINAL workspace layout; they resolve there, not inside the export — that is by design and is transparency-listed in `07_status/REFERENCE_VERIFICATION.md`.

## 2. Where each requested item lives

| # | Requested | Location |
|---|---|---|
| 1 | Latest approved master prompt + every module it references | `…/01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md` (v3.1.1 TEST FREEZE) + `PEB_v3.1_MODULE_GRAPHICS.md` + `PEB_v3.1_MODULE_MOTION_PIPELINES.md` + `PEB_v3.1_APPENDIX_REFERENCE.md` — the CORE references exactly these three modules (verified). Delivered test bundle of the same four docs: `…/archive/PRO_EDITOR_BRAIN_v3.1.1_TEST.zip`. |
| 2 | SKILL_REGISTRY_PROTOTYPE_v0.9 or successor | Prototype: `extras/download/SKILL_REGISTRY_PROTOTYPE_v0.9.md`. Latest successor: `…/02_registry/SKILL_REGISTRY_v1.0.md` (path-corrected in-package version is the authoritative one). |
| 3 | IMPLEMENTATION_INVENTORY_v0.9 or successor | `…/03_implementation_inventory/IMPLEMENTATION_INVENTORY_v0.9.md` (v0.9 IS the latest; no successor exists). |
| 4 | PROPOSED_CORE_PATCHES_MINIMAL_v0.9 | `…/07_status/PROPOSED_CORE_PATCHES_MINIMAL_v0.9.md` (proposed only — see EXPORT_APPROVAL_STATE §3). |
| 5 | PAPER_ROUTING_TESTS_v0.9 | `…/02_registry/PAPER_ROUTING_TESTS_v0.9.md` (3/3 PASS). |
| 6 | Current tool/capability registry + evidence behind claimed tests | `…/02_registry/SKILL_REGISTRY_v1.0.md` + `PEB_v3.2_MODULE_TOOL_REGISTRY.md`; evidence: `…/07_status/STATUS_LEDGER.md` (per-tool evidence column), `07_status/evidence/pack_equivalence_result.json`, `05_components/` (the verification scripts themselves), `extras/scripts/build_package_manifest_and_verify_refs.py`. ⚠ probe report FILES are missing — see §3. |
| 7 | Reusable scripts/templates/components/schemas/fixtures referenced by inventories | `…/05_components/` (12 scripts + COMPONENTS_MAP mapped to inventory rows); templates: 20 × `template.html` + `render.py` (reference implementations) in `04_catalogs_and_resources/claude-motion-styles-20/motion-*/`; schema: `Captions_and_Effects_v2/EFFECTS_AND_CAPTIONS_SPEC_v2.schema.json`; fixtures: T6 known-card fixture is spec-only (never created), pilot fixtures excluded as campaign media — see §3. |
| 8 | Caption/effects v2 bundle + three motion/style packs | Working set: `…/04_catalogs_and_resources/` (Captions_and_Effects_v2 9-file set; 20-pack loose tree — 20 styles × 4 files + gallery + README + previews; pastel-indigo + malayalam SKILL.md). As-delivered vendor bundles: `extras/upload/` (3 zips: Captions_and_Effects_v2, malayalam, pastel-indigo). The 13.4 MB outer 20-pack vendor zip was excluded at the delivery rebuild as a member-verified duplicate of the shipped loose tree — see §4. |
| 9 | SaaS-Animation-Videos-with-Claude.pdf | `…/04_catalogs_and_resources/SaaS-Animation-Videos-with-Claude.pdf` (2,584,478 B, SHA-256 f1ba32be…, hashed + read in full as supplied text). |
| 10 | Current reconciliation/integration reports | `…/07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` + `COVERAGE_RECONCILIATION_v2.1.md` (current); v1.0/v1.1 and v1.0/v2.0 historical in `…/archive/`. |
| 11 | Approval-state note | `EXPORT_APPROVAL_STATE.md` (this export root). |

## 3. Missing referenced files (identified, NOT created)

These files are referenced by shipped documents but do not exist in this export or the source workspace. No replacements were fabricated.

1. **Probe reports T3/T4/T5-PROBE-1 (standalone files)** — cited as "sources of truth" by IMPLEMENTATION_INVENTORY_v0.9 and STATUS_LEDGER ("T3 tool probe; T5-PROBE-1 report lineage"), but no such files were ever persisted to the workspace. The probe RESULTS survive only as recorded claims (TOOL_REGISTRY cards; STATUS_LEDGER §1; inventory row 5 "probe 9/9"). Treat as summarized evidence, not raw logs.
2. **Caption preview media (never delivered)** — `previews/01_keyword_pop_cyan.jpg` … `previews/41_vhs_retro_stamp.jpg` (41 files), `caption_styles_raw.mp4`, `styles_v2_mobile.mp4`, `styles_v3_18s.mp4`, `styles_v4_2min.mp4` — referenced by CAPTION_LIBRARY_v2.md and its original; absent from the delivered v2 bundle (9 text files only) and never delivered to this workspace. Runtime rendering was never performed (`VALIDATION_REPORT.json`).
3. **T6 known-card fixture** — the OCR smoke-test fixture is specified in the T6 card ("OCR a known-card fixture frame, require the expected string") but was never created; intake-sweep gate is queued.
4. **Pinned skill bodies for SR-01…03** — no skill body is stored locally; EXEC activation is gated on pin SHA + first-use fixture (PENDING_RULINGS §B).
5. **Vendor SKILL.md-internal workflow assets** — `reel/`, `project/`, `gsap.min.js`, `phrases.json`, `edit.json`, `storyboard.md`, `voice_cut*.wav`, `render_fallback.py`, etc. — these are per-run artifacts the vendor skills create when executed; they are not part of the delivered packs (each pack ships SKILL.md only, except the 20-pack's per-style template/render/preview).
6. **Remote-repository material (deliberately not shipped)** — `scripts/extract_video.py` (inside the third-party 274326424/video-content-extractor repo, recorded by the operator audit), `itsjwill/vanta` LICENSE/code/SKILL.md (never read here), the 60 audited repositories' bodies. These are remote references, not local files.
7. **The declared-but-never-delivered "single zip" variant of the 20-pack** — declared in vendor material, never delivered, equivalence unverifiable (REPORT v1.2 §2.2 non-generalization list).

## 4. Intentional exclusions (with reasons)

- **Campaign footage and campaign-derived media** (per "exclude large campaign videos"): `rextrix_review/` (10 source clips ×2 copies, audio, frames, sheets, transcripts, RexTrix_10_Clips.zip), `pilot_review/` (pilot frames + body audio), the clip-28 pilot draft MP4. The derived REPORTS are included (`archive/REXTRIX_10clip_review.md`, `archive/PILOT_CLIP28_REVIEW.md`) and the reusable verification PATTERN is included (`05_components/pilot28_verify.py`).
- **Credentials**: `rextrix_review/cookies.txt` + `headers.txt` (session credential material) — never referenced by system docs.
- **Caches / transient**: `tool-results/` (its duplicate `pack_equivalence_result.json` is canonical in `07_status/evidence/`); `.git`; no `node_modules` exists anywhere in the workspace.
- **Session-root duplicate copies**: workspace-root `SKILL_REGISTRY_v1.0.md` (identical content to the package's 02_registry copy except two reference-path lines pointing at the former workspace layout), `COVERAGE_RECONCILIATION_v2.1.md` and `RESOURCE_INTEGRATION_REPORT_v1.2.md` (byte-identical to package copies). The package copies are authoritative.
- **Master-prompt construction parts** (`scripts/peb_*_part*.md`): superseded writing intermediates, not byte-equivalent to the assembled documents; the assembled, approved, regression-audited documents are shipped.
- **Raw operator inputs in the source `upload/`** (23 pasted task texts, `consult A–D responses.txt`, original prompt input copies `PRO_EDITOR_BRAIN_MASTER_PROMPT_REVISED.md` / `PRO_EDITOR_BRAIN_v3*.md`, `RexTrix_Workflow_Review.md`, `On_Demand_Video_Tool_Guide.md`, duplicate SaaS PDF): processed/consolidated versions are in the package; the standing operator-input record is `…/archive/OPERATOR_INPUT_2026-10-28/`.
- **`upload-to-claude/` per-style zips** (20, inside the original vendor bundle): verified byte-identical duplicates (80/80 SHA-256) of the included loose directories — documented in `START_HERE.md` §6 + `07_status/evidence/`.
- **The original outer vendor zip `upload/claude-motion-styles-20.zip` (13.4 MB)** — excluded at the 2026-10-28 delivery rebuild: the first build of this export (26.9 MB, 179 files) failed to download for the operator (transfer-size limit), and this zip was the single dominant item. Member-level verification performed at rebuild (read-only, `scripts/check_vendor_zip_overlap.py` in the source workspace): of its 126 entries, 84 real files are byte-identical (SHA-256) to the shipped loose tree, 20 are the `upload-to-claude/` wrapper zips whose members were already verified 80/80, and 22 are directory entries — **zero unique real content; nothing is lost by this exclusion**. The original file remains in the source workspace `upload/`; the shipped loose tree is the authoritative working copy. (This closes the former "outer zip equivalence never compared" open item.)
- **Prior delivery ZIP** (`HANDOFF_PACKAGE_PEB_RexTrix_v1.0.zip` from the previous packaging task) and its helper `handoff_zip_check.py`: delivery artifacts of the packaging task itself, not system components (their contents = the shipped package folder).

## 5. Dependency manifests and lockfiles

**None exist in the workspace** — searched for `package.json`, `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `requirements*.txt`, `pyproject.toml`, `Pipfile*`, `poetry.lock`, `Gemfile`, `composer.json`: zero hits. Dependencies are documented textually in `…/06_setup/DEPENDENCIES_AND_SETUP.md` (toolchain T0–T7, fonts incl. Malayalam-capable via `fc-list :lang=ml`; install commands are TEXT-ONLY — installs are operator-gated). The vendor `render.py` scripts assume a local Playwright-style browser render path (retained reference only — NOT the production renderer; production is T3 HyperFrames pinned 0.8.207, adapter gap G1 open).

## 6. Security scan

Pattern scan (API keys / passwords / bearer tokens / private-key blocks / common credential formats) over every shipped text file: **no credentials found**. Only benign prose matches ("'secret' / 'pro tip' moments" caption copy; "never type passwords" instruction; the `ELEVENLABS_API_KEY` env-var NAME listed as a third-party requirement, with no value).

## 7. Integrity

- Package folder inside this export: verified byte-identical to the source workspace copy (`diff -r`, 0 differences) and hash-covered per-file by `…/PACKAGE_MANIFEST.md` (170 files hashed + manifest itself).
- This ZIP: full CRC test + set-parity against the staged tree performed at packaging time (worklog Task 31). Re-verify with `unzip -t` and against PACKAGE_MANIFEST SHA-256 lines if desired.
- **Delivery rebuild (2026-10-28, worklog Task 32)**: first build (26.9 MB, 179 files) failed to download for the operator. Rebuilt as a ~13.5 MB, 178-file ZIP by excluding the member-verified duplicate outer vendor zip (§4). System files are unchanged; the only content difference vs the first build is that one excluded duplicate and these updated notes. Full CRC test + set-parity re-run against the staged tree after rebuild: PASS.
