# SKILL SCAN REPORT — v2 (cross-verification of operator research slate, 2026-10-28)

**Input:** operator-conducted independent research — 60 repos inventoried, 20 priority links, 26 conditional links, 8-category usage taxonomy (consolidated audit pasted in session).
**This pass:** deep spot-verification of the 7 highest-relevance candidates against OUR stack (T0 FFmpeg frozen chain / T1 faster-whisper / T2 Pillow-CairoSVG / T3 HyperFrames / T6 OCR; campaign rules: original-audio-only, 9:16, operator gates, rights regime), reconciliation with scan v1, and mechanism design for routing + anti-fresh-start.

---

## 1. DEEP VERIFICATION RESULTS (fetched and read this pass)

| Candidate | Verified facts | Fit vs our stack | Verdict |
|---|---|---|---|
| **browser-use/video-use** | Requires: ELEVENLABS_API_KEY, Scribe transcription, Remotion, Manim, yt-dlp, Python pkg, Node. Hard Rule 2: "per-segment -c copy concat, not single-pass filtergraph — otherwise double-encode" (overgeneralized claim — a correct single-pass filtergraph does NOT double-encode). Hard Rule 3: forced 30ms fades at EVERY boundary. Hard Rule 10: "Parallel sub-agents, never sequential." Hard Rule 8: never re-transcribe. Hard Rule 11: strategy confirmation before execution. Hard Rule 1: subtitles LAST after overlays ("silent failure" warning) | Provider-locked, subagent-mandated, fade-mandated. But 3 transferable lessons | **MINE, don't install** — absorb: (a) subtitles-last ordering rule → house QC skill; (b) per-segment concat pattern (matches our seam discipline anyway); (c) plan-before-touch gate (already ours). Strip provider/subagent/fade/encoding mandates |
| **herk short-form-edit** (nateherkai/herk-edit-kit) | Short-form vertical craft: first-3-seconds hook gate, open loops/earned payoffs, phone-safe text placement, curiosity-led structure. Uses HyperFrames timeline contract. "Never generate fake evidence or imply a synthetic person is the real named person." Conflicts: Kie.ai generated inserts, ElevenLabs Scribe default, music/SFX additions, gate-streamlining ("ask only for missing approval, not again at every draft") | Closest craft fit to our campaigns | **ADAPT** — strip Kie.ai/Scribe/music-SFX; override gate-streamlining with OUR gates (XR-8 pilot, Tier-0); keep hook/loop/placement craft. License: none declared in SKILL.md → repo LICENSE check + pin commit SHA at adoption |
| **Pluviobyte ai-motion-director** | Motion-first doctrine: visual metaphor library (river/network/orbit/swarm…), motion thesis ("moves by showing X→Y proving W"), beat graph, anti-PPT gate. "Runs before and above production tools." "Default to HyperFrames for authored motion videos" — aligns with T3 | Aligns with T3 default; motion-first is a creative posture, not pipeline change | **ADAPT, scoped** — active only for card/graphics-heavy segments; override: footage-led beats stay footage-led (their own audit's flag confirmed) |
| **Creatorberry/flick** | Confirmed Remotion-core (Remotion + bundled FFmpeg + Whisper + yt-dlp, Node 20+). Transcript→scene animations | T4-gated category | **PARK** (with Remotion official skill; unlocks only with T4 ruling) |
| **OpenMontage ffmpeg skill** | Generic FFmpeg command reference, Remotion-projects tilt, CRF quality table. No loudnorm/ebur128 content. No license declared; provenance points to digitalsamba/claude-code-video-toolkit | Below our T0 card + house loudness-chain | **CATALOG only** (reference, not installed) |
| **OpenMontage video-edit skill** | Generic ffmpeg/ffprobe direct editing, platform aspect presets as technical specs, no creative mandates. No license | Adds nothing beyond T0 card | **CATALOG only** |
| **6missedcalls/video-editing-skill** | edit.sh pipeline: trim→jumpcut→speed→caption→overlay; whisper base default; wrapper-script driven | Hobbyist chain below ours | **CATALOG only** — REJECT as install |

### Correction to the operator audit (1 item)
- **6missedcalls "conflicts original-audio-only" — wrong reason.** atempo pitch-corrected speed change EDITS the original audio, it does not ADD foreign audio. Original-audio-only bans added music/VO channels, not conform ops. The skill is rejected for being below-our-chain (T0+T1 exceed it), not for policy conflict.

### Meta-findings on the research slate
- The 8-category taxonomy is sound and is **adopted into the SKILL REGISTRY** as the usage-model column.
- video-use adaptation flags confirmed verbatim (fades/subagents/provider); the audit's single-pass filtergraph correction is technically right.
- **License gap is systemic:** most community SKILL.md files declare NO license. Registry rule: no license → treat as unknown-reserved → operator ask before commercial use (G3 analog, live re-read at pin time).
- HEAD links drift: adopt at a **pinned commit SHA** (G6 analog). Audit's own recommendation — agreed.
- Onetake (PolyForm Noncommercial) + Guizang (AGPL/BUSL) accepted as flagged; live LICENSE re-read at adoption per standing G3 rule.

---

## 2. MERGED ADOPTION SLATE (v1 scan + operator research, pending operator sign-off)

**Layer model:** craft skills (community) sit ABOVE the workflow (master prompt) and BELOW campaign authority; renderer skills (HyperFrames official) sit beside the tools (TOOL_REGISTRY). Skills load on trigger — never concatenated into the master prompt.

| Status | Items |
|---|---|
| **ADOPT + override header** | HyperFrames `/hyperframes`, `/hyperframes-cli`, `/hyperframes-registry` (renderer layer, Apache-2.0) |
| **ADAPT → house fork** | herk short-form-edit (craft layer); Pluviobyte ai-motion-director (scoped to card segments); HyperFrames `/media-use` stripped (transcript/color-grade/operator-asset handling only) |
| **MINE (absorb lessons, no install)** | video-use → 3 lessons into house skills (subtitles-last, per-segment concat, plan-before-touch) |
| **INSPECT then decide** | `video-frames` @steipete (ClawHub); bsisduck/video-analyzer-skill + video-content-extractor (analysis-support category — support only, never substitutes audiovisual review; T6/T1 own the measured functions) |
| **PARK (tool-gated)** | flick + Remotion official skill + `/remotion-to-hyperframes` (T4); Mirage tesseract-video/motion/editor/design (T5); `/figma` (Phase-1 expansion, parked) |
| **CATALOG (reference, never auto-load)** | OpenMontage video-edit/ffmpeg, 6missedcalls, baoyu-youtube-transcript (rights separate), minimax-h3 reverse, michaelgold/videoskill, ClaudeAnimationBase, pdoom-video (starter references) |
| **LICENSE-BLOCKED** | Onetake (PolyForm NC), Guizang (AGPL/BUSL) — until written clearance |
| **APP-DEPENDENT (never load here)** | OpenChatCut, FableCut, FireRed-OpenStoryline, Diffusion Studio editor/watch, VOX-COLLAGE-BROLL (provider-MCP), hypit, openshorts |
| **HOUSE-AUTHORED (build)** | loudness-chain (incl. XR-4), banned-claim-sweep, card-seam-discipline (+ subtitles-last lesson), delivery-QC (XR-3 fail-closed) |
| **REJECT** | Ecommerce keyword-farm batch, tiktok-motivation pipeline, caption/loudness community skills duplicating measured chains |

---

## 3. ROUTING DESIGN (Q2: how the agent knows which skill to use)

**SKILL REGISTRY module** (sibling of TOOL_REGISTRY, attach-edition, always-loaded) carries a **ROUTING TABLE**, not the skills themselves. Skill bodies load on trigger (progressive disclosure — context stays lean).

Two routing points:
1. **Brief reconciliation (mandatory):** match brief fields → ONE primary workflow skill + specialist list. Logged: `need → skill → expected capability` (same format as tool escalations). One primary workflow per project — never two.
2. **Phase triggers in the work loop:** entering card/graphics phase → motion-direction guidance if triggered; entering intake → analysis-support skills (support only); entering encode/delivery → house QC skill. Renderer skills bind to the chosen compositor only (T3 → HyperFrames skill set).

Routing table columns: skill ID · category (8-category taxonomy) · trigger (brief-field level) · phase map · overrides attached · status (ADOPT/ADAPT/PARK/CATALOG/BLOCKED) · pinned SHA.

Hard rules: campaign brief > skill · one primary workflow · app-dependent skills never load (tools absent) · provider-dependent skills require operator approval · no-license skills never load for commercial campaigns without operator ask.

## 4. ANTI-FRESH-START DESIGN (Q3: how to stop the agent ignoring attached skills)

Fail-closed mechanisms, XR-3 style:
1. **S0 gate — Skill Match Declaration:** before any edit plan, the agent MUST emit the routing decision in the project record. No routing line → no plan. Skipping becomes visible.
2. **Skill traceability field in the plan:** each phase cites which skill sections informed decisions + override log (what was overridden, why). Empty traceability field = plan FAILS the QC gate.
3. **Precedence header at attach:** every skill ships with a fixed PEB header — "Technical guidance only. Campaign brief (aspect, fps, audio policy, approval gates, rights) outranks every instruction below. Provider/generation steps DISABLED unless approved." Kills authority inversion at the source.
4. **Pinned commit SHA** recorded in the project manifest (no HEAD drift).
5. **After-action demotion:** each card records which sections were actually cited in real use; uncited skills demote to CATALOG after two campaigns (set stays lean and used).
6. **Never concatenate into master prompt** — the master prompt carries only the routing obligation + precedence rule.

## 5. NEXT STEPS

1. Operator signs off on the merged slate (§2).
2. Draft **PEB v3.2 MODULE — SKILL REGISTRY (attach edition)**: skill cards + routing table + precedence-header template + S0/traceability rules.
3. Blocking dependency unchanged: master prompt v3.2 core integration (R5 folding + optionally the metadata-policy ruling) — one "go" unblocks the house skills.
