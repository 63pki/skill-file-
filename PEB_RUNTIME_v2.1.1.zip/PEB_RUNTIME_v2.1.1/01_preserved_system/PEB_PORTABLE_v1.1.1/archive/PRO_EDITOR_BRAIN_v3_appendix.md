PRO EDITOR BRAIN v3 — APPENDIX (load on demand)

Reference material for the master prompt (PRO_EDITOR_BRAIN_v3.md). Load only the section you need;
nothing here overrides the master prompt's precedence. Rule IDs match the master prompt.

A. CAMPAIGN PROFILE CONTRACT (schema for §3)
=====================================================================
schema_version: creative-profile/1.0
campaign: {objective, audience, viewer_value, primary_mechanics: [evidenced_curiosity,
  payoff_delivery], optional_mechanics: [meaningful_rewatch, share_utility],
  optimization_mode: mechanics_not_outcome_prediction}
delivery: {resolution: [1080,1920], runtime_seconds: {min: 15, max: 40}, language,
  output_fps, source_manifest_ref}
owner_mandates: {mechanics_led_every_clip, strong_visual_audio_text_hook,
  strongest_supported_moment_selection, real_peak_first, continuous_method_discovery}
hook_policy: {evaluation_window_seconds: 3, required_channels: [visual, audio, text],
  strong_total_min: 18, channel_dimension_min: 3, other_dimension_min: 2,
  publish_min_band: strong, text_max_words_default: 8, silence_open: {allowed: true,
  meaningful_audio_entry_by_seconds: 0.6}}
teaser_policy: {mode: real_peak_preview, source_peak_required: true,
  preview_seconds_default: [0.4, 1.25], payoff_complete_runtime_fraction: [0.70, 0.85],
  payoff_hold_min_seconds: 1.0}
compliance_gates: {registry_ref, required_gate_refs: [claims_verification, banned_claim,
  honesty, rights_and_source_eligibility, campaign_and_platform], on_unresolved_hard_conflict:
  block_and_report}
taste_defaults: {rubric_ref: taste/1.0, minimum_score: 75, weights: {story_clarity: 25,
  source_fit: 20, restraint: 15, rhythm: 15, readability: 15, brand_fit: 10}}
brand: {approved_tokens_ref, hard_requirements, flexible_dimensions, prohibited_associations}
banned_patterns: [{id, match, severity: hard|review|preference, reason, fallback}]
cta_rules: {max_requests_per_clip: 1, allowed_actions, approved_destinations_ref,
  placement: after_primary_payoff, required_disclosures_ref,
  prohibit_withholding_promised_answer: true}
variety_budget: {axis_caps: {hook_family: 0.25, opening_beat: 0.25, pacing_curve: 0.30,
  graphic_archetype: 0.35, ending_treatment: 0.30, audio_strategy: 0.35},
  exact_signature_cap: 0.10, normalized_entropy_min: 0.70,
  allocation: {established_methods: 0.70, adjacent_variations: 0.20, new_method_candidates: 0.10}}
platform_targets: [{platform, placement, safe_area_ref, audio_delivery_ref,
  caption_delivery, analytics_mapping_ref}]
Every field carries enforcement: hard | floor | default. Missing facts stay missing.

B. SIGNAL SIDECAR SHAPE (§7.1) — one per source clip
=====================================================================
{clip_id, fps, frame_count, cpu_ms, degraded: [],
 words: [{id, text, start_frame, end_frame, logprob, uncertainty_frames, snap_ms}],
 vad: [{start_frame, end_frame, speech_prob}],
 breaths: [{start_frame, end_frame, confidence, followed_by_word_id}],
 music: {bpm, beat_confidence, downbeat_confidence, beat_frames[], downbeat_frames[],
   asset_time_offset_ms},
 envelopes: {hop_frames, speech_env[], music_env[], rms_norm[], overlap, separation_quality},
 motion: [{frame, mean, p95}],
 shots: [{id, in_frame, out_frame, boundary_conf, scale, face_height_ratio, gaze, complexity,
   text_density}],
 silence: [{class, start_frame, end_frame, db}]}
Signals below their gate are logged and ignored (confidence ladder §7.1). Never invent a
frame-accurate edge from a low-confidence timestamp.

C. RHYTHM REFERENCE TABLES (§7.2, at F=30)
=====================================================================
Shot lengths by energy (p10 / p50 / p90 seconds, hard min, hard max, shots per 15 s / 40 s):
- Low (luxury, testimony, quiet emotion): 1.0 / 2.2 / 4.0, min 0.70, max 6.0, 5–8 / 12–18
- Medium: 0.55 / 1.4 / 2.8, min 0.40, max 4.5, 8–12 / 18–28
- High (hype, action, music drive): 0.33 / 0.70 / 1.6, min 0.27, max 2.8, 12–18 / 28–45
CV bands: low 0.35–0.65, medium 0.40–0.75, high 0.45–0.85; CV < 0.25 fails.
High energy: ≤2 impact flashes of 4–6 f per spot; ≥1 shot ≥42 f per 8 s.
Shot-scale classes (advisory, by face_height/frame_height): ECU >0.40, CU 0.26–0.40,
MCU 0.16–0.26, MS 0.09–0.16, WS <0.09, no face → insert/wide. Simplified 3-class
alternative: close ≥0.22, medium 0.08–0.22, wide below.

D. FEEL SPEC SCHEMA (§7.6) — written before the first cut; ≤16 KB; 5–12 beats
=====================================================================
{clip_id, fps, dur_ms, lead: dialogue|action|music|hybrid, energy_profile, pace_template,
 music: {asset, offset_ms, bpm, grid_conf, downbeat_conf, sections: [{t_ms, type}]},
 beats: [{id, role: hook|setup|escalation|turn|payoff|button, start_ms, end_ms, energy,
   pace_class: hold|slow|medium|fast|burst, asl_ms: [min, max],
   anchor: {type: downbeat|grid_beat|word_onset|phrase_end|breath|action_apex|motion_settle|
     reveal|free, ref, frame, tol_f},
   emphasis: [{kind: punch_step|punch_push|caption_hl|sfx|dip, frame, params}],   // ≤1 per beat
   hold: {planned, min_ms, max_ms, why: "<signal-cited rationale, non-null>"},
   audio: {lead, split: none|J|L, split_f, sfx_budget, silence_ms, duck_db},
   caption: {density, hl_words[]}, conf}],
 budgets: {max_sfx, max_punch, max_convergence: 3, min_breaths_kept_ratio: 0.4},
 qc_actuals: {asl_ms, cv, longest_over_asl, anchor_hit_rate, late_window_hits, midword_cuts,
   half_breaths, jl_ratio, sfx_per_cut, punch_motivated, emotion_r, peak_err_ms, range,
   tells: [], flags: []}}
Filled from the RENDERED timeline after export; both plan and qc_actuals stored.

E. MOMENT-CLASS TAXONOMY (§10.1; durations include entrance+exit)
=====================================================================
Class | Communication purpose | Ideal duration | Preferred placement
HOOK hook title | establish the clip's question/tension/promised subject | 1.2–2.8 s | U/M field, opposite subject
CONTEXT context setter | explain what viewers are seeing before details arrive | 1.8–4.0 s | U, L, or side rail
STAT quantitative claim | make a sourced quantity/unit/result legible | 2.0–4.5 s | stable U/M near referent
STEP process/sequence | explain order, dependency, current operation | 1.2–2.8 s/step; 2.5–5.5 s diagram | side rail or U, away from hands
EMPHASIS semantic emphasis | direct attention to one supported word/phrase | 0.7–1.6 s | attached to caption/title geometry
CALLOUT referent annotation | identify a specific object/feature/component | 1.2–3.2 s | target-relative, label in nearby free space
COMPARE comparison | expose an actual difference between equivalents | 2.8–5.5 s | two aligned zones or one matrix
QUOTE attributed quotation | preserve a distinctive statement + speaker | 2.4–5.0 s | opposite speaker; U/L if face allows
STAMP location/time | establish where/when | 1.2–2.6 s | available corner or short rail
TRANSITION structural | explain a genuine chapter/state change | 0.2–0.6 s seam (+ reading time for any title) | along a verified cut boundary
IDENTITY person/product ID | resolve who / which version | 1.6–3.2 s | rail beside subject, not centered
CTA action instruction | one approved next action | 2.0–4.0 s (end-card gates govern) | endboard or action rail
Placement fields (U x72–1008 y144–560; M y560–1280; L y1280–1760; rails x72–360 / 720–1008)
are SEARCH REGIONS — intersect with live safe masks, caption reservations, subject protection.
High-risk classes (STAT/COMPARE/QUOTE/STAMP/IDENTITY) need p ≥0.98–0.995 or verified sources.

F. GRAPHIC CHOREOGRAPHY TABLE (§10.3, at 30 fps)
=====================================================================
Element class | Entrance | Exit | Stagger | Min readable hold
Hook/headline block | 6–10 f | 4–6 f | support +3–4 f | 30 f + reading math
Context/body block | 6–8 f | 4–6 f | label leads body +2–4 f | 42 f
Number + unit | 6–10 f | 4–6 f | unit ≤2 f after number | 45 f
Process nodes | 6–8 f/node | 4–6 f | 3–5 f (total ≤12 f) | 30 f per read step
Emphasis underline/bracket | 3–5 f | 2–4 f | none | 15 f
Leader callout | line 4–6 f, label 4–6 f | 3–4 f | label +2–4 f after line | 30 f
Comparison rows | 8–12 f/group | 4–6 f | 3–4 f/row | 60 f + reading math
Quote + attribution | 6–10 f | 4–6 f | attribution +3–4 f | 60 f + reading math
Location/time slug | 4–6 f | 3–4 f | ≤2 f | 30 f
Identity folio | 5–8 f | 3–4 f | role +2–3 f | 36 f
Transition geometry | 4–8 f/side | in seam | none | no text credit during seam
CTA/endboard | 8–12 f (system ≤16 f) | 0 at program end, else 4–6 f | 3–4 f | 60 f + decision time
Easing: entrance/settle cubic-bezier [0.22, 1, 0.36, 1]; exit [0.40, 0, 1, 1]; neutral
[0.40, 0, 0.20, 1]; linear only where constant progression has meaning. Solve Bx(u)=t then
evaluate By(u). Reading rates: label 3.5, headline 3.0, context/quote/identity/CTA 2.5,
comparison/technical 2.0 words/s. Hold floors: kinetic/shutter 14 f; ≤4-word badge/slate/
callout 30 f; stat/quote/versus 45 f.

G. STARTER ARCHETYPE LIBRARY (§10.6)
=====================================================================
Shared instance contract: archetype_id | moment_id | evidence_refs (1–16, resolve to approved
records) | start_frame | duration_frames (from reading time + footage) | bounds_px (solver-
generated, pass geometry gates) | alignment (auto|left|right|center) | density (low|medium|
high, grammar-restricted) | accent_role (none|rule|target|primary|selected_row) |
reduced_motion | params (archetype-specific). Materialize defaults before validation; local
frame 0 = archetype start; all *_ref fields resolve to approved evidence/copy/asset records —
never free-form generation slots.
- A01 Editorial margin headline — headline beside a structural rule; 2–6 words ≤2 lines;
  optional source-backed kicker; span 6–10 columns; the rule is alignment, not decoration.
  Fallback: static; omit if premise unsupported.
- A02 Scene-premise sidecar — category label + premise ≤8 words, rule-separated; side
  opposite the action; never obscure hands for a tidy rail. Fallback: one static line.
- A03 Calibrated marker ruler — axis, 2–5 ticks, one final-value marker, unit + scope;
  marker = (value−min)/(max−min) on a finite, sourced domain; never invent a domain;
  required scope qualifier must display. Fallback: plain value + unit.
- A04 Connected process rail — 2–4 nodes ≤3 words each on a path; no progress % or badge;
  highlight_current only with source-linked step timing. Fallback: static ordered diagram.
- A05 Semantic underline/bracket — attaches to measured word boxes of an existing caption/
  title; 1–3 target words; never estimate word positions from character counts.
- A06 Tracked elbow annotation — leader to a tracked target, one elbow, label ≤5 words;
  offset preference loses to endpoint identity; drop to a static label only if the referent
  is unambiguous. Fallback: static label.
- A07 Aligned comparison matrix — 2 labeled columns × 1–3 aligned rows, ≤12 words; validate
  comparability row by row; no winner decoration without a separate approved conclusion.
- A08 Attributed quote bracket — quote block + restrained mark + attached attribution ≤12
  quote words; attribution stays attached through the hold. Fallback: static exact quote.
- A09 Locator/time slug — compact rule-led location and/or time; ≥1 verified field;
  reformatted time preserves timezone + precision. Fallback: verified field only.
- A10 Cut-bridging chapter rail — rule traverses a REAL cut + verified topic/process change;
  label only with a sourced next-topic; bridges only that cut; no label → pre+post frames.
  Fallback: clean cut; omit label.
- A11 Identity folio — verified name/model + optional role/version in a stable rail, 3–6
  columns; role/version never inferred from appearance; not attached to facial motion.
  Fallback: static verified identity; omit unknown fields.
- A12 Product/action split endboard — protected product zone + action/destination zone; logo
  integrated; ONE action; destination only from approved records (never invent shortened
  URLs/handles); existing end-card gates are authoritative; if mandatory, escalate — never
  silently omit. Fallback: static approved endboard.
Instantiate only from a proposed moment of the mapped class; clamp params once, then
reduced-motion fallback or omit; route number claims / word clusters / progress / seals /
closing stamps to the five existing recipes (§17), never re-implemented here.

H. KEYFRAME LAYER JSON CONTRACT (§11)
=====================================================================
{schema_version: "peb-keyframe/1", fps: {num: 30, den: 1}, frame_count: N,
 canvas: {width: 1080, height: 1920}, working_space: "srgb_display_referred",
 output_alpha: "straight", asset_manifest_hash: "sha256:...",
 layers: [{id, kind: visual|audio, asset, start_frame, end_frame, pivot: [x, y],
   pan_mode: mono_equal_power|stereo_balance,
   tracks: {
     position: {bounds_policy: error|clamp, keyframes: [{time: {frame}|{ms}, value: [x, y],
       interpolation: {type: linear} | {type: cubic_bezier, x1, y1, x2, y2} |
         {type: smoothstep, degree: 3|5|7} | {type: damped_spring, mass, stiffness, damping,
         initial_velocity_per_s}}]},
     scale / rotation / opacity / crop / volume / pan: same keyframe structure with scalar
       or [x,y,w,h] values}}]}
Semantics: key times are absolute output times normalized to integer frames (half-up) before
evaluation — duplicates after rounding are validation errors; the ease on a key applies to
the interval ending at the NEXT key; before first / after last key, hold endpoint values;
[frame_N rendered? no — visibility is [start, end); a key may define the endpoint value of
frame N−1]; interpolate vector components with the same eased progress; ms audio keys map
directly to samples; visual ms → frames via floor(t×F/1000+0.5). Crop is in continuous
source-pixel coordinates inside the source rectangle. Rotation unwrapped, degrees clockwise
in a y-down canvas. Volume is linear gain (project ceiling 4 unless approved); pan −1..1
requires pan_mode. Reject visual properties on audio layers and vice versa; reject
non-finite numbers and end_frame ≤ start_frame. Springs: analytic under/critical/over-damped
solutions only; E(u) = s(uD)/s(D); endpoint-normalized; unsettled at segment end → logged
warning + snap at next key.

I. STABILIZATION PARAMETER TABLE + COMMANDS (§12)
=====================================================================
Shot class | Detect (shakiness/accuracy/stepsize) | Transform smoothing | maxshift | maxangle | zoom
Tripod micro-jitter | 3 / 12 / 6 | 15–30 | 12 | 0.005 (~0.29°) | 0–2%
Walking / handheld | 7 / 12 / 6 | 10–20 | 48 | 0.025 (~1.43°) | 2–6%
Whip-pan | skip by default (approved experiment: detect 4/12/4) | 2–4 | 12 | 0.005 | 0–2%
Strong parallax | skip or very mild (5/15/6) | 3–6 | 16 | 0.008 | 0–3%
ffmpeg -i shot.mkv -map 0:v:0 -an -vf "vidstabdetect=shakiness=7:accuracy=12:stepsize=6:\
result=shot.trf" -f null -
ffmpeg -i shot.mkv -map 0:v:0 -an -vf "vidstabtransform=input=shot.trf:smoothing=12:\
maxshift=48:maxangle=0.025:optzoom=0:zoom=4:crop=black:interpol=bicubic" -c:v ffv1 \
-level 3 -g 1 stabilized.mkv
Scale pixel-valued limits with the stabilization input dimensions. Validity plate: re-run
vidstabtransform on an all-white plate with the SAME saved transforms/params — black or
interpolated boundaries reveal invalid support. Area loss from zoom z: 1 − 1/(1+z/100)².
Deshake fallback (verify options locally): deshake=rx=16:ry=16:edge=blank. Crop-and-track
fallback: fixed-size crop following a σ≈8-frame smoothed trajectory; export crop matrices.

J. FINAL ENCODE PATTERN + FRAME-TRUTH FIXTURE (§16)
=====================================================================
Encode (canonical BT.709 RGB frames + exact-length PCM):
ffmpeg -framerate 30 -start_number 0 -i 'comp/%06d.png' -i mix.wav \
  -map 0:v:0 -map 1:a:0 \
  -vf "scale=w=iw:h=ih:in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p" \
  -c:v libx264 -preset medium -crf 18 -fps_mode:v passthrough \
  -color_primaries bt709 -color_trc bt709 -colorspace bt709 -color_range tv \
  -c:a aac -b:a 192k -ar 48000 -ac 2 -movflags +faststart final.mp4
Frame-truth fixture: 120 frames with large visible frame numbers + machine-readable B/W
frame-ID blocks (several redundant locations, including inside an opaque subject-shaped
region); known translation/rotation, a cut, duplicated frames, a retimed interval; oracle
mattes with known moving boundaries; a graphic on frames 37–60; a key authored at 1250 ms
(expected frame 38 at 30 fps, half-up); audio correlation markers at sample indices matching
frames 37, 61, 100. Probe: ffprobe -v error -select_streams v:0 -show_frames -show_entries
frame=pts,best_effort_timestamp -of json final.mp4 (read the stream time base separately;
judge PTS, not packet order — B-frames reorder decode). Acceptance: count exactly 120;
PTS×tb = n/30 ∀n; source selection matches the map; overlay on 37–60 only; matte/RGB
registration zero offset; pre-AAC markers ≤1 sample; final AAC ≤1 ms, no accumulating drift;
priming/tail padding measured and recorded.

K. CAPABILITY QC GATE TABLES (§18)
=====================================================================
Keyframes: round-trip serialize/reload/independent-evaluate error ≤1e-6 (scalar), ≤0.01 px
(position/crop); fiducial rectangle corners/pivot recovered ≤0.5 px / 0.1° / 0.1%; endpoint
behavior exact (no accidental endpoint frame); overshoot evaluated on ALL frames + audio
samples against bounds_policy; visibility intervals zero off-by-one on decoded fixtures;
baked PCM vs independent gain/pan computation ≤1e-6 (reference float), sample count exact.
Stabilization: ≥30 background tracks spanning ≥6 of 9 grid cells, ≥70% inliers (else
not_checked); residual HF RMS ≤2 px tripod / ≤4 px walking, ≥40% reduction when input >3 px;
edge wobble p95 ≤3 px, ≤0.5 px worse than input; row-binned jello RMSE ≤2.5 px, increase
≤0.5 px; crop ≤8% pass / 8–12% warn / >12% fail (per-edge ≤4%; walking may reach 20%/6% only
with approval); validity plate zero invalid pixels +2 px margin; drift p95 ≤2% per dimension,
peak ≤4%; subject bbox inside [6%,94%]×[8%,88%]; critical composition never clipped.
Segmentation: alpha numeric (exact dims/count, finite 0–1, no gamma on masks); temporal
boundary flicker p95 ≤0.08, max ≤0.15 (5 px bands around current + warped-previous 0.5
contours); interior instability mean ≤0.01 (8 px eroded); matte breathing p95 ≤3%, no
unexplained single-frame jump >10%; halo ≤2 px over >10% of contour; coverage ≥60% of
boundary with valid correspondence else not_checked; reference masks (if annotated) opaque
IoU ≥0.97, boundary F1 ≥0.90 at 3 px.
Compositing: alpha oracle within ±2 code values (±1 reference path); transparent-RGB hygiene
(RGB=0 where α=0); original reconstruction ≤2/255/channel; depth-order proof (subject wins
α≥0.98, graphic visible α≤0.02, error ≤2/255); contact-shadow attachment ≤5 px / direction
≤15°; reflection none above plane; grade match median ΔE00 ≤3, p95 ≤6 — never from arbitrary
averages. Evidence for every pass; not_checked when measurement did not occur; never relax
thresholds automatically — record calibrated exceptions and their approval.

L. FAILURE DISCLOSURE TEMPLATES (§20) — replace bracketed fields with measured facts
=====================================================================
Keyframes — best: "Keyframes: rendered from the approved animation specification; numerical,
visual-timing, and audio-automation checks passed."
Keyframes — acceptable: "Keyframes: [feature] was replaced with [replacement] because
[reason]. Timing checks passed. Plan change approved under [approval ID]."
Keyframes — minimal: "Keyframes: continuous animation reduced to [static poses/cuts/fades].
The requested motion is not present. Plan change approved under [approval ID]."
Keyframes — skip: "Keyframes: not applied because [reason]. Requested animated elements were
[removed/replaced]. [Approval statement or delivery blocked]."
Stabilization — best: "Stabilization: applied with [engine]; incremental crop loss [value]%.
Motion, border, and composition checks passed."
Stabilization — acceptable: "Stabilization: limited [deshake/translation tracking] used.
Rotation, parallax, and rolling-shutter correction are not claimed. Plan change approved
under [approval ID]."
Stabilization — minimal: "Stabilization: no motion correction; fixed reframe only. Handheld
movement remains. Plan change approved under [approval ID]."
Stabilization — skip: "Stabilization: skipped because [reason]. Shot [retained as handheld/
replaced]. [Approval statement or delivery blocked]."
Background removal — best: "Background removal: applied with [model/export]; sampled edge
and temporal-consistency checks passed."
Background removal — acceptable: "Background removal: [reduced-resolution/propagated] mattes
rather than the requested method. Edge and temporal checks passed. Plan change approved
under [approval ID]."
Background removal — minimal: "Background removal: limited to [still/freeze-frame range].
Continuous moving-subject extraction is not present. Plan change approved under [approval
ID]."
Background removal — skip: "Background removal: not applied because [reason]. Original
background retained; behind-subject effects [removed/replanned]. [Approval statement or
delivery blocked]."
Compositing — best: "Compositing: graphics occluded by verified subject mattes; depth-order
and applicable grounding/color checks passed."
Compositing — acceptable: "Compositing: [shadow/reflection/lighting/depth feature] omitted or
simplified because [reason]. Plan change approved under [approval ID]."
Compositing — minimal: "Compositing: graphics moved to [placement]; they are not behind the
subject. Plan change approved under [approval ID]."
Compositing — skip: "Compositing: requested layered effect not applied because [reason].
[Replacement treatment]. [Approval statement or delivery blocked]."
