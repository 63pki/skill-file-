# OPERATOR INPUT — CONSOLIDATED HANDOFF (verbatim resupply, 2026-10-28)

> PERSISTENCE RECORD: saved verbatim from the operator's IM resupply message of 2026-10-28
> after the original in-session delivery failed to persist (input-persistence failure, corrected
> per operator instruction). This file is the verbatim original; see NORMALIZED_INVENTORY.md
> and RECEIPT.md for parsed views and hashes. No wording, order, or content is modified here.
> Transit artifacts preserved as received (e.g., the flattened category paragraph in the Verdict
> section is reproduced as supplied; the reconstructed 8-category table lives only in the
> normalized inventory).

---

## Verdict

My earlier filtering was too restrictive. A useful editing skill can live inside an application repository, and web/UI animation skills can support professional video production.

The correct approach is to distinguish:CategoryHow the agent should use itEditing workflow skillGuide source inspection, story selection, timeline decisions and revisionsMotion/design specialistSolve a selected visual communication problemTechnical renderer skillImplement compositions, timing, captions and exportsApp-dependent skillUse only when that application's actual tools are availableAnalysis/transcript supportAssist understanding—not substitute for audiovisual reviewLibrary/dependencySupply technical capabilities through a tested adapterStarter/reference projectStudy implementation; do not present it as an installed skillHosted/generated-media workflowRequire provider, privacy, cost and campaign authorization

## What was checked

- 60 repository records: 58 unique repositories from your links, plus two follow-up sources.
- 145 successful candidate/README document fetches, plus selected helper scripts, licenses and engine documentation.
- Repository trees were inspected where accessible; five requests were rate-limited.
- Large catalogs were searched and sampled—not audited exhaustively.
- No repository installation, execution, render, paid API call, private-media upload or publishing was performed.

These are researched candidates, not runtime-tested or security-certified integrations. GitHub HEAD links can change; pin a reviewed revision before adoption.

## Priority candidates

| Candidate | Best use | Qualification |
|---|---|---|
| browser-use/video-use | Existing-footage editing, transcript-driven decisions, EDL and project persistence | Adapt provider assumptions, mandatory delegation, fades and encoding claims |
| Creatorberry/flick | Transcript-to-Remotion animation and reusable motion B-roll | Supporting animation workflow—not automatic story selection |
| Pluviobyte/video-production-skills | Motion direction, visual metaphors and reference-based QC | Select relevant skills; do not make motion-first mandatory |
| Leonxlnx/cinetic | Concept, branding, timeline, UI motion and finishing | Large, opinionated workflow; load selectively |
| AbubakrChan/product-launch-motion | Deliberate product-specific motion films | Current and legacy routes differ; do not mix them blindly |
| nilbuild/video-demo | Web-product capture and intentional demonstration | Distinguish live product capture from mocked fixtures |
| 1weiho/cinematic-shot | Motivated UI camera and lighting treatments | Specialist aesthetic—not a universal editing style |

These supplement—not automatically replace—Herk's short-form workflow, Barty-Bart's motion B-roll and official Remotion/HyperFrames guidance.

## Important corrections to earlier exclusions

- OpenMontage: restore selected video-edit, video-understand and FFmpeg skills. Other routes have separate service dependencies.
- OpenChatCut, FableCut and FireRed: contain genuine skills, but their application-specific tools must exist before their instructions can be executed.
- Diffusion Studio: keep its editor/watch guidance as app-dependent instructions, not a portable renderer.
- VideoCaptioner: has an actual CLI skill. It should not be rejected merely because it also has an application interface.
- Web/UI animation: keep relevant skills and dependencies, but require deterministic, seekable video rendering rather than relying on scrolling, hover or wall-clock timing.

## Restrictions that matter before adoption

browser-use/video-use needs adaptation. Its instructions assume ElevenLabs/Scribe, mandate parallel subagents and prescribe fades at every segment boundary. Those cannot override campaign permissions, available tools or actual speech boundaries. Its encoding guidance also should not become a universal rule: a correctly constructed single-pass FFmpeg filtergraph does not inherently double-encode segments.

Onetake is on hold for paid campaign use. Its inspected license declares PolyForm Noncommercial; obtain suitable permission or licensing before commercial adoption.

Guizang requires separate code/asset review. Its skill declares AGPL code and BUSL-labeled fallback assets. Do not assume either unrestricted commercial reuse or that every rendered video automatically inherits the software's license.

VOX-COLLAGE-BROLL is provider-dependent, not a local effects pack: its execution route requires authenticated MaxFusion MCP and a prescribed generation model.

Product Launch Motion has distinct routes. The current root skill uses HTML seek(t) with music-first/one-shape direction; the legacy route uses narration, GSAP and HyperFrames. Select a route rather than importing both sets of assumptions.

## Analysis and transcript support

Keep these as support—not substitutes for listening, motion review or claim verification:

- bsisduck/video-analyzer-skill: frame/scene analysis with optional transcription.
- video-content-extractor: frame/OCR extraction; its default sampling interval needs adjustment for short clips. The supporting script is at repository-root scripts/extract_video.py.
- baoyu-youtube-transcript: transcript/subtitle retrieval; availability and usage rights remain separate questions.
- michaelgold/videoskill: structured extraction from narrated video—not a finishing editor.
- minimax-h3-video-reverse: reference interpretation and prompt packaging—not a generator or recovery of a hidden original prompt.

## Starter projects worth retaining

ClaudeAnimationBase: useful p5/p5.brush animation guide and renderer reference. Its character-specific styling and browser flags are not campaign-wide defaults.

pdoom-video: useful deterministic Three.js, typography and frame-rendering reference. Its README states the song is not theirs; the code license does not grant soundtrack rights.

## Duplicate resolution

- Repeated video-use and videoskill URLs → one source each.
- NanoSkill's video-editing listing → browser-use/video-use.
- NanoSkill's YouTube transcript listing → Baoyu's transcript skill.
- Remotion's skills documentation → existing official Remotion skill source.
- MCP Market's workflow listing → affaan-m/ecc.
- Agentic Awesome's video-content-extractor entry → prefer canonical upstream plus its required script.
- .agents, .claude and plugin copies are not automatically separate capabilities.

## Recommended adoption plan

Do not install everything or concatenate these skills into the master prompt.

For each project:

1. Identify the actual task: footage recut, product capture, motion graphics, animation, generated media or analysis.
2. Load one primary workflow and the necessary specialist guidance.
3. Choose one primary compositor.
4. Check exact version, license, dependencies, media privacy and costs.
5. Test a small fixture.
6. Produce one representative pilot.
7. Keep campaign instructions above skill defaults.
8. Report technical, campaign, creative and performance status separately.

---

## 2. SHORTLIST_DIRECT_SKILL_LINKS.txt

20 direct skill links. These are candidates for selective adoption—not pre-approved installations.

https://github.com/browser-use/video-use/blob/HEAD/SKILL.md
https://github.com/Creatorberry/flick/blob/HEAD/skills/flick/SKILL.md
https://github.com/Pluviobyte/video-production-skills/blob/HEAD/ai-motion-director/SKILL.md
https://github.com/Pluviobyte/video-production-skills/blob/HEAD/reference-video-replica-qc/SKILL.md
https://github.com/Leonxlnx/cinetic/blob/HEAD/skills/cinetic/SKILL.md
https://github.com/AbubakrChan/product-launch-motion/blob/HEAD/SKILL.md
https://github.com/1weiho/cinematic-shot/blob/HEAD/skills/cinematic-shot/SKILL.md
https://github.com/nilbuild/video-demo/blob/HEAD/SKILL.md
https://github.com/calesthio/OpenMontage/blob/HEAD/.agents/skills/video-edit/SKILL.md
https://github.com/calesthio/OpenMontage/blob/HEAD/.agents/skills/video-understand/SKILL.md
https://github.com/calesthio/OpenMontage/blob/HEAD/.agents/skills/ffmpeg/SKILL.md
https://github.com/bsisduck/video-analyzer-skill/blob/HEAD/SKILL.md
https://github.com/274326424/video-content-extractor/blob/HEAD/skills/video-content-extractor/SKILL.md
https://github.com/JimLiu/baoyu-skills/blob/HEAD/skills/baoyu-youtube-transcript/SKILL.md
https://github.com/nexu-io/open-design/blob/HEAD/skills/motion-design/SKILL.md
https://github.com/nexu-io/open-design/blob/HEAD/plugins/_official/video-templates/frame-liquid-bg-hero/SKILL.md
https://github.com/nateherkai/herk-edit-kit/blob/HEAD/.agents/skills/short-form-edit/SKILL.md
https://github.com/barty-bart/motion-graphics/blob/HEAD/skills/motion-broll/SKILL.md
https://github.com/remotion-dev/remotion/blob/HEAD/packages/skills/skills/remotion-best-practices/SKILL.md
https://github.com/6missedcalls/video-editing-skill/blob/HEAD/SKILL.md

## 3. CONDITIONAL_DIRECT_SKILL_LINKS.txt

26 direct links. "Conditional" means app, provider, licensing, specialist-format or workflow adaptation is required—not that the skill is necessarily poor.

https://github.com/diffusionstudio/skills/blob/HEAD/skills/editor/SKILL.md
https://github.com/diffusionstudio/skills/blob/HEAD/skills/watch/SKILL.md
https://github.com/0xsline/OpenChatCut/blob/HEAD/src/agent/skills/product-ad-video-script/SKILL.md
https://github.com/0xsline/OpenChatCut/blob/HEAD/src/agent/skills/storyboard-shot-breakdown/SKILL.md
https://github.com/0xsline/OpenChatCut/blob/HEAD/src/agent/skills/create-motion-graphics/SKILL.md
https://github.com/0xsline/OpenChatCut/blob/HEAD/src/agent/skills/verification/SKILL.md
https://github.com/ronak-create/FableCut/blob/HEAD/skills/edit-video/SKILL.md
https://github.com/ronak-create/FableCut/blob/HEAD/skills/motion-graphics/SKILL.md
https://github.com/ronak-create/FableCut/blob/HEAD/skills/remake-reel/SKILL.md
https://github.com/FireRedTeam/FireRed-OpenStoryline/blob/HEAD/.storyline/skills/speech_rough_cut_skill/SKILL.md
https://github.com/mutonby/openshorts/blob/HEAD/skills/openshorts/SKILL.md
https://github.com/hypit-ai/hypit/blob/HEAD/skills/hypit/SKILL.md
https://github.com/WEIFENG2333/VideoCaptioner/blob/HEAD/skills/SKILL.md
https://github.com/op7418/guizang-product-video-skill/blob/HEAD/SKILL.md
https://github.com/MegaTroll222/VOX-COLLAGE-BROLL/blob/HEAD/SKILL.md
https://github.com/gnipbao/codex-whiteboard-video-skill/blob/HEAD/SKILL.md
https://github.com/Jackywxsz/Jacky-motion/blob/HEAD/SKILL.md
https://github.com/alchaincyf/huashu-art-motion/blob/HEAD/SKILL.md
https://github.com/gnipbao/minimax-h3-video-reverse-skill/blob/HEAD/SKILL.md
https://github.com/eternityspring/shuohao-skills/blob/HEAD/skills/novel-storyboard/SKILL.md
https://github.com/s1dashu/director/blob/HEAD/SKILL.md
https://github.com/michaelgold/videoskill/blob/HEAD/SKILL.md
https://github.com/huangbai-AI/one-prompt-video-skills/blob/HEAD/opus-code-animation/SKILL.md
https://github.com/browser-use/browser-use/blob/HEAD/skills/browser-use/SKILL.md
https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/plugins/agentic-awesome-skills/skills/video-router/SKILL.md
https://github.com/sickn33/agentic-awesome-skills/blob/HEAD/plugins/agentic-awesome-skills/skills/pro-motion/SKILL.md

Onetake is intentionally outside these adoption lists pending commercial-license clearance.

## 4. ALL_REPOSITORIES_DEDUPLICATED.txt

Complete inventory: 60 repositories. This is an inventory, not an installation list.

https://github.com/liabru/matter-js
https://github.com/acamposuribe/p5.brush
https://github.com/greensock/GSAP
https://github.com/danielwh2/cube-motion
https://github.com/oil-oil/oil-motion
https://github.com/shadcn-labs/shadercn
https://github.com/lucasmarkes/hairline
https://github.com/remotion-dev/remotion
https://github.com/radiumcoders/evil-buttons
https://github.com/barty-bart/motion-graphics
https://github.com/lemomo-ai/lemo-opuscar
https://github.com/calesthio/OpenMontage
https://github.com/heygen-com/hyperframes
https://github.com/diffusionstudio/editor
https://github.com/matteoikarieth96/whiteboard-video-skill
https://github.com/mltframework/shotcut
https://github.com/motion-canvas/motion-canvas
https://github.com/3b1b/manim
https://github.com/0xsline/OpenChatCut
https://github.com/nicolaigaina/ai-video-captions
https://github.com/nateherkai/herk-edit-kit
https://github.com/edenfunf/reelmimic
https://github.com/hypit-ai/hypit
https://github.com/ronak-create/FableCut
https://github.com/FireRedTeam/FireRed-OpenStoryline
https://github.com/itsjwill/vanta
https://github.com/storytold/effectcraft
https://github.com/mutonby/openshorts
https://github.com/PhiloLabs/awesome-video-agents
https://github.com/yihui-dev/awesome-opus5-5-videos
https://github.com/Pluviobyte/video-production-skills
https://github.com/diffusionstudio/skills
https://github.com/eternityspring/shuohao-skills
https://github.com/gnipbao/codex-whiteboard-video-skill
https://github.com/s1dashu/director
https://github.com/nilbuild/video-demo
https://github.com/op7418/guizang-product-video-skill
https://github.com/Jackywxsz/Jacky-motion
https://github.com/huangbai-AI/one-prompt-video-skills
https://github.com/Leonxlnx/cinetic
https://github.com/gnipbao/minimax-h3-video-reverse-skill
https://github.com/1weiho/cinematic-shot
https://github.com/alchaincyf/huashu-art-motion
https://github.com/Creatorberry/flick
https://github.com/feitangyuan/onetake
https://github.com/MegaTroll222/VOX-COLLAGE-BROLL
https://github.com/michaelgold/videoskill
https://github.com/274326424/video-content-extractor
https://github.com/nexu-io/open-design
https://github.com/sickn33/agentic-awesome-skills
https://github.com/6missedcalls/video-editing-skill
https://github.com/browser-use/video-use
https://github.com/JohnHeibel/ClaudeAnimationBase
https://github.com/JimLiu/baoyu-skills
https://github.com/WEIFENG2333/VideoCaptioner
https://github.com/bsisduck/video-analyzer-skill
https://github.com/AbubakrChan/product-launch-motion
https://github.com/mexicat/pdoom-video
https://github.com/affaan-m/ecc
https://github.com/browser-use/browser-use

Bottom line: retain this as a searchable resource catalog. The editing agent should load the skills needed for the approved creative treatment—not attempt to use the entire collection.
