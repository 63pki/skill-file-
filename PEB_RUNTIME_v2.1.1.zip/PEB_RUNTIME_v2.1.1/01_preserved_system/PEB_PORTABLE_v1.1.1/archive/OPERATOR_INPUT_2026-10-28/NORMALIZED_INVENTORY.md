# NORMALIZED INVENTORY — operator resupply (parsed view; the verbatim original is untouched)

Source: CONSOLIDATED_HANDOFF_VERBATIM.md (same directory). Parsed 2026-10-27.

## Reconstructed usage-category table (flattened in transit; reconstructed from the verbatim string)

| Category | How the agent should use it |
|---|---|
| Editing workflow skill | Guide source inspection, story selection, timeline decisions and revisions |
| Motion/design specialist | Solve a selected visual communication problem |
| Technical renderer skill | Implement compositions, timing, captions and exports |
| App-dependent skill | Use only when that application's actual tools are available |
| Analysis/transcript support | Assist understanding—not substitute for audiovisual review |
| Library/dependency | Supply technical capabilities through a tested adapter |
| Starter/reference project | Study implementation; do not present it as an installed skill |
| Hosted/generated-media workflow | Require provider, privacy, cost and campaign authorization |

## A. Repository inventory (60)

| # | owner/repo | direct links |
|---|---|---|
| 1 | liabru/matter-js | — |
| 2 | acamposuribe/p5.brush | — |
| 3 | greensock/GSAP | — |
| 4 | danielwh2/cube-motion | — |
| 5 | oil-oil/oil-motion | — |
| 6 | shadcn-labs/shadercn | — |
| 7 | lucasmarkes/hairline | — |
| 8 | remotion-dev/remotion | 1 |
| 9 | radiumcoders/evil-buttons | — |
| 10 | barty-bart/motion-graphics | 1 |
| 11 | lemomo-ai/lemo-opuscar | — |
| 12 | calesthio/OpenMontage | 3 |
| 13 | heygen-com/hyperframes | — |
| 14 | diffusionstudio/editor | — |
| 15 | matteoikarieth96/whiteboard-video-skill | — |
| 16 | mltframework/shotcut | — |
| 17 | motion-canvas/motion-canvas | — |
| 18 | 3b1b/manim | — |
| 19 | 0xsline/OpenChatCut | 4 |
| 20 | nicolaigaina/ai-video-captions | — |
| 21 | nateherkai/herk-edit-kit | 1 |
| 22 | edenfunf/reelmimic | — |
| 23 | hypit-ai/hypit | 1 |
| 24 | ronak-create/FableCut | 3 |
| 25 | FireRedTeam/FireRed-OpenStoryline | 1 |
| 26 | itsjwill/vanta | — |
| 27 | storytold/effectcraft | — |
| 28 | mutonby/openshorts | 1 |
| 29 | PhiloLabs/awesome-video-agents | — |
| 30 | yihui-dev/awesome-opus5-5-videos | — |
| 31 | Pluviobyte/video-production-skills | 2 |
| 32 | diffusionstudio/skills | 2 |
| 33 | eternityspring/shuohao-skills | 1 |
| 34 | gnipbao/codex-whiteboard-video-skill | 1 |
| 35 | s1dashu/director | 1 |
| 36 | nilbuild/video-demo | 1 |
| 37 | op7418/guizang-product-video-skill | 1 |
| 38 | Jackywxsz/Jacky-motion | 1 |
| 39 | huangbai-AI/one-prompt-video-skills | 1 |
| 40 | Leonxlnx/cinetic | 1 |
| 41 | gnipbao/minimax-h3-video-reverse-skill | 1 |
| 42 | 1weiho/cinematic-shot | 1 |
| 43 | alchaincyf/huashu-art-motion | 1 |
| 44 | Creatorberry/flick | 1 |
| 45 | feitangyuan/onetake | — |
| 46 | MegaTroll222/VOX-COLLAGE-BROLL | 1 |
| 47 | michaelgold/videoskill | 1 |
| 48 | 274326424/video-content-extractor | 1 |
| 49 | nexu-io/open-design | 2 |
| 50 | sickn33/agentic-awesome-skills | 2 |
| 51 | 6missedcalls/video-editing-skill | 1 |
| 52 | browser-use/video-use | 1 |
| 53 | JohnHeibel/ClaudeAnimationBase | — |
| 54 | JimLiu/baoyu-skills | 1 |
| 55 | WEIFENG2333/VideoCaptioner | 1 |
| 56 | bsisduck/video-analyzer-skill | 1 |
| 57 | AbubakrChan/product-launch-motion | 1 |
| 58 | mexicat/pdoom-video | — |
| 59 | affaan-m/ecc | — |
| 60 | browser-use/browser-use | 1 |

## B. Shortlist direct skill links (20)

| # | owner/repo | ref | path |
|---|---|---|---|
| 1 | browser-use/video-use | HEAD | /SKILL.md |
| 2 | Creatorberry/flick | HEAD | /skills/flick/SKILL.md |
| 3 | Pluviobyte/video-production-skills | HEAD | /ai-motion-director/SKILL.md |
| 4 | Pluviobyte/video-production-skills | HEAD | /reference-video-replica-qc/SKILL.md |
| 5 | Leonxlnx/cinetic | HEAD | /skills/cinetic/SKILL.md |
| 6 | AbubakrChan/product-launch-motion | HEAD | /SKILL.md |
| 7 | 1weiho/cinematic-shot | HEAD | /skills/cinematic-shot/SKILL.md |
| 8 | nilbuild/video-demo | HEAD | /SKILL.md |
| 9 | calesthio/OpenMontage | HEAD | /.agents/skills/video-edit/SKILL.md |
| 10 | calesthio/OpenMontage | HEAD | /.agents/skills/video-understand/SKILL.md |
| 11 | calesthio/OpenMontage | HEAD | /.agents/skills/ffmpeg/SKILL.md |
| 12 | bsisduck/video-analyzer-skill | HEAD | /SKILL.md |
| 13 | 274326424/video-content-extractor | HEAD | /skills/video-content-extractor/SKILL.md |
| 14 | JimLiu/baoyu-skills | HEAD | /skills/baoyu-youtube-transcript/SKILL.md |
| 15 | nexu-io/open-design | HEAD | /skills/motion-design/SKILL.md |
| 16 | nexu-io/open-design | HEAD | /plugins/_official/video-templates/frame-liquid-bg-hero/SKILL.md |
| 17 | nateherkai/herk-edit-kit | HEAD | /.agents/skills/short-form-edit/SKILL.md |
| 18 | barty-bart/motion-graphics | HEAD | /skills/motion-broll/SKILL.md |
| 19 | remotion-dev/remotion | HEAD | /packages/skills/skills/remotion-best-practices/SKILL.md |
| 20 | 6missedcalls/video-editing-skill | HEAD | /SKILL.md |

## C. Conditional direct skill links (26)

| # | owner/repo | ref | path |
|---|---|---|---|
| 1 | diffusionstudio/skills | HEAD | /skills/editor/SKILL.md |
| 2 | diffusionstudio/skills | HEAD | /skills/watch/SKILL.md |
| 3 | 0xsline/OpenChatCut | HEAD | /src/agent/skills/product-ad-video-script/SKILL.md |
| 4 | 0xsline/OpenChatCut | HEAD | /src/agent/skills/storyboard-shot-breakdown/SKILL.md |
| 5 | 0xsline/OpenChatCut | HEAD | /src/agent/skills/create-motion-graphics/SKILL.md |
| 6 | 0xsline/OpenChatCut | HEAD | /src/agent/skills/verification/SKILL.md |
| 7 | ronak-create/FableCut | HEAD | /skills/edit-video/SKILL.md |
| 8 | ronak-create/FableCut | HEAD | /skills/motion-graphics/SKILL.md |
| 9 | ronak-create/FableCut | HEAD | /skills/remake-reel/SKILL.md |
| 10 | FireRedTeam/FireRed-OpenStoryline | HEAD | /.storyline/skills/speech_rough_cut_skill/SKILL.md |
| 11 | mutonby/openshorts | HEAD | /skills/openshorts/SKILL.md |
| 12 | hypit-ai/hypit | HEAD | /skills/hypit/SKILL.md |
| 13 | WEIFENG2333/VideoCaptioner | HEAD | /skills/SKILL.md |
| 14 | op7418/guizang-product-video-skill | HEAD | /SKILL.md |
| 15 | MegaTroll222/VOX-COLLAGE-BROLL | HEAD | /SKILL.md |
| 16 | gnipbao/codex-whiteboard-video-skill | HEAD | /SKILL.md |
| 17 | Jackywxsz/Jacky-motion | HEAD | /SKILL.md |
| 18 | alchaincyf/huashu-art-motion | HEAD | /SKILL.md |
| 19 | gnipbao/minimax-h3-video-reverse-skill | HEAD | /SKILL.md |
| 20 | eternityspring/shuohao-skills | HEAD | /skills/novel-storyboard/SKILL.md |
| 21 | s1dashu/director | HEAD | /SKILL.md |
| 22 | michaelgold/videoskill | HEAD | /SKILL.md |
| 23 | huangbai-AI/one-prompt-video-skills | HEAD | /opus-code-animation/SKILL.md |
| 24 | browser-use/browser-use | HEAD | /skills/browser-use/SKILL.md |
| 25 | sickn33/agentic-awesome-skills | HEAD | /plugins/agentic-awesome-skills/skills/video-router/SKILL.md |
| 26 | sickn33/agentic-awesome-skills | HEAD | /plugins/agentic-awesome-skills/skills/pro-motion/SKILL.md |
