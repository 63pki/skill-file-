# COVERAGE RECONCILIATION — v2.0 (complete, 2026-10-28)

**Scope:** reconciliation only. No installs, no adapters, no rendering, no master-prompt changes, no registry changes applied. Registry changes are PROPOSED in §8 and stop for approval.

**Prior work status:** v1.0 of this reconciliation recovered a 42-resource subset from persisted artifacts and flagged the input-persistence failure. The operator resupplied the complete audit + lists in-message on 2026-10-28. That resupply is now persisted and verified. This v2.0 supersedes v1.0's coverage tables; v1.0's §2 A–E rows remain valid prior work and are folded in, not duplicated verbatim.

---

## 1. INPUT RECEIPT / PERSISTENCE VERIFICATION (Task 1)

**Status: VERIFIED ON DISK.** Not a worklog claim — files exist and were hashed after writing:

| File (under `download/OPERATOR_INPUT_2026-10-28/`) | Bytes | SHA-256 (prefix) |
|---|---|---|
| CONSOLIDATED_HANDOFF_VERBATIM.md | 13,289 | full hash in RECEIPT.md |
| SHORTLIST_DIRECT_SKILL_LINKS.txt | 20 URLs, verbatim lines | in RECEIPT.md |
| CONDITIONAL_DIRECT_SKILL_LINKS.txt | 26 URLs, verbatim lines | in RECEIPT.md |
| ALL_REPOSITORIES_DEDUPLICATED.txt | 60 URLs, verbatim lines | in RECEIPT.md |
| NORMALIZED_INVENTORY.md | parsed view (verbatim original untouched) | — |
| RECEIPT.md | hashes + verification flags | — |

**Count verification (script `scripts/verify_operator_input_v1.py`, output saved):**
- Shortlist links parsed: **20 / expected 20** ✓
- Conditional links parsed: **26 / expected 26** ✓
- Repository URLs parsed: **60 / expected 60** ✓ — all unique at owner/repo level; all root-format
- Every link URL ends in `/SKILL.md` ✓; every link's repository **is present in the 60** ✓ (no orphan links)
- 35 of 60 repositories carry direct links; 25 do not (full list in §4); 46 links resolve across 35 repos with these multi-link groupings: OpenChatCut ×4 · FableCut ×3 · OpenMontage ×3 · Pluviobyte ×2 · open-design ×2 · diffusionstudio/skills ×2 · agentic-awesome-skills ×2
- All six previously-missing candidates confirmed present in the 60 ✓

**Parsing problems / transit artifacts (logged, none blocking):**
1. The audit's usage-category table arrived flattened into one string (markdown lost in transit). Preserved as-is in the verbatim file; reconstructed as a table only in NORMALIZED_INVENTORY.md. The 8 categories are: Editing workflow skill · Motion/design specialist · Technical renderer skill · App-dependent skill · Analysis/transcript support · Library/dependency · Starter/reference project · Hosted/generated-media workflow. This taxonomy is **adopted** into the registry's usage-model column (it supersedes the earlier 8-category set only in wording; content matches).
2. Zero-width/formatting characters from IM transit are not byte-reproducible; the saved file is a faithful readable transcription. Counts and URLs are unaffected.
3. The audit self-reports "58 unique repositories from your links, plus two follow-up sources." Which two of the 60 came from follow-up sources is not identifiable from the supply — immaterial to coverage.
4. Onetake appears in the 60 but intentionally not in either adoption list (its own note) — consistent, recorded as rights-blocked.

**Process fix applied per operator ruling (input-persistence failure = architect defect, not operator omission):** from now on, every operator-supplied inventory is written verbatim to `download/OPERATOR_INPUT_<date>/` with hashes at receipt, BEFORE any processing. This session's files are the first instance.

---

## 2. THE SIX PREVIOUSLY-MISSING CANDIDATES (first, per instruction)

All six: **architect inspection = not performed** (no SKILL.md fetched by me); evidence = operator audit findings (145 fetches reported) + this handoff. All six therefore land as **readable-reference candidates with conditions**, not numbered cards. Licensing is unverified for all six → REFERENCE-ONLY under registry §6.

| # | Repository | Links | Disposition | Conditions & unresolved issues |
|---|---|---|---|---|
| 1 | **Leonxlnx/cinetic** | shortlist `skills/cinetic/SKILL.md` | Reference (catalog), selective-load trigger | Audit: concept, branding, timeline, UI motion, finishing; "large, opinionated workflow; load selectively." Unresolved: license; which sub-sections are load-worthy; overlap with SR-10/SR-11 craft. Would change: SKILL.md read + license → could become a numbered craft card or a scoped ADAPT |
| 2 | **AbubakrChan/product-launch-motion** | shortlist root `SKILL.md` | Reference (catalog), ROUTE-SELECTION required | Audit: two routes — root skill = HTML `seek(t)` + music-first/one-shape direction; legacy route = narration + GSAP + HyperFrames. **Conflict map:** root route's music-first lane collides with original-audio-only (provenance gate); legacy route's HyperFrames reference aligns with T3 but GSAP-inside-T3 determinism is UNVERIFIED (adapter does not exist; inventory row 11 contract would govern). Do not import both sets of assumptions (audit's own rule). Unresolved: license; per-route file layout |
| 3 | **nilbuild/video-demo** | shortlist root `SKILL.md` | Reference (catalog), capture-vs-fixture distinction mandatory | Audit: web-product capture and intentional demonstration; distinguish live product capture from mocked fixtures. **Environment note:** no screen/application capture capability is verified in this chain — campaigns run on operator-supplied footage; the skill's capture instructions cannot execute here. Craft value = intentional-demonstration structure (what to show, in what order, what proves the claim). Unresolved: license |
| 4 | **1weiho/cinematic-shot** | shortlist `skills/cinematic-shot/SKILL.md` | Reference (catalog), specialist-not-universal | Audit: motivated UI camera and lighting treatments; "specialist aesthetic—not a universal editing style." Applies to rendered camera moves over UI/product footage (T3-adjacent), not to documentary-style handling of supplied footage. Unresolved: license |
| 5 | **barty-bart/motion-graphics** | shortlist `skills/motion-broll/SKILL.md` | Reference (catalog), ADAPT-CANDIDATE | Audit names it baseline: "Barty-Bart's motion B-roll" supplements the craft set. Motion B-roll = reusable animation segments for T3 card/graphics segments. Unresolved: license; block format vs T3 composition model. Would change: inspection + license → candidate for the next craft card slot (evidence-based, not count-based) |
| 6 | **nexu-io/open-design** | shortlist ×2: `skills/motion-design/SKILL.md` + `plugins/_official/video-templates/frame-liquid-bg-hero/SKILL.md` | Reference (catalog), determinism-conditioned | Audit: web/UI animation skills retained, but **require deterministic, seekable video rendering** rather than scrolling/hover/wall-clock timing. This matches our existing determinism contract (inventory row 11) and the v2 spec's own `WEB_UI_VIDEO_ROUTING_CORRECTION.md` adapter limits. One template path supplied (frame-liquid-bg-hero) — treated as an example, not a family endorsement. Unresolved: license; whether motion-design guidance is renderer-agnostic |

**Net for the six:** no cards issued. Two of them (product-launch-motion legacy route, open-design) jointly define the same missing capability — see §7 gap G1.

---

## 3. OPERATOR-CORRECTION ADOPTION LEDGER (audit's "corrections to earlier exclusions")

Each audit correction is accepted or answered explicitly — none is silently applied:

| Audit correction | Our prior position | Action taken | Registry effect |
|---|---|---|---|
| OpenMontage: restore video-edit, video-understand, FFmpeg skills; other routes have separate service dependencies | 2 catalog lines (video-edit, ffmpeg) | **Accepted** — video-understand restored as third catalog line; "service dependencies" caveat recorded | P-C1a (§8) |
| OpenChatCut/FableCut/FireRed: genuine skills, but app tools must exist before execution | BLOCKED (missing verified capability), craft citable | **Accepted — already aligned**; wording refined per audit: blocked ≠ poor; craft remains citable | No change needed (BLOCKED prose already carries it) |
| Diffusion Studio editor/watch: app-dependent instructions, not a portable renderer | BLOCKED (capability) | **Accepted — already aligned** | No change |
| VideoCaptioner: has an actual CLI skill; not to be rejected for also having an app | Not in our records (gap) | **Accepted — restored** as catalog reference line; install-reject still stands (duplicates measured T1+T3+T6 caption chain), reference value kept; audit's app-vs-CLI duality distinction recorded | P-C1b (§8) |
| Web/UI animation: keep relevant skills + dependencies; require deterministic, seekable rendering | Partially covered (v2 spec's routing correction; determinism contract) | **Accepted** — condition adopted as the standing gate for the whole cluster; collective LIBRARY-INDEX entry proposed instead of per-repo cards | P-C3 (§8) |

Also adopted from the audit: the 8-category usage taxonomy (§1 above) and the duplicate-resolution rulings (NanoSkill listings → canonical sources; MCP Market workflow listing → affaan-m/ecc; Agentic Awesome extractor entry → canonical upstream + required script; `.agents`/`.claude`/plugin copies not separate capabilities). These match how links are counted in §5 — one capability per canonical source, copy paths not double-counted.

---

## 4. COMPLETE REPOSITORY CROSSWALK — ALL 60 (Task 2)

**Inspection honesty:** "audit" = evidence reported by the operator's audit (145 document fetches; trees inspected where accessible; sampling on large catalogs) — I have NOT independently re-fetched these. "doc-read" = I read the document in a prior pass. "metadata" = directory-level facts only. Nothing in this table is runtime-tested by anyone; see §6.

Categories map to the audit taxonomy: [EW]=editing workflow · [MS]=motion/design specialist · [TR]=technical renderer · [AD]=app-dependent · [AN]=analysis/transcript support · [LIB]=library/dependency · [SR]=starter/reference · [HG]=hosted/generated-media workflow.

| # | Repository | Cat | Links | Inspection | Disposition | Card / entry | Evidence, reason, unresolved issues | What would change it |
|---|---|---|---|---|---|---|---|---|
| 1 | heygen-com/hyperframes | TR | 0 | doc-read + implementation/runtime (T3 tool probe 9/9, determinism ×3) | Adopted ×3 + adapted ×1 | SR-01/02/03/04 | Render contract, CLI, ~450-block registry, media-use fork design; Apache-2.0; scan v1 §A1 | Pin SHA + first-use fixture |
| 2 | remotion-dev/remotion | TR | 1 (remotion-best-practices) | doc-read (skill scope) | Deferred (tool-gated) | SR-21 | T4 headcount ruling on file; audit: official guidance baseline | T4 ruling |
| 3 | mltframework/shotcut | TR | 0 | not inspected | Not relevant (agent chain) | none | GUI NLE; no agent skill supplied; T0 owns conform. Honest: never examined | Documented headless/CLI need → T5-class ruling |
| 4 | 3b1b/manim | LIB | 0 | not inspected | Reference (genre: math/explainer animation) | none | Heavy engine; no campaign need demonstrated; adapter nonexistent | Explainer-brief need + adapter decision |
| 5 | nateherkai/herk-edit-kit | EW | 1 | doc-read | Adapted | SR-10 | Closest craft fit; strips Kie.ai/Scribe/music-SFX; gates ours. License undeclared in SKILL.md | License + pin → EXEC after fork |
| 6 | browser-use/video-use | EW | 1 | doc-read | Mined (no install) | MINED block | 3 lessons absorbed; provider/subagent/fade/encoding mandates rejected — audit restrictions match ours exactly | Clean fork would be re-reviewable |
| 7 | Pluviobyte/video-production-skills | MS | 2 | doc-read (ai-motion-director); 2nd link not inspected | Adapted (scoped) + 1 catalog addition | SR-11 + P-C1c | Motion-first scoped to card segments; **reference-video-replica-qc is NEW to our records** (analysis/QC support candidate) | 2nd SKILL.md read → catalog line |
| 8 | Creatorberry/flick | MS | 1 | doc-read | Deferred (tool-gated) | SR-20 | Remotion-core; audit: supporting animation, not auto story selection | T4 ruling |
| 9 | Leonxlnx/cinetic | EW/MS | 1 | not inspected | Reference (selective-load) | P-C2 line | Audit qualification in §2 row 1 | SKILL.md read + license |
| 10 | AbubakrChan/product-launch-motion | MS | 1 | not inspected | Reference (route-selection) | P-C2 line | §2 row 2; root route provenance-blocked | Route file inspection + license |
| 11 | nilbuild/video-demo | EW | 1 | not inspected | Reference | P-C2 line | §2 row 3 | Inspection; capture tooling ruling |
| 12 | 1weiho/cinematic-shot | MS | 1 | not inspected | Reference (specialist) | P-C2 line | §2 row 4 | Inspection + license |
| 13 | barty-bart/motion-graphics | MS | 1 | not inspected | Reference (adapt-candidate) | P-C2 line | §2 row 5 | Inspection + license → craft-card candidate |
| 14 | nexu-io/open-design | MS/LIB | 2 | not inspected | Reference (determinism-conditioned) | P-C2 line | §2 row 6 | Inspection + license |
| 15 | calesthio/OpenMontage | EW/AN | 3 | doc-read ×2 (video-edit, ffmpeg); video-understand not inspected | Reference ×3 | 3 catalog lines (+P-C1a) | Generic ffmpeg reference below T0; video-understand restored per audit; "other routes have separate service dependencies" recorded | video-understand SKILL.md read |
| 16 | 6missedcalls/video-editing-skill | EW | 1 | doc-read | Reference (rejected as install) | catalog line | Below-chain; audit-correction on atempo/provenance already logged (scan v2) | — |
| 17 | WEIFENG2333/VideoCaptioner | AN/EW | 1 | not inspected | Reference (install-reject stands) | P-C1b | Audit: real CLI skill; app duality ≠ rejection reason. Caption chain frozen (T1+T3+T6) — install would duplicate measured chain | CLI inspection; caption-chain change (not recommended) |
| 18 | nicolaigaina/ai-video-captions | AN | 0 | not inspected | Reference / unassessed | none | No audit note; caption-class; presumed duplicate of measured chain — NOT claimed as fact | First-need triage |
| 19 | bsisduck/video-analyzer-skill | AN | 1 | metadata | Reference (support-only) | catalog line | Audit: frame/scene analysis, optional transcription; never substitutes audiovisual review | — |
| 20 | 274326424/video-content-extractor | AN | 1 | metadata | Reference (support-only) | catalog line | Audit: sampling interval needs short-clip retune; helper script at repo-root `scripts/extract_video.py` (recorded) | — |
| 21 | JimLiu/baoyu-skills | AN | 1 | metadata | Reference | catalog line | Transcript retrieval; rights separate | — |
| 22 | michaelgold/videoskill | AN | 1 | metadata | Reference | catalog line | Structured extraction; not a finishing editor | — |
| 23 | gnipbao/minimax-h3-video-reverse-skill | AN | 1 | metadata | Reference | catalog line | Reference interpretation/prompt packaging; not a generator | — |
| 24 | JohnHeibel/ClaudeAnimationBase | SR | 0 | metadata | Reference (starter) | catalog line | Audit: p5/p5.brush guide; char styling + browser flags NOT campaign defaults | — |
| 25 | mexicat/pdoom-video | SR | 0 | metadata | Reference (starter) | catalog line | Audit: deterministic Three.js/typography; code ≠ soundtrack rights | — |
| 26 | feitangyuan/onetake | EW | 0 | metadata (license verified) | **Blocked (rights)** | BLOCKED prose | PolyForm NC; intentionally outside both adoption lists | Written clearance |
| 27 | op7418/guizang-product-video-skill | MS/HG | 1 | metadata (license verified) | **Blocked (rights)** | BLOCKED prose | AGPL code / BUSL assets; separate code/asset review required; no license-inheritance assumption | Written clearance per layer |
| 28 | MegaTroll222/VOX-COLLAGE-BROLL | HG | 1 | metadata | **Blocked (provenance)** | BLOCKED prose | Authenticated MaxFusion MCP + prescribed generation model — provider route conflicts with audio provenance | Provenance-policy change (not recommended) |
| 29 | 0xsline/OpenChatCut | AD | 4 | not inspected | Blocked (capability); craft citable | BLOCKED prose ×4 | Audit: genuine skills (product-ad-script, storyboard-breakdown, motion-graphics, verification); app tools must exist first | Verified local runtime |
| 30 | ronak-create/FableCut | AD | 3 | not inspected | Blocked (capability); craft citable | BLOCKED prose ×3 | edit-video, motion-graphics, remake-reel | Verified local runtime |
| 31 | FireRedTeam/FireRed-OpenStoryline | AD | 1 | not inspected | Blocked (capability); craft citable | BLOCKED prose | speech rough-cut skill | Verified local runtime |
| 32 | diffusionstudio/skills | AD | 2 | not inspected | Blocked (capability); craft citable | BLOCKED prose ×2 | editor + watch = app-dependent instructions per audit | Verified local runtime |
| 33 | diffusionstudio/editor | AD | 0 | not inspected | Blocked (capability) | BLOCKED prose | Application repo (the editor itself) | — |
| 34 | mutonby/openshorts | AD | 1 | not inspected | Blocked (capability) | BLOCKED prose | — | Verified local runtime |
| 35 | hypit-ai/hypit | AD | 1 | not inspected | Blocked (capability) | BLOCKED prose | — | Verified local runtime |
| 36 | browser-use/browser-use | AD | 1 | not inspected | Reference (out-of-domain today) | none | Browser-automation framework skill; no verified browser runtime in chain; potential future capture/intake support only | Capture-automation need + runtime verification |
| 37 | sickn33/agentic-awesome-skills | AD/MS | 2 | not inspected | Reference (2 sub-skills) | none | video-router (routing meta-skill — study-only vs our registry routing) + pro-motion (unknown content) | Inspection on demand |
| 38 | affaan-m/ecc | AD | 0 | not inspected | Reference (placeholder) | none | Duplicate-resolution canonical target (MCP Market listing); no audit findings quoted — honestly unassessed | First-need triage |
| 39 | greensock/GSAP | LIB | 0 | metadata + referenced-by-evidence | Library index (P-C3), determinism-gated | P-C3 | Appears in product-launch-motion legacy route + malayalam pack's gsap-lite; adapter into T3 UNVERIFIED; v2 spec names it in web_ui_resources | T3-embed adapter verified |
| 40 | liabru/matter-js | LIB | 0 | metadata | Library index (P-C3) | P-C3 | Physics lib; named in v2 routing correction with adapter limits | same |
| 41 | acamposuribe/p5.brush | LIB | 0 | metadata | Library index (P-C3) | P-C3 | Named in v2 routing correction; used by ClaudeAnimationBase | same |
| 42 | motion-canvas/motion-canvas | LIB/TR | 0 | metadata | Library index (P-C3) + renderer-category note | P-C3 | Animation-for-video lib with its own renderer — renderer slot owned by T3 (§6 category rule) | T4-class ruling if its renderer wanted |
| 43 | shadcn-labs/shadercn | LIB | 0 | metadata | Library index (P-C3) | P-C3 | Named in v2 routing correction (TypeGPU relation) | same |
| 44 | lucasmarkes/hairline | LIB | 0 | metadata | Library index (P-C3) | P-C3 | Named in v2 routing correction | same |
| 45 | radiumcoders/evil-buttons | LIB | 0 | metadata | Library index (P-C3) | P-C3 | Named in v2 routing correction | same |
| 46 | itsjwill/vanta | LIB | 0 | metadata | Library index (P-C3) | P-C3 | Animated WebGL backgrounds; NOT among v2's 8 web_ui_resources — extra find, same gate | same |
| 47 | danielwh2/cube-motion | LIB | 0 | metadata | Library index (P-C3) | P-C3 | Named in v2 routing correction | same |
| 48 | oil-oil/oil-motion | LIB | 0 | metadata | Library index (P-C3) | P-C3 | Named in v2 routing correction | same |
| 49 | gnipbao/codex-whiteboard-video-skill | MS | 1 | not inspected | Reference (genre: whiteboard) | none | Uninspected; no campaign need demonstrated | First-need triage |
| 50 | matteoikarieth96/whiteboard-video-skill | MS | 0 | not inspected | Reference (genre: whiteboard) | none | Same class as #49 | First-need triage |
| 51 | eternityspring/shuohao-skills | EW | 1 (novel-storyboard) | not inspected | Reference (story craft) | none | Story/narrative craft; uninspected | First-need triage |
| 52 | s1dashu/director | EW | 1 | not inspected | Reference | none | Uninspected | First-need triage |
| 53 | Jackywxsz/Jacky-motion | MS | 1 | not inspected | Reference | none | Uninspected | First-need triage |
| 54 | alchaincyf/huashu-art-motion | MS | 1 | not inspected | Reference | none | Uninspected | First-need triage |
| 55 | huangbai-AI/one-prompt-video-skills | MS | 1 (opus-code-animation) | not inspected | Reference (single sub-skill mapped) | none | Link maps one sub-skill only; repo may hold more — not assumed | Inspection |
| 56 | edenfunf/reelmimic | EW | 0 | not inspected | Reference (unassessed) | none | No audit note quoted — honestly unassessed | First-need triage |
| 57 | lemomo-ai/lemo-opuscar | TR/LIB | 0 | not inspected | Reference (unassessed) | none | Same | First-need triage |
| 58 | storytold/effectcraft | MS | 0 | not inspected | Reference (unassessed) | none | Same | First-need triage |
| 59 | PhiloLabs/awesome-video-agents | index | 0 | metadata (sampled per audit) | Reference index | none | Awesome-list; audit states large catalogs searched/sampled, not exhaustively audited | On-demand lookup only |
| 60 | yihui-dev/awesome-opus5-5-videos | index | 0 | metadata (sampled per audit) | Reference index | none | Same | On-demand lookup only |

**Row-count audit:** 60 rows; 60/60 dispositioned at audit-evidence level or better; 12 rows architect doc-read (prior passes); 48 rows honest not-inspected-by-architect (operator-audit evidence recorded as such). No row claims a runtime test.

---

## 5. COMPLETE DIRECT-LINK CROSSWALK — ALL 46 (Task 2)

Grouped by repository (the audit's duplicate-resolution rules applied: one capability per canonical source; copy paths not double-counted). Every link resolves to a §4 row — no silent drops.

**Shortlist (20):**

| Link (repo → path tail) | Disposition | Entry |
|---|---|---|
| browser-use/video-use → SKILL.md | Mined, no install | MINED block |
| Creatorberry/flick → skills/flick | Deferred T4 | SR-20 |
| Pluviobyte → ai-motion-director | Adapted scoped | SR-11 |
| Pluviobyte → reference-video-replica-qc | Catalog addition proposed (NEW to records) | P-C1c |
| Leonxlnx/cinetic → skills/cinetic | Reference (selective-load) | P-C2 |
| AbubakrChan/product-launch-motion → root | Reference (route-selection) | P-C2 |
| 1weiho/cinematic-shot → skills/cinematic-shot | Reference (specialist) | P-C2 |
| nilbuild/video-demo → root | Reference | P-C2 |
| calesthio/OpenMontage → video-edit | Reference | catalog |
| calesthio/OpenMontage → video-understand | Reference (restored per audit) | P-C1a |
| calesthio/OpenMontage → ffmpeg | Reference | catalog |
| bsisduck/video-analyzer-skill → root | Reference (support-only) | catalog |
| 274326424/video-content-extractor → skills/… | Reference (support-only; script path recorded) | catalog |
| JimLiu/baoyu-skills → baoyu-youtube-transcript | Reference | catalog |
| nexu-io/open-design → skills/motion-design | Reference (determinism-conditioned) | P-C2 |
| nexu-io/open-design → frame-liquid-bg-hero template | Reference (example, not family endorsement) | P-C2 |
| nateherkai/herk-edit-kit → short-form-edit | Adapted | SR-10 |
| barty-bart/motion-graphics → motion-broll | Reference (adapt-candidate) | P-C2 |
| remotion-dev/remotion → remotion-best-practices | Deferred T4 | SR-21 |
| 6missedcalls/video-editing-skill → root | Reference (rejected as install) | catalog |

**Conditional (26) — "conditional" matches our BLOCKED/gated classes, not quality judgments:**

| Link (repo → path tail) | Condition class | Disposition |
|---|---|---|
| diffusionstudio/skills → editor, watch (×2) | App-dependent | Blocked (capability); craft citable |
| 0xsline/OpenChatCut → product-ad-video-script, storyboard-shot-breakdown, create-motion-graphics, verification (×4) | App-dependent | Blocked (capability); craft citable |
| ronak-create/FableCut → edit-video, motion-graphics, remake-reel (×3) | App-dependent | Blocked (capability); craft citable |
| FireRedTeam/FireRed-OpenStoryline → speech_rough_cut (×1) | App-dependent | Blocked (capability); craft citable |
| mutonby/openshorts → openshorts (×1) | App-dependent | Blocked (capability) |
| hypit-ai/hypit → hypit (×1) | App-dependent | Blocked (capability) |
| WEIFENG2333/VideoCaptioner → skills (×1) | App+CLI duality | Reference (CLI real per audit); install-reject stands |
| op7418/guizang-product-video-skill → root (×1) | Licensing (AGPL/BUSL) | Blocked (rights) |
| MegaTroll222/VOX-COLLAGE-BROLL → root (×1) | Provider (MaxFusion MCP) | Blocked (provenance) |
| gnipbao/codex-whiteboard-video-skill → root (×1) | Workflow adaptation | Reference |
| Jackywxsz/Jacky-motion → root (×1) | Workflow adaptation | Reference |
| alchaincyf/huashu-art-motion → root (×1) | Workflow adaptation | Reference |
| gnipbao/minimax-h3-video-reverse-skill → root (×1) | Support-only | Reference (catalog) |
| eternityspring/shuohao-skills → novel-storyboard (×1) | Workflow adaptation | Reference |
| s1dashu/director → root (×1) | Workflow adaptation | Reference |
| michaelgold/videoskill → root (×1) | Support-only | Reference (catalog) |
| huangbai-AI/one-prompt-video-skills → opus-code-animation (×1) | Workflow adaptation | Reference (single sub-skill) |
| browser-use/browser-use → skills/browser-use (×1) | App-dependent (browser runtime) | Reference (out-of-domain today) |
| sickn33/agentic-awesome-skills → video-router (×1) | Meta/routing study | Reference (study-only) |
| sickn33/agentic-awesome-skills → pro-motion (×1) | Workflow adaptation | Reference (uninspected) |

**Count closure:** 20 + 26 = 46 links → 35 repositories → all mapped above. 18 links live in 7 multi-link repos; 28 links are single-repo. Onetake: 0 links by design (rights note).

---

## 6. READINESS SEPARATION (six layers, per operator instruction)

| Layer | State | Contents & evidence |
|---|---|---|
| **Source coverage** | COMPLETE | 60/60 repositories receipted, hashed, parsed, dispositioned (§4); 46/46 links mapped (§5); audit taxonomy + corrections adopted (§3). Coverage ≠ inspection — see next layer |
| **Readable guidance** | Card/citation level: yes. Body level: partial | Everything dispositioned above is citable. Bodies of the 7 prior doc-read skills were read once but not stored — re-fetch at pin time (HEAD drift rule). The 48 not-inspected rows have NO readable body here yet — only the audit's reported findings |
| **Adapted guidance** | Designs only, nothing built | video-use 3 lessons + scoped layer-order note (in registry text); SR-04 media-use fork design; SR-10 override design; SR-11 scoping; web/UI determinism condition (§3, adopted); product-launch-motion route-selection rule |
| **Runnable implementations** | 3 skill cards EXEC-eligible, zero resident | SR-01/02/03 — runnable AFTER pin + first-use fixture. Zero skill bodies stored locally; zero skills have ever executed here |
| **Feature-tested capabilities** | Tools, not skills — 12 inventory rows + new structural test | Unchanged 12 rows (T3 probe, loudness chain, T1, T6, seam, QC, metadata, audio transforms, determinism, alpha). NEW this pass: pack packaging/content equivalence = **structural file comparison, 80/80 byte-identical** (correction #4 evidence) — a structural test, still not a runtime test. Skill bodies feature-tested: **zero** |
| **Campaign approval** | Zero | No routing line ever emitted in a real brief; prototype v0.9 + all patch sets (P1–P3, P-R1–R3, P-M1, P-C series) await operator ruling |

---

## 7. ACTUAL UNCOVERED CAPABILITIES (concise — the honest gap list)

- **G1 — Deterministic seekable web-animation→video adapter.** GSAP/matter-js/p5.brush-class libraries and the web/UI skill cluster (open-design, product-launch-motion legacy) all require it; the v2 spec's routing correction already demands it; no verified component exists (no inventory row). This is the single highest-leverage gap — it gates the whole LIB cluster + 2 priority references from REFERENCE to EXECUTABLE.
- **G2 — Live web-product capture.** video-demo's discipline (intentional demonstration, capture-vs-fixture) is referencable, but no screen/application capture capability is verified in this environment. Campaigns today run on operator-supplied footage only. Capability, not a skill: needs a capture tool ruling before any skill can execute it.
- **G3 — Reference-based QC replication.** Our QC measures technical conformance (grid, loudness, seams, claims). Pluviobyte's reference-video-replica-qc targets "does it look like the reference" craft QC — currently uncovered and uninspected. Catalog-addition proposed (P-C1c), not an inventory row.
- **G4 — Motion B-roll reuse.** barty-bart motion-broll is the named baseline supplement; no measured path exists for loading B-roll segments into T3 compositions. Adapt-candidate, evidence pending inspection.
- **Not gaps (recorded to prevent false ones):** whiteboard/math-animation genres (no campaign need demonstrated); caption CLI alternatives (measured chain owns captions); rough-cut story assembly (app-dependent; T0/T3 chain handles rough cut); routing meta-skills (registry routing already exists — study-only).

---

## 8. MINIMAL PROPOSED REGISTRY CHANGES (NOT applied — stop for approval)

| ID | Change | Why | Why not more |
|---|---|---|---|
| **P-C1** | Three catalog-line additions: (a) OpenMontage video-understand; (b) VideoCaptioner CLI reference; (c) Pluviobyte reference-video-replica-qc | Operator corrections + link coverage; each is one line, REFERENCE-ONLY | Uninspected → no numbered cards, no EXEC claims |
| **P-C2** | One PRIORITY REFERENCE block (7 lines): cinetic, product-launch-motion, video-demo, cinematic-shot, barty-bart motion-broll, open-design (+ template example note), each with the audit's qualification + our conflict conditions inline | Operator-designated priority; must be visible at routing time, not buried in an external file | Audit findings quoted, not independently verified; licensing unknown → REFERENCE-ONLY |
| **P-C3** | One collective LIBRARY-INDEX entry (10 repos): GSAP, matter-js, p5.brush, motion-canvas, shadercn, hairline, evil-buttons, vanta, cube-motion, oil-motion — standing gate: deterministic seekable rendering; adapter required | Audit category rule; 8/10 already referenced by v2 spec's web_ui_resources + routing correction; per-repo cards would inflate count without adding routing value | motion-canvas has its own renderer → extra renderer-category note inside the entry |
| **P-C4** | Close the video-frames @steipete INSPECT item (carried from v1.0): read SKILL.md → card or logged rejection | Only resource whose disposition trail stopped mid-air | One pass, one item |

**Explicitly not proposed:** numbered SR cards for any uninspected resource; any install; any adapter (G1/G2 are logged, not built); master-prompt text; inventory rows beyond the already-pending P-R3; per-repo cards for the LIB cluster; any change to BLOCKED classes (already aligned with audit).

---

## 9. CORRECTIONS TO THE TWO REPORTS (Task 3 — applied)

**RESOURCE_INTEGRATION_REPORT → v1.1 (edited in place, correction log added):**
1. "never tested by anyone" blanket phrasing replaced by the layered evidence limitation (structure-only validation by authors, self-claimed template tests, our read+structural checks; runtime possible and gated, not impossible).
2. Production-renderer distinction: ONE primary production renderer (T3) vs retained alternatives (20-pack render.py = retained reference implementation; libass = available-not-tested; T0/T2 = proven static path).
3. "T3 verified captions" scoped to named tested features (probe-verified render pipeline) vs NOT-feature-tested (styled captions in T3 text, libass).
4. Packaging/content equivalence: **now substantiated by file comparison** — upload-to-claude/ folder EXISTS (prior "missing" claim was an inventory error) and all 20 per-style zips are byte-identical to loose dirs (80/80 SHA-256). Equivalence to the never-delivered declared single zip remains UNVERIFIABLE (no manifest to compare against).
5. Comedy emphasis choice marked example-specific (TEST 1), not a campaign-wide comedy rule.
6. SaaS PDF: explicit inventory record added (size, SHA-256, source, extraction method, page-count not extracted).

**COVERAGE_RECONCILIATION:** v1.0 stands as the honest failure record; v2.0 (this file) completes it. No edits to v1.0.

---

## 10. STOP

All three tasks executed within scope: input restored and verified; reconciliation complete at source level with honest inspection limits; two reports corrected. No installs, no adapters, no renders, no core rewrites, no registry changes applied. Awaiting operator approval on §8 (P-C1..C4) and the earlier pending rulings (P-R1/R2/R3, P1–P3, v3.2 core integration).
