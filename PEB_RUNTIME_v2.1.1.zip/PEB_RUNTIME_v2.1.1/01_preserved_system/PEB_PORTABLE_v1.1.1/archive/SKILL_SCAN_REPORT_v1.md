# SKILL SCAN REPORT — v1 (Phase-2 output, 2026-10-28)

**Purpose:** candidate agent-skills shortlist for the editing agent, scored against the Phase-1 need areas and triaged under the registry discipline (need match → license → telemetry/safety → conflict check → verdict). Feeds the future SKILL REGISTRY module after operator approval of the ADOPT list.

**Phase-1 areas (confirmed by operator):** editing craft · motion graphics · audio · QC/compliance · tool operation. Standing rule: skills are technical guidance, NEVER authority over the campaign brief.

**Method:** ClawHub discovery (6 queries) + vendor repo enumeration (mirage-hq/tesseract, heygen-com/hyperframes, remotion-dev/skills) + agent-skills directories (cmds.si, mcpmarket, skillsllm). All findings logged below; verdicts are recommendations pending operator sign-off.

---

## TIER A — VENDOR-NATIVE SKILLS (highest value)

### A1. HyperFrames (HeyGen) — 7 official skills, Apache-2.0, `npx skills add heygen-com/hyperframes`

| Skill | Scope | Fit vs Phase-1 | Conflict flags | Verdict |
|---|---|---|---|---|
| `/hyperframes` (core) | Render contract + work loop; references for format, motion, look, captions, films, storyboards | Tool operation + motion graphics | Creative defaults documented in T3 card (landscape bias, 30 fps, add-music suggestions) | **ADOPT + override header** |
| `/hyperframes-cli` | Scaffold, check, preview, render local/cloud, publish, project history | Tool operation | Minor: "publish/cloud" paths must stay OFF (local-only policy) | **ADOPT** |
| `/hyperframes-registry` | ~450 ready blocks: transitions, overlays, titles, kinetic type, captions, charts, maps, 3D, camera moves | Motion graphics | Blocks are templates — each use must pass campaign gates (9:16, fps grid, rights) | **ADOPT** |
| `/media-use` | Getting/making media: music, SFX, voiceover, avatars, generated video, transcripts, color grades, icons, logos | ⚠️ touches audio + rights boundary | HEAD-ON collision: original-audio-only policy + rights regime (sourced/generated music & voiceover are banned channels) | **ADAPT** — strip sourcing/generation sections; keep transcript + color-grade + operator-asset handling |
| `/figma` | Figma assets → rendered video components, brand tokens, storyboard frames as motion | Off-profile (no design-ingest area) | None technical; **Phase-1 expansion question** | **PARK** (operator call — see §Phase-1) |
| `/slideshow` | Presentations/pitch decks with slides, reveals, branching | Off-profile (decks ≠ campaign deliverables) | — | **REJECT (out of scope, revisit on a deck brief)** |
| `/remotion-to-hyperframes` | Migrate Remotion code/footage into HyperFrames, frame-by-frame verification | Tool operation (conditional) | Only meaningful if T4 artifacts exist | **PARK** (T4-gated) |

**License check:** Apache-2.0, same as T3 tool — zero friction. **Telemetry:** T3 card rule stands (HYPERFRAMES_NO_TELEMETRY=1 before client material). **Authority risk:** HIGH — this is the most capable skill set we found, which is exactly why the override header is mandatory.

### A2. Mirage Tesseract — 4 official skills, current as of Release 0.4.0 (matches our pinned probe version)

| Skill | Scope | Gate | Verdict |
|---|---|---|---|
| `tesseract-video` | Edit footage → finished video: cuts, dialogue preservation, sound design, audio mixing, motion-graphics scenes | T5 FREE-CLAUSED verify-first | **PARK** — skills follow the tool's unlock path (license check → re-probe → G7) |
| `tesseract-motion` | Titles, typography, diagrams, overlays animation | T5 gate; overlaps T3 category (§6 one-tool rule) | **PARK** |
| `tesseract-editor` | Build browser editor for .tsrct projects | T5 gate | **PARK** |
| `tesseract-design` | Static visuals: posters, social graphics, mockups | T5 gate; T2 owns static graphics | **PARK** |

Note: skills updated with tool release 0.4.0 = version coherence good sign. All four become live candidates the day tsrct unlocks.

### A3. Remotion — 1 official skill ("Remotion Programmatic Video", remotion-dev/skills, 3.9k installs)

- Scope: programmatic video with React/TS, best practices, captions, motion graphics/charts.
- Gate: T4 headcount ruling ON FILE before any install. Community layer exists (myceldigital/remotion-claude-skill — "broadcast-quality motion design craft" atop official skill) — noted, not vetted.
- **Verdict: PARK** (T4-gated, same as tool).

---

## TIER B — PUBLIC DIRECTORIES (ClawHub + skill directories)

**Overall verdict: weak for pro editing.** Dominated by keyword-farmed 0-install entries (dozens of ecommerce-platform video skills, douyin/xiaohongshu pipelines) — off-domain, unvetted, zero adoption evidence. No "crazy find" in this tier.

| Candidate | Evidence | Fit | Verdict |
|---|---|---|---|
| `video-frames` @steipete | 13 installs/60d (highest relevant count); reputable author | Formalizes frame extraction for agent review — complements T6 intake sweep + Tier-0 frame review | **INSPECT** — read SKILL.md for telemetry/network; likely ADAPT into intake workflow |
| `video-subtitles` @ngutman (4/60d), `subtitle` @scikkk (2/60d) | Low traction | Caption chain is owned: T1 timestamps + T3 captions-as-design (frozen) | **REJECT** — duplicates measured chain; authority-contamination risk |
| `audio-quality-check` @tenequm | 0 installs | Loudness regime is frozen (loudnorm two-pass + alimiter + ebur128) | **REJECT** |
| `tiktok-motivation-video` @thuongvh2-python | Full pipeline: AI script + ElevenLabs VO + Pexels stock | Violates original-audio-only + rights policy | **REJECT** |
| Ecommerce keyword-farm batch (~25 skills) | 0 installs, platform-specific | Off-domain | **REJECT** |

---

## TIER C — HOUSE-AUTHORED (planned, not scanned)

Distill our own frozen patterns into SKILL.md packages (nobody else has these):
1. **loudness-chain** — loudnorm two-pass + alimiter + ebur128 QC procedure incl. XR-4 corrections (adelay=3S samples bug, impulse-test requirement).
2. **banned-claim-sweep** — T6 intake sweep workflow + vocabulary + logging format + "no hits ≠ no claims" limit.
3. **card-seam-discipline** — segment render → FFmpeg concat seam, PTS grid, no re-encode drift.
4. **delivery-QC** — fail-closed checklist + 5 negative fixtures (XR-3).

These become the SKILL REGISTRY's founding house cards after the master prompt v3.2 core integration (still pending operator "go").

---

## PHASE-1 BOUNDARY TEST (the operator decision point)

Nothing found **forces** a Phase-1 edit. Two finds are *expansion candidates*, both optional and rights-sensitive:

1. **`/figma`** — would add a "design-asset ingest" area. Only worth it if campaigns actually use Figma brand kits. Recommendation: keep PARKED; activate on first real brief need.
2. **`/media-use` sourcing half** — would add a "media sourcing" area. Recommendation: do NOT add — the original-audio-only + rights regime is a deliberate architecture decision, not a gap. The ADAPT (strip-and-keep) path preserves the useful 30%.

## RECOMMENDED ADOPT LIST (pending operator sign-off)

| # | Skill | Source | Action |
|---|---|---|---|
| 1 | `/hyperframes` | HeyGen official | ADOPT + override header, pin |
| 2 | `/hyperframes-cli` | HeyGen official | ADOPT, pin |
| 3 | `/hyperframes-registry` | HeyGen official | ADOPT, pin, per-block gate note |
| 4 | `/media-use` (stripped) | HeyGen official | ADAPT → house fork |
| 5 | `video-frames` | ClawHub @steipete | INSPECT content, then likely ADAPT |
| 6 | Tier-C house skills (4) | Authored | BUILD after v3.2 core integration |

PARKED (tool-gated): 4 Mirage skills (T5), Remotion skill (T4). REJECTED: 30+ logged above.

## NEXT STEPS

1. Operator approves/edits the ADOPT list.
2. Then: draft **PEB v3.2 MODULE — SKILL REGISTRY (attach edition)** — sibling to TOOL_REGISTRY: skill cards, override-header template, pin/dry-run/after-action procedure.
3. Dependency note: master prompt v3.2 core integration (R5 folding) remains the gating item for the Tier-C house skills — one "go" unblocks both.
