# PRO EDITOR BRAIN — MINIMAL PATCH SET (v1.0 → v2)

Exact find/replace and insertion text for each material finding. Applied against the original
master prompt, these produce the consolidated file `PRO_EDITOR_BRAIN_v2_consolidated.md`.
Nothing is removed; everything not shown here stays verbatim.

---

## PATCH 1 — §1 Mission: decouple client verticals (Finding F2)

FIND (end of the second paragraph):
```
Build a reusable, machine-executable Pro Editor Brain Module for real-estate, technology, product demonstration, and founder footage, initially focused on BOXABL modular homes.
```

REPLACE WITH:
```
Build a reusable, machine-executable Pro Editor Brain Module for real-estate, technology, product demonstration, and founder footage, initially focused on BOXABL modular homes.

Client verticals are configuration, not identity. The module's editorial laws, QC, and recipes must remain valid for any short-form client — real-estate products, technology demos, founder interviews, or clipping campaigns for apps and shows. Client-specific facts, claims, branding, and recipe parameters live in the client profile and campaign rules, never hard-coded into the module's behavior.
```

---

## PATCH 2 — §3 Input contract: add campaign rules as first-class input (Finding F1)

FIND:
```
- Working directory: configurable; prefer /pro_engine/ when writable.
- Preserve source originals.
```

REPLACE WITH:
```
- Working directory: configurable; prefer /pro_engine/ when writable.
- Preserve source originals.

Client profile and campaign rules (required for campaign work):
- Client, product, brand assets (logo files, fonts, colors), approved claims, and the posting account(s).
- Mandatory inclusions per post (for example: bio-link call to action, caption mention, branded end card).
- Banned claims and prohibited content. Treat them like the claims ledger: excluded unless the operator waives them in writing.
- Language requirements (for example: English-only speech and burned-in text).
- End-card specification: a compliant campaign end card includes the actual brand logo graphic AND wording that instructs the required viewer action (for example, "Download the app — link in bio"). Wording that only names the brand does not satisfy this gate.
- Post-publish requirements (submission windows, analytics captures, audience thresholds): the module emits an operator checklist for these; it does not publish, submit, or capture analytics itself.
```

---

## PATCH 3 — §5 Source intelligence: language gate + claim examples scoping (Finding F1, F2)

3a. FIND (end of the "Transcribe and identify" list):
```
- Repetition and filler.
- Uncertain words and potentially misleading claims.
```

REPLACE WITH:
```
- Repetition and filler.
- Uncertain words and potentially misleading claims.

Language gate (when campaign rules require a specific language): verify the spoken language AND burned-in text of each candidate source segment before building on it. Paraphrase captions do not rescue non-qualifying speech. Rebuild qualifying moments around qualifying screen content (UI, prompt screens, score popups, product screens) and cut non-qualifying speech and subtitles entirely. Record language verification in the source index as a pre-selection check.
```

3b. FIND:
```
Treat "375 SQ FT," "$50,000," and "1 HR SETUP" as unverified examples unless supported by provided, relevant evidence.
```

REPLACE WITH:
```
Treat "375 SQ FT," "$50,000," and "1 HR SETUP" as unverified examples unless supported by provided, relevant evidence. These are BOXABL-profile examples of the method; every client's claims follow the same rule through the claims ledger.
```

---

## PATCH 4 — §7 Design system: remove the dangling "Zone 3" reference (Finding F4)

FIND:
```
The hero at Y = 1050 is an intentional main-image placement, not a Zone 3 caption.
```

REPLACE WITH:
```
The hero at Y = 1050 sits inside the Main imagery region (Y = 360..1150). It is an intentional main-image placement, not a Captions/lower-emphasis element; do not renumber these regions or invent additional zones.
```

---

## PATCH 5 — §9 Hook preset B: disambiguate timing annotations (Finding F5)

FIND:
```
- Frame 9: optional riser begins, 300 ms.
- Frame 27: emphasis/contact event and impact, 900 ms.
- Frame 27: riser ends with a shaped envelope.
```

REPLACE WITH:
```
- Frame 9 (= 300 ms at 30 fps): optional riser begins.
- Frame 27 (= 900 ms at 30 fps): emphasis/contact event; the effect's impact transient lands.
- Frame 27: riser ends with a shaped envelope.
```

---

## PATCH 6 — §10 Recipes: client profiles + campaign end-card rule (Finding F2, F1)

6a. FIND (end of the "Each recipe must:" list):
```
- Include a tsrct implementation only if its actual interface is verified.
```

REPLACE WITH:
```
- Include a tsrct implementation only if its actual interface is verified.
- Accept a client profile: every name, label, color, icon, and example format below is a parameter. The domain examples (rooms, stat pills) illustrate the BOXABL profile; for other clients, substitute profile-appropriate content without weakening any requirement.
```

6b. Recipe B — FIND:
```
- Responsive layout and readable hierarchy.
```
REPLACE WITH:
```
- Responsive layout and readable hierarchy.
- Pill labels are profile parameters (real-estate stats, episode counts, formats, game modes); every displayed value comes from the approved claims ledger.
```

6c. Recipe C — FIND:
```
- Original red/white or brand-appropriate treatment.
```
REPLACE WITH:
```
- Brand-appropriate treatment (the original red/white look is the BOXABL-profile example, not a default).
```

6d. Recipe D — FIND:
```
- Format example: 01/04 · FULL KITCHEN.
- State derived from actual edit sections.
```
REPLACE WITH:
```
- Counter content is a profile parameter (rooms for a home tour, episodes/acts for a series, steps for a demo, levels for a game); "01/04 · FULL KITCHEN" is the BOXABL example format.
- State derived from actual edit sections.
```

6e. Recipe D — FIND:
```
- Do not imply a room count or floor plan unsupported by the footage.
```
REPLACE WITH:
```
- Do not imply sections, counts, or floor plans unsupported by the footage; the room-count rule is the BOXABL case of this general rule.
```

6f. Recipe E — FIND (end of recipe E list):
```
- Disable shake when it weakens the premium finish or accessibility.
```
REPLACE WITH:
```
- Disable shake when it weakens the premium finish or accessibility.
- Campaign end cards: when campaign rules require one, the stamp must include the brand logo graphic AND wording that instructs the required viewer action (for example, "Download the app — link in bio"). Wording that only names the brand (for example, "to try <Brand>") does not satisfy the gate.
```

---

## PATCH 7 — §13 QC: add Campaign Release Gates (Finding F1)

FIND:
```
Severity:
- Critical: corruption, missing essential content, materially misleading claims, unusable audio, broken synchronization.
```

INSERT BEFORE IT:
```
CAMPAIGN RELEASE GATES (apply only when campaign rules are supplied)

For campaign work, the following are release-blocking checks in addition to the QC above:
- End-card compliance: brand logo graphic present AND explicit action instruction, per the end-card specification.
- Language compliance: all retained speech and burned-in text satisfies the campaign language rule.
- Claim compliance: no banned claim, invented capability, or unapproved universal claim; on-screen wording matches the claims ledger.
- Mandatory elements: every required inclusion (caption mention, CTA, bio-link note in the description draft) is present and listed in the QC report.
- Rights compliance: only authorized source material was used.

A campaign-gate failure is a Major defect at minimum; a materially misleading claim remains Critical.

The module does not publish, submit URLs, or capture analytics. It must emit an operator checklist covering the campaign's post-publish steps (for example: submit the post URL within the required window; record and send the 24-hour analytics capture; verify posting-account audience requirements). These steps are outside module scope but inside delivery completeness.

```
(Insert the block immediately before the existing "Severity:" list so both share one severity scale.)

---

## PATCH 8 — §12 Artifacts: add the operator checklist (supports Finding F1)

FIND:
```
- review frames/contact sheets
- demonstration or project export
```

REPLACE WITH:
```
- review frames/contact sheets
- demonstration or project export
- operator_checklist.md (emitted for campaign work)
```

---

## PATCH 9 — §15 Delivery order: staged build with acceptance gates (Finding F3)

FIND:
```
If filesystem access exists:
- Write and test actual files.
```

INSERT BEFORE IT:
```
When building the module (Mode A), construct it in stages and report status at each stage boundary. Do not begin the next stage until the previous one meets its acceptance gate:
- Stage 1 — Core: capability matrix; timing/frame/sample math; source-index and claims-ledger schemas; ONE motion recipe end-to-end (asset → composite → render → post-render QC) with a synthetic fixture. Gate: the Stage 1 render passes the full post-render checklist, and all timing/geometry tests pass.
- Stage 2 — Recipes and QC: remaining four recipes; pre-render validation; collision and safe-region checks; audio event alignment. Gate: each recipe renders from configuration and passes its QC tests.
- Stage 3 — Package: full test suite, fixtures, spec/schema, README, operator checklist emission. Gate: the complete artifact list exists with honest verification status per artifact.

If output limits threaten completion, stop cleanly at a stage boundary, report exactly what passed, and do not label the partial package complete.

```

---

## OPTIONAL (not applied in v2 — noted for completeness)

§9 speed-ramp bullet "Do not treat PTS/varying_speed as a generally correct variable-speed
solution." is jargon-compressed but correct: the adjacent integration rule (source_time(t) =
source_in + ∫v dτ) already states the right method, and the failure it guards against (naive
per-frame PTS division) is covered. Adding an explanation would spend words without changing
agent behavior. Leave as-is unless a run shows an agent misreading it.
