# ARCHIVE INDEX — Historical Audits and Records (NOT mandatory startup reading)

**Purpose:** complete audit trail of the project's history, preserved byte-exact. Read a file only when you need to trace WHY a current rule exists. Nothing in this folder is an instruction — where anything here conflicts with the living documents (START_HERE, 01–07 folders), the living documents win.

## What's here

### Skill/resource audit lineage
| File | What it is |
|---|---|
| `SKILL_SCAN_REPORT_v1.md` / `SKILL_SCAN_REPORT_v2.md` | Phase-1/2 skill scans (vendor skills, ClawHub triage, deep verification of 7 SKILL.md files, routing design) |
| `COVERAGE_RECONCILIATION_v1.0.md` | The honest failure record (input-persistence defect) + 42-resource subset recovery |
| `COVERAGE_RECONCILIATION_v2.0.md` | Complete 60-repo + 46-link reconciliation with P-C1…C4 as PROPOSED (superseded by v2.1's application record) |
| `RESOURCE_INTEGRATION_REPORT_v1.0.md` / `RESOURCE_INTEGRATION_REPORT_v1.1.md` | Caption/effects integration report as originally delivered / first correction round (superseded by v1.2 in `../07_status/`) |
| `OPERATOR_INPUT_2026-10-28/` | The operator's resupplied consolidated audit, verbatim + hashed (CONSOLIDATED_HANDOFF_VERBATIM.md, 3 list files, NORMALIZED_INVENTORY.md, RECEIPT.md) — the first instance of the persist-at-receipt process fix |

### Master-prompt version lineage
| File | What it is |
|---|---|
| `PRO_EDITOR_BRAIN_v2_consolidated.md` / `PRO_EDITOR_BRAIN_v2_patches.md` / `PRO_EDITOR_BRAIN_v2.1_video_patches.md` | v2 full rewrite + patch sets |
| `PRO_EDITOR_BRAIN_v3.md` / `PRO_EDITOR_BRAIN_v3_appendix.md` | v3 (technical content kept; governance later rebuilt in v3.1) |
| `V3_EXTERNAL_REVIEW_verdict_and_actions.md` / `V3_REVIEW_user_prompt_vs_goals.md` / `V3_integration_map.md` / `V3_improvement_roadmap.md` | v3 external review + verdicts |
| `V3.1.1_TEST_CORRECTIONS.md` / `PEB_v3.1.1_PAPER_TESTS.md` / `PEB_v3.1.1_PILOT_PLANS.md` / `PRO_EDITOR_BRAIN_v3.1.1_TEST.zip` | the v3.1.1 freeze record (5 corrections C1–C5, FRT traces, pilot plans, frozen bundle) |

### RexTrix campaign review rounds
| File | What it is |
|---|---|
| `REXTRIX_campaign_input.md` | Original campaign input |
| `REXTRIX_10clip_review.md` | The 10-clip intake review (conform/loudness/claims) |
| `EDITING_AGENT_RUN1_REVIEW.md` | Run-1 review (R1–R4 rulings, 2 owned brief defects) |
| `EDITING_AGENT_REVIEW_R2.md` … `EDITING_AGENT_REVIEW_R5.md` | Rounds 2–5 (pilot approval, batch scope S1–S5, card-audio/typeface rulings, SA-1…SA-6 QC audit, XR-1…XR-8 external-review adoption) |
| `PILOT_CLIP28_REVIEW.md` | Independent clip-28 pilot verification (all QC claims reproduced) |

### Consults and scouts
| File | What it is |
|---|---|
| `CONSULT_A_feel_engine.txt` / `CONSULT_B_motion_graphics.txt` / `CONSULT_C_keyframes_stab_bg_pipeline.txt` / `CONSULT_D_campaign_brain_viral.txt` | Four domain consults folded into v2/v3 |
| `SCOUT_campaign_brief_prompt.txt` | Scout prompt v1 (superseded by v2 in `../campaign_context/`) |

## Integrity

All files are copies of the canonical versions in the project's download tree (outside this package), preserved unmodified. The full package manifest with SHA-256 hashes is at `../PACKAGE_MANIFEST.md`.
