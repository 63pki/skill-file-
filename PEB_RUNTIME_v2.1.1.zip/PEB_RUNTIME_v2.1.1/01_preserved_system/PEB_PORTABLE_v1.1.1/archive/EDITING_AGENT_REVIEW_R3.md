# EDITING AGENT REVIEW — ROUND 3 (REFERENCE RESOLUTION + BATCH SCOPE RULING)
Date: 2026-10-27 · Trigger: agent query — "I can't resolve what P5 refers to — no P5
gate exists in the campaign profile, audit or fix plan in the workspace (gates run
P-V1…P-V7). Which clip set should I render?"
Verdict: the agent's query is CORRECT behavior and the confusion is a sender-side
defect. P5 is a ruling, not a gate. Render scope is ruled below, with preconditions.

## 1. WHAT "P5" IS (reference resolution)

Three numbering systems are live in this campaign. Namespace map:

| Prefix      | Lives in                              | Meaning                    |
|-------------|---------------------------------------|----------------------------|
| P-V1…P-V7   | CAMPAIGN_BRIEF_RexTrix.md / profile   | campaign verification GATES|
| R1…R4       | EDITING_AGENT_RUN1_REVIEW.md          | Round-1 rulings            |
| P1…P5       | EDITING_AGENT_REVIEW_R2.md §2         | Round-2 rulings            |

"P5" = Round-2 Ruling 5, EDITING_AGENT_REVIEW_R2.md §2, verbatim:

> P5 — BATCH COMPOSITION RULE (going forward). A clip is a submission candidate only if:
> (1) it passes the three gates after the approved card fix; (2) no burned-in banned-claim
> class in the picture; (3) no unfixable body defect; (4) deviations logged. Keep batches
> small enough to inspect; stop a repeated defective pattern before making more (CORE
> pilot-gate language applies to batches, not just pilots).

Where the dangling reference came from: PILOT_CLIP28_REVIEW.md §6, the recommended
operator message ("Apply to the P5-eligible clips") cites the ruling ID without its
source file. The agent searched the profile/audit/fix-plan namespaces — reasonable
targets, wrong namespace. Rulings resolve in the architect review files; index the
ruling IDs from the three review files into the project record so future citations
resolve locally.

STANDING RULE (adopted as of this round, binds both sides of the channel):
- Every ruling citation must carry file + section, e.g. "R2-P5
  (EDITING_AGENT_REVIEW_R2.md §2)".
- An unresolvable reference is a defect in the SENDING document. The receiving agent's
  correct response is exactly what happened here: log it, ask, do not guess. This query
  is cited as the reference example of that behavior — the honesty layer outranks the
  embarrassment of asking.

## 2. BATCH SCOPE RULING (the actual question)

S1 — ELIGIBLE SET ("P5-eligible clips"): 30 clips minus the R2-P2 exclusions
(08, 09, 17, 24, 25) = 25 clips:
01, 02, 03, 04, 05, 06, 07, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 23,
26, 27, 28, 29, 30.

S2 — CLIP 28 DOES NOT RE-RENDER. Its verified pilot (PILOT_CLIP28_REVIEW.md: every gate
reproduced independently, SHA-pinned chain of custody) IS the approved pattern and
carries forward as the batch reference. Re-rendering it adds provenance noise, not
value. Batch render set = 24 clips.

S3 — "BATCH 3 ONLY" IS DENIED AS SCOPE. The 60→30 frame-drop conform is applied
per-source-measurement, not per-episode-batch: any clip whose measured encoded source
is the synthetic-60fps class gets the conform; nothing else does. Known conform-class
sources among the 24: 21, 22, 23, 26, 27, 29, 30. Sub-batch membership is fixed by ID;
the conform step itself is decided by each clip's own measurement (CORE rule), so a
surprise in either direction is a logged deviation, not a re-plan.

S4 — DELIVERY STRUCTURE (P5's own "small enough to inspect" clause): 4 sub-batches
of 6, ruled schedule —
- Sub-batch A: 21, 22, 23, 26, 27, 29  — conform class first: highest source risk,
  the very clips where batch 3's interpolation artifacts lived; the pattern proves
  itself against the hard cases before touching the easy ones.
- Sub-batch B: 30, 01, 02, 03, 04, 05
- Sub-batch C: 06, 07, 10, 11, 12, 13
- Sub-batch D: 14, 15, 16, 18, 19, 20
Full per-clip QC in every sub-batch. HARD STOP after sub-batch A: deliver A, stand by
until its QC is reviewed, then continue. Any repeated defect pattern anywhere → stop
the line, report (P5 final sentence; CORE pilot-gate language applies to batches).

S5 — LABELING REGIME. All batch renders carry the review_draft label + the same
disclosure block (derived mark provenance) + per-clip QC tables + evidence artifacts.
They are NOT release candidates. R4 (a)/(b) logo and the rights grant block RELEASE,
not review-labeled renders — same logic as P1. If R4 resolves to (a) official PNG, the
card asset changes and affected renders get one more pass under the frozen pattern;
plan for it, do not pre-render it.

## 3. PRECONDITIONS — CHECK BEFORE RENDERING (all three must be on file)

1. [D7] batch-pattern approval actually received from the operator (their human
   watch/listen of the pilot done). If not received, request it and HOLD.
2. Card audio variant decided ONCE, batch-wide: silent tail (as rendered on the pilot)
   or source-music-continuation under the card. An un-decided variant must not
   propagate into 24 renders — this freezes with the pattern, not per clip.
3. Typeface frozen: DejaVu placeholder signed off, or the campaign font supplied.

Missing any of the three → ask, hold, render nothing. That is P5's pilot-gate language
applied to batches.

## 4. RULINGS ON THE PROPOSED MENU

- "All 25 eligible (01–30 minus 08, 09, 17, 24, 25)" — correct SET, wrong delivery:
  25 in one run violates P5's inspectability clause, and clip 28 must not re-render.
  → governed by S1–S4.
- "Batch 3 only (21–30 minus 24, 25)" — DENIED as scope (S3). It would idle 17
  eligible clips for no gate reason.
- "A specific list I'll paste" — S1 + S4 above IS that list; no further input needed.
- "Skip" — not applicable; a scope question gets answered, not skipped.

## 5. OPERATOR LINE (paste to the editing agent)

"Pilot accepted; batch pattern approved [D7]. Card audio variant: [silent tail /
source music under card]. Typeface: [DejaVu placeholder signed off / font supplied].
Render the 24 remaining eligible clips — 01-30 minus 08, 09, 17, 24, 25, with 28
carried forward from the verified pilot (no re-render) — as four sub-batches of 6 in
this order: A 21,22,23,26,27,29 · B 30,01,02,03,04,05 · C 06,07,10,11,12,13 ·
D 14,15,16,18,19,20. Conform by per-source measurement, not by batch. Full QC per
clip; hard stop after sub-batch A until its QC is reviewed. All renders labeled
review_draft with disclosure block and QC tables; not release candidates. Scope
authority: R2-P5 (EDITING_AGENT_REVIEW_R2.md §2) + R3 rulings
(EDITING_AGENT_REVIEW_R3.md)."

---

# ADDENDUM R3-a — CARD-AUDIO VARIANT: MENU CORRECTION (same round, operator relay)
Trigger: the agent's option menu for the bracketed alternative in the pilot-acceptance
line ("accepted [or: accepted with the silent-card variant change]",
PILOT_CLIP28_REVIEW.md §6) offered two choices that do not match the recorded
variant set.

## 1. CORRECTIONS TO THE MENU

- FACT CHECK: the pilot AS RENDERED is the silent-card variant — 250 ms audio fade at
  card entry (13.933 s), then digital silence under the card (astats RMS −inf from
  14.0 s). The card does not "keep a fade under it"; the fade is the entry transition,
  and ~4.9 s of the 5.000 s card play in digital silence. Option 1's wording is
  imprecise; option 1's SUBSTANCE ("accepted as rendered") is valid and requires no
  re-cut of clip 28.
- STRUCK: the menu's option 2 ("true digital silence, cut instead of the 250 ms fade,
  re-cut clip 28 to match") is a NEW variant never ruled on. It has no compliance or
  retention benefit over the as-rendered fade, adds hard-cut click/jarring risk at
  card entry, and triggers an unnecessary clip-28 re-cut. Not adopted. If the operator
  explicitly wants the harder ending, it must be requested as such and logged as a
  deviation from the rendered pilot — the default remains the fade.
- MISSING: the menu omits the alternative actually on file — variant B
  (PILOT_CLIP28_REVIEW.md §5): extend the source's OWN music bed under the card at
  low level. Original audio only, M7-compliant (no ADDED music), and the only variant
  that addresses the recorded retention consideration (~26% of runtime
  silent-and-static). Choosing B means clip 28 IS re-cut and all 24 batch renders
  adopt it batch-wide.

## 2. THE VALID OPTION SET (operator picks ONE; decided once, batch-wide)

- VARIANT A — "Accepted as rendered" (silent tail): 250 ms fade at card entry, digital
  silence under the card. Clip 28 stands as delivered; batch copies the pilot pattern
  exactly. Zero re-cuts.
- VARIANT B — "Accepted with the source-music variant": the source's own music bed
  continues under the card at low level. Clip 28 re-cut to match; all 24 batch renders
  use this treatment. M7-compliant (source audio, not added music).

Both are compliant; the difference is taste/retention, which is exactly why the
operator's listen ([D7] item 1) decides it. Architect default: A, unless the silent
ending bothered the operator on watch/listen — B is the compliant fix for that case.

## 3. PASTE-READY LINES (pick one; fills the card-audio bracket of the R3 §5 line)

Variant A:
"Card-audio variant = A (silent tail), accepted as rendered: 250 ms fade at card
entry, digital silence under the card (RMS −inf from 14.0 s). Clip 28 stands as
delivered, no re-cut; batch renders copy the pilot pattern exactly. Source:
PILOT_CLIP28_REVIEW.md §5 + ADDENDUM R3-a."

Variant B:
"Card-audio variant = B (source-music continuation): extend the source's own music
bed under the card at low level — original audio only, M7-compliant
(PILOT_CLIP28_REVIEW.md §5 + ADDENDUM R3-a). Re-cut clip 28 to match; all 24 batch
renders use this treatment batch-wide."

## 4. PROCESS NOTE (standing)

Second menu divergence in this round-set (R3 §4 covered the render-scope menu omitting
the pilot path). Standing rule: when the agent builds option menus for operator
decisions, the options MUST be sourced from the recorded decision lists in the review
files (here: PILOT_CLIP28_REVIEW.md §4–§5), not reconstructed from memory. Any menu
option not traceable to a file must be labeled "PROPOSED — not on file" so the
operator can see it is new.

---

# ADDENDUM R3-b — EMPTY BRACKETS: WHAT THE BATCH ASSUMES (logo / font / rights)
Trigger: the operator line arrived with the logo / font / rights [fill] brackets
empty; the agent asked what to assume for the batch.

## 1. RULING: ALL PENDING — CARRY THE DISCLOSURES (the menu's option 1)

- An empty bracket is NOT a sign-off. Silence cannot manufacture consent — same
  honesty-layer principle as R3 §1 (unresolvable references: log, ask, never guess;
  the agent asked, which is correct). Option 2 ("derived mark signed off") is
  UNSUPPORTED: no R4(b) written confirmation exists anywhere in the record. Option 3
  is moot: no logo file, campaign font, or rights terms were supplied.
- What applies to the batch is therefore not an assumption of decisions but the
  DOCUMENTED DEFAULT STATE, confirmed by this ruling:
  - Derived mark stays, WITH the provenance disclosure (P1: sanctioned for labeled
    review drafts only).
  - DejaVu placeholder stays, WITH the placeholder disclosure.
  - Rights grant (intake Q3) stays OPEN.
  - Every render: review_draft label + disclosure block + QC table listing the three
    open items verbatim: "logo: R4 (a)/(b) pending · font: campaign-font decision
    pending · rights: intake Q3 grant pending".
- CONSEQUENCE LOG (accepted, not hidden): if a pending item later resolves to an
  official logo PNG or the campaign font, affected renders take ONE MORE PASS under
  the frozen pattern (R3-S5 logic extended to the font). That is the known cost of
  rendering under placeholders — the operator owns it by leaving the brackets empty.
  It is a scheduling cost, not a compliance defect: nothing submitted as release
  candidate ever carries an unresolved placeholder.

## 2. CARD-AUDIO CHECK (one line)

If the card-audio bracket in the same line was ALSO empty, variant A (silent tail,
as rendered) applies by default per R3-a §2 — zero re-cuts. If it was answered A or
B, apply as answered. Record which in the QC tables.

## 3. BATCH UNLOCK STATUS (R3 §3 preconditions, resolved)

1. [D7] batch-pattern approval — SATISFIED (the operator line was received; this
   round's empty brackets do not reopen it).
2. Card-audio variant decided — SATISFIED (answered A/B, or A-default per §2 above).
3. Typeface frozen — RESOLVED BY RULING: the R3 §3 hold existed so the batch would
   not inherit an UN-decided card pattern. The batch now inherits a DECIDED interim
   pattern — placeholder-by-ruling, disclosed, with the §1 consequence log — which
   satisfies the precondition's purpose. The design-system freeze remains OPEN as an
   operator decision; a later font decision triggers the one-more-pass clause, not a
   violation.

→ Sub-batch A (21, 22, 23, 26, 27, 29) may render NOW under these terms. Hard stop
after A until its QC is reviewed (R3-S4). Release candidates remain blocked on
R4 (a)/(b) + the rights grant.

## 4. MENU REVIEW (standing rule R3-a §4, applied)

This menu was well-formed: all three options map to real record states, and asking
instead of assuming on an empty bracket is exactly correct behavior — cited as the
second reference example of it. One nit for future menus: a "signed off" branch must
cite the artifact that constitutes the sign-off (operator message + date); option 2
cited none, which is how it could have been silently selected. Label such branches
with their constituting artifact or mark them unavailable.

## 5. OPERATOR LINE (paste to the editing agent)

"Batch proceeds under the all-pending default (ADDENDUM R3-b): nothing is signed
off — derived mark with provenance disclosure, DejaVu placeholder with placeholder
disclosure, rights grant (intake Q3) open. All 24 renders: review_draft labels +
disclosure blocks + QC tables listing three open items verbatim: 'logo: R4 (a)/(b)
pending · font: campaign-font decision pending · rights: intake Q3 grant pending'.
Card-audio variant: [A/B as answered — or, if that bracket was also empty: A
silent-tail default applies]. Sub-batch A = 21, 22, 23, 26, 27, 29 — render now;
hard stop after A until its QC is reviewed (R3-S4). If a pending item later resolves
to an official PNG or the campaign font, affected renders take one more pass under
the frozen pattern. Release candidates remain blocked on R4 (a)/(b) + the rights
grant. Authority: ADDENDUM R3-b (EDITING_AGENT_REVIEW_R3.md)."
