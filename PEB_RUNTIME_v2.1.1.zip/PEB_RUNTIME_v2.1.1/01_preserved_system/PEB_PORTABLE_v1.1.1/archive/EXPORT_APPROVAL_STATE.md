# EXPORT APPROVAL STATE — PEB / RexTrix system (snapshot 2026-10-28)

One-line states only. Locations are relative to `HANDOFF_PACKAGE_PEB_RexTrix_v1.0/` unless prefixed `extras/`.
Evidence tiers in the underlying documents: `[DIRECT]` (inspected here) / `[INHERITED-AUDIT]` (operator audit says so) / `[PROJECT-RULE]` (binding campaign rule). Application to a registry is NOT campaign approval. Zero skill bodies are feature-tested; zero cards are campaign-approved.

## 1. Approved and applied
- **Master prompt PRO_EDITOR_BRAIN v3.1.1 TEST FREEZE (2026-10-26)** + the 3 modules it references — `01_master_prompt/` (CORE, GRAPHICS, MOTION_PIPELINES, APPENDIX_REFERENCE + README manifest). Regression audit 102/102, paper tests 3/3, clip-28 pilot verified. Frozen baseline — still NOT cleared for unsupervised production runs (operator gate before every render batch).
- **SKILL_REGISTRY_v1.0** (`02_registry/`) — with the operator-approved additions applied 2026-10-28: P-R1 (SR-40…45 style/effect catalog) · P-C1 (3 catalog lines) · P-C2 (priority-reference block) · P-C3 (LIBRARY-INDEX, corrected to 9 libraries) · P-C4 (video-frames @steipete closed by logged rejection). Six corrections baked in (vanta reclassified engine-class; four-dimension permissions; language-preserving caption fallback; emphasis/FX counts demoted to optional guidance; testing claims scoped; stale upload-to-claude statement removed).
- **RESOURCE_INTEGRATION_REPORT_v1.2 + COVERAGE_RECONCILIATION_v2.1** (`07_status/`) — the six corrections applied; v1.0/v1.1 and v1.0/v2.0 preserved in `archive/`.
- **CAPTION_LIBRARY_v2 + EFFECTS_AND_CAPTIONS_SPEC_v2 bundle** (`04_catalogs_and_resources/Captions_and_Effects_v2/`) — structurally validated (counts, IDs, hashes, chain of custody); runtime rendering NOT performed (`VALIDATION_REPORT.json`: `runtime_rendering_performed: false`).
- **CATALOG_GUIDANCE_v1.0** (`04_catalogs_and_resources/`) — applied catalog routing layer.
- **Frozen production chain** — T0 FFmpeg-first, original-audio rule (audio lanes only), 9:16 / 30 fps / n/30 grid, operator approval gates, XR-3 fail-closed QC, XR-4 loudness corrections.

## 2. Approved but not applied
- **None at this time.** Every item the operator approved on 2026-10-28 (the six corrections + the catalog/reference additions) was applied at packaging time; the corrections were a precondition and were applied before the catalog changes.

## 3. Proposed only (HELD — do not apply without a new operator ruling)
- **P-R2** (registry §2 routing sentence) · **P-R3** (inventory row 13, styled captions) · **P-M1** (optional master-prompt sentence) — exact text in `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` §4.
- **P1–P3** minimal core patches — `07_status/PROPOSED_CORE_PATCHES_MINIMAL_v0.9.md` (P1 required / P2 verify-only / P3 optional).
- **v3.2 core integration** (folding `02_registry/PEB_v3.2_MODULE_TOOL_REGISTRY.md` into the core) — `PENDING_RULINGS.md` §B.
- **House-skill authoring** (loudness-chain, banned-claim-sweep, card-seam-discipline, delivery-QC) — gated on v3.2 integration.
- **SR-01…03 EXEC activation** (pin SHA + first-use fixture) · **SR-04 fork review**.
- **T4 Remotion / T5 tsrct / T7 InVideo rulings** · **T6 intake-sweep activation** · **G1–G4 adapter/capability builds**.

## 4. Superseded (preserved for lineage)
- `extras/download/SKILL_REGISTRY_PROTOTYPE_v0.9.md` → superseded by `02_registry/SKILL_REGISTRY_v1.0.md` (both shipped).
- PRO_EDITOR_BRAIN v2 / v2.1 / v2 patches / v3 / v3 appendix → superseded by the v3.1.1 TEST FREEZE (`archive/`).
- SKILL_SCAN_REPORT_v1 → v2 · COVERAGE_RECONCILIATION_v1.0/v2.0 → v2.1 · RESOURCE_INTEGRATION_REPORT_v1.0/v1.1 → v1.2 (`archive/` + `07_status/`).
- `05_components/v3_regression_audit.py` → superseded by `v31_regression_audit.py` for current files (kept for lineage, per COMPONENTS_MAP).
- Master-prompt construction parts (`scripts/peb_*_part*.md` in the source workspace) → superseded by the assembled, approved documents (not shipped; not byte-equivalent to the assembled docs).
- Raw operator inputs in `upload/` (pasted task texts, consult responses, original prompt copies) → superseded by processed versions in `archive/` and `04_catalogs_and_resources/`.

## 5. Unresolved (open questions, not approvals)
- **Probe report files (T3/T4/T5-PROBE-1) were never persisted as standalone files** — probe results survive only as recorded claims in the TOOL_REGISTRY cards, `07_status/STATUS_LEDGER.md` and inventory row 5. Treat as summarized evidence, not raw logs.
- **Caption preview media never delivered** — `previews/01…41*.jpg`, `caption_styles_raw.mp4`, `styles_v2_mobile.mp4`, `styles_v3_18s.mp4`, `styles_v4_2min.mp4` are referenced by CAPTION_LIBRARY_v2 but absent from the delivered bundle (see EXPORT_README).
- **Licensing unverified for all reference-tier/community material**; **provider availability unverified** (e.g. MaxFusion MCP); **campaign approval count = zero** — four separate dimensions, never inferred from one another.
- **Campaign-side operator decisions**: R4(a)/(b) logo/wordmark, rights grant, font sign-off, sub-batch A approval + B/C/D unlocks, brief items Q1/Q2/Q5/Q6/Q7/Q9.
- **Open capability gaps G1–G4**; **T3 styled-caption compositions untested** (pipeline probe-verified ≠ composition-tested); **T5 unprobed features**; **T6 known-card fixture** specified but not yet created (queued gate).

## 6. Delivery-rebuild closure note (2026-10-28)
- **Outer 20-pack zip member equivalence — CLOSED at the export rebuild.** The formerly open item ("outer zip never compared; prior verification covered only the 20 upload-to-claude members, 80/80") was closed by a read-only member-level comparison (`scripts/check_vendor_zip_overlap.py`, source workspace) prompted by a delivery failure: of the outer `claude-motion-styles-20.zip`'s 126 entries, 84 real files are byte-identical (SHA-256) to the shipped loose tree, 20 are the already-80/80-verified `upload-to-claude/` wrapper zips, and 22 are directory entries — zero unique real content. Consequence: the outer vendor zip is EXCLUDED from the rebuilt export (26.9 MB → ~13.5 MB, 179 → 178 files; system files unchanged); the original remains in the source workspace `upload/`. This is a delivery-packaging fix only — no approval state above is affected by it.
