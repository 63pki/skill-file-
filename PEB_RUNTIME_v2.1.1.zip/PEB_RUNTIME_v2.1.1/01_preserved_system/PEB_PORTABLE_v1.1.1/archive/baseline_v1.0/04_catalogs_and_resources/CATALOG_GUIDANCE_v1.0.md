# CATALOG GUIDANCE — Caption/Effects/Style Catalogs (v1.0, 2026-10-28)

**What this is:** the operating guidance for the catalog resources in this folder. It consolidates the corrected routing table and rules from `../07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` (§3) with the operator's six corrections of 2026-10-28 baked in. The registry cards SR-40…45 (`../02_registry/SKILL_REGISTRY_v1.0.md`) point here for treatment selection; the library bodies listed below are loaded per selected treatment, never wholesale.

## 1. The catalog bodies (this folder)

| Body | File | What it is |
|---|---|---|
| Caption library v2 | `Captions_and_Effects_v2/CAPTION_LIBRARY_v2.md` | 41 styles (CAP01–CAP41) + governance contracts (authority/evidence, selection-by-job, caption-vs-title-vs-demonstration, timing/geometry, corrected ASS notes). |
| Effects spec v2 (structured) | `Captions_and_Effects_v2/EFFECTS_AND_CAPTIONS_SPEC_v2.json` | 24 caption_styles + 45 video_effects + 8 sound_effects + 41 catalog + 6 motion_recipes + 8 web_ui_resources. `runtime_rendering_performed: false` — a structural reference, not a tested renderer. |
| Schema | `Captions_and_Effects_v2/EFFECTS_AND_CAPTIONS_SPEC_v2.schema.json` | Draft 2020-12 structure validation only. |
| Manifest / provenance | `Captions_and_Effects_v2/FILE_MANIFEST.json`, `Captions_and_Effects_v2/REVISION_NOTES.md`, `Captions_and_Effects_v2/VALIDATION_REPORT.json` | 8/8 SHA-256 verified; chain of custody intact; authors' validation scope = structure only. |
| Web/UI routing policy | `Captions_and_Effects_v2/WEB_UI_VIDEO_ROUTING_CORRECTION.md` | Per-resource adapter limits for the 8 web_ui_resources (cube-motion, oil-motion, shadercn/TypeGPU, hairline, evil-buttons, matter-js, p5.brush, gsap). |
| Preserved originals | `Captions_and_Effects_v2/originals/` | The UNcorrected v1 predecessors — retained as evidence, never production instructions. |
| 20-style motion pack | `claude-motion-styles-20/` | 20 style dirs (each with its own SKILL.md, template.html, preview.jpg and the byte-identical shared render.py) + pack-root extras. The pack's render.py is a RETAINED REFERENCE (Playwright frame-stepping, `renderFrame(t)` contract) — NOT the production renderer; T3 owns that category. The pack's `upload-to-claude/` zips are excluded here as verified byte-identical duplicates of the loose dirs (80/80 SHA-256 — `../07_status/evidence/pack_equivalence_result.json`). |
| Pastel-indigo style | `pastel-indigo-motion-graphics/SKILL.md` | HyperFrames-native style contract, 18 recipes (1–6 author-claimed tested; 7–18 sketches). |
| Malayalam workflow | `malayalam-pastel-reel-edit/SKILL.md` | End-to-end multilingual keyword-caption workflow; strip authoring-env instructions before reuse. |
| SaaS animation guide | `SaaS-Animation-Videos-with-Claude.pdf` | Course PDF (© course material — cite patterns, never reproduce). Reference-only; its Remotion/ElevenLabs stack is gated. |

## 2. Permissions model (four separate dimensions — never inferred from one another)

1. **Licensing review** — legal rights per layer (registry §6: REPO/FILE/ASSET/DEP). E.g., 20-pack = README grant (use/remix incl. client work, no pack resale; no LICENSE file); caption libraries + the two SKILL packs = no license statement (operator-recovered material — confirm at adoption); SaaS PDF = © course material, reference use only.
2. **Campaign permission** — the operator's ruling for the campaign at hand. Currently: no catalog entry is campaign-ruled.
3. **Provider availability** — whether a required service/account is verified in this environment. Currently: no visual-generation or audio-generation provider is verified; Remotion = T4 license gate; ElevenLabs = provider gate.
4. **Optional house preferences** — style defaults the operator may set per campaign; never laws.

**The original-audio-only rule governs AUDIO lanes only.** It neither prohibits nor permits visual-generation lanes — visual generation follows the four dimensions above on its own facts. Do not infer one dimension from another.

## 3. Standing selection rules (corrected 2026-10-28)

- **Treatment selection is need-driven.** Consult the catalog only when a communication need exists; `no added treatment`, `clean cut`, and `held shot` are valid selections recorded like any other (this is also the v2 library's own `no_effect_is_mandatory: true`).
- **Emphasis counts are OPTIONAL craft guidance, not laws.** E.g., "one justified emphasis per beat" is advisory; the selection gate (communication need + campaign gates) governs. Same for any per-style count in the library bodies.
- **High-energy FX examples are EXAMPLES, not defaults.** The 45 FX families and their "high-energy opener" use class are optional guidance; suitability is judged per segment through the selection gate.
- **Caption fallbacks preserve language and accessibility.** Same-language clean caption first. English-only keywords are NOT an automatic Malayalam fallback (or a fallback for any other language); a language switch or translation is an OPERATOR decision; keep the sidecar transcript.
- **SFX family (8 IDs) is default-inactive** — audio provenance gate; needs authorization + asset files.
- **Text = spoken words only** for speech captions; no rewrites that hide negations. Banned-claim gate applies to every on-screen claim (source + date + units for stat cards).

## 4. Routing table (per resource family — corrected version)

| Family | Trigger (editorial need) | Suitable | Unsuitable | Required inputs | Renderer | Implementation status | Accessibility risks | Fallback | Verification needed |
|---|---|---|---|---|---|---|---|---|---|
| Speech captions (CAP 09/17/19/30 class) | Clarify dialogue, noisy audio, accessibility baseline | Talking-head, interviews | Reaction beats where faces carry meaning; every-word popping | Word timings (T1, estimates) + transcript sidecar | T3 text or FFmpeg libass | Recipe contracts; no renderer tested in this project's chain | Contrast, reading load, script shaping, safe areas | Static clean caption (same language) | Fixture render + human frame review |
| Emphasis/keyword styles (01/02/06/16/18/37…) | Emphasis moments justified via the selection gate (count guidance is OPTIONAL, not a law) | Keyword moments | Unjustified emphasis stacking (per-beat counts advisory) | Approved claim/word | T3 | Motion recipes (design contracts) | Overshoot bounds, gradient fill support | Plain bold color word (same language) | Bounds inspection incl. overshoot frames |
| Stat/claim cards (07/15/21/39) | Communicate a verified result | Approved numbers only | Unverified claims | Source + date + units | T2/T3 | Static cards PROVEN (inventory row 4) | Units, qualifier visibility | Plain text card | Claim check + readability |
| FX transitions/graphics (45 FX) | Hook, section change, comparison | High-energy openers (EXAMPLE use class — optional guidance, never defaults) | Quiet reveals; documentation tone | Source action supporting it | T3 (web-class) or FFmpeg (simple) | Legacy sketches deprecated → new T3 compositions needed | Flash risks (QC flash_review) | Hard cut | Flash/strobe review + fixture |
| 20-style pack templates | Ambitious motion treatment that improves communication | Brand-appropriate stylized segments | When style ≠ brand or overwhelms meaning | Text + palette params | **T3 via adapter** (adapter MISSING — gap G1; never the pack's Playwright path) | template.html → T3 composition mapping (bounded adaptation, fixture before reliance) | Fonts (system fallbacks), bounds | Simpler style | Determinism seek test + fixture |
| Pastel-indigo style | Explainer/talking-head with designed graphics | 16:9 or 9:16 explainers | Brands whose palette conflicts (tokens must NOT be reinvented) | Speaker footage + script | T3 (native fit) | Recipes 1–6 author-claimed tested — re-verify on first use | HUD clutter on small screens, serif legibility | Reduced-motion variant | Snapshot QC per beat |
| Malayalam workflow | Multilingual (Malayalam) keyword captions | Malayalam talking-head | Full-subtitle volume (it teaches keywords, not walls) | Script as timing source (±0.2–0.3 s) | T3 | Template embedded; env instructions stripped | Conjunct shaping, mask height, font verification | **Same-language first:** clean Malayalam caption via T3 text, conjunct-safe font; language switch = operator decision; English-only keywords are NOT an automatic fallback; sidecar transcript preserved | `fc-list :lang=ml` + render test line first |
| SFX family (8 IDs) | — | — | **Default inactive** | Authorized asset files + operator ruling | FFmpeg amix/alimiter path exists | Provenance gate: new audio needs authorization | Mix balance (−14 LUFS chain stays ours) | No SFX | Loudness + listen check when authorized |
| SaaS PDF patterns | SaaS/product promo structure | Product demos | Its specific stack | Logo, real clips/screens | T3 equivalent | Check-frames + storyboard-first patterns reusable | Vertical safe areas | — | — |

## 5. Honest testing status of the catalog bodies

Structurally verified in this project (counts, IDs, hashes, chain of custody, 20× identical render.py, packaging equivalence 80/80). NOT runtime-tested here: any render, template execution, determinism-under-seek in T3, libass rendering of ASS sketches, Malayalam conjunct shaping in this environment, gsap-lite behavior. Author-produced preview assets (the per-style preview.jpg files and `claude-motion-styles-20/PREVIEW-all-20-styles.mp4`) exist as files but were not watched or accepted as rendering evidence. First use of any treatment requires a fixture through the declared renderer path before reliance (fixture-first rule, inventory row 5/11 contracts).
