# START HERE — PEB / RexTrix Fresh-Session Handoff Package (v1.0, 2026-10-28)

You are restarting in a fresh session. This package is the complete, self-contained state of the **Pro Editor Brain (PEB)** video-editing system for the **RexTrix** campaign: the approved master prompt and modules, the updated skill registry, the implementation inventory, the caption/effects catalogs with their resource files, the reusable components, setup instructions, and the explicit tested/untested/gated status of everything. Historical audits are archived at the back — they are NOT mandatory startup reading.

## 0. What happened just before this package (one paragraph)

On 2026-10-28 the operator **conditionally approved** the proposed catalog/reference additions, required **six limited corrections** first (stale upload-to-claude statement removed; testing claims scoped to this review's actual limits; itsjwill/vanta rechecked directly and reclassified — it is a Remotion-based AI video engine, NOT a WebGL-background library; permissions split into licensing review / campaign permission / provider availability / optional house preferences; caption fallbacks made language-preserving; emphasis counts and high-energy FX examples demoted to optional guidance), and then ordered **only the approved catalog/reference changes applied** plus this handoff package. The corrections are delivered in `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md` and `07_status/COVERAGE_RECONCILIATION_v2.1.md`; the application lives in `02_registry/SKILL_REGISTRY_v1.0.md`. The master prompt and core architecture were NOT rewritten; nothing was installed; nothing was rendered.

## 1. Reading order (mandatory → on-demand)

| # | Read | File | Why |
|---|---|---|---|
| 1 | **Mandatory first** | `01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md` | THE master prompt (v3.1.1 TEST FREEZE, 2026-10-26). Self-sufficient for intake, editing, QC, delivery. Its FILE MAP tells you when to load the other modules. |
| 2 | Mandatory | `01_master_prompt/README.md` | File manifest + attach rules (which files attach to a campaign run, in what order). |
| 3 | Mandatory | `02_registry/SKILL_REGISTRY_v1.0.md` | The updated skill registry — 20 numbered cards, 13 catalog lines, 7 priority-reference lines, LIBRARY-INDEX (9 libraries), closures. Routing rules + permissions model live here. |
| 4 | Mandatory | `02_registry/PEB_v3.2_MODULE_TOOL_REGISTRY.md` | Tool capability catalog T0–T7 + lazy-install gate. The registry's T-numbers resolve here. |
| 5 | Mandatory | `03_implementation_inventory/IMPLEMENTATION_INVENTORY_v0.9.md` | The 12 TESTED components. Check here BEFORE building anything. |
| 6 | Mandatory | `07_status/STATUS_LEDGER.md` | Explicit tested / untested / gated status of everything. |
| 7 | Mandatory | `07_status/PENDING_RULINGS.md` | What is still HELD and needs an operator ruling. Do not apply held items. |
| On demand | Campaign context | `campaign_context/CAMPAIGN_BRIEF_RexTrix.md` | The ready-to-attach RexTrix brief (verified master-intake edition). |
| On demand | Graphics work | `01_master_prompt/PEB_v3.1_MODULE_GRAPHICS.md` | When the edit involves any graphic/title/annotation/endboard. |
| On demand | Motion pipelines | `01_master_prompt/PEB_v3.1_MODULE_MOTION_PIPELINES.md` | Keyframes, stabilization, bg removal, layered compositing. |
| On demand | Intake/render/QC | `01_master_prompt/PEB_v3.1_APPENDIX_REFERENCE.md` | Campaign-profile schema, signal sidecar, rhythm tables, encode pattern, disclosure templates. |
| On demand | Treatment selection | `04_catalogs_and_resources/CATALOG_GUIDANCE_v1.0.md` | How to route caption/effects/style needs to the catalog bodies (with the six corrections baked in). |
| On demand | Setup | `06_setup/DEPENDENCIES_AND_SETUP.md` | Toolchain, fonts, install commands (TEXT ONLY — installs are gated). |
| On demand | Components | `05_components/COMPONENTS_MAP.md` | The actual reusable scripts, mapped to inventory rows. |
| On demand | Evidence | `07_status/RESOURCE_INTEGRATION_REPORT_v1.2.md`, `07_status/COVERAGE_RECONCILIATION_v2.1.md`, `07_status/evidence/` | The current corrected reports and structural-test evidence. |
| **Not required** | History | `archive/` | Historical audits, older versions, campaign review rounds. Reference only — never mandatory startup reading. |

## 2. Frozen production chain (do not violate)

- **T0 FFmpeg first**: cuts/conform/concat/static graphics/loudness/encode/QC are solved at production scale — never re-solve solved problems (inventory rows 1–4, 8).
- **Original audio only** (audio provenance rule). Audio transforms on original audio (atempo/afade/adelay/loudness) are provenance-neutral conform ops. NOTE: this rule governs AUDIO lanes only — it neither prohibits nor permits visual-generation lanes (see the four-dimension permissions model in the registry).
- 9:16 vertical, 30 fps, PTS = n/30 grid, operator approval gates before renders, fail-closed QC (XR-3), loudnorm two-pass + alimiter + ebur128 with XR-4 corrections.
- One primary production renderer: **T3 HyperFrames (pinned 0.8.207)** for motion graphics; the 20-pack's Playwright render.py is a RETAINED REFERENCE implementation, not production.

## 3. What is approved vs held (snapshot)

**Approved & applied (2026-10-28):** P-R1 (SR-40…45 STYLE/EFFECT CATALOG cards) · P-C1 (3 catalog lines) · P-C2 (PRIORITY REFERENCE block) · P-C3 (LIBRARY-INDEX, corrected to 9 libraries) · P-C4 (video-frames closed by logged rejection). All with the six corrections baked in.

**Still HELD — do not apply without an operator ruling:** P-R2 (routing sentence) · P-R3 (inventory row 13) · P-M1 (optional prompt sentence) · P1–P3 (core patches, see `07_status/PROPOSED_CORE_PATCHES_MINIMAL_v0.9.md`) · v3.2 core integration · SR-01…03 EXEC pin+fixture · house-skill authoring · T4/T5/T7 rulings · G1–G4 adapter/capability builds · any install · any render.

**Standing rules:** operator inputs are persisted + hashed at receipt (`archive/OPERATOR_INPUT_2026-10-28/` is the first instance of that process). Evidence tiers are labeled [DIRECT] / [INHERITED-AUDIT] / [PROJECT-RULE] and never mixed. Zero skill bodies are feature-tested; zero cards are campaign-approved — registry application is not campaign approval.

## 4. Package map

```
HANDOFF_PACKAGE_PEB_RexTrix_v1.0/
├── START_HERE.md                     ← you are here
├── PACKAGE_MANIFEST.md               every file + SHA-256 (verify integrity)
├── 01_master_prompt/                 approved master prompt + 3 required modules + manifest
├── 02_registry/                      SKILL_REGISTRY_v1.0 + TOOL_REGISTRY + paper-routing tests (3/3 PASS)
├── 03_implementation_inventory/      12 tested components + known-NOT-verified list
├── 04_catalogs_and_resources/        catalog guidance + CAPTION_LIBRARY_v2 + effects spec v2
│                                       + 20-style pack (loose dirs; upload-to-claude/ zips excluded
│                                       as verified byte-identical duplicates — see 07_status/evidence/)
│                                       + pastel-indigo + malayalam workflow + SaaS PDF
├── 05_components/                    actual reusable scripts + COMPONENTS_MAP
├── 06_setup/                         DEPENDENCIES_AND_SETUP (text-only install commands)
├── 07_status/                        STATUS_LEDGER + PENDING_RULINGS + current reports + evidence
├── campaign_context/                 RexTrix brief + scout prompt v2 + correction notes
└── archive/                          33 historical files + operator input records (NOT startup reading)
```

## 5. First actions in a fresh session

1. Read items 1–7 of the reading order.
2. Verify package integrity against `PACKAGE_MANIFEST.md` if desired (SHA-256 per file).
3. Acknowledge the operator directive (registry §0) in your project record.
4. For a campaign run: attach `01_master_prompt/` files per the manifest + the campaign brief + authorized footage + brand assets. For RexTrix, use `campaign_context/CAMPAIGN_BRIEF_RexTrix.md`.
5. Do NOT install tools, render, add cards, or apply held patches without an explicit operator ruling.

## 6. Compliance statement for this package

Packaging only: no tools installed, no archive code executed (copying + hashing only), no providers called, no renders, no master-prompt edits, no core changes. The `upload-to-claude/` zips of the 20-pack were excluded from the package as verified duplicates (80/80 SHA-256 member equivalence vs the loose directories — full record in `07_status/evidence/pack_equivalence_result.json`); the loose directories ARE included and are the working material.
