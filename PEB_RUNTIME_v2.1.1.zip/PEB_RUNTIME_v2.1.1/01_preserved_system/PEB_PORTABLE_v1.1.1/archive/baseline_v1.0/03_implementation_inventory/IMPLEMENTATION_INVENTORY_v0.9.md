# IMPLEMENTATION INVENTORY — v0.9 (companion to SKILL REGISTRY PROTOTYPE)

**Purpose:** the agent checks HERE before building anything. Every row is a tested component with evidence. Rebuilding a row needs a logged reason the tested component fails the need.

**Sources of truth:** TOOL_REGISTRY v3.2.2 cards · probe reports (T3/T4/T5-PROBE-1) · R5 rulings (XR-1..XR-8) · frozen-chain production record.

| # | Need | Tested component | Evidence status | Rebuild rule |
|---|---|---|---|---|
| 1 | Cuts, conform, concat | FFmpeg frame-drop de-interpolation; per-segment render → `-c copy` concat seam | Production scale (frozen chain) | Never rebuild; the seam IS the pattern |
| 2 | Program loudness | loudnorm two-pass + alimiter + ebur128 QC | Measured (clip-28; XR-4: identical targets/preprocessing; `adelay=3S` is SAMPLES not ms; impulse latency test mandatory) | Never rebuild; XR-4 corrections are mandatory reading |
| 3 | Encode | H.264/AAC, CRF-disciplined | Production | Presets from project manifest only |
| 4 | Static graphics / end cards | T0 drawtext/overlay + T2 Pillow/CairoSVG | Production-proven | Static cards are SOLVED — do not re-solve with new tools |
| 5 | Animated cards / motion graphics | T3 HyperFrames pinned 0.8.207 | Probe 9/9: exact frame grid, CRF monotonic, ProRes 4444 alpha (default on mov), byte-identical determinism ×3, audio routing enforced (`data-has-audio`), frame-accurate ingest, font-fallback + `check` lint | Segment render → FFmpeg concat; integer 30 fps when integrating with frozen n/30 grid; determinism contract (no wall-clock/random/network in comps) |
| 6 | Transcription | T1 faster-whisper, small int8 (base fallback) | Production | Word timestamps are estimates — never ground truth for claim decisions |
| 7 | On-screen-text sweep | T6 OCR pattern: sample N frames → OCR → grep banned-claim vocabulary | Card + smoke spec (known-card fixture) | "No hits found" ≠ "no claims exist"; human frame review stays for Tier-0 |
| 8 | QC measurement | blackdetect / freezedetect / ebur128 / hashing / frame extraction | Production | Fail-closed QC per XR-3 (negative fixtures included) |
| 9 | Metadata hygiene | `ffmpeg -map_metadata -1 -c copy` | Card | Clean manifest when required; hygiene only — no distribution effect |
| 10 | Audio transforms on original audio | atempo / afade / adelay / loudness chain | Chain + XR-4 | Provenance unaffected — conform ops on original audio are chain-legal (see registry §6 audio distinction in PROPOSED patch P3) |
| 11 | Deterministic rendering | T3 determinism contract (probe-verified) | Probe | Any new render path must honor: no Date.now/Math.random/wall-clock timers/uncontrolled fetches |
| 12 | Alpha intermediates | ProRes 4444 via T3 (`--format mov`, yuva444p12le) | Probe (per-pixel alpha verified) | For FFmpeg overlay pipelines; QC gates pix_fmt |

**Known NOT-verified (do not assume):** T5 tsrct unprobed features (keyframes, time-remap, adjustment layers, audio layers, groups, HDR) · T4 Remotion runtime (license-gated) · any cloud/account path (default-OFF) · T3 `check` browser phase on new machines (re-verify before trusting "0 issues").

**Rule of order:** inventory → house pattern → registry card → (only then) new build with logged justification.
