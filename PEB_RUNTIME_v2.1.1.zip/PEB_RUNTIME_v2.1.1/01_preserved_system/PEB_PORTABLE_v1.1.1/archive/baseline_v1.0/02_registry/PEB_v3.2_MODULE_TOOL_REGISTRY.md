# PEB v3.2 MODULE — TOOL REGISTRY (capability catalog + lazy installation)
Status: PROPOSED MODULE for the next campaign start. Does NOT modify the frozen v3.1.1
core. The live RexTrix v1 run continues on its frozen FFmpeg chain (SA-4 pattern
discipline) — this module governs need-detection and installation from the next brief
reconciliation onward.
Verification: web-verified 2026-10-27 by research agent Task 20-a (sources in §9).
Marketing claims are tagged [claim]; official-source facts are tagged [verified].
In-sandbox smoke tests remain the final proof at install time (verify-before-use,
core §1: "A reported capability is not proof the installed version supports it").
v3.2.1 (2026-10-27): cross-reviewed against a second independent capability guide
(On_Demand_Video_Tool_Guide.md, same date). Convergent architecture confirmed; merged:
the four-state status model (§1a), T3 authority/audio-routing/determinism warnings,
T4 version-discipline note, T5 license-snapshot caution, G3 re-read rule.

## 1. THE PATTERN (why this module exists)
The agent knows FFmpeg natively — capabilities, limits, escape hatches. That knowledge
is what lets it decide when FFmpeg is enough. Every OTHER tool deserves the same
treatment, at near-zero cost:
- CAPABILITY CATALOG — always in the brain. This module. Text, no installs, no disk,
  no licenses. The agent cannot reach for a tool it does not know exists or does.
- LAZY INSTALLATION — deferred, gated, justified. The catalog is loaded by default;
  NO tool is installed by default. An install happens only when a reconciled brief
  triggers a card's conditions AND passes the install gate (§3).
This resolves the exact gap observed in production: the agent can install tools on
command but did not know WHICH tool serves WHICH editing need. Now every need has a
named escalation path (§2), and every escalation is logged.

## 1a. CAPABILITY STATUS MODEL (four distinct states — never conflated)
Every tool/feature claim is classified as exactly ONE of:
- DOCUMENTED — official docs/license state it. Never sufficient alone.
- INSTALLED — pinned version present in the sandbox manifest. Does not imply tested.
- FEATURE-TESTED — passed a logged fixture in the target environment (smoke test or
  probe artifact: rendered file + ffprobe/hash evidence, stored with the card).
- APPROVED-FOR-PROJECT — operator sign-off for THIS campaign's use.
Only FEATURE-TESTED and APPROVED-FOR-PROJECT claims may appear in QC tables as verified
capabilities. A package list, a vendor promise, or another agent's environment never
upgrades a state. Vendor skills supply technical guidance, never authority over the
campaign profile (aspect ratio, fps grid, audio policy, approval gates, rights).

## 2. SELECTION LADDER (FFmpeg-first, need-driven escalation)
1. FFmpeg/ffprobe sufficiency check FIRST: if the job is cuts/conform/concat/static
   text and graphics (drawtext/overlay)/loudness (loudnorm+ebur128)/encode/QC
   measurement — FFmpeg does it, proven at production scale (RexTrix v1). No install.
2. ESCALATE only on an unmet need, to the ONE card whose trigger matches, via the
   install gate. Escalation reason goes in the log: need → card → expected capability.
3. ONE TOOL PER CATEGORY (§6). Never install two tools that cover the same category.
4. NEVER escalate mid-campaign without a pattern-amendment ruling (§7).

## 3. INSTALL GATE (procedure, in order)
G1. NEED: state the unmet need in one line, tied to a brief field (not curiosity).
G2. MATCH: name the registry card whose trigger matches.
G3. LICENSE: check the card's license class against §4. Restricted-class = STOP,
    ask the operator in writing, attach the exact clause. Clause quotes in §4 are
    snapshots — re-read the live LICENSE/TERMS at install time; never bake a changing
    threshold into the master prompt.
G4. APPROVAL: free-class tools (Apache-2.0/MIT/BSD) may be installed with logged
    justification. Clause-class and account-class tools require written operator
    approval BEFORE install. Cloud/account features are default-OFF.
G5. TELEMETRY: any tool with default-on telemetry is disabled immediately after
    install, before any client material touches it.
G6. PIN: record exact installed version + source in the project manifest.
G7. SMOKE TEST: verify the card's claimed core capability in-sandbox on a fixture
    (render a test segment, measure it, compare to the claim). A claim that fails the
    smoke test is recorded in the card and the tool is quarantined for that need.
G8. AFTER-ACTION: record verified capabilities/limits found during real use back into
    the card (§8). The registry is evidence-based, not marketing-based.

## 4. LICENSE GATE (classes)
| Class | Examples | Install rule |
|---|---|---|
| FREE-OPEN | HyperFrames (Apache-2.0), Tesseract OCR (Apache-2.0) | Install freely, justification logged |
| FREE-CLAUSED | Remotion (headcount-gated), tsrct by Mirage (revenue-gated) | Operator written approval BEFORE install, clause quoted |
| ACCOUNT/CLOUD | HeyGen cloud render, hosted HyperFrames MCP, Remotion Lambda, InVideo MCP | Operator pre-approval per campaign; default OFF; never required for local work |

Clause texts that matter (quote to the operator when asking):
- Remotion: free for individuals AND organizations up to 3 employees; 4+ employees
  requires a Company License — $25/mo per creator seat and/or $0.01 per render with a
  $100/mo minimum (combined floor $100/mo). Headcount is company-wide. [verified]
- tsrct: free including commercial use, BUT any for-profit business (or its
  commissioned work) with ≥ US$1,000,000 trailing-12-month revenue ("Covered
  Business") needs a separate written agreement from Mirage. If the CLIENT is a
  Covered Business, this clause reads on the client relationship — ask before use.
  License revocable; $100 liability cap. [verified]

## 5. TOOL CARDS

### T0 — FFmpeg/ffprobe (BASELINE, in use, verified at production scale)
- Covers natively: cuts/concat/conform (frame-drop de-interpolation), drawtext/overlay
  static graphics, loudnorm two-pass + alimiter + ebur128 QC, H.264/AAC encode,
  blackdetect/freezedetect, stream copy/remux, hashing, frame extraction.
- Sufficiency boundary: the reference for every escalation decision. Static end
  cards (RexTrix v1 pattern) live here and are PROVEN — do not re-solve solved
  problems with new tools.

### T1 — faster-whisper (in use)
- ASR with word timestamps; small int8 default, base fallback. Limits: timestamps are
  estimates, not guaranteed ground truth (core language unchanged).

### T2 — Pillow/CairoSVG (in use)
- Static raster/vector graphics for overlays. Boundary: no timeline, no motion.

### T3 — HyperFrames (HeyGen) — DEFAULT motion-graphics compositor [NEW]
- IDENTITY: open-source (Apache-2.0) HTML-to-video engine: HTML/CSS/JS compositions,
  timing via data-start/data-duration on class="clip" elements, headless-Chrome
  frame-stepping, FFmpeg encode. CLI 0.8.207 (2026-10-27), ~73k stars, no account,
  local-only path is fully free ("no per-render fees or commercial-use thresholds").
  [verified]
- CAPABILITIES (beyond FFmpeg/Pillow): animated end cards, kinetic typography,
  lower-thirds, captions-as-design, charts, composed explainers mixing REAL footage
  (<video> ingest; H.264 MP4 native, HEVC/ProRes auto-proxied) with animated overlays;
  registry blocks (npx hyperframes add); check command audits layout, runtime errors,
  and WCAG contrast in one pass (maps to our safe-area discipline); skills router;
  encode control: --crf (default quality "looks" = CRF 16), --fps accepts RATIONAL
  values (30000/1001 forwarded verbatim), keyframe-interval/max-bitrate; ProRes 4444
  alpha, VP9-alpha WebM, PNG-sequence RGBA intermediates; deterministic renders.
  [verified]
- PERFORMANCE: measured ~300 frames @1080p in 9.8 s optimized / 25 s worst-case; a
  600-frame (20 s) vertical comp ≈ 20–50 s on that machine class; 4K ≈ 4× slower.
  [verified]
- HARD LIMITS: Node.js ≥22 + bundled Chromium + FFmpeg host footprint; per-frame
  browser rendering (minutes at 4K); audio mixing + normalize-audio exist but PROGRAM
  loudness stays in the FFmpeg chain (our loudnorm/alimiter/ebur128 regime is the
  spec — do not duplicate it); cloud render / hosted MCP / Studio sign-in are account
  class — default OFF. [verified]
- AUTHORITY WARNING: vendor skills and examples contain creative defaults (landscape
  orientation, 30 fps, add-music/SFX suggestions for longer films). These are technical
  guidance, NEVER authority — they do not override the campaign brief (9:16, fps grid,
  original-audio-only policy, approval gates, rights). Import selective technical
  instructions only.
- AUDIO ROUTING: visible media is not automatically audible — current docs use
  data-has-audio for video audio; verify routing explicitly per composition.
- DETERMINISM: no random or time-based animation, no wall-clock timers, no uncontrolled
  network assets inside a render composition. Browser preview format support can differ
  from render support; preview proxies may be required.
- TRIGGERS (brief-level, at reconciliation): animated or motion end card (a brief
  demanding more than the static card pattern); lower-thirds with motion; styled
  kinetic captions; parameterized A/B variant generation of any card design; composed
  segments needing alpha intermediates (ProRes 4444/WebM alpha) for FFmpeg overlay.
- NEVER-USE: conform, loudness, body cuts, QC measurement, or anything the frozen
  FFmpeg chain already does. Render the SEGMENT (e.g., a 5 s card), then concat/encode
  in FFmpeg — same seam discipline as the current card pipeline. Strip provenance
  metadata tags (ffmpeg -map_metadata -1 -c copy) if a clean manifest is required.
- INSTALL GATE: class FREE-OPEN. Pin version; smoke test = render a 1 s fixture at
  1080×1920@30000/1001, verify frame count + CRF control + ProRes-alpha export path.

### T4 — Remotion — CONDITIONAL, license-gated alternative to T3 [NEW]
- IDENTITY: React-based programmatic video framework, 4.0.539 current. Mature
  distributed rendering (Lambda: cents per simple render; measured $0.001 hello-world
  → $0.103 10-min HD). React-only — no plain-HTML authoring mode. [verified]
- LICENSE: FREE only for individuals/organizations ≤3 people; 4+ employees = Company
  License ($25/mo/seat and/or $0.01/render, $100/mo minimum, license changing in 5.0).
  [verified]
- TRIGGERS: ONLY if (a) the operator qualifies for the free license or has paid the
  Company License in writing, AND (b) the brief needs Remotion-specific ecosystem
  (Lambda distributed rendering at volume, @remotion/player, @remotion/captions).
  Otherwise T3 covers the category with no license exposure.
- VERSION DISCIPLINE: do not copy a newer documentation example into an older pinned
  package without verifying the API against the installed version.
- NEVER-USE: in a 4+-person org without the license; alongside T3 in the same project
  (one compositor per category, §6).

### T5 — Tesseract by Mirage (tsrct) — VERIFY-FIRST NLE-class candidate [NEW]
- IDENTITY: free local agentic video-editing suite — Rust CLI + agent skills +
  ChatGPT/Codex plugin; native Vulkan engine + FFmpeg libs; .tsrct ZIP project model
  (groups/layers/keyframes/audio layers, JSON checkout→commit, no track timeline);
  100% local, no account. Version 0.4.0 (2026-10-13) — our old seed datum was
  CURRENT, not stale. [verified] Project is ~6 weeks old, 160 stars — early.
  [verified]
- CAPABILITIES (beyond FFmpeg): NLE-style NON-DESTRUCTIVE editing of real footage —
  keyframes, adjustment layers, time remapping, multi-layer compositions, editable
  audio layers with timed envelopes; preview/filmstrip QC artifacts; HDR (PQ/HLG),
  ACES 2.0 color. "250+ AI-native video tools" = [claim], unenumerated publicly.
- HARD LIMITS [verified]: integer fps export ONLY (no 30000/1001); auto bitrate
  (≈10 Mbps @1080p30) with NO manual CRF control; Linux bundle has NO H.264 encoder —
  final encode MUST use an external FFmpeg (--encoder-backend external-ffmpeg-command),
  so the pipeline stays FFmpeg-native at the seam anyway; Vulkan/GPU adapter required
  (lavapipe software fallback works); canvas 7680 px/side; telemetry ON by default —
  disable before any client material; Claude Code plugin not shipped yet; no MCP.
- LICENSE: FREE-CLAUSED (proprietary freemium) — the ≥$1M "Covered Business" written-
  agreement clause in §4 applies; revocable; $100 liability cap. [verified]
- LICENSE SNAPSHOT: §4 clause texts are snapshots (2026-10-27); terms can change between
  releases — G3 re-reads the actual TERMS at install time.
- FPS POLICY: integer-fps export is documented; if a brief ever needs a fractional
  output rate, that is an explicit verified policy decision, never a silent conversion.
- TRIGGERS: a brief demanding NLE-class keyframed editing/time-remap/adjustment-layer
  work that FFmpeg filter graphs would do badly AND T3 cannot cover. Then: license
  clause ask → operator approval → sandbox probe (Vulkan adapter present? external
  encoder path works? envelope model adequate?) → fixture smoke test.
- NEVER-USE: for loudness (its helper measures via FFmpeg loudnorm anyway — our chain
  keeps that job); for static cards (T0); as a second compositor next to T3 in one
  project; in any Covered Business context without the written agreement.

### T6 — Tesseract OCR (classic, Apache-2.0) — banned-claim gate automation [NEW]
- IDENTITY: the classic open-source OCR engine — NOT related to T5 (name-collision
  hazard already flagged in core §1; keep both cards, never confuse them).
- CAPABILITY: per-frame text extraction. Campaign use: INTAKE SWEEP — OCR N sampled
  frames per source at ingest, grep the output against the banned-claim vocabulary
  (R-04 class: pricing/availability/rewards/unverified claims). This converts the
  clip-25 catch ("STREAM FREE" burned-in card, found manually in Run 1) into a
  MEASURED, repeatable intake gate. Log hits with frame timestamps + confidence.
- LIMITS: OCR misses stylized/low-contrast text — treat a clean sweep as "no hits
  found", never "no claims exist"; keep the human frame review for Tier-0 sign-off.
- TRIGGERS: every intake containing burned-in on-screen text (which is: every source,
  given caption-heavy vertical content). Cheap; class FREE-OPEN; pin version at
  install; smoke test = OCR a known-card fixture frame, require the expected string.

### T7 — InVideo MCP — report-only (unchanged)
- Only if actually exposed and authorized (core §1 language stands). No change.

## 6. CATEGORY RULES (one tool per category)
- Motion-graphics compositor: T3 default; T4 conditional; never both in one project.
- NLE-class footage editing: T5 only, verify-first. Static graphics: T2 (or T0).
- Transcription: T1. OCR/text-extraction: T6. T5 ≠ T6 despite the shared name —
  every mention in logs must use the full card ID (T5 "tsrct by Mirage" / T6
  "Tesseract OCR") to prevent the collision the core already warns about.

## 7. CAMPAIGN FREEZE & PATTERN-AMENDMENT RULE
The live RexTrix v1 campaign completes on its frozen FFmpeg chain. New tools do NOT
touch a running pattern: any mid-campaign tool need is a pattern amendment (the
chain-v2 / SA-4 precedent) and requires an explicit operator ruling before install or
use. Registry need-detection activates at the NEXT brief reconciliation, where tool
needs are proposed as part of the profile (e.g., "animated end card → T3") and installs
happen under §3 BEFORE first render, with versions pinned in the project manifest.

## 8. AFTER-ACTION FEEDBACK (living registry)
After each campaign (or any real use of a registry tool), update its card with
observed facts: verified capabilities, measured limits, failures. This answers
finding D5 (V3 review): the capability matrix is seeded from observed reality and
maintained as a project artifact — not from stale marketing claims.

## 9. VERIFICATION LOG (Task 20-a, 2026-10-27)
- HyperFrames: Apache-2.0 + version 0.8.207 + CLI flags + perf + proxying verified
  from github.com/heygen-com/hyperframes (LICENSE, README, docs/guides). Cloud-credit
  pricing NOT published ([not-found]) — cloud stays OFF by default anyway.
- Remotion: LICENSE.md + remotion.pro/license + Lambda cost examples verified.
- tsrct: github.com/mirage-hq/Tesseract (releases, installation.md, capabilities.md,
  local-operation.md, telemetry.md, THIRD_PARTY_NOTICES.md) + mirage.app FAQ + Sept
  22 2026 press coverage. "250+ tools" unenumerated ([claim]). No Product Hunt/HN
  coverage found. Claude Code plugin not shipped.
- Tesseract OCR: license Apache-2.0 well-known; version pinned at install.

## 10. OPERATOR LINE (paste to the editing agent)
"New module on file: PEB_v3.2_MODULE_TOOL_REGISTRY.md — read it and acknowledge in
your project record. No installs now; the RexTrix chain is frozen and untouched
(Campaign Freeze, registry §7). The catalog is knowledge-only from now on: any future
unmet need escalates via the selection ladder (FFmpeg-first) to the one matching card,
through the install gate (need → match → license → approval → telemetry-off → pin →
smoke test → after-action). HyperFrames T3 is the default motion-graphics compositor;
Remotion T4 only with license resolution; tsrct T5 verify-first with the Covered
Business clause check; Tesseract OCR T6 becomes an intake sweep candidate for the
banned-claim gate at next campaign start. Never two tools from one category; log every
escalation; report any capability that fails its smoke test."
