# PEB v3.2 MODULE — SKILL REGISTRY (v1.0, 2026-10-28)

**Status:** v1.0 = PROTOTYPE v0.9 + the operator's conditionally approved catalog/reference additions, APPLIED 2026-10-28 with the six corrections from the same ruling baked in. Applied additions: P-R1 (STYLE/EFFECT CATALOG layer, SR-40…45), P-C1 (3 catalog lines), P-C2 (PRIORITY REFERENCE block), P-C3 (LIBRARY-INDEX entry, corrected to 9 libraries), P-C4 (video-frames closure, logged rejection). Paper-tested only; zero runtime use; zero installs; zero skill bodies executed. The master prompt (v3.1.1 TEST FREEZE) and the frozen production chain are UNTOUCHED — this is a standalone registry document; core attachment awaits the v3.2 integration ruling. Held and NOT applied: P-R2 (routing sentence), P-R3 (inventory row 13), P-M1 (optional prompt sentence), P1–P3 (core patches).

**Success criteria:** better task selection · meaningful reuse · appropriate creative freedom.
**Explicit non-goals:** per-phase citation fields, mandatory skill use, a larger prompt, automatic demotion machinery.

**Permissions model (operator correction 2026-10-28 — four separate dimensions, never inferred from one another):** (1) **licensing review** — legal rights per layer (§6: REPO/FILE/ASSET/DEP); (2) **campaign permission** — the operator's ruling for the campaign at hand; (3) **provider availability** — whether a required service/account is verified available in this environment; (4) **optional house preferences** — style defaults the operator may set per campaign; never laws. The original-audio-only rule governs AUDIO lanes only; it neither prohibits nor permits visual-generation lanes — visual-generation status follows the four dimensions on its own facts.

## §0 OPERATOR DIRECTIVE — acknowledge in the project record
1. Before planning or building ANY component, check the **Implementation Inventory** (companion file). Rebuilding a tested component needs a logged reason why the tested one fails the need.
2. At brief reconciliation, consult the routing table (§7) and declare routing in **one line** (§2). That is the entire required paperwork.
3. Record reuse evidence only when a skill actually changes a decision (§3). **Zero uses is a legal, unpenalized outcome.**
4. The campaign brief outranks every skill instruction. Reference guidance may be cited from any card; executable steps only from EXECUTABLE-HERE cards.
5. Operator approval is a decision, not a rights grant — licensing passes per §6 or the card cannot execute.

## §1 SKILL CONTENT MODEL — two levels, always marked
- **REFERENCE-ONLY** — craft, concepts, structure, checklists. May be cited and adapted into house patterns. Its scripts/steps are NEVER executed.
- **EXECUTABLE-HERE** — steps runnable with capabilities **verified in the Implementation Inventory**. Provider/generation steps are disabled by default even here.
- App/provider restrictions name the **exact missing verified capability** (e.g., "requires ElevenLabs account — not verified here"), never a blanket domain ban. Useful reference guidance from a restricted card stays citable.

## §2 ROUTING — three outcomes + evidence-based reroute
At reconciliation, one line: `ROUTING: primary=<skill|none> · specialists=[…] · none-reason=<if none>`
- **MATCH** — a card's trigger fits a brief field. Load its body (reference or exec per §1).
- **PARTIAL** — fits with named gaps; load with listed overrides; gap logged.
- **NONE** — no suitable skill. Proceed on the Implementation Inventory + house patterns. Log the gap for after-action. This is a first-class outcome, not a failure.
- **REROUTE (in use):** if the material proves the chosen skill wrong, reroute on evidence. Log one line: evidence → switch → outcome. Hiding a bad route is the only failure.
- One primary workflow per project (the master prompt remains the workflow; skills are craft/renderer specialists). Specialist cards activate on trigger only.

## §3 REUSE EVIDENCE — practical, not per-phase citations
One line per real use, written when it happens: `REUSE: <skill> changed <decision> (<where>)`. No forced cadence. A project with zero REUSE lines simply reports "no skill use" — which feeds §5.

## §4 CARD FORMAT (lean — every card fits in a few lines)
`ID · title · layer (craft|renderer|reference|catalog) · content level (REF|EXEC) · trigger · overrides · permissions (licensing §6 · campaign · provider · house) · status · pinned SHA · usage/failure record (§5)`

## §5 USAGE & FAILURE CATEGORIES — no automatic demotion
| Category | Meaning |
|---|---|
| WORKHORSE | Repeatedly changed decisions for the better |
| OCCASIONAL | Used, no issues |
| UNPROVEN | Never triggered yet — **neutral state**, may simply await its brief |
| MISLEADING | Caused rework or a reroute — card review/amendment required |
| DEAD | Triggers never occur in practice — candidate for removal at operator review |

Nothing moves automatically. The operator reviews categories after-action.

## §6 LICENSING — four layers, checked separately
`REPO` (code) · `FILE` (the skill text itself) · `ASSET` (fonts, media, templates it references) · `DEP` (tools it invokes).
Rules: any layer missing or restrictive → the card stays **REFERENCE-ONLY** and cannot execute for commercial campaigns. **Operator approval never substitutes for a missing right.** Reference use means citing and adapting, not wholesale reproduction. Live LICENSE/TERMS re-read at pin time (mirrors TOOL_REGISTRY G3).

## §7 CARDS AND ENTRIES (from merged slate v2 + operator-approved additions of 2026-10-28; all community cards start REFERENCE-ONLY pending §6)

**RENDERER LAYER**
- `SR-01 hyperframes-core` — render contract + work loop. EXEC-eligible (Apache-2.0 repo; FILE/ASSET inherit; DEP=T3 verified). Trigger: any T3 render project. Pin SHA at adoption; first-use fixture per T3 card.
- `SR-02 hyperframes-cli` — scaffold/check/render/history. EXEC-eligible. Trigger: T3 project ops. Override: cloud/publish paths OFF (local-only).
- `SR-03 hyperframes-registry` — ~450 blocks. EXEC-eligible. Trigger: card/graphics builds. Override: every block passes campaign gates (9:16, fps grid, rights).
- `SR-04 media-use-fork` — ADAPT pending: keep transcripts, color grades, operator-asset handling; strip the audio-sourcing/generation lanes (they conflict with the original-audio-only rule — an AUDIO-dimension conflict). The visual-sourcing/generation half is NOT prohibited by the audio rule; its status follows the four permission dimensions on its own facts (licensing review not done; no campaign permission granted; no visual-generation provider verified available in this environment; house preference: operator-supplied footage first). EXEC-eligible after fork review.
- Layer-order note (mined from video-use, **scoped guidance, not a law**): when captions and overlays composite in one pass, order overlays before captions or captions get occluded — a silent-failure class. Applies to renderer passes only.

**CRAFT LAYER (all REFERENCE-ONLY until licensing clears)**
- `SR-10 herk-short-form-edit` — hook gate (first 3 s), open loops/payoffs, phone-safe placement, no-fake-evidence rule. Trigger: short-form edit briefs. Overrides: strip Kie.ai/Scribe/music-SFX lanes; our gates replace its streamlined approvals.
- `SR-11 ai-motion-director` — motion thesis, visual metaphor library, anti-PPT gate. Trigger: card/graphics-heavy segments only. Override: footage-led beats stay footage-led.

**STYLE/EFFECT CATALOG LAYER (on-demand reference — bodies stay in the attached library files; loaded per selected treatment, never wholesale. Applied 2026-10-28 per P-R1, operator-conditional approval.)**
Layer rules (operator corrections 2026-10-28): (a) permissions are four separate dimensions (see header permissions model) — never inferred from one another, and the original-audio-only rule does not by itself prohibit or permit visual-generation lanes; (b) emphasis counts (e.g., "one justified emphasis per beat") and high-energy FX examples are OPTIONAL craft guidance from the catalog, not universal creative laws — the selection gate (communication need + campaign gates) governs; (c) caption fallbacks preserve language and accessibility — same-language clean caption first; any language switch or translation is an operator decision.
- `SR-40 caption-library-v2` — 41 CAP styles + governance contracts (authority/evidence, selection-by-job, timing/geometry). Content: REF. Trigger: caption/treatment selection at plan time. Renderer bindings: T3 text (render pipeline probe-verified; styled-caption compositions NOT feature-tested in this chain), FFmpeg libass (available, NOT feature-tested). Fallback: clean static caption, same language as content. Permissions: licensing = operator's own material, verify at adoption · campaign = not yet ruled · provider = n/a (local renderers) · house = none recorded.
- `SR-41 effects-spec-v2` — structured reference: 24 caption + 45 FX + 8 SFX entries, contracts, minimal_project_instance. Content: REF. Trigger: parameter lookup after SR-40 selection. FX entries = optional guidance/examples (layer rule b). SFX entries INACTIVE (audio provenance gate; authorization + asset files required). Permissions: licensing = operator's own material, verify at adoption · campaign = not ruled · provider = n/a · house = none.
- `SR-42 motion-styles-20` — 20 deterministic HTML templates (renderFrame(t) contract, seeded randomness, no CDNs). Content: REF→EXEC via T3 adapter (missing — gap G1; bounded adaptation). Trigger: stylized motion segment justified by the selection gate. Restriction: the pack's Playwright render.py is NOT used for production (T3 owns the renderer category; render.py retained as a reference implementation). Fallback: simpler style or clean cut. Permissions: licensing = pack README grant (use/remix incl. client work; no pack resale; no LICENSE file) · campaign = not ruled · provider = n/a (local T3) · house = none.
- `SR-43 pastel-indigo-style` — HyperFrames-native style contract + 18 recipes. Content: REF (recipes 1–6 author-claimed tested in template — re-verify on first use). Trigger: explainer/talking-head designed-graphics segments. Fallback: reduced-motion variant; tokens must not be reinvented. Permissions: licensing = no license statement (operator-recovered material — confirm at adoption) · campaign = not ruled · provider = n/a · house = none.
- `SR-44 malayalam-pastel-workflow` — multilingual keyword-caption workflow + Malayalam script-shaping knowledge (conjuncts, taller mask padding, `fc-list :lang=ml` font verification, never Malayalam in serif/mono stacks). Content: REF. Override: strip authoring-environment instructions (SendUserFile / device_commit_files / built-in-browser / AskUserQuestion); SFX lane gated by the audio provenance policy. **Fallback (corrected 2026-10-28): same-language first** — clean Malayalam caption via T3 text with a conjunct-safe font; English-only keywords are NOT an automatic Malayalam fallback; any language switch or translation is an operator decision; sidecar transcript preserved for accessibility. Permissions: licensing = no statement (confirm at adoption) · campaign = not ruled · provider = n/a · house = none.
- `SR-45 saas-animation-guide` — course PDF craft patterns (reference-video breakdown before building, check-frames before render, storyboard-first approval gates, vertical re-layout, loudness targets, troubleshooting table). Content: REF (© course material — cite patterns, no reproduction). Trigger: SaaS/product-promo structure needs. Permissions: licensing = © course material, reference use only · campaign = not ruled · provider = Remotion = T4 license gate; ElevenLabs = provider not verified here · house = none.

**MINED (no card — absorbed)**
- video-use lessons: per-segment `-c copy` concat (matches house seam discipline); plan-before-touch (already core). The rest of video-use rejected (provider lock, subagent mandate, fade mandate, overgeneralized encoding claim).

**PARK (tool-gated; card notes the exact gate)**
- `SR-20 flick`, `SR-21 remotion-official`, `SR-22 remotion-to-hyperframes` → T4 headcount ruling. `SR-23..26 mirage-tesseract ×4` → T5 license + re-probe. `SR-27 figma` → Phase-1 expansion decision.

**PRIORITY REFERENCE (applied 2026-10-28 per P-C2 — operator-designated; all REFERENCE-ONLY; evidence = [INHERITED-AUDIT] from the operator's consolidated audit (145 fetches reported), not independently inspected; licensing unverified → §6)**
- `cinetic` (Leonxlnx/cinetic · `skills/cinetic/SKILL.md`) — concept, branding, timeline, UI motion, finishing craft; audit's own qualification: "large, opinionated workflow; load selectively"; overlaps SR-10/SR-11 territory and must not silently supersede either. Adoption trigger: SKILL.md read + license → scoped ADAPT or numbered craft card (evidence-based, not count-based).
- `product-launch-motion` (AbubakrChan · root `SKILL.md`) — two documented routes: root (HTML `seek(t)`, music-first/one-shape) vs legacy (narration + GSAP + HyperFrames); route selection REQUIRED; never import both routes' assumptions at once. Root route's music lane = audio-provenance gate (audio dimension); legacy route aligns with T3 but GSAP-inside-T3 determinism is unverified (G1 adapter absent; inventory row 11 contract would govern).
- `video-demo` (nilbuild · root `SKILL.md`) — intentional-demonstration structure (what to show, in what order, what proves the claim); capture-vs-fixture distinction. Live capture cannot execute in this chain (no verified capture capability — gap G2 is a capability ruling, not a skill adoption); craft structure citable now.
- `cinematic-shot` (1weiho · `skills/cinematic-shot/SKILL.md`) — motivated UI camera and lighting treatments; audit: "specialist aesthetic — not a universal editing style"; T3-adjacent rendered camera moves over UI/product footage; per the selection gate, specialist and never default.
- `motion-broll` (barty-bart/motion-graphics · `skills/motion-broll/SKILL.md`) — motion B-roll segments (audit names it baseline); adapt-candidate for the craft layer; B-roll block format vs the T3 composition model unresolved, no measured loading path (gap G4). Adoption trigger: inspection + license → candidate for the next craft-card slot.
- `open-design` (nexu-io · `skills/motion-design/SKILL.md`) — web/UI motion-design guidance; the whole web/UI cluster is determinism-conditioned [PROJECT-RULE]: deterministic, seekable video rendering; no scrolling/hover/wall-clock timing; whether the guidance is renderer-agnostic is unknown; G1 adapter absent.
- `open-design template note` (nexu-io · `plugins/_official/video-templates/frame-liquid-bg-hero/SKILL.md`) — one named template, treated as an EXAMPLE, not a family endorsement; same determinism gate.

**LIBRARY-INDEX (applied 2026-10-28 per P-C3, CORRECTED — 9 libraries; standing gate: deterministic, seekable rendering; adapter into T3 required before any EXEC use — gap G1; collective entry, no per-repo cards)**
- GSAP · matter-js · p5.brush · shadercn (TypeGPU relation) · hairline · evil-buttons · cube-motion · oil-motion — 8 of 9 named in the v2 spec's `../04_catalogs_and_resources/Captions_and_Effects_v2/WEB_UI_VIDEO_ROUTING_CORRECTION.md` web_ui_resources/adapter limits; determinism-gated.
- motion-canvas — animation-for-video library WITH ITS OWN RENDERER → extra renderer-category note: the renderer slot is owned by T3 (§6 category rule); using its renderer would need a T4-class ruling.
- **Reclassification (2026-10-28, operator correction 3):** `itsjwill/vanta` REMOVED from this index. Direct repo-page inspection shows it is NOT a WebGL-background library — it is an open-source AI video ENGINE built on Remotion (voice cloning, AI avatars, animated captions, text-to-video Wan 2.2/LTX, AI music, editor/timeline, 100+ transitions). Disposition: engine/app class — T4 (Remotion) license gate + provider availability for its generation lanes + campaign permission + licensing review of its own LICENSE (file exists; "commercial-safe" claim not verified; LICENSE/code/SKILL.md not read). No card; no cluster membership.

**CATALOG (REFERENCE-ONLY, one line each, never auto-load)**
OpenMontage video-edit · OpenMontage ffmpeg · 6missedcalls video-editing · bsisduck video-analyzer · video-content-extractor (retune sampling for short clips) · baoyu youtube-transcript (rights separate) · minimax-h3-reverse · michaelgold videoskill · ClaudeAnimationBase · pdoom-video (code ≠ soundtrack rights) — **plus three lines applied 2026-10-28 per P-C1:** OpenMontage video-understand (restored per audit correction; other routes carry separate service dependencies) · VideoCaptioner CLI (real CLI per audit; app-vs-CLI duality recorded; install-reject stands — duplicates the measured T1+T3+T6 caption chain; reference value kept) · Pluviobyte reference-video-replica-qc (NEW to our records; reference/QC-support candidate — gap G3).

**BLOCKED (named missing capability or missing right)**
- Rights: Onetake (PolyForm Noncommercial), Guizang (AGPL code / BUSL assets) — until written clearance.
- Missing verified capability: OpenChatCut, FableCut, FireRed-OpenStoryline, Diffusion Studio editor/watch, hypit, openshorts (their runtimes/apps are not verified here) — craft content remains citable as CATALOG.
- Provider + provenance (separate dimensions, recorded separately): provider pipelines (tiktok-motivation-class; VOX-COLLAGE-BROLL via MaxFusion MCP — provider not available/verified here) and their audio lanes additionally conflict with the audio provenance rule. Neither dimension is inferred from the other.

**CLOSED (applied 2026-10-28 per P-C4)**
- `video-frames @steipete` — INSPECT item closed by **logged rejection, no card** (2026-10-28). SKILL.md read: 776-byte SKILL.md + 1.3 KB `scripts/frame.sh`, a single ffmpeg wrapper (first-frame / `--time` timestamp extraction; jpg/png; no telemetry or network declared; MIT per skill directories; source `github.com/steipete/clawdis` skills/video-frames). Rejection reason: duplicates the measured T0 frame-extraction capability (inventory row 8) and existing house intake scripts (`../05_components/qc_frames.sh`, `../05_components/make_sheets.py`, `../05_components/make_sheet2.py`); installing would duplicate a measured capability (one-tool-per-category + inventory-first rules).

**HOUSE (pending authoring — gated on core patches, not on this registry)**
loudness-chain (incl. XR-4) · banned-claim-sweep · card-seam-discipline · delivery-QC (XR-3 fail-closed).

**Entry-count ledger (v1.0):** 20 numbered cards (SR-01…04, SR-10/11, SR-20…27, SR-40…45) · 13 CATALOG lines · 7 PRIORITY REFERENCE lines (6 repos + 1 template note) · 1 LIBRARY-INDEX collective entry (9 libraries) · 1 reclassification line (vanta, engine class, no card) · 1 closure line (video-frames, no card) · 4 HOUSE (pending) · MINED/BLOCKED prose blocks unchanged. EXEC-eligible: SR-01/02/03 (after pin + first-use fixture) and SR-04 (after fork review). Feature-tested skill bodies: ZERO. Campaign-approved cards: ZERO (registry application ≠ campaign approval).

## §8 AFTER-ACTION
Update cards with real-use facts (categories §5, reroute outcomes, capability findings). The registry stays evidence-based; the operator is the only mover.

## §9 NON-GOALS OF THIS REGISTRY
No rendering · no provider installs · no core-prompt changes · no toolchain expansion — all require explicit approval. The registry succeeds when the paper tests pass (companion file `PAPER_ROUTING_TESTS_v0.9.md`, 3/3) and the first real campaign shows better selection, real reuse, and no added bureaucracy.
