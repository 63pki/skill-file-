# PENDING RULINGS — held items awaiting the operator (v1.0, 2026-10-28)

Everything below is HELD. A fresh session must NOT apply, install, render, or build any of it without a new operator ruling. (Applied items are listed in `../02_registry/SKILL_REGISTRY_v1.0.md` and `../07_status/COVERAGE_RECONCILIATION_v2.1.md` §8.)

## A. Registry-adjacent patches (proposed, NOT applied)

| ID | What it would do | Where the exact text lives |
|---|---|---|
| **P-R2** | Add one treatment-selection sentence to registry §2 routing ("no added treatment / clean cut / held shot are valid selections…") | `RESOURCE_INTEGRATION_REPORT_v1.2.md` §4 (this folder; v1.0/v1.1 preserved in `../archive/`) |
| **P-R3** | Add inventory row 13 (styled captions: T3 pipeline probe-verified, styled compositions NOT feature-tested; libass available, not tested) | same §4 |
| **P-M1** | OPTIONAL one-sentence master-prompt addition (treatments chosen from the catalog only when they improve communication) | same §4 — touches the master prompt, hence held under "do not rewrite the master prompt" |
| **P1–P3** | Minimal core patches: P1 REQUIRED (consult routing table + inventory, declare one line); P2 VERIFY-ONLY authority-language coverage; P3 OPTIONAL audio provenance-vs-transform clarification | `PROPOSED_CORE_PATCHES_MINIMAL_v0.9.md` (this folder) |

## B. Architecture-level (parked)

- **v3.2 core integration** — folding the tool/skill registry layer into the master prompt core (incl. R5 rulings + metadata ruling). Gating item for house-skill authoring.
- **House skills** (4, pending authoring): loudness-chain (incl. XR-4) · banned-claim-sweep · card-seam-discipline · delivery-QC (XR-3 fail-closed).
- **SR-01…03 EXEC activation:** pin SHA + first-use fixture required before any EXECUTABLE-HERE claim.
- **SR-04 fork review** before EXEC eligibility.

## C. Tool rulings

- **T4 Remotion** headcount/license ruling · **T5 tsrct** any-use ruling (Covered-Business clause) · **T7 InVideo** exposure/authorization · **T6** intake-sweep activation at next campaign start.

## D. Capability gaps (logged, NOT built — adapters/capabilities, not skills)

- **G1** deterministic seekable web-animation→video adapter (gates the whole LIB cluster + 2 priority references; highest leverage)
- **G2** live web-product capture (capability ruling needed first)
- **G3** reference-based QC replication (Pluviobyte reference-video-replica-qc now a catalog line; inspection pending)
- **G4** motion B-roll reuse lane into T3 compositions

## E. Campaign-side operator decisions (RexTrix, from the review rounds — archived)

- R4(a)/(b) logo/wordmark decision · rights grant · campaign font sign-off (DejaVu placeholder disclosed) · card-audio variant already ruled per batch rules where applicable · sub-batch A approval + B/C/D unlock conditions (see archived `../archive/EDITING_AGENT_REVIEW_R4.md` and `../archive/EDITING_AGENT_REVIEW_R5.md`, SA-1…SA-6 + XR-1…XR-8 checklists) · open brief items Q1/Q2/Q5/Q6/Q7/Q9.

## F. Standing obligations for the next session

1. Persist + hash every operator input at receipt (`../05_components/verify_operator_input_v1.py` pattern; `../archive/OPERATOR_INPUT_2026-10-28/` is the worked example).
2. Keep [DIRECT] vs [INHERITED-AUDIT] vs [PROJECT-RULE] evidence tiers separate in every statement.
3. One routing line at reconciliation (registry §2); zero skill use is a legal outcome.
4. Check the Implementation Inventory before building anything; rebuilding a tested row needs a logged reason.
5. Four-dimension permissions (licensing / campaign / provider / house) — never infer one from another; the audio rule governs audio lanes only.
