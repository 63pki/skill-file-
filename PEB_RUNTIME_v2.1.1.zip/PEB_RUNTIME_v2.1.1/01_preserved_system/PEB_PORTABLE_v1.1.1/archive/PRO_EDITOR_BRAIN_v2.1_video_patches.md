# PRO EDITOR BRAIN — v2.1 Video-Derived Patches (P-V1..P-V6)

Date: 2026-10-24 · Basis: independent QC of the 10-clip RexTrix Mode B delivery
(60 sampled frames across 10 clips, ffprobe spec verification, keyframe+audio decode
integrity, ebur128 loudness, ASR transcription of all 10 audio tracks)

These six patches are additive. They are already applied in
`PRO_EDITOR_BRAIN_v2_consolidated.md` (marked in-line with `[v2.1]`).
Apply them manually only if you maintain your own copy of v2.

---

## P-V1 — End-card duration floor · §10 E (CLOSING STAMP)

**FIND (end of the "Campaign end cards" bullet):**
```
Wording that only names the brand (for example, "to try <Brand>") does not satisfy the gate.
```
**REPLACE WITH:**
```
Wording that only names the brand (for example, "to try <Brand>") does not satisfy the gate. [v2.1] Duration floor: the end card must hold for at least 4.5 seconds, or the campaign minimum plus 0.5 seconds, whichever is greater. A card that measures exactly at the campaign minimum is a defect risk, not a pass — rounding, platform-side trimming, or preview cropping can silently shorten it. Verify the card's start and end timestamps on the rendered file, not in the timeline.
```
**Observed failure:** all 10 delivered end cards measured exactly 18.0–22.0 s = 4.0 s —
at the ≥4 s minimum with zero margin.

---

## P-V2 — Language gate for music-only sources · §5 (Language gate)

**FIND (end of the Language gate paragraph):**
```
Record language verification in the source index as a pre-selection check.
```
**REPLACE WITH:**
```
Record language verification in the source index as a pre-selection check. [v2.1] Music-only or ambient-only sources: if no speech is detectable, the spoken-language check cannot fail the source — but it cannot pass it either. Verify all burned-in text against the campaign language rule, record the source as "language: instrumental — operator to confirm any vocals before posting", and list it in the delivery notes. Never record an instrumental source as language-verified.
```
**Observed failure:** Clip 07 (AI band) has no detectable speech; the gate had no
defined path for instrumentals.

---

## P-V3 — Source-resolution floor · §12 (POST-RENDER verify list)

**FIND:**
```
- Loudness and true peak on the encoded output.
```
**REPLACE WITH:**
```
- Loudness and true peak on the encoded output.
- [v2.1] Source-resolution floor: when the best available source is below 720p in the main-image band, deliverable sharpness is source-limited. Still deliver, but record "degraded source" in the delivery notes and ask the operator for higher-resolution masters instead of presenting the output as fully meeting the quality bar. Never upscale-and-silence: softness that will cost retention must be stated, not hidden.
```
**Observed failure:** all 10 clips built from 640×360 sources (soft main image).

---

## P-V4 — Loudness measured on final renders · §11 (delivery target)

**FIND:**
```
- Treat these as project defaults, not universal platform requirements.
```
**REPLACE WITH:**
```
- Treat these as project defaults, not universal platform requirements.
- [v2.1] Measurement rule: loudness and true peak are measured on the final encoded files with a named tool and command (for example, ffmpeg ebur128), and re-measured after any gain or mix change. Pre-render estimates and post-filter calculations do not satisfy this gate. Any delivered file deviating more than 1.5 LU from the target is re-normalized, not merely noted.
```
**Observed failure:** manifest claimed −13.1..−15.6 LUFS; independent measurement of
Clip 01 = −16.3 LUFS (outside claimed range, 2.3 LU under target).

---

## P-V5 — Source-baked defects policy · §13 (Campaign Release Gates)

**FIND:**
```
A campaign-gate failure is a Major defect at minimum; a materially misleading claim remains Critical.
```
**REPLACE WITH:**
```
A campaign-gate failure is a Major defect at minimum; a materially misleading claim remains Critical.

[v2.1] Source-baked defects: typos, awkward grammar, and artifacts that exist inside the source footage itself (for example, a misspelled word baked into the source's own subtitles) are reported in the delivery notes, never silently corrected — preserving source fidelity — and never counted against the deliverable's QC grade, since the module did not introduce them.
```
**Observed failure:** "summarrize" typo baked into Clip 02's source subtitles.

---

## P-V6 — Reproducible QC claims · §12 (defect record)

**FIND:**
```
status | revalidation result.
```
**REPLACE WITH:**
```
status | revalidation result.

[v2.1] Every QC pass/fail claim in the delivery manifest must name the tool and command that produced it, so an independent reviewer can reproduce the result. A claim without a stated method is recorded as "not checked", never "passed".
```
**Observed failure:** manifest loudness/decode claims were not exactly reproducible
under independent measurement.
