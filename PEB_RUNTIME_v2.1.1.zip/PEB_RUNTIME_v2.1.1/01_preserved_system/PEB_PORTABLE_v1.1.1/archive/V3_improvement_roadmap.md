# V3 IMPROVEMENT ROADMAP — Pro Editor Brain

Basis: review of the 2026-10-24 user rewrite (see V3_REVIEW_user_prompt_vs_goals.md) + the four
consultation tracks. The user's v3 goals: premium-ad professional-editor quality; full power in
editing creativity + campaign-rule adherence; four new capabilities (motion graphics, keyframes,
stabilization, BG removal/layering); "listen and feel"; viral mandate (strong 3-channel hooks,
teaser method, strongest-moment storytelling); complete brain, not a limited one — campaign
rules adapt it, never amputate it.

## Phase 0 — Restore the compliance spine (do first, no consultation needed)

Patch into the user's rewrite (keep their architecture):

- P0-1 §Intake/QC: add CAMPAIGN COMPLIANCE GATES block — mandatory inclusions, banned-claims
  scan, end-card specification (logo graphic + explicit action wording), language gate (spoken
  AND burned-in text per source segment; instrumental path: "operator to confirm vocals"),
  post-publish operator checklist emission.
- P0-2 §ENDING: keep "no universal hold time", append: "when the campaign states a minimum
  hold, the release gate verifies the rendered card holds at least that minimum plus 0.5 s,
  measured on the encoded file."
- P0-3 §POST-RENDER: restore named-tool loudness measurement (e.g., ffmpeg ebur128) + 1.5 LU
  re-normalization trigger; QC claims must name their reproducing command (unstated method =
  "not checked"); degraded-source disclosure (<720p main-image band); source-baked-defects
  policy (report, never correct, never count against the deliverable).
- P0-4 Global: restore section numbers; fix the dangling "§13" reference.
- P0-5 §HOOK: resolve preset tension (presets are reference implementations, not mandates);
  add the viral mandate as mechanics: "design for hook strength, payoff delivery, rewatch
  structure, and share triggers; never claim or predict outcomes. Hook channel coverage
  (visual/audio/text) is a campaign-profile requirement executed honestly from source evidence."
- P0-6 Add TEASER METHOD to the hook engine with honesty guardrails (peak must be real footage
  from this source; payoff must arrive; no bait-and-switch).

## Phase 1 — Integrate the four consultation answer-sets

When the user brings back the answers to CONSULT A–D:

- A (Feel Engine) → new section "AUDIOVISUAL FEEL ENGINE": signal stack, rhythm architecture,
  decision mapping with tolerances, AI-tells audit, emotion curve, feel-spec JSON, grading
  rubric. Extract every "RULE:" line, de-duplicate against existing laws, place by topic.
- B (Motion Graphics) → expand §recipes into "MOTION GRAPHICS DESIGN ENGINE": opportunity
  taxonomy → evidence-gated detection → design tokens/style frames → choreography → asset
  pipeline → anti-slop rules → archetype library (existing 5 recipes become members).
- C (Pipeline) → new section "ADVANCED LAYER PIPELINE": keyframe JSON schema + render path,
  stabilization decision tree + QC, BG removal strategy + edge/flicker QC, layered compositing
  (graphics behind subjects), frame-truth test protocol, failure ladders.
- D (Campaign brain + viral) → upgrade intake + add "CREATIVE STRATEGY LAYER": campaign-profile
  schema, hook strength rubric, strongest-moment scoring, teaser mechanics, engagement R&D
  loop, variety engine, anti-dumbing governance.

Integration discipline: no rule may weaken the honesty layer (no predicted virality, no
invented capabilities) or the compliance gates; every imported RULE: line gets an id
(V3-A-01 style), a category, and a severity; contradictions resolve in favor of
truthfulness/rights > campaign gates > craft.

## Phase 2 — Structure for token economy

- Keep the full brain in one master prompt (user's "complete brain" goal).
- Mark §recipes/§engineering artifacts as "Mode A load-on-demand; Mode B reads only the
  sections it executes" so 30-clip batches don't burn context on unused build specs.
- Target ≤ 55k chars total after integration; if exceeded, move archetype parameter schemas
  and JSON examples into an appendix file the agent reads on demand.

## Phase 3 — Regression harness (so it never gets dumber)

- T1 Mode B smoke test (2 clips, RexTrix input) → emits requirement matrix, claims ledger,
  compliance gates, operator checklist.
- T2 Compliance probe (non-English speech + "free" claim) → gate rejects/blocks.
- T3 Math probe (30 fps frame math) → exact formulas.
- T4 Honest-status probe (no playback) → review_draft, never verified_delivery.
- T5 Pilot diversity (3 pilots) → structurally different.
- T6 (post-integration) Paired rule-on/rule-off render on one clip, graded by the A-rubric —
  catches any new rule that degrades taste (consult D Q7).

## Sequence

P0 patches now → consult A–D out (done) → answers back → Phase 1 integration → Phase 2 trim →
Phase 3 harness → then first v3 test batch (3 pilots) on the live campaign.
