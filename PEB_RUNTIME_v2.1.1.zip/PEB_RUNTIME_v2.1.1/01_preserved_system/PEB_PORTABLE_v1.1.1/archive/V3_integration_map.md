# V3 INTEGRATION MAP — Consult Answers → PRO EDITOR BRAIN v3

Basis: 14 model responses across 4 consults (A: feel engine — 3 responses; B: motion graphics — 3;
C: pipeline — 4; D: campaign brain/viral — 4), integrated into the user's numbered rewrite
(`PRO_EDITOR_BRAIN_MASTER_PROMPT_REVISED.md`, the v3 chassis) per the discipline:
**truthfulness/rights > campaign gates > craft defaults > agent preferences**, no rule may weaken
the honesty layer, every imported rule gets a v3 rule ID.

Companion files: `PRO_EDITOR_BRAIN_v3.md` (master prompt), `PRO_EDITOR_BRAIN_v3_appendix.md`
(load-on-demand reference: schemas, archetype library, disclosure templates, parameter tables).

---

## 0. CHASSIS DECISIONS (P0 — before any consult content)

| # | Decision | Rationale |
|---|----------|-----------|
| C-1 | Chassis = user's **numbered** rewrite (REVISED.md, §1–15), not the unnumbered paste | Fixes D1 (dangling §13); preserves all 11 verified improvements |
| C-2 | Restore compliance spine as **§3 CAMPAIGN COMPLIANCE GATES + verification rules in §18** (not a verbatim v2 §3 paste) | Roadmap P0-1/P0-3; review's "restoration design note" |
| C-3 | Keep "no universal hold time" (creative) + append campaign-minimum verification floor | Roadmap P0-2; preserves user improvement #9 while restoring R3 |
| C-4 | Section count grows 15 → 21; new engines inserted in production order | See structure below |
| C-5 | Token economy: master prompt ≤ ~58k chars; schemas/archetypes/disclosure-templates/param-tables moved to appendix, loaded on demand; §10–13 and appendix marked "load when the task needs them" | Roadmap P2 / defect D4 |
| C-6 | Capability matrix seeded from 30+ observed RexTrix runs: ffmpeg/ffprobe/ebur128/ASR verified; **sandbox OOM-SIGKILLs long/background ffmpeg** → bounded foreground stages, ETA extrapolation, staged intermediates | Defect D5 + Task-4 worklog finding |
| C-7 | Frame-rate policy stays campaign-first/source-native; all frame tables in v3 marked "at F=30; derive from intended times at other rates"; audio invariant generalized to samples = frames × 48000/F | User improvement (math contract) vs 30fps-only consult tables |

**v3 structure**: §1 Mission · §2 Modes · §3 Input+Campaign Compliance · §4 Editorial Laws & Precedence ·
§5 Source Intelligence, Moments & Claims · §6 Brief, Story Spine & Decision Records · §7 Audiovisual Feel Engine ·
§8 Hook, Teaser & Rhythm · §9 Design System & Platform Safety · §10 Motion Graphics Engine · §11 Keyframe Engine ·
§12 Stabilization · §13 BG Removal & Layer Compositing · §14 Captions/Audio/Color · §15 Ending & CTA ·
§16 Render Pipeline & Sync · §17 Engineering Contract · §18 QC (incl. rubric, campaign gates) ·
§19 Creative Strategy, Variety & Learning · §20 Iteration, Release & Failure Disclosure · §21 Response Order.

---

## 1. CONSULT A — FEEL ENGINE (3 responses: R1 precise, R2a conservative, R2b aggressive)

**Base model = R2a (CPU-realistic, confidence-gated) upgraded with R1's unified machinery; R2b mined for
mechanics only.** Rule IDs in v3 §7: `SIG-*` (signal stack), `RHY-*` (rhythm), `CUT-*` (cut mapping),
`TELL-*` (tells audit), `EMO-*` (emotion curve), `FS-*` (feel spec).

### Adopted (all three or 2/3 agree)
- Signal sidecar written BEFORE any cut decision; every value carries confidence + method [`SIG-1`]
- Unified confidence ladder (R1): ≥0.7 hard anchor ±1f · 0.4–0.7 soft ±2f · <0.4 absent/ignored, never guessed [`SIG-4`]
- Proxy analysis at 360×640@8fps; faces ≤5fps; OCR triggered only by text-proxy; never analyze full-raster every frame [`SIG-2`]
- ASR edges never frame-true: ±4f minimum uncertainty (±8f if logprob < −0.5); drop words logprob < −1.0 or <2f [`SIG-5`]
- Energy-snap word boundaries to RMS inflection (R1+R2b): snap start back ≤60ms lookback; record snap distance; snapped edges still carry ±1–2f honesty [`SIG-6`]
- Breath detection heuristic on gaps 120–900ms, conf ≥0.6 usable, tie-breaker only below; disable under baked music unless stem separated [`SIG-7`]
- Beat grid in asset time → timeline via offset; recompute after atempo; `beat_conf < 0.55 → music anchors off`; downbeat conf < 0.5 → hints only [`SIG-8`]
- Demucs only when overlap flagged AND budget remains; proxy envelopes otherwise; separation_quality recorded [`SIG-9`]
- Room tone: extract ≥300ms patch per dialogue source; never bridge trims with digital zero-silence (R2b, adopted) [`SIG-10`]
- Material mode (dialogue/action/music/hybrid) chosen from sidecar before cuts; clause length outranks shot-length tables (R2a) [`RHY-1`]
- Act structure R2a (hook 8–15% cap 3.0s, setup 20–30%, escalation 35–50%, payoff 15–25% min 2.5s, button 0.8–1.6s) + R1's phase-density table as prior only — anchors decide [`RHY-2`]
- Shot-length targets by energy (p10/p50/p90 + hard min/max + shots-per-15s/40s, R2a table → appendix); CV by energy 0.35–0.85, fail < 0.25 [`RHY-4`]
- ≥1 shot ≥3× ASL per piece (R1); high energy: ≥1 shot ≥42f per 8s, ≤2 impact flashes 4–6f (R2a) [`RHY-5`]
- Rule of three (R1): 3 consecutive shots within ±20% → next deviates ≥35% [`RHY-6`]
- Accelerando-into-hold ≥1 per piece (med/high); payoff = contrast (longest hold OR densest burst, never same density as escalation) (R1) [`RHY-7`]
- Holds table: mid-clause → next legal edge; landing line breath+8–15f; reaction 1.6–4.0s; product motion 2.0–4.5s; 3 fast cuts → recovery ≥1.2s; text density >0.12 → ≥24f (R2a table) [`RHY-8`]
- Low motion during speech = hold candidate, not dead air (R2a) [`RHY-9`]
- Word integrity: no edit inside [word_start+1, word_end−1]; straight speaker cut at word_end+2..5f; incoming pre-roll −2..−4f; never start at word_t0 [`CUT-1`]
- Beat snap: legal only if beat within 2f of a legal speech/impact anchor; land −1..0f; push 3–4f early legal for impacts/reveals; avoid late window +1..+5f; half-beat deliberate = legal (R1+R2a) [`CUT-3`]
- J/L: J 4–15f (default 6–8), L 3–20f (default 6–12), min split 4f, one direction per cut, ≥50% speaker changes in conversational material (reconciled 45/60/60) [`CUT-4`]
- Punch-in: only stress ≥0.6 or action apex; scale 1.08–1.20; land 1–2f before stressed onset (step) or reach target at onset (push); ≤1 per 4–6s; never consecutive stressed words; no punch if face conf < 0.65 (R2b guard) [`CUT-5`]
- SFX: only idea-change/energy-jump anchored; ≤1 per 6s; none within 200ms of word onset; silence/dip (−6..−12dB, 400–900ms) preferred on reveals; none on routine exits/labels [`CUT-6`]
- 12-tell audit (R1 list, R2a blockers 1/2/3/8/12 hard); run before export; blocker tell fails QC even if decode/loudness pass [`TELL-1`]
- No more than one of {cut, punch, SFX, caption-start} inside any 3-frame window (R2a) [`TELL-2`]
- Emotion curve: T(t) target from brief-annotated units (valence/intent from brief only, never lexicons — R2a; unknown intent → human); R(t) realized from rendered timeline; r ≥ 0.60 pass / 0.40–0.60 review / < 0.40 fail; peak error ≤1s; range ≥0.4 [`EMO-1..3`]
- Never add cuts/zooms/SFX to raise a realized metric — re-choose holds/anchors; "keep the pause and fail the metric" (R2a) [`EMO-4`]
- Feel spec before first cut; 5–12 beats; ≤16KB; every cut/hold/punch/SFX references a beat + anchor; `qc_actuals` filled from rendered timeline; hold requires non-null rationale citing a signal [`FS-1..4`]
- Human review: sarcasm/irony/humor timing, claims, lyric-picture, hero-frame gaze/closed eyes (R2a) — folded into §18 review routing

### Reconciled conflicts (decision → rationale)
| Conflict | Positions | v3 decision |
|---|---|---|
| Proxy/flow | R1 240p@30f Farneback every frame · R2a 360×640@8fps absdiff + Farneback near candidates · R2b parses codec MVs | **R2a** — sandbox CPU reality; codec MVs encoder-dependent (R1's own caveat) |
| Whisper model | R1 small · R2a base · R2b small.en|base | **small int8 default, base fallback** — balance; verify at runtime |
| Rubric pass | R1 ≥17/20 no zeros · R2a all-2 · R2b ≥85/100 + auto re-edit | **R1 bands** (block: zero in anchor/speech/SFX or <12; review: 12–16 or any other zero; release ≥17 no zeros) — auto-re-edit = metric laundering, REJECTED |
| Spec size | R1 <15KB · R2a ≤32KB · R2b uncapped | **≤16KB** — token economy |
| Emotion r threshold | R1 0.6 · R2b 0.75 | **0.6** — 0.75 unvalidated, overclaims |
| Pause edits to hit beats | R2b allows ±3f mutation | **REJECTED** — source alteration; speech wins above 4f divergence; Δ>8f → hold + punch-in (R1) |

### Rejected from R2b (honesty/precision overclaim)
- "±15ms frame-exact" claims and 100%-within-tolerance enforcement; auto re-edit loop on rubric failure; −6dB breath attenuation (mutates source); synthesized −48dBFS room tone passed as real; madmom/PyAV-MV/PaddleOCR hard dependencies (fragile); sentiment-lexicon valence.
- Kept from R2b as mechanics: silence-drop before payoff words; 450ms music-swell hysteresis (4f attack/15f release); B-roll velocity trim (cut in ≥60% of shot-median velocity, out before <50%); crest-factor >14dB breath veto (as quality flag); "never two A-roll cuts at same camera scale without B-roll cover" (as review flag, not hard gate).

---

## 2. CONSULT B — MOTION GRAPHICS (3 responses: R1 calibrated, R2 binary-blockers, R3 OKLCH/Sobol)

**Base model = R1; R2's blocker discipline + operational caps adopted broadly; R3 mined for pipeline/QC
technique with its honesty violations gated.** Rule IDs in v3 §10: `MG-*`; typography/placement `DES-*` in §9.

### Adopted
- Engine sits ABOVE recipes/layout/QC: evidence → communication job → composition graph → candidates → allocation → render; **"leave the footage alone" is a selectable result** [`MG-1`]
- Classify the communication job BEFORE choosing archetype/animation; a class ≠ a visual treatment [`MG-2`]
- Moment classes (R1's 14, R2 adds speaker-id routing): HOOK/CONTEXT/STAT/STEP/EMPHASIS/CALLOUT/COMPARE/QUOTE/STAMP/TRANSITION/IDENTITY/CTA (+ identity-folio) — taxonomy table → appendix [`MG-3`]
- Evidence ledger: every displayed factual token resolves to evidence records; calibrated confidence only (never LLM self-report); high-risk classes (STAT/COMPARE/QUOTE/STAMP/IDENTITY) need p ≥ 0.98–0.995 or verification; unknown → REVIEW queue, never autonomous render [`MG-4..6`]
- **R2 binary blockers override any score** (B_NO_SOURCE, B_READ_TIME, B_CAPTION_DUP ≥0.82 similarity, B_SAFE, B_NO_FACE_DATA, B_DERIVED_CLAIM, B_VISUAL_PLACE...); a blocked moment is omitted, never rendered with a disclaimer [`MG-7`]
- Never infer place/time/price/statistic from pixels; no spelled-out→digit conversion without a unit-tested normalizer; hedge-veto: number preceded by "about/maybe/almost" → veto unless verified (R3, adopted) [`MG-8`]
- Information gain 0–3 (0 = omit); density: optional graphics ≤45% active-time union; ≤min(7, ⌊s/3⌋) primary moments; R2 count caps 3/15s, 5/25s, 7/40s; ≥12 graphic-free frames between unrelated primaries; no graphic >6f before its supporting utterance [`MG-9..10`]
- Copy transformations: verbatim / meaning-preserving deletion of whole words from span ends only (R2); punctuation normalization for quotes only; ellipsis marks any omission [`MG-11`]
- Composition graph (identify/quantify/sequence/contrast/attribute/orient/act) → up to 3 grammars × 3 free regions × widths × alignments; hard gates eliminate before ranking; score S = 0.45G + 0.25R + 0.20F + 0.10V; novelty only between near-equal candidates [`MG-12`]
- Design tokens (R1 values): display 128 / headline 88 / body 60 / label 48 px; nonessential 36px never for essential content; measure actual x-height; 12-col grid 72px margins (R2: derive regions from live safe mask, inset 8px, snap 8px — adopted over hardcoded rects) [`DES-4`]
- Palette from brand assets: CIELAB k-means on alpha ≥0.95 pixels, ΔE76<5 dedupe, chromatic cluster (C*ab≥20 or S≥0.15, fraction ≥2–5%), provisional until approved; no usable accent → neutral system; never recolor brand accent to pass contrast [`DES-5`]
- One coherent campaign language frozen (fonts/palette/geometry/easing families/shadow policy); style-frame approval gate: 6 real footage conditions + 360×640 phone previews + 3 motion proofs before batch; batch clips may not change fonts/accent/radius/stroke [`DES-6..7`]
- Variety: variation tuple; no complete repeat within 4 clips; primary archetype ≤35% rolling 12 clips; ≥2 changed dimensions between adjacent moments; deterministic seed hash(campaign:clip:moment) [`MG-13`]
- Choreography (R1 table → appendix): entrance 3–12f / exit 2–8f / stagger 2–5f; easing entrance [0.22,1,0.36,1] exit [0.4,0,1,1]; overshoot ≤1.03, ≤1/clip, never on data/measurement/tracking; backplates lead text 0–2f [`MG-14`]
- Reading time (R1 formula): H = ceil(30·(W/r + 0.25 + 0.35N + 0.35P + A)); rates 2.0–3.5 w/s by copy type; reading frames require opacity ≥0.95, ≤1px/frame movement, settled scale ±1%; if copy can't fit: shorten verified copy / extend / simplify / omit — never accelerate entrance or shrink below minimums. MODE_SYNC alternative (R2): speech-anchored full-opacity ≥ max(12f, speech span) [`MG-15`]
- Exit discipline: shot-specific graphics reach zero alpha by cut−2f; carry-through explicit, ≤1 cut, same referent; tracked graphics reinitialize at cuts; endboard holds final frame [`MG-16`]
- Entrance never in [cut−12, cut−1]; exit never completes in [cut+1, cut+12] (R3, adopted) [`MG-17`]
- SFX: ≤1 per 45f (R2); anchor the main arrival ±1f; id must exist in campaign vocabulary else silence; none during transcript words (t−0.1..t+0.2s); none on exits/routine labels [`MG-18`]
- Asset pipeline routing: A = SVG→CairoSVG (geometry only) → alpha PNG; B = drawtext (plain fallback/diagnostics); C = Python per-frame PNG (complex transforms only); capability manifest at startup; a plan uses only confirmed capabilities [`MG-19`]
- **Text shaping (R2)**: rasterize text with Pillow, never CairoSVG; if libraqm unavailable, omit any string containing codepoints > U+00FF; pin variable fonts to static instances; check glyph coverage (no tofu); features kern+liga (+tnum for counters, R3) [`MG-20`]
- Alpha/color: 2× supersample → Lanczos down; premultiplied filtering; straight-alpha PNG storage; RGB=0 where α=0; resample every frame from cached artwork; composite in RGB then single convert to yuv420p BT.709; never fade type in YUV [`MG-21`]
- 12 graphics anti-tells (R1 list, R2 additions: all-caps reading text banned, full-frame dim ≤0.25 opacity ≤12f, icon only if in brief icon map) [`MG-22`]
- QC (§18): 100% evidence coverage else block; zero hard-mask intersection +≥12px clearance; ≥24px faces / ≥16px product; ≥24px caption separation; contrast p05 ≥4.5:1 essential (7:1 target; 3:1 only for ≥96px noncritical display); phone test 360×640, x-height ≥8px; stroke ≥1.25px; tracking median ≤4px p95 ≤8px; measure contrast at 1080 AND ~390px width on composited hold frames; frame-family sampling (R3's 5 diagnostic frames + cuts) [`QC-GFX-*`]
- Archetype library: R1's A01–A12 as starter grammars (appendix); the existing 5 recipes remain callable members — number claims/progress/stamp route to them, never re-implemented inside archetypes (R2) [`MG-23`]

### Rejected / gated from R3
- Count-up tickers animating through invented intermediate values → **gated**: reveal final values only; count-up only from a verified source value with approved treatment.
- `winner_index` default-winner decoration on comparisons → forbidden without separate approved conclusion (R1-A07 rule wins).
- Caption suppression during kinetic moments; 40% full-frame dim → rejected (accessibility + R2's dim cap adopted instead).
- Hardcoded exclusion zones/margins → replaced by R2's live-mask-derived geometry.
- Uncalibrated composite confidence score (0.5·sem+0.2·aud+0.3·vis) passing as the evidence gate → schema-valid ≠ gate-pass; R1 calibrated thresholds + R2 blockers remain binding.
- 3.5 w/s reading rate for claims/quotes → use R1's 2.0–2.5 w/s (slowest applicable floor for factual copy).
- Full-bleed shutter + text-behind-subject break styles → allowed only as named campaign-approved exceptions with caps (≤2/30s; matte ≥0.92; ≤25% glyph occlusion).

---

## 3. CONSULT C — PIPELINE (4 responses: R1 reference-evaluator, R2 license-aware, R3 budget-hardened, R4 GPU-leaning)

**Base model = R1, hardened with R3's budget/ETA discipline and R2's licensing gates; R4 mined for
technique (its async-audio and sendcmd-audio paths rejected).** Rule IDs: `KF-*` (§11), `STAB-*` (§12),
`BG-*`/`COMP-*` (§13), `SYNC-*`/`ENC-*` (§16), `FAIL-*` (§20).

### Global reconciliations (the two hard forks)
| Fork | Positions | v3 decision |
|---|---|---|
| Working color/alpha space | C-R1 linear-light BT.709 premultiplied · C-R2 rgb24 premultiplied no-linear · C-R3 straight alpha until final encode · C-R4 linear sRGB · **B-R1 (graphics consult) explicitly display-referred sRGB** | **Display-referred sRGB, full-range working composite; premultiplied filtering during transforms; straight-alpha storage; explicit BT.709 limited-range delivery.** Linear-light optional only if a fixture-tested path exists. Rationale: verifiable in the Python/Pillow/FFmpeg stack, and it unifies the B and C pipelines (they must composite identically). |
| ms→frame rounding | C-R1 ties-to-even · C-R2 half-up + snap>0.25f warning · C-R3 half-up (bans Python round()) · C-R4 ties-to-even | **Half-up (`floor(t×F/1000 + 0.5)`)** — matches the chassis math contract (§8); R2's snap-distance warning adopted. Documented as a deliberate fork resolution. |

### §11 Keyframe engine — adopted
- One authoritative Python evaluator; FFmpeg expressions are optimization targets for a validated subset (translation/opacity), never a second interpretation [`KF-1`]
- Layer schema (appendix): tracks position/scale/rotation/opacity/crop/volume/pan; interpolation linear | cubic_bezier(x1,y1,x2,y2) | smoothstep(3,5,7) | damped_spring(mass,stiffness,damping,v0) analytic; ease belongs to the outgoing segment; hold before first/after last key; bounds_policy error|clamp [`KF-2`]
- Key times normalized to integer frames (half-up) BEFORE evaluation; duplicate/colliding keys after rounding = validation error; snap error >0.25f → warning [`KF-3`]
- Transform order: crop → pivot to origin → scale → rotate → translate → opacity → composite; rotation unwrapped (350→370 not 350→10) [`KF-4`]
- Springs: analytic solution, endpoint-normalized; unsettled spring at segment end = logged warning + snap at next key, never a silent jump (R2) [`KF-5`]
- Audio automation sample-accurate in Python (envelope × signal); dB domain for gain, equal-power pan; ≥5ms ramps at discontinuities; frame-quantized audio paths (sendcmd volume) forbidden as primary; never invent `volume:eval=sample` [`KF-6`]
- Render paths: A = Python evaluator + rasterized assets + compositor → FFmpeg encode (reference); B = validated FFmpeg expression subset (disclosed when used); C = baked PNG sequences for genuinely changing geometry only; never zoompan for production transforms (R3/R4) [`KF-7`]
- FFmpeg overlay for graphics: force `format=rgb` + explicit `alpha=`; never let overlay default to yuv420 chroma blending (R2) [`KF-8`]

### §12 Stabilization — adopted
- Decision tree: intentional movement (whip/POD/handheld style) → retain by default; global-coherent background → candidate; rolling shutter/parallax/foreground-dominated → global stab likely worsens; no crop margin → milder/none [`STAB-1`]
- Runtime probe: `ffmpeg -filters` for vidstabdetect/vidstabtransform; absent → do not claim stabilization; skip if already stable (HF RMS < 1.5px); never stabilize across cuts; never jello (RS index > 2px) or whip pans by default [`STAB-2`]
- Two-pass vidstab on identical conformed frames/geometry; parameter table (C-R1 conservative defaults → appendix); prefer `optzoom=0` + explicit tested zoom + `crop=black` (never crop=keep to pass QC; optzoom=2 adaptive rejected as default — breathing) [`STAB-3`]
- Validity-plate measurement of exposed borders: zero invalid pixels +2px margin [`STAB-4`]
- Gates: residual HF RMS ≤2px tripod / ≤4px walking AND ≥40% reduction; edge wobble p95 ≤3px (+≤0.5px vs input); jello RMSE ≤2.5px; crop ≤8% pass / 8–12% warn / >12% fail; subject drift p95 ≤2%; never push subject bbox outside [6%,94%]×[8%,88%] safe box (R4) [`STAB-5`]
- Fallback ladder: verified vidstab → deshake (translation-only, disclosed) → Python crop-and-track (σ=8 smoothed, export crop matrices) → retain handheld + disclose; one retry per rung then step down [`STAB-6`]

### §13 BG removal & compositing — adopted
- **No cutout promise until the model manifest shows: exact checkpoint/export/adapter loaded, timed (≥16 consecutive real frames incl. hard edges, p50/p95/RSS), license cleared** [`BG-1`]
- **Licensing gate (R2 finding): RVM is GPL-3.0 → `license_cleared=false → allowed_in_plan=false` for client campaign work unless the operator approves in writing.** Model manifest records license per model [`BG-2`]
- Per-shot selection: temporal recurrent models (RVM-class) for continuous human motion — reset at cuts/discontinuities, never parallelize recurrent frames; per-frame (U²-Net/IS-Net) for static subjects; prompted (SAM-class) for one-of-several with IoU <0.80 re-prompt; BiRefNet-class for high-detail stills [`BG-3`]
- Refuse cutouts on motion blur, transparency, fur-on-clutter, edge-hugging, tiny subjects — record refusal reason; every cutout shot ships with a pre-approved no-cutout fallback in the plan [`BG-4`]
- Temporal consistency: prefer the model's own temporal mechanism; else motion-compensated filtering (λ 0.15–0.35) only when motion confidence ≥0.8 and forward/backward error ≤2px; never average unaligned masks; static-pixel median/EMA only where |ΔY|<8/255 [`BG-5`]
- One refine pass only (erode 0.5–2px + feather σ≈1.5–3; guided filter only if verified); a second QC fail skips the cutout (R3) [`BG-6`]
- Keep alpha soft (float/gray16) through the chain; never binarize for delivery [`BG-7`]
- Segmentation gates: temporal boundary flicker p95 ≤0.08 / max ≤0.15; interior instability mean ≤0.01; matte breathing p95 ≤3%; halo ≤2px over >10% contour; coverage ≥60% of boundary measurable else not_checked; hair/transparency → sampled visual review mandatory [`BG-8`]
- Depth contract: explicit z-order; graphics-behind-subject only with QC-passed matte; subject matte between behind-graphic and foreground layers; captions composite AFTER subject (never hidden by it) [`COMP-1`]
- Original-background identity: B = over(graphic, frame); C = over(subject, B) reconstructs the original within quantization; never move the cutout off its plate position without a verified clean plate (ghost rule) [`COMP-2`]
- Grounding: contact shadow only when a ground/contact plane exists (lower ~28% of subject bbox, opacity 0.10–0.35); reflections default OFF; light-wrap default OFF (band-blend only when justified); grade-match moves the graphic toward the footage, clamped (≤±6 L*); never grade-match onto graphic backgrounds (R3) [`COMP-3`]
- Staged immutable intermediates, never one mega filter_complex; bounded 2–4 frame working queues; stream frames; peak RAM <4GB; **extrapolate ETA from the first 2–4 processed frames — if projected >10 min, degrade the plan BEFORE the full render** [`COMP-4`]
- Mezzanine: FFV1 (or x264 qp0) — never raw RGBA sequences, never ProRes on the agent path; cache QC-passed artifacts keyed by content hash + canonical params + tool/model hashes (never filename/mtime), atomic promote only [`COMP-5`]

### §16 Sync & encode — adopted
- One canonical output frame index n for RGB, mattes, graphics, automation; conform each input ONCE (fps first), then `settb=1/F,setpts=N`; never a second fps after overlay; never `-r`/`-fps_mode cfr` to repair sync; never `shortest=1` to hide length mismatch [`SYNC-1`]
- Overlay visibility: half-open `enable='gte(n,S)*lt(n,E)'` (≡ `between(n,S,E−1)`); align epochs before time-based enables; repeatlast=0; no last-frame smearing [`SYNC-2`]
- Audio: preserve source A/V offset before any timestamp reset; map samples to the output timeline; exact sample count = frames × 48000/F (at 30fps: 1600/frame); atempo chains only 0.5–2.0 per stage; no async=1 to conceal drift (log inserted/dropped samples instead) [`SYNC-3`]
- Final encode pattern (appendix): PNG/rawvideo pipe + PCM wav → explicit BT.709 conversion, `-color_primaries/trc bt709 -colorspace bt709 -color_range tv`, libx264 CRF 18, `-fps_mode passthrough`, assert dup/drop = 0 and PTS = n/F on decode [`ENC-1`]
- **Frame-truth protocol** before campaign work + after any filter/FFmpeg/renderer change: 120-frame fixture with machine-readable frame IDs (barcode) + audio beep markers at known sample indices; acceptance: exact frame count, PTS = n/F, overlay present exactly [37,60), matte/RGB zero offset, pre-encode markers ≤1 sample, final AAC ≤1ms drift, priming measured not "fixed" [`SYNC-4`]

### §20 Failure disclosure — adopted
- Capability ladder JSON: requested/achieved level, reason_code, qc_state, creative_change, approval_id, delivery_blocked + exact disclosure wording templates (appendix) for keyframes/stab/BG/compositing at best/acceptable/minimal/skip levels [`FAIL-1`]
- One retry per rung with documented secondary parameters, then step down; a failed/degraded capability forces re-planning of the affected shot — never keep the original plan with a weaker rung unannounced [`FAIL-2`]
- Never describe a capability as applied unless its gate state is pass (or pass_with_warning + disclosure); not_checked ≠ pass [`FAIL-3`]
- BG-removal degradation cascades compositing: cutout drops below usable → behind-subject graphics relocate to foreground safe zones or are omitted (R4 cascade) [`FAIL-4`]

### Rejected from R4
- sendcmd 30–100Hz frame-quantized audio automation as primary path (sample-inaccurate); `aresample=48000:async=1` allowance (R1/R2/R3 forbid; conceals sync defects); whip-pan stabilization as default; optzoom=2 walking default (breathing); unsharp after transform as default look change; 48–70s cold budget claims (unverified outlier).

---

## 4. CONSULT D — CAMPAIGN BRAIN + VIRAL (4 responses: R1 three-layer, R2 21pt/tiers, R3 30pt/floors, R4 30pt/NLI)

**Base model = R1; R3's floor-only campaign adjustments and R2's operational caps adopted; hook/moment
scale fork resolved to R1's.** Rule IDs: `CAMP-*` (§3), `PREC-*` (§4), `MOM-*` (§5), `SPN-*` (§6),
`HOOK-*`/`TEAS-*` (§8), `VAR-*`/`RND-*`/`GOV-*` (§19).

### Adopted
- "Built to go viral" = production objective expressed as **mechanics gates** (hook score, payoff placement, rewatch structure, share trigger, variety entropy); never outcome prediction; no virality probability, view-count, or retention estimates; records say "designed for / placed at / scores", never "will perform / guaranteed" [`CAMP-1`]
- Four layers: L0 governance (existing honesty/compliance — unoverridable) / L1 craft core (versioned) / L2 campaign profile (every field hard|floor|default) / L3 creative strategy (per batch/clip) [`PREC-2`]
- Precedence: honesty/compliance > locked owner mandates > campaign hard requirements > craft defaults > agent preferences; lower tiers change HOW, never WHETHER; contradictory hards → unsatisfiable-constraint report, never a silent winner; no weighted score compensates a hard failure [`PREC-1`]
- Campaign may RAISE floors (hook minimum, taste bar), never lower below core minimums, never waive deception guards or timecode citations (R3) [`CAMP-2`]
- Volume target vs craft floor conflict → ship the qualifying subset + gap report; do not fill quota with weak/fabricated hooks [`CAMP-3`]
- Campaign profile contract (R1 YAML, appendix): objective/audience/viewer_value, delivery, owner mandates, hook policy, teaser policy, compliance gate refs, taste defaults, brand tokens, banned patterns, CTA rules, variety budget, platform targets; missing facts stay missing (no invented audience personas) [`CAMP-4`]
- Hook: three channels (visual/audio/text) reinforce ONE bounded promise, each citing source evidence; first-3s composition (meaningful frame 0; text readable ≤0.15s unless designed reveal; meaningful audio ≤0.6s; subject + promise legible ≤3s; 2–8 words ≤2 lines; dwell ≥ max(1.2s, 0.35s×words)) [`HOOK-1..3`]
- Hook rubric (R1 6 dims × 0–4 = 24): strong 18–24 with visual/audio/text each ≥3 and others ≥2; mid 12–17 (enters only after documented rework, ≤25% of batch — R2 cap); weak ≤11 or channel ≤1 → revise before batch; kill criteria (unsupported premise, unidentifiable answer, removed qualification, absent/unrelated channel, ineligible source, unreadable opening) override any score; paper rubric rechecked on rendered frames [`HOOK-4..6`]
- Silence-open is a legal audio hook only if meaningful audio enters by the profile deadline (default 0.6s) [`HOOK-7`]
- Teaser (peak-first): authentic peak fragment 0.4–1.25s from an eligible moment IN THIS SOURCE sharing event identity with setup and payoff; context to ~0.25T; payoff completes 0.70–0.85T with ≥1.0s hold; contract booleans verified pre-lock: same_event ∧ variable_arrives_uncut ∧ pct_in_window ∧ ¬open_already_resolves (R3) [`TEAS-1..2`]
- Peak-type classification (process/reveal/verbal — R2): reveal & verbal peaks never show the resolution frame in the teaser; use reaction-onset/question/mystery opens; blind-slice legibility test — cold open alone must name subject+action else switch to context-first [`TEAS-3`]
- Deception guardrails: preview preserves qualifications at FIRST exposure; no cross-event reaction implication; "earlier" only with established chronology; preview may withhold resolution, never create a false outcome; full result shown first cannot be recounted as a delayed reveal; payoff answers the opening promise, not a substitute moment; loops leave the first viewing complete (no hidden answer, no cut-off word) [`TEAS-4..5`]
- "Wait for it" overlays: ≤1, before 50% of runtime, verified payoff, ≤10% of batch (R2) [`TEAS-6`]
- Moment scoring (R1): candidate cards with inspected timecodes + observable cues; M = Σw·s/4 (novelty 15, intensity 15, specificity 20, payoff 25, visual 15, audio 10); strong M ≥75 + specificity ≥3 + payoff ≥3; **rights = gate, never weight** (R3's rights-as-weight REJECTED); inner-state language labeled inference [`MOM-1..3`]
- Story spine: 1 promise + 1–2 setup + 1–3 escalation + 1 payoff + optional closure; setup ≤25% runtime; among peaks within 5 points prefer less setup; prune every beat that does not establish context, advance the question, supply a qualification, or close; over-duration → prune escalation first, never the payoff hold or legibility-critical setup (R2) [`SPN-1..2`]
- Zero-strong-moment cases: (A) usable evidence exists → build concept around a genuine moment, keep original scores (no inflation), publish only if hooks/taste pass; (B) none → hold, emit missing-footage request, return fewer clips — never manufacture a peak [`MOM-4`]
- R&D loop: a new method changes information structure (when/what/how/why/what-idea), not cosmetics; hypothesis record pre-registers ONE treatment factor, held-constant list, primary metric + denominator, minimum meaningful difference, guardrails, design class (controlled|exploratory) [`RND-1..2`]
- Existing pilot allowance (≤3) is consumed by control+treatment; multi-change comparisons labeled exploratory; no performance decision before 72h; default comparison 7d; extend to 14d else inconclusive; ~4,400 eligible observations/arm for ±3pp binary planning (or ≥6 matched pairs with ≥65% win-rate — R2); ≥50 events for rare metrics; missing metrics stay missing (no reconstruction from unrelated totals; a looping retention curve is not a rewatch count) [`RND-3..5`]
- Keep/kill: promote locally only with predeclared threshold met + guardrails non-inferior; promote to campaign profile after a second agreeing batch; to craft core only after a second campaign or versioned review; every learning carries do_not_generalize_beyond + transfer conditions + retest triggers; expire trend-dependent learnings at 30d (R2) [`RND-6`]
- Variety: six-axis records (hook family, opening beat, pacing curve, graphic archetype, ending, audio strategy); axis caps 25/25/30/35/30/35% (defaults, campaign-adjustable); exact signature ≤10%; max 2 consecutive identical opening beats (R2); literal cold-open-peak family ≤60%, remainder approved alternatives (R2); same source peak reused >10% → review; second use of a peak = labeled recut with different hook text AND ending (R3); normalized entropy ≥0.70 on feasible labels; feasibility check Σ⌊cap×N⌋ ≥ N else scoped exception request [`VAR-1..4`]
- Same-y detection: pairwise weighted signature similarity ≥0.80 clusters flagged; opening-template similarity (layout+beat order + text skeleton ≥0.85 + same 0.1s timing bins); rhythm convergence (mean shot duration, caption interval, accent density all within ±10%); relabeled duplicates detected as the same pattern [`VAR-5`]
- Rotation budget 70% established / 20% adjacent variations / 10% new-method candidates within pilot capacity; never pick a weak variant to satisfy diversity; ≥10% of batch reserved for footage-motivated deviations from craft defaults (canary — missed twice → freeze new rules, R3) [`VAR-6`]
- Governance: every rule carries id, trigger, severity, exceptions+authority, fallback, ≥2 prevented defects, golden fixture, review date; ≤8 active soft directives per decision stage (≤2 per axis); hard gates never pruned to satisfy budgets; rule firing >50% of clips = template rule → narrow or reclassify (R2); overridden >30% → rewrite (R2) / >70% prefer-rules → downgrade (R3); zero fires over 2 campaigns/300 clips → retire (R2) [`GOV-1..3`]
- Taste rubric: story clarity 25, source fit 20, restraint 15, rhythm 15, readability 15, brand fit 10; accept ≥75/100, no dimension <2, clarity/source-fit/readability ≥3; hard gates separate [`GOV-4`]
- Creativity regression: paired before/after renders on identical footage + seed; adopt a rule change only if median taste ≥−3, ≤20% of fixtures lose >7 points, no new critical failure, feasible distinct candidates ≥80% of baseline, hard-block fixtures still block [`GOV-5`]
- Version freeze per render: core/profile/rule-set/strategy/source-manifest/platform-spec versions; never reinterpret old results under a new rubric [`GOV-6`]
- 10 failure modes with mechanism-level countermeasures (R1 table → §19; "diagnose which mechanism failed, never answer weak clips with more cuts/louder sound/bigger text") [`VAR-7`]
- Analytics winner stays a scoped prior; analytics never rewrites quotas or the hook floor; ≤40% batch share for any winning pattern; ≥20% on non-modal structures (R2/R3) [`VAR-8`]

### Reconciled fork: hook & moment scales
R1 24pt/0–4 · R2 21pt/0–3 · R3 30pt/0–5 (floor 18, raisable) · R4 30pt/0–5 (min 22, NLI gates).
**Decision: R1's 24pt rubric as core default** (it ships with the profile schema); campaign profiles may raise
the floor (never below 18); R2's mid-band cap adopted; R4's NLI gate noted as an optional calibrated
classifier, not a default dependency. Moment scoring likewise R1's 0–4/weights-100 form (R3's
rights-as-weight and R4's multiplicative gates documented as rejected alternatives).

### Rejected
- R2's 0.60 entropy floor (unvalidated looseness) → 0.70 kept; R2's 15% setup cap (starves truthful context) → 25% kept; R4's ≥2,500-view/MDE-12% autonomous thresholds (platform-dependent overprecision) → planning guidance only; R3's 60% setup allowance (spoiler risk) → 25% kept; any analytics-driven quota rewriting; any synthetic-comment/fake-urgency/correction-farming engagement ideas (all four responses converge — hard ban).

---

## 5. WHAT v3 REJECTS GLOBALLY (honesty screen applied to all 14 responses)
1. Outcome prediction in any form (virality probability, view counts, retention estimates).
2. Auto-re-edit loops that re-cut until metrics pass (score laundering) — revision always routes through review.
3. Source mutation to hit grids (pause stretching, breath attenuation, beat-motivated audio edits).
4. Invented intermediate values (count-ups), winner decoration without approved conclusions, uncalibrated confidence standing in for evidence.
5. Accessibility/honesty regressions (caption suppression, >0.25 full-frame dim, hardcoded safe zones replacing live masks).
6. Unverified capability claims (model loads, filter options, sendcmd syntax, license status) — everything starts `not_checked`.
7. Sample-quantized audio automation; async resample to hide drift; shortest=1 to hide length mismatches.
8. GPL-3.0 models in client deliverables without written operator approval.

## 6. COVERAGE LEDGER (consult RULE lines → v3 homes)
- A: 45 R1 rules + 25 R2a + 30 R2b → §7 (`SIG/RHY/CUT/TELL/EMO/FS`), §8 pacing, §18 rubric/review routing. Rejected: 6 (see §1).
- B: 40 R1 + 53 R2 + 10-of-32 R3 → §9–10 (`DES/MG`), §18 `QC-GFX`, appendix archetypes/tokens. Rejected/gated: 9 R3 items.
- C: 35 R1 + 33 R2 + 35 R3 + 15-of-31 R4 → §11–13, §16, §20 (`KF/STAB/BG/COMP/SYNC/ENC/FAIL`), appendix. Rejected: R4 audio path + 5 items.
- D: 45 R1 + 35 R2 + 35 R3 + condensed R4 → §3–6, §8, §19 (`CAMP/PREC/MOM/SPN/HOOK/TEAS/VAR/RND/GOV`), §20 operator checklist. Forks resolved: 4 (scales, windows, caps, setup share).

---

## 7. POST-BUILD OUTCOME NOTES (honest record)

**Size vs the P2 target.** The roadmap targeted ≤55k chars for the master prompt — set when the expected
consult volume was 4 single responses (~60k chars of source material). The actual return was 14 model
responses totaling ~724k chars. Final build: master prompt 106.8k chars (§10–13 marked LOAD ON DEMAND →
standing context ≈82k chars ≈20k tokens vs the user chassis's ~12k), appendix 22k chars, integration
map 38k. Compression ratio from consult source to master: ~7:1. Every roadmap-mandated P0/P1 element
is present and audit-verified; the size overage buys the four capability engines the user explicitly
prioritized ("complete brain, not a limited one"). If a leaner variant is wanted later, the highest-
value cut is §10.3–10.5 detail (→ appendix) and §19 prose tightening; the compliance spine and feel
engine must never be the cut.

**Audit.** `scripts/v3_regression_audit.py` (2026-10-26): ALL CHECKS PASS — 6/6 v2.1 patches, 5/5
compliance restorations (R1–R5), 7/7 defect fixes (D1–D7), 11/11 user improvements preserved, 27/27
rule-ID domains greppable, all section cross-references resolve. Re-run it after any future edit to v3.

**Known open items.** (1) v3 is prompt-verified, not yet output-verified — the T1–T6 live tests from
the roadmap (Mode B smoke test, compliance probe, math probe, honest-status probe, pilot diversity,
paired rule-on/rule-off render) should run on the first 3-pilot batch before trusting it at scale.
(2) The RVM GPL-3.0 licensing block [BG-2] needs an operator decision per campaign. (3) Hook/moment
scale unification (R1's 24pt) should be recalibrated once ≥20 scored clips exist.
