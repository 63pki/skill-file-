# RexTrix — 10-Clip Campaign Compliance Review
Reviewed: 2026-10-24 · Reviewer: independent QC pass (frame extraction + ffprobe + ebur128 + ASR)
Input: Google Drive zip (10 MP4 + DELIVERY_MANIFEST.md), delivered 2026-10-23 as "review_draft" from Pro Editor Brain v2 Mode B run.

## VERDICT: 10/10 PASS on campaign gates — cleared for posting, subject to the operator checklist and two minor residual notes.

---

## 1. Technical verification (measured, all 10 clips)

| Check | Requirement | Result |
|---|---|---|
| Resolution | 1080 × 1920 | PASS — all 10 |
| Aspect | SAR 1:1, DAR 9:16 | PASS — all 10 |
| Frame rate | CFR 30/1 | PASS — r_frame_rate = avg_frame_rate = 30/1, all 10 |
| Frame count | 660 (22 s × 30) | PASS — nb_read_frames = 660/660, no truncation |
| Codec / pixel format | H.264 High / yuv420p | PASS — all 10 |
| Audio | AAC-LC 48 kHz stereo | PASS — all 10 |
| A/V duration match | equal | PASS — audio_duration = video duration, all 10 |
| Full decode | no errors | PASS — decoded in full during loudness pass |
| Loudness (measured) | −14 LUFS ±2 project default | PASS — measured −16.3 … −13.6 LUFS |
| True peak (measured) | ≤ −1.0 dBTP | PASS — max −1.0 (Clips 02, 04 at the limit) |

Note: my measured loudness range (−16.3 … −13.6) differs slightly from the manifest's claimed
(−13.1 … −15.6) — within measurement-configuration tolerance; no clip is out of spec.
Clip 01 is the quietest (−16.3 LUFS, 2.3 LU under target) — harmless; platforms normalize.

## 2. End card gate (the Clip 16 rejection rule) — 10/10 PASS

Frames sampled at t = 18.3 s, 20.3 s, 21.6 s on every clip:
- RexTrix LOGO GRAPHIC present (two-tone wordmark + diamond) — yes, all 10
- Wording "Download the RexTrix app" + "Link in bio" — yes, all 10 (explicit download
  instruction; NOT the rejected text-only "to try RexTrix" wording)
- Tagline "AI-generated Games & Stories" — yes, all 10
- Card spans the full ~4 s tail (18 → 22 s), no blank tail frames detected at 21.6 s

## 3. Language gate (the Clip 15 rejection rule) — PASS

ASR transcription of 0–17.5 s source-arc audio:
- Clips 01–06, 08–10: English speech (sample: "He's not normal, his shadow moves on its own",
  "I trained my employee into Office GPT…", "Game one, Grandma's footsteps…")
- Clip 07 (AI band): NO speech detected (music performance clip) — burned-in text verified
  English visually ("YOUR NEW FAVOURITE AI BAND", ELI/RYAN/DAMON/ALEX/RAVEN, NEON RIOT)
- No non-English speech detected in any clip. Burned-in subtitles spotted in frames are English
  (incl. Clip 10's "BUT IS IT TIME TO OUR MOVE" — awkward grammar but English, source's own text).

## 4. Banned claims / prohibited content — PASS

- No "free", "unlimited generations", "earn real money" wording in any sampled frame or transcript
- No invented-capability claims; hooks are story hooks, not product claims
- No fabricated-analytics elements (no screenshots of stats anywhere)

## 5. RexTrix connection — PASS with 1 note

- End card (brand + tagline + CTA): all 10 clips, 4 full seconds — this alone satisfies
  "clear RexTrix connection + on-screen CTA"
- Source watermark visible in sampled frames: Clips 01 (top-right), 02 (bottom-left),
  03/04 (top-center), 07 (card art + bottom-center), 08 (bottom-left), 10 (top-left)
- NOT visible in my sampled frames: Clips 05, 06, 09 (dark scenes) — the watermark may still
  appear at other moments. Residual risk is LOW because the end card carries the connection,
  but do one human eyeball pass on 05/06/09 in motion before posting.

## 6. Format treatment — PASS

- Blurred-pad vertical treatment (no sliced faces/text) — visible and clean on all sampled frames
- Hook pill sits immediately above the main video (v2 caption-safe-area fix verified in output)
- All burned-in text inside the top ~78% frame zone

## 7. Manifest accuracy spot-check

The DELIVERY_MANIFEST.md claims held up under independent measurement (specs, frame counts,
decode, end card, language, rejected-source handling). Two honest caveats confirmed by the
manifest itself and visible in frames:
- Sources were 640×360 → main-image band is soft/low-detail. Not a compliance failure, but it
  will cost retention vs. native-vertical competitors. Fix: supply higher-res masters.
- "No external music/voiceover" is consistent with the audio I heard/transcribed (source-trailer
  dialogue + score) but is not independently verifiable without the source files — status:
  not checked, not failed.

## 8. What this review could NOT check (operator items)

- Caption text (must mention "RexTrix", ideally first 3–4 words) — captions were not supplied
- Bio link live on the posting account from day 1
- 30-minute URL submission window · 24 h analytics screen recording · 40%+ US audience
- Human playback review of the full 0–18 s arcs (manifest correctly ships as review_draft)

## Bottom line

Post these 10 after: (a) your quick motion check on Clips 05/06/09 watermark, (b) writing
compliant captions, (c) confirming the bio link is live. Then run the standard operator
checklist: submit URLs ≤30 min, analytics recording at 24 h, keep posts public.

---

# Addendum (2026-10-24, second independent pass)

A full re-verification was run on the same 10 files (fresh frame extraction at 6 timestamps
per clip incl. boundary frames at 17.5/18.0/21.9 s, fresh ffprobe pass, keyframe+audio decode
integrity on all 10, fresh ASR transcription of all 10 audio tracks, ebur128 re-measurement).
All findings in the original report above were reproduced. Three additional findings:

## A1. End card sits at exactly 4.0 s — zero margin (AT RISK, campaign-rule edge)

Boundary frames prove the transition to the end card lands precisely at t=18.0 s on all 10
clips, and the card holds to the final frame (21.9 s sample) — i.e., the card duration is
exactly 4.0 s, precisely at the campaign minimum with no margin. It passes today, but any
rounding difference, platform-side trim, or preview cropping could silently bring it under
4 s — the exact failure class that got Clip 16 rejected. Recommendation: re-render with the
card starting at 17.5 s (4.5 s duration). Encoded into the prompt as patch **P-V1**.

## A2. Clip 07 language verification is provisional, not failed (PASS with condition)

Fresh ASR again returned no speech for Clip 07 (music performance clip). Burned-in text is
English (verified visually). The English gate is therefore *not violated* — but it is also
*not provably satisfied* if the song contains vocals. Operator: play Clip 07 once and confirm
any vocals are English before posting. Encoded into the prompt as patch **P-V2**.

## A3. Manifest loudness claims not exactly reproducible (QC hygiene)

Measured (this pass): Clip 01 −16.3 LUFS · Clip 05 −14.3 · Clip 10 −13.6. The manifest
claimed −13.1..−15.6 across all 10; Clip 01 falls outside that claimed range and 2.3 LU under
the −14 target. Harmless for posting (platforms normalize; speech is audible), but the
discrepancy shows QC numbers were produced by unstated tooling or pre-render estimates.
Encoded into the prompt as patch **P-V4** (named-tool measurement + 1.5 LU re-norm trigger)
and **P-V6** (claims must state their reproducing command).

## A4. Logo provenance — still operator-confirmable

The end-card wordmark (two-tone serif "RexTrix" + diamond) is consistent and professional, and
the manifest states it was sourced from rextrix.ai. The rextrix.ai homepage fetched during
review does not display the wordmark, so authenticity could not be confirmed from the sandbox.
This was already a `[TO CONFIRM]` field in REXTRIX_campaign_input.md — confirm once with the
client and the whole campaign is covered.

## Updated verdict

10/10 PASS on campaign gates, unchanged. Items that are *operator-side before posting*:
1. Motion-check watermark visibility on Clips 05/06/09 (A1 note above)
2. Confirm Clip 07 vocals are English (A2)
3. Write captions with "RexTrix" in the first 3–4 words; bio link live
4. Submit URLs ≤30 min; 24 h analytics recording; 40%+ US-audience account
5. Optional but recommended: re-render with 4.5 s end cards (A1) and supply ≥720p sources
   for sharper masters (P-V3)
