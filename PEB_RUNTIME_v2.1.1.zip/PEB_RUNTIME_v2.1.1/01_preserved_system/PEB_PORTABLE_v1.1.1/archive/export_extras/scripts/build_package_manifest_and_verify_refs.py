#!/usr/bin/env python3
"""Handoff package tooling: local-reference verification + SHA-256 manifest.

Modes:
  check    - scan the package's living navigation docs for local file references
             (markdown links + backtick path-like strings), verify each resolves
             inside the package, and write 07_status/REFERENCE_VERIFICATION.md.
  manifest - write PACKAGE_MANIFEST.md with SHA-256 + size for every file.

Verification design (matches the operator's instruction "verify that local
references resolve inside the package"):
- STRICT docs = the package's own navigation/guidance documents (authored for this
  package): every relative reference must resolve inside the package.
- INFORMATIONAL pass = byte-exact project documents (master prompt files, reports,
  inventory, tests, patches) and vendor/library bodies: their references point at
  the original project tree by design (they are versioned records, not rewritten);
  unresolved ones are reported as INFO, not failures.
- Explained exclusions (intentional, documented): upload-to-claude/ (verified
  duplicate zips excluded from the package by design)."""
import hashlib, re, sys, datetime
from pathlib import Path

PKG = Path("/home/z/my-project/download/HANDOFF_PACKAGE_PEB_RexTrix_v1.0")

STRICT_DOCS = [
    "START_HERE.md",
    "02_registry/SKILL_REGISTRY_v1.0.md",
    "04_catalogs_and_resources/CATALOG_GUIDANCE_v1.0.md",
    "05_components/COMPONENTS_MAP.md",
    "06_setup/DEPENDENCIES_AND_SETUP.md",
    "07_status/STATUS_LEDGER.md",
    "07_status/PENDING_RULINGS.md",
    "archive/ARCHIVE_INDEX.md",
]
EXPLAINED_EXCLUSIONS = {
    "upload-to-claude/": "intentionally excluded from the package: per-style zips are verified byte-identical duplicates (80/80 SHA-256) of the included loose dirs; see START_HERE §6 and 07_status/evidence/pack_equivalence_result.json",
}
INTENTIONAL_MENTIONS = {
    "skills/cinetic/SKILL.md": "remote repository path tail cited by the PRIORITY REFERENCE block (Leonxlnx/cinetic shortlist link)",
    "skills/cinematic-shot/SKILL.md": "remote repository path tail (1weiho/cinematic-shot shortlist link)",
    "skills/motion-broll/SKILL.md": "remote repository path tail (barty-bart/motion-graphics shortlist link)",
    "skills/motion-design/SKILL.md": "remote repository path tail (nexu-io/open-design shortlist link)",
    "plugins/_official/video-templates/frame-liquid-bg-hero/SKILL.md": "remote repository path tail (open-design template example)",
    "SKILL.md": "generic vendor skill-body filename (video-frames closure note); actual bodies exist per style dir in 04_catalogs_and_resources/",
    "scripts/frame.sh": "file inside the inspected remote steipete/video-frames skill (not shipped here; the skill was rejected)",
    "github.com/steipete/clawdis": "remote repository identifier (no scheme), cited as source of the rejected video-frames skill",
    "itsjwill/vanta": "repository slug of the reclassified engine (no local body; deliberately not in the package)",
    "render.py": "per-style vendor script name mentioned descriptively; actual files at 04_catalogs_and_resources/claude-motion-styles-20/<style>/render.py",
}
EXT_RE = re.compile(r"[^/`]+\.(md|json|txt|py|sh|pdf|zip|jpg|jpeg|png|mp4|mov|wav|html|webm|ts|js|css)$", re.I)
MD_LINK_RE = re.compile(r"\[[^\]]*\]\(([^)\s]+)\)")
BACKTICK_RE = re.compile(r"`([^`\n]+)`")

def is_candidate(ref: str) -> bool:
    if ref.startswith(("http://", "https://", "mailto:", "#", "ftp://")):
        return False
    if " " in ref or ref.startswith("-") or "{" in ref or "<" in ref:
        return False
    if "/" in ref:
        return True
    return bool(EXT_RE.match(ref))

def extract_refs(text: str):
    refs = set()
    for m in MD_LINK_RE.finditer(text):
        refs.add(m.group(1).split("#")[0])
    for m in BACKTICK_RE.finditer(text):
        r = m.group(1).strip().rstrip(".,;:")
        if is_candidate(r):
            refs.add(r)
    return {r for r in refs if r}

def check_docs():
    findings, info = [], []
    for rel in STRICT_DOCS:
        doc = PKG / rel
        if not doc.exists():
            findings.append((rel, "(the strict doc itself is missing!)", "MISSING"))
            continue
        text = doc.read_text(encoding="utf-8")
        for ref in sorted(extract_refs(text)):
            target = (doc.parent / ref).resolve()
            try:
                inside = target.is_relative_to(PKG.resolve())
            except AttributeError:
                inside = str(target).startswith(str(PKG.resolve()))
            if target.exists() and inside:
                continue
            if ref in EXPLAINED_EXCLUSIONS:
                findings.append((rel, ref, "EXPLAINED-EXCLUSION"))
            elif ref in INTENTIONAL_MENTIONS:
                findings.append((rel, ref, "INTENTIONAL-MENTION"))
            elif target.exists() and not inside:
                findings.append((rel, ref, "ESCAPES-PACKAGE"))
            else:
                findings.append((rel, ref, "BROKEN"))
    # informational pass: everything else (project docs copied byte-exact + vendor bodies)
    for p in sorted(PKG.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in (".md", ".json", ".txt"):
            continue
        rel = p.relative_to(PKG).as_posix()
        if rel in STRICT_DOCS or rel.startswith("archive/") or rel in (
            "07_status/REFERENCE_VERIFICATION.md", "PACKAGE_MANIFEST.md"):
            continue
        text = p.read_text(encoding="utf-8", errors="replace")
        for ref in sorted(extract_refs(text)):
            if ref in EXPLAINED_EXCLUSIONS or ref in INTENTIONAL_MENTIONS:
                continue
            target = (p.parent / ref).resolve()
            if not target.exists():
                info.append((rel, ref))
    return findings, info

def write_verification(findings, info):
    lines = []
    lines.append("# REFERENCE VERIFICATION — local references resolve inside the package (2026-10-28)\n")
    lines.append("Checker: `scripts/build_package_manifest_and_verify_refs.py check` (this workspace) — markdown links + backtick path-like strings; STRICT pass over the package's own navigation docs, INFORMATIONAL pass over byte-exact project documents and vendor bodies (their references point at the original project tree by design and are preserved unedited).\n")
    broken = [f for f in findings if f[2] == "BROKEN"]
    escapes = [f for f in findings if f[2] == "ESCAPES-PACKAGE"]
    explained = [f for f in findings if f[2] == "EXPLAINED-EXCLUSION"]
    mentions = [f for f in findings if f[2] == "INTENTIONAL-MENTION"]
    missing = [f for f in findings if f[2] == "MISSING"]
    lines.append(f"**STRICT pass: {len(STRICT_DOCS)} navigation docs scanned — {len(broken)} broken, {len(escapes)} escaping the package root, {len(explained)} explained exclusions, {len(mentions)} intentional remote/descriptive mentions, {len(missing)} missing docs.**\n")
    if broken:
        lines.append("\n## Broken (must fix)\n\n| Doc | Reference |")
        lines.append("|---|---|")
        for d, r, _ in broken:
            lines.append(f"| `{d}` | `{r}` |")
    if escapes:
        lines.append("\n## Escaping package root (must fix)\n\n| Doc | Reference |")
        lines.append("|---|---|")
        for d, r, _ in escapes:
            lines.append(f"| `{d}` | `{r}` |")
    if explained:
        lines.append("\n## Explained exclusions (intentional, documented)\n\n| Doc | Reference | Reason |")
        lines.append("|---|---|---|")
        for d, r, _ in explained:
            lines.append(f"| `{d}` | `{r}` | {EXPLAINED_EXCLUSIONS[r]} |")
    if mentions:
        lines.append("\n## Intentional mentions (documented — remote or descriptive, not package references)\n")
        lines.append("| Doc | Mention | Why it is not a package reference |")
        lines.append("|---|---|---|")
        for d, r, _ in mentions:
            lines.append(f"| `{d}` | `{r}` | {INTENTIONAL_MENTIONS[r]} |")
    if not broken and not escapes and not missing:
        lines.append("\n**Result: PASS — every reference in the package's navigation documents resolves to a file inside the package, or is a documented explained-exclusion / intentional mention.**")
    lines.append(f"\n## Informational pass (byte-exact project docs + vendor bodies): {len(info)} unresolved references — expected\n")
    lines.append("These documents are versioned records or vendor material copied unedited; their path citations refer to the original project tree (`/home/z/my-project/...`), where they do resolve. Listed for transparency; not failures. The strongest evidence artifacts are mirrored inside the package (`07_status/evidence/`, `05_components/`).\n")
    if info:
        lines.append("| Doc | Reference (resolves in original project tree) |")
        lines.append("|---|---|")
        for d, r in info[:200]:
            lines.append(f"| `{d}` | `{r}` |")
        if len(info) > 200:
            lines.append(f"\n(+{len(info)-200} more)")
    out = PKG / "07_status" / "REFERENCE_VERIFICATION.md"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return broken, escapes, missing

def write_manifest():
    rows, total = [], 0
    for p in sorted(PKG.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(PKG).as_posix()
        if rel == "PACKAGE_MANIFEST.md":
            continue
        b = p.read_bytes()
        rows.append((rel, len(b), hashlib.sha256(b).hexdigest()))
        total += len(b)
    lines = ["# PACKAGE MANIFEST — HANDOFF_PACKAGE_PEB_RexTrix_v1.0 (generated 2026-10-28)\n",
             f"**{len(rows)} files · {total:,} bytes total.** Every file SHA-256-hashed. Verify any file: `sha256sum <path>` and compare.\n",
             "| File | Bytes | SHA-256 |", "|---|---|---|"]
    for rel, n, h in rows:
        lines.append(f"| `{rel}` | {n:,} | `{h}` |")
    (PKG / "PACKAGE_MANIFEST.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"manifest: {len(rows)} files, {total:,} bytes -> PACKAGE_MANIFEST.md")

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "check"
    if mode == "check":
        f, i = check_docs()
        b, e, m = write_verification(f, i)
        print(f"strict findings: {len(f)} (broken={len(b)}, escapes={len(e)}, explained-exclusion={sum(1 for x in f if x[2]=='EXPLAINED-EXCLUSION')}, mention={sum(1 for x in f if x[2]=='INTENTIONAL-MENTION')}, missing={len(m)}); informational: {len(i)}")
        for d, r, k in f:
            print(f"  [{k}] {d} -> {r}")
        sys.exit(1 if (b or e or m) else 0)
    elif mode == "manifest":
        write_manifest()
    else:
        print("usage: script [check|manifest]"); sys.exit(2)
