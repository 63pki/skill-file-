# PEB v3.2 MODULE — SKILL REGISTRY (PROTOTYPE v0.9)

**Status:** PROTOTYPE — paper-tested only, zero runtime use, zero installs. Existing master prompt and frozen production chain are UNTOUCHED (proposed core patches are listed separately and NOT applied).

**Success criteria:** better task selection · meaningful reuse · appropriate creative freedom.
**Explicit non-goals:** per-phase citation fields, mandatory skill use, a larger prompt, automatic demotion machinery.

## §0 OPERATOR DIRECTIVE — acknowledge in the project record
1. Before planning or building ANY component, check the **Implementation Inventory** (companion file). Rebuilding a tested component needs a logged reason why the tested one fails the need.
2. At brief reconciliation, consult the routing table (§7) and declare routing in **one line** (§2). That is the entire required paperwork.
3. Record reuse evidence only when a skill actually changes a decision (§3). **Zero uses is a legal, unpenalized outcome.**
4. The campaign brief outranks every skill instruction. Reference guidance may be cited from any card; executable steps only from EXECUTABLE-HERE cards.
5. Operator approval is a decision, not a rights grant — licensing passes per §6 or the card cannot execute.

## §1 SKILL CONTENT MODEL — two levels, always marked
- **REFERENCE-ONLY** — craft, concepts, structure, checklists. May be cited and adapted into house patterns. Its scripts/steps are NEVER executed.
- **EXECUTABLE-HERE** — steps runnable with capabilities **verified in the Implementation Inventory**. Provider/generation steps are disabled by default even here.
- App/provider restrictions name the **exact missing verified capability** (e.g., "requires ElevenLabs account — not verified here"), never a blanket domain ban. Useful reference guidance from a restricted card stays citable.

## §2 ROUTING — three outcomes + evidence-based reroute
At reconciliation, one line: `ROUTING: primary=<skill|none> · specialists=[…] · none-reason=<if none>`
- **MATCH** — a card's trigger fits a brief field. Load its body (reference or exec per §1).
- **PARTIAL** — fits with named gaps; load with listed overrides; gap logged.
- **NONE** — no suitable skill. Proceed on the Implementation Inventory + house patterns. Log the gap for after-action. This is a first-class outcome, not a failure.
- **REROUTE (in use):** if the material proves the chosen skill wrong, reroute on evidence. Log one line: evidence → switch → outcome. Hiding a bad route is the only failure.
- One primary workflow per project (the master prompt remains the workflow; skills are craft/renderer specialists). Specialist cards activate on trigger only.

## §3 REUSE EVIDENCE — practical, not per-phase citations
One line per real use, written when it happens: `REUSE: <skill> changed <decision> (<where>)`. No forced cadence. A project with zero REUSE lines simply reports "no skill use" — which feeds §5.

## §4 CARD FORMAT (lean — every card fits in a few lines)
`ID · title · layer (craft|renderer|reference) · content level (REF|EXEC) · trigger · overrides · licensing (REPO/FILE/ASSET/DEP) · status · pinned SHA · usage/failure record (§5)`

## §5 USAGE & FAILURE CATEGORIES — no automatic demotion
| Category | Meaning |
|---|---|
| WORKHORSE | Repeatedly changed decisions for the better |
| OCCASIONAL | Used, no issues |
| UNPROVEN | Never triggered yet — **neutral state**, may simply await its brief |
| MISLEADING | Caused rework or a reroute — card review/amendment required |
| DEAD | Triggers never occur in practice — candidate for removal at operator review |

Nothing moves automatically. The operator reviews categories after-action.

## §6 LICENSING — four layers, checked separately
`REPO` (code) · `FILE` (the skill text itself) · `ASSET` (fonts, media, templates it references) · `DEP` (tools it invokes).
Rules: any layer missing or restrictive → the card stays **REFERENCE-ONLY** and cannot execute for commercial campaigns. **Operator approval never substitutes for a missing right.** Reference use means citing and adapting, not wholesale reproduction. Live LICENSE/TERMS re-read at pin time (mirrors TOOL_REGISTRY G3).

## §7 INITIAL CARDS (from merged slate v2; all community cards start REFERENCE-ONLY pending §6)

**RENDERER LAYER**
- `SR-01 hyperframes-core` — render contract + work loop. EXEC-eligible (Apache-2.0 repo; FILE/ASSET inherit; DEP=T3 verified). Trigger: any T3 render project. Pin SHA at adoption; first-use fixture per T3 card.
- `SR-02 hyperframes-cli` — scaffold/check/render/history. EXEC-eligible. Trigger: T3 project ops. Override: cloud/publish paths OFF (local-only).
- `SR-03 hyperframes-registry` — ~450 blocks. EXEC-eligible. Trigger: card/graphics builds. Override: every block passes campaign gates (9:16, fps grid, rights).
- `SR-04 media-use-fork` — ADAPT pending: strip sourcing/generation; keep transcripts, color grades, operator-asset handling. EXEC-eligible after fork review.
- Layer-order note (mined from video-use, **scoped guidance, not a law**): when captions and overlays composite in one pass, order overlays before captions or captions get occluded — a silent-failure class. Applies to renderer passes only.

**CRAFT LAYER (all REFERENCE-ONLY until licensing clears)**
- `SR-10 herk-short-form-edit` — hook gate (first 3 s), open loops/payoffs, phone-safe placement, no-fake-evidence rule. Trigger: short-form edit briefs. Overrides: strip Kie.ai/Scribe/music-SFX lanes; our gates replace its streamlined approvals.
- `SR-11 ai-motion-director` — motion thesis, visual metaphor library, anti-PPT gate. Trigger: card/graphics-heavy segments only. Override: footage-led beats stay footage-led.

**MINED (no card — absorbed)**
- video-use lessons: per-segment `-c copy` concat (matches house seam discipline); plan-before-touch (already core). The rest of video-use rejected (provider lock, subagent mandate, fade mandate, overgeneralized encoding claim).

**PARK (tool-gated; card notes the exact gate)**
- `SR-20 flick`, `SR-21 remotion-official`, `SR-22 remotion-to-hyperframes` → T4 headcount ruling. `SR-23..26 mirage-tesseract ×4` → T5 license + re-probe. `SR-27 figma` → Phase-1 expansion decision.

**CATALOG (REFERENCE-ONLY, one line each, never auto-load)**
OpenMontage video-edit · OpenMontage ffmpeg · 6missedcalls video-editing · bsisduck video-analyzer · video-content-extractor (retune sampling for short clips) · baoyu youtube-transcript (rights separate) · minimax-h3-reverse · michaelgold videoskill · ClaudeAnimationBase · pdoom-video (code ≠ soundtrack rights).

**BLOCKED (named missing capability or missing right)**
- Rights: Onetake (PolyForm Noncommercial), Guizang (AGPL code / BUSL assets) — until written clearance.
- Missing verified capability: OpenChatCut, FableCut, FireRed-OpenStoryline, Diffusion Studio editor/watch, hypit, openshorts (their runtimes/apps are not verified here) — craft content remains citable as CATALOG.
- Provenance policy: provider pipelines (tiktok-motivation-class, VOX-COLLAGE-BROLL MaxFusion route) — conflict with audio provenance rules.

**HOUSE (pending authoring — gated on core patches, not on this prototype)**
loudness-chain (incl. XR-4) · banned-claim-sweep · card-seam-discipline · delivery-QC (XR-3 fail-closed).

## §8 AFTER-ACTION
Update cards with real-use facts (categories §5, reroute outcomes, capability findings). The registry stays evidence-based; the operator is the only mover.

## §9 NON-GOALS OF THIS PROTOTYPE
No rendering · no provider installs · no core-prompt changes · no toolchain expansion — all require explicit approval. The prototype succeeds when the paper tests pass (companion file) and the first real campaign shows better selection, real reuse, and no added bureaucracy.
