# RESOURCE INTEGRATION REPORT — Captions & Effects Libraries into PEB + Skill Registry (v1.1, 2026-10-28 — delivered as this separate file `RESOURCE_INTEGRATION_REPORT_v1.1.md`; the original v1.0 is preserved byte-exact as `RESOURCE_INTEGRATION_REPORT_v1.0.md`; precision corrections per operator Task-3 ruling + review items — see §10 correction log)

**Role:** architect / resource reviewer. **Compliance:** no campaign video edited, no renders, no package installs, no archive code executed (extraction + parsing + hashing only), no providers called, no media uploaded, nothing published. Existing master prompt and frozen chain untouched. **STOP CONDITION honored:** report + proposed patches only.

**Method:** Phase-1 inventory (archive listing → extraction to inspection area → hashing → structural verification) → Phase-2 preservation analysis → Phase-3 technical honesty spot-checks → Phases 4–7 integration design. Every count below was independently verified, not taken from the libraries' own reports.

---

## 1. EXECUTIVE VERDICT

**Useful (integrate):**
- **The v2 governance layer is the most valuable part of the whole delivery.** CAPTION_LIBRARY_v2's authority/evidence rules, selection-by-job table, caption-vs-title-vs-demonstration distinction, timing/geometry contract, and corrected ASS notes are production-grade craft governance that matches our registry discipline almost line-for-line (its statuses are literally documented/installed/feature_tested/approved_for_project — the same four states as TOOL_REGISTRY §1).
- **Pastel-indigo style guide (HyperFrames-native)** — directly compatible with our verified T3 renderer; contains a complete style contract, motion language, and an honest internal tier ("recipes 1–6 tested in template; 7–18 are sketches").
- **Malayalam workflow's script-shaping knowledge** — real accessibility value: Malayalam conjunct shaping, taller mask padding, font verification via `fc-list :lang=ml`, "never put Malayalam in serif/mono stacks."
- **20-style pack templates** — deterministic `renderFrame(t)` contract, zero CDN dependencies, seeded randomness, alpha export paths; well-engineered as *template material* for T3.

**Redundant (do not duplicate):**
- The 20-pack's `render.py` (Playwright → ffmpeg) would be a **second production web-to-video path** — we keep exactly ONE primary production renderer (T3 HyperFrames, probe-verified). The pack's renderer is **retained as a reference implementation** (read, hashed, kept under `resource_review/` for inspection), not adopted for production; the category-conflict note governs its use, not its deletion. The templates remain reusable.
- 20 identical `render.py` copies (byte-identical ×20) — one shared script, not 20 implementations.
- The v2 libraries' SFX linkage per style is inert under our audio provenance policy until separately authorized.

**Unverified (treat as reference only):**
- Every visual outcome: **no runtime rendering evidence exists anywhere — a specific evidence limitation, not an absolute.** Precisely: (a) the library authors' own validation is explicitly structure/preservation/references-only (`runtime_rendering_performed: false`, `render_test_status: not_performed`); (b) the packs' "tested in template" claims (pastel-indigo recipes 1–6, 20-pack determinism) are self-reported, plausible on code reading, unverified in this environment; (c) our inspection added file reads, structural re-computation and one file comparison (§2.2/§10) — no frame has ever been rendered. Runtime testing is possible and remains gated behind the fixture-first rule; it is not impossible.
- Motion fields in the legacy caption catalog: source videos were **static Pinterest pins** (library's own honesty note) — all Motion fields are inferred direction, not measured timing.
- All 45 FX / 41 CAP / 24 caption JSON implementations: structurally present, execution unproven. A parsed recipe is not a renderer.

**Should remain inactive:**
- All legacy ASS/drawtext command sketches (explicitly deprecated; kept as history in `legacy_examples`).
- SFX family (8 IDs) and any audio-addition lane — provenance gate, needs separate authorization.
- PDF guide's executable stack (Remotion + ElevenLabs): T4 license gate + provider gate. Its *craft patterns* are referenceable now.

## 2. RESOURCE INVENTORY (grounded in actual files; hashes verified)

**Declared vs actual packaging:** the brief's "Editing_Resources_Recovered.zip" arrived as **three separate zips** (`claude-motion-styles-20.zip`, `malayalam-pastel-reel-edit.zip`, `pastel-indigo-motion-graphics.zip`). Content matches the description; packaging does not. No file was assumed from its name — all verified by extraction.

### 2.1 Captions_and_Effects_v2.zip — 9 files, all 8 manifest SHA256 verified OK
| Path | Type | Verified facts |
|---|---|---|
| `CAPTION_LIBRARY_v2.md` (68,590 B) | style reference + governance | 51 `##` headings = 10 governance sections + **41 styles (01–41)** with machine IDs CAP01–CAP41. Corrected ASS notes present verbatim (BGR order, BorderStyle=3 = rect not rounded, shadow≠glow, `\fad`≠blink loop, `\frx`≠slice). Legacy catalog preserved with honesty note (static-pin sources; styles 22–41 from web research) |
| `EFFECTS_AND_CAPTIONS_SPEC_v2.json` (275,679 B) | schema-structured reference | Independently confirmed: **24 caption_styles + 45 video_effects + 8 sound_effects + 41 catalog (CAP01–CAP41) + 6 motion_recipes + 8 web_ui_resources**, all ID sets unique. `revision.source_sha256` = preserved v1 original's hash (chain of custody intact). `runtime_rendering_performed: false`. `ffmpeg_visual_effect_filter` fields replaced by deprecation pointers; originals retained in `legacy_examples` |
| `EFFECTS_AND_CAPTIONS_SPEC_v2.schema.json` | schema | Draft 2020-12; validates structure incl. `implementation_status: const "not_tested"` on catalog entries. Parse-checked; **not a runtime/render contract** (their report says the same) |
| `FILE_MANIFEST.json` | manifest | 8/8 SHA256 independently re-computed and matched |
| `REVISION_NOTES.md` / `VALIDATION_REPORT.json` | provenance/history | Scope honestly limited to structure/preservation/references; render + source-recording review explicitly `not_performed` |
| `WEB_UI_VIDEO_ROUTING_CORRECTION.md` | routing policy | 8 web/UI resources with per-resource adapter limits (cube-motion, oil-motion, shadercn/TypeGPU, hairline, evil-buttons, matter-js, p5.brush, gsap) |
| `originals/CAPTION_LIBRARY.md` + `originals/EFFECTS_AND_CAPTIONS_SPEC.json` | preserved originals | v1 claims confirmed present UNcorrected (e.g., line 180 rounded-pill-from-BorderStyle=1 claim) — related-but-different variant of v2, retained as evidence, not production instructions |

**Duplicate relationships:** originals ≠ duplicates of v2 (they are the preserved, uncorrected predecessors). No exact duplicate files inside this zip.

### 2.2 claude-motion-styles-20.zip — 84 files
- 20 style dirs (particles, liquid-morph, holographic, neon-glow, wireframe-3d, glassmorphism, kinetic-type, isometric, clay-3d, ascii-art, gradient-mesh, comic-book, split-flap, retro-vhs, halftone, bauhaus, pixel-art, blueprint, art-deco, neo-brutalism), each: `SKILL.md` (unique) + `template.html` (unique) + `preview.jpg` (unique) + `render.py` — **all 20 render.py byte-identical** (md5 e67b868f…): one shared Playwright+Chromium frame-stepping renderer (`window.renderFrame(t)`, fonts.ready wait, MP4 / ProRes 4444-alpha MOV / VP9-alpha WebM / PNG still).
- Plus `gallery.html`, `README.md`, `PREVIEW-all-20-styles.jpg` (158 KB), `PREVIEW-all-20-styles.mp4` (7.3 MB).
- **`upload-to-claude/` — present** (20 per-style zips; CORRECTION of the initial inventory, see §2.6 and §10). **Packaging/content equivalence — [DIRECT] file comparison, claim scoped to exactly what was compared** (2026-10-28; script `scripts/verify_pack_equivalence.py`; full per-member results incl. per-zip SHA-256 in `tool-results/pack_equivalence_result.json`):
  - **Compared ZIP members — the 20 per-style archives in `resource_review/claude-motion-styles-20/claude-motion-styles-20/upload-to-claude/`:** `motion-art-deco.zip`, `motion-ascii-art.zip`, `motion-bauhaus.zip`, `motion-blueprint.zip`, `motion-clay-3d.zip`, `motion-comic-book.zip`, `motion-glassmorphism.zip`, `motion-gradient-mesh.zip`, `motion-halftone.zip`, `motion-holographic.zip`, `motion-isometric.zip`, `motion-kinetic-type.zip`, `motion-liquid-morph.zip`, `motion-neo-brutalism.zip`, `motion-neon-glow.zip`, `motion-particles.zip`, `motion-pixel-art.zip`, `motion-retro-vhs.zip`, `motion-split-flap.zip`, `motion-wireframe-3d.zip` — each holding exactly 4 members (`SKILL.md`, `render.py`, `template.html`, `preview.jpg`) = **80 ZIP members total**.
  - **Compared loose files:** the same-named files in the 20 sibling style directories `…/claude-motion-styles-20/<style>/` under the same tree (recursive enumeration; 80 loose files total).
  - **Criterion & result:** member-by-member SHA-256 (zip member paths normalized for a possible top-level `<style>/` folder; comparison in-memory — no zip extraction to disk, no execution): **80/80 byte-identical; 0 mismatches, 0 zip-only, 0 loose-only.**
  - **Explicit scope limit — this claim does NOT generalize.** It covers only the 20 listed ZIPs and the contents of the 20 compared loose style directories. It does not cover: (a) the pack-root extras (`gallery.html`, `README.md`, `PREVIEW-all-20-styles.jpg`, `PREVIEW-all-20-styles.mp4` — present at pack root, never inside the per-style zips, never compared); (b) any other bundle in this project (outer `upload/claude-motion-styles-20.zip`, `malayalam-pastel-reel-edit.zip`, `pastel-indigo-motion-graphics.zip`, `upload/Captions_and_Effects_v2.zip`, `download/PRO_EDITOR_BRAIN_v3.1.1_TEST.zip`, `rextrix_review/RexTrix_10_Clips.zip` — none were members of this comparison); or (c) the declared-but-never-delivered single zip ("Editing_Resources_Recovered.zip"), whose equivalence remains UNVERIFIABLE — no artifact or manifest exists to compare against.
- **License:** README grant only — "free to use, remix and share, including client work; don't resell the pack as-is." **No LICENSE file.** Claims "no external libraries or CDNs," "deterministic (seeded randomness)" — consistent with the renderFrame contract I read; not runtime-verified here.

### 2.3 malayalam-pastel-reel-edit.zip — 1 file
`SKILL.md` (680 lines): end-to-end HyperFrames reel workflow (ffprobe → contact sheet → conform → script-based alignment ±0.2–0.3 s → authoring rules → snapshot QC → SFX mix → loudness → delivery). **Authoring-environment-specific instructions embedded** (SendUserFile, device_commit_files, `~/Movies/claude-motion-demo/`, built-in-browser skill, AskUserQuestion) — must be stripped before any reuse. Embeds a full template HTML + `gsap-lite` fallback. **No license statement** (appears to be operator's own recovered project material — confirm at adoption).

### 2.4 pastel-indigo-motion-graphics.zip — 1 file
`SKILL.md` (530 lines): HyperFrames-native style contract (tokens, Instrument Serif/JetBrains Mono, HUD, masked-spring motion, 7 named transitions, recipe library with honest tested-vs-sketch tiers, vertical adaptation). **No license statement** (same provenance note as 2.3).

### 2.5 SaaS-Animation-Videos-with-Claude.pdf — 1 file (explicit inventory & inspection record)
- **File:** `upload/SaaS-Animation-Videos-with-Claude.pdf` · 2,584,478 bytes · SHA-256 `f1ba32bea534e3710a66620da1bc1168a4174b45b5f70ec9a50e65f32b26a82f` · received 2026-10-27 as a standalone operator upload (not inside any zip; no manifest).
- **Inspection method:** supplied text read in full in-session; no PDF re-render or page-image extraction performed (page count therefore not recorded); no code from it executed.
Vendor course guide (Mateen Alvi, © course material): Claude Code + Remotion 4 + ElevenLabs + ffmpeg workflow for SaaS promo videos. Craft patterns of value: reference-video frame breakdown before building, check-frames-before-render, storyboard-first approval gates, word-timing-driven animation, vertical re-layout rules (nothing in bottom 15%), loudness −14 LUFS / −1 dBTP, a real troubleshooting table. Executable stack = Remotion (T4-gated) + ElevenLabs (provider gate) + music/SFX lanes (provenance gate). **Reference-only.**

### 2.6 Missing files / unresolved references
- **`upload-to-claude/` folder** referenced by the 20-pack README — **CORRECTED: present** (20 per-style zips; contents verified byte-identical to the loose style dirs — §2.2). The initial inventory missed it; correction logged in §10.
- **Legacy preview images** for the caption catalog — explicitly not included (v2 MD line 77).
- **Source videos** (`caption_styles_raw.mp4`, batch sources v1/v6/v9…) — not included; all source-reference fields are historical notes, not re-verifiable evidence.
- **No LICENSE files** in any zip (README grant for the 20-pack; the two SKILL packs and caption libraries have none — provenance suggests operator's own recovered material; confirm at adoption).
- Fonts referenced (Instrument Serif, JetBrains Mono, Manjari, Noto Sans Malayalam, Montserrat/Anton/Bebas) — not bundled; T3's font-fetch/cache behavior applies.

## 3. INTEGRATION MAP (four-way, reusing existing artifacts — no new registries)

**A. Skill Registry** → gains ONE new layer, **STYLE/EFFECT CATALOG (on-demand reference)**, cards SR-40…SR-45 (patch P-R1 below). These cards hold triggers/risk/license/fallback — never the style bodies. Style bodies stay in the attached files, loaded per selected treatment.

**B. Style/Effect Catalog** → `CAPTION_LIBRARY_v2.md` (human guide) + `EFFECTS_AND_CAPTIONS_SPEC_v2.json` (structured reference) become the catalog bodies; the 20-pack templates and pastel-indigo guide become renderer-ready treatment sources; the PDF becomes craft-pattern reference.

**C. Implementation Inventory** → gains rows: web-to-video deterministic production path = **T3, the ONE primary production renderer** (probe-verified); ASS/libass path = **available via FFmpeg, NOT feature-tested in our chain** (retained alternative path); static caption via T0/T2 = proven; script-shaping check for non-Latin scripts = new checklist item. The 20-pack's Playwright renderer is **retained as a reference implementation, not adopted for production** (category conflict: T3 owns the category).

**D. Project Record** → existing fields suffice: routing line, REUSE lines, plus one new optional line `TREATMENT: <style/ref | none> · renderer <T3|FFmpeg-libass|T2> · checks <…>` when a treatment is selected. "No added treatment" is recorded exactly like a selection.

### Phase-5 routing table (per resource family)

| Family | Trigger (editorial need) | Suitable content | Unsuitable | Required inputs | Renderer | Implementation | Accessibility risks | Rights | Fallback | Verification needed |
|---|---|---|---|---|---|---|---|---|---|---|
| Speech captions (CAP, dialogue roles 09/17/19/30) | Clarify dialogue, noisy audio, accessibility baseline | Talking-head, interviews | Reaction beats where faces carry meaning; every-word popping | Word timings (T1, estimates) + transcript sidecar | T3 text or FFmpeg libass | Recipe contracts; no tested renderer | Contrast, reading load, script shaping, safe areas | Text = spoken words only; no rewrites hiding negations | Static clean caption | Fixture render + human frame review |
| Emphasis/keyword styles (01/02/06/16/18/37…) | One justified emphasis per the selection gate | Keyword moments | More than one per beat | Approved claim/word | T3 | Motion recipes (design contracts) | Overshoot bounds, gradient fill support | — | Plain bold color word | Bounds inspection incl. overshoot frames |
| Stat/claim cards (07/15/21/39) | Communicate a verified result | Approved numbers only | Unverified claims | Source + date + units | T2/T3 | Static cards proven | Units, qualifier visibility | Banned-claim gate applies | Plain text card | Claim check + readability |
| FX transitions/graphics (45 FX) | Hook, section change, comparison | High-energy openers | Quiet reveals; documentation tone | Source action supporting it | T3 (web-class) or FFmpeg (simple) | Legacy sketches deprecated → new T3 compositions needed | Flash risks (QC flash_review) | — | Hard cut | Flash/strobe review + fixture |
| 20-style pack (templates) | Ambitious motion treatment that improves communication | Brand-appropriate stylized segments | When style ≠ brand or overwhelms meaning | Text + palette params | **T3 via adapter** (not Playwright path) | template.html → T3 composition mapping (adapter missing) | Fonts (system fallbacks), bounds | Pack grant: use/remix OK, no pack resale | Simpler style | Determinism seek test + fixture |
| Pastel-indigo style | Explainer/talking-head with designed graphics | 16:9 or 9:16 explainers | Brands whose palette conflicts (tokens must NOT be reinvented — or re-tokened deliberately) | Speaker footage + script | T3 (native fit) | Recipes 1–6 claimed tested in template — re-verify | HUD clutter on small screens, serif legibility | Fonts via T3 fetch; freeze set | Reduced-motion variant | Snapshot QC per beat |
| Malayalam workflow | Multilingual (Malayalam) keyword captions | Malayalam talking-head | Full-subtitle volume (it teaches keywords, not walls) | Script as timing source (±0.2–0.3 s) | T3 | Template embedded; env instructions stripped | Conjunct shaping, mask height, font verification | — | English-only keywords | `fc-list :lang=ml` + render test line first |
| SFX family (8 IDs) | — | — | **Default inactive** | Authorized asset files + operator ruling | FFmpeg amix/alimiter path exists | Provenance gate: new audio needs authorization | Mix balance, −14 LUFS chain stays ours | Audio provenance policy | No SFX | Loudness + listen check when authorized |
| PDF guide patterns | SaaS/product promo structure | Product demos | Its specific stack | Logo, real clips/screens | T3 equivalent | Check-frames + storyboard-first patterns reusable | Vertical safe areas | Never-invent-numbers rule aligns with ours | — | — |

## 4. MINIMAL PATCHES (exact text; nothing applied)

**P-R1 — Registry prototype patch (REQUIRED for this integration):** insert into `SKILL_REGISTRY_PROTOTYPE_v0.9.md` after the CRAFT LAYER block:

```
**STYLE/EFFECT CATALOG LAYER (on-demand reference — bodies stay in attached files)**
- `SR-40 caption-library-v2` — 41 CAP styles + governance contracts. Content: REF. Trigger: caption/treatment selection at plan time. Licensing: operator's own material (verify at adoption). Renderer bindings: T3 text (render pipeline probe-verified; styled-caption compositions NOT feature-tested), FFmpeg libass (available, NOT feature-tested). Fallback: clean static caption.
- `SR-41 effects-spec-v2` — structured reference: 24 caption + 45 FX + 8 SFX entries, contracts, minimal_project_instance. Content: REF. Trigger: parameter lookup after SR-40 selection. SFX entries INACTIVE (provenance gate).
- `SR-42 motion-styles-20` — 20 deterministic HTML templates. Content: REF→EXEC via T3 adapter (missing — bounded adaptation). Trigger: stylized motion segment justified by selection gate. Restriction: pack's Playwright render.py NOT used (T3 owns the category). License: README grant, no LICENSE file.
- `SR-43 pastel-indigo-style` — HyperFrames-native style contract + recipes. Content: REF (recipes 1–6 claimed tested in template — re-verify on first use). Trigger: explainer/talking-head designed-graphics segments.
- `SR-44 malayalam-pastel-workflow` — multilingual keyword-caption workflow + script-shaping knowledge. Content: REF. Override: strip authoring-env instructions (SendUserFile/device_commit/etc.); SFX lane gated by audio provenance policy.
- `SR-45 saas-animation-guide` — course PDF craft patterns (reference breakdown, check-frames, vertical re-layout, troubleshooting table). Content: REF. Its Remotion/ElevenLabs/music lanes: T4/provider/provenance gated — never executable here by default.
```

**P-R2 — Registry §2 routing addition (one sentence):** after the MATCH/PARTIAL/NONE outcomes add:
> "Treatment selection is a separate, later decision: consult the Style/Effect Catalog only when a communication need exists; `no added treatment`, `clean cut`, and `held shot` are valid selections recorded like any other."

**P-R3 — Implementation Inventory patch (one row):** append to `IMPLEMENTATION_INVENTORY_v0.9.md`:
> `| 13 | Styled captions / text effects | T3 render pipeline probe-verified (frame grid, determinism, alpha, font-fallback lint) — that probe did NOT test styled caption compositions; T3 text-based styled captions NOT feature-tested; FFmpeg libass available but NOT feature-tested | Inventory row 12 + T3 probe | New caption backends (incl. the first T3-text styled caption) require a fixture before reliance; 20-pack render.py retained as reference only (category conflict for production) |`

**P-M1 — Master prompt patch (OPTIONAL, one sentence; complements P1):** in the plan/visual-selection step:
> "Visual treatments are chosen from the on-demand Style/Effect Catalog only when they improve communication; no treatment is mandatory and restraint is recorded as a decision."

**Explicitly NOT patched:** the frozen chain, the four-state status model, the audio policy text (P3 from the earlier patches file already covers provenance-vs-transform), the QC gate, and nothing about peak-first/hooks/music/cut-rhythm — none of these libraries' style defaults become rules (see §7).

---

## 5. PROPOSED CATALOG/CARD FIELDS (reuse-first)

**Reused unchanged** — registry §4 card format: `ID · title · layer · content level (REF|EXEC) · trigger · overrides · licensing (REPO/FILE/ASSET/DEP) · status · pinned SHA · usage/failure record`.

**One necessary addition for STYLE CATALOG cards only** (4 fields, all serving routing — not bureaucracy):
`renderer_binding · treatment_family · accessibility_risks · fallback`

**Why these four:** renderer_binding prevents the §6 category conflict class (the 20-pack lesson); treatment_family is the catalog's own role enum (speech_caption / hook_title / ui_label / evidence_graphic / transition); accessibility_risks and fallback are required by the v2 libraries' own contracts (contrast/shaping/flash; reduced-motion and static alternatives) — we would otherwise have to derive them per selection anyway.

**Rejected additions:** per-style sub-cards (41 CAP cards would bloat the registry — the catalog INDEX stays one card, bodies on demand); a crosswalk field between CAP## and legacy JSON IDs (the libraries deliberately provide `legacy_spec_style_id: null` — we preserve that honesty); any "tested" flag vocabulary beyond the existing four states.

## 6. REUSE & ADAPTATION BACKLOG (ranked by editorial value, not visual complexity)

**Tier 1 — Ready references (use now, zero adaptation):**
1. `CAPTION_LIBRARY_v2` governance sections (authority/evidence, selection-by-job, caption-vs-title, timing/geometry contract) — adopt as the catalog's standing rules. *Value: prevents an entire class of caption errors.*
2. Pastel-indigo style guide — T3-native explainer style. *Value: complete designed-graphics language for talking-head segments.*
3. Malayalam script-shaping rules + font verification procedure. *Value: makes multilingual captions safe.*
4. PDF craft patterns: reference breakdown before building; check-frames before render; one-message timestamped feedback; vertical re-layout. *Value: workflow hygiene independent of its stack.*

**Tier 2 — Candidate implementations (bounded adaptation, fixture before reliance):**
5. 20-pack templates → T3 compositions. Missing adapter: map `renderFrame(t)` contract → HyperFrames clip/timeline model; verify seek determinism + font behavior in T3. Start with kinetic-type, split-flap, blueprint (most communication-relevant).
6. Accessibility-first caption styles (CAP 09/17/19) → first fixture through ONE renderer path (recommend T3 text first; libass second) with contrast + reading-load + bounds checks.
7. JSON `minimal_project_instance` → caption sidecar format for the project record (it already defines required project/word-event fields).
8. Pastel-indigo recipes 7–18 (sketches) → snapshot + verify timing before trust, per the pack's own instruction.

**Tier 3 — Blocked resources (remain inactive):**
9. SFX family (8 IDs) + every pack's music/SFX lanes — audio provenance gate; needs operator authorization + asset files we don't hold.
10. PDF's Remotion + ElevenLabs stack — T4 license gate + provider gate.
11. All legacy ASS/drawtext sketches — deprecated by the library itself; history only.
12. 20-pack `render.py` as a renderer — category conflict with T3 (templates remain usable).

**Tier 4 — Missing adapters (build only on a real trigger, per inventory-first rule):**
13. JSON word-timing → T3 composition timing adapter.
14. libass caption path fixture (only if T3 text proves insufficient for volume captioning).
15. Style→recipe crosswalk — deliberately NONE exists; do not invent one.

## 7. THREE PAPER TESTS (no rendering)

**TEST 1 — Dialogue/comedy where timing and reactions matter.**
Constraint: original audio only; comedic timing lives in faces and pauses. → Need: clarify occasionally overlapping dialogue WITHOUT stomping reaction beats. → Selection (EXAMPLE-SPECIFIC to this test's dialogue/comedy case — not a campaign-wide comedy rule): phrase-level clean caption (CAP 09/17/19 class), no emphasis styles on this test's punchlines (its laugh must land untouched); captions duck out entirely during this test's held reaction shots. Other comedy material requires its own selection pass through the same gates. → Reuse: CAPTION_LIBRARY selection-by-job row 1 + timing contract ("preserve meaningful pauses"); T3 text path. → Limitation: word timings from T1 are estimates — comedy beats need manual boundary confirmation against the waveform. → Checks: reading-load at phone size, caption-free reaction windows verified frame-by-frame, sidecar transcript kept for accessibility, bounds inspection. `TREATMENT: CAP09-class clean caption · renderer T3-text · no-emphasis-during-reactions recorded`.

**TEST 2 — Product/UI demonstration requiring purposeful motion.**
Constraint: real interface only (no invented UI); banned-claim gate active. → Need: direct attention to the one action that proves the claim. → Selection: cursor-led highlight + one stat card (CAP 07/21 class) with source+date+units; PDF's check-frames pattern for the demo segment; 20-pack NOT selected (brand mismatch + adapter cost for one segment). → Reuse: inventory rows 4–5 (static cards proven; T3 render pipeline probe-verified — the styled stat-card composition itself is untested, see this test's Limitation); PDF storyboarding pattern. → Limitation: none of the library entries is a tested renderer — the stat card must be built as a new small T3 composition from the recipe contract (new code justified: "no tested component renders styled stat cards yet" — inventory-first rule satisfied). → Checks: claim approval before render, flash review n/a, safe-area for platform UI, final-frame readability.

**TEST 3 — Wordless reveal/transformation where restraint may be strongest.**
Constraint: transformation reads visually; voiceover absent by design; original ambient audio only. → Need: none that text or added motion improves — the transformation IS the message. → Selection: **NO ADDED TREATMENT** — clean cut into the reveal, held shot, no caption, no effect (valid selection per P-R2; also the v2 libraries' own `no_effect_is_mandatory: true` and the selection gate's "what does the viewer understand better than with a clean cut" question). → Reuse: nothing loaded — zero skill bodies, zero style bodies; routing line records the restraint decision. → Limitation: none claimed. → Checks: exposure/continuity QC through the existing chain only. This test exists to prove the registry doesn't force resource theater.

## 8. HONEST STATUS

**Evidence provenance (operator review item 5):** every row below is **[DIRECT]** — performed by the architect on files present in this project (reads, hashes, structural re-computation, the §2.2 file comparison). Statements sourced from the operator's 2026-10-28 consolidated audit (145 fetches reported) are **[INHERITED-AUDIT]**; in this report they appear only in §9 and are labeled there per row — none is presented as direct inspection. Vendor/self-reported claims ("tested in template", determinism) remain labeled as author claims throughout.

| Level | Scope |
|---|---|
| **Inspected (read)** | Every file in all four zips' key surfaces: v2 MD (governance fully + legacy-catalog sample + honesty notes), v2 JSON (structure, counts, policy sections, representative entries of every array), schema, manifest, revision notes, validation report, routing correction; 20-pack README + full render.py + structure of all 20 dirs; both SKILL.md packs (opening sections + targeted greps); PDF (full provided text) |
| **Structurally checked (independently re-computed)** | 8/8 manifest SHA256 match; counts 24/45/8/41/6/8; ID uniqueness all four sets; CAP01–CAP41 span; 20× identical render.py (md5); v1-originals relationship (uncorrected claims confirmed present); chain of custody (`revision.source_sha256` = preserved original hash); absence of LICENSE files; `upload-to-claude/` missing |
| **NOT runtime-tested** | Any render, any template execution, determinism-under-seek of the 20-pack in T3, libass rendering of any ASS sketch, font shaping (Malayalam conjuncts) in our environment, `gsap-lite` behavior, loudness paths from the packs |
| **NOT audiovisually reviewed** | The packs' preview JPG/MP4 files (vendor evidence, not watched as QC), source recordings (not provided), caption timing against real speech |
| **Evidence status of library claims** | "Tested in template" (pastel-indigo recipes 1–6, 20-pack determinism) = author claims, plausible per code reading, UNVERIFIED here. Their own validation scope = structure/preservation only. Everything carries `not_tested`/`design_contract_not_executable` markers honestly |

**Not verified, stated plainly:** I did not watch any video, render any frame, run any validator beyond JSON parsing, or verify third-party font licenses (Instrument Serif/JetBrains Mono/etc. are Google-Fonts-class but license re-read happens at adoption per standing G3). The catalogs' historical "verified against footage" flags apply to static frames only, per the libraries' own notes.

---

## 9. SIX PRIORITY CANDIDATES — FIVE-ATTRIBUTE STATEMENTS (operator review item 3, 2026-10-28)

**Evidence provenance (operator review item 5):** none of the six repositories below has been directly inspected by the architect — no SKILL.md has been fetched from any of them in this project. Every "audit:" statement below is **[INHERITED-AUDIT]** evidence, quoted from the operator's consolidated 2026-10-28 audit (145 document fetches reported), not independently re-verified here; chain-constraint statements are **[PROJECT-RULE]** (frozen-chain facts). This inherited tier is kept separate from the [DIRECT] inspection evidence of §2/§8. Canonical record: `COVERAGE_RECONCILIATION_v2.0.md` §2 + §4 rows 9–14 + §5; held registry proposal: P-C2 (§8 there). **All six: no cards issued, REFERENCE-ONLY, licensing unverified.**

### 9.1 Leonxlnx/cinetic (shortlist link: `skills/cinetic/SKILL.md`)
- **Useful guidance now [INHERITED-AUDIT]:** editing-workflow craft guidance spanning concept, branding, timeline, UI motion, and finishing — with the audit's own qualification: "large, opinionated workflow; load selectively." Usable today at citation level only.
- **Execution limitation:** not inspected; nothing loaded or resident; no adapter; selective-load scoping mandatory (overlaps SR-10/SR-11 craft territory — must not silently supersede either).
- **Unresolved permissions:** license not inspected → REFERENCE-ONLY under registry §6.
- **Uncovered need:** workflow-level finishing/branding guidance adjacent to the existing craft cards; which sub-sections are load-worthy is undetermined.
- **Adoption trigger:** SKILL.md read (L1 INSPECT) + license verification → scoped ADAPT into the craft layer or a numbered craft card (evidence-based, not count-based).

### 9.2 AbubakrChan/product-launch-motion (shortlist link: root `SKILL.md`)
- **Useful guidance now [INHERITED-AUDIT]:** two documented routes — root (HTML `seek(t)`, music-first/one-shape direction) and legacy (narration + GSAP + HyperFrames). The route-selection discipline is the immediately usable part; the audit's rule stands: do not import both routes' assumptions at once.
- **Execution limitation:** root route's music-first lane collides with the original-audio-only provenance gate; legacy route aligns with T3 but GSAP-inside-T3 determinism is unverified (the G1 adapter does not exist); per-route file layout unknown.
- **Unresolved permissions:** license unknown; the root route's music lane additionally needs authorized audio assets.
- **Uncovered need:** jointly with open-design defines gap G1 — deterministic seekable web-animation→video adapter (the highest-leverage uncovered capability).
- **Adoption trigger:** route decision + per-route file inspection + license; the legacy route additionally requires the G1 adapter built and determinism-tested under inventory row 11's contract before any EXEC claim.

### 9.3 nilbuild/video-demo (shortlist link: root `SKILL.md`)
- **Useful guidance now [INHERITED-AUDIT]:** intentional-demonstration structure for product demos — what to show, in what order, what proves the claim; capture-vs-fixture distinction.
- **Execution limitation:** live web-product capture cannot execute in this chain — no screen/application capture capability is verified in this environment [PROJECT-RULE: campaigns run on operator-supplied footage]. The craft structure is usable; the capture workflow is not.
- **Unresolved permissions:** license unknown.
- **Uncovered need:** gap G2 — live web-product capture (a capability ruling, not a skill adoption).
- **Adoption trigger:** license + inspection → catalog reference for demo structure; any executional use additionally requires an operator capture-tooling ruling (G2).

### 9.4 1weiho/cinematic-shot (shortlist link: `skills/cinematic-shot/SKILL.md`)
- **Useful guidance now [INHERITED-AUDIT]:** motivated UI camera and lighting treatments — explicitly a "specialist aesthetic, not a universal editing style."
- **Execution limitation:** specialist scope only: rendered camera moves over UI/product footage (T3-adjacent); not documentary-style handling of supplied footage; nothing loaded.
- **Unresolved permissions:** license unknown.
- **Uncovered need:** cinematic camera-move language for T3-composed product/UI segments.
- **Adoption trigger:** inspection + license → scoped catalog/craft reference; usable only per the selection gate (specialist, never default).

### 9.5 barty-bart/motion-graphics (shortlist link: `skills/motion-broll/SKILL.md`)
- **Useful guidance now [INHERITED-AUDIT]:** motion B-roll — reusable animation segments supplementing the craft set (audit names it baseline); candidate material for T3 card/graphics segments.
- **Execution limitation:** not inspected; B-roll block format vs the T3 composition model unresolved; no measured loading path exists (gap G4).
- **Unresolved permissions:** license unknown.
- **Uncovered need:** gap G4 — motion B-roll reuse lane into T3 compositions.
- **Adoption trigger:** inspection + license → candidate for the next craft-card slot (evidence-based, not count-based); any EXEC use additionally requires a measured B-roll→T3 path.

### 9.6 nexu-io/open-design (shortlist links ×2: `skills/motion-design/SKILL.md` + `plugins/_official/video-templates/frame-liquid-bg-hero/SKILL.md`)
- **Useful guidance now [INHERITED-AUDIT]:** web/UI motion-design guidance plus one named template (frame-liquid-bg-hero) — an example, not a family endorsement.
- **Execution limitation:** the whole web/UI cluster is determinism-conditioned [PROJECT-RULE]: requires deterministic, seekable video rendering — no scrolling/hover/wall-clock timing; whether the motion-design guidance is renderer-agnostic is unknown; G1 adapter absent.
- **Unresolved permissions:** license unknown.
- **Uncovered need:** jointly defines G1 with product-launch-motion's legacy route; the v2 spec's own `WEB_UI_VIDEO_ROUTING_CORRECTION.md` already demands the same gate.
- **Adoption trigger:** inspection + license + a G1 adapter decision — the determinism gate (inventory row 11) must pass before any member of this cluster moves beyond reference.

**Net for the six:** zero cards; zero EXEC claims; all REFERENCE-ONLY pending inspection + license; two jointly define gap G1, one defines G2 participation, one defines G4.

---

## 10. PRECISION-CORRECTION LOG (v1.0 → v1.1, operator Task-3 ruling + review items, 2026-10-28)

**Versioning note (delivery fix, 2026-10-28):** the Task-3 corrections were initially applied in place inside the v1.0-named file — title said v1.1, filename said v1.0, and the original v1.0 text was overwritten in the working tree. Per operator instruction this is now fixed: the original v1.0 is preserved **byte-exact** (restored from git commit `4eece0b`; verified identical) as `RESOURCE_INTEGRATION_REPORT_v1.0.md`, and the corrected text is delivered as the separate file `RESOURCE_INTEGRATION_REPORT_v1.1.md`. Items 1–6 are the operator's Task-3 precision corrections; items 7–9 arise from the operator's review of the corrected draft (same date).

1. Blanket "never tested by anyone" phrasing replaced by the layered evidence limitation (§1 Unverified).
2. ONE primary production renderer distinguished from retained alternative implementations/references (§1 Redundant, §3.C).
3. "T3 verified" scoped to named tested features — probe-verified pipeline vs untested styled-caption compositions (P-R1 SR-40 card, P-R3 row 13, TEST 2).
4. Packaging/content equivalence substantiated by file comparison: `upload-to-claude/` present, 20/20 zips byte-identical to loose dirs (80/80 files, SHA-256; script `scripts/verify_pack_equivalence.py`, results in `tool-results/pack_equivalence_result.json`). Equivalence to the never-delivered declared single zip remains unverifiable (no artifact/manifest exists to compare against). Initial "missing folder" claim corrected (§2.2, §2.6).
5. TEST 1 comedy emphasis choices marked example-specific (§7).
6. SaaS PDF explicit inventory + inspection record added (§2.5).
7. **80/80 equivalence claim scoped precisely (operator review item 4):** §2.2 now names the exact compared ZIP members and loose files, the SHA-256 criterion, and an explicit non-generalization list (pack-root extras; all other project bundles; the never-delivered declared single zip). The claim is unambiguously limited to the compared members.
8. **Direct inspection separated from inherited audit evidence (operator review item 5):** §8 opens with an explicit provenance legend; the new §9 labels every statement [INHERITED-AUDIT] or [PROJECT-RULE]. No audit-sourced statement is presented as direct inspection anywhere in this report.
9. **Six priority candidates added as §9 (operator review item 3):** the five required attributes per candidate (useful guidance now / execution limitation / unresolved permissions / uncovered need / adoption trigger), consolidated from `COVERAGE_RECONCILIATION_v2.0.md` §2 + §4 rows 9–14 + §5 + §7. Included here so the review package is self-contained; no cards issued — all six held reference-only.

**STOP CONDITION:** report and patches complete; all proposed integrations HELD pending review. No master-prompt text changed, no adapters implemented, no production started, no cards added, nothing installed, nothing rendered. Awaiting operator ruling on P-R1/P-R2/P-R3 (registry+inventory), P-M1 (optional prompt sentence), and the held P-C1…C4 registry additions (`COVERAGE_RECONCILIATION_v2.0.md` §8).
