# REVIEW — User's Improved Pro Editor Brain (2026-10-24 upload, 893 lines / 47,682 chars)

Reviewer: independent pass · Compared against: PRO_EDITOR_BRAIN v2 + v2.1 patches, the 10-clip
independent QC findings, and the user's v3 goals (premium-ad taste, viral mechanics, motion
graphics, keyframes, stabilization, BG removal/layering, listen & feel).

## VERDICT

**Best craft/engineering spine of any version so far — but the campaign-compliance spine fell
out during the rewrite, and none of the four newly requested capabilities exist yet.** The
rewrite is worth keeping; it needs (1) restoration of the compliance layer, (2) four new
capability sections, (3) ~8 defect fixes, (4) consultation-derived deepening. Status: untested
by design — a minimal test plan is included below.

## A. What is genuinely BETTER than v2 (keep all of it)

1. **Mode semantics fixed**: "an attached brief with links is sufficient to begin Project
   Execution intake; missing or blocked media does not switch the task to Module Build" —
   kills the real ambiguity that made Mode B runs stall waiting for footage.
2. **Campaign intake from a single brief** (link/source register + requirement matrix with
   mandatory/preference/unresolved) — better than v2's static input block; matches how briefs
   actually arrive.
3. **Mode B scope diet**: full reusable package required only in Module Build; Mode B keeps
   project records + scripts for the actual edit. Runs get faster and cheaper.
4. **Risk-proportionate claims verification**: extends the claims ledger to editorial
   assertions with effort matched to risk ("do not require a named human approver for every
   incidental statement") — smarter than v2's blanket ledger.
5. **Source handling section**: VFR/timestamps, conformed intermediates only where needed, no
   synthetic interpolation by default, no marketing upscaling as recovered detail, verify sync
   on decoded output. All correct.
6. **Pilot gate**: up to three representative pilots with plan approval before rendering;
   "select different editorial challenges, not arbitrary variation".
7. **Platform-safety honesty**: exclusion masks, documented conservative profiles, "a sampled
   composite check is not an in-app safe-area check".
8. **Math contract tightened**: actual glyph/alpha bounds (not nominal font size), rotated
   bound formula, cubic-Bézier solving warning ("Do not substitute u directly into By"), spring
   honesty, bounds-through-overshoot.
9. **ENDING AND CTA section** (source tail inspection, one coherent ending, CTA placement
   around the payoff, no long freezes).
10. **Token economics**: "Do not let paperwork consume the editing budget", lean response
    order, no repeated self-audits.
11. **Full portability**: BOXABL demoted everywhere to illustration; no default creative
    solution (pill/blur-pad/logo card all conditional now).

## B. Critical regressions — the compliance spine fell out (must restore)

| # | Lost element | Evidence in new text | Consequence if not restored |
|---|---|---|---|
| R1 | **Language gate** (verify spoken language AND burned-in text per source segment before building; instrumental-source path) | only surviving "language" mention is "visual language" (line 289) | The Clip 15 rejection class (Arabic speech) is unprotected again |
| R2 | **Campaign rules input block**: mandatory inclusions, banned claims, end-card specification (logo graphic + explicit action wording), post-publish operator checklist | only line 581 ("Campaign rules override permission to add music/VO/SFX…") | The Clip 16 rejection class (text-only "to try RexTrix" end card) is unprotected; banned-claim scanning ("free / unlimited / earn") has no home |
| R3 | **End-card verification floor** | line 610: "No universal hold time is assumed" | Correct as a *creative* principle, but the v2.1 rule was a *verification* rule: card must hold ≥ campaign minimum + 0.5 s on the rendered file (all 10 delivered cards measured exactly 4.0 s = zero margin). Without it the platform-trim failure class returns |
| R4 | **v2.1 QC lessons**: named-tool loudness measurement + 1.5 LU re-norm trigger; QC claims must name their reproducing command; degraded-source disclosure; source-baked-defects policy | absent (two-pass normalization remains, good, but not the measurement rule) | Manifest numbers drift from measured reality (Clip 01: claimed range vs −16.3 LUFS measured); sub-720p sources ship silently again (all 30+ campaign clips were 640×360) |
| R5 | **Operator checklist emission** (30-min URL submission, 24 h analytics, audience requirements) | absent from delivery stage | Delivery completeness regresses; the campaign's post-publish duties become invisible |

**Restoration design note**: do not paste v2 §3 back verbatim. The new architecture is better —
restore the lost content as (a) a "CAMPAIGN COMPLIANCE GATES" block inside the existing intake/
QC structure, and (b) verification rules inside POST-RENDER. Keep the user's "no universal hold
time" sentence but append: "when the campaign states a minimum hold, the gate verifies the
rendered card holds at least that minimum plus 0.5 s."

## C. New defects introduced by the rewrite

| # | Defect | Detail |
|---|---|---|
| D1 | Dangling cross-reference | Line ~826: "the separate check categories from §13" — sections are now unnumbered. Restore section numbers (v2's 1–15 scheme) so internal references resolve |
| D2 | Hook engine tension | §HOOK says "consider up to three materially different approaches… do not force unsuitable types", but MODE A still mandates "implement these two configurable hook presets". Clarify: presets are reference implementations for Module Build, never creative mandates in Project Execution |
| D3 | Hook mandate vs anti-hook rules | "No added headline is a valid choice" and "a headline pill… is not a default creative solution" vs the campaign mandate "every clip must open with a strong hook (visual + audio + text)". Resolution: hook requirements are declared per campaign profile (channel coverage required, execution honest to source); the brain supplies them from source evidence — added copy only when specific and truthful |
| D4 | Prompt mass | 47.7k chars ≈ 12k+ tokens of standing instructions before any footage work. Acceptable for the "one complete brain" goal, but make §10 recipes and §12 engineering artifacts load-on-demand in Project Execution (they are already mode-scoped — finish the job with an explicit "skip unread, mark not-applicable" clause for Mode B) |
| D5 | Stale capability seeds | tsrct 0.4.0 / Kenney / InVideo MCP still listed as "reported tools". After 30+ real runs, the capability matrix should be seeded from observed reality and maintained as a project artifact |
| D6 | Viral objective absent | The prompt bans promising virality (correct) but states no optimization target. Add the mandate as mechanics: "design for hook strength, payoff delivery, rewatch structure, and share triggers; never claim or predict outcomes" |
| D7 | Pilot-gate friction at 30+ clip scale | "Up to three pilots… obtain plan approval" can bottleneck campaigns. It already allows user-authorized alternatives — make explicit: "the user may pre-approve a batch pattern after reviewing pilots" |

## D. Gap analysis vs the four requested capabilities

All four are absent; each needs its own section (consultation prompts A–D are designed to fill
exactly these):

| Capability | Current state | Required addition |
|---|---|---|
| Motion graphics around raw footage | 5 fixed recipes only; no scene→opportunity→design→animate→composite engine | Motion Graphics Design Engine: opportunity taxonomy, detection with evidence rules, design tokens/style frames, animation choreography, asset pipeline, anti-template variety, starter archetype library |
| Keyframes | Easing math + per-recipe timing exist; no general keyframe track schema or renderer contract | Universal keyframe JSON schema (position/scale/rotation/opacity/crop/volume tracks) + frame-accurate evaluation + render path |
| Stabilization | Zero mention | Decision tree, vidstab-class two-pass strategy, artifact QC gates, fallback ladder |
| BG removal / character layering | Zero mention | Segmentation tooling strategy, temporal-flicker and edge QC, compositing graphics BEHIND subjects (depth order, contact shadow, light wrap) |
| Listen & feel | Waveform/ASR honesty exists; no signal layer feeds decisions | Feel Engine: speech/breath/beat/energy/motion signals → rhythm architecture → cut/emphasis mapping with tolerances → AI-tells audit → feel spec JSON |
| Teaser method | Not present | Peak-first teaser structure with honesty guardrails (peak must be real footage from this source) |
| Engagement R&D | Analytics review exists | propose → one-variable pilot → measure → keep/kill loop with learning ledger |
| Premium-ad default | Design-token concept exists | Style-frame gate before batch production; brand-locked typography/color defaults per campaign profile |

## E. Untested prompt — minimal test plan (run before trusting it)

- **T1 Mode B smoke test**: 2 clips + RexTrix campaign input → must emit requirement matrix,
  claims ledger, and (after restoration) compliance gates + operator checklist.
- **T2 Compliance probe**: source with non-English speech and a "free games" on-screen claim →
  language gate must reject/rebuild; banned claim must block.
- **T3 Math probe**: request frame math at 30 fps → exact formulas, rational fps handling.
- **T4 Honest-status probe**: disable playback/review → must ship review_draft with pending
  checks listed, never verified_delivery.
- **T5 Pilot diversity**: 3 pilots from one batch must differ structurally (hook type, pacing
  curve, graphic archetype), not cosmetically.

## F. Bottom line

Keep this rewrite as the v3 chassis. Restore the five lost compliance elements (B), fix the
seven defects (C), then integrate the four consultation answer-sets (A: feel engine, B: motion
graphics, C: pipeline capabilities, D: campaign-adaptive brain + viral strategy) as new
sections. Expected result: a complete brain that keeps its honesty and compliance skeleton and
gains the four capability engines.
