# PILOT REVIEW — RexTrix_Clip_28_pilot_v1_review_draft.mp4
Reviewer: system architect (this thread) · Date: 2026-10-27 ·
Method: independent re-measurement of the uploaded file in a separate environment
(measure, do not trust the render log) + visual frame inspection + machine ASR.

## VERDICT: PILOT PASSES — the pattern is batch-ready, pending operator decisions.
Every measurable gate reproduced independently. The visual card is compliant. The
spoken-language OPEN item is now closed by ASR. What remains before a batch is human
judgment and the operator's open decisions (Section 4) — not measurements.

## 1. Chain of custody
- SHA-256 of the uploaded file: 78d7e8b6d21e0968d662b459799f3646268baadd1d34ecdcf5f613e7be58f520
  — byte-identical to the agent's claimed delivery. The file reviewed here IS the file the agent QC'd.

## 2. Independent measurements (all PASS)
| Check | Agent claim | Architect re-measurement | Result |
|---|---|---|---|
| Decoded frames | 568 | 568 | PASS |
| PTS grid | n/30, max dev 6.7e-7 | first 0.000000, last 18.900000, max dev 6.67e-07 | PASS |
| Card entry | frame 418 @ 13.933 s | frame 418 @ 13.933 s (frame-diff, independent method) | MATCH |
| Card hold | 5.000 s = 150 frames | 150 frame periods (13.9333 -> 18.9333 s display span) | PASS (>=4.5 s, 0.5 s margin) |
| Card stillness | static by design | max mean frame-diff inside card = 0.00 | PASS |
| Loudness | -14.0 LUFS | -14.0 LUFS (ebur128, audio-only decode) | PASS — on target |
| True peak | -6.7 dBTP | -6.7 dBFS, LRA 5.2 | PASS (gate <=-1.0; headroom deliberate) |
| Black events | 0 | 0 (bounded blackdetect) | PASS |
| Freeze events | 1 = the card | 1 @ 13.9333 = the card | PASS (intentional hold) |
| Faststart | moov before mdat | box order: ftyp, moov, free, mdat | PASS |
| Colour tags | bt709 x3 / tv | bt709/bt709/bt709, range tv | PASS (C4 contract) |
| Video | 1080x1920 H.264 High yuv420p CRF 18 | identical | PASS |
| Audio | AAC-LC 48 kHz stereo | identical, 889 frames | PASS |
| Runtime | 18.933 s | 18.933 s (15-25 s band) | PASS |
| Card wording | verbatim approved string | visually verified on frames: "Download the app" / "- link in bio" + "AI-generated Games & Stories" | PASS |
| Card layout | elements above 78% line | logo ~y600-815, CTA ~y1041-1170, tagline ~y1426-1458 (limit 1497.6) | PASS |
| Body integrity | not re-checked by agent | frames at 0.5 / 7.0 / 13.5 s: hook pill intact, burned-in English captions, blurred-pad treatment, no new defects | PASS |

Note on the hold arithmetic: my frame-diff span read 4.967 s (149 PTS intervals); the
display duration is 150 frame periods = 5.000 s as claimed. Both readings start the card
at the same frame; the agent's figure is the correct display-duration semantics.

## 3. Language — OPEN item closed by machine, downgraded for the human
- ASR (this environment, z-ai CLI, 16 kHz mono, 0-13.9 s body audio) returns continuous,
  fluent English throughout: "...Teachers got to switch pods every thirty seconds. Hit the
  wrong person with a marble, instant elimination. Last person standing wins one hundred
  million dollars. This hiding spot is actually insane..."
- No non-English words. No banned claims in speech. The $100M line is the logged in-story
  game-show premise (intake §4.4): source fiction, not an app claim — keep it out of
  captions, titles and thumbnails.
- Status: M2 language gate = VERIFIED (machine). The operator's human listen is now
  optional comfort, not a blocker for the batch decision. Record method + date in the QC table.

## 4. What still stands between here and a batch (operator decisions, none technical)
1. HUMAN REVIEW of the pilot itself: watch and listen once — pacing, whether the hook
   works, whether the silent card ending feels acceptable. ASR and frames cover language
   and mechanics; taste is yours. [D7] batch-pattern approval follows this.
2. R4 logo: (a) supply the official transparent PNG, or (b) written sign-off on the
   derived mark (disclosure text is already in the delivery note).
3. Typeface: supply the campaign font, or sign off on the DejaVu placeholder (disclosed).
4. Rights/usage grant covering footage, mark and font — still open (intake Q3); masters
   remain non-ingestible (>100 MiB per-file cap).
5. Keep 08, 09, 17, 24, 25 excluded per Round-2 P2 (body re-cuts or drop).

## 5. Observations (not defects — log and move on)
- SILENT CARD: audio fades at card entry; the 5.000 s card plays in digital silence
  (astats: RMS -inf from 14.0 s). Legal under M7 (no ADDED music permitted; the source
  vocal over the CTA would be worse). 26% of runtime silent-and-static is a retention
  consideration — the operator's listen (item 1) should explicitly judge this. If it
  bothers, a variant can extend the source's own music bed under the card at low level
  (still original audio, still compliant) — decide once, apply batch-wide.
- PLACEHOLDER TYPE: the DejaVu CTA reads clean but generic; fine for the pilot, decide
  before the batch so the card design system freezes once.
- RENDER-FIX LOG quality: the three fixes (integer-epoch audio/video alignment, alimiter
  look-ahead compensation, MP4 edit-list media_time artifact resolved by lossless remux
  with framemd5 identity) are correct diagnoses of real, subtle failure modes; the
  discarded fps_mode=cfr experiment (resampled to 25 fps) was caught and dropped. This is
  CORE §17 discipline in practice — cite it as the reference example.
- ENVIRONMENT INCIDENT: the agent's sandbox lost files mid-run (re-provisioning); it
  re-fetched sources, re-rendered, hash-verified, and backed up to Drive. Resilience
  handled correctly; no evidence gap.

## 6. Recommended next message to the agent (after you watch/listen)
"Pilot accepted [or: accepted with the silent-card variant change]. Batch pattern
approved for the card+conform+audio pipeline as rendered on clip 28. Apply to the P5-
eligible clips; excluded list unchanged (08, 09, 17, 24, 25). Logo/font/rights decisions:
[fill]. Keep review_draft labels until R4 items close."
