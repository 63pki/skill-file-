# v3.1.1 Pilot Plans — Three Private Pilots (PLANS ONLY — NO RENDER UNTIL APPROVED)

Status per the pilot-readiness review: **plans only; do not render until the operator approves**;
do not reopen source-access retries without new evidence or authorization.

## 0. Source and profile status (read first)

- **What exists today:** 10 *delivered* RexTrix finals + `DELIVERY_MANIFEST.md`. These are finished
  outputs, **not clean raw sources** — a prompt revision does not resolve missing originals. No
  RexTrix raw-source access exists in this workspace, and none will be attempted.
- **Therefore every pilot needs you to supply clean, authorized source files** (original camera
  audio where dialogue matters; ≥1080×1920 or croppable; rights cleared). Any authorized,
  non-campaign footage you own is valid pilot input — the pilots test the *prompt's behavior*,
  not a specific campaign.
- **Profile:** the appendix §A.1 RexTrix instance is INACTIVE (C3). Pilots run under a minimal
  generic profile (1080×1920, 30 fps, 15–40 s, English sources, no campaign mandates) unless you
  supply the current RexTrix brief for reconciliation — in which case intake builds the active
  profile from the brief, not from the example.

## Pilot 1 — Visual reveal (restraint under temptation)

- **Main question:** does the agent allow the scene to unfold without unnecessary interference
  (no timer-cuts, no reflex zooms, no decorative overlays, no premature text)?
- **Source needed:** one continuous authorized take (15–40 s) with a natural visual reveal
  (e.g., a transformation, a hidden detail becoming clear, an environment opening up).
- **Agent does:** intake + environment probe; minimal-evidence floor (§7.1); paper edit with
  structure chosen from evidence (FRT treatment (a) expected); technical QC with named tools +
  reproduction commands; delivery notes disclose any deviations.
- **You do:** watch and listen to the exact delivered file. Judge: did it breathe? Was anything
  cut that carried the reveal? Would a human editor have shipped this?
- **Pass:** all Tier 0 gates pass; no waiver used; no unjustified cut/zoom/text; payoff complete
  and understandable; QC block reproducible.

## Pilot 2 — Dialogue / comedy (context and timing over cleverness)

- **Main question:** does the edit preserve context, the complete exchange, and the reaction —
  and keep its hands off the timing?
- **Source needed:** authorized dialogue footage (15–40 s) containing a setup → punchline →
  reaction beat, clean production audio.
- **Agent does:** ASR + word-boundary mapping (±tolerance per §13, never hard anchors); word-
  integrity-safe cuts; preserve breaths/hesitation where they carry the performance (§4
  human-sensitive list); minimal or zero graphics (legal per paper test P3); full QC.
- **You do:** watch and listen. Judge: does the joke land as performed? Any mid-word clip, any
  stolen reaction, any unnecessary caption racing the punchline?
- **Pass:** Tier 0 gates pass; exchange complete (`answer_delivered_complete`); reaction present;
  no meaning-changing rearrangement; joke timing routed to human review queue, not auto-passed.

## Pilot 3 — Process / transformation (promise → understandable result)

- **Main question:** does the opening establish the task and the ending deliver an understandable
  result — with the structure chosen from evidence rather than a forced peak-preview template?
- **Source needed:** authorized before → process → after footage (15–40 s), any subject.
- **Agent does:** moment selection with evidence; opening structure from the §6.2 menu (expected:
  result-first or chronological, NOT forced peak-preview); payoff contract §6.3 written at
  paper-edit and verified on rendered frames; honest end treatment (no end card unless a supplied
  profile requires one); full QC.
- **You do:** watch and listen. Judge: did you understand the task immediately and the result
  completely? Any false-outcome preview? Any repetition that adds or subtracts meaning?
- **Pass:** promise_evidenced / answer_delivered_complete / no_false_outcome /
  qualifications_preserved all true on rendered frames; structure choice logged with evidence.

## Scaling gate (review Step 4)

Only after you review all three pilots. If a pilot fails: revise that specific edit first; change
the master only when the failure reveals a **repeatable instruction problem** — not because one
creative decision was weak. A production run (e.g., 30 clips) is approved by you, on pilot
evidence plus — eventually — audience data, never by document-check counts.
