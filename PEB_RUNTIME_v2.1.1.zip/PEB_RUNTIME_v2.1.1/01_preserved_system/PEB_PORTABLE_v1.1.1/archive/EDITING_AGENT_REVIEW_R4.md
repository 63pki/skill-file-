# EDITING AGENT REVIEW — ROUND 4 (SUB-BATCH A: QC AUDIT + FOUR RULINGS)
Date: 2026-10-27 · Trigger: agent delivery of sub-batch A (21, 22, 23, 26, 27, 29),
full QC, four decision requests, hard stop honored before B/C/D.
Evidence-level disclosure (honesty layer): the six renders and the packet live on the
agent's Drive — NOT uploaded to this channel. This round is a DOCUMENT-LEVEL audit:
reported numbers were checked for internal consistency (arithmetic reproduced in §0),
not independently re-measured. One file upload (SA-6, item 6) bridges that gap before
B unlocks.
Verdict: hard gates 6/6 as reported; delivery discipline is exemplary (card entry found
independently per file — cited as reference behavior). The HARD STOP HOLDS: four
rulings below + the SA-6 checklist, then B opens.
Naming note (R3 §1 standing rule): Round-4 rulings are prefixed SA- (sub-batch A),
NOT "R4-", because R4 already names a Round-1 ruling in this campaign's namespace.

## 0. ARITHMETIC SPOT-CHECKS (document-level — all consistent)
- The −15.3 LUFS finding reproduces exactly: body-only normalization to −14.0, then a
  5.000 s silent card over 18.933 s pulls whole-file integrated down by
  10·log10(18.933/13.933) ≈ 1.33 dB → −15.33. The diagnosis is arithmetically exact,
  and fixing the methodology (full-program normalization) rather than iterating the
  target is the correct systemic response — same class as the Round-1 R3 limiter
  conclusion.
- Conform accounting reproduces: 1016f@60 = 16.933 s → 418 body + 150 card = 568 =
  18.933 s ✓; 824f = 13.733 s, entry 10.733 → 322 + 150 = 472 = 15.733 s ✓; 928f =
  15.467 s, entry 12.467 → 374 + 150 = 524 = 17.466 s ✓. All six card holds 5.000 s.
  Deliverable band 15–25 s: all six inside (worst: 22 at 15.733).
- All six sources appear to carry a 3.000 s template outro card (entry = total − 3.0 s
  in every case) — consistent with a channel outro template, and precisely why SA-5
  exists: six same-structure sources (four of them identical in duration, frame count
  AND card-entry time) are exactly where a source mis-mapping would be invisible to
  every gate.

## SA-1 — CLIP 22 ENTRY POINT (question 1: "want a different entry point?")
Facts first, then decide — do not re-cut on taste alone.
- REQUIRED: ASR the dropped source region 10.733→13.733 s (source time) and classify
  the speech:
  (a) Source outro/promo speech (expected under a template outro card) → KEEP AS
      DELIVERED. Dropping the source's own CTA under the campaign end card is not a
      loss — a source CTA competing with the campaign CTA is a brand conflict, and
      unverified availability claims there would be an R-04-class risk. Log the
      transcript excerpt + classification in the QC table.
  (b) Material in-story speech → RE-CUT: move the card entry to the first card
      boundary AFTER the material speech ends (keeps the speech, card stays 5.000 s,
      runtime stays in band), re-run full QC on the re-cut.
- Default is (a) keep-as-delivered. The 1.2 s "loss" is bounded by what the transcript
  says, not by the runtime arithmetic.

## SA-2 — BODY FREEZES ON 23 (4) AND 29 (1) (question 2)
The agent's stated evidence does not yet support the conclusion. Motion present in the
60 fps source at the same content time + freeze in the delivery is NOT proof of a
"delivered dramatic hold" — it is equally consistent with a conform-extended hold. The
differential below is the proof, one way or the other. Required before B:
- For each of the 5 events: count consecutive below-threshold frames in the delivered
  file vs the SAME content span in the 60 fps source sampled at 30 fps
  (every-other-frame, the delivered cadence). Hold lengths match within one frame
  period → SOURCE-NATIVE hold: log as an observation with an evidence strip (the
  black_windows_strip pattern), accept, move on. Delivered hold longer → CONFORM
  EXTENDED: fix the frame-selection logic, re-render the affected clip(s), full re-QC.
- Document the freeze detector's threshold and minimum duration in the QC methodology
  (it is currently implicit — "freeze" must be defined identically for B/C/D or the
  comparisons are meaningless).
- If source-native: these are observations, not defects — no gate covers pacing holds.
  If conform-extended: this is a repeated defective pattern inside the conform class
  (21/23/26/27/29 + upcoming 30) and must be fixed BEFORE B, per P5's final sentence.

## SA-3 — CARD BED: VARIANT B IMPLEMENTATION (question 3)
Direct answer: do NOT hunt beds earlier in the sources. Implement B as the agent's own
experiment — same-source looped ambience — under these conditions:
1. Bed audio comes ONLY from the same source file (original audio, M7-compliant; this
   is a re-edit of source audio, not ADDED music — record that reasoning in the QC
   methodology once).
2. The looped segment contains NO speech (no fragments, no half-words — a garbled
   speech loop under the CTA is worse than silence).
3. Click-free crossfades at loop seams (a 5.000 s card over a shorter loop = at least
   one seam per clip).
4. Post-normalization bed level lands in the band −30 to −20 dBFS under the card —
   quiet presence, never competing with the CTA. The agent's −20 dB result sits at the
   top edge of the band; acceptable.
5. Per-clip provenance in the QC table: source range used, loop length, seam count.
6. Full re-measure on final files after the bed change: integrated LUFS (the bed
   shifts it — the full-program chain re-normalizes), TP, card hold, black, PTS grid,
   freeze re-scan.
- Per-clip fallback: if a source has no clean non-speech ambience, that clip falls
  back to the A-style silent tail, disclosed in its QC table. Allowed, rare, logged.
- The operator elected B to avoid a digitally silent card; a verified −20 dB source
  ambience serves that intent. If the operator listens to A-final and wants a real
  musical bed, the earlier-source hunt becomes an explicit operator request — not a
  default.

## SA-4 — AUDIO CHAIN v2 + PILOT RE-CUT (question 4)
- APPROVED as a pattern amendment: audio chain v2 = full-program loudness measurement
  and normalization (body + card), bounded post-encode correction pass (observed
  +0.5 to +1.3 dB), limiter ceiling −1.5 dBFS. Rationale: the deliverable is the whole
  file; the platform reads whole-file loudness; the R2-P1 re-norm rule anticipated
  exactly this class of drift. Nothing in the card or conform changed — pattern
  identity is preserved.
- TP margin condition: with the ceiling at −1.5 dBFS, flag any clip whose FINAL
  measured TP lands above −1.2 dBTP (0.2 dB margin to the −1.0 gate is too thin for
  codec overshoot variance). Current worst in A: −2.1 — comfortable. Add a TP-margin
  column to the QC table.
- PILOT RE-CUT: the "stays as delivered" option is VOID — the operator's variant-B
  election already obsoleted the delivered pilot file (R3-a: clip 28 re-cuts to
  match). Clip 28 therefore takes ONE re-cut combining variant B bed + chain v2, so
  the pilot reference and the batch share one chain version. Full QC re-run on the
  re-cut, new hash on file, review_draft label unchanged.

## SA-5 — PROVENANCE + LANGUAGE COMPLETION ITEMS (new, cheap, blocking)
1. SOURCE IDENTITY: surface the per-clip source SHA-256 into the QC table (the render
   records likely already contain it), and confirm first-frame uniqueness across the
   six (frame-hash or the six-up strip, stated explicitly). Four same-structure
   sources make a mis-mapping invisible to every gate; this check kills that class.
2. LANGUAGE (M2): per-clip body ASR row in the QC table (pilot precedent: machine
   verification, fluent-English + no banned claims). Clip 22's row includes the SA-1
   region transcript.

## SA-6 — B UNLOCK CHECKLIST (hard stop holds until ALL are closed)
1. SA-1 closed: 22 region ASR + classification applied (re-cut only on branch (b)).
2. SA-2 closed: differential done for all 5 events + detector threshold documented;
   conform fix + re-renders only if conform-extended.
3. SA-3 closed: bed pass applied to all six per the conditions; fallbacks disclosed.
4. SA-4 closed: clip 28 re-cut (B + chain v2) delivered; TP-margin column added.
5. SA-5 closed: source hashes surfaced + first-frame uniqueness + M2 rows on file.
6. INDEPENDENT BRIDGE: upload the FINAL clip 23 (post-corrections) to this channel
   for pilot-grade independent re-measurement. If the numbers match, the other five
   document-level reports carry batch confidence; if they do not, the whole packet
   reopens before B.
Then B renders (30, 01, 02, 03, 04, 05) under the same pattern. Operator listen on
A-final: optional before B, recommended before any release candidate (which remains
blocked on R4 (a)/(b) + the rights grant regardless).

## REFERENCE BEHAVIORS CITED (this round)
- Per-file independent card-entry detection ("a batch-wide assumption would have
  wrecked 22 and 29") — measure-don't-assume at batch scale; reference example.
- mpdecimate drop accounting tied to the card's own hold — nothing duplicated or
  frozen by the conform, verified rather than presumed.
- Drive durable copy after the earlier sandbox loss — the resilience lesson retained.
- Four questions raised instead of four assumptions made — the ask-don't-assume
  discipline holding under production pressure.

## OPERATOR LINE (paste to the editing agent)
"Sub-batch A rulings SA-1…SA-6 (EDITING_AGENT_REVIEW_R4.md): (1) Clip 22 — ASR the
dropped 10.733–13.733 source region first; keep as delivered if it is source-outro/
promo speech (default, log transcript + classification); re-cut entry only for
material in-story speech, then full QC. (2) Freezes 23/29 — current evidence is not
conclusive either way; run the hold-length differential (delivered vs source at 30fps
cadence, same span): match within one frame period = source-native, log + evidence
strip, accept; longer = conform-extended, fix selection + re-render before B;
document the freeze-detector threshold in the QC methodology. (3) Bed — no hunt;
implement B as same-source looped ambience: no speech in the looped segment,
click-free crossfades, post-norm level −30 to −20 dBFS under the card, per-clip
provenance in QC, full re-measure of LUFS/TP/card/black/PTS/freezes after the bed
change; per-clip silent-tail fallback allowed if no clean ambience, disclosed.
(4) Chain v2 APPROVED as pattern amendment (full-program loudness, bounded
post-encode pass, ceiling −1.5 dBFS; flag any final TP above −1.2 dBTP; add TP-margin
column); clip 28 takes ONE re-cut combining variant B + chain v2 — 'stays as
delivered' is void because B already obsoleted it. (5) Surface per-clip source
SHA-256 into the QC table, confirm first-frame uniqueness across the six, add
per-clip M2 ASR rows. (6) B unlocks only after items 1–5 close AND final clip 23 is
uploaded to this channel for independent spot re-measurement. Hard stop holds until
then. Cited as reference behavior: per-file card-entry detection, mpdecimate
accounting, Drive durable copy, ask-don't-assume."
