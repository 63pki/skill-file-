# EXTERNAL REVIEW OF v3 — VERIFICATION, VERDICT, AND ACTION PLAN

Input: an external review comparing PRO_EDITOR_BRAIN_v3.md (+ appendix) against the user's revised
master prompt (upload/PRO_EDITOR_BRAIN_MASTER_PROMPT_REVISED.md). Method here: every substantive
claim in that review was checked against the shipped v3 text line-by-line before deciding anything.

Headline answer to "fix, add, remove, or new consultations?":

**Fix and remove — yes. Add — almost nothing. New consultations — no.**
The review's diagnosis is confirmed: v3 is not missing knowledge, it over-governs the knowledge it
has. A new consultation would add another engine — precisely the failure mode the review warns
against ("remove unjustified obligations — not add another engine"). The correct response is a
governance revision: **v3.1**, executed in this run.

---

## 1. Claim-by-claim verification (external review vs actual v3 text)

### 1.1 The eight "most important regressions"

| # | Review claim | Verified? | Evidence (v3.md) | Verdict |
|---|---|---|---|---|
| 3.1 | Editorial preferences became hard creative laws (setup ≤25%, payoff windows, shot-length thresholds, ≥3× ASL, J/L minimums, dynamics patterns) | YES | L255 "Setup ≤25% of runtime"; L266 "Payoff entry lands at 70–85% of runtime"; L355–357 "CV < 0.25 fails the cut [RHY-4]", "At least one shot ≥3× ASL per piece [RHY-5]"; L386 "≥50% of speaker changes should be J or L"; L1085–1099 feel rubric blocks release | **ACCEPT.** The 3× ASL rule is mathematically impossible for any piece with few shots (a 10 s two-shot edit has ASL 5 s and would need a 15 s shot inside 10 s). Same contradiction is embedded in TELL-7 (L417) and rubric item 4 (L1089). Also: §6 caps setup at ≤25% while §7.2 band is 20–30% — an internal conflict the review didn't even catch. |
| 3.2 | One template replaced by a more elaborate template (peak-preview default + export-blocking payoff window) | YES | L490–493 [TEAS-1] "Default timeline: real peak preview 0.4–1.25 s … payoff completing at 0.70–0.85T"; L498–501 [TEAS-2] "contract booleans — any miss blocks export … pct_in_window (payoff completes 0.70–0.85T)"; appendix A L20–22 bakes `mode: real_peak_preview` into the profile schema | **ACCEPT, with nuance.** TEAS-5 does offer alternatives, but TEAS-2's blocking booleans as written apply regardless of chosen structure — so a context-first or uninterrupted structure can auto-fail. Real contradiction. |
| 3.3 | Three-channel hook requirement conflicts with restraint | YES | L450 [HOOK-1] "Build the hook as a three-channel package"; L466–469 [HOOK-4] "Strong: 18–24 with visual/audio/text each ≥3"; "Weak: ≤11 **or any channel ≤1** — revise before batch entry"; appendix A L16 `required_channels: [visual, audio, text]` — while L481–484 [D3] says "No added headline is a valid choice when the source supplies the hook" | **ACCEPT.** As written, a wordless visual reveal scores text ≤1 → forced "weak" → forced rework. The rubric punishes exactly the restraint §4 protects. |
| 3.4 | Subjective scoring with unjustified precision (moment ≥75, hook ≥18, r ≥0.60, taste ≥75, entropy ≥0.70, quotas) | YES | L221 [MOM-2] "M ≥ 75"; L468 [HOOK-4] "18–24"; L430 [EMO-2] "Pass r(T,R) ≥0.60"; L1219–1220 [GOV-4] "accept ≥75/100"; L1164 [VAR-3] "normalized entropy ≥0.70"; L1159–1166 [VAR-2] axis caps | **ACCEPT.** None of these thresholds has been validated against performance data. "Metrics are checks, never objectives" [EMO-4] is contradicted by the same metrics blocking release in §18. |
| 3.5 | Campaign rules imported into the permanent master (end-card logo+wording; +0.5 s beyond any campaign minimum) | PARTIALLY | L131–133 §3 end-card definition; L934–938 §15 "holds at least that minimum PLUS 0.5 s (e.g., ≥4.5 s against a 4 s rule)" | **SPLIT DECISION — push back partially.** These rules are not inventions: they encode measured rejection causes (Clip 16 failed at exactly 4.0 s; Clip 07 needed the instrumental path). Removing the compliance *mechanism* would regress the R1–R5 restorations that v3 was rebuilt for. But the review is right that **values** don't belong in universal law. Fix = parameterize: gate mechanism stays in the core; durations, wording definitions, margins move to the campaign profile (with the 0.5 s margin documented as a production policy with its Clip-16 rationale). The review's sharpest sub-point is adopted: a margin is not a substitute for exact measurement — both stay. |
| 3.6 | Environment-specific history became permanent truth ("known-bad" background FFmpeg; keyframe+audio as integrity path) | YES | L91–92 "known-bad are long-running or backgrounded ffmpeg jobs (the environment kills them, OOM-style) [D5]"; L96 "Environment governance (observed constraint, **applies everywhere**)" [ENV-1]; L1075–1076 keyframe+audio fallback in QC | **ACCEPT.** One sandbox's OOM behavior is not a law of nature. The keyframe+audio path also cannot prove inter-frame decode. Fix = session-start environment probe; results recorded per environment; fallback evidence must be labeled "partial integrity inspection; full decode not checked" — never as equivalent. |
| 3.7 | Mandatory analysis can block the drafts you want (signal stack before any cut; unknown intent stops for a human; MG-5/6 block graphics) | YES | L300–301 [SIG-1] sidecar "BEFORE any cut"; L302–303 [SIG-2] "never drop words/VAD/silence"; L427–428 [EMO-1] "unknown intent → stop for a human"; L599–601 [MG-5/6] "route to review rather than autonomous render … never render-queue entries" — while §18 L1151–1153 permits clearly-labeled private drafts | **ACCEPT.** The review's three-way distinction becomes policy: (a) missing evidence that makes an edit *unsafe or misleading* → hard gate; (b) missing optional automation → degrade to a simpler treatment; (c) pending *perceptual* judgment → deliverable as labeled review draft. |
| 3.8 | Source-baked defects get an inappropriate exemption ("never counted against the deliverable's QC grade") | YES | L896–898 [P-V5] | **ACCEPT.** Origin ≠ severity ≠ acceptability. A baked-in banned claim or non-qualifying burned-in language is still disqualifying (§3 already gates burned-in text — the two rules currently contradict each other). Fix: three buckets — cosmetic inherited (disclose, not the editor's defect); compliance-relevant inherited (still gates the source segment); quality-relevant inherited (disclose + retention-risk note per P-V3). |

**Score: 7 fully verified, 1 split, 0 unfounded.** The review earned its conclusion.

### 1.2 The six technical inconsistencies

| # | Claim | Verified? | Evidence | Fix adopted in v3.1 |
|---|---|---|---|---|
| T1 | Word-edge ±4 f vs "hard anchor ±1 f" | YES | L307–308 [SIG-5] vs L338 [SIG-4] | Hard anchors are redefined as machine-verified **visual/audio** events (decoded-frame-verified scene boundary, impact/flash frame, downbeat conf ≥0.7). ASR word edges are **never** hard anchors; their floor stays ±4 f (±8 f low logprob). |
| T2 | Frame-normalized keys vs ms audio keys → samples | YES | L740–742 [KF-3] "normalize every key time to an integer output frame" vs appendix H L189–190 "ms audio keys map directly to samples" | One explicit contract: visual keys → integer frames (half-up); audio keys → **sample indices** from a single epoch, computed cumulatively. Master text corrected. |
| T3 | dB-domain gain vs linear gain | YES | L752 [KF-6] "dB domain for gain" vs appendix H L192 "Volume is linear gain" | One domain: storage and interpolation **linear** (matches sample-multiplication rendering and pan math); dB allowed only as human-authored input/reporting with the documented conversion linear = 10^(dB/20). |
| T4 | frames × 48000/F not always integer | YES | L751 [KF-6], L972 [SYNC-3] — while §3 L82 makes fps configurable | Total samples = round(total_duration × 48000) computed **once, cumulatively**; per-frame 1600 only when 48000/F is an integer; endpoint policy defined; AAC priming measured (kept from v3). |
| T5 | sRGB working space vs BT.709 encode tags | YES | L945–953 [ENC-2] "Working composite = display-referred sRGB" vs appendix J L218–224 "canonical BT.709 RGB frames" + range/matrix scale + `-color_trc bt709` | The review is technically right: primaries match but sRGB and BT.709 **transfer functions differ**; range+matrix conversion plus tags without a transfer conversion is relabeling. v3.1: working space = BT.709 primaries + BT.709 transfer (γ 2.4) display-referred full-range; sRGB artwork linearized on ingest through an explicit, fixture-verified transfer conversion; delivery = matrix+range only. If a toolchain step cannot convert transfer functions, it blocks or routes through the fixture-tested linear route — never silently relabels. |
| T6 | Overshoot 1.03 cap vs hero recipe 1.10 | YES | L649–650 "scale overshoot ≤1.03" vs L1017–1018 recipe A "scale 60%→110%→100%" | 1.03 stays the global cap; §17 recipe A is declared a **documented exception** (1.10, display-type entrances only, never on data/measurement/tracking endpoints). |

### 1.3 Bonus defects found during verification (not in the external review)

- **B1.** §6 setup cap (≤25%) conflicts with §7.2 setup band (20–30%) — unified in v3.1 to one band with a deviation-logging ceiling.
- **B2.** Appendix H contains a leftover editing artifact: "[frame_N rendered? no — visibility is [start, end)" — a broken sentence fragment shipped in the reference contract.
- **B3.** Appendix A bakes `owner_mandates: {…, real_peak_first, strong_visual_audio_text_hook, …}` into the *schema itself* — meaning one campaign's owner mandates masquerade as a universal schema default, and via PREC-2 ("locked owner mandates" outrank campaign requirements and craft defaults) become effectively unoverridable everywhere. This amplifies review points 3.2/3.3 and is the deepest governance bug in v3. The schema now takes owner mandates as **per-campaign data**; the RexTrix instance ships separately.
- **B4.** RHY-4's CV gate and TELL-1's autocorrelation have no minimum shot count — CV is undefined/meaningless for N<4 shots. Guard added.

### 1.4 Claims in the review that were slightly overstated (recorded for fairness)

- §7.2's act percentages already declared themselves "DENSITY PRIORS ONLY … never pad shots to hit a percentage" (L350–352). The rigidity entered through §6's spine cap and the QC gates, not §7.2 itself. (Still fixed.)
- MG-5/6 route unknowns to **review drafts**, and §18 does define review_draft as a deliverable state — so the machinery for the review's fix partially existed; it was just contradicted by "stop for a human" and "never render-queue entries" phrasing. (Reconciled.)

---

## 2. What happens to v3 (the execution decision)

The review's own 5-step recommendation is adopted almost verbatim as the v3.1 work order:

**KEEP (confirmed strengths):** payoff/answer evidence contract (window removed from gate status); fallback ladders + disclosure templates; compositing anti-mislead rules (duplicate subjects, retimed RGB/mattes, anatomy); "cosmetic variation ≠ creative variety" distinction; source-evidence discipline; claims ledger; delivery identity; §9 design system; word-integrity cutting; room-tone/breath rules; deception guardrails; R&D pre-registration; operator checklist duty.

**DEMOTE to advisory diagnostics (Tier 3) — measured and reported, never blocking alone:** moment score M, hook rubric totals, emotion-curve r, taste rubric, entropy, all variety axis caps, CV/ASL/accelerando/rule-of-three, J/L proportions, punch-spacing statistics, twelve-tell audit (except its law-level members), feel-rubric totals, payoff percentage windows, opening-family quotas. Each diagnostic records: value, band, and a one-line interpretation. Thresholds are explicitly labeled **uncalibrated priors** until the §R&D loop validates them on real campaign data.

**KEEP AS CRAFT DEFAULTS (Tier 2) — deviation allowed with a logged reason:** pacing bands, hold-length windows, SFX/punch budgets, caption density targets, graphic moment caps, reading-time formula (this one stays strong — it protects comprehension), phase percentages.

**KEEP AS LAWS (Tier 0) — unoverridable:** truthfulness/honesty layer; rights; claims evidence; language gate mechanism; deception guardrails (no false outcomes, no meaning-changing rearrangement, qualifications preserved); word integrity (no cut inside a word); sync/decode/loudness verification with named tools; QC reproduction commands; disclosure duties; "answer delivered uncut" payoff proof.

**CAMPAIGN LAYER (Tier 1) — profile data, not universal law:** end-card definition (logo graphic + action wording), duration floors + the 0.5 s margin (as documented production policy with rationale), language rule values, banned-claim lists, channel policy, owner mandates (peak-first, three-channel hooks, strongest-moment selection — kept because the *owner* mandated them, but executed **attempt-first with logged deviation**, never as forced fabrication; the owner can amend their own mandate at any time).

**REMOVE/REPLACE:** "applies everywhere" environment claims → per-environment probe; blanket P-V5 exemption → origin/severity/acceptability split; TEAS-2 universal blocking booleans → structure-relative (universal booleans: promise evidenced, answer delivered uncut, no false outcome, qualifications preserved); MG-5/6 absolute render block → simpler-treatment-or-review-draft routing; EMO-1 stop-for-human on unknown intent → intent-neutral treatment + concept routed to review in the private draft.

**RESTRUCTURE (token economics):** the review is right that "load on demand" inside one pasted document removes nothing. v3.1 ships as **four files**: CORE (always pasted, self-sufficient for standard edits) + MODULE_GRAPHICS + MODULE_MOTION_PIPELINES + APPENDIX_REFERENCE (attached only when the task needs them). Achieved: CORE 83.9k chars / 11.8k words vs v3's 108.1k / 15.1k (−22%); the 26k-char graphics/keyframes/stabilization/compositing machinery plus rhythm tables, QC gate tables, and disclosure templates now live in attachable files. The remaining core mass is operating rules, not reference material — the deeper cut the review asked for comes from demotion (nothing left in the core blocks release on uncalibrated taste numbers), not from deleting the keep-list content.

**NEW — Freedom Regression Test (FRT):** the system must be able to approve, without any waiver, when footage supports them: (a) an uninterrupted slow reveal; (b) a wordless visual moment (no added text); (c) a dialogue joke with minimal graphics. Any rule that makes one of the three fail is mis-tiered and must be re-tiered. Encoded in CORE §QC and in the audit harness.

---

## 3. Why no new consultations

1. Every defect above is an **integration-governance** error (heuristics hardened into laws, one campaign's profile baked into the schema), not a knowledge gap. The four consults' technical content — signal stack, fallback ladders, compositing protections, R&D design — survived review and stays.
2. The only open empirical question ("do these thresholds predict performance?") cannot be answered by any consultant; it is answered by the pilot + R&D loop already designed into v3 (pre-registered experiments, ≥20-clip calibration, scoped priors) plus the new FRT.
3. Adding consultant material now would move token mass in the wrong direction: the review's core complaint is burden, and the correct next artifact is a *leaner* core.
4. The one consult worth doing later — threshold calibration review after the first ~30 scored clips with performance data — is scheduled as a **triggered** action, not a now action.

---

## 4. Execution map (produced in this run)

| File | Content |
|---|---|
| `V3_EXTERNAL_REVIEW_verdict_and_actions.md` | This document. |
| `PRO_EDITOR_BRAIN_v3.1_CORE.md` | Revised master prompt: 4-tier rule taxonomy; parameterized campaign layer; fixed audio/color/sample/anchor contracts; freedom regression test; self-sufficient for standard Mode B edits. |
| `PEB_v3.1_MODULE_GRAPHICS.md` | §10 motion-graphics engine (moment classes, allocation, choreography, archetypes, anti-slop) with MG-5/6 re-routed to simpler-treatment-or-review-draft. |
| `PEB_v3.1_MODULE_MOTION_PIPELINES.md` | Keyframe engine, stabilization, background removal, layered compositing — with corrected sample/gain/overshoot contracts. |
| `PEB_v3.1_APPENDIX_REFERENCE.md` | Campaign profile schema (owner mandates as per-campaign data + separate RexTrix instance), signal sidecar, rhythm reference tables (marked uncalibrated priors), feel-spec schema, frame-truth fixture, disclosure templates. Appendix B2 fragment removed. |
| `scripts/v31_regression_audit.py` | Audits v3.1: compliance spine, tier labels, 8 regression fixes, 6 technical fixes, freedom-regression test, forbidden patterns, cross-file references. Final run: **76/76 PASS**. |

Precedence is unchanged and now explicit: **honesty layer > campaign gates (mechanism) > profile values > craft defaults > diagnostics.**
