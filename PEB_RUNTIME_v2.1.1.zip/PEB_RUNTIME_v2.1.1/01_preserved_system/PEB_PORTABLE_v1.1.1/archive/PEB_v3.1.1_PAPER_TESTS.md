# v3.1.1 Paper Tests — FRT Traces at Document Level

Run: 2026-10-26, against the frozen v3.1.1-TEST files, after the audit (102/102). A paper test is
CORE §15.6's own mechanism: trace each treatment through every gate and record which rules would
obstruct it. These are **instruction-following tests, not proof of editing quality** — they check
that the rule set routes correctly on paper; only pilots on real footage test behavior.

The four checks the pilot-readiness review requires of every test:

1. Appropriate restrained treatments remain legal.
2. Mandatory campaign requirements remain enforced.
3. Missing optional automation does not block a safe private draft.
4. Unsupported claims and missing promised payoffs still block acceptance.

---

## P1 — Uninterrupted slow reveal (single held shot or minimal cuts, complete story)

**Gate trace.**
- §6.2 OPENING STRUCTURES: the menu (peak_preview, chronological_context_first,
  result_first_process, uninterrupted_scene, mystery_question) explicitly contains the
  uninterrupted scene; "no structure is universal" (appendix §A teaser_policy). The
  peak-preview window [0.4–1.25 s] and payoff window [0.70–0.85] are Tier 3 diagnostics that
  "never block a structure chosen for evidence-based reasons" [3.2-fix] — a reveal that skips the
  peak-preview structure trips nothing.
- §4 tiers: pacing bands, hold windows = Tier 2 (deviate freely, log); variety budget and opening
  beat caps = Tier 1 **PREFERENCE** post-C2 (attempt-first, deviate with logged reason) — a single
  slow piece can never be blocked by a batch-level quota.
- §6.3 payoff contract: a held shot satisfies `answer_delivered_complete` — the boolean requires a
  complete, understandable delivery, not a cut count; `promise_evidenced`, `no_false_outcome`,
  `qualifications_preserved` are source-evidence checks, structure-neutral.
- §15.6 FRT: treatment (a) is approvable without waiver when the campaign permits it.
- §7.1 minimal evidence floor (T0) is evidence-gathering (speech/silence map), not creative
  automation; no optional automation (keyframes, graphics engine) is needed by this treatment.

**Conditional branch (deliberate):** if the campaign's profile carries a MANDATORY caption or
branding rule, the corrected §15.6 records the treatment as unavailable-for-this-campaign and the
mandatory stands — no re-tiering. This is the C1 guard doing its job.

**Result: PASS.** Checklist: 1 ✔ (legal when campaign permits) · 2 ✔ (mandatory override branch
routes to "unavailable", never to rule-weakening) · 3 ✔ (no automation needed; review-draft path
per §15.8 stays open) · 4 ✔ (claims ledger §5 and payoff booleans §6.3 untouched by the treatment).

## P2 — Wordless visual moment (no added text; hook carried by image and natural sound)

**Gate trace.**
- §8 HOOK CHANNELS: "channel the concept does not need is scored 'not used', and a missing
  unnecessary channel is NOT a [weakness]" [3.3-fix]; "dimensions for channels not used are marked
  'not used' and excluded". No channel floor forces a caption onto a wordless opening.
- Appendix §A hook_policy: `silence_open: {allowed: true, meaningful_audio_entry_by_seconds: 0.6}`
  — a quiet open is legal profile data; no universal channel list, no universal score floor.
- §4/§8: hook and moment scores are Tier 3 diagnostics — they rank and organize review; "the
  rubric organizes rework and review; it does not gate release" [3.4-fix].
- §11 captions: caption density targets are Tier 2 defaults; text appears only when the concept
  needs it. If the profile makes captions MANDATORY, the C1 branch applies (treatment unavailable
  this campaign, requirement stands) — same as P1.
- §15.6 FRT: treatment (b) approvable without waiver when the campaign permits it.

**Result: PASS.** Checklist: 1 ✔ · 2 ✔ (same mandatory branch as P1) · 3 ✔ (wordless needs no
automation; diagnostics missing = "not checked carries a reason", never a block for a private
draft) · 4 ✔ (no text = no claims surface; language gate trivially satisfied by silence, burned-in
text check still runs if any text exists).

## P3 — Dialogue joke with minimal graphics (cuts and timing carry the humor)

**Gate trace.**
- §7.3 word integrity + §6.4 deception guardrails (Tier 0): no cut inside a word, no
  meaning-changing rearrangement, reaction preserved — these protect the exchange and are exactly
  compatible with `answer_delivered_complete` post-C5 (a complete exchange may legitimately span
  several shots; qualifications survive).
- §9 / GRAPHICS module: graphic moment caps and anti-slop checks limit EXCESS (Tier 2/3) — they
  never force graphics onto a minimal treatment; zero graphics trips nothing.
- §15.8 HUMAN REVIEW ROUTING: humor and joke timing go to the review queue — "queue, never
  auto-pass"; per §15.8, pending human review does not automatically block an authorized private
  draft (mark the exact pending checks) [3.7-fix]. So taste uncertainty routes; it does not block.
- §3 language gate (P-V2) still verifies the dialogue language — the joke gets no exemption, and
  correctly so.
- §15.6 FRT: treatment (c) approvable without waiver when the campaign permits it.

**Result: PASS.** Checklist: 1 ✔ · 2 ✔ (language/claims mandatories untouched and enforced) ·
3 ✔ (review-draft path open; graphics engine not needed) · 4 ✔ (a spoken claim in dialogue still
needs the claims ledger — routing to §5 unchanged).

---

## Summary table

| Test | Legal without waiver (campaign permitting) | Mandatories still enforced | No automation blocking | Claims/payoff still gate | Verdict |
|---|---|---|---|---|---|
| P1 uninterrupted slow reveal | ✔ | ✔ (C1 branch) | ✔ | ✔ | PASS |
| P2 wordless visual moment | ✔ | ✔ (C1 branch) | ✔ | ✔ | PASS |
| P3 dialogue joke, minimal graphics | ✔ | ✔ | ✔ | ✔ | PASS |

**Honest limitations.** These traces were performed by the prompt's builder (self-test), at
document level, against a generic/absent profile. They show the rule set no longer structurally
obstructs restrained treatments and that the C1/C2 guards route mandatory conflicts correctly.
They do not substitute for: (a) running the FRT at a real campaign start against a real reconciled
profile, and (b) the three pilot renders where a human watches and listens to the delivered files.
