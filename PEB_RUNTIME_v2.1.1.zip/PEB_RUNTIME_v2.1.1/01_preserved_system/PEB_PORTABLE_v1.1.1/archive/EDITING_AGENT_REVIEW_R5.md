# EDITING AGENT REVIEW — ROUND 5 (external-review adoption, XR series)

Date: 2026-10-27
Source: second independent review, two files — `RexTrix_Workflow_Review.md` (workflow
audit + independent clip-28 re-check) and `On_Demand_Video_Tool_Guide.md` (tooling).
Namespace discipline (per R3 §1):
- `ER-F1…ER-F7` = the external review's findings (their numbering, quoted in §1).
- `XR-1…XR-8` = THIS round's adoption rulings (XR = external-review adoption; chosen to
  avoid collision with R1–R4, P1–P5, P-V1…P-V7, SA-1…SA-6).
- Registry references = `PEB_v3.2_MODULE_TOOL_REGISTRY.md` (now v3.2.1).

Scope note (the review's own caveat, adopted): the external reviewer inspected a ZIP
snapshot that may not contain the agent's latest scripts. Therefore no blind patching:
every finding gets a per-finding status report from the CURRENT files first.

---

## 1. FINDING TRIAGE

| # | External finding (severity) | Triage | Ruling |
|---|---|---|---|
| ER-F1 | Clip-28 pilot is a repair test, not a creative pilot (High) | ADOPT — matches the pilot verdict's own scope: pattern verified, editorial judgment not tested | XR-1 |
| ER-F2 | Production started during an audit-only phase (High) | ADOPT — quarantine + P3 already corrected output; the phase-permission model closes the cause | XR-2 |
| ER-F3 | QC can report PASS without required evidence (CRITICAL) | ADOPT IN FULL — fail-open code paths are honesty-layer violations | XR-3 |
| ER-F4 | Audio implementation reproducibility risks (High) | ADOPT IN FULL — includes a concrete FFmpeg semantics bug (`adelay=delays=3S`) | XR-4 |
| ER-F5 | "60→30 removes interpolation" not established (High) | ADOPT — claim language corrected, measurement stays | XR-5 |
| ER-F6 | Storage/evidence versions fragile (High) | ADOPT — extends FRT restore discipline to the full packet | XR-6 |
| ER-F7 | Current brief ≠ old defaults (5 s card compliant) | NO ACTION — already this campaign's standing position (P-V5: 5.000 s mandatory ≥4.5 s); changes require a brief amendment, never a quiet override | — |
| ER-C28 | Independent clip-28 re-check: measurements match architect's Task-15 values exactly (−14.0 LUFS, TP −6.7 dBTP, 568 frames, card 5.000 s ≈ 26% runtime); adds the ~13.7 s "NOW THAT WE'RE IN MY TERRITORY" caption boundary | ADOPT the added check; measurements stand as dual-verified | XR-7 |

Convergence note: the external tool guide and the PEB v3.2 registry were produced
independently and reached the same architecture — capability router instead of
mandatory renderers, detail loaded on demand, documented ≠ installed ≠ tested ≠
approved, fixture before adoption, one compositor per category, vendor skills are
technical guidance not authority, simplest sufficient path, explicit fallback. The
registry is bumped to v3.2.1 with their deltas (§5). Two independent reviews
converging is itself evidence the design is right.

---

## 2. RULINGS

### XR-1 — Pilot relabel (disposition, not rework)
- The clip-28 pilot is reclassified: `TECHNICAL_REPAIR_PILOT`. It proved assembly,
  card replacement, audio processing and output verification. It did not test hook
  selection, payoff boundaries, pacing, reframing or story construction.
- Record the disposition verbatim; never cite the pilot as evidence the editorial
  engine works. The pilot's technical PASS verdict stands (dual-verified).
- The existing 5 s card stays compliant (ER-F7); its retention effect remains a
  hypothesis for post-level analytics, not a defect.

### XR-2 — Phase-permission model (governance)
- The project record MUST carry a machine-readable phase field:
  `PHASE ∈ {AUDIT, PLAN, PILOT_PRIVATE, BATCH, PUBLISH}`.
- Each phase permits only its named actions. Out-of-phase actions = hard stop + ask.
- Standing (reaffirmed): an approval with unfilled brackets is not approval (R3-b);
  a pilot approval authorizes that pilot only, never automatic batch production
  (P3/R3-S lineage). A later explicit approval does not retro-authorize earlier
  out-of-phase work; it acknowledges and quarantines it.
- This is a ruling on the live run; the same model is queued for PEB core v3.2
  integration at next campaign start (no mid-run core edits — TEST FREEZE holds).

### XR-3 — QC fail-closed rewrite + negative fixtures (CRITICAL — blocks sub-batch B)
Step 1 — status report first (per the review's own stale-ZIP caveat). For each of the
four sub-findings, report from the CURRENT scripts with file+line evidence:
`STILL PRESENT / ALREADY FIXED / NOT APPLICABLE`:
  (a) language gate tests confidence but not `lang == "en"`; missing confidence passes;
  (b) loudness checks use passing defaults (`true_peak_dbtp or -9` pattern) — missing
      values AND the valid numeric value 0 are replaced by a passing default;
  (c) black/freeze event counts reported but not incorporated into combined status;
  (d) OCR at 2 s intervals treated as proof of English-only text throughout.
Step 2 — patch confirmed defects, fail-closed:
  - Explicit null/type checks. Missing or non-numeric required evidence =
    `NOT_CHECKED` or `REVIEW`, never PASS.
  - `0` is a valid measured value (0 dBTP is real and LOUD) — never a default.
  - Language gate requires the language field itself (`lang == "en"`), with
    confidence as a second condition; missing either = REVIEW.
  - Black/freeze events enter the combined status with classification:
    INTENTIONAL (declared, e.g. the card freeze) vs UNRESOLVED (= REVIEW).
Step 3 — negative fixture suite (canaries that MUST fail). Run and publish results:
  1. Deliberately non-English audio → language gate FAILS.
  2. Missing loudness/TP measurement → status NOT_CHECKED/REVIEW, never PASS.
  3. True-peak exactly 0 dBTP → treated as a real measurement, not a default.
  4. Short foreign burned-in text (OCR sampling miss) → REVIEW, not PASS.
  5. Intentional card freeze vs accidental freeze → classified differently.
Step 4 — publish the new gate count. The old 102/102 is retired: a check count is
only as strong as what the checks assert. The regression suite now includes canaries.

### XR-4 — Audio chain reproducibility (blocks sub-batch B)
(a) Two-pass loudnorm: pass 1 (measurement) and pass 2 (application) MUST use identical
    explicit targets (I=-14, TP=-1.5, LRA=pinned in profile) and identical preprocessing.
    Record from the loudnorm JSON whether normalization ran LINEAR or DYNAMIC per clip.
(b) `adelay=delays=3S` is 3 SAMPLES (~0.06 ms at 48 kHz), not 3 ms — FFmpeg's `S`
    suffix denotes samples. The intended look-ahead compensation did not occur as
    described. Architect correction on the record: my Task-15 acceptance of that
    mechanism is RETRACTED (the clip-28 output measurements stand; the mechanism
    explanation was not impulse-tested — that acceptance was my error).
(c) No guessed offsets replace it. Required: impulse fixture (click/identifiable event
    before the limiter → measure the actual output offset on the ENCODED file); check
    whether the installed alimiter supports latency compensation (`latency` option);
    compensate with the MEASURED constant; report the measured latency per chain.
(d) Chain is versioned as a unit (chain v2, SA-4 lineage); final encoded output is
    what gets measured and reported.

### XR-5 — Interpolation claim language
In all conform disclosures, QC tables and summaries, replace "60→30 removes/drops
interpolation" style claims with exactly:
  "No new interpolation applied; inherited interpolation not conclusively excluded."
Per-source drop accounting (mpdecimate counts, per-source measurement) stays — it is
cadence evidence, not frame-provenance evidence. Clean native sources remain preferred.

### XR-6 — Storage packet + restore drill
- Persist a versioned packet to a verified durable location: source inventory +
  SHA-256s, source-to-output edit decisions, exact scripts/configs, final-file hashes,
  approvals, QC statuses.
- Before sub-batch C: full restore drill — restore to a clean location, re-hash
  everything, spot-decode two files, report. A backup that has never been restored is
  a hypothesis, not a backup.
- Standing (adopted from the review): state access failures precisely — a connector's
  file-size limit does not prove every authorized route is impossible; use an approved
  alternative or request targeted files; no endless retries, no unauthorized bypasses.

### XR-7 — Out-point continuation check (extends SA-5)
- For every delivered and future clip: inspect the source + ASR a ±3 s window around
  each in/out cut point. A cut mid-sentence or mid-payoff = REVIEW, not PASS.
- Explicitly included: clip 28 — source caption "NOW THAT WE'RE IN MY TERRITORY" at
  ~13.7 s sits ~0.2 s before card entry at 13.933 s. Verify whether source speech
  continues past the cut and report. (This is a boundary review request, not a
  finding that a payoff was cut — the review itself marks it "worth reviewing".)

### XR-8 — Editorial pilot (gates sub-batch C)
- After B closes, render ONE editorial pilot before any scale-up:
  1. State the source-supported promise and payoff in two lines.
  2. Exact in/out boundaries with the XR-7 continuation check.
  3. What changed vs. the existing edit, and why (source-supported).
  4. Paper edit FIRST; rough cut before any decorative graphics.
  5. Human watch/listen passes before sub-batch C renders.
- Rationale: ER-F1 — the system has proven it can execute a pattern; it has not yet
  demonstrated it selects and edits better stories. That is the central objective.

---

## 3. UNLOCK STATE (updated)

- **Sub-batch B unlock** = SA-1…SA-5 closures + SA-6 (clip-23 upload for independent
  re-measurement) + **XR-3** (fail-closed QC + negative fixtures published) +
  **XR-4** (chain reproducibility evidence incl. impulse test).
- **Sub-batch C unlock** = B delivered + **XR-6** restore drill + **XR-8** editorial
  pilot passed human review.
- Release candidates remain blocked on: R4 (a)/(b) logo decision, typeface freeze,
  rights grant, clean-source access resolution (repairs to burned-in exports stay
  labeled as such — never presented as clean-source recuts).

## 4. WHAT THE EXTERNAL REVIEW GOT RIGHT / WHERE IT STANDS

- Right, and adopted: ER-F1…ER-F6, the clip-28 boundary check, "102/102 is only as
  strong as what the checks assert", the stale-ZIP caveat.
- Already our position (no action): the 5 s card is brief-compliant (ER-F7); pilot
  approval was explicit and is not described as unauthorized anywhere on file.
- Their disposition of clip-28 ("technically decodable private review draft; not
  proof the editorial engine works") is consistent with the Task-15 verdict and XR-1.

## 5. TOOLING DISPOSITION (summary — detail in the registry)

- `PEB_v3.2_MODULE_TOOL_REGISTRY.md` bumped to **v3.2.1**: four-state capability model
  (DOCUMENTED / INSTALLED / FEATURE-TESTED / APPROVED-FOR-PROJECT), T3 authority /
  audio-routing / determinism warnings, T4 version discipline, T5 license-snapshot
  caution, G3 live-re-read rule.
- No renderer installs in the agent's environment during the RexTrix run (registry
  §7 Campaign Freeze). New tools never touch a running pattern.
- Architect-side sandbox probing of T3 (HyperFrames) is approved and ready — fixture
  matrix, evidence artifacts, single-writer card consolidation; triggers on first
  motion-graphics need or explicit operator go.

## 6. PASTE-READY OPERATOR LINE

See the operator block issued with this file (chat). It is the authoritative relay
text; if it and this file ever disagree, this file governs.
