# REXTRIX — CLIENT PROFILE & CAMPAIGN RULES
# Purpose: attach this WITH the PRO EDITOR BRAIN v2 prompt when running MODE B
# (project execution) on a RexTrix clip. This is the "campaign rules" input
# required by §3 of the prompt. Fill the [TO CONFIRM] fields before first use.

## 1. CLIENT PROFILE
- Client: RexTrix — "AI-generated Games & Stories" (Clip Brand / Content Rewards campaign)
- Product world: AI-generated playable games + serialized AI dramas
- Logo file: [TO CONFIRM — attach transparent PNG, needed for the end-card gate]
- Fonts / colors: [TO CONFIRM — or let the module propose and you approve]
- Posting accounts: TikTok @rextrix_ai_studio · Instagram @rextrix_ai_info · X @RextrixAI · YouTube "RexTrix AI" · Facebook "RexTrix.AI"
- Primary platform: YouTube Shorts (also TikTok / IG Reels / X)
- Delivery: 1080 × 1920, 9:16, constant 30 fps, MP4 H.264 yuv420p + AAC 48 kHz
- Bio link (account-level, live from day 1): https://rextrix.onelink.me/nJbb/dbj5fov3

## 2. MANDATORY INCLUSIONS (every post — release-blocking)
- Caption mentions "RexTrix", ideally in the first 3–4 words
- Verbal or on-screen CTA in every video: tell viewers to click the link in bio
- Clear RexTrix connection in every video: app UI visible, real gameplay, verbal mention, or on-screen text
- End card, minimum 4 s: RexTrix LOGO GRAPHIC + wording "Download the app — link in bio"
  ⚠ Text-only wording like "Link in bio / to try RexTrix" was REJECTED by the reviewer
  (2026-10-23, Clip 16). The logo graphic + explicit "Download the app" wording is required.

## 3. BANNED CLAIMS (never display — same status as fabricated content)
- "every game free"
- "unlimited generations"
- "earn real money"
- Any invented feature or capability the app does not have
- Edited screenshots, fabricated analytics, manipulated engagement (fraud → removal)

## 4. RIGHTS & FOOTAGE
- Official RexTrix material only: the supplied assets Drive, or RexTrix's own socials
- No stock footage, no other games, no third-party content
- Audio: keep each asset's ORIGINAL audio. No external music or voiceover
  (campaign materials are silent on audio licensing — this is the safe fallback)
- Verify each asset's content and quality before building on it; a supplied asset
  is not automatically usable

## 5. LANGUAGE RULE
- English-only speech AND burned-in text
- Non-English segments: rebuild the moment around English screen content
  (app UI, prompt screens, score popups, App Store listing) and cut foreign-language
  speech/subtitles entirely
  ⚠ Clip 15 (1,195 views) was REJECTED for Arabic speech even with English paraphrase
  captions. English captions do NOT rescue non-English source speech.

## 6. POST-PUBLISH — OPERATOR CHECKLIST (you execute, not the module)
- [ ] Post publicly on the target platform
- [ ] Submit the post URL on the campaign page within 30 minutes of posting
      (the system rejects older posts)
- [ ] After 24 h: screen-record the post's analytics (views, reach, audience)
      and send it to the campaign support chat — review does not start without it
- [ ] Posting account must hold a 40%+ US audience
- [ ] Keep the post public through the campaign + review period
- [ ] Post at US prime time; seed the first hour with US viewers

## 7. APPROVED CLAIMS LEDGER (seed — extend only with evidence)
| claim_id | wording | status | allowed on-screen wording |
|----------|---------|--------|---------------------------|
| R-01 | "AI-generated games & stories" | approved (client positioning) | as stated |
| R-02 | "Type an idea → get a playable game" | approved IF real gameplay shown proving it | as stated |
| R-03 | Specific game/show titles (e.g., Live Paranormal: Sacred Heart Asylum, Panda BoBo, The Phoenix Throne, ZEROED, NULL ANGEL) | approved per asset | asset title only |
| R-04 | Pricing, generation limits, rewards | NOT verified | do not display |

## 8. CREATIVE NOTES (preferences, not requirements)
- Approved format menu (client): A can't-believe-AI-made-this · B gameplay challenge ·
  C story plot twists · D creation process · E POV reactions · F before/after
  (prompt vs result) · G trend riding
- Hook-first opening: strongest visual in first 3 s, one hook line max
- 15–25 s mini-arc (setup → escalation → payoff)
- Burned-in text kept in the top ~78% of frame
- Landscape sources: blurred-pad or QC-passed tracking crop only — never slice faces/text
