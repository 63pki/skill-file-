#!/usr/bin/env python3
"""P3 REGRESSION GUARDRAIL AUDIT — PRO EDITOR BRAIN v3
Verifies that v3 contains:
  A. All 6 v2.1 patches (P-V1..P-V6)
  B. All 5 compliance-spine restorations (R1..R5 from V3_REVIEW)
  C. All 7 defect fixes (D1..D7)
  D. All 11 user improvements preserved (keeper list)
  E. Rule-ID coverage for the 4 consult domains
  F. Size / token-economy metrics
Exits non-zero if any REQUIRED check fails.
"""
import re, sys, unicodedata

V3 = "/home/z/my-project/download/PRO_EDITOR_BRAIN_v3.md"
APP = "/home/z/my-project/download/PRO_EDITOR_BRAIN_v3_appendix.md"
text = open(V3, encoding="utf-8").read()
app = open(APP, encoding="utf-8").read()
full = text + "\n" + app
norm = unicodedata.normalize("NFKD", full)

def check(label, pattern, src=None, required=True, flags=re.I | re.S):
    body = src if src is not None else full
    ok = re.search(pattern, body, flags) is not None
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}")
    if not ok and required:
        failures.append(label)
    return ok

failures = []
print("=== A. v2.1 PATCHES (P-V1..P-V6) ===")
print("P-V1 end-card >= 4.5s floor (campaign min + 0.5s, measured on encoded file):")
check("floor rule present", r"minimum\s*PLUS\s*0\.5\s*s|minimum\s*plus\s*0\.5\s*s|at\s*least\s*that\s*minimum\s*\+\s*0\.5")
check("measured on encoded file, not timeline", r"measured\s+on\s+the\s+encoded\s+file,\s*not\s*the\s*timeline")
print("P-V2 instrumental language-gate path:")
check("instrumental path", r"instrumental — operator to confirm|instrumental.*operator to confirm")
check("never language-verified", r"never record it as language-verified")
print("P-V3 degraded-source disclosure:")
check("degraded source rule", r"degraded source.{0,80}delivery notes|record \"degraded source\"")
check("never upscale-and-silence", r"upscale-and-\s*silence")
print("P-V4 named-tool loudness measurement:")
check("ebur128 named", r"ebur128")
check("1.5 LU re-normalization", r"1\.5\s*LU[\s\S]{0,80}re-normali[sz]ed")
print("P-V5 source-baked defects policy:")
check("source-baked report-never-correct", r"Source-baked\s+defects[\s\S]{0,160}never\s+silently\s+corrected")
check("never counted against grade", r"never\s+counted\s+against\s+the\s+deliverable")
print("P-V6 QC claims name reproducing command:")
check("unstated method = not checked", r"names the tool and command|without a stated method is recorded")
check("reproduce the result", r"reproduce the result|independently reviewer can reproduce|independent reviewer can reproduce")

print("=== B. COMPLIANCE SPINE RESTORED (R1..R5) ===")
print("R1 language gate:")
check("spoken AND burned-in", r"spoken language AND (all )?burned-in text")
check("pre-selection check recorded", r"pre-selection check")
print("R2 campaign compliance block:")
check("banned claims scan", r"[Bb]anned claims and prohibited content|banned list")
check("end-card spec logo+action", r"brand\s+logo\s+graphic\s+AND\s*\n?\s*wording\s+that\s+instructs")
check("mandatory inclusions", r"[Mm]andatory inclusions")
print("R3 end-card verification floor:")
check("floor in §15", r"minimum PLUS 0\.5 s|minimum plus 0\.5 s")
print("R4 v2.1 QC lessons:")
check("named-tool + command + degraded + baked (4 markers above)", r"ebur128")  # covered by A; presence marker
print("R5 operator checklist:")
check("operator checklist emission", r"operator_checklist\.md|operator checklist covering the campaign's post-publish")
check("30-min/24h style duties named", r"24-hour analytics capture")

print("=== C. DEFECT FIXES (D1..D7) ===")
check("D1 numbered sections 1..21", r"^21\. REQUIRED RESPONSE", text, flags=re.M | re.I)
refs = [int(m) for m in re.findall(r"§(\d+)", text)]
missing = sorted({n for n in refs if not re.search(r"^%d\. " % n, text, re.M)})
print(f"  [{'PASS' if not missing else 'FAIL'}] D1 every section cross-reference resolves (refs up to §{max(refs)}; unresolved: {missing or 'none'})")
if missing:
    failures.append("D1 cross-refs resolve")
check("D2 presets are Module Build reference impls", r"Module Build reference implementations only")
check("D3 hook channels from source evidence", r"campaign-profile requirement executed honestly from\s+source evidence|channel coverage is a campaign-profile requirement")
check("D4 load discipline present", r"LOAD DISCIPLINE")
check("D4 load-on-demand markers", r"\[LOAD ON DEMAND", text)
check("D5 capability matrix seeded from observed reality", r"Seed the capability matrix from observed project reality|seeded from observed")
check("D5 sandbox constraint encoded", r"OOM-style|kills them")
check("D6 viral objective as mechanics", r"engineered\s+for\s+viewer\s+attention\s*\n?\s*through\s+mechanics|design\s+for\s+hook\s+strength,\s+payoff\s+delivery,\s+rewatch")
check("D6 never claim outcomes", r"[Nn]ever claim, promise, predict, or imply viral outcomes")
check("D7 batch pattern pre-approval", r"pre-approve a batch pattern")

print("=== D. 11 USER IMPROVEMENTS PRESERVED ===")
check("1 mode semantics (missing media != Module Build)", r"Missing\s+or\s+blocked\s+media\s+does\s+not\s+switch\s+the\s+task\s+to\s+Module\s+Build")
check("2 single-brief intake register", r"link/source register")
check("3 Mode B scope diet", r"full\s+reusable\s*\n?\s*package\s+only\s+in\s+Module\s+Build|require\s+the\s+full\s+reusable\s*\n?\s*package\s+only\s+in\s+Module\s+Build")
check("4 risk-proportionate claims", r"do not require a named human approver")
check("5 source handling (no interpolation default)", r"Avoid synthetic frame interpolation by default")
check("6 pilot gate", r"PILOT GATE")
check("7 platform-safety honesty", r"sampled\s+composite\s+check\s+is\s+not\s+an\s+in-app\s*\n?\s*safe-area\s+check")
check("8 math contract (Bezier warning)", r"Do\s+not\s+substitute\s+u\s+directly\s+into\s+By|never\s+substitute\s+time\s+directly\s+into\s*\n?\s*By|solve\s+Bx\(u\)=t\s+then\s+evaluate\s+By")
check("9 ending/CTA section + no universal hold", r"No universal hold time is assumed")
check("10 token economics", r"Do not let paperwork consume the editing budget")
check("11 portability (BOXABL illustrative)", r"BOXABL,\s+room\s+tours,\s*\n?\s*and\s+product\s+specifications\s+below\s+are\s+illustrative")

print("=== E. CONSULT RULE-ID COVERAGE (v3 domains) ===")
for prefix, minimum in [("SIG",6),("RHY",6),("CUT",5),("TELL",2),("EMO",3),("FS-",3),
                        ("MG-",14),("DES-",4),
                        ("KF-",6),("STAB-",5),("BG-",7),("COMP-",4),
                        ("SYNC-",3),("ENC-",1),
                        ("CAMP-",4),("PREC-",2),("MOM-",3),("SPN-",1),("HOOK-",6),("TEAS-",5),
                        ("VAR-",7),("RND-",6),("GOV-",5),
                        ("FAIL-",3),("ENV-",1),("RUB",1)]:
    n = len(re.findall(r"\[" + prefix.replace("-","\\-") + r"[\d\.\-]*\]", text))
    check(f"{prefix} rules ≥{minimum} (found {n})", None if n >= minimum else "x") if False else print(f"  [{'PASS' if n >= minimum else 'FAIL'}] {prefix}: {n} tagged (need ≥{minimum})")
    if n < minimum: failures.append(f"{prefix} coverage")

print("=== F. SIZE / TOKEN ECONOMY ===")
chars_m = len(text); chars_a = len(app)
standing = len(re.sub(r"^10\. MOTION.*?(?=14\. CAPTIONS)", "", text, flags=re.S | re.M))
print(f"  master: {chars_m:,} chars | appendix: {chars_a:,} chars | standing (excl. §10–13): {standing:,} chars")
print(f"  user rewrite was 47,682 chars; v2.1 was 42,376; roadmap target ≤55k (set before 14 responses arrived)")

print()
if failures:
    print(f"RESULT: {len(failures)} FAILURE(S):")
    for f_ in failures: print("  -", f_)
    sys.exit(1)
print("RESULT: ALL CHECKS PASS")
