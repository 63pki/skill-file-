#!/usr/bin/env python3
"""Task 1 verification: parse the verbatim operator handoff, verify expected counts
(60 repos / 20 shortlist / 26 conditional links), cross-check link-to-repo membership,
hash everything, and emit: 3 separate list files (operator's filenames), a normalized
inventory, and a receipt. Parsing only — no network, no modification of the verbatim file."""
import hashlib, pathlib, re, json, datetime

D = pathlib.Path("/home/z/my-project/download/OPERATOR_INPUT_2026-10-28")
VERBATIM = D / "CONSOLIDATED_HANDOFF_VERBATIM.md"
text = VERBATIM.read_text(encoding="utf-8")

# --- section split (operator's own headers) ---
def section(header):
    m = re.search(rf"## {re.escape(header)}\n(.*?)(?=\n## |\nBottom line:)", text, re.S)
    return m.group(1) if m else ""

url_re = re.compile(r"https://github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)(?:/(?:blob|tree)/([^/\s]+))?(?:/([^\s]+))?")

def parse_urls(block):
    out = []
    for line in block.splitlines():
        line = line.strip()
        if line.startswith("https://github.com/"):
            m = url_re.match(line)
            owner, repo, ref, path = m.group(1), m.group(2), m.group(3), m.group(4)
            out.append({"url": line, "owner": owner, "repo": repo,
                        "ref": ref or "", "path": ("/" + path) if path else "/"})
    return out

shortlist = parse_urls(section("2. SHORTLIST_DIRECT_SKILL_LINKS.txt"))
conditional = parse_urls(section("3. CONDITIONAL_DIRECT_SKILL_LINKS.txt"))
repos = parse_urls(section("4. ALL_REPOSITORIES_DEDUPLICATED.txt"))

report = {"counts": {"shortlist": len(shortlist), "conditional": len(conditional), "repos": len(repos)}}

# --- uniqueness ---
for name, lst in [("shortlist", shortlist), ("conditional", conditional), ("repos", repos)]:
    urls = [e["url"] for e in lst]
    dupes = sorted({u for u in urls if urls.count(u) > 1})
    report[f"{name}_unique_urls"] = len(set(urls)) == len(urls)
    report[f"{name}_duplicates"] = dupes
repo_keys = [f"{e['owner']}/{e['repo']}" for e in repos]
dupes_r = sorted({r for r in repo_keys if repo_keys.count(r) > 1})
report["repos_unique_owner_repo"] = len(set(repo_keys)) == len(repo_keys)
report["repos_duplicate_owner_repo"] = dupes_r

# --- cross-checks: every link repo in the 60; which repos have no link ---
link_repos = {}
for lname, lst in [("shortlist", shortlist), ("conditional", conditional)]:
    for e in lst:
        link_repos.setdefault(f"{e['owner']}/{e['repo']}", []).append(lname)
report["links_not_in_repo_inventory"] = sorted(set(link_repos) - set(repo_keys))
report["repos_with_direct_links"] = len(link_repos)
report["repos_without_direct_links"] = sorted(set(repo_keys) - set(link_repos))
report["links_per_repo"] = {k: len(v) for k, v in sorted(link_repos.items()) if len(v) > 1}

# --- format checks ---
bad = [e["url"] for e in repos if not re.fullmatch(r"https://github\.com/[^/\s]+/[^/\s]+", e["url"])]
report["repo_urls_non_root_format"] = bad
report["all_shortlist_are_skill_paths"] = all(e["path"].endswith("/SKILL.md") for e in shortlist)
report["all_conditional_are_skill_paths"] = all(e["path"].endswith("/SKILL.md") for e in conditional)

# --- six previously-missing candidates present? ---
six = ["Leonxlnx/cinetic", "AbubakrChan/product-launch-motion", "nilbuild/video-demo",
       "1weiho/cinematic-shot", "barty-bart/motion-graphics", "nexu-io/open-design"]
report["six_named_in_60"] = {s: (s in set(repo_keys)) for s in six}

# --- write the 3 separate list files (verbatim URL lines, operator filenames) ---
for fname, lst in [("SHORTLIST_DIRECT_SKILL_LINKS.txt", shortlist),
                   ("CONDITIONAL_DIRECT_SKILL_LINKS.txt", conditional),
                   ("ALL_REPOSITORIES_DEDUPLICATED.txt", repos)]:
    (D / fname).write_text("\n".join(e["url"] for e in lst) + "\n", encoding="utf-8")

# --- hashes ---
def sha_file(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
files = ["CONSOLIDATED_HANDOFF_VERBATIM.md", "SHORTLIST_DIRECT_SKILL_LINKS.txt",
         "CONDITIONAL_DIRECT_SKILL_LINKS.txt", "ALL_REPOSITORIES_DEDUPLICATED.txt"]
hashes = {f: {"sha256": sha_file(D / f), "bytes": (D / f).stat().st_size} for f in files}

# --- normalized inventory ---
lines = [
"# NORMALIZED INVENTORY — operator resupply (parsed view; the verbatim original is untouched)",
"",
"Source: CONSOLIDATED_HANDOFF_VERBATIM.md (same directory). Parsed " + datetime.date.today().isoformat() + ".",
"",
"## Reconstructed usage-category table (flattened in transit; reconstructed from the verbatim string)",
"",
"| Category | How the agent should use it |",
"|---|---|",
"| Editing workflow skill | Guide source inspection, story selection, timeline decisions and revisions |",
"| Motion/design specialist | Solve a selected visual communication problem |",
"| Technical renderer skill | Implement compositions, timing, captions and exports |",
"| App-dependent skill | Use only when that application's actual tools are available |",
"| Analysis/transcript support | Assist understanding—not substitute for audiovisual review |",
"| Library/dependency | Supply technical capabilities through a tested adapter |",
"| Starter/reference project | Study implementation; do not present it as an installed skill |",
"| Hosted/generated-media workflow | Require provider, privacy, cost and campaign authorization |",
"",
"## A. Repository inventory (60)",
"",
"| # | owner/repo | direct links |",
"|---|---|---|"]
for i, e in enumerate(repos, 1):
    key = f"{e['owner']}/{e['repo']}"
    lines.append(f"| {i} | {key} | {len(link_repos.get(key, [])) or '—'} |")
lines += ["", "## B. Shortlist direct skill links (20)", "", "| # | owner/repo | ref | path |", "|---|---|---|---|"]
for i, e in enumerate(shortlist, 1):
    lines.append(f"| {i} | {e['owner']}/{e['repo']} | {e['ref']} | {e['path']} |")
lines += ["", "## C. Conditional direct skill links (26)", "", "| # | owner/repo | ref | path |", "|---|---|---|---|"]
for i, e in enumerate(conditional, 1):
    lines.append(f"| {i} | {e['owner']}/{e['repo']} | {e['ref']} | {e['path']} |")
(D / "NORMALIZED_INVENTORY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

# --- receipt ---
rc = ["# RECEIPT — operator input persistence verification", "",
"Verbatim source: CONSOLIDATED_HANDOFF_VERBATIM.md (supplied in-message by operator, 2026-10-28).",
"Persistence failure of the original in-session delivery acknowledged as process defect (not operator omission).",
"", "## Files on disk (verified readable, hashed at save time)", "",
"| File | Bytes | SHA-256 |", "|---|---|---|"]
for f in files:
    rc.append(f"| {f} | {hashes[f]['bytes']} | {hashes[f]['sha256']} |")
rc += ["", "## Count verification", "",
f"- Shortlist links parsed: **{len(shortlist)}** (expected 20)",
f"- Conditional links parsed: **{len(conditional)}** (expected 26)",
f"- Repository URLs parsed: **{len(repos)}** (expected 60)",
f"- Repositories unique (owner/repo): **{report['repos_unique_owner_repo']}**" + (f" — duplicates: {dupes_r}" if dupes_r else ""),
f"- Shortlist URLs unique: **{report['shortlist_unique_urls']}**; Conditional URLs unique: **{report['conditional_unique_urls']}**",
f"- All shortlist paths end in /SKILL.md: **{report['all_shortlist_are_skill_paths']}**; conditional: **{report['all_conditional_are_skill_paths']}**",
f"- Link repos missing from the 60-repo inventory: **{report['links_not_in_repo_inventory'] or 'none'}**",
f"- Repos carrying direct links: **{report['repos_with_direct_links']}** of 60; without: {len(report['repos_without_direct_links'])} (listed in reconciliation report)",
f"- Six previously-missing candidates present in the 60: **{all(report['six_named_in_60'].values())}**",
"", "## Parsing problems / transit artifacts", "",
"1. Verdict-section category table arrived flattened to a single string (markdown table lost in transit).",
"   Preserved as-is in the verbatim file; reconstructed in NORMALIZED_INVENTORY.md §table.",
"2. Stray zero-width/formatting characters present in the message were not reproducible byte-for-byte;",
"   the saved file is a faithful readable transcription. Counts and URLs are unaffected.",
"3. Audit self-description: '58 unique repositories from your links, plus two follow-up sources' — which",
"   two of the 60 came from follow-up sources is not identifiable from the supply; immaterial to coverage.",
"4. Onetake intentionally absent from both adoption lists (its own note) but present in the 60 — consistent.",
"", "## Cross-reference note", "",
"The audit's 'Duplicate resolution' list describes dedups already applied upstream; this parse found no",
"residual duplicate URLs within any list (see uniqueness flags above).",
]
(D / "RECEIPT.md").write_text("\n".join(rc) + "\n", encoding="utf-8")

print(json.dumps({k: v for k, v in report.items() if k != "links_per_repo"}, indent=1))
print("\nLINKS PER REPO >1:", json.dumps(report["links_per_repo"]))
