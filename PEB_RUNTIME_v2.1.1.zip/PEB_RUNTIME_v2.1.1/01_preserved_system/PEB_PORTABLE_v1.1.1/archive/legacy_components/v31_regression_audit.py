#!/usr/bin/env python3
"""v3.1/v3.1.1 regression audit: compliance spine, tier taxonomy, review fixes, technical fixes,
forbidden patterns, cross-file references, and the five v3.1.1 corrections (C1-C5).
Re-run after any future v3.1.x edit. A shipped copy lives in download/ so results are reproducible
outside this workspace. SCOPE: document-level checks only — this proves wording/tier/reference
integrity, not edit quality, footage selection, or audience performance."""
import re, sys, os

BASE = "/home/z/my-project/download"
CORE = os.path.join(BASE, "PRO_EDITOR_BRAIN_v3.1_CORE.md")
GFX  = os.path.join(BASE, "PEB_v3.1_MODULE_GRAPHICS.md")
MOT  = os.path.join(BASE, "PEB_v3.1_MODULE_MOTION_PIPELINES.md")
APP  = os.path.join(BASE, "PEB_v3.1_APPENDIX_REFERENCE.md")

files = {p: open(p, encoding="utf-8").read() for p in (CORE, GFX, MOT, APP) if os.path.exists(p)}
ALL = "\n".join(files.values())
CORE_TXT = files.get(CORE, "")
GFX_TXT = files.get(GFX, "")
APP_TXT = files.get(APP, "")

results, failures = [], []
def check(name, cond, detail=""):
    results.append((name, cond, detail))
    if not cond: failures.append(name)

# ---------- A. Compliance spine restored in CORE ----------
spine = [
    ("R1 language gate mechanism (spoken + burned-in)", r"verify the spoken language AND all burned-in text", CORE_TXT),
    ("R1 instrumental path (P-V2)", r"instrumental \u2014 operator to confirm any vocals|language: instrumental", CORE_TXT),
    ("R2 mandatory inclusions gate", r"Mandatory inclusions: every profile-required inclusion", CORE_TXT),
    ("R3 end-card verification gate", r"End-card verification: verify the rendered end card against the profile", CORE_TXT),
    ("R3 banned claims gate", r"Banned claims and prohibited content", CORE_TXT),
    ("R4 rights compliance", r"Rights compliance: only authorized source material", CORE_TXT),
    ("R5 operator checklist duty", r"operator checklist covering the profile", CORE_TXT),
    ("P-V4 named-tool loudness + 1.5LU re-norm", r"named tool and command \(e\.g\., ffmpeg ebur128\)[\s\S]{0,200}re-normalized", CORE_TXT),
    ("P-V6 QC reproduction commands", r"Every QC pass/fail claim in the delivery\s*\nnames the tool and command|names the tool and command that produced it", CORE_TXT),
    ("P-V3 degraded source disclosure", r"degraded source\", in delivery notes|record\s*\"degraded source\"", CORE_TXT),
]
for name, pat, txt in spine:
    check(name, re.search(pat, txt) is not None, pat)

# ---------- B. Tier taxonomy present ----------
for name, pat in [
    ("Tier 0 LAWS defined", r"TIER 0 — LAWS \[T0\]"),
    ("Tier 1 CAMPAIGN PROFILE defined", r"TIER 1 — CAMPAIGN PROFILE \[T1\]"),
    ("Tier 2 CRAFT DEFAULTS defined", r"TIER 2 — CRAFT DEFAULTS \[T2\]"),
    ("Tier 3 DIAGNOSTICS defined", r"TIER 3 — DIAGNOSTICS \[T3\]"),
    ("Diagnostics = uncalibrated priors", r"UNCALIBRATED PRIORS"),
    ("Tier labels used throughout", len(re.findall(r"\[T0\]|\[T1\]|\[T2\]|\[T3\]", ALL)) >= 25),
    ("Diagnostics never block alone", r"never (release-)?blocking on their own|never blocks? release"),
]:
    if isinstance(pat, str):
        check(name, re.search(pat, ALL) is not None, pat)
    else:
        check(name, bool(pat), "count check")

# ---------- C. Review regression fixes (3.1-3.8) ----------
fixes = [
    ("3.1 no hard 3xASL gate (guarded by N>=4, diagnostic only)",
     r"skipped entirely for pieces\s*with fewer than 4 shots|statistics are meaningless below that"),
    ("3.1 CV bands demoted to priors", r"CV bands \(appendix §C\) are calibrated priors"),
    ("3.2 structure menu equally available", r"EQUALLY\s*\nAVAILABLE|EQUALLY AVAILABLE"),
    ("3.2 payoff window is diagnostic, never blocks", r"never blocks a structure chosen for evidence-based reasons"),
    ("3.3 missing unnecessary channel not a weakness", r"missing unnecessary channel is NOT a\s*weakness|a missing unnecessary channel is NOT a weakness"),
    ("3.3 channels scored only when used", r"channels not used are marked \"not used\" and\s*excluded|marked \"not used\" and\s*excluded"),
    ("3.4 moment score ranks, does not gate", r"score RANKS candidates for review and selection; it is a Tier 3 diagnostic"),
    ("3.4 hook rubric does not gate release", r"The rubric organizes rework and review; it does not gate release"),
    ("3.4 taste rubric is diagnostic", r"Taste rubric \(story clarity 25[\s\S]{0,120}\) is a Tier 3 diagnostic"),
    ("3.5 end-card margin is profile policy with rationale", r"margin_seconds: 0\.5, margin_rationale"),
    ("3.5 margin not a substitute for exact measurement", r"never a substitute for exact\s*measurement|never a substitute for exact measurement"),
    ("3.6 environment probe replaces permanent truth", r"ENVIRONMENT PROBE \[ENV-2\]"),
    ("3.6 no 'applies everywhere' claim", None),  # negative check below
    ("3.6 partial integrity disclosure wording", r"partial integrity inspection; full decode not checked"),
    ("3.7 minimal evidence floor vs full stack", r"Minimal evidence floor \[T0 — required before any cut decision\]"),
    ("3.7 unknown intent no longer stops the edit", r"UNKNOWN\s*\nINTENT DOES NOT STOP THE EDIT|UNKNOWN INTENT DOES NOT STOP THE EDIT"),
    ("3.7 graphics route to simpler treatment or review draft", r"routes to: \(i\) a simpler treatment that\s*omits that token, or \(ii\) a REVIEW draft|routes to: \(i\) a simpler treatment"),
    ("3.8 inherited defects: origin != acceptability", r"Origin and\s*acceptability are recorded separately|origin != severity != acceptability|Origin and acceptability are recorded separately"),
    ("3.8 compliance-relevant inherited still gates", r"still gates the SOURCE SEGMENT"),
]
for name, pat in fixes:
    if pat is None: continue
    check(name, re.search(pat, ALL) is not None, pat)

# ---------- D. Technical fixes T1-T6 ----------
tech = [
    ("T1 word edges never hard anchors", r"ASR word edges are NEVER hard anchors"),
    ("T1 hard anchor = visual/musical verified", r"machine-verified VISUAL or\s*MUSICAL event|machine-verified VISUAL or MUSICAL event"),
    ("T2 visual keys frames / audio keys samples", r"AUDIO keys \(volume,\s*pan\) resolve to SAMPLE indices|AUDIO keys resolve to SAMPLE indices"),
    ("T2 cumulative sample rounding (no per-segment mult)", r"computed cumulatively — never per-frame multiplication except when\s*48000/F is an integer|computed cumulatively"),
    ("T3 linear gain domain", r"volume automation is stored and interpolated as LINEAR\s*gain|stored and interpolated as LINEAR gain"),
    ("T3 dB conversion documented", r"linear = 10\^\(dB/20\)"),
    ("T4 total samples rounded once from duration", r"exactly round\(total_duration × 48000\) samples|round\(total_duration × 48000\)"),
    ("T5 explicit transfer conversion, no silent relabel", r"including\s+an\s+explicit\s+transfer-function\s+conversion|INCLUDING\s+an\s+explicit\s+transfer-function\s+conversion"),
    ("T5 sRGB relabel forbidden", r"silently\s+tagging\s+sRGB\s+output\s+as\s+bt709\s+is\s+forbidden"),
    ("T6 recipe A overshoot exception documented", r"DOCUMENTED\s*EXCEPTION to the (graphics module's )?1\.03 overshoot cap|DOCUMENTED EXCEPTION"),
    ("B1 unified setup band", r"setup ≤30% of runtime with a logged-deviation ceiling at 35%"),
    ("B4 stats guard N>=4", r"pieces with ≥4 shots|≥4 shots"),
    ("B2 appendix fragment gone (no stray '[frame_N rendered?')", None),  # negative below
]
for name, pat in tech:
    if pat is None: continue
    check(name, re.search(pat, ALL) is not None, pat)

# ---------- E. Freedom Regression Test ----------
check("FRT present", re.search(r"FREEDOM REGRESSION TEST", CORE_TXT) is not None)
for kw in ["uninterrupted slow reveal", "wordless visual moment", "dialogue joke with minimal graphics"]:
    check(f"FRT counterexample: {kw}", kw in CORE_TXT)
check("FRT binds future rule changes", re.search(r"Every proposed rule change additionally passes the FRT|passes the FRT", CORE_TXT) is not None)

# ---------- F. Forbidden patterns (v3 wording that must NOT survive) ----------
negatives = [
    ("applies everywhere (removed)", r"applies everywhere"),
    ("old P-V5 blanket exemption (removed)", r"never counted\s*\nagainst the deliverable's QC grade|never counted against the deliverable's QC grade"),
    ("CV 'fails the cut' as hard gate (removed)", r"CV < 0\.25 fails the cut"),
    ("'stop for a human' on unknown intent (removed)", r"unknown intent → stop for a human|unknown intent → stop"),
    ("stray appendix fragment (removed)", r"frame_N rendered\? no"),
    ("unscoped blocking payoff boolean (removed)", r"pct_in_window \(payoff completes"),
    ("three-channel universal requirement in schema (removed)", r"required_channels: \[visual, audio, text\]"),
    ("real_peak_first as schema default (removed from schema)", r"owner_mandates: \{[^}]*real_peak_first"),
    ("dB domain for gain (removed)", r"dB domain for gain"),
    ("normalize EVERY key time to frames (removed)", r"normalize every key time to an integer output frame"),
    ("known-bad as permanent law (reworded)", r"known-bad are long-running"),
]
for name, pat in negatives:
    check(name, re.search(pat, ALL, re.IGNORECASE if "known-bad" in pat else 0) is None, pat)

# ---------- G. Cross-file references ----------
for ref, target in [("PRO_EDITOR_BRAIN_v3.1_CORE.md", CORE),
                    ("PEB_v3.1_MODULE_GRAPHICS.md", GFX),
                    ("PEB_v3.1_MODULE_MOTION_PIPELINES.md", MOT),
                    ("PEB_v3.1_APPENDIX_REFERENCE.md", APP)]:
    if ref == "PRO_EDITOR_BRAIN_v3.1_CORE.md":
        continue  # core is referenced by others, not by itself
    check(f"reference to {ref} resolves", ref in ALL and os.path.exists(target))
# appendix sections referenced by core must exist in appendix
for sec in ["§A", "§B", "§C", "§D", "§J" ]:
    pass  # core references appendix by letter names A-D; appendix uses A/B/C/D/E/F/G/H
for sec_name in ["CAMPAIGN PROFILE CONTRACT", "SIGNAL SIDECAR", "RHYTHM REFERENCE TABLES",
                 "FEEL SPEC SCHEMA", "FRAME-TRUTH FIXTURE", "FAILURE DISCLOSURE TEMPLATES"]:
    check(f"appendix section present: {sec_name}", sec_name in files.get(APP, ""))
check("graphics module self-contained (taxonomy table inline)", "Preferred placement" in files.get(GFX, ""))
check("graphics module self-contained (choreography table inline)", "Min readable hold" in files.get(GFX, ""))
check("graphics module self-contained (archetype library inline)", "A01 Editorial margin headline" in files.get(GFX, ""))

# ---------- H. Section numbering sanity in CORE ----------
core_secs = re.findall(r"^(\d{1,2})\. [A-Z][A-Z0-9 ,&'’\-—:()\.\/]*$", CORE_TXT, re.M)
nums = [int(x) for x in core_secs]
check("CORE sections 1..18 in order", nums == list(range(1, 19)), f"found {nums}")

# ---------- I. v3.1.1 corrections C1-C5 ----------
check("C1 FRT scope guard present", "NEVER overrides verified mandatory campaign requirements" in CORE_TXT)
check("C1 old FRT override clause removed", re.search(r"Any rule that obstructs without protecting", CORE_TXT) is None)
check("C1 FRT unavailable-for-campaign path", "unavailable-for-this-campaign" in CORE_TXT)
check("C2 Tier1 MANDATORY class defined", re.search(r"A MANDATORY\s+entry", CORE_TXT) is not None)
check("C2 Tier1 PREFERENCE class defined", re.search(r"A PREFERENCE\s+entry", CORE_TXT) is not None)
check("C2 logged reason ≠ permission", "never authorizes noncompliance" in CORE_TXT)
check("C2 mandatory block-and-escalate", re.search(r"blocked and escalated to the operator for an\s+authorized amendment", CORE_TXT) is not None)
check("C2 PREC-2 mandatory override ban", "can never override Tier 0 or a Tier 1 MANDATORY value" in CORE_TXT)
check("C2 old Tier1 attempt-first flattening removed", "Executed attempt-first;" not in CORE_TXT)
check("C2 schema class field", "class: mandatory|preference" in APP_TXT)
check("C2 schema deviation note", "never authorizes" in APP_TXT)
check("C3 appendix A.1 inactive header", "INACTIVE until reconciled with the supplied brief" in APP_TXT)
check("C3 activation rule present", "Activation rule: at intake, reconcile every value" in APP_TXT)
check("C3 unconfirmed mandates rule", "UNCONFIRMED until source-verified" in APP_TXT)
check("C3 core §3 anchor", "Example profiles shipped with this prompt (appendix §A.1) are" in CORE_TXT)
check("C3 old attribution wording removed", "owner_mandates (from the RexTrix owner)" not in APP_TXT)
check("C4 four-quantity contract", re.search(r"primaries,\s+encoding\s+transfer,\s+display\s+assumption,\s+(and\s+)?range", CORE_TXT) is not None)
check("C4 conflation wording removed", re.search(r"BT\.709 transfer \(γ 2\.4\)", ALL) is None)
check("C4 OETF formula named", "1.099·L^0.45" in CORE_TXT)
check("C4 BT.1886 named as display assumption", "BT.1886 reference" in CORE_TXT)
check("C4 conversion fixture present", re.search(r"assert round-trip\s+error ≤1 code value", CORE_TXT) is not None)
check("C4 graphics module sync", "display gamma such as BT.1886" in GFX_TXT)
check("C4 appendix encode-pattern sync", "BT.709-OETF" in APP_TXT)
check("C5 payoff boolean renamed", "answer_delivered_complete" in CORE_TXT)
check("C5 old uncut boolean removed", re.search(r"answer_delivered_uncut|delivered uncut", CORE_TXT) is None)
check("C5 meaning-preservation clause", "preserve meaning, necessary" in CORE_TXT)

# ---------- Report ----------
passed = sum(1 for _, ok, _ in results if ok)
total = len(results)
width = max(len(n) for n, _, _ in results)
for n, ok, d in results:
    print(f"{'PASS' if ok else 'FAIL'}  {n.ljust(width)}  {d if not ok else ''}")
print(f"\n{passed}/{total} checks pass")
sys.exit(0 if not failures else 1)
