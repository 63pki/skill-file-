#!/bin/bash
# Transcribe all RexTrix clips with rate-limit-friendly spacing
set -u
OUT=/home/z/my-project/rextrix_review/transcripts
LOG=/home/z/my-project/rextrix_review/transcripts/asr_log.txt
mkdir -p "$OUT"
: > "$LOG"
for f in /home/z/my-project/rextrix_review/audio/RexTrix_Clip_*.wav; do
  base=$(basename "$f" .wav)
  if [ -s "$OUT/${base}.json" ]; then
    echo "$base: already done" >> "$LOG"
    continue
  fi
  ok=0
  for attempt in 1 2 3; do
    if timeout 110 z-ai asr -f "$f" -o "$OUT/${base}.json" >> "$LOG" 2>&1; then
      if [ -s "$OUT/${base}.json" ]; then
        echo "$base: OK (attempt $attempt)" >> "$LOG"
        ok=1
        break
      fi
    fi
    echo "$base: attempt $attempt failed, sleeping 30s" >> "$LOG"
    sleep 30
  done
  [ $ok -eq 0 ] && echo "$base: FAILED after 3 attempts" >> "$LOG"
  sleep 15
done
echo "ASR_ALL_DONE" >> "$LOG"
