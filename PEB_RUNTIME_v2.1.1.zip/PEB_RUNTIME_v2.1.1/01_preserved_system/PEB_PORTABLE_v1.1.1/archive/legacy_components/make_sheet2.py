#!/usr/bin/env python3
"""Contact sheets for boundary frames: 17.5 / 18.0 / 21.9 per clip, one row per clip."""
import os
from PIL import Image, ImageDraw, ImageFont

FR = "/home/z/my-project/rextrix_review/frames2"
OUT = "/home/z/my-project/rextrix_review/sheets"
TS = ["17.5", "18.0", "21.9"]
clips = sorted(set(f.rsplit("_t", 1)[0] for f in os.listdir(FR) if f.endswith(".jpg")))

try:
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16)
except Exception:
    font = ImageFont.load_default()

W, H, LBL = 360, 640, 26
sheet = Image.new("RGB", (W * 3 + 8, (H + LBL) * len(clips) + 4), (30, 30, 30))
d = ImageDraw.Draw(sheet)
for r, clip in enumerate(clips):
    num = clip.split("_")[2]
    for c, t in enumerate(TS):
        p = os.path.join(FR, f"{clip}_t{t}.jpg")
        x = c * (W + 4)
        y = r * (H + LBL + 1)
        d.text((x + 6, y + 4), f"Clip {num}  t={t}s", fill=(255, 255, 100), font=font)
        if os.path.exists(p):
            im = Image.open(p).convert("RGB")
            if im.size != (W, H):
                im = im.resize((W, H))
            sheet.paste(im, (x, y + LBL))
        else:
            d.rectangle([x, y + LBL, x + W, y + LBL + H], fill=(90, 0, 0))
outp = os.path.join(OUT, "sheet_boundaries.jpg")
sheet.save(outp, quality=85)
print(outp, sheet.size)
