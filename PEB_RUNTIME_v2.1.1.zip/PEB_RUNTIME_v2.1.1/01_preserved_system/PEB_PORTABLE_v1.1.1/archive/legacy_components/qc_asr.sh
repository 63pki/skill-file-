#!/bin/bash
# Extract 0-17.5s source-arc audio (16kHz mono wav) and transcribe each clip
cd /home/z/my-project/rextrix_review/clips
mkdir -p ../audio ../transcripts
for f in RexTrix_Clip_*.mp4; do
  base="${f%.mp4}"
  n=$(echo "$base" | rg -o "Clip_([0-9]+)" -r '$1')
  ffmpeg -v error -i "$f" -t 17.5 -vn -ac 1 -ar 16000 -y "../audio/${n}.wav"
done
echo "--- extraction done ---"
ls ../audio/
for w in ../audio/*.wav; do
  n=$(basename "$w" .wav)
  echo "=== TRANSCRIBING ${n} ==="
  z-ai asr -f "$w" -o "../transcripts/${n}.json" 2>&1 | tail -2
done
echo "--- all done ---"
