#!/usr/bin/env python3
"""Build labeled contact sheets (3x2) for each RexTrix clip."""
import os
from PIL import Image, ImageDraw, ImageFont

FRAMES = "/home/z/my-project/rextrix_review/frames"
OUT = "/home/z/my-project/rextrix_review/sheets"
os.makedirs(OUT, exist_ok=True)

TS = ["0.5", "2.0", "9.0", "18.5", "20.0", "21.5"]
CLIPS = [d[:-4] for d in sorted(os.listdir(FRAMES)) if d.endswith(".jpg")]
clips = sorted(set(c.rsplit("_t", 1)[0] for c in CLIPS))

try:
    font = ImageFont.truetype(
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22)
except Exception:
    font = ImageFont.load_default()

for clip in clips:
    tiles = []
    for t in TS:
        p = os.path.join(FRAMES, f"{clip}_t{t}.jpg")
        if not os.path.exists(p):
            tiles.append(None)
            continue
        im = Image.open(p).convert("RGB")
        # add label bar on top
        bar = Image.new("RGB", (im.width, 34), (20, 20, 20))
        d = ImageDraw.Draw(bar)
        d.text((10, 5), f"t={t}s", fill=(255, 255, 80), font=font)
        combo = Image.new("RGB", (im.width, im.height + 34), (0, 0, 0))
        combo.paste(bar, (0, 0))
        combo.paste(im, (0, 34))
        tiles.append(combo)
    w = max(t.width for t in tiles if t)
    h = max(t.height for t in tiles if t)
    sheet = Image.new("RGB", (w * 3 + 20, h * 2 + 15), (40, 40, 40))
    for i, t in enumerate(tiles):
        if t is None:
            continue
        x = (i % 3) * (w + 5)
        y = (i // 3) * (h + 5)
        sheet.paste(t, (x, y))
    outp = os.path.join(OUT, f"sheet_{clip}.jpg")
    sheet.save(outp, quality=88)
    print(outp, sheet.size)
print("DONE")
