#!/usr/bin/env python3
"""Independent architect verification of RexTrix_Clip_28_pilot_v1_review_draft.mp4.
Checks: SHA-256, frame count, PTS=n/30 audit, end-card hold (frame-diff), faststart order.
Method mirrors the intake audit (measure on decoded file, never trust manifests)."""
import subprocess, hashlib, json, sys

F = "/home/z/my-project/upload/RexTrix_Clip_28_pilot_v1_review_draft.mp4"

# 1) SHA-256 (compare to agent claim 78d7e8b6...520)
h = hashlib.sha256(open(F, "rb").read()).hexdigest()
print("SHA256:", h)
print("  agent claimed: 78d7e8b6d21e0968d662b459799f3646268baadd1d34ecdcf5f613e7be58f520")
print("  MATCH" if h == "78d7e8b6d21e0968d662b459799f3646268baadd1d34ecdcf5f613e7be58f520" else "  MISMATCH")

# 2) Decoded frame count
r = subprocess.run(["ffprobe", "-v", "error", "-count_frames", "-select_streams", "v:0",
                    "-show_entries", "stream=nb_read_frames", "-of", "csv=p=0", F],
                   capture_output=True, text=True)
n = int(r.stdout.strip())
print(f"\nDecoded frames: {n} (claimed 568) ->", "PASS" if n == 568 else "FAIL")

# 3) PTS audit: every pts_time, diffs must be 1/30 with tiny tolerance, first ~0
r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0",
                    "-show_entries", "frame=pts_time", "-of", "csv=p=0", F],
                   capture_output=True, text=True)
pts = [float(x.strip().rstrip(',')) for x in r.stdout.strip().splitlines() if x.strip()]
diffs = [b - a for a, b in zip(pts, pts[1:])]
maxdev = max(abs(d - 1/30) for d in diffs)
print(f"PTS: first={pts[0]:.6f} last={pts[-1]:.6f} count={len(pts)} "
      f"max |diff - 1/30| = {maxdev:.2e} ->", "PASS" if maxdev < 1e-3 and abs(pts[0]) < 1e-3 else "FAIL")

# 4) End-card hold: decode all frames as tiny gray, find last strong boundary
cmd = ["ffmpeg", "-v", "error", "-i", F, "-vf", "scale=135:240", "-f", "rawvideo",
       "-pix_fmt", "gray", "-"]
raw = subprocess.run(cmd, capture_output=True).stdout
nf = len(raw) // (135 * 240)
import numpy as np
fr = np.frombuffer(raw[:nf * 135 * 240], dtype=np.uint8).reshape(nf, 240, 135).astype(np.int16)
d = np.abs(np.diff(fr, axis=0)).mean(axis=(1, 2))  # diff between consecutive frames
# strong boundaries = frame transitions > 8; card entry = last strong transition
strong = np.where(d > 8.0)[0]
entry_frame = int(strong[-1]) + 1 if len(strong) else -1
entry_t = entry_frame / 30.0
hold = (nf - 1 - entry_frame) / 30.0  # from first card frame to last frame
# stillness after entry
tail = d[entry_frame:] if entry_frame >= 0 else []
print(f"\nFrame-diff: {nf} frames decoded; last strong boundary after frame {entry_frame} "
      f"(t={entry_t:.3f}s); hold to last frame = {hold:.3f}s "
      f"({nf - 1 - entry_frame} frames)")
print(f"Max mean-diff inside card: {tail.max() if len(tail) else float('nan'):.2f} "
      f"(static card expected < 2)")
print("End-card hold >= 4.5s:", "PASS" if hold >= 4.5 else "FAIL")

# 5) faststart: walk top-level MP4 boxes
def boxes(f):
    out, pos = [], 0
    data = open(f, "rb").read(4_000_000)
    import struct
    while pos + 8 <= len(data):
        size, typ = struct.unpack(">I4s", data[pos:pos + 8])
        typ = typ.decode("latin1")
        out.append((typ, pos, size))
        if size == 1:
            size = struct.unpack(">Q", data[pos + 8:pos + 16])[0]
        if size == 0:
            break
        pos += size
    return out
bx = boxes(F)
top = [t for t, _, _ in bx]
print(f"\nTop-level boxes: {top[:6]}")
print("faststart (moov before mdat):", "PASS" if "moov" in top and "mdat" in top
      and top.index("moov") < top.index("mdat") else "FAIL")
