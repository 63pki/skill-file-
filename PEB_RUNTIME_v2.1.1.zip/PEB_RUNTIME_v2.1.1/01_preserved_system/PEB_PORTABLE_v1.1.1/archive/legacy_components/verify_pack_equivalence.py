#!/usr/bin/env python3
"""Packaging/content equivalence check: upload-to-claude/*.zip vs extracted loose dirs.
Compares SHA-256 of every file inside each per-style zip against the loose extracted
counterpart files under resource_review/claude-motion-styles-20/claude-motion-styles-20/.
No extraction to disk of zips (reads in-memory), no execution, no rendering."""
import hashlib, zipfile, pathlib, json, sys

BASE = pathlib.Path("/home/z/my-project/resource_review/claude-motion-styles-20/claude-motion-styles-20")
UP = BASE / "upload-to-claude"

def sha(b): return hashlib.sha256(b).hexdigest()

results = {"styles": [], "summary": {}}
total_zip_files = 0
total_matched = 0
total_mismatched = 0
total_ziponly = 0
total_looseonly = 0
zip_sha = {}

style_dirs = sorted(d for d in BASE.iterdir() if d.is_dir() and d.name.startswith("motion-"))
for z in sorted(UP.glob("*.zip")):
    stylename = z.stem  # e.g. motion-art-deco
    loose = BASE / stylename
    entry = {"zip": z.name, "zip_sha256": sha(z.read_bytes()), "loose_dir_exists": loose.is_dir(), "files": []}
    zip_sha[z.name] = entry["zip_sha256"]
    loose_files = {}
    if loose.is_dir():
        for f in loose.rglob("*"):
            if f.is_file():
                loose_files[f.relative_to(loose).as_posix()] = sha(f.read_bytes())
    with zipfile.ZipFile(z) as zf:
        names = [n for n in zf.namelist() if not n.endswith("/")]
        # handle possible top-level folder inside zip
        for n in names:
            rel = n
            parts = pathlib.PurePosixPath(n).parts
            if len(parts) > 1 and parts[0] == stylename:
                rel = pathlib.PurePosixPath(*parts[1:]).as_posix()
            data = zf.read(n)
            h = sha(data)
            total_zip_files += 1
            if rel in loose_files:
                if loose_files[rel] == h:
                    total_matched += 1
                    entry["files"].append({"file": rel, "status": "match"})
                else:
                    total_mismatched += 1
                    entry["files"].append({"file": rel, "status": "MISMATCH", "zip_sha": h, "loose_sha": loose_files[rel]})
            else:
                total_ziponly += 1
                entry["files"].append({"file": rel, "status": "zip-only"})
    for lf in loose_files:
        if lf not in [f["file"] for f in entry["files"] if f["status"] in ("match", "MISMATCH")]:
            total_looseonly += 1
            entry["files"].append({"file": lf, "status": "loose-only"})
    results["styles"].append(entry)

results["summary"] = {
    "zips_checked": len(results["styles"]),
    "style_dirs_on_disk": len(style_dirs),
    "zip_files_total": total_zip_files,
    "matched": total_matched,
    "mismatched": total_mismatched,
    "zip_only": total_ziponly,
    "loose_only": total_looseonly,
}
out = pathlib.Path("/home/z/my-project/tool-results/pack_equivalence_result.json")
out.write_text(json.dumps(results, indent=1))
print(json.dumps(results["summary"], indent=1))
for s in results["styles"]:
    bad = [f for f in s["files"] if f["status"] != "match"]
    if bad:
        print(s["zip"], "->", bad)
