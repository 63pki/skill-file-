# COMPONENTS MAP — Actual Reusable Components (v1.0, 2026-10-28)

**What this is:** the concrete, reusable script components this project actually produced, mapped to the Implementation Inventory rows they implement or support. The inventory (`../03_implementation_inventory/IMPLEMENTATION_INVENTORY_v0.9.md`) is the authority on WHAT is tested; this folder holds the actual artifacts. Every script below was used in this project's real verification work (RexTrix 10-clip review, clip-28 pilot verification, operator-input receipt, pack equivalence test, prompt regression audits).

**Honest scope note:** several scripts contain hard-coded project paths from the RexTrix review workspace (clip and transcript directories inside the original project tree). They are reusable as patterns/templates — adapt paths and clip-name patterns per campaign. They are NOT a packaged CLI.

| Component | Implements / supports | Status | Notes for reuse |
|---|---|---|---|
| `qc_probe.sh` | Inventory row 8 (QC measurement — ffprobe stream/CFR/loudness probing) | Used in production review (10-clip intake) | Adapt the input dir + file glob. |
| `qc_loudness.sh` | Inventory row 2 (loudnorm/ebur128 measurement; XR-4 corrections apply to the CHAIN, this is the measuring side) | Used (clip loudness verification) | ebur128 peak=true per file; parse I/TP. |
| `qc_frames.sh` | Inventory row 8 (frame extraction for review) + intake-sweep support | Used (review frames per clip) | Timestamps were campaign-specific — retime per brief. |
| `qc_asr.sh` | Inventory row 6 (T1 audio extraction → transcription prep) | Used | 16 kHz mono wav extraction per clip. |
| `run_asr.sh` | Inventory row 6 (T1 batch transcription with rate-limit spacing + resume) | Used | Skip-if-done logic; log file; provider call pattern. |
| `make_sheets.py` | Review support (labeled contact sheets, 3×2) | Used | Pillow; DejaVu font path; frame-dir convention. |
| `make_sheet2.py` | Review support (boundary-frame sheets) | Used | Companion to make_sheets for edge moments. |
| `pilot28_verify.py` | Pilot verification pattern (SHA-256 chain of custody, frame count, PTS=n/30 audit, end-card hold via frame-diff, faststart order) | Used (clip-28 pilot, independently reproduced all agent QC claims) | The reference example of "measure on decoded file, never trust manifests." |
| `verify_pack_equivalence.py` | Structural test (zip-member vs loose-file SHA-256 equivalence, in-memory, no extraction) | Used (80/80 result — `../07_status/evidence/pack_equivalence_result.json`) | Reusable for any packaging-equivalence check. |
| `verify_operator_input_v1.py` | Process fix (persist + verify operator inventories at receipt: counts, URL normalization, link-to-repo membership, hashing) | Used (OPERATOR_INPUT_2026-10-28 receipt) | The standing input-persistence rule, implemented. |
| `v31_regression_audit.py` | Document-level regression audit of the master prompt files (102 checks; C1–C5 freeze corrections) | Used at v3.1.1 freeze | Re-run after ANY edit to the four prompt files. Identical to the copy shipped alongside the master-prompt files in the original project's download tree. |
| `v3_regression_audit.py` | Historical guardrail audit for v3 (P-V patches, R1–R5, D1–D7) | Used at v3 | Superseded by the v3.1 audit for current files; kept for lineage. |

**Rule of order (from the inventory):** inventory → house pattern → registry card → only then a new build, with logged justification. These components ARE the house patterns' concrete form; check them before writing anything new.
