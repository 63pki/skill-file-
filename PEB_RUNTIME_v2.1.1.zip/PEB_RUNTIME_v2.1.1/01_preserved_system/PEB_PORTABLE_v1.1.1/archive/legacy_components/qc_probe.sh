#!/bin/bash
# Probe all 10 RexTrix clips: streams, CFR check, loudness/true-peak
cd /home/z/my-project/rextrix_review/clips
for f in RexTrix_Clip_*.mp4; do
  echo "=================================================================="
  echo "FILE: $f"
  ffprobe -v error -select_streams v:0 \
    -show_entries stream=width,height,sample_aspect_ratio,display_aspect_ratio,r_frame_rate,avg_frame_rate,nb_frames,codec_name,profile,pix_fmt \
    -show_entries format=duration,bit_rate \
    -of default=noprint_wrappers=1 "$f"
  # audio stream
  ffprobe -v error -select_streams a:0 \
    -show_entries stream=codec_name,sample_rate,channels,channel_layout \
    -of default=noprint_wrappers=1 "$f"
  # frame count vs CFR expectation (22s * 30 = 660)
  ffprobe -v error -select_streams v:0 -count_frames \
    -show_entries stream=nb_read_frames -of default=noprint_wrappers=1 "$f" | sed 's/^/measured_/'
  # audio/video sync sanity: duration of audio stream
  ffprobe -v error -select_streams a:0 -show_entries stream=duration -of default=noprint_wrappers=1 "$f" | sed 's/^/audio_/'
done
echo "=================================================================="
echo "ALL PROBES DONE"
