#!/bin/bash
# Extract review frames per clip: open (0.5s), mid-arc (9s), endcard start (18.3s), endcard mid (20.3s), last (21.6s)
cd /home/z/my-project/rextrix_review/clips
mkdir -p ../frames
for f in RexTrix_Clip_*.mp4; do
  base="${f%.mp4}"
  n=$(echo "$base" | rg -o "Clip_([0-9]+)" -r '$1')
  for t in 0.5 9.0 18.3 20.3 21.6; do
    ffmpeg -v error -ss "$t" -i "$f" -frames:v 1 -vf scale=540:960 -y "../frames/${n}_t${t}.png"
  done
done
ls ../frames | wc -l
