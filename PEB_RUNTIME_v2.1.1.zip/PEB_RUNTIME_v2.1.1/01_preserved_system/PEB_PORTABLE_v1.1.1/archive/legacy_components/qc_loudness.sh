#!/bin/bash
# Measure integrated LUFS + true peak on each clip (verify manifest claims)
cd /home/z/my-project/rextrix_review/clips
for f in RexTrix_Clip_*.mp4; do
  out=$(ffmpeg -nostats -i "$f" -vn -af ebur128=peak=true -f null - 2>&1 | tail -14)
  lufs=$(echo "$out" | rg -o "I:\s*(-?[0-9.]+)\s*LUFS" -r '$1' | tail -1)
  peak=$(echo "$out" | rg -o "Peak:\s*(-?[0-9.]+)\s*dBFS" -r '$1' | tail -1)
  echo "$f | I: ${lufs} LUFS | TruePeak: ${peak} dBFS"
done
