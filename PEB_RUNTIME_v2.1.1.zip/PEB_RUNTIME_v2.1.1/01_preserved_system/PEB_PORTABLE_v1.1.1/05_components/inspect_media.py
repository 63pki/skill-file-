#!/usr/bin/env python3
"""Metadata/hash inspection only. Not a renderer, full QC, or listening check."""
import argparse,hashlib,json,subprocess
from pathlib import Path
from fractions import Fraction

def parse_rate(value):
 try:
  n=Fraction(str(value));return str(n) if n>0 else None
 except (ValueError,ZeroDivisionError):return None

def inspect(path,probe='ffprobe',timeout=90):
 path=Path(path).resolve()
 if not path.is_file():raise FileNotFoundError(path)
 digest=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):digest.update(chunk)
 result=subprocess.run([probe,'-v','error','-show_streams','-show_format','-of','json',str(path)],capture_output=True,text=True,timeout=timeout,check=True)
 data=json.loads(result.stdout)
 if not isinstance(data,dict) or not isinstance(data.get('streams'),list):raise ValueError('Unexpected ffprobe schema')
 return {'path':str(path),'sha256':digest.hexdigest(),'size':path.stat().st_size,'probe':data,'checks':{'metadata_read':'passed','full_decode':'not_checked','frame_grid':'not_checked','av_sync':'not_checked','audio_listening':'not_checked','caption_readability':'not_checked','campaign_compliance':'not_checked','creative_review':'not_checked'},'warning':'Equal reported average/nominal rates do NOT prove CFR. Metadata success is not a media-quality or release pass.'}

def main():
 p=argparse.ArgumentParser();p.add_argument('media',type=Path);p.add_argument('--ffprobe',default='ffprobe');p.add_argument('--out',type=Path,required=True);p.add_argument('--timeout',type=int,default=90);a=p.parse_args()
 if a.out.exists():p.error('Refusing to overwrite output')
 try:r=inspect(a.media,a.ffprobe,a.timeout)
 except Exception as e:print(json.dumps({'status':'failed','error':str(e)}));return 1
 a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(r,indent=2)+'\n');print('Metadata report written; full audiovisual QC NOT performed.');return 0
if __name__=='__main__':raise SystemExit(main())
