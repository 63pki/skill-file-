#!/usr/bin/env python3
"""Builder-written, stdlib, read-only package validation. No media/network execution."""
import argparse,hashlib,json,re
from pathlib import Path

def sha256(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def validate(root,verify_hashes=True):
 root=Path(root).resolve();checks=[]
 def add(name,ok,detail=''):checks.append({'name':name,'passed':bool(ok),'detail':detail})
 def load(rel):return json.loads((root/rel).read_text())
 nav=load('07_status/ACTIVE_NAVIGATION.json')
 for rel in nav:add('file:'+rel,(root/rel).is_file())
 for rel in nav:
  p=root/rel
  if not p.is_file() or p.suffix!='.md':continue
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
   if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',target) or target.startswith('#'):continue
   q=(p.parent/target.split('#')[0]).resolve()
   add('link:'+rel+' -> '+target,q.is_relative_to(root) and q.exists())
 for rel,count in [('02_registry/ALL_REPOSITORIES_62.txt',62),('02_registry/SHORTLIST_DIRECT_SKILL_LINKS_20.txt',20),('02_registry/CONDITIONAL_DIRECT_SKILL_LINKS_26.txt',26)]:
  u=[x.strip() for x in (root/rel).read_text().splitlines() if x.strip()];add('count:'+rel,len(u)==count and len(set(u))==count,str(len(u)))
 repos={x.rstrip('/').casefold() for x in (root/'02_registry/ALL_REPOSITORIES_62.txt').read_text().splitlines()}
 for rel in ['02_registry/SHORTLIST_DIRECT_SKILL_LINKS_20.txt','02_registry/CONDITIONAL_DIRECT_SKILL_LINKS_26.txt']:
  for url in (root/rel).read_text().splitlines():
   key='/'.join(url.split('/')[:5]).casefold();add('link_repo:'+url,key in repos)
 spec='04_catalogs_and_resources/Captions_and_Effects_v2/EFFECTS_AND_CAPTIONS_SPEC_v2.json';d=load(spec)
 for k,n in [('caption_styles',24),('video_effects',45),('sound_effects',8),('caption_library_catalog',41)]:
  a=d[k];add('catalog_count:'+k,len(a)==n)
  idkey=next((key for key in ['style_id','effect_id','sfx_id','sound_id','catalog_id','library_id','id'] if all(key in x for x in a)),None)
  if idkey:add('id_unique:'+k,len({x[idkey] for x in a})==len(a),idkey)
 # Original body must remain exactly preserved after the marker.
 core=(root/'01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md').read_text();original=(root/'archive/baseline_v1.0/01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md').read_text()
 add('core_original_body_unchanged',core.split('ORIGINAL v3.1.1 BODY (unchanged):\n\n',1)[-1]==original)
 # The actual catalog bodies must match original export hashes.
 baseline=load('07_status/PRESERVATION_HASHES.json')
 for rel,h in baseline.items():add('preserved:'+rel,(root/rel).is_file() and sha256(root/rel)==h)
 if verify_hashes:
  manifest=load('PACKAGE_MANIFEST.json');listed=set(manifest['files'])
  excluded=set(manifest['excluded_generated_paths']);actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}-excluded
  add('manifest_exact_file_set',actual==listed,json.dumps({'missing':sorted(listed-actual),'extra':sorted(actual-listed)}))
  for rel,h in manifest['files'].items():
   p=root/rel;add('hash:'+rel,p.is_file() and sha256(p)==h)
 return {'scope':'package navigation, integrity, counts and preservation only; no media/backend/creative tests','passed':all(x['passed'] for x in checks),'checks':checks,'failed':[x for x in checks if not x['passed']]}
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--no-hashes',action='store_true');p.add_argument('--json-out',type=Path);a=p.parse_args()
 try:r=validate(a.root,not a.no_hashes)
 except Exception as e:r={'passed':False,'failed':[{'name':'validation_exception','detail':str(e)}]}
 if a.json_out:a.json_out.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'passed':r['passed'],'check_count':len(r.get('checks',[])),'failed':r['failed']},indent=2));return 0 if r['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
