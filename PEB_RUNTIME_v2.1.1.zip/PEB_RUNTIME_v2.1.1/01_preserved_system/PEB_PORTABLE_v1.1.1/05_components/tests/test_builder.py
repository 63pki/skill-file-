import importlib.util,json,subprocess,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('inspect_media',P/'inspect_media.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class BuilderTests(unittest.TestCase):
 def test_rational_rate(self):self.assertEqual(m.parse_rate('30000/1001'),'30000/1001')
 def test_zero_rate(self):self.assertIsNone(m.parse_rate('0/0'))
 def test_invalid_rate(self):self.assertIsNone(m.parse_rate('not-rate'))
 def test_missing_media(self):
  with self.assertRaises(FileNotFoundError):m.inspect('/path/that/does/not/exist')
 def test_metadata_scope(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'space ; quote.mp4';p.write_bytes(b'fixture-data-not-video')
   with patch.object(m.subprocess,'run',return_value=subprocess.CompletedProcess([],0,json.dumps({'streams':[{'codec_type':'video'}],'format':{}}),'')) as run:
    r=m.inspect(p);self.assertEqual(r['checks']['full_decode'],'not_checked');self.assertEqual(run.call_args.args[0][-1],str(p.resolve()));self.assertIsInstance(run.call_args.args[0],list)
 def test_invalid_probe_schema(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'f';p.write_bytes(b'x')
   with patch.object(m.subprocess,'run',return_value=subprocess.CompletedProcess([],0,'{"streams":null}','')):
    with self.assertRaises(ValueError):m.inspect(p)
 def test_probe_failure(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'f';p.write_bytes(b'x')
   with patch.object(m.subprocess,'run',side_effect=subprocess.CalledProcessError(1,['ffprobe'])):
    with self.assertRaises(subprocess.CalledProcessError):m.inspect(p)
# --- v1.1.1 regression checks: catalog ID-key uniqueness (correction C1) ---
def _load_validator():
 s2=importlib.util.spec_from_file_location('verify_package',P/'verify_package.py')
 v=importlib.util.module_from_spec(s2);s2.loader.exec_module(v);return v
def _mk_pkg(td,sound_effects,catalog):
 root=Path(td)/'pkg'
 (root/'07_status').mkdir(parents=True);(root/'07_status/ACTIVE_NAVIGATION.json').write_text('[]')
 (root/'02_registry').mkdir(parents=True)
 for f in ('ALL_REPOSITORIES_62.txt','SHORTLIST_DIRECT_SKILL_LINKS_20.txt','CONDITIONAL_DIRECT_SKILL_LINKS_26.txt'):(root/'02_registry'/f).write_text('')
 d=root/'04_catalogs_and_resources/Captions_and_Effects_v2';d.mkdir(parents=True)
 (d/'EFFECTS_AND_CAPTIONS_SPEC_v2.json').write_text(json.dumps({'caption_styles':[{'style_id':'s0'},{'style_id':'s1'}],'video_effects':[{'effect_id':'e0'},{'effect_id':'e1'}],'sound_effects':sound_effects,'caption_library_catalog':catalog}))
 (root/'01_master_prompt').mkdir(parents=True);(root/'01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md').write_text('X')
 (root/'archive/baseline_v1.0/01_master_prompt').mkdir(parents=True);(root/'archive/baseline_v1.0/01_master_prompt/PRO_EDITOR_BRAIN_v3.1_CORE.md').write_text('X')
 (root/'07_status/PRESERVATION_HASHES.json').write_text('{}')
 return root
class IdKeyRegressionTests(unittest.TestCase):
 def _id_check(self,r,n):return next((c for c in r['checks'] if c['name']==n),None)
 def test_sfx_and_library_id_now_checked(self):
  v=_load_validator()
  with tempfile.TemporaryDirectory() as td:
   r=v.validate(_mk_pkg(td,[{'sfx_id':'x1'},{'sfx_id':'x2'}],[{'library_id':'L1'},{'library_id':'L2'}]),verify_hashes=False)
   c=self._id_check(r,'id_unique:sound_effects');self.assertIsNotNone(c);self.assertTrue(c['passed']);self.assertEqual(c['detail'],'sfx_id')
   c=self._id_check(r,'id_unique:caption_library_catalog');self.assertIsNotNone(c);self.assertTrue(c['passed']);self.assertEqual(c['detail'],'library_id')
 def test_duplicate_sfx_id_detected(self):
  v=_load_validator()
  with tempfile.TemporaryDirectory() as td:
   r=v.validate(_mk_pkg(td,[{'sfx_id':'dup'},{'sfx_id':'dup'}],[{'library_id':'L1'}]),verify_hashes=False)
   c=self._id_check(r,'id_unique:sound_effects');self.assertIsNotNone(c);self.assertFalse(c['passed'])
 def test_duplicate_library_id_detected(self):
  v=_load_validator()
  with tempfile.TemporaryDirectory() as td:
   r=v.validate(_mk_pkg(td,[{'sfx_id':'x1'}],[{'library_id':'dup'},{'library_id':'dup'}]),verify_hashes=False)
   c=self._id_check(r,'id_unique:caption_library_catalog');self.assertIsNotNone(c);self.assertFalse(c['passed'])

if __name__=='__main__':unittest.main()
