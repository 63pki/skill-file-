# Components map v1.1

## Builder utilities (new, bounded implementations)
- `verify_package.py`: stdlib package validator. Active navigation, manifest hashes, original core-body preservation, catalog preservation/counts and source-link consistency. No network, backend or supplier-code execution. Tests/results in the validation report.
- `inspect_media.py`: metadata/SHA-256 helper for a real future campaign; ffprobe subprocess argument array, timeout, explicit not_checked fields. Unit tests mock ffprobe; no real media tested in this build. Does not claim CFR, sync or full decode from metadata.
- `tests/test_builder.py`: seven helper logic/error-handling tests. Only these new builder tests executed. No legacy scripts executed.

## Supplier scripts retained, not approved as portable CLIs
All 12 supplier scripts are in `../archive/legacy_components/`, with the original COMPONENTS_MAP.md. Static inspection found old absolute workspace assumptions in every script. They are patterns to adapt, not ready-to-run integrations. `run_asr.sh` invokes `z-ai asr`; `qc_asr.sh` references the provider route. Neither proves a packaged faster-whisper implementation. Some logs imply truncation/retry/overwrite behavior; inspect before using real project assets.
Neither prompt-regression script is a creative test or fresh proof of renderer capability. Old fixture timestamps and 30 fps assumptions remain historical. Do not run package scripts automatically on extraction. A tool being present in the environment does not mean these scripts match it.
