# Next-campaign startup instruction

Copy this file's step list into the editing agent's first message, with the
package and the new campaign's brief and footage. No architecture discussion
is needed or wanted; the master prompt carries the rules.

## The instruction

> Work from the PEB_EDITORIAL_SYSTEM_v2.1.1 package. Read
> `05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md` and root `START_HERE.md` first;
> that is your entire orientation. RexTrix and any other paused campaign stay
> paused; their numbers and approvals are history, not defaults.
>
> 1. **Reconcile the job once.** From the current brief, record every
>    consequential requirement (id, source, scope, units,
>    mandatory/default/preference, amendments), the authority mode for this
>    batch, and what is explicitly NOT authorized. Surface conflicts once.
>    Start a fresh v2.0 project record
>    (`06_system_improvement/05_templates/PROJECT_RECORD_TEMPLATE_v2.0.json`).
> 2. **Understand the material.** Inspect actual pixels, context and sound of
>    the relevant sources with the best authorized means. Titles never
>    approve clips; scout before cutting. Label OBSERVED / TESTED /
>    HYPOTHESIS / UNKNOWN.
> 3. **Choose one editorial idea.** Answer the master prompt §3 questions
>    (audience, opening, promise/payoff, our contribution, brand bridge,
>    beats). Consider scene-led, commentary and demonstration routes honestly;
>    pick one and say why. Record it in the record's `creative` block.
> 4. **Build the calibration pilot.** One finished output, smallest
>    sufficient implementation, within existing authorization. Ask only at a
>    genuinely new boundary (new provider, upload, cost, installation,
>    publication).
> 5. **Review the exact export** (master prompt §6): technical, campaign,
>    creative (actual-export cold-viewer pass, recorded as a review entry bound
>    to the output's current SHA-256), performance (UNKNOWN unless matched
>    analytics exist). Fix the largest specific defect and re-check what
>    changed.
> 6. **Calibrate, then scale** (§7) only within the recorded authorization:
>    variety means different supported ideas, not arithmetic offsets; every
>    scoped exception gets adopted, retired or re-scoped before the next
>    batch; report fewer eligible ideas instead of filler.
> 7. **Deliver honestly** (§8): preview, short verdict, material unresolved
>    issues, one next action. Keep technical, campaign, creative and
>    performance statuses separate. No view promises.
>
> Optional tools (validators, vision adapter, catalogs) are listed in the
> master prompt; none is required to edit. If a capability you need is
> missing, name the smallest adaptation and continue independent work.

## Stop conditions (pre-agreed, not new approvals)

- Any publication/account action: only inside the campaign's recorded,
  active authorization; verify campaign state with timestamp first.
- A mandatory requirement that cannot be verified: hold the output, report
  the exact gap — do not pass it on vocabulary.
- A genuinely new external boundary (upload, cost, provider, installation):
  ask once, concretely, and continue unrelated authorized work meanwhile.

## Optional first-week pattern (only when publishing is authorized)

When a campaign resumes and submissions are allowed, the highest-value first
experiment from the debriefs is a small pre-registered comparison (e.g. one
scene-led clip with paratextual brand vs one narration-led clip with an
in-story brand bridge vs one control), measured on 24h/72h/7d views and, if
available, retention near the card join — recorded as a hypothesis before
posting. This is a campaign decision, not part of the editing workflow.
