# Additive continuation change log

v1.2 is this bundle's version, not a promotion of the frozen core or approval
of a v3.2 architecture. No original baseline or delivered evidence file rewritten.
Added: current stage/approvals, NVIDIA usage and independent-check protocol,
fresh-session prompt, recovery register, pending next actions, portable client,
hash manifest and mechanical packaging report.

Verification scope: archive CRC, baseline path/content parity, delivered manifest
hashes, new Python AST syntax and bounded credential-pattern scan. No supplier
script execution, no fixture rerun, no media render, no provider request.
The original development receipts describe tests in Agent 1's environment.
Raw synthetic media was not supplied, so this build cannot independently reproduce
or certify those timing/readability/audio results.

Future updates: append the actual approval message and exact source boundaries,
new sanitized check receipts, final export identity and editable decision record
when those actions genuinely happen. Keep old evidence labeled historical.
