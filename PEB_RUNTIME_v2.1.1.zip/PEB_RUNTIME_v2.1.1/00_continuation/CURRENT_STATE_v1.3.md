> **HISTORICAL SNAPSHOT (banner added v2.0).** Superseded by CURRENT_STATE_AND_APPROVALS.md in its own era and by the v2.0 entry point now. Body preserved unaltered below.

# Latest supplied project state and recovery

- P02 revision 02: preserved technical/reference draft; do not rerender as campaign creative by default.
- Cloudwhale P03 v02: user reports a private 22.733-second/682-frame draft, moving opening, one omission at output 1.833 seconds (source 24.200→27.033), complete native visual reaction and 4.5-second mandatory card. The splice remains speech-unverified. **The current v02 MP4 was not attached to this build request; its QC assertions were not independently remeasured here.** Do not run V3 on v01/source and label it v02.
- Current work completed: read entire supplied 481-line reference brief; inspected four attached review drafts; built additive V1/V2/V3 adapter/consumption contract plus tests and bounded NVIDIA evidence. See actual BUILD_RESULT, not assumptions.
- Current build scope: reference understanding and synthetic fixture tests, no production edits/renders, no installation, new provider, account action or publication.
- Actual originals for the four reference drafts remain in the user's attachments. The archive retains their identities/hashes and exact derived provider inputs/contact sheets; original MP4s are not duplicated here. Fixture MP4s and pictures are included. P02/full campaign sources are not newly bundled; recover them from the existing full checkpoints/source registers before revision.
- Credentials, raw HTTP responses, base64 payloads and model internal reasoning are absent. Existing valid media/provider authorization should be reused within scope, not repeatedly requested. Source rights/language/product-claims/campaign contribution remain evidence-based and separate from technical passes.
- Next production action: use one relevant reference mechanism for a source-supported concept, then run the new scoped stages on the actual authorized inputs/output. No fixed effects quota, fake app test or guaranteed views. Preserve source mapping and report exact unresolved issues rather than spinning through generic reanalysis.
