> **HISTORICAL — DO NOT EXECUTE (banner added v2.0).** This continuation prompt predates the campaign pause. The active entry point is the root `START_HERE.md`; the active master prompt is `05_master_prompt/PRO_EDITOR_BRAIN_v4.0.md`. Old approvals, next actions and P02 state are history, not permission. Body preserved unaltered below.

# Copy this into a fresh agent session

Continue the existing PEB/RexTrix project from this continuity ZIP. Do not redesign
or rewrite the system, repeat all audits, or assume historical campaigns are defaults.
Follow root START_HERE.md. If you cannot extract/read attachments or call APIs,
state that limitation rather than pretending access.

First summarize current state and missing inputs briefly. Preserve originals,
evidence and IDs. Read current brief and governing source rules; distinguish current
requirements, operator defaults, historical claims and pending decisions.

One pilot means one finished video, not necessarily one source excerpt. Choose a
viewer-relevant concept before tools/effects. Enough source inspection is valuable,
but do not start another broad search for the current P02 without a new reason/approval.
State audience interest, opening promise, payoff and honest RexTrix relevance.
No mandatory motion/caption/skill quota. Effects are neither forbidden globally nor
an automatic substitute for originality.

Use NVIDIA Nemotron 3 Nano Omni as the preferred authorized audiovisual analyst:
model nvidia/nemotron-3-nano-omni-30b-a3b-reasoning.
Read 02_nvidia/USAGE_AND_VERIFICATION.md. Existing joint video+WAV and audio-only
calls succeeded, but timestamps and repetition errors occurred. Do not equate API
success with accurate transcription, language clearance, rights or creative approval.
Use another independent model only for consequential unresolved questions and only
with authorization for that provider/media. No second model is configured or tested here.
Never log, echo, embed, commit or bundle credentials. Do not assume cross-session
key persistence. Prefer available secret configuration; explain actual limitations.

Current P02: preserve the full measurement/opinions/weld exchange chronologically.
Old deletion of excerpt 6.5–11.9 seconds is suspended. Approximate original range
28.133333–45.200000 is provisional, not speech-safe. Keep the actual payoff/reaction;
do not force duration. Existing tests are reported completed, NOT final-export QC.

Proceed only with the next authorized stage in CURRENT_STATE_AND_APPROVALS.md.
Do not turn approval for analysis/development into permission to render or publish.
No source-footage render until separately approved and boundaries confirmed.
For a later approved pilot: real logo and exact “Download the RexTrix app — link in bio”
fully readable for >=4.5 seconds (already includes the 0.5-second margin).

Bring the user specific uncertainties, not the whole editorial job. Model-assisted
analysis can support decisions but must not be described as your own human listening.
Keep technical, campaign, creative and performance statuses separate.
Save edit decisions, inputs/hashes, paths, versions, receipts and resume state so a
fresh session can make a revision without reconstructing the project from chat.
