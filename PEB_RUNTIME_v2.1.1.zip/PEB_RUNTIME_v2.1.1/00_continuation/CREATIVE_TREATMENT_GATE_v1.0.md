> **SUPERSEDED IN PART (banner added v2.0).** The compulsory three-route paperwork and the creative_gate.py planning requirement are retired: the active decision rules are `05_master_prompt/PRO_EDITOR_BRAIN_v4.0.md` §3 and the compact record. The route-comparison *thinking* survives there; the form and the separate gate no longer apply. Body preserved unaltered below.

# Creative treatment gate — decision and operating module v1.0

## Decision
The user's concern is accepted: do not count “find a scene → headline/captions → logo” as completion of the creative task merely because the export works. The target is an intentional campaign-led short with a source-supported viewer promise, designed information sequence, meaningful editorial contribution and professional execution. A compelling minimal scene is still valid; it must win on evidence, not because it is easiest. More effects, narration or instructions are not proof of engagement. We do not know why earlier posts stalled without analytics.

This module strengthens the creative decision/acceptance step, not the frozen master prompt. It adds no new campaign tier, score, provider, render authorization or mandatory effects package. It supersedes the older addendum's “present only one recommendation” default only at the trigger below. Source rights, the original-audio brief and existing approvals still govern.

## Trigger — not another endless gate
Apply once for a new pilot or a user-requested substantive creative reset. Do NOT redo it for a routine trim, caption repair, layout correction or an already approved treatment unless new feedback invalidates the concept. Reuse existing source inspection and model evidence; no extra library search or API call merely to fill this form.

## 1. Compare distinct creative routes before rendering
Present three compact treatment cards where evidence permits:
A. SCENE-LED — reconstruct the strongest complete joke, discovery, transformation or suspense beat.
B. NARRATIVE-LED — author a source-supported angle using intentional selects, narration or text and explanatory graphics where useful. Narration may be proposed while permission is pending; it may not be silently executed.
C. DEMONSTRATION/PRODUCT-EVIDENCE-LED — a real documented problem → action → visible result when actual product evidence exists. If only trailers are supplied, mark this route unavailable with the precise missing evidence. Do not invent app screens, a prompt submission, playability or a personal test. If useful, compare a second genuinely different entertainment-led route instead and explain why.

Do not force three feasible concepts from inadequate footage. The obligation is to consider the routes honestly, report unavailable/permission-dependent options and choose deliberately—not generate a long report or manufacture a third concept. The third route need not be selected; an app demonstration is not mandatory.

Each card contains:
- Audience and why this specific viewer would care (hypothesis, not invented research).
- Distinct angle and opening: actual moving/held image, heard sound and any text—not just a headline.
- Opening promise and complete payoff/reaction, with source IDs and inspection spans.
- What the editing adds beyond the source's own acting/joke/spectacle.
- Truthful campaign connection; important claim references and permissions.
- Feasibility, execution gap and why a cleaner/alternative treatment is better or worse.

Reject a generic concept that could fit any brand unchanged. Do not reject material solely because one model misunderstood it. Do not choose scene-led by default or narrative-led solely to demonstrate sophistication.

## 2. Recommend one treatment and storyboard it
Recommend the strongest combination of audience relevance, evidence, payoff, honest brand relevance and feasible execution. Explain why the other routes lose or remain unavailable; no numerical taste threshold.

Storyboard every major beat with output time range (provisional if necessary), source/asset reference, exact proposed VO/text, actual picture/reframe/motion, sound, intended viewer understanding, reason the treatment helps and remaining uncertainty. Include mandatory ending in duration arithmetic. No unsupported cut precision.

Plan effects against a job:
- Motion graphic: clarify scale, relationship, comparison or information hierarchy.
- Reframe/zoom: direct attention to an evidenced detail without hiding qualifications.
- Split screen: make a meaningful, provenance-supported comparison legible.
- Sound/VO: provide useful context or contrast, only when permitted and licensed.
- Caption emphasis: clarify an accurate phrase, quantity, qualifier or payoff.
- Held shot/silence: allow an important response or reveal to register.
No effect is mandatory, and no effect earns its place by looking premium alone.

## 3. Plan approval vs execution
At the user's current request, the next creative deliverable is the compact treatment comparison plus ONE selected storyboard—not another render. Routine implementation thereafter uses existing authorization; this module does not force repeated approval of individual edits. Render only within valid scope and once any genuinely new permission is settled.

RexTrix's recorded brief currently specifies original audio only. The user's VO/motion example authorizes thinking in that direction, not a silent amendment to that brief. Mark added narration/music/SFX as requires_permission until explicitly amended. Text/source-audio alternatives can be evaluated honestly; they are not automatically equal substitutes. If no feasible concept wins, name the specific evidence/scope gap once rather than repeat generic analysis.

## 4. Build and review, when authorized
Make the rough cut to test the information sequence; then add only justified designed treatment. Use V1/V2/V3 with their current limits and local checks. Review the exact export for cold-viewer clarity, complete payoff, craft, truthful brand integration and technical integrity. A technical pass or a finished render is not creative acceptance.

Keep technical, campaign/rights/claims, creative and actual audience performance separate. Predeclare one creative hypothesis for later observed analytics; no promised 1,000 or million views. Feedback should trigger one specific justified change, not cosmetic churn or another system rewrite.

## Executable record check
Fill `04_vision_stages/09_project_templates/CREATIVE_TREATMENT_PLAN_TEMPLATE.json` and run:
`python 04_vision_stages/05_components/creative_gate.py path/to/plan.json --phase plan`
Before an authorized new render use `--phase render`. This checks required decision records and permission flags, NOT artistic quality, factual truth or campaign clearance. A filled template does not prove a concept is good. Routine revisions declare `trigger: routine_revision` and reference the existing approved treatment rather than repeat three concepts.

## Current handoff
Agent 1 should first confirm whether an existing approved storyboard already satisfies this gate. If not, prepare the compact comparison and selected storyboard using its current source evidence. Keep P02/current Cloudwhale exports unchanged during planning. Do not infer missing product footage or grant a voiceover exception.
