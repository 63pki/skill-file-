> **HISTORICAL — DO NOT EXECUTE (banner added v2.0).** RexTrix is paused; these actions are expired history. See root `START_HERE.md` and `NEXT_CAMPAIGN_STARTUP.md`. Body preserved unaltered below.

# Next actions — pending, not automatically authorized

1. Ask only for the remaining audiovisual confirmation on the existing full 23.8s
   excerpt: exact words, “this one” referent, complete punchline and reaction.
   Use a second independent transcription/AV route if specifically authorized and
   useful; do not create an endless verification loop. Otherwise flag uncertainty.
2. Confirm actual speech-aware IN/OUT. Do not delete the opinions interval.
3. Decide whether the objective is a PRIVATE technical preview or a campaign pilot.
   The meaningful-contribution concern is unresolved. Development approval is not
   campaign acceptance, rights clearance or publication permission.
4. Obtain separate render approval. Do NOT change booleans merely to bypass guards.
5. Only after approval, relocate source/card paths in a NEW local approval plan,
   verify exact hashes and environment assumptions. Keep original plan unchanged.
6. Render ONE approved private output, if authorized. No batch/publication follows.
7. Check actual final output: decode, output PTS/frame count, source mapping,
   audio continuity/sync/encoded true peak, exact CTA, logo, readable hold, text
   language, safe areas; watch/listen to full exact export and judge story/ending.
8. Save editable decisions and resume state; test one requested revision in a fresh
   session. Update manifest/status without rewriting historical receipts.
9. Publication requires separate rights/campaign/account/platform approval.
   Only actual authorized analytics can support performance conclusions.

Suggested message to Agent 1 NOW:
“Your development checkpoint is received. Keep rendering held. Retain all inputs
and report paths/hashes for the source, endboard and plan. The remaining decision
is full dialogue/reaction confirmation and whether P02 is a private technical
preview or a sufficiently original campaign concept. Do not repeat completed
fixtures or add decorative effects to manufacture originality. After boundary
confirmation, request one explicit render approval; no publication.”
