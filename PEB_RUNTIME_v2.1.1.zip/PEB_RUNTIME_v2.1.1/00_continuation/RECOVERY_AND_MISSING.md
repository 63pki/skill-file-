> **HISTORICAL (banner added v2.0).** RexTrix-era recovery register; source URLs/hashes remain valid provenance for that paused campaign only. Body preserved unaltered below.

# Recovery, paths and genuinely missing material

## Included
Complete unchanged PEB_PORTABLE_v1.1.1 tree; NVIDIA sanitized evidence/scripts;
Agent 1 development files/artwork; earlier P02 review evidence; supplied brief/rules;
new continuation docs, portable NVIDIA helper and packaging verification.

## Not included (intentional)
- API key or any credential. No key persistence is implied.
- 43.7 MB review MP4 and full ~92 MB source episode: excluded to keep download small.
- Analysis proxy/WAV, synthetic fixture media and full local source-decode outputs:
  absent from delivered evidence bundles. Reports cannot replace those originals.
- Future tests, independent second-model results or final pilot: not yet done.
- Full live Notion page export: this bundle contains a labeled state summary instead.

## Source recovery
Full SRC03 episode Drive URL:
https://drive.google.com/file/d/1luhjuRlSocD9m3lz-Izen54f5Qifv52W/view
Expected full episode SHA256:
085d19e1e4afa6d5388a4703a08c635ee2213309ac1dae92cf079529f9519c92
Review excerpt filename SRC03_source_review_00-28.133_to_00-51.933.mp4
Expected SHA256:
6739164c8ccef38d7b82457daf64658ae5f5ecbfa04d613d4101f1a3f2a68e1a
Excerpt 0 maps approximately to original 28.133333 seconds.
Verify recovered files; do not infer identity from a filename.

## Portability limitations
The supplied pilot_plan.json points to /data/rextrix_project/... . Those are origin
paths, not files magically present in a new session. Do not run with guessed paths.
The preserved NVIDIA evidence scripts similarly use /data/nvidia_p02_test; use
02_nvidia/tools/analyze_av.py instead for a parameterized helper.
The new helper is syntax-checked only, NOT runtime/API-tested; historical receipts
apply to original scripts, not to this adaptation.
The project pipeline assumes SRC03's measured 30fps/44.1kHz stereo/portrait geometry
and uses specific ffmpeg filters/fonts. It is NOT a general arbitrary-video renderer.
Verify those assumptions before approved reuse. It labels BT.709; metadata tags
alone are not proof of a correct arbitrary-input color conversion.
