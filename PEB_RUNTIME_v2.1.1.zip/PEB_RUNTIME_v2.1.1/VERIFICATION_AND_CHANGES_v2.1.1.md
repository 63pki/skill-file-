# VERIFICATION AND CHANGES — v2.1.1 packaging split

Date: 2026-10-30. Task: split the operator-supplied baseline
`PEB_EDITORIAL_SYSTEM_v2.1.1` into a lightweight runtime package and an
optional reference archive. RexTrix remains **paused**; no render, upload,
provider call or publication occurred. This is a packaging task with one
scoped instruction check — no architecture change, no skill redesign.

## 1. Baseline (preserved unchanged)

| Item | Value |
|---|---|
| Baseline | `PEB_EDITORIAL_SYSTEM_v2.1.1.zip` — 26,300,007 bytes (26.30 MB / 25.08 MiB), SHA-256 `e7ae09d10c5aac6ccd15bf71abeeccda024afae804aedd44c79f8daa2a20b0ce` |
| Integrity | CRC clean; 570 files; `MANIFEST_v2.1.1.json` format reused for the split |
| Modification | **None.** The baseline ZIP was read-only for this task. |

## 2. Diagnostic clarification (scoped instruction check) — PRESENT, retained

The active master prompt `05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md` contains,
in §3 (verbatim, lines retained unchanged):

> The headline-removal and brand-removal questions are diagnostic, not
> automatic rejection rules. Legitimate scene-led entertainment and story
> spotlights remain eligible when their campaign connection is truthful and
> the brief permits them. Evaluate their actual effectiveness rather than
> forcing an app demonstration or additional narration.

The paragraph continues with the preservation riders: reject/hold only for an
actual unmet mandatory campaign requirement or an unsupported material claim,
and "This does not waive rights, truthful attribution, mandatory branded
elements or a campaign's meaningful-contribution requirement." The prompt also
states pacing diagnostics "do not become automatic hard [gates]". Machine
checks: the file is **byte-identical to the baseline** (no edit was needed or
made), and `test_diagnostic_clarification.py` passes (3/3). No conflicting
automatic-rejection instruction exists in the active prompt; the only
unconditional rejections concern evidence honesty (impossible time ranges,
invented events, repeated dialogue, fabricated proof), which are unrelated to
headline/brand treatment. Rights, truthful-claims, mandatory-branding and
meaningful-contribution requirements remain in force.

## 3. Split design (every original file accounted for)

| Rule | Contents | Files | Bytes |
|---|---|---|---|
| R1 | vision offline test fixtures stay (`04_vision_stages/fixtures/**`) | 50 | — |
| R2 | all text/code/governance (default) | 396 | — |
| A1 | `04_vision_stages/reference_review/**` past-analysis media + decode logs | 28 | 7,888,060 |
| A2 | media/binaries: catalog previews + preview reel, copyrighted reference PDF, RexTrix review JPGs, superseded nested ZIPs | 41 | 18,827,895 |
| A3 | `03_current_project/**` RexTrix history (paused; evidence only) | 39 | 234,406 |
| A4 | superseded release records (manifests/verifications v1.2–v2.1, `CHANGE_REPORT_v2.0.md`, `START_HERE_v1.3.2_HISTORY.md`) | 16 | 650,736 |

*Runtime originals total 446 files / 5,012,584 bytes; archive
originals 124 files / 27,601,097 bytes. **Omissions: 0.**

## 4. File accounting (machine-verified against the baseline)

| Result | Count |
|---|---|
| Baseline originals | 570 |
| Runtime, byte-identical | 445 |
| Archive, byte-identical | 124 |
| Originals changed (intentional, recorded) | 1 — `START_HERE.md` (§6) |
| Documented omissions | **0** |
| New in runtime | `SKILL_INDEX.md`, `ARCHIVE_POINTER.md`, `MANIFEST_RUNTIME_v2.1.1.json`, this report |
| New in archive | `README_ARCHIVE.md`, `MANIFEST_ARCHIVE_v2.1.1.json` |

Skill-file preservation: **every file under `01_preserved_system/`,
`06_system_improvement/`, `04_vision_stages/` (except nothing), `02_nvidia/`,
`05_master_prompt/` and `00_continuation/` is byte-identical to the baseline.**
Zero skill files were rewritten, simplified or deleted; no internal reference
was modified to perform the split. The count of changed skill files is **0**.

## 5. Manifests and clean-room verification

- `MANIFEST_RUNTIME_v2.1.1.json`: 449 entries — every runtime file except the
  manifest itself. Verified in a clean-room extraction: **0 hash mismatches,
  0 unlisted files**.
- `MANIFEST_ARCHIVE_v2.1.1.json`: 125 entries — every archive file except the
  manifest itself. Verified: **0 hash mismatches, 0 unlisted files**.
- Both ZIPs: CRC clean; **no self-nesting** (neither ZIP contains itself or
  its companion; the only nested ZIPs are the pre-existing superseded release
  archives inside the archive, documented in `README_ARCHIVE.md`).
- Credential pattern scan (both packages): **0 hits**. This is a pattern
  scan, not universal detection; the only key-related text is the documented
  absence of a packaged NVIDIA key (env-var name only, no value).

## 6. Changed files — complete list with reasons

| File | Change | Reason |
|---|---|---|
| `START_HERE.md` | Extended (103 → 125 lines). Inserted section "Runtime + archive split (this package)"; updated two Package-map bullets (`03_current_project` moved to archive; root delivery docs listing); updated the test-run paragraph to state all tests run without the archive. All original text preserved. | The task requires one clear root START_HERE identifying the active prompt and normal workflow in the split layout. Navigation file only — not a skill. |
| `SKILL_INDEX.md` (new) | Concise index: type, full path, when to use, dependencies, capability status, archive references for every resource. | Task requires a concise skill index; routing only — no skill content changed. |
| `ARCHIVE_POINTER.md` (new) | Names the archive, its SHA-256, the A1–A4 rules, and the reference-resolution rule. | Required so runtime references to archive-resident paths are explained, never silent. |
| `README_ARCHIVE.md` (new, in archive) | Archive-side change notes and contents summary. | Task requires change notes inside the packages. |
| `MANIFEST_*_v2.1.1.json` (new, 2 files) | Hash manifests in the baseline format. | Task requires manifests for both packages. |
| This report (new) | Verification record. | Task requires the verification report inside the package. |

## 7. Tests (run in the clean-room runtime extraction, without the archive)

| Test | Cases | Result | Note |
|---|---|---|---|
| test_record_governance.py | 21 | PASS | OK |
| test_evidence_contract.py | 30 | PASS | OK |
| test_probe_inspection.py | 5 | PASS | OK |
| test_review_and_scope_gates.py | 20 | PASS | OK |
| test_standalone_prompt.py | 7 | PASS | OK |
| test_diagnostic_clarification.py | 3 | PASS | OK |
| test_contracts.py | 12 | PASS | OK |
| test_creative_gate.py | 5 | PASS | OK |

**Total: 103 tests, 103 passed, 0 failed, 0 skipped.**
**Archive-dependent tests: NONE** — the vision offline fixtures are runtime-resident
by design, so no test was skipped and no skip is counted as a pass. This equals
the baseline's own record (100 tests at v2.1 + 3 added by the v2.1.1
diagnostic-clarification patch) rerun on the split tree. Test inputs are
unchanged by this report file's presence; the final ZIP was re-extracted and
the suite re-run to confirm identical results before delivery.

## 8. Cross-package references (all explained, none silent)

Resolution rule: any runtime-referenced path absent from the runtime exists in
`PEB_ARCHIVE_REFERENCE_v2.1.1.zip` at the **same relative path**
(see `ARCHIVE_POINTER.md`). 39 runtime documents reference
archive-resident paths; they are historical/status documents, the baseline
manifest (which by design covers all 570 baseline paths), and this split's own
navigation files:

- `00_continuation/AGENT1_LESSONS_AND_ROUTING_RULES_v1.0.md` — references 1 archive-resident path(s): `04_vision_stages/reference_review/REFERENCE_LEARNING_AND_DECISIONS.md`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/CATALOG_GUIDANCE_v1.0.md` — references 2 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/SaaS-Animation-Videos-with-Claude.pdf`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/PREVIEW-all-20-styles.mp4`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/README.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/PREVIEW-all-20-styles.mp4`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-art-deco/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-art-deco/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-ascii-art/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-ascii-art/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-bauhaus/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-bauhaus/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-blueprint/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-blueprint/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-clay-3d/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-clay-3d/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-comic-book/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-comic-book/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-glassmorphism/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-glassmorphism/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-gradient-mesh/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-gradient-mesh/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-halftone/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-halftone/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-holographic/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-holographic/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-isometric/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-isometric/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-kinetic-type/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-kinetic-type/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-liquid-morph/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-liquid-morph/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-neo-brutalism/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-neo-brutalism/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-neon-glow/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-neon-glow/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-particles/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-particles/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-pixel-art/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-pixel-art/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-retro-vhs/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-retro-vhs/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-split-flap/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-split-flap/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-wireframe-3d/SKILL.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-wireframe-3d/preview.jpg`
- `01_preserved_system/PEB_PORTABLE_v1.1.1/PACKAGE_MANIFEST.json` — references 27 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/SaaS-Animation-Videos-with-Claude.pdf`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/PREVIEW-all-20-styles.jpg`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/PREVIEW-all-20-styles.mp4`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-art-deco/preview.jpg`…
- `01_preserved_system/PEB_PORTABLE_v1.1.1/archive/ARCHIVE_INDEX.md` — references 1 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/archive/PRO_EDITOR_BRAIN_v3.1.1_TEST.zip`
- `04_vision_stages/REQUEST_INDEX.json` — references 4 archive-resident path(s): `04_vision_stages/reference_review/T1/nvidia/artifact.json`, `04_vision_stages/reference_review/T2/nvidia/artifact.json`, `04_vision_stages/reference_review/T3/nvidia/artifact.json`, `04_vision_stages/reference_review/VO/nvidia/artifact.json`
- `04_vision_stages/START_HERE.md` — references 1 archive-resident path(s): `04_vision_stages/reference_review/REFERENCE_LEARNING_AND_DECISIONS.md`
- `06_system_improvement/03_evidence/debrief_B/EVIDENCE_INDEX.json` — references 2 archive-resident path(s): `06_system_improvement/03_evidence/debrief_B/evidence/P02_existing_tail_inspection.jpg`, `06_system_improvement/03_evidence/debrief_B/evidence/P03_v02_existing_storyboard.jpg`
- `06_system_improvement/07_status/BUILD_RESULT.md` — references 1 archive-resident path(s): `PACKAGE_VERIFICATION_v1.4.0.json`
- `06_system_improvement/07_status/BUILD_RESULT_v2.0.md` — references 3 archive-resident path(s): `03_current_project/HISTORICAL_README.md`, `CHANGE_REPORT_v2.0.md`, `PACKAGE_VERIFICATION_v2.0.json`
- `06_system_improvement/07_status/CHANGELOG.md` — references 1 archive-resident path(s): `START_HERE_v1.3.2_HISTORY.md`
- `06_system_improvement/07_status/CHANGELOG_v2.0.md` — references 4 archive-resident path(s): `03_current_project/HISTORICAL_README.md`, `CHANGE_REPORT_v2.0.md`, `MANIFEST_v2.0.json`, `PACKAGE_VERIFICATION_v2.0.json`
- `06_system_improvement/07_status/CHANGELOG_v2.1.md` — references 2 archive-resident path(s): `MANIFEST_v2.1.json`, `PACKAGE_VERIFICATION_v2.1.json`
- `06_system_improvement/07_status/PATCH_REPORT_v2.1.md` — references 2 archive-resident path(s): `MANIFEST_v2.1.json`, `PACKAGE_VERIFICATION_v2.1.json`
- `ARCHIVE_POINTER.md` — references 4 archive-resident path(s): `CHANGE_REPORT_v2.0.md`, `MANIFEST_ARCHIVE_v2.1.1.json`, `README_ARCHIVE.md`, `START_HERE_v1.3.2_HISTORY.md`
- `MANIFEST_v2.1.1.json` — references 124 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/SaaS-Animation-Videos-with-Claude.pdf`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/PREVIEW-all-20-styles.jpg`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/PREVIEW-all-20-styles.mp4`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-art-deco/preview.jpg`…
- `SKILL_INDEX.md` — references 2 archive-resident path(s): `CHANGE_REPORT_v2.0.md`, `START_HERE_v1.3.2_HISTORY.md`
- `START_HERE.md` — references 3 archive-resident path(s): `03_current_project/HISTORICAL_README.md`, `CHANGE_REPORT_v2.0.md`, `START_HERE_v1.3.2_HISTORY.md`
- `VERIFICATION_AND_CHANGES_v2.1.1.md` — references 41 archive-resident path(s): `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/SaaS-Animation-Videos-with-Claude.pdf`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/PREVIEW-all-20-styles.jpg`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/PREVIEW-all-20-styles.mp4`, `01_preserved_system/PEB_PORTABLE_v1.1.1/04_catalogs_and_resources/claude-motion-styles-20/motion-art-deco/preview.jpg`…

## 9. Navigation usability check (locating check, not creative quality)

Representative tasks were walked against `SKILL_INDEX.md`; every required
resource resolves in the runtime with its dependencies stated:

| Task | Resources located | Result |
|---|---|---|
| Dialogue editing | active prompt (speech boundaries), playbook v1.2, motion-pipelines reference, project-record template | 4/4 in runtime |
| Captions | caption library, effects spec + schema, validation report | 4/4 in runtime |
| Reframing | playbook, motion-pipelines reference, tool registry | 3/3 in runtime |
| Authorized narration/graphics | vision module, NVIDIA protocol, `analyze_av.py`, style `render.py`/`template.html`, creative-gate test | 6/6 in runtime (previews optional in archive) |

This proves locating and dependency understanding only — it does not measure
taste, truth or performance.

## 10. Deliverable sizes (measured, not estimated)

| Package | Bytes | MB (10^6) | MiB (2^20) | SHA-256 |
|---|---|---|---|---|
| `PEB_ARCHIVE_REFERENCE_v2.1.1.zip` | 24,354,113 | 24.35 | 23.23 | `38d63fcd42e8402131b79e164dc7bf2fb1e5c8658a6b3a08b91f6f56d356731f` |
| `PEB_RUNTIME_v2.1.1.zip` | see delivery message* | — | — | see delivery message* |

*A file cannot contain the hash of the ZIP that carries it. The runtime ZIP's
exact byte size, decimal MB, MiB and SHA-256 are stated in the platform
delivery message and are verifiable against `MANIFEST_RUNTIME_v2.1.1.json`
coverage. Earlier projections in this conversation (~1.5 MB) were estimates;
the measured value is authoritative.

## 11. Remaining limitations (truthfulness boundary, unchanged)

- No creative pilot has been observed; editorial-judgment capability remains
  DOCUMENTED, not performance-tested. Campaign clearance: none (RexTrix
  paused; historical approvals are not current authorization). Audience
  performance: unknown.
- Vision fixture status remains INCOMPLETE_NOT_PASSED; external AV-model use
  is approval-gated and the NVIDIA key is not packaged.
- ffprobe identity remains UNPINNED; catalog render scripts are not
  feature-tested in this environment (their SKILL.md files state this).
- Credential detection was pattern-based, not exhaustive.
- Structural validators verify declared records and artifact identity — never
  taste, rights clearance or campaign truth.
