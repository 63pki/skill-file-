import sys,unittest,tempfile,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'04_components'))
from evidence_contract import validate,digest
class EvidenceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  (self.root/'output.bin').write_bytes(b'SYNTHETIC RECORD FIXTURE, NOT A VIDEO');(self.root/'evidence.json').write_text('{"synthetic":true}')
  sha=digest(self.root/'output.bin')
  self.r={'project_id':'test','campaign_state':'paused','authorizations':[], 'requirements':[{'id':'card','source_ref':'fixture only, not campaign rule','enforcement':'mandatory','applies_to':'all_outputs','metric':'card_seconds','unit':'s','min':4.5}], 'creative':{k:'synthetic example' for k in ('audience','angle','opening_picture_sound','promise','payoff_before_cta','editorial_contribution','brand_connection','selected_route','selection_reason')},'outputs':[{'id':'test','path':'output.bin','sha256':sha,'measurements':{'card_seconds':{'value':4.5,'unit':'s','evidence_ref':'evidence.json'}},'checks':[{'requirement_id':'card','status':'pass','output_sha256':sha,'method':'synthetic','scope':'record test only','evidence_ref':'evidence.json'}]}],'expected_output_ids':['test']}
  self.r['creative']['beats']=[dict(id='b',source_ref='synthetic',information_change='example',picture='example',sound='example',semantic_review={'status':'not_checked','reason':'fixture only'})]
  self.r['reviews']=[{'id':'R1','output_id':'test','output_sha256':sha,'basis':'actual_export','opening_observed':'synthetic opening observed on fixture','payoff_observed':'synthetic payoff observed on fixture','sound_observed':'synthetic sound observed on fixture','headline_removal':'no headline used; scene stands on its own','biggest_defect':'none observed; synthetic fixture','verdict':'approved'}]
 def tearDown(self):self.tmp.cleanup()
 def fail_record(self):self.assertTrue(validate(self.r,self.root))
 def test_valid_record_is_not_media_pass(self):self.assertFalse(validate(self.r,self.root))
 def test_empty_record(self):self.assertTrue(validate({},self.root))
 def test_empty_output_set(self):self.r.update(outputs=[],expected_output_ids=[]);self.fail_record()
 def test_missing_expected_output(self):self.r['expected_output_ids'].append('missing');self.fail_record()
 def test_duplicate_output(self):self.r['outputs']*=2;self.fail_record()
 def test_missing_reference(self):self.r['outputs'][0]['checks'][0]['evidence_ref']='absent';self.fail_record()
 def test_empty_reference(self):(self.root/'evidence.json').write_text('');self.fail_record()
 def test_missing_output(self):(self.root/'output.bin').unlink();self.fail_record()
 def test_hash_mismatch(self):(self.root/'output.bin').write_bytes(b'new version');self.fail_record()
 def test_stale_qc(self):self.r['outputs'][0]['checks'][0]['output_sha256']='old';self.fail_record()
 def test_mandatory_not_checked(self):self.r['outputs'][0]['checks'][0].update(status='not_checked',reason='not listened');self.fail_record()
 def test_partial_gate_set(self):self.r['requirements'].append(dict(id='language',source_ref='fixture',applies_to='all_outputs',enforcement='mandatory'));self.fail_record()
 def test_three_second_card(self):self.r['outputs'][0]['measurements']['card_seconds']['value']=3;self.fail_record()
 def test_unit_confusion(self):self.r['outputs'][0]['measurements']['card_seconds']['unit']='frames';self.fail_record()
 def test_nan(self):self.r['outputs'][0]['measurements']['card_seconds']['value']=float('nan');self.fail_record()
 def test_rule_conflict(self):self.r['open_requirement_conflicts']=['3s vs4.5s'];self.fail_record()
 def test_duplicate_requirement(self):self.r['requirements']*=2;self.fail_record()
 def test_missing_method(self):del self.r['outputs'][0]['checks'][0]['method'];self.fail_record()
 def test_path_escape(self):self.r['outputs'][0]['checks'][0]['evidence_ref']='../outside';self.fail_record()
 def test_no_arbitrary_unlinked_beats(self):del self.r['creative']['beats'][0]['source_ref'];self.fail_record()
 def test_preferences_not_hard_gates(self):self.r['requirements'].append(dict(id='pace',source_ref='taste',applies_to='all_outputs',enforcement='preference'));self.assertFalse(validate(self.r,self.root))
 def test_paused_publication(self):self.assertTrue(validate(self.r,self.root,'publish'))
 def test_active_without_authority(self):self.r['campaign_state']='active';self.assertTrue(validate(self.r,self.root,'publish'))
 def test_authorized_publication_record(self):self.r.update(campaign_state='active',authorizations=[{'action':'publish','active':True,'reference':'synthetic fixture permission'}]);self.assertFalse(validate(self.r,self.root,'publish'))
 def test_no_silent_rule_replacement(self):self.r['learning_changes']=[{'id':'new','action':'supersede'}];self.fail_record()
 def test_routine_plan_needs_no_new_three_route_report(self):self.assertFalse(validate(self.r,self.root,'plan'))
 def test_diagnostics_not_mandatory(self):self.r['requirements'].append(dict(id='freeze',source_ref='diagnostic',applies_to='all_outputs',enforcement='preference'));self.assertFalse(validate(self.r,self.root))
 def test_card_only_repair_does_not_hide_bad_runtime(self):
  self.r['requirements'].append(dict(id='runtime',source_ref='fixture',enforcement='mandatory',applies_to='all_outputs',metric='runtime_seconds',unit='s',min=15,max=25))
  self.r['outputs'][0]['measurements']['runtime_seconds']={'value':12.9,'unit':'s','evidence_ref':'evidence.json'}
  self.r['outputs'][0]['checks'].append(dict(requirement_id='runtime',status='pass',output_sha256=self.r['outputs'][0]['sha256'],method='fixture',scope='synthetic',evidence_ref='evidence.json'))
  self.fail_record()
 def test_explicit_different_campaign_requirement_allowed(self):
  self.r['requirements'][0].update(min=3,source_ref='explicit different campaign brief',amendment_of='old brief')
  self.r['outputs'][0]['measurements']['card_seconds']['value']=3
  self.assertFalse(validate(self.r,self.root))
 def test_non_pass_without_reason(self):
  self.r['outputs'][0]['checks'][0]['status']='not_checked';self.fail_record()
if __name__=='__main__':unittest.main()
