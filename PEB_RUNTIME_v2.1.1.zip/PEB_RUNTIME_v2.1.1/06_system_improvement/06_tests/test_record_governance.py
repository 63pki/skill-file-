"""v2.0 governance tests: reviews, exceptions, overrides, and counterexamples
proving the validator does NOT force a template (minimal scene-led, commentary,
and comparison records all pass without VO/graphics/effect rows)."""
import sys,unittest,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'04_components'))
from evidence_contract import validate,digest

def base_record(root):
    (root/'out.mp4').write_bytes(b'SYNTHETIC OUTPUT FIXTURE, NOT A VIDEO')
    (root/'ev.json').write_text('{"synthetic":true}')
    sha=digest(root/'out.mp4')
    r={'project_id':'governance-test','campaign_state':'paused','authorizations':[],
       'requirements':[{'id':'card','source_ref':'fixture only','enforcement':'mandatory','applies_to':'all_outputs','metric':'card_seconds','unit':'s','min':3}],
       'creative':{'audience':'fixture viewer','angle':'fixture angle','opening_picture_sound':'fixture opening','promise':'fixture promise',
                   'payoff_before_cta':'fixture payoff','editorial_contribution':'selection and pacing only',
                   'brand_connection':'paratextual per brief','selected_route':'scene_led','selection_reason':'strongest complete scene',
                   'beats':[{'id':'b1','source_ref':'fixture 0-10s','information_change':'setup and payoff','picture':'two-shot','sound':'native dialogue','semantic_review':{'status':'reviewed','reason':'fixture transcript read'}}]},
       'outputs':[{'id':'o1','path':'out.mp4','sha256':sha,
                   'measurements':{'card_seconds':{'value':3,'unit':'s','evidence_ref':'ev.json'}},
                   'checks':[{'requirement_id':'card','status':'pass','output_sha256':sha,'method':'synthetic','scope':'fixture','evidence_ref':'ev.json'}]}],
       'expected_output_ids':['o1'],
       'reviews':[{'id':'R1','output_id':'o1','output_sha256':sha,'basis':'actual_export','opening_observed':'two-shot, dialogue starts immediately','payoff_observed':'punchline completes before card','sound_observed':'native dialogue, card silence on PCM','headline_removal':'no headline used; scene stands on its own','biggest_defect':'none observed on fixture','verdict':'approved'}]}
    return r

class GovernanceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.r=base_record(self.root)
 def tearDown(self):self.tmp.cleanup()
 def fail_record(self,stage='delivery'):self.assertTrue(validate(self.r,self.root,stage))
 # --- valid cases ---
 def test_minimal_scene_led_record_passes_delivery(self):
  """Counterexample vs overstrict rules: no VO, no graphics, no captions, one beat."""
  self.assertFalse(validate(self.r,self.root,'delivery'))
 def test_commentary_route_with_vo_authorization_passes(self):
  """Counterexample: commentary record must not be rejected for having VO."""
  self.r['creative'].update(selected_route='narrative_led',selection_reason='supported contrast')
  self.r['authorizations']=[{'action':'render','active':True,'reference':'fixture VO permission'}]
  self.r['creative']['beats'].append({'id':'b2','source_ref':'fixture 10-20s','information_change':'authored contrast','picture':'selects','sound':'authorized VO over ambience','semantic_review':{'status':'not_checked','reason':'fixture only'}})
  self.assertFalse(validate(self.r,self.root,'delivery'))
 def test_comparison_route_two_sources_passes(self):
  """Counterexample: a meaningful two-source comparison is a valid idea record."""
  self.r['creative'].update(selected_route='comparison',selection_reason='supported relationship')
  self.r['creative']['beats']=[{'id':'c1','source_ref':'fixture A 0-5s + fixture B 0-5s','information_change':'side-by-side contrast','picture':'split screen','sound':'both native, sequenced','semantic_review':{'status':'reviewed','reason':'fixture frames read'}}]
  self.assertFalse(validate(self.r,self.root,'delivery'))
 def test_plan_stage_needs_no_reviews(self):
  self.r['reviews']=[];self.assertFalse(validate(self.r,self.root,'plan'))
 # --- reviews ---
 def test_delivery_without_reviews_fails(self):
  self.r['reviews']=[];self.fail_record()
 def test_review_missing_field_fails(self):
  del self.r['reviews'][0]['payoff_observed'];self.fail_record()
 def test_review_wrong_basis_fails(self):
  self.r['reviews'][0]['basis']='plan_imagination';self.fail_record()
 def test_review_bad_verdict_fails(self):
  self.r['reviews'][0]['verdict']='great';self.fail_record()
 def test_review_unknown_output_fails(self):
  self.r['reviews'][0]['output_id']='ghost';self.fail_record()
 def test_output_without_review_fails(self):
  (self.root/'out2.mp4').write_bytes(b'SECOND SYNTHETIC FIXTURE')
  sha=digest(self.root/'out2.mp4')
  self.r['expected_output_ids'].append('o2')
  self.r['outputs'].append({'id':'o2','path':'out2.mp4','sha256':sha,'measurements':{'card_seconds':{'value':3,'unit':'s','evidence_ref':'ev.json'}},'checks':[{'requirement_id':'card','status':'pass','output_sha256':sha,'method':'synthetic','scope':'fixture','evidence_ref':'ev.json'}]})
  self.fail_record()
 def test_review_headline_removal_can_explain_no_headline(self):
  """The counterfactual question is answered, not gamed: naming 'no headline' is valid."""
  self.r['reviews'][0]['headline_removal']='no headline used; scene stands on its own'
  self.assertFalse(validate(self.r,self.root,'delivery'))
 # --- exceptions ---
 def test_pending_exception_blocks_publish_not_delivery(self):
  self.r['exceptions']=[{'id':'card2.5','scope':'this batch only','decision':'pending'}]
  self.fail_record('publish')
  self.assertFalse(validate(self.r,self.root,'delivery'))
 def test_adopted_exception_allows_publish(self):
  self.r.update(campaign_state='active',authorizations=[{'action':'publish','active':True,'reference':'fixture permission'}])
  self.r['exceptions']=[{'id':'card2.5','scope':'this batch only','decision':'adopted','note':'adopted by operator before next batch'}]
  self.assertFalse(validate(self.r,self.root,'publish'))
 def test_invalid_exception_decision_fails(self):
  self.r['exceptions']=[{'id':'x','scope':'s','decision':'kept forever silently'}];self.fail_record()
 def test_exception_missing_scope_fails(self):
  self.r['exceptions']=[{'id':'x','decision':'adopted'}];self.fail_record()
 # --- overrides ---
 def test_fit_warning_override_without_override_entry_fails(self):
  self.r['creative']['fit_warning_override']='ov1';self.fail_record()
 def test_recorded_override_passes(self):
  self.r['creative']['fit_warning_override']='ov1'
  self.r['overrides']=[{'id':'ov1','overrides_ref':'scout note g5: weakest fit','reason':'campaign requires this window; risk recorded'}]
  self.assertFalse(validate(self.r,self.root,'delivery'))
 def test_override_without_reason_fails(self):
  self.r['overrides']=[{'id':'ov1','overrides_ref':'scout note'}];self.fail_record()
 def test_duplicate_override_ids_fail(self):
  self.r['overrides']=[{'id':'ov1','overrides_ref':'a','reason':'r'},{'id':'ov1','overrides_ref':'b','reason':'r'}];self.fail_record()
 # --- authority/publish interplay unchanged ---
 def test_paused_publish_still_fails(self):
  self.fail_record('publish')
 def test_authorized_publish_passes(self):
  self.r.update(campaign_state='active',authorizations=[{'action':'publish','active':True,'reference':'fixture permission'}])
  self.assertFalse(validate(self.r,self.root,'publish'))
if __name__=='__main__':unittest.main()
