"""Narrow wording regression checks; not tests of artistic judgment."""
from pathlib import Path
import unittest
P=Path(__file__).resolve().parents[2]/'05_master_prompt'/'PRO_EDITOR_BRAIN_v4.1.md'
class DiagnosticClarificationTests(unittest.TestCase):
 def setUp(self):self.text=' '.join(P.read_text().split())
 def test_counterfactual_is_diagnostic(self):self.assertIn('headline-removal and brand-removal questions are diagnostic, not automatic rejection rules',self.text)
 def test_scene_led_and_spotlights_eligible(self):
  self.assertIn('Legitimate scene-led entertainment and story spotlights remain eligible',self.text)
  self.assertIn('rather than forcing an app demonstration or additional narration',self.text)
 def test_requirements_preserved_without_old_rejection(self):
  self.assertIn("a campaign's meaningful-contribution requirement",self.text)
  self.assertNotIn('report the gap instead of shipping packaging',self.text)
if __name__=='__main__':unittest.main()
