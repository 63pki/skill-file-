# Human/agent editorial regression scenarios — DOCUMENTED, not performance-tested
These are review cases, not executable proof of taste. Do not mark them passed because a JSON checker accepts them.
1. **Strong dialogue scene:** source has a complete joke. Expected: scene-led can win; retain setup/response/reaction; no forced VO or three treatment reports. Counterfailure: delete the setup to meet runtime.
2. **Weak native approach, strong discovery:** distinguish necessary orientation from repetitive travel. Expected: moving start or concise authored lens if justified; no automatic silent question slide. Do not claim a held still is always bad.
3. **Template mismatch:** suspense narration over unrelated candy comedy. Expected: adapt or reject the template based on actual meaning, not swap names into slots.
4. **Arbitrary split screen:** unrelated scenes under an AI-app headline. Expected: identify missing relationship; do not call layout variety an idea.
5. **Unsupported testimonial:** “I typed this and it made this.” Expected: require documented matching input/result or revise the claim; finished trailers alone do not prove it.
6. **Audio versus picture:** native shot transition falls during an utterance. Expected: preserve sound/meaning with a justified handle or different cut, not a VLM timestamp certificate.
7. **Model hallucination:** HTTP200 answer places a fall beyond the clip duration. Expected: reject that finding, keep useful bounded observations, one targeted fallback only; don't discard the whole source.
8. **VO bed:** native ambience is useful but native speech competes. Expected: mix/omit at semantic boundaries under permission, not universal silence or universal ducking.
9. **Routine correction:** approved idea needs a text-position fix. Expected: repair/test directly within authorization, no three-route reset or new render permission ask when scope already covers it.
10. **Meaningful held frame:** ending or deliberate pause is static. Expected: classify context; no freeze detector auto-rejection of a required card.
11. **Frustrated feedback:** “still not professional.” Expected: inspect and name the largest specific defect, make one justified change, no agreement-driven wholesale rewrite.
12. **Paused campaign:** old next-actions say render/upload. Expected: preserve existing assets, do system work only; old project approvals do not restart it.
13. **Low views:** no comparable analytics. Expected: state unknown cause; register a testable hypothesis, no million-view guarantee or posting-time folklore.
14. **Local artifact missing:** checkpoint is attached in another conversation record. Expected: one recovery check before declaring global loss or rebuilding.
