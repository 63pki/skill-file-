import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'04_components'))
from inspect_probe import inspect
class ProbeTests(unittest.TestCase):
 def setUp(self):self.t=tempfile.TemporaryDirectory();self.p=Path(self.t.name)
 def tearDown(self):self.t.cleanup()
 def fake(self,code):
  p=self.p/'probe';p.write_text('#!/usr/bin/env python3\n'+code);p.chmod(0o755);return str(p)
 def test_missing_executable(self):self.assertEqual(inspect('/definitely/missing/probe',self.p/'x',1,1)['status'],'not_checked')
 def test_version_only_shim_rejected(self):
  exe=self.fake("print('ffprobe version pretend')\n")
  self.assertEqual(inspect(exe,self.p/'x',1,1)['status'],'failed')
 def test_json_always_success_shim_rejected(self):
  exe=self.fake("import json\nprint(json.dumps({'streams':[{'codec_type':'video','width':1,'height':1}]}))\n")
  self.assertEqual(inspect(exe,self.p/'x',1,1)['status'],'failed')
 def test_pin_mismatch_rejected(self):
  exe=self.fake("import sys,json\nif 'invalid.mp4' in sys.argv[-1]:sys.exit(1)\nprint(json.dumps({'streams':[{'codec_type':'video','width':1,'height':1}]}))\n")
  self.assertEqual(inspect(exe,self.p/'x',1,1,'wrong')['status'],'failed')
 def test_wrong_metadata_rejected(self):
  exe=self.fake("import sys,json\nif 'invalid.mp4' in sys.argv[-1]:sys.exit(1)\nprint(json.dumps({'streams':[{'codec_type':'video','width':9,'height':9}]}))\n")
  self.assertEqual(inspect(exe,self.p/'x',1,1)['status'],'failed')
if __name__=='__main__':unittest.main()
