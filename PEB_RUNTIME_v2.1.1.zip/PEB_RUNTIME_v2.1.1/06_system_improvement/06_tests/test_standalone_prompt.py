"""Standalone-prompt guard: the consolidated master prompt must be genuinely
standalone, campaign-agnostic, and explicitly separate required environment
from optional packaged tools. A regression that re-embeds a paused campaign's
numbers as defaults fails here."""
import unittest
from pathlib import Path
PROMPT=Path(__file__).resolve().parents[2]/'05_master_prompt'/'PRO_EDITOR_BRAIN_v4.1.md'
class StandalonePromptTests(unittest.TestCase):
 def setUp(self):
  self.assertTrue(PROMPT.is_file(),'standalone master prompt missing from package')
  self.text=PROMPT.read_text(encoding='utf-8')
 def test_nontrivial(self):self.assertGreater(len(self.text),8000)
 def test_required_sections_present(self):
  for section in ('PRECEDENCE AND STANDALONE USE','REQUIRED ENVIRONMENT','OPTIONAL PACKAGED TOOLS',
                  'evidence labels','Establish the effective job','Review the exact export',
                  'Calibrate, then scale','Measurement hygiene','Recoveries and failure modes'):
   self.assertIn(section,self.text)
 def test_required_vs_optional_explicit(self):
  self.assertIn('REQUIRED ENVIRONMENT',self.text)
  self.assertIn('OPTIONAL PACKAGED TOOLS',self.text)
  self.assertIn('not required to edit',self.text)
 def test_no_paused_campaign_identity_or_numbers_as_defaults(self):
  """RexTrix-specific values must never become universal defaults inside the prompt."""
  import re
  self.assertNotIn('RexTrix',self.text)
  for pattern in (r'\b135\b',r'15[–-]25',r'\b4\.5\b'):
   self.assertIsNone(re.search(pattern,self.text),'forbidden campaign-specific token: '+pattern)
 def test_evidence_labels_and_capability_states_present(self):
  for token in ('OBSERVED','TESTED','HYPOTHESIS','UNKNOWN','not_checked','approved-for-project'):
   self.assertIn(token,self.text)
 def test_review_integrity_rules_present(self):
  """v2.1 patch lock: the hash-binding, verdict-gate and brief-boundary rules are in the active prompt."""
  for token in ('bound to that output\'s current SHA-256','unresolved hold or revise verdicts block acceptance',
                'provisional','campaign brief controls campaign parameters',
                'not permission to fabricate evidence'):
   self.assertIn(token,self.text)
 def test_neutrality_both_directions(self):
  """Neither 'more effects' nor 'more restraint' may be declared the solution."""
  self.assertIn('not automatically a complete creative solution',self.text)
  self.assertIn('Nor are voiceover, motion graphics or complexity automatic improvements',self.text)
  self.assertIn('A strong self-contained scene is valid',self.text)
if __name__=='__main__':unittest.main()
