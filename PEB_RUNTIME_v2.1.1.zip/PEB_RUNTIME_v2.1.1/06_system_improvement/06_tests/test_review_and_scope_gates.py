"""v2.1 review-binding and scope gates — valid paths must pass; fake/stale must block.

Ported from the v1.4.2 bounded patch and adapted to the reconciled v2.1
contract (v2.0 review shape: five observed fields + actual_export basis;
coverage requires one review per output). Verdict vocabulary: approved (the
documented v2.0-era alias 'deliver' must behave identically).

Positive cases pin the two paths the patch must preserve:
  1. a clearly labeled provisional review draft passes DELIVERY validation;
  2. a corrected, hash-bound publication record passes PUBLISH validation
     (including a hold explicitly resolved by an approved review of the SAME bytes).
Negative cases pin every new rejection rule: missing/mismatched review hashes,
reviews of nonexistent outputs, unresolved hold/revise at publish, provisional
drafts at publish, invalid resolution links, and requirement scopes that
reference output ids that do not exist (the typo that would make a mandatory
check silently vanish). Runs against the v2.1 evidence_contract.validate().
"""
import sys, tempfile, unittest, hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / '04_components'))
from evidence_contract import validate, digest


def observed_fields(tag='cold-viewer pass on the exact export; opening reads, payoff registers; sound as planned'):
    return {'basis': 'actual_export',
            'opening_observed': tag + ' — opening',
            'payoff_observed': tag + ' — payoff',
            'sound_observed': tag + ' — sound',
            'headline_removal': 'no headline used; scene stands on its own',
            'biggest_defect': 'none observed; synthetic fixture'}


def base_record(sha1, sha2):
    creative_core = {k: 'synthetic' for k in ('audience', 'angle', 'opening_picture_sound',
                     'promise', 'payoff_before_cta', 'editorial_contribution',
                     'brand_connection', 'selected_route', 'selection_reason')}
    creative_core['beats'] = [{'id': 'b1', 'source_ref': 'synthetic', 'information_change': 'x',
                               'picture': 'x', 'sound': 'x',
                               'semantic_review': {'status': 'not_checked', 'reason': 'fixture'}}]
    return {
        'project_id': 'review-gates', 'campaign_state': 'paused', 'authorizations': [],
        'requirements': [
            {'id': 'card', 'source_ref': 'fixture only, not a campaign rule', 'enforcement': 'mandatory',
             'applies_to': 'out1', 'metric': 'card_seconds', 'unit': 's', 'min': 4.5},
        ],
        'creative': creative_core,
        'outputs': [
            {'id': 'out1', 'path': 'out1.bin', 'sha256': sha1,
             'measurements': {'card_seconds': {'value': 4.6, 'unit': 's', 'evidence_ref': 'evidence.json'}},
             'checks': [{'requirement_id': 'card', 'status': 'pass', 'output_sha256': sha1,
                         'method': 'synthetic', 'scope': 'fixture', 'evidence_ref': 'evidence.json'}]},
            {'id': 'out2', 'path': 'out2.bin', 'sha256': sha2, 'measurements': {}, 'checks': []},
        ],
        'expected_output_ids': ['out1', 'out2'],
        'reviews': [
            dict(id='R1', output_id='out1', output_sha256=sha1, verdict='approved', **observed_fields()),
            dict(id='R2', output_id='out2', output_sha256=sha2, verdict='approved', **observed_fields()),
        ],
    }


class ReviewGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
        (self.root / 'out1.bin').write_bytes(b'FIXTURE OUT1 NOT A VIDEO')
        (self.root / 'out2.bin').write_bytes(b'FIXTURE OUT2 NOT A VIDEO')
        (self.root / 'evidence.json').write_text('{"synthetic": true}')
        self.sha1 = hashlib.sha256((self.root / 'out1.bin').read_bytes()).hexdigest()
        self.sha2 = hashlib.sha256((self.root / 'out2.bin').read_bytes()).hexdigest()
        self.r = base_record(self.sha1, self.sha2)

    def tearDown(self): self.tmp.cleanup()

    def pub(self):
        self.r['campaign_state'] = 'active'
        self.r['authorizations'] = [{'action': 'publish', 'active': True,
                                     'reference': 'synthetic fixture permission'}]

    # ----- valid paths must pass -----
    def test_valid_hash_bound_approval_passes_delivery_and_publish(self):
        self.assertFalse(validate(self.r, self.root))
        self.pub()
        self.assertFalse(validate(self.r, self.root, 'publish'))

    def test_clearly_labeled_provisional_draft_passes_delivery(self):
        self.r['reviews'] = [dict(id='R1', output_id='out1', output_sha256=self.sha1,
                                  verdict='provisional_draft',
                                  biggest_defect='payoff unverified against a second viewer',
                                  **{k: v for k, v in observed_fields().items() if k != 'biggest_defect'}),
                             self.r['reviews'][1]]
        self.assertFalse(validate(self.r, self.root))  # delivery preserved, label carried by verdict

    def test_unresolved_hold_still_delivers_but_blocks_publish(self):
        self.r['reviews'][0]['verdict'] = 'hold'
        self.assertFalse(validate(self.r, self.root))            # delivery path preserved
        self.pub()
        self.assertTrue(validate(self.r, self.root, 'publish'))  # publish blocked

    def test_hold_resolved_by_approval_of_same_bytes_passes_publish(self):
        self.r['reviews'][0]['verdict'] = 'hold'
        self.r['reviews'].append(dict(id='R3', output_id='out1', output_sha256=self.sha1,
                                      verdict='approved',
                                      findings_note='re-review of identical bytes; concern addressed, output unchanged',
                                      **observed_fields()))
        self.r['reviews'][0]['resolved_by'] = 'R3'
        self.pub()
        self.assertFalse(validate(self.r, self.root, 'publish'))

    def test_corrected_stale_review_rebound_to_current_hash_passes(self):
        (self.root / 'out1.bin').write_bytes(b'FIXTURE OUT1 REVISED BYTES')
        new_sha = hashlib.sha256((self.root / 'out1.bin').read_bytes()).hexdigest()
        self.r['outputs'][0]['sha256'] = new_sha
        self.r['outputs'][0]['checks'][0]['output_sha256'] = new_sha
        self.assertTrue(validate(self.r, self.root))   # stale-bound review rejected...
        self.r['reviews'][0]['output_sha256'] = new_sha  # ...corrected: re-recorded against current bytes
        self.assertFalse(validate(self.r, self.root))

    def test_scope_to_existing_output_passes(self):
        # counterexample guard: a correctly scoped mandatory row must not be rejected
        self.assertFalse(validate(self.r, self.root))

    def test_v2_0_era_deliver_alias_behaves_as_approved(self):
        self.r['reviews'][0]['verdict'] = 'deliver'
        self.assertFalse(validate(self.r, self.root))
        self.pub()
        self.assertFalse(validate(self.r, self.root, 'publish'))

    # ----- fake/stale/typo must be blocked -----
    def test_review_missing_hash_rejected_at_delivery(self):
        del self.r['reviews'][0]['output_sha256']
        self.assertTrue(validate(self.r, self.root))

    def test_stale_review_hash_rejected_after_output_change(self):
        (self.root / 'out1.bin').write_bytes(b'FIXTURE OUT1 REVISED BYTES')
        new_sha = hashlib.sha256((self.root / 'out1.bin').read_bytes()).hexdigest()
        self.r['outputs'][0]['sha256'] = new_sha
        self.r['outputs'][0]['checks'][0]['output_sha256'] = new_sha
        self.assertTrue(validate(self.r, self.root))

    def test_review_of_nonexistent_output_rejected(self):
        self.r['reviews'][0]['output_id'] = 'ghost_output'
        self.assertTrue(validate(self.r, self.root))

    def test_duplicate_review_id_rejected(self):
        self.r['reviews'].append(dict(self.r['reviews'][0]))
        self.assertTrue(validate(self.r, self.root))

    def test_invalid_verdict_rejected(self):
        self.r['reviews'][0]['verdict'] = 'looks_fine'
        self.assertTrue(validate(self.r, self.root))

    def test_review_missing_observed_field_rejected(self):
        del self.r['reviews'][0]['payoff_observed']
        self.assertTrue(validate(self.r, self.root))

    def test_review_wrong_basis_rejected(self):
        self.r['reviews'][0]['basis'] = 'plan_imagination'
        self.assertTrue(validate(self.r, self.root))

    def test_unresolved_hold_blocks_publish(self):
        self.r['reviews'][0]['verdict'] = 'hold'
        self.pub()
        errors = validate(self.r, self.root, 'publish')
        self.assertTrue(any('Unresolved hold' in e for e in errors))

    def test_unresolved_revise_blocks_publish(self):
        self.r['reviews'][0]['verdict'] = 'revise'
        self.pub()
        errors = validate(self.r, self.root, 'publish')
        self.assertTrue(any('Unresolved revise' in e for e in errors))

    def test_provisional_draft_is_not_a_publish_verdict(self):
        self.r['reviews'][0]['verdict'] = 'provisional_draft'
        self.pub()
        errors = validate(self.r, self.root, 'publish')
        self.assertTrue(any('Provisional review draft is not a publish verdict' in e for e in errors))

    def test_resolution_must_reference_existing_approved_same_bytes_review(self):
        self.r['reviews'][0]['verdict'] = 'hold'
        self.r['reviews'][0]['resolved_by'] = 'R9'  # R9 does not exist
        self.pub()
        self.assertTrue(validate(self.r, self.root, 'publish'))
        self.r['reviews'].append(dict(id='R9', output_id='out1', output_sha256=self.sha2,
                                      verdict='approved', **observed_fields('different bytes')))
        self.assertTrue(validate(self.r, self.root, 'publish'))  # same output, wrong hash -> still blocked
        self.r['reviews'][2]['verdict'] = 'hold'
        self.assertTrue(validate(self.r, self.root, 'publish'))  # non-approved resolver -> still blocked

    def test_requirement_scope_typo_rejected_at_delivery_and_plan(self):
        self.r['requirements'][0]['applies_to'] = 'out3'  # typo; outputs are out1/out2
        self.assertTrue(validate(self.r, self.root))
        self.assertTrue(validate(self.r, self.root, 'plan'))

    def test_plan_scoped_requirement_needs_declared_expected_ids(self):
        self.r['expected_output_ids'] = []
        self.assertTrue(validate(self.r, self.root, 'plan'))  # scoped row names an output the plan refuses to declare


if __name__ == '__main__':
    unittest.main()
