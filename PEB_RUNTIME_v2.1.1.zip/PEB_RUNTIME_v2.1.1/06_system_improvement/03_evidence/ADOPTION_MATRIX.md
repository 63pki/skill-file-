# Consolidation and adoption decisions
## Evidence boundaries
Imported ledger A has 24 findings; B has 28: 52 attributed entries, not 52 independently reproduced tests. All original ledgers and supplied evidence survive unchanged. Report agreement is not independent verification. Some evidence paths describe files in an agent's old runtime and do not exist in this ZIP.

The additional pasted narrative about 30 split-screen clips at10.90s/3s cards, a fake ffprobe, missing22rules and nonexistent hash references is NOT established by ledger A. Its attached executive summary instead describes34 batch-30 passes plus12 batch-15, a different set of issues and repaired measurement methods. The narrative may describe another batch/runtime. Do not merge the populations, accuse a tool of fakery as verified, or declare30/30 failed without identifying and inspecting the actual outputs/code. These assertions justify negative regression tests, not historical certainty.

B's 'missing locally' C01 export/checkpoint is not proof of global loss: attachments in this conversation previously supplied them. Cross-agent recovery must distinguish local absence from loss. This system-update package does not duplicate all production footage or assert fresh C01 QC.

## Decisions by evidence group
| Evidence | Decision | Scope / counterexample |
|---|---|---|
| A F-15,F-24; B F04-F06,F09,F26 | Adopt compact authored-idea/beat/brand decision and actual-export judgment | Strong scene-led work can win; do not demand effects or original narration |
| A F-04,F-18; B F27 | Adopt honest eligible counts and controlled changes mid-batch | A numeric assignment is not itself evidence of filler |
| A F-05,F-13,F-14; B F02,F07-F08,F10-F13,F17,F20 | Adopt multimodal scope, source verification and labeled interpretation | No VLM-only exact boundaries; no forced successful rescue/app demonstration |
| A F-02,F-03,F-10,F-12,F-21-F22; B F16,F18-F19,F23-F24 | Adopt evidence references, version binding, method scope and capability/recovery checks | Recipes are not final-mix measurements; derivative is not bit-identical source |
| A F-01; B F14-F15,F22 | Adopt campaign-state/action-specific permission and supported credential routes | Local editing does not require repeated permission; no absent-secret-setter loop |
| A F-06-F08,F-15; B F03-F05,F21 | Playbook options and explicit template-fit reasons, not global bans | Source bed under VO, split screens, freezes, caption position and quiet mixes are contextual |
| A F-09 'source bed under VO is always a defect' | Do not generalize | Competing speech can be defective; ambience/music can be appropriate and permitted |
| A F-16,F-19-F20,F-23; B F25,F28 | Preserve hypothesis/unknown and severity boundaries | No causal view claims, no taste auto-fail, no mandatory app demo |
| A recommendation of independent QC for every pass | Preserve useful separation of build and review, not compulsory subagents | Reproducible checks and fresh review can occur without another agent; no subagent use authorized by this update |
| Missing references, no-op comparisons, stale rules, substitute verifier (pasted narrative) | Add adversarial contract tests; historical claim unresolved | Inspect original code/output if later available; don't silently call them proven |

## Deferred / not adopted
No millions-of-views rule; no universal15–25s,4.5s card, font, caption position, original-audio policy, loudness number, ban on freezes, ban on source audio under VO, or mandatory narrator. These are campaign constraints or contextual choices, not general laws.
No forced B08 recheck, campaign repair or new broad search: RexTrix is paused.
No claim that improved documentation alone fixes artistic performance. The next authorized campaign needs a real pilot calibration and later matched analytics.
