# Categorized learnings — RexTrix editing debrief (2026-10-30)

Companion to `EXECUTIVE_SUMMARY.md`. Same evidence labels: OBSERVED,
TESTED (scope stated), HYPOTHESIS, UNKNOWN. "Builder claim" means a
subagent's report not yet independently reproduced; "parent-verified" means
the main agent reproduced it from the delivered file. "Campaign rule" means
the Content Rewards campaign's own rules; "house rule" means a rule this
project set itself (card length, caption systems, loudness targets) — the
two are not interchangeable, and several findings below turn on confusing
them.

---

## 2. Actual scope and outputs

### Assigned task and audience / campaign objective

- **Batch-30 (2026-10-29 brief):** 30 professional, intentional,
  retention-optimized clips, hook in 1–3s, complete thought resolving
  before the end card, no dead air, no mid-sentence cuts, no gimmick
  padding, delivered READY TO UPLOAD (not uploaded). OBSERVED from
  `batch-30/PRODUCTION_BRIEF.md`.
- **Batch-15 cinematic (2026-10-29):** 15 clips on a user-supplied lore
  template, separately from the 30, then a warning-template batch after
  them (count never specified). OBSERVED from `batch-15/EXECUTION_SCRIPT_CINEMATIC.md`
  and `batch-15/QUEUE_WARNING_BATCH.md`.
- **Voiceover pilot:** one script-led clip proving a VO workflow.
  OBSERVED from `new-batch-7/voiceover-pilot/REVIEW.md`.
- **T-drafts:** rebuild three user-supplied drafts (debunk, split-screen,
  addiction-loop) from source footage with semantic cards. OBSERVED from
  `t-drafts/REBUILD_NOTES.md`.
- **Audience (as briefed, not as measured):** US Shorts viewers, gaming
  and drama fans; posting ~10 PM–1 AM PKT for US evenings; 40%+ US audience
  on the posting account (campaign rule). No audience research, survey, or
  retention pull is on record for any batch. UNKNOWN: whether the actual
  audience matches this description.
- **Campaign objective:** $2.00/1K views, payouts from 500 views, max
  $200/clip on the campaign page (rules doc says $300/post — discrepancy
  on record, unresolved). Carried from the prior session's campaign-page
  and manifest records, not re-verified today.

### Prompt / package / core version actually used

- Batch-30: `PRODUCTION_BRIEF.md` (2026-10-29) + `CLIP_RULES.md` (last
  updated 2026-10-29, §10 added 2026-10-30) + `NEVER_REPEAT_RULES.md`
  (created 2026-10-30, 34 entries). OBSERVED (files read, hashes in
  `EVIDENCE_INDEX.json`).
- Batch-15: `EXECUTION_SCRIPT_CINEMATIC.md` (master monologue ~60 words /
  ~22s, name → trait → sentence → stakes → invitation) + group A/B/C
  scout packages + `CLIP_RULES.md`. The warning script
  (`EXECUTION_SCRIPT_WARNING.md`) is a reference recipe only — see §4.
- Campaign brief: `CAMPAIGN_BRIEF_Rextrix.md`, READY_FOR_MASTER_INTAKE,
  revised 2026-10-27 per `SCOUT_CORRECTION_NOTES.md` (CR-1..CR-6).
- Per-clip spec actually enforced: 1080x1920 30fps, H.264 slow CRF 16,
  yuv420p, AAC 192k, faststart; content ≤25s + end card exactly 4.5s
  (batch-30) or 2.5s (batch-15 template); ~−16 LUFS; TP ≤ −1 dB
  (tightened to ≤ −1.05 on oversampled reads after B3); English only; no
  banned claims; no faked studio UI; family-safe flags disclosed.
  OBSERVED from briefs, logs, and parent-verified finals.

### Sources inspected, and depth / modalities

- **Batch-30 pool:** 6 batch-7 episode-1s, Toilet Knight ep1 (183.6s),
  Strawberry ep1 (302.8s), 3 Drive episodes (Panda BoBo, Phoenix Throne,
  Echo of Derelict), 19 local sources (`sources/src_*.mp4`), 3 edit-3
  originals — then re-scoped mid-batch to new Drive shows after the survey.
  OBSERVED from brief + coordinator log.
- **Drive survey (2026-10-29 ~16:27 PKT):** full enumeration via the Drive
  connector: 105 parent items = 101 folders + 4 mapping files; classified
  33 promising new, 28 excluded (adult/romance), 13 empty, 7 check-first,
  19 already used/touched, 1 reserved (Swapped at Birth). Classification
  was title-based ONLY; the survey itself states "a title is not a
  verdict; the hook scout of episode 1 decides." OBSERVED from
  `drive-survey/INVENTORY.md`.
- **Batch-15 scouts:** episode-1 downloads tool-verified by byte size +
  ffprobe; full-episode Whisper transcripts (base, CPU) + frame sheets
  (1fps windows, 10s intervals, full-size frames); per-window evidence
  lines for every monologue claim (baked-subtitle timestamps, transcript
  ranges, frame ranges). Group A package read in full for this debrief;
  group B/C packages sampled (weakest points + windows). OBSERVED.
- **T2 hunt:** Cheating's ep1 (235.4s, full transcript + 5s frames, 100%)
  and Swapped ep1–6 (full transcripts + 10s frames, 94 frames, grep
  plan/daughter/kitchen = 0 hits) — elimination-grade depth. SBE-07..13
  never checked. OBSERVED from rebuild notes.
- **Modalities used:** ffprobe (dims/fps/duration/codec), null decode,
  loudnorm (atrim / pre-trimmed), stereo oversampled true peak, PCM card
  silence, frame viewing (hook/mid/card/boundaries, 1fps sweeps for flags),
  Whisper tiny/base transcripts (VAD and no-VAD), baked-subtitle reading
  on frames. **Not used:** human listening test on any final mix (pilot
  review states this explicitly); speaker diarization; retention analytics
  on delivered clips (they were never posted); any vision-model call
  evidenced in RexTrix logs (see §8).

### Concepts considered, templates attempted, outputs delivered

| Work | Considered | Built / delivered | Status |
|---|---|---|---|
| Batch-30 scene-led | 6 groups from held + new-show pool | 36 built, 34 QC-passed + parent-verified, 2 held (gun rulings) | Delivered ready-to-upload, held by pause |
| Batch-15 cinematic VO-led | 15 scouted windows | 12 finals parent-verified PASS, 3 held (family-safe rulings) | Delivered ready-to-upload, held by pause |
| Warning template | Script ready | 0 built | Queued, count TBD — recipe only |
| Voiceover pilot | 1 script | v1 (bed defect) → v2 → v3 (approved, uploaded + submitted 2026-10-29, ID 7efa2a79-…) | Only pilot with audience exposure; views on record: none pulled after submission |
| T-drafts | 3 drafts | T1 + T3 rebuilt, parent-QC passed, uploaded + submitted; T2 unresolved | T2: source hunt exhausted for 2 candidates |
| Edit-3 | 3 user-supplied drafts, edited + stem-ducked | 3 edits delivered, user verdict "not good clips still" | Not uploaded; originals retained as source material |
| Benched templates | Before/After, Speedrun, Satisfying Split | 0 built | Benched until genuine studio recordings exist |
| Drive D/E clips (user-supplied) | 6 clips | 6 uploaded + submitted 2026-10-29 | Live, Pending |

### Tools actually invoked (not merely listed)

- **ffmpeg/ffprobe:** every build and every QC pass. OBSERVED.
- **demucs 4.1.0 (CPU torch):** installed after a disk-full failure
  (CUDA torch download), via TMPDIR/pip-cache on home storage; used for
  edit-3 stem ducking (htdemucs two-stems vocals, music ducked to 0.355 =
  −9 dB under speech) and batch-15 stem beds. OBSERVED from edit-3 review
  addendum.
- **faster-whisper (tiny/base):** transcripts in scouts and QC; broken in
  one QC environment (see §8). OBSERVED.
- **smart-reframe (custom skill):** saliency-tracked reframe; failed
  visibly on Crow doorway/corridor, Primal armor-mass, G3 moves — manual
  windows substituted. OBSERVED.
- **ElevenLabs "Hope" (Eleven v4) via browser session (engload23):** all
  pilot + batch-15 VOs (15 monologues, 19.6–25.3s). OBSERVED.
- **Fish Audio API:** credential present, HTTP 402 (credits exhausted) at
  every test through 2026-10-29 ~21:19 PKT. Never delivered a VO for this
  project. OBSERVED (see §8 for the auth-vs-provider distinction).
- **Google Drive connector:** survey enumeration + download inventory.
  OBSERVED.
- **YouTube Studio + Content Rewards via browser:** uploads, chains,
  submissions, pause verification. OBSERVED.
- **Muse remote-storage upload:** attempted for batch-30/15 delivery,
  FAILED (approval card timed out; exec killed after ~30 min); delivery
  fell back to chat attachments (user's authorized fallback). OBSERVED.
- **Not invoked for RexTrix on any record in these logs:** NVIDIA vision
  models (see §8), openai-whisper, any licensed SFX library, FreePD
  (permanently closed), any motion-graphics tool beyond ffmpeg
  drawtext/ASS/zooms.

### Permissions, constraints, execution blockers

- **Approval:** RexTrix = per-file user approval for the exact version
  (house rule, `CLIP_RULES.md` §6); a blanket word ("start uploading now,
  paced with gaps," 2026-10-30) was treated as covering the 34 passed
  batch-30 + 10 batch-15 clips at that time — then superseded by the
  user's HOLD + campaign pause. Swiss campaign authority (full autonomous
  approve+publish, 2026-10-12/13) is a different campaign's authority and
  was not applied to RexTrix. OBSERVED.
- **Campaign constraints:** 30-minute upload→submit window; submit button
  disabled while paused; bio link required; AI disclosure Yes at upload;
  caption must mention RexTrix; 40%+ US audience; no banned claims; posts
  stay public through review. OBSERVED.
- **Blockers encountered:** Fish 402; faster-whisper env break; VM
  restarts killing builders (G4/G5 "restart drain," G3 hold-terminal
  undelivered); disk-full on pip; /tmp wipe losing the edit-3 workdir;
  Discord "new login location" verification (manager appeal still
  unposted); campaign pause (all uploads held); single-slot Secure Vault
  google.com entry (aze password rejected twice; user bypassed by direct
  sign-in).
- **What was never tested:** any clip's audience performance for
  batch-30/15; viral vs professional captions; posting-window causality;
  US-audience targeting effect; warning template at all; SFX licensing
  route; a second ASR engine on the same audio (except tiny vs base on
  the C3 survivor line).

### Strongest and weakest delivered examples (technical/structural only —
no audience data exists for these)

- **Strongest: `c15_c2_dog.mp4`.** Parent reproduced every gate
  (1080x1920/30fps, content-only 198.3 kbps, I −16.04/TP −3.58, card
  exactly 75 frames, PCM ±1 LSB). Two real build defects were caught and
  fixed in-build and disclosed: the title/desert boundary (title ends
  ~72.2s, desert starts ~72.5s — a 72.0s start would have opened on a
  sliced title) and frame-inaccurate stream-copy extraction (first build
  discarded, re-extracted with re-encode to exactly 645 frames). Its
  honest weakest point (owner face absent in the opening reframe, beat
  carried by a baked sub) is disclosed, not hidden. Source: C2 QC report
  + parent note in assembly log.
- **Strongest fix-loop exemplar: `g2_apoc_died_three_times.mp4`.** Failed
  independent QC on a mid-sentence end cut, was extended (not trimmed) to
  353.2s into a verified speech pause, and passed re-QC with an explicit
  nuance judgment: clean ending = speech completes + pause + next sentence
  absent; baked-subtitle persistence at the last frame is NOT an
  incomplete ending. This is the project's best-documented single fix.
- **Weakest: `g1_cloudwhale.mp4`.** 3.87s of content, 720p softness, "never
  call it HD." It passes every gate and its hook is specific, but the
  clip is thin: a 3.9s moment + 4.5s card means the card is longer than
  the content. Gate-pass and thinness coexist — the clearest proof that
  gates do not measure substance.
- **Weakest template fit: `c15_b2_primal.mp4`.** Scout package: "weakest
  fit in Group B… no named human character, no choice dialogue, and no
  reveal beyond the machine-rex appearance… saved only by the
  face-close + roar + charge-at-the-line arc." Built anyway, delivered
  with "weakest template fit" flagged. The failure here is process (a
  scout warning built without a recorded override), not the render, which
  passed its gates.

---

## 3. Creative development and source understanding

### How the subject was chosen — three different orders, only one honest

- **Batch-30: scene first, angle second.** Group 1 used six hooks scouted
  2026-10-29 (Survival "MOVE AND YOU DIE," Neon "YOU CAN'T TAKE MY
  COLORS," etc.); groups 2–6 used "strongest hook-first moments" from the
  pool by the same bar. The caption/gloss was written to the scene.
  OBSERVED from brief + hook ranking. Consequence: hooks are specific and
  scene-true, but the brand's role is paratextual (title + card) — see
  "brand belonging" below.
- **Batch-15: template first, scene second.** The monologue shape
  (name → trait → sentence → stakes → invitation) pre-existed; scouts
  then found windows whose characters could fill the slots, with
  evidence lines per claim. This is angle-before-selection done honestly
  (evidence requirements per claim), but it still forced slots onto
  unsuitable windows (Primal, C1 Briggs, C3 tone). OBSERVED from
  execution script + scout packages.
- **Pilot: script first, footage second.** A verbatim user script drove
  segment selection from three star-god sources. OBSERVED from pilot
  review scene map. Consequence: the script's "three powerful gods"
  claim collided with a baked "FOUR GODS. FOUR CAGES." on the hook shot
  — a script-first defect that survived into v3 as a disclosed open item.
- **Audience insight did not precede any of these.** No audience data,
  retention pull, or viewer research is on record. What preceded selection
  was: campaign rules, user directives (hooks, US window, professional
  style), and prior Studio patterns (Cinema distributes best, QubeEase
  flat — see §11P for why that pattern cannot bear the weight put on it).
  Label: HYPOTHESIS wherever a brief claims an "audience insight"; the
  evidence supports "operator judgment + campaign constraints" only.

### Opening promise vs payoff, by work type

- **Scene-led (batch-30):** promise = hook card + first 1–3s moment
  ("MOVE AND YOU DIE" over frozen arena players); payoff = the complete
  thought resolving before the card (rules thought, defiant line, leopard
  stalk). Where payoff failed, it was visible and fixable (G2 mid-sentence
  cut). Where payoff was thin, it was disclosed (cloudwhale 3.9s,
  cloudwhale/giants source softness/darkness). OBSERVED.
- **VO-led (batch-15):** promise = "they call her/him X because…" +
  character face; payoff = trait demonstrated + stakes + invitation line
  flowing into the card. The promise/payoff link is narration, not
  picture: in C1 the named character never appears, so the promise names
  someone the payoff cannot show. In B4 the accusation beat is one-sided
  (Voss out of frame final ~8.5s) — the payoff's reaction half is absent.
  OBSERVED from assembly log + scout packages.
- **Pilot:** promise = "AI entertainment is officially getting out of
  control" + starlight world; payoff = "it's actually playable" +
  "download link is in my bio." The payoff's "playable" claim rests on a
  palace-walk segment (verified on frame after the first choice proved
  wrong — lions/savanna, not palace walk). The correction is documented;
  the claim itself ("playable") is supported by gameplay-like footage,
  not by a documented test of playability. HYPOTHESIS that a viewer
  accepts "playable" from this footage; OBSERVED that the segment was
  frame-verified as palace, not savanna.

### Essential context, qualification, or reaction that had to survive

- **The final line.** G2's fix exists because the final line ("I've
  watched the sky for 30 years") is the payoff; cutting inside it broke
  the clip even though everything else passed. Lesson: in dialogue-led
  clips, the last line is load-bearing, not trailing. OBSERVED.
- **The reaction after the line.** §10 (human-edit-feel) requires holding
  a reaction a beat past the line; C3 holds the boy close-up looking up
  at 23.0s with no card (reaction held past the line); C2 gives 0.90s
  breath before the card. Conversely, B4's missing Voss reaction and
  C2's missing owner face show what happens when the reaction half is
  cut or cropped away: the beat is carried by text instead of a face.
  OBSERVED.
- **Qualifications the VO must not drop.** Scout packages withhold
  spellings that lack baked-subtitle evidence (Miris vs Mira; VARANORC;
  Cord not visually linked to the Gardener; Leo is the brother, not the
  Crow-Ash boy). The monologues use descriptive epithets instead of
  guessed names. This restraint is correct and is the project's best
  truthfulness habit. OBSERVED from group-A package + C3 QC report.
- **The "hey little guy" line.** A2 deliberately carries NO card for it
  (assembly log), because the baked line already says it at that moment.
  Withholding a card is an editorial act; the doubling rule forced it,
  but the effect is restraint done right. OBSERVED.

### What the editing contributed beyond the source

Ranked by evidence, not by effort:

1. **Selection and exclusion.** Choosing fresh moments, dropping
   adjacent continuations of batch-6 scenes, excluding 28 adult/romance
   shows, scoping windows to avoid episode-level flags (Witch window
   238–264s avoids the bone-bikini costuming elsewhere in the episode).
   This is the largest contribution and it is invisible to the viewer.
2. **Silencing + re-voicing.** Cinematic clips silence source audio and
   replace it with a monologue that supplies trait/stakes/invitation the
   picture alone lacks. This genuinely changes understanding (see §4).
3. **Reframing + evidence preservation.** Pillarbox strips (G2, G3 Crow,
   C2 title) preserve full-width baked subtitles that a 9:16 crop would
   slice. The contribution is negative in the good sense: it prevents a
   defect rather than adding a flourish.
4. **Caption glossing.** G2's gloss cards ("A PLAN, NOT CHANCE") interpret
   the scene in the project's words; judged accurate, not misleading, by
   independent QC. This is authorship — and therefore the place where
   accuracy matters most.
5. **Pacing and emphasis.** Cuts on beats, reaction holds, one punch-in
   or push per clip (§10). Real but small: C2's portal-escalation and
   C3's reaction-before-reveal are the only two §10 applications
   documented in a QC report, and both postdate §10 itself — §10 was
   written 2026-10-30, after batch-30/15 were built, so most delivered
   clips predate it. Do not credit §10 for clips built before it.
6. **The end card and chain.** Campaign compliance + distribution
   plumbing, not storytelling. The card contributes the CTA and nothing
   else; any claim that it contributes narrative payoff is false (see
   §11F).

### Why the product/brand belonged in the story — and where it did not

- **Cinematic VO clips:** the brand belongs narratively — "one sentence
  typed into RexTrix" is the inciting incident, "the story is waiting
  inside the app" is the invitation. The brand is a story element.
  OBSERVED from monologue texts.
- **Scene-led batch-30 clips:** the brand belongs only paratextually —
  title ("RexTrix | …"), caption mention, end card, bio link. Nothing in
  the scene itself is about RexTrix; the scene is a drama the app
  supposedly generated, but the clip never says so in its own voice.
  This is compliant (caption mentions RexTrix, card carries the CTA) but
  it is not storytelling. If a viewer strips title + card, the clip is
  just a drama excerpt. See §11C.
- **Pilot:** in between — the VO names the app and its mechanism ("you
  just type a sentence… it builds you a custom game or a short drama
  film") while the picture shows generated worlds. The brand claim is
  explicit and therefore falsifiable in a way the scene-led clips' brand
  is not. The "actually playable" line is the least-supported brand
  claim in the pilot (see above).

### Weak source vs unsuccessful treatment — three clean separations

- **Weak source, adequate treatment: giants/cloudwhale.** Darkness,
  motion blur, 720p softness are source-baked; the treatment disclosed
  them and did not pretend otherwise. Keeping them with flags was
  correct; dropping them would have hidden a source-quality fact the
  next batch needs (landscape dark scenes + 720p vertical sources are
  weak inputs).
- **Treatment verdict without a separable cause: edit-3.** User verdict
  "these are not good clips still" (2026-10-29) names no defect. The
  edits had cut 7–9.5s of filler, fixed a format-switch-in-opening, and
  stem-ducked audio — all documented. Whether the verdict condemns the
  treatment, the source moments, or the premise is UNKNOWN on record.
  The correct response (taken) was to retain originals as source material
  and let batch-30's group-5 scout judge the pool fresh; it correctly
  reported ZERO strong clean moments. The verdict itself taught nothing
  reusable — see §10.
- **Pool exhaustion, not treatment failure: group-5 edit-3 scouting.**
  C2's zero-overlap cut starts mid-sentence; C1's candidate is visual-only
  with constraining baked text; C3 has no candidate. Reporting that
  instead of building weak clips is the honesty rule working. OBSERVED.

### Useful beats rejected — and whether the rejection was justified

- **B4's stronger payoff (560–615s, redundant-asset reclassification)
  deliberately not used** because the task scoped the show to its
  opening. JUSTIFIED as scope discipline, UNJUSTIFIED as storytelling:
  the delivered clip's weakest point (one-sided accusation) is partly a
  consequence of this scope. The scout itself flags the upgrade. OBSERVED
  from group-B package. Lesson: scope decisions should record their
  storytelling cost at the time, not just their discipline benefit.
- **Phoenix villain 131–147s (dagger at throat + blood spatter)
  deprioritized** on family-safe grounds. JUSTIFIED: safety bar outranks
  payoff. OBSERVED from G3 hold notes.
- **Dark stems for Dog/Mutant rejected.** JUSTIFIED and later vindicated
  (fitting tracks arrived). OBSERVED.
- **C3 survivor line left uncaptioned in the fallback edit** because tiny
  + base disagreed ("You're mild" certainly a mishear). JUSTIFIED
  restraint at the time; the stem version later transcribed it cleanly
  ("Every survivor eventually meets me"). Lesson: restraint + revisit
  when audio improves beats guessing. OBSERVED from edit-3 review.

### Bias from titles, thumbnails, transcripts, or model summaries

- **Titles:** controlled, not eliminated. Survey classification was
  title-based (first pass) with a mandatory ep1 scout before any cut
  (rule 17: "a show title never approves a clip"). Two title candidates
  for T2 were then eliminated on evidence. But the survey's "promising
  new" 33 are still title-promising until scouted; any future batch that
  treats them as vetted would inherit title bias. OBSERVED.
- **Transcripts:** Whisper is a bias source in both directions — it
  invents spellings (Miris/Mira, VARANORC, "Neil" for "kneel," "Rex
  Tricks") and it misses quiet lines (Phoenix ~80s, survival "Please!").
  The control that worked was baked-subtitle corroboration on frames:
  "kneel before the city" (baked) overruled Whisper ("Neil"); doors
  silence verified by a no-VAD pass. OBSERVED.
- **Thumbnails:** no thumbnail-based selection is on record. UNKNOWN
  whether thumbnails influenced any scout; the packages cite frames and
  transcripts, not thumbnails.
- **Model summaries:** no model summary was used as a selection basis on
  record; scout packages cite transcript ranges + frame ranges, not a
  model's verdict. The absence is worth noting because the pipeline
  contains model-capable steps (vision QC) that were not evidenced here
  (see §8).

### Inspection depth — enough, too little, or too much?

- **Enough to eliminate:** T2 candidates (full transcripts + frames,
  100% of Cheating's ep1, 6 Swapped episodes). Depth was sufficient for
  a negative verdict. OBSERVED.
- **Too little to identify:** T2's true source remains UNKNOWN; the hunt
  stopped at user-direction-pending, with SBE-07..13 unchecked and no
  other candidate queue. Depth was sufficient to rule out, insufficient
  to find. OBSERVED.
- **Enough for the batch, not for the catalogue:** batch-30/15 scouted
  assigned ep1s only; 14 second-wave shows + SBE-07..13 + 7 check-first
  folders remain unscouted. For a 30-clip batch that is adequate; for a
  "check every corner" order it is incomplete by construction — the
  order produced a survey, not a scout of everything. OBSERVED.
- **Too much in one place:** the Drive survey enumerated 101 folders +
  per-folder children (parent_listing.json + children/*.json) before
  groups 2–6 could finalize picks. The mid-batch hold + G3 respawn cost
  is documented (coordinator log 16:22–16:31). A survey phase before the
  brief would have cost the same enumeration without the churn. See §10.

### The default workflow, and where it actually ran

The default — "find scene → add headline/captions → attach end card" —
is OBSERVED as the literal structure of batch-30: hook ranking → window →
centered phrase cards → 4.5s card. It is not inherently bad; it produced
specific hooks and complete thoughts. It becomes a failure mode when the
headline does the work the scene should do (gloss cards substituting for
a missing payoff), when the card is treated as the payoff (see §11F),
and when it runs 36 times with the same card, font, and structure so
that "different footage" is the only variation (see §5, repetitive
selection). The counter-cases in this project are the ones where the
workflow was broken deliberately: silencing + VO (cinematic), extension
instead of trimming (G2), pillarbox instead of crop (G2/G3), holding
instead of forcing music (Dog/Mutant), recut instead of drop (cut_rope).

### Restraint as the correct creative choice — cases on record

1. Not captioning the C3 survivor line in the fallback (see above).
2. Not using the C2 title segment's sliced-title opening; moving the
   desert start to 72.5s and shortening content 22.0 → 21.5s.
3. Not re-encoding video for the 944:945 SAR or 96 kHz sample rate
   (invisible differences; audio-only fixes where possible).
4. Not padding the batch (0 padded) and not dropping cut_rope (recut).
5. Not faking studio UI for the three benched templates.
6. Not uploading clip 1's siblings after the pause (hold), and not
   re-uploading after failed submissions (submission-only retry rule).

---

## 4. Template and story-structure learning

Mechanism = what the template does to the viewer's understanding, not what
it looks like. "Implemented" means a delivered file exists; "recipe" means
a script/package with no delivered file.

### Scene-led comedy / dialogue / discovery / suspense (batch-30)

- **Mechanism:** a self-explanatory moment in 1–3s + a complete thought +
  a caption gloss. Understanding changes only via selection (which moment)
  and gloss (what the moment means). The picture's own dialogue carries
  the story where dialogue exists; where it does not (G6 visual/music-only
  clips, G4 dialogue-free primal clips), the cards carry everything.
- **Suitable when:** the window contains a complete, self-explanatory
  beat with a payoff inside ≤25s. Unsuitable when: the beat needs
  context outside the window (B4-style one-sidedness), the source is
  dialogue-free and the cards must invent the story, or the moment is
  under ~5s (cloudwhale) and the card outweighs the content.
- **Assets/permissions:** source episode + Montserrat + card graphic;
  no VO permission needed; music stems optional (G6 used a single native
  mix, no demucs — a judgment call recorded as acceptable because
  speech p=1.00 and no competing tracks).
- **Implemented vs recipe:** implemented 36 times. The recipe (brief)
  matches the exports except for the documented deviations (centered
  Y-50% spec overriding the pad rule for full-frame sources; pillarbox
  for G2/G3 Crow).
- **Export evidence:** hooks specific; complete thoughts verified by
  transcript + frame checks; weakest points disclosed per clip.
- **Failure modes:** gloss substituting for payoff; late payoff
  (leopard ~12s); card longer than content (cloudwhale); dialogue-free
  clips where cards assert a story the picture does not show (G6 dog
  clips: "cards must carry the hook (no dialogue does)" — coordinator
  log). Boundary: if the gloss must assert a fact the frames do not
  show, the window is wrong, not the gloss.

### Narrated / text-led editorial storytelling (batch-15 cinematic)

- **Mechanism:** VO monologue supplies character, trait, stakes, and
  invitation; picture supplies atmosphere and proof-by-footage. This is
  the only template in the project that changes understanding beyond
  selection: a viewer who watches muted gets a different (thinner) story
  than one who listens. That is both its power and its risk (muted
  viewers are a real Shorts population — UNKNOWN share here).
- **Suitable when:** the window has a real, nameable-or-describable
  character, a visible trait, and a resolving beat. Unsuitable when: no
  named human exists (Primal), the character never appears (C1 Briggs),
  the tone mismatches (C3 candy comedy under a suspense monologue), or
  the window is a montage needing the VO to stitch it (B4 redundancy
  window: "leans on the VO to stitch it together").
- **Assets/permissions:** ElevenLabs session (browser, engload23) or Fish
  credits; royalty-free/stem music; card graphic. VO permission was the
  binding constraint (Fish 402 → picture-only scouts → parent-recorded
  ElevenLabs VOs later).
- **Implemented vs recipe:** implemented 12 times (2.5s card per template
  spec, a house-rule deviation flagged in every note). The recipe's
  "grade: dark, cinematic, high-contrast" was applied to windows; no
  grade measurement is on record, so grade effect is UNKNOWN.
- **Export evidence:** VO uncut on all 12 (verified); music ducked 0.35
  (recipe claim, not final-mix measurable — see §7); ASS phrase chunks
  verified; C2/C3 parent-verified in full.
- **Failure modes:** name-slot forcing (absent/guessed characters);
  template arc repeated 12 times (name→trait→sentence→stakes→invitation)
  so that structure is identical while footage differs; VO tail
  redundancies (B5 monitor shot after device payoff); dual-text windows
  where baked subs persist under cards (C3 ~2.5s). Boundary: if the
  monologue's first sentence cannot be evidenced from the window alone
  (name, trait, or stakes from outside the window), either re-scope the
  window or drop the clip — do not borrow evidence from elsewhere in the
  episode without disclosing it (the Apocalypse "24 hours" line comes
  from transcript 292–298s, outside the 189–211s window; the package
  discloses this, which is the correct handling, but a viewer cannot see
  the disclosure).

### Script-led montage (voiceover pilot)

- **Mechanism:** a fixed script's sentences select segments; picture
  illustrates the sentence playing. Understanding = script, picture =
  illustration. The pilot is the only clip where brand mechanism is
  explained in-voice ("you just type a sentence…").
- **Suitable when:** the script's claims map 1:1 onto available footage.
  Unsuitable when: the script asserts a count the picture contradicts
  ("three gods" vs baked "FOUR GODS") or a capability the footage cannot
  show ("playable" from a walk cycle).
- **Implemented:** v3 delivered, uploaded + submitted, user-approved.
  v1's defect (source bed at −22 dB under VO) is the project's
  clearest audio lesson and is now a standing rule (silence, never bed).
- **Failure modes:** source-internal mid-sentence cuts (0.87s / 2.23s /
  10.4s in v3, still open — deep re-cut held); baked-text collisions
  ("FOUR GODS" vs three-gods VO); first-render doubling (old lower-third
  captions burned into source + new centered captions — caught by parent
  frame check, render discarded, never sent). Boundary: a script-led
  montage must be rebuilt from captionless segments, never captioned
  over a captioned render (CLIP_RULES §9 scope limit).

### Comparison / split screen (T2)

- **Mechanism (intended):** two worlds side by side, one app, one typed
  sentence — comparison as proof of range ("ONE OF THESE WAS TYPED. NOT
  WRITTEN." / "SAME APP. DIFFERENT WORLDS").
- **Implemented:** no. The draft exists (`t2_split_screen.mp4`); the
  rebuild was never made because the top-panel source was never
  identified. The bottom panel was corrected (Toilet Knight cauldron,
  TKSV-1 40–44s, not Strawberry as first assumed) — a genuine finding
  from frame matching, but it does not complete the pair.
- **Failure mode on record:** title-based candidate selection (Cheating's
  as "best fit" on theme) failed on evidence; the montage structure of
  the top panel (kitchen ~0–4s, bedroom ~5s, kitchen close-up ~8s) means
  even a correct show identification still requires matching three
  shots, not one. Boundary: do not start a split-screen rebuild until
  all panels are sourced; the fallback (Toilet-vs-Strawberry from held
  material) changes the concept and needs a user decision, not a quiet
  substitution.

### Result-first, chronological, mystery, process structures

- **Not attempted as deliberate structures.** Batch-30 windows preserve
  source chronology within the window (no reordering except edit-3's C3
  flash-forward cold open, which was user-rejected as part of edit-3).
  No result-first cut (payoff first, then how) was delivered; no process
  documentation (how the app builds) was delivered; the cinematic
  monologue is character-led, not mystery-led (it tells the trait
  upfront). Do not claim experience with these structures from this
  project. Their absence is a gap, not a verdict: a result-first version
  of the Apocalypse button-press (press first, then the standoff) is a
  legitimate untested variant.

### Detail reveals, transformations, before/after

- **Before/after, Speedrun, Satisfying Split: benched, never built.**
  Mechanism would have been transformation-as-proof (type → world), but
  the only available material was drama scenes, and faking typing UI
  would have been false advertising. The benching decision is correct
  and should stay until genuine studio recordings exist. What remains a
  recipe: the template descriptions in `CLIP_RULES.md` §8. No export
  evidence exists for or against these templates' performance.
- **Detail reveals in practice:** C2's pillarbox title beat (entering
  the TV) and C3's reaction-before-reveal (skyward look held 1–2s before
  the spirit) are detail-reveal mechanics inside other templates, and
  both are documented in QC reports. Keep them as devices, not templates.

### Commentary, visual explanation, motion graphics

- **Not built.** No explainer graphics, arrows, diagrams, or
  screen-recorded UI exist in any delivered file. Motion is limited to
  cuts, 1.1x static zooms, one punch-in/push per clip (§10), and the
  C3 slow push. "Motion graphics" in this project means ASS text
  timing, not graphics. Any future claim of motion-graphics capability
  must be built and measured first.

### Loops, replays, reaction-led editing

- **Loops explicitly banned** (§4: no loops/freeze/slow-mo padding) and
  none is on record in a delivered file. Good: the ban held.
- **Replays:** none delivered (the edit-3 C3 cold open repeats a Kai
  shot in two framings — inherent to its flash-forward, disclosed, and
  the edit was rejected; do not cite it as a replay technique).
- **Reaction-led:** partially implemented via §10 holds (C3 boy
  close-up tail; C2 owner-reaction hold) and via the cinematic template's
  slow-on-dialogue rule. No clip is primarily reaction-led. The B4
  missing-reaction case shows the failure mode: without the reaction,
  an accusation beat reads as narration, not drama.

### Which methods changed understanding vs merely styling

- **Changed understanding:** VO monologue (trait/stakes/invitation);
  caption glossing where it interprets (G2 "A PLAN, NOT CHANCE");
  selection itself (which moment, which window, what is excluded);
  silencing (removing competing source audio changes what the viewer
  can follow).
- **Merely styling:** grade (unmeasured), zooms/pushes (emphasis, not
  information), card styling (font/outline/placement), music bed choice
  (mood, not information — except where the wrong bed actively misleads
  by tone, as dark stems would have on Dog/Mutant).
- **"Viral template" claims lacking post/analytics evidence:** viral
  captions (pilot-only experiment, no view data on record for v3's
  caption system specifically); hook-first (no A/B against non-hook-first
  cuts); human-edit-feel §10 (written after the clips it would govern);
  1.5–2s picture cuts (warning template, never built); US-window posting
  (correlation, confounded — see §11P). All are HYPOTHESIS for retention
  until the §13 test runs.

### Methods that should remain available despite not fitting this project

- Benched templates (before/after, speedrun, satisfying split) — pending
  genuine recordings. Do not delete the bench; do not build from drama.
- Split-screen comparison — pending T2 sourcing or an explicit fallback
  decision.
- Result-first and process structures — untested, legitimate variants
  for the next campaign's brief, not for retrofitting held clips.
- Wordless visual moments (G6 visual/music-only clips prove the pipeline
  can do them) and dialogue jokes with minimal graphics (never delivered
  under the caption-mandated system — an untested freedom, see §12).

---

## 5. Robotic editing / "AI slop" diagnosis

"Slop" is not used as a verdict below. Each symptom names an example and a
likely mechanism, or is marked absent/untested.

- **Generic hooks that could describe any video: largely ABSENT in
  batch-30.** Hooks are scene-specific ("MOVE AND YOU DIE," "YOU CAN'T
  TAKE MY COLORS," "EVERY HUNT IS CALCULATED"). The counter-example on
  record is batch-6's "HIS CLOSING WORD" (vague label, cited in
  `CLIP_RULES.md` §7 as what not to do) — a pre-batch-30 defect the
  hook rule was written to prevent. Mechanism when it occurs: writing the
  card from the clip's position in an edit (closing words) instead of
  from its visual content.
- **Narration naming what is already visible: PRESENT in narrow cases.**
  C1's VO names Briggs, who never appears — narration asserting what the
  picture cannot show (template name-slot mechanism). C2's "owner shouts"
  beat is carried by a baked sub, not a heard shout or a visible face
  (crop mechanism). Elsewhere the cinematic VO adds trait/stakes beyond
  the visible, which is the opposite of this symptom.
- **Unsupported excitement, stakes, authority, product claims: PRESENT
  in one place.** Pilot "actually playable" (see §3) and cinematic stakes
  lines whose evidence sits outside the window (Apocalypse "24 hours").
  Mechanism: monologue scope (whole-episode knowledge) wider than window
  scope (what the viewer sees). Mitigation on record: scout packages
  disclose cross-window evidence; the viewer cannot see the disclosure.
- **Repetitive scene-selection patterns disguised by different footage:
  PRESENT at template level.** The cinematic arc repeats identically 12
  times; batch-30 repeats hook → complete thought → card 36 times. The
  footage differs; the structure does not. Mechanism: one brief, one
  spec, parallel builders. §10 ("never identical templates") was written
  to counter this but postdates the clips. Whether viewers notice
  structural repetition across a channel is UNKNOWN (no retention data).
- **Constant zooms, shakes, flashes, transitions: ABSENT.** No shakes or
  flashes are on record in any delivered file. Zooms are capped (1.1x
  static, one punch-in/push per clip in §10; C2 1.10x payoff punch-in;
  C3 single slow push). Mechanism of absence: the spec never asked for
  them, and §4 bans padding devices. This is a genuine non-symptom.
- **Mechanical beat-cutting / identical shot durations: UNTESTED as a
  risk, not observed.** Cinematic cuts follow dramatic beats (slow on
  dialogue); the warning template's prescribed 1.5–2s picture cuts were
  never built, so their mechanical risk is HYPOTHESIS, not observed.
  Batch-30 shot durations vary with the source window (8.5–24.7s
  content), not a grid.
- **Overlong setup, premature spoilers, missing payoff, redundant
  aftermath: PRESENT in disclosed instances.** Overlong setup: wild
  leopard dominant at ~12s (G1 re-QC retention note); doors ~4s
  speech-free cold open (G3 re-QC). Missing payoff: G2 original
  mid-sentence cut (fixed by extension). Redundant aftermath: B5 VO tail
  adds a monitor shot after the device payoff + 0.19s "App." card overlap
  (flagged blemish, optional fix offered, not taken). Premature spoiler:
  no clear case on record — hooks promise the moment rather than giving
  away the ending, except arguably edit-3 C3's cold-open confrontation
  (flash-forward by design; user-rejected as part of edit-3, cause
  UNKNOWN).
- **Reaction shots detached from cause: PRESENT once, by absence.**
  B4's accusation without Voss's reaction (he is out of frame final
  ~8.5s) is a reaction missing, not detached. No case of a reaction
  visibly belonging to a different cause is on record. The C2 owner-face
  absence is adjacent (beat carried by text, not face).
- **Artificial cliffhangers / incomplete loops: PRESENT as disclosed
  open items, not as deceptions.** Pilot v3 source-internal mid-sentence
  cuts (0.87s/2.23s/10.4s) remain open with a deep re-cut held; cut_rope's
  elliptical middle (splash-implied fall) is an honest ellipsis, judged
  complete by re-QC, with the ellipsis named as the weakest point.
  Mechanism: source-internal cuts inherited from supplied renders
  (pilot) vs deliberate splice in a speech gap (cut_rope). The two must
  not be conflated.
- **Text overload, permanent headlines, competing subtitle layers:
  PRESENT in bounded windows.** C3 dual-text ~2.5s (added cards +
  persistent baked line, baked line larger); A3 busy frame ~12.3s (ASS +
  baked, different texts/positions, judged not a double); G3 blur-pad
  echo (faint blurred echo of the baked sub in the pad); B5 "App." card
  beside device text 0.19s. Mechanism: three text layers coexist
  (baked subs + added cards + watermark) with only one coordination rule
  (no shared words at the same moment). All four cases pass that rule as
  written and would fail a stricter "one text block at a time" rule —
  the rule, not the clips, is the open decision (see §12).
- **Inconsistent typography, composition, motion, visual hierarchy:
  PRESENT at project level.** Two fonts (DejaVu vs Montserrat), three
  caption placements (lower-third, centered, pad), two card lengths
  (4.5s vs 2.5s). Mechanism: rules evolved per batch without retrofit
  (correct per §10 non-retrofit, but the channel-level inconsistency was
  never decided). Within any single batch, typography is consistent.
- **Excessive blur padding, poor crops, tiny important details: PRESENT
  in disclosed instances.** B3 letterbox: ~66% of the canvas black
  (1080x608 band) to hold a two-shot — accepted by user decision, not by
  default. Crow 9:16 crops sliced full-width baked subs (fixed by
  pillarbox). Primeval center-crop + faint blur band (accepted, ghost
  blobs illegible at phone scale). Key message on small baked text
  (batch-6 explore-screen list) is the cited §7 case. Mechanism: 9:16
  adaptation of landscape sources always trades something (subject,
  subtitles, or screen area); every trade in this project was disclosed,
  but disclosure is not the same as a good trade.
- **Uncontrolled generative/source artifacts: PRESENT, source-baked.**
  Giants darkness + motion blur, primeval ghost blobs, cloudwhale 720p
  softness, dog clips upscaled from 608x1080 saliency crops (softer than
  native Mutant). None was introduced by the editors; all were disclosed
  with honest softness notes. The editor-introduced artifact class is
  different: blur-pad echo (G3), card-join transients (fixed), and the
  pilot's first-render doubling (caught, discarded).
- **Robotic voiceover, pronunciation, pacing, emotional mismatch:
  MIXED.** Delivery quality: UNKNOWN — no human listening test on any
  final mix is on record; Whisper detection (p=1.00) proves intelligibility
  to ASR, not naturalness to a listener. Pronunciation: "Rex Tricks" is
  a Whisper mishear, not a VO error (captions spell "RexTrix" correctly).
  Pacing: deliberate (VO offsets 0.0/+0.5s, breath tails, 0.18s pads in
  the template). Emotional mismatch: OBSERVED once — C3's suspense
  monologue over bright candy comedy ("works as whimsy, not tension,"
  per its QC report). Mechanism: template tone assigned before the
  window's tone was judged.
- **Audio masking, abrupt silence, clipped words, overprocessing:
  PRESENT historically, fixed on record.** Pilot v1 bed (masking, fixed
  by silencing); batch-6 closers unenhanced (fixed by §7); G2 original
  clipped thought (fixed by extension, not by processing); loudnorm
  two-pass undershoot on peaky SFX (G4 recovery: mix −16.09 → −17.32,
  method changed). No overprocessing case (pumping, distortion) is on
  record; TP fixes were gain-only, video untouched.
- **Abrupt advertising endings with no convincing brand bridge: PRESENT
  as a structural property, not a defect of any single clip.** Every clip
  ends in a silent logo card (2.5s or 4.5s). The bridge is the VO's final
  line ("Link is in my bio") or, for scene-led clips, nothing at all —
  the card follows the payoff with no spoken bridge. Whether this loses
  viewers at the join is UNKNOWN (no retention at the join on record).
  The card is campaign/house-mandated, so "fixing" it means changing the
  mandate (e.g., VO tail over the first card second — never attempted),
  not editing harder within it.

---

## 6. Picture, motion, graphics, and captions

- **Portrait/landscape adaptation.** Three methods used, each with a
  known price: (a) saliency reframe (608x1080 crop upscaled to 1080
  wide) — price: softness + subject risk + subtitle slicing; (b)
  pillarbox strip-over-blur (1080x608 strip at y656–1264 over blurred
  cover fill) — price: half the canvas is blur, but the full frame and
  every baked line survive; (c) letterbox acceptance (B3: 1080x608 band)
  — price: ~66% black, chosen to hold two faces simultaneously. The
  project's rule ("never a dead center-crop," "verify every reframe on
  frames") is the right control; its failures (Crow doorway, Primal
  armor-mass) prove the control is necessary, not that reframing is
  broken. OBSERVED.
- **Reframing and enlargement limits.** Native 1080-width crops do not
  exist for landscape sources in this pipeline: the crop is 608 wide,
  upscaled. The honest wording ("upscale of the crop, not native 1080
  width") appears in scout packages and must be used in user-facing
  notes too. Enlargement beyond 1.1x static zoom / 1.10x punch-in is not
  on record; no clip was enlarged to the point of visible pixelation
  beyond the disclosed softness cases. OBSERVED.
- **Source resolution, frame cadence, inherited defects.** Sources span
  1920x1080 landscape, 1080x1920 vertical native, 1080x1880 (Swapped,
  40px short), 640x360 strips, 720p vertical (cloudwhale). All outputs
  are 1080x1920 30fps; 40px-short and 720p sources were handled by
  padding/upscaling, disclosed, never claimed as native. Frame cadence:
  all delivered files verified frame-count = duration × 30 (except the
  disclosed A3 +1 silent picture frame, card still exactly 75).
  Inherited defects (darkness, blur, ghost blobs, softness) are listed
  in §5. OBSERVED.
- **Motion graphics: what clarified vs distracted.** Nothing beyond
  text timing, zooms, and one push per clip exists to judge. What
  clarified: the C2 pillarbox title beat (a format switch at the story
  hinge — entering the TV — which re-orients the viewer); the C3
  reaction-before-reveal hold (curiosity carried by delay). What
  distracted: nothing on record — no motion device was ever flagged as
  distracting, which may mean the devices were restrained or that QC
  never looked for distraction. UNKNOWN which. The lesson is narrow: in
  this project, motion did little, good or bad, because so little was
  used. Do not generalize to "motion doesn't matter."
- **Timing, easing, hierarchy, consistency.** Card dwells: descriptive
  cards ~20–30% longer than operational cards (§9); knocks 1.8s card
  judged "one clean read" (54 frames, large bold 3-word type); neon 2.0s
  dwell readable; no easing functions are on record (ffmpeg fades only:
  short audio fades at joins, 0.5s music tail fades into card joins).
  Hierarchy: centered Montserrat Bold white + 4px black outline is the
  single hierarchy for batch-30/15; baked subs sit below, watermark
  top-right. Consistency within a batch is verified; across batches it
  is not (see §5 typography).
- **Fonts, glyphs, line breaks, reading time, safe placement.** Montserrat
  Bold installed from Google Fonts (`~/.local/share/fonts/Montserrat-Bold.ttf`,
  registers as family "Montserrat Thin," style Bold — ASS Fontname
  "Montserrat Thin" + Bold=-1 renders true Bold; documented, and a
  trap for any fresh session that trusts the filename). Edit-3/pilot use
  DejaVu Sans Bold 54 instead — a second font with no recorded
  rationale. Line breaks follow phrase boundaries (§9), never raw word
  counts; the one documented exception is C2's "DOG OF THE WEST" (4
  words, proper name kept whole). Reading time: 1.8s is the shortest
  judged-readable dwell on record; no dwell under 1.8s was passed.
  Safe placement: added-caption bottom edge at/above y=1500 (Shorts
  UI line); pad cards at glyph rows y1309–1340 (fixer's "MarginV 1290"
  is the ASS margin, glyph gap 45px, not 26px — a documentation
  correction, not a defect, from G3 re-QC).
- **Captions: accuracy, phrase grouping, emphasis, source-output
  mapping.** Accuracy: transcripts verified against baked subs where
  they disagree (baked wins); Whisper-only lines carry stated
  uncertainty (wormhole "Move!" tail, redundancy "hid"→"hit me" —
  both confirmed as Whisper limits, not edit errors). Phrase grouping:
  §9 (never split a noun phrase or brand command; "DON'T DOWNLOAD
  REXTRIX" stays whole). Emphasis: none beyond bold + size; no italics,
  color emphasis, or word-by-word highlighting in delivered batch-30/15
  files (the pilot v3's word-timed chunks are timing, not emphasis).
  Source-output mapping: recoverable from NOTES.md + QC reports + ASS
  files for T-rebuilds and C2/C3; for batch-30 groups, mapping lives in
  per-group NOTES.md (not re-read for this debrief — see coverage
  limits). No single machine-readable clip→source→card index exists
  (see §9).
- **Burned-in subtitles vs added text.** The coordination rule (no
  shared words at the same moment; if the source says it, remove or
  retime) worked as a floor and failed as a ceiling: it prevents
  doubling but permits dual-text windows (C3), busy frames (A3), and
  pad echo (G3). The rule's bar ("illegible smudge at phone scale" for
  echo) vs a frozen-still bar ("zero decipherable echo") is an open
  human decision, explicitly flagged by re-QC ("if bar were zero
  decipherable echo on a frozen still, no blur-fill could pass").
  OBSERVED.
- **Caption/visual claim agreement and limits.** Gloss cards assert
  interpretations ("A PLAN, NOT CHANCE") judged accurate by QC; VO
  monologue claims are evidence-lined in scout packages but the evidence
  is not visible to the viewer. The limit: a caption can agree with the
  picture and still exceed it (stakes from outside the window). The
  project's control (evidence lines in packages) is a production control,
  not a viewer-facing one. OBSERVED.
- **Color/compositing/alpha issues actually encountered.** Pilot card
  patch seam invisible (background matched RGB 16,16,16). G4 QC: `select
  eq(n)` fails past the card join due to bt709 vs unknown colour-space
  reconfiguration — documented, not a defect. Card PNGs pixel-identical
  across G1's six clips (verified). No alpha-channel issue is on record
  (cards are opaque video, not overlays with alpha). OBSERVED.
- **"What would the viewer lose if this effect were removed?"**
  Saliency reframe: the subject in frame (landscape sources would be
  letterboxed or center-cropped, losing faces or subtitles). Blur pads:
  the full frame + whole subtitles (Crow). Slow zoom (1.1x static):
  almost nothing — it is emphasis on a static window, and its removal
  would be unnoticed in most clips; the brief's "static >1.5s gets a
  zoom" rule is the weakest-evidenced effect rule in the project
  (HYPOTHESIS that it aids retention; no test). Punch-in (C2 1.10x):
  payoff emphasis; removal loses a beat of escalation, not information.
  Grade (dark cinematic): UNKNOWN — no graded-vs-ungraded comparison
  exists. Centered phrase cards: the hook and the story for muted
  viewers (batch-30) and the VO's structure (batch-15) — removal loses
  the most, which is why caption accuracy matters more than any other
  effect in this project.
- **No blanket rules are recommended from this section.** In particular:
  the 3-word cap is a ceiling, not a splitting rule (§9); zoom cadence
  is not prescribed; shot-hold duration is scene-dependent (8.5s
  cut_rope recut reads complete; 3.9s cloudwhale reads thin — duration
  alone decides neither).

---

## 7. Audio and narration

### What was actually verified (per method)

- **Listening:** no human listening test on any final mix (pilot review
  states this explicitly). What "verified" means in this project is:
  Whisper detection + loudnorm + TP + boundary dB slices + frame checks.
  Do not upgrade that to "listened and approved."
- **ASR:** faster-whisper tiny/base on source audio, VO audio, and final
  mixes; English p=1.00 widely reported; word timestamps used for card
  timing (pilot v3: 26 events timed to Whisper word timestamps).
- **Audiovisual model analysis:** none evidenced in RexTrix logs (see §8).
- **Waveform inspection:** boundary slices (0.1s slices around joins,
  e.g., G3 cut_rope splice −19 to −24 dB; card-first-0.5s peaks) and PCM
  card silence (exact zero / ±1 LSB). Used, and it caught real issues
  (card-join transients, get_up tail).
- **Loudness measurement:** atrim / pre-trimmed loudnorm, I and TP, on
  content sections; whole-file figures quoted only as diluted references.
  Sample parent-verified finals: C2 I −16.04/TP −3.58; C3 I −16.26/
  TP −2.50; G5 range I −16.00 to −16.46/TP −1.08 to −1.55; G2 clip-2
  re-QC I −16.22/TP −1.68 (fixer figure reproduced exactly). OBSERVED.
- **Stream/decode checks:** null decode + faststart (moov before mdat)
  on every delivered file; corrupt files quarantined (renamed, never
  deleted): G4 seg0 files (moov not found), B4 corrupt window, G1 first
  final (missing moov, rebuilt). OBSERVED.

### Dialogue wording, speaker identification, speech boundaries

- **Wording confidence:** high where baked subs corroborate; stated as
  Whisper-limited where they do not (wormhole "Move!" tail, redundancy
  "hid"→"hit me," C3 survivor line in the fallback). No diarization was
  performed: speakers are identified by scene role (the witch, the boy,
  Voss), never by voiceprint. Any claim of "who said what" rests on
  subtitles + frames, not on speaker ID. OBSERVED.
- **Speech-boundary confidence:** low from VAD-merged segments (6.5–44.2s
  as one segment — timestamps unusable as cut boundaries, G2 hold note);
  high from no-VAD passes + frame-read baked subs (the method that
  caught the G2 mid-sentence cut). The project's own rule (never use
  VAD-merged segments for cut boundaries) is TESTED by that catch.
- **Waveform/timestamp treated as proof of complete speech (error
  case):** G2 original: NOTES claimed the thought ended at "Yes. How did
  you know?" while the delivered last frame showed the next line's
  subtitle and speech was active across the cut. The error mechanism:
  trusting a note/transcript end-point instead of checking speech
  activity across the boundary. Fixed by the boundary-speech check
  (pause 353.0–353.2s, next sentence first at ~353.5s). OBSERVED.
- **Seen subtitles mistaken for heard dialogue (error risk, caught
  once):** C2's "owner shouts" beat: the viewer sees the baked sub "get
  down it's not safe" and hears the VO say the owner shouts — but no
  owner shout is heard and no owner face is in the opening reframe. The
  QC report discloses this; it is narration-asserted, not heard. The
  same class applies to any VO line whose evidence is a baked sub
  rather than audible speech. OBSERVED (C2), HYPOTHESIS as a general
  risk for other VO lines (not audited line-by-line for this debrief).

### Music, dialogue, ambience, SFX, VO responsibilities

- **VO:** carries story (cinematic, pilot). Never cut (cinematic rule);
  offsets 0.0/+0.5s; breath tails before cards (C2 0.90s, C3 2.73s
  spirit-payoff tail).
- **Source dialogue:** carries story (batch-30 dialogue clips) or is
  silenced (all VO clips). Never bedded under VO after v1 — standing
  rule, TESTED by the v1 defect and its fix.
- **Music:** mood bed only, ducked 0.35 under VO (cinematic) or −9 dB
  stem duck under speech (edit-3). Single native mix where no competing
  tracks exist (G6). Music-only clips: level-matched only, otherwise
  untouched (§5).
- **Ambience:** 0.18s room-tone pads around dialogue cuts (cinematic
  template); 0.15s sentence buffers (warning template, unbuilt). No
  ambience track is separately credited in any delivered file; "room
  tone" here means short fades/silence, not a designed bed. OBSERVED.
- **SFX:** ffmpeg-synthesized accents only (C2 whoosh 5.0s + soft hit
  10.0s; C3 chime 16.0s; gain 0.12, ducked low). No verified licensed
  library was found on disk. Any future SFX claim must name the actual
  file and license. OBSERVED from C2/C3 QC reports.

### Narration usefulness, factual support, delivery, timing

- **Usefulness:** VO monologues add trait/stakes/invitation the picture
  lacks (see §4). Factual support is package-lined (baked sub +
  transcript + frame per claim) but cross-window evidence is disclosed
  only in packages, not to viewers. Delivery: ElevenLabs "Hope," v4;
  quality to a human listener UNKNOWN (no listening test). Timing: VO
  never cut; picture cut to VO; card follows the invitation line. The
  warning template's payoff-into-card flow ("don't say I didn't warn
  you" → card as punchline landing) is unbuilt and therefore
  HYPOTHESIS as a device.

### Licensing and permission

- **YouTube Audio Library tracks (C2/C3):** "That's Right I'm Country"
  (western) and "Silly Snickerdoodle" (whimsical), YouTube Audio Library
  License, monetizable, NO attribution required. Verified on disk
  (ffprobe durations/sizes match). OBSERVED.
- **MacLeod candidates (9 files on disk, unused):** CC BY 3.0,
  attribution MANDATORY if used (`Music: [Title] by Kevin MacLeod
  (incompetech.com), licensed under CC BY 3.0`). Fit judged from
  titles/catalog, NOT by ear. Any future use must add the attribution
  and accept false-Content-ID dispute risk (noted on record). OBSERVED
  (files exist; use = none).
- **Edit-3 stems:** derived from campaign footage itself (no-vocals
  stems of the project's own clips) — no third-party license question,
  but reuse across clips is noted per package (c1/c2 reuse). OBSERVED.
- **Synthesized SFX:** original ffmpeg output — no license question,
  but also no library provenance; do not describe them as library SFX.
- **Narration permission assumed vs unavailable:** Fish key was
  authorized and present; its 402 is exhaustion, not permission denied.
  ElevenLabs was available via the user's browser session throughout,
  but subagents cannot use a browser — so scouts recorded "VO BLOCKED"
  while a VO route existed at the parent level. The permission was not
  missing; the routing was. See §10.

### Loudness / true peak / intelligibility / processing artifacts / sync

- Gates held on delivered files (see sample figures above); tightest
  passes: G2 built_not_disaster I −16.90 (0.10 LU inside the 1 LU gate),
  G3 cut_rope I −16.80 (0.80 LU off), B3 TP −0.9903 → fixed to −1.078.
  Processing artifacts: none reported (no pumping/distortion); the
  loudnorm two-pass undershoot on peaky SFX (G4) is a method note, not
  an artifact. Sync: wild 0.03s A/V offset (inaudible, not a fail);
  0.03s-class offsets appear twice on record and are consistently judged
  immaterial. OBSERVED.
- **Do not claim normalization will fix audio.** No platform
  normalization behavior is on record in this project, and the project's
  gates (−16 LUFS, TP ≤ −1) are delivery specs, not platform guarantees.
  A clip that passes here can still be gain-changed by a platform; that
  is UNKNOWN for these files (never posted, except pilot v3 + T1/T3,
  for which no post-publish loudness read exists).

### Picture edits needing different audio boundaries

- G2 clip-2: picture boundary moved to 353.2s because the AUDIO
  boundary (speech pause) was there; the picture cut follows the audio,
  not the reverse. Cut_rope splice placed in a speech gap. B5 "App."
  card timing vs device entrance (0.19s overlap) is a picture/text
  boundary, not audio, but the same principle applies: boundaries must
  be verified in the modality that carries the information (speech
  pause for speech, subtitle switch for text). OBSERVED.

---

## 8. Vision / audiovisual model reliability

### What was actually invoked — and what was not

- **No NVIDIA vision-model invocation is evidenced in any RexTrix log
  re-read for this debrief.** Grep of the batch-30 coordinator log,
  batch-15 assembly log, T-draft rebuild notes, and both rule files
  returns zero mentions of OMNI, nemotron, llama, or 11b-vision. The
  QC-model instruction (OMNI for joint text+image+audio; 11b-vision for
  frame contact sheets) exists in the wider workspace (Boxabl context)
  and is referenced in session memory, but no RexTrix QC report cites a
  model ID, an endpoint, or a model-returned artifact. Frame checks in
  RexTrix QC were: the main agent viewing extracted stills, and QC
  agents viewing frames — human/model viewing of stills, not a
  vision-model API call on record.
- **Therefore this section's honest scope is:** Whisper (ASR) +
  human/frame viewing + ffmpeg measurement. Any claim that "the vision
  model checked these clips" would be invented. UNKNOWN whether any
  subagent called a vision API without logging it; the absence of
  evidence is itself a logging gap (see §9: model calls must be logged
  with ID + input + output, or not claimed).
- **Inputs/modalities for the checks that did run:** extracted stills
  (1fps sheets, 10s-interval frames, full-size frames, boundary frames);
  audio via Whisper; measurements via ffmpeg. No raw video was passed
  to any model on record (consistent with the workspace note that no
  model takes raw video — sampled frames only).

### Whisper: findings, contradictions, failures

- **Invented events/dialogue:** no Whisper invention of an event is on
  record. The invention risks on record are human-side: guessed name
  spellings (Miris/Mira/VARANORC) from Whisper output, controlled by
  withholding names without baked-subtitle evidence. OBSERVED control.
- **Incorrect/impossible timestamps:** VAD-merged segments (6.5–44.2s as
  one segment) — timestamps unusable as cut boundaries (G2 hold note);
  1fps sheet tile mapping offset ~1s mid-file (C2 title/desert boundary
  — caught by exact-seek measurement, desert moved to 72.5s).
  OBSERVED, both caught by a second method.
- **Observation vs inference confusion:** Whisper "Neil" vs baked
  "kneel" (inference from audio vs observed text — baked won); Whisper
  "Rex Tricks" vs script "RexTrix" (ASR artifact vs ground truth —
  script won); Whisper "You're mild" vs stem-version "Every survivor
  eventually meets me" (low-quality audio inference vs cleaner-audio
  inference — cleaner won, and the fallback correctly left the line
  uncaptioned rather than guessing). OBSERVED.
- **Qualifications dropped:** Whisper merges and garbles shouted/
  overlapping fantasy dialogue (Hells Army transcript note: "several
  segments are garbled merges"); packages lean on baked subs where
  Whisper is unreliable — the correct control, and the reason baked-sub
  reading is a required QC step, not an optional one.
- **Text misread as spoken audio:** the reverse error is on record as a
  risk, not a confirmed case: baked subs are sometimes the only evidence
  for a VO line (C2 "owner shouts" — see §7). No case where a QC report
  claims "heard X" on the sole basis of a baked sub is confirmed, but
  no line-by-line audit separating heard vs seen evidence exists for
  batch-30/15 VO lines. UNKNOWN for lines not specifically audited.
- **Overconfident quality/engagement judgments:** no model made an
  engagement judgment on record. Overconfident PASS judgments came from
  builders (self-QC), not models: G1 audio, G3 audio, B3 TP — all
  overturned by independent re-measurement. The mechanism (self-interest
  + method error) differs from model overconfidence, but the control is
  the same: independent reproduction.
- **Incorrect "pass" findings:** G1 audio PASS (builder) → FAIL
  (independent, bitrate method); G3 audio FAIL (independent, full-file
  method) → OVERTURNED (content-only method) — a false fail, the
  mirror error, caused by the same method confusion; B3 TP −1.00
  (builder, 2-decimal) → FAIL (independent, 4x oversampled −0.9903).
  All three are measurement-method errors, not perception errors.
  OBSERVED.
- **Credential / timeout / capacity / format / parsing problems:**
  faster-whisper broken in the G2-QC environment (`av`
  metadata_errors incompatibility) and again for C2/C3 parent
  verification (same incompatibility; openai-whisper not installed) —
  an ENVIRONMENT failure, not a model failure: the same tool worked in
  scout environments. Parser bug: C3's QC script read ffprobe columns in
  the wrong order and returned 0.0 kbps before being fixed and
  re-measured (194.6 kbps) — a parsing error caught by re-measurement.
  Curl deaths mid-download (range-resumed to exact byte size) and VM
  restarts are infrastructure, not model, failures. OBSERVED.
- **Authentication vs absent credential vs provider error (kept
  distinct):** Fish 402 = provider-side credit exhaustion with a valid
  credential present (NOT an auth failure, NOT an absent key). Discord
  "new login location" = provider challenge requiring the user's email
  verification link (NOT a wrong password). Aze vault password = a
  genuinely stale/wrong saved credential (rejected twice by Google;
  user bypassed via direct sign-in). Conflating these three produces
  three wrong fixes; the logs keep them separate and so should any
  future incident note. OBSERVED.
- **Were model outputs consumed by edits, or merely saved?** Whisper
  outputs were consumed: transcripts selected windows, timed cards,
  and caught the G2 cut. No vision-model output was consumed on record
  (none evidenced). Scout packages were consumed by assembly (windows,
  evidence lines, music picks, flags). QC reports were consumed by fix
  loops (narrowed to failed clips only, with md5 untouched checks).
- **V1/V2/V3 evidence value:** pilot v1 proved the bed defect (negative
  evidence, high value); v2 proved the TP fix method (audio re-mux);
  v3 proved the doubling trap (captioning over a captioned render) and
  its fix (rebuild from captionless segments). Each version added
  distinct evidence; none was a mere restyle. Edit-3 fallback → stem
  versions added the ducking evidence (music stem −9 dB under speech;
  total mix moved only −0.1 to −0.3 dB because vocals already
  dominated — an honest limit, not a failure). OBSERVED.
- **Checks that remained unavailable:** transcript re-verification in
  the C2/C3 parent environment (faster-whisper broken); human listening;
  any vision-model second opinion; retention analytics; a duck-ratio
  measurement from a finished mix. All are listed as UNKNOWN/limits in
  their QC reports rather than papered over — the correct handling, and
  the reason this debrief can trust those reports' other claims.
- **Do not assume a second model would solve the problem.** The
  failures on record are method failures (wrong bitrate denominator,
  wrong TP downmix, VAD timestamps, parser column order) and routing
  failures (VO via browser-only session). A second model reproduces
  none of those fixes; independent re-measurement and frame checks do.

---

## 9. Implementation and recovery

### Capability matrix (documented / installed / feature-tested / approved-for-project)

| Capability | Status on record | Evidence |
|---|---|---|
| ffmpeg/ffprobe | Installed, feature-tested on every file, approved | All QC reports |
| demucs 4.1.0 (CPU torch) | Installed after disk-full failure; feature-tested on edit-3 stems; approved for stem work | `~/workspace/demucs-venv`, edit-3 review addendum |
| faster-whisper tiny/base | Installed; feature-tested in scouts; BROKEN in G2-QC + C2/C3-parent envs (av incompatibility) | Coordinator log, assembly log |
| openai-whisper | Not installed | Assembly log limit note |
| smart-reframe skill | Documented + used; failed on Crow doorway, Primal armor-mass, G3 moves | Coordinator log, QC reports |
| Montserrat Bold font | Installed (`~/.local/share/fonts/`), tested (ASS renders true Bold) | Briefs, QC reports |
| ElevenLabs "Hope" v4 | Browser session (engload23), feature-tested (pilot + 15 VOs), approved | Pilot review, assembly log |
| Fish Audio API | Credential present, feature-tested → 402 exhausted; NOT approved as sole VO route | Pilot/scout notes |
| Google Drive connector | Connected, feature-tested (survey + downloads) | Survey inventory |
| YouTube Studio + Content Rewards via browser | Feature-tested (uploads, chains, submissions, pause check) | Manifest, upload records |
| Muse remote-storage upload | Feature-tested → FAILED (approval timeout); fallback = chat attachments | Delivery record (summary) |
| NVIDIA vision models | Documented (connector + Boxabl QC instruction); NO invocation evidenced for RexTrix | Grep: zero mentions in RexTrix logs |
| Licensed SFX library | Claimed in §10 ("existing SFX library"); NOT FOUND on disk for C2/C3 | C2/C3 QC reports |
| Kenney SFX (pro-engine) | Directory does not exist on disk | C2/C3 build notes |
| FreePD | Permanently closed; not an asset | Prior session record |
| MacLeod tracks | Downloaded (9 files), unused, CC BY 3.0 attribution required | `batch-15/music/` |

### Catalog entries that were only links, examples, or recipes

- Warning-template script: recipe, 0 builds. Benched templates: recipes
  + bench rationale, 0 builds. MacLeod list: downloaded files, 0 uses,
  fit judged from titles only. "Existing SFX library": a phrase in a
  rule, not a verified directory. The Drive survey's "promising new" 33:
  title classifications, not vetted shows. Any future brief that cites
  these as available assets without re-verifying repeats the SFX error.

### Smallest adaptations that solved real needs

- Direct-download route (`uc?export=download&id=`) after Drive UI
  downloads failed unconfirmed — solved all episode fetching thereafter.
- Curl + range-resume (`-C -`) after mid-download deaths — solved
  truncated episodes (including a 188MB truncated apocalypse download
  with no moov, re-downloaded fresh).
- TMPDIR + pip cache on home storage after /tmp disk-full — solved the
  demucs install (CPU torch only).
- Content-only bitrate + atrim loudnorm + stereo oversampled TP + PCM
  card silence — solved four false fail/pass classes with method
  changes, not waivers.
- Audio-only fix + remux (video copied untouched, framemd5 identical
  for B3) — solved TP/boundary issues without video re-encode.
- Pillarbox strip-over-blur — solved subtitle slicing without
  re-framing, at the price of blur area.
- Quarantine-by-rename (never delete) for corrupt files — preserved
  evidence (G4 seg0, B4 window, pre-fix files with md5s).

### Unnecessary frameworks, installations, repeated tests, architecture

- The CUDA torch download attempt (disk-full) before falling back to CPU
  torch: wasted a full install cycle; CPU was sufficient throughout.
- Repeated full-file bitrate measurements across groups before the
  content-only correction was written down: G1, then G3, then the
  correction. The second occurrence was preventable by writing the
  method down after the first — the ledger now does this, but only
  because the error repeated.
- The G3 old-builder hold-terminal + respawn: a runtime delivery gap
  (completion handoff unseen) forced a fresh builder with full spec.
  Cost: one full respawn + background-file pointer work. No work was
  lost (scouting preserved on disk), which is the recovery lesson, not
  the failure: on-disk state, not handoff delivery, is what survived.
- No unnecessary framework is on record beyond these: the pipeline is
  ffmpeg + scripts + logs, and its simplicity is a strength. Do not
  "upgrade" it without a failing case.

### Encoding, timing, frame-mapping, audio-latency, compatibility failures

- **Missing moov / partial writes:** G1 first final, B4 window, G4 seg0,
  truncated apocalypse download — all caught by probe/decode before
  promotion. Mechanism: killed renders + truncated downloads. Control:
  null decode + moov/faststart check before promotion (ledger 27).
- **Frame-mapping:** stream-copy extraction frame-inaccurate (C2 first
  build 22.17s for a 21.5s plan — discarded, re-extracted with
  re-encode to exactly 645 frames); 1fps sheet tile offset ~1s (C2
  boundary); output-position `-ss` on volumedetect silently ignored
  (whole-file stats returned — G3 re-QC first attempt). All three are
  "the tool silently did something else" failures; all were caught by
  exact-seek or frame-count verification, never by trusting the first
  number.
- **Audio latency / sync:** 0.03s-class A/V offsets (wild, shark
  overhang 0.03s) judged immaterial twice; card-join transients
  (≤1-frame boundary, AAC smear −55.3 dB claimed once, disproved to
  exact zero on re-measurement — G4 gets_up). No latency failure
  affected a delivered file's verdict.
- **Compatibility:** AAC 192k @ 48kHz stereo explicit after the 96 kHz /
  44.1 kHz mixture in G1; 944:945 SAR (0.1%, invisible) explicitly not
  re-encoded. Colour-space reconfiguration past card joins (bt709 vs
  unknown) documented, not a defect. No playback-compatibility failure
  is on record for a delivered file.

### What a failure actually established vs the initial diagnosis

- G1 "bitrate fail" initially diagnosed as an encode failure; actually a
  measurement-denominator error (silent card dilution). Fix: method, not
  encode — though the fix loop re-encoded audio anyway (mechanical,
  harmless, and it normalized sample rates — a side benefit, not the
  cause).
- G3 "audio fail" initially diagnosed the same way; actually the same
  denominator error; the coordinator overturned it by re-measurement
  instead of re-encoding. The two handlings differ, and the second is
  the better precedent: re-measure before re-encoding.
- B3 "TP −1.00" initially read as a pass (2 decimals); actually a fail
  at 4x oversampling (−0.9903). Fix: gain-only, video untouched.
- Fish "VO blocked" initially read as a missing credential; actually
  provider exhaustion + a routing gap (browser-only ElevenLabs at parent
  level). Fix: route, not credential.
- "Bot activity" rejections: initial operator-side hypotheses (geography,
  seeding, bots) all fail on record — geography was not the reason
  (One Player 92.6% US, still rejected), no bots/boosts were used, the
  planned seeding never ran, and support will not disclose flag metrics.
  What the failure establishes: the trigger is UNKNOWN and
  undisclosed, not operator-confirmed. Any future "avoid bot flags by
  X" advice is HYPOTHESIS until a disclosure or a controlled
  comparison exists.

### Failed attempts that taught something reusable

- Drive UI downloads (virus-scan "Download anyway," action "unknown,"
  nothing landed) → direct-download route (reusable, still the rule).
- Demucs CUDA install (disk-full) → CPU torch + home TMPDIR (reusable).
- /tmp workdir loss (edit-3 build script) → recreate from spec in the
  project folder (stem_audio.py now lives in edit-3/, not /tmp).
- Old G3 hold-terminal (undelivered completion) → fresh builder +
  on-disk state pointers (reusable: never depend on handoff delivery
  alone; always leave state on disk).
- Remote-storage delivery (approval timeout) → chat attachments as
  authorized fallback (reusable, but a fallback, not a strategy —
  direct-download links remain the rule).

### Environment differences that invalidated earlier assumptions

- /tmp is a 512M tmpfs wiped on restart: venvs and workdirs there do not
  survive. Home disk (100G) is the durable location. Any brief that puts
  build state in /tmp is broken by design.
- VM restarts kill builders mid-render (G4/G5 restart drain, G3 chain
  deaths, G4 reframe deaths): idempotent, resume-from-verified-
  intermediate builds are required, not optional.
- faster-whisper works in scout envs, breaks in QC/parent envs (av
  incompatibility): tool availability is per-environment, not global.
  A brief that assumes "Whisper is available" without naming the env is
  under-specified.
- Browser sessions persist across restarts (Google sessions, ElevenLabs)
  while subagent handoffs do not reliably deliver (G3, G6-QC "completed"
  with no report until later): durable state lives on disk and in
  sessions, not in delivery promises.

### Fresh-session recovery check (can a new session do this?)

- **Locate originals and exports:** YES for batch-30/15 finals (bare
  names in group/finals dirs), T-rebuilds, edit-3 edits + originals,
  pilot v3, scout windows. PARTIAL for batch-5/6 (files exist; not
  re-inventoried here) and for batch-15 set-1/set-2 intermediates
  (work/assembly/ referenced in logs, not re-verified here).
- **Identify versions and hashes:** YES as of this debrief —
  `file_hashes.txt` + `EVIDENCE_INDEX.json` give sha256 for 20 docs,
  36 batch-30 deliverables, 8 group-6 prior-version files, 12 batch-15
  finals, and 6 T/edit-3/pilot files. NOTE from hashes: six group-6
  `_v1` files (chase, map, creature, glow, night) and fall_v3 are
  byte-identical to their bare deliverables — they are copies, not
  distinct renders. A fresh session must not treat a `_v` suffix as
  proof of a distinct version; the hash decides. Only fall_v1/v2 differ.
- **Reconstruct source-output mapping:** YES for batch-30 (coordinator
  log + per-group NOTES/QC reports + source timestamps in notes) and
  batch-15 (scout packages give source file + window + evidence lines;
  assembly log gives VO + music + card per clip). NO single
  machine-readable index exists — reconstruction requires reading the
  logs. That is the missing asset (see below).
- **Recover caption/graphic/audio decisions:** YES for T-rebuilds
  (.ass files on disk), C2/C3 (ASS re-parsed in QC reports), pilot
  (build script + review). PARTIAL for batch-30 groups (ASS/drawtext
  sources live in group work/ dirs, referenced but not centrally
  indexed here).
- **Understand permissions and missing checks:** YES from this debrief
  + `NEVER_REPEAT_RULES.md` + manifest (holds, rulings pending, pause).
  The pending human rulings (guns, Crow-Ash/Reaper/Rat King, T2, warning
  count, vault separation) are all named in §13/open questions.
- **Make a requested revision without rebuilding from chat:** YES for
  audio-only revisions (B3 precedent: gain + remux, video untouched)
  and for card/text revisions where .ass + segments survive; NO for
  any clip whose build script or segment list is missing (batch-15
  set-1/set-2 build scripts referenced as build.sh in logs — not
  verified here; treat as "referenced, verify before promising").

### Missing recovery assets (precise)

1. A machine-readable clip index: clip → source file + window → VO file
   → music file → card source → build script → QC report → hash.
   (Logs contain it in prose; no JSON/CSV exists.)
2. G1 `work/audiofix/` folder referenced in NOTES.md — does not exist
   (log states this; verdict rests on delivered files' measurements,
   so this is a documentation gap only).
3. `/tmp/edit3/` workdir — lost in a restart; recreated as
   `edit-3/stem_audio.py` (recovered, not missing, but the original
   is gone).
4. SBE-07..13 scouts — never made (T2).
5. Per-clip retention/view analytics for batch-30/15 — never existed
   (held, unposted).
6. The 7 rejection screenshots Emy requested — never pulled.
7. Chain-edit verifications for D2/D3/D4 (public pages do not show
   related videos) and clip-1's chain re-point — unconfirmed.
8. Batch-5/6 per-clip QC reports — exist on disk, not re-read here;
   treat any claim about them beyond the manifest as second-hand.
9. Model-call log — no record of any vision-model call (ID, input,
   output) for RexTrix; if one happened, it is unrecoverable from logs.

---

## 10. Prompt and operator-pressure audit

Quoted wording is verbatim only where a project file records it; otherwise
it is labelled a paraphrase from the session record. Each entry: the
instruction, the observable interpretation, the output affected, real
conflict vs misinterpretation, smallest correction, protection to keep.

### 1. Numerical target: "30 quality intentional professional looking clips… ready to upload, double check each, review independently and honestly" (paraphrase of the 2026-10-29 order; brief adds "honesty over count")

- **Interpretation:** target 30, but the brief's honesty rule overrode the
  count. Builders reported gaps instead of padding (group-5 edit-3 scout:
  ZERO strong moments; batch completed 34 passed without padding).
- **Affected:** batch-30 (positive). The count did not produce filler —
  this time.
- **Conflict vs misinterpretation:** real tension (count vs quality),
  resolved correctly by an explicit override rule in the brief. Without
  that sentence, the same order would predictably have produced padding.
- **Smallest correction:** every numerical order gets its override in
  the same sentence ("deliver the strong ones and report the gap").
- **Keep:** honesty-over-count, stated before the number, in every brief.

### 2. "Keep it simple" — did it become "avoid authorship"?

- **Instruction on record:** the brief's "no gimmick padding," "one clean
  audio design per clip," and §4's bans (no loops/freeze/slow-mo).
- **Interpretation:** builders avoided devices, which is correct — but
  the same pressure also produced gloss cards that summarize instead of
  interpret, and a reluctance to reorder (only edit-3 C3 reordered, and
  it was rejected). Simplicity was interpreted as "don't touch the
  source's order," which is not the same as "keep it simple."
- **Affected:** batch-30 (chronology preserved everywhere; no
  result-first variant attempted).
- **Conflict vs misinterpretation:** misinterpretation, partly. The
  brief never forbade reordering; it forbade faking. The correction is
  to name reordering as allowed when evidence supports it.
- **Smallest correction:** brief line: "Reordering is allowed when the
  reordered beat is frame-verified; faking is never allowed."
- **Keep:** the bans on loops/freeze/slow-mo padding and faked UI.

### 3. "Professional" — did it become "add more effects"?

- **Instruction on record:** `CLIP_RULES.md` §7 (user correction):
  "Professional = clean style AND sharp copy AND readable size."
- **Interpretation:** correctly resisted effect-adding. The project never
  added shakes/flashes/transitions to look "professional." The risk ran
  the other way: "professional" as clean-but-generic (see §5 hooks).
- **Affected:** batch-30/15 caption systems (clean, consistent within
  batch).
- **Conflict vs misinterpretation:** neither — the user's own correction
  already fixed the likely misreading before this batch. Credit where
  due: §7 is a good rule because it defines professional by copy and
  readability, not by effect count.
- **Smallest correction:** none needed; keep §7 verbatim.
- **Keep:** "sharp, specific, tied to the visual in the same seconds"
  as the hook-copy test.

### 4. "Human edit feel" (user direction 2026-10-30, recorded in §10) — did it become a new template?

- **Instruction on record:** §10: cut on beats, vary shot lengths, hold
  reactions, one punch-in/push per clip max, one pattern interrupt per
  clip, vary openers/pacing, "two clips must not share the same edit
  beat-for-beat."
- **Interpretation:** C2/C3 applied it differently per clip (portal
  escalation + title-beat interrupt vs wide open + reaction-before-
  reveal + single push) — the correct reading. But §10's own devices
  (one punch-in, one interrupt) risk becoming the new stamp if a future
  brief checks "punch-in present?" instead of "does it feel human?"
- **Affected:** C2/C3 only (postdate §10); batch-30/15 predate it and
  were correctly NOT retrofitted.
- **Conflict vs misinterpretation:** real tension: a rule against
  templates, expressed as a template. Resolved by treating §10's devices
  as a menu with a "vary or omit" clause — which the text does not
  currently contain.
- **Smallest correction:** add one line to §10: "Omit any device that
  does not serve this clip; a clip with no punch-in and no interrupt
  still passes if its pacing serves its scene."
- **Keep:** "human does not mean sloppy" + the non-retrofit clause.

### 5. "Never repeat mistakes" (file-recorded order in NEVER_REPEAT_RULES.md header: "mistakes seen in clips must never be repeated, and every clip must get better than the last") — did it become checklist-passing?

- **Interpretation:** a 34-entry ledger with auto-FAIL for any repeat,
  required reading for every brief/QC/upload. It caught real repeats
  (method errors) and grew correctly (entries 21–28 are method fixes).
- **Affected:** all batches after 2026-10-30; enforcement is prospective.
- **Conflict vs misinterpretation:** real risk, not yet a failure: an
  ever-growing auto-FAIL ledger eventually fails clips for taste
  entries (e.g., "weak hook") as if they were compliance entries
  (e.g., "no bots"). The ledger currently mixes both without severity
  tiers.
- **Smallest correction:** tag each entry with a tier — COMPLIANCE/
  SAFETY (auto-fail), MEASUREMENT (auto-fail on method), CRAFT
  (flag + disclose, human decides). Do not change any entry's content
  in this debrief; tiering is a proposed amendment for user approval.
- **Keep:** auto-fail for compliance/safety/measurement; the
  "append before the next batch" growth mechanism; scoped exceptions
  recorded as dated exceptions, never silent rewrites.

### 6. "Check every corner of Drive" (user order, recorded in the brief's scope update 2026-10-29 ~16:25 PKT) — scope explosion mid-batch

- **Interpretation:** groups 2–6 held, survey run, assignments replaced,
  G3 respawned. The survey itself was valuable (101 folders classified).
- **Affected:** batch-30 schedule + builder churn (holds, respawn,
  restart deaths overlapping the hold window).
- **Conflict vs misinterpretation:** real conflict: a mid-batch scope
  change vs a running production. The coordinator handled it correctly
  (holds acknowledged, no builds finalized on stale assignments), but
  the cost was real and avoidable.
- **Smallest correction:** survey phases run BEFORE briefs. A brief
  freezes its pool; new material enters the NEXT brief, not the running
  one — unless the user explicitly orders a mid-batch re-scope and
  accepts the churn.
- **Keep:** the survey itself and its title-is-not-a-verdict rule.

### 7. "Autonomous" — did Swiss authority leak into RexTrix?

- **Instruction on record:** Swiss clipping (2026-10-12/13): full
  autonomous approve+publish authority. RexTrix: per-file approval.
- **Interpretation:** kept separate. RexTrix uploads waited for the
  user's word per version; the 2026-10-30 blanket word was treated as
  covering passed clips, then the HOLD overrode it. No RexTrix clip was
  uploaded on Swiss authority.
- **Affected:** none negatively — but the blanket-word reading is the
  fragile point (see entry 8).
- **Conflict vs misinterpretation:** potential misinterpretation
  avoided by luck + the hold, not by a written boundary.
- **Smallest correction:** brief header line per campaign per batch:
  "Authority for THIS batch: [per-file | blanket for listed versions |
  autonomous]. Expiry: [date/condition]."
- **Keep:** per-file approval as the RexTrix default.

### 8. Blanket authorization vs exact-version approval (2026-10-30 "start uploading now, paced with gaps")

- **Interpretation:** treated as authorization for the passed clips
  (34 + 10 at the time). The upload run then hit the pause at clip 1.
- **Affected:** clip 1 (uploaded, not submitted — see §9 pre-flight
  failure, which is separate from the authorization question).
- **Conflict vs misinterpretation:** real ambiguity: "start uploading
  now" names no versions, no channel order, no expiry. The main agent
  resolved it against the delivered-passed list, which was reasonable
  but not explicit. The user's later HOLD shows the authorization was
  narrower in practice than the run assumed.
- **Smallest correction:** a blanket word must name the version list
  (or "all currently passed finals") + an expiry ("this session" /
  "until the pause lifts") before the run starts; otherwise treat it as
  per-file and ask.
- **Keep:** the 30-minute same-session submit rule and the per-clip
  upload checklist.

### 9. "Reuse tools" / "use skills" — did it prevent a justified small implementation?

- **Instruction pattern:** smart-reframe skill reused for landscape
  sources; "existing SFX library" cited in §10.
- **Interpretation:** saliency reframe was the default even after
  visible failures (Crow doorway, Primal armor-mass) — manual windows
  were the fix, but only after a failed saliency pass each time. The
  SFX "library" was cited without verification and did not exist; the
  actual implementation (ffmpeg-synthesized accents) was small, honest,
  and worked — but it was presented as a fallback, not as the asset.
- **Affected:** G3, G4, C2 (reframe retries); C2/C3 (SFX provenance).
- **Conflict vs misinterpretation:** misinterpretation: "reuse" was read
  as "try the skill first, always," instead of "use the skill when it
  fits, verified on frames." The skill itself is fine; the default is
  the problem.
- **Smallest correction:** brief line: "Saliency reframe is a proposal:
  verify on frames before building; budget the manual window as the
  expected path for dialogue scenes." And: "Name SFX assets by file +
  license, never by 'library.'"
- **Keep:** the skill itself and the frame-verification requirement.

### 10. Missing credentials as an excuse to stop unrelated work

- **Case:** Fish 402 → scouts recorded "VO BLOCKED" and produced
  picture-only windows. Unrelated work (scouting, grading, music
  selection) continued — good. But the VO route through the parent's
  ElevenLabs browser session was not sequenced into the scout brief, so
  "blocked" persisted until the parent recorded VOs later. The stop was
  partial and procedural, not total — but it still delayed assembly.
- **Affected:** batch-15 scouts → assembly handoff.
- **Conflict vs misinterpretation:** misinterpretation (routing gap,
  not permission gap — see §8).
- **Smallest correction:** brief fallback order, explicit: "VO engine
  order: (1) parent ElevenLabs session, (2) Fish if credits return,
  (3) picture-only windows + flagged VO gap. Never stop scouting for
  a VO gap."
- **Keep:** "do not substitute silently" (never fake a VO).

### 11. User frustration / agreement — the edit-3 verdict

- **Instruction on record:** user verdict (2026-10-29): "these are not
  good clips still" (paraphrase spelling normalized; wording from
  session record).
- **Interpretation:** accepted without asking for one defect per clip.
  The main agent moved on to batch-30 scouting instead of extracting
  the reusable defect. This is the main agent's failure, not the user's:
  a frustrated verdict is still an instruction, but an unactionable one
  should be clarified before the next build, not obeyed by changing
  subjects.
- **Affected:** edit-3 (no fix loop), batch-30 group-5 scouting (which
  independently reached the pool-exhaustion verdict — a lucky second
  opinion, not a substitute for the missing defect list).
- **Conflict vs misinterpretation:** neither a conflict nor a prompt
  defect — an execution failure: the agent agreed too readily by
  changing the subject instead of asking one question.
- **Smallest correction:** on any blanket rejection, reply with: "Noted.
  Before I rebuild: one defect per clip, in your words, so the fix
  targets it." Then rebuild.
- **Keep:** the user's right to a blanket verdict; the agent's duty to
  make it actionable.

### 12. New feedback abandoning a sound decision without evidence

- **Case:** none confirmed on record. Counter-cases exist: the 2.5s card
  was NOT generalized beyond its scope despite repeated use; the
  pillarbox deviation was NOT generalized beyond G2/G3 Crow; the G3
  audio FAIL was overturned by re-measurement, not by abandoning the
  gate. Where feedback did change a decision (B3 letterbox acceptance),
  it was a user decision with a recorded alternative (re-render vs
  accept), not an abandonment.
- **Watch item:** the "professional captions" vs "viral captions"
  tension. The pilot-only scoping (§8) is the protection; if a future
  brief copies the pilot's centered captions without the "pilot-only"
  label, that will be the abandonment case. Flag it here so it is
  recognizable when it happens.

### 13. Compliance checking displacing creative development

- **Pattern on record:** briefs and QC reports are dominated by
  card/logo/CTA/bitrate/loudness gates; the creative content of a clip
  is one line ("hook," "weakest point") in a note. The G2 fix loop is
  the exception that proves the rule: it fixed a creative defect
  (mid-sentence ending) with a creative solution (extension), and it
  required a QC agent to notice a speech boundary — not a gate.
- **Affected:** all batches (structure, not any single clip).
- **Conflict vs misinterpretation:** real structural tension: gates are
  checkable, creativity is not, so checkable work expands to fill the
  brief. The brief never required an "idea in one sentence" or "what
  the viewer learns/feels" per clip.
- **Smallest correction:** per-clip note header, before specs: "Idea
  (one sentence). Promise (first 3s). Payoff (last 5s). What the viewer
  learns or feels." Gates stay; they stop being the whole note.
- **Keep:** every compliance gate (they prevent rejections) — but as
  gates, not as the definition of quality.

### 14. Fear of hallucination preventing useful, labelled interpretation

- **Pattern on record:** name withholding (Miris/Mira, VARANORC, Cord,
  Leo) is correct restraint. The over-restraint case is gloss cards:
  G2's "A PLAN, NOT CHANCE" is an interpretation, judged accurate —
  but no other batch-30 clip attempts an interpretive gloss, and no
  brief invites one. The fear (inventing meaning) suppressed a
  legitimate device (interpreting visible meaning).
- **Affected:** batch-30 glossing (underused).
- **Conflict vs misinterpretation:** misinterpretation: "never invent"
  was read as "never interpret." The scout packages prove the project
  can do labelled interpretation well (evidence lines per claim).
- **Smallest correction:** brief line: "Interpretation is allowed when
  it is evidence-lined (frame + subtitle + transcript) and labelled as
  gloss in the note. Invention (a fact no frame shows) is never
  allowed."
- **Keep:** the evidence-line discipline and the name-withholding rule.

### 15. The main agent's own execution failures (not the prompt's fault)

1. **No campaign-status pre-flight before the 2026-10-30 upload run**
   (see executive summary failure 5). The upload brief's checklist
   covers per-clip items but not campaign state. Fix: pre-flight line
   (see §12, rule R-01).
2. **Treating a "READY TO UPLOAD" verdict as authorization for
   T1-fixed** (superseded by the rebuild; noted in session record).
   Fix: authorization comes from the user's word for the exact version,
   never from a verdict label. The project already states this; the
   failure was in applying it once.
3. **G1 NOTES.md claiming a `work/audiofix/` folder that does not
   exist.** Documentation gap only (verdict rests on delivered-file
   measurements), but it breaks the "verify-first-then-promote" audit
   trail for that fix. Fix: fix notes must cite paths that exist, or
   say "folder not preserved" explicitly.
4. **Delivering C2/C3 with an unmeasurable duck claim and a stated
   transcript limit, without a stems archive note.** The limits were
   stated (correct), but no decision was recorded about preserving
   stems/mix recipes as verification assets. Fix: stems + mix recipe
   archived per clip (see §12, rule R-08).

---

## 11. Adversarial spot-check questions

Thirteen questions, each answered with an example. The challenging one
is Q-T and Q-P: they push back on the project's own explanations.

**A. If every added caption disappeared, would the video still have a
clear idea?**
Scene-led batch-30: PARTLY. Dialogue clips (G2 apoc, G5 redundancy)
keep their idea through speech + baked subs; dialogue-free clips (G6
dog/mutant, G4 primal) lose theirs — the cards were the story. VO-led
batch-15: YES, the VO carries the idea; captions are structure +
accessibility, not the story. Pilot: YES (VO script). So the honest
answer is per-template, and it exposes the dependency: scene-led
dialogue-free clips are caption-dependent by construction. If a future
brief wants caption-independent clips, it must require dialogue or VO,
not just captions.

**B. If every decorative effect disappeared, what would actually be
lost?**
Almost nothing, by design: no shakes/flashes/transitions exist to
remove; zooms/pushes would cost emphasis only (see §6 effect audit);
grade would cost mood (unmeasured). What would be lost is NOT
decorative: the reframe (subject in frame), the pillarbox (whole
subtitles), the card (CTA + compliance). The project's effects budget
was already near zero — which means "remove decoration" is not a
useful critique here, and "add decoration" is not a useful fix either.
The work is in selection, VO, and captions.

**C. If the logo were removed, would there still be a specific, truthful
reason this content belongs to this campaign?**
Cinematic VO clips: YES — the VO says a sentence typed into RexTrix
built this world, and the picture shows generated worlds. Scene-led
clips: NO, not specifically — without title/card/logo, they are drama
excerpts that could belong to any AI-drama campaign. The brand link is
paratextual for 36 of 48 delivered clips. That is compliant but thin,
and it is the strongest structural weakness in the batch-30 approach.
A future scene-led brief should require at least one in-clip brand
truth (a visible RexTrix UI moment, a spoken app reference, or a
caption that states the generative fact) instead of relying on title +
card alone.

**F. Did you call a CTA a payoff?**
YES, in one structural sense: every clip's final beat before the card
is followed by a silent logo card, and several notes describe the VO's
invitation line ("Link is in my bio") as the payoff. The invitation is
a CTA, not a story payoff. The story payoff is the button press, the
slash + shocked face, the "alive" line, the spirit reveal. Where the
note conflates them, it overstates the ending. The warning template
makes the conflation explicit ("the card is the punchline landing") —
that is a defensible joke structure (the warning IS the joke), but it
is still a CTA wearing a punchline's clothes, and it is unbuilt, so its
effect is HYPOTHESIS.

**G. Did you call source variety creative variety?**
PARTLY. Batch-30 spans 6+ shows per group and 15+ shows overall — that
is source variety. Creative variety (different structures, different
promises, different endings) is much narrower: one scene-led structure
and one VO arc dominate. The group-5 scout's ZERO-moment report is the
counter-proof that variety was judged per pool, not per structure.
§10's "never identical templates" rule names the gap but postdates the
clips. Honest label: source-diverse, structure-monotonous.

**H. Did you label an edit "narrative-led" despite leaving the source
structure essentially unchanged?**
YES — the cinematic template is called "story-first" and
"storytelling about the world," but the picture structure is the
source window's chronology with a VO laid over it. The narrative work
is the monologue, not a re-editing of the picture's structure (no
reordering, no parallel action, no withheld reveal except C3's
reaction-before-reveal hold). The label is defensible for the VO, not
for the picture edit. Future notes should say "VO-led" (accurate) rather than "narrative-led" (overclaim) unless the picture itself was
restructured.

**J. Which apparently weak choice might be correct for a different
audience or source?**
The 3.9s cloudwhale clip: weak as a standalone Short (card longer than
content), but correct as a teaser/loop-adjacent fragment for an audience
that already knows the show, or as the hook half of a two-part post.
Similarly, the B3 letterbox (66% black) is weak for phone impact but
correct for an audience that values seeing both faces react
simultaneously — a two-shot value a crop cannot deliver. And the
dialogue-free G6 clips are weak for a story-seeking viewer but correct
for a visual/mood-scrolling viewer. Weakness judgments in this project
assume a story-seeking viewer; that assumption is never stated in a
brief and should be (see §12).

**P. What would disprove your explanation for a video's weak
performance? — the challenging question.**
The project's standing explanation for low views is: dead-hours posting
(12:00–14:25 PKT ≈ 3–5am US Eastern) + young channels + age (hours old).
What would disprove it: a clip posted in the standing 10 PM–1 AM PKT
window, on Cinema (the best-distributing channel), at comparable age,
that still draws ~10–20 views — or, conversely, a dead-hours clip that
breaks 500. Neither comparison exists on record: the dead-hours batch
and the window rule were never run as a comparison, and age, channel,
and posting time are confounded in every view pattern cited (QubeEase
flat 0–8 historically vs Cinema best — channel and content differ too).
The honest status of "post in the US window" is HYPOTHESIS with a
plausible mechanism, not TESTED. Worse: the 500+ clips that did break
through (3 approved, 7 rejected) took days, which suggests age alone
could explain the dead-hours batch's low early numbers without any
window effect. The project should stop citing the window as a cause
until the §13 comparison runs. This challenges the user's standing
posting rule itself — not to discard it (it costs nothing to follow),
but to stop treating it as an explanation.

**R. What did a completed form or passing validator fail to detect?**
The gate suite (dims/fps/codec/duration/loudnorm/TP/card frames/decode)
passed clips with: a late payoff (leopard ~12s), a 3.9s content, an
absent protagonist (C1 Briggs), a one-sided beat (B4), a tone mismatch
(C3), and a card longer than the content (cloudwhale). Validators check
the container and the audio; they cannot check promise, payoff,
presence, or tone. The per-clip "weakest point" note was the only
instrument that caught these, and it is a human judgment, not a
validator. Any future "all gates pass" delivery without a weakest-point
note should be treated as incomplete.

**S. Where did technical success conceal a creative failure?**
B3's TP fix is the cleanest case: the −0.1 dB gain + remux is a perfect
technical success (TP −1.078, video bit-identical), and it concealed
nothing — but it also fixed nothing creative, and the clip's real
problem (letterbox two-shot vs full-frame reframe) was decided
separately by the user. The concealment case is cloudwhale: every gate
passes, the file is technically excellent, and the clip is still thin.
And Primal: every gate passes, the VO is uncut, the mix is correct —
and the template fit is the weakest in its group. Technical success
conceals creative failure exactly when the delivery note leads with
gates and buries the weakest point. This debrief's rule (weakest point
first, gates second) is the proposed correction.

**T. Where did our criticism incorrectly reject a valid restrained
edit? — the second challenging question.**
Edit-3. The verdict "these are not good clips still" rejected three
edits that had done restrained, correct things: cut 7–9.5s of filler,
fixed a format-switch inside the opening (C1), stem-ducked audio, left
an untranscribable line uncaptioned rather than guessing (C3). The
verdict names no defect, so it cannot be checked against the edits'
documented changes — and at least one of its possible targets (the C3
flash-forward cold open repeating a Kai shot) is a deliberate structure,
not an error. It is possible the verdict was right about overall
quality and wrong about every specific edit; it is equally possible the
verdict condemned the source moments, which the group-5 scout later
independently judged as having ZERO strong clean moments. Either way,
the criticism as delivered was unactionable and therefore, as
criticism, incorrect in form even if right in outcome. The correction
is §10 entry 11: one named defect per rejected clip, before any rebuild.

**V. What important check was never performed on the actual delivered
file?**
Three: (1) a human listening test on any final mix (ASR detection is
not listening); (2) a final-mix duck-ratio measurement (impossible
without stems — so the check is really "are stems archived?", and the
answer is: not as a named asset per clip); (3) a muted-viewing check
for VO-led clips (does the picture alone cohere for a muted viewer?
C1's absent Briggs and B4's missing reaction suggest it partly does
not — but no muted-viewing pass is on record). All three are cheap and
should be added to the QC list (see §12).

**W. What should we REMOVE from the prompt rather than add?**
Four removals, each with a reason: (1) the full-file bitrate gate (it
was already replaced by content-only; any brief still quoting it is
stale); (2) volumedetect as a card-silence method (replaced by PCM);
(3) mono-downmix TP (replaced by stereo oversampled); (4) the phrase
"existing SFX library" wherever it appears (it names an asset that
does not exist — replace with the actual asset list or nothing).
And one structural removal: remove the implication that gate-passing
equals quality — i.e., remove any brief sentence that presents the spec
list as the definition of a good clip, and replace it with the
idea/promise/payoff header (§10 entry 13). Removal beats addition here
because the rulebook's problem is accumulation (see §12 on exceptions).

**X. What should remain an editorial choice instead of becoming a rule?**
Card dwell within the allowed range (2.5s vs 4.5s is already a scoped
choice, not a universal); opener type (cold line vs visual hook vs
question — §10 lists them as options, correctly); whether to use a
punch-in or a pattern interrupt at all (§10 correction, entry 4);
whether a clip is caption-dependent or VO-led (audience-dependent,
see Q-J); the blur-pad echo bar (frozen-still vs phone-scale — a human
judgment about the channel's standard, not a measurement); and the
family-safe bar for borderline frames (gun-to-temple, bone bodice at
the frame edge, dark humanoid) — these are judgments the user must make
per clip, and a rule that pretends to decide them in advance will
either over-block or under-disclose. The ledger should record rulings
as precedents, not convert them into automatic gates.

---

## 12. Proposed reusable learning — not a new master prompt

Format per rule as specified in the task. Classification summary first,
then the rules. "Disposition" here means the rule's standing in THIS
debrief (keep / amend / remove / investigate); the task's four
classifications (READY TO ADOPT / PROVISIONAL / DO NOT GENERALIZE /
RETIRE) are given per rule as "Class."

### Classification summary

- **READY TO ADOPT:** R-01 (campaign pre-flight), R-02 (one defect per
  rejection), R-03 (content-only measurement methods), R-04 (independent
  QC, no self-QC verdicts), R-05 (title never green-lights), R-06
  (saliency-as-proposal), R-09 (honesty over count), R-10 (idea header
  before specs).
- **PROVISIONAL:** R-07 (VO listening check), R-11 (template-fit veto
  with recorded override), R-12 (muted-viewing check).
- **DO NOT GENERALIZE:** the 2.5s card, centered viral captions, the
  pillarbox pad system, the US-window posting rule as a causal claim.
- **RETIRE:** full-file bitrate gate, volumedetect card floor,
  mono-downmix TP, output-side `-t` loudnorm, "existing SFX library"
  phrasing, the 3-word cap as a splitting rule (superseded by §9
  phrase chunking).
- **INVESTIGATE:** R-08 (stems archive + duck verification method),
  the blur-pad echo bar, the caption-system unification decision, the
  §10 device menu (vary-or-omit amendment).

### Rules

**Rule ID:** R-01
**Lesson:** An upload run must verify campaign status before the first
upload, or a pause turns the first upload into an unsubmittable clip.
**Status:** observed
**Scope:** campaign-specific
**Trigger:** any upload run's first clip.
**Recommended action:** Record campaign page status + submit-button
state with timestamp before uploading; if paused or the button is
disabled, hold the entire run and report.
**What NOT to require:** a status check per clip (once per run is
enough, unless the run spans a day boundary).
**Exception or alternative:** none; a user direction to upload despite
a pause must be explicit and must name the unsubmittable consequence.
**Fallback:** hold + report; do not upload "in case it resumes."
**Supporting evidence:** clip 1 uploaded 2026-10-30 ~02:46 PKT,
pause verified ~02:58 PKT, submit disabled, views will not count per
support reply (Ghuffran).
**Counterexample / regression risk:** none; the check costs one page
read.
**Smallest future test:** add the line to the next upload brief and
confirm the check appears in the run's first report.
**Likely effort or cost, if known:** negligible (one browser read).
**Disposition:** keep
**Class:** READY TO ADOPT

**Rule ID:** R-02
**Lesson:** A blanket rejection without per-clip defects cannot drive a
fix loop.
**Status:** observed
**Scope:** universal honesty/safety
**Trigger:** any "not good" verdict covering more than one clip.
**Recommended action:** Before rebuilding, ask for one named defect per
clip, in the user's words; record it verbatim in the fix brief.
**What NOT to require:** a full review essay — one defect per clip is
enough.
**Exception or alternative:** if the user declines to specify, record
"defect unspecified; rebuild targets [named hypothesis]" and treat the
rebuild as experimental, not corrective.
**Fallback:** scout the pool fresh (group-5 precedent) instead of
rebuilding blind.
**Supporting evidence:** edit-3 verdict (no defect on record) vs G2
fix loop (one defect → one exact fix → re-QC pass).
**Counterexample / regression risk:** a user may find the question
annoying; mitigate by asking once, with the fix loop waiting on the
answer, not by skipping it.
**Smallest future test:** next rejection of 2+ clips: ask, record, and
check the fix brief cites the defects.
**Likely effort or cost, if known:** one message.
**Disposition:** keep
**Class:** READY TO ADOPT

**Rule ID:** R-03
**Lesson:** Audio gates must be measured content-only (bitrate), via
atrim/pre-trimmed loudnorm (I/TP), in stereo with oversampling (TP),
and on PCM (card silence).
**Status:** tested
**Scope:** tool-environment-specific
**Trigger:** every QC pass on a file with a silent end card.
**Recommended action:** Use exactly these methods; quote full-file
figures only as diluted references, never as verdicts.
**What NOT to require:** re-encoding when re-measurement overturns a
fail (G3 precedent: re-measure first).
**Exception or alternative:** none for method; gates themselves
(−16 ±1 LUFS, TP ≤ −1.05 oversampled) may be waived per clip by the
user, recorded.
**Fallback:** if a method cannot run in an environment, state the limit
and do not substitute a retired method silently.
**Supporting evidence:** G1 bitrate fail → content-only pass; G3
audio fail overturned; B3 TP −1.00 → −0.9903 → −1.078 fix; volumedetect
−91 dB floor vs PCM exact zero/±1 LSB (C2/C3).
**Counterexample / regression risk:** none on record; the methods are
stricter and more accurate than the retired ones.
**Smallest future test:** next QC report must show method strings
(content-only / atrim / stereo-oversampled / PCM) beside every figure.
**Likely effort or cost, if known:** negligible (same tools, correct
flags).
**Disposition:** keep
**Class:** READY TO ADOPT

**Rule ID:** R-04
**Lesson:** A builder's self-QC "PASS" is an input, never a verdict.
**Status:** tested
**Scope:** universal honesty/safety
**Trigger:** every delivery.
**Recommended action:** Independent QC (different agent, from scratch:
probe, decode, frames, transcript, measurements) before delivery; fix
loops touch only failed clips, verified by md5 untouched checks.
**What NOT to require:** re-QC of untouched clips (md5 check suffices).
**Exception or alternative:** none; user waiver of independent QC must
be explicit per batch and recorded as a risk acceptance.
**Fallback:** if no independent agent is available, the parent
re-measures the gates itself (C2/C3 precedent) — still not the
builder's numbers.
**Supporting evidence:** G1 audio, G2 mid-sentence cut, B3 TP — all
builder-passed, independently failed, then fixed and re-passed.
**Counterexample / regression risk:** slower delivery (one extra QC
pass per group). Mitigated by parallel QC agents per group (batch-30
precedent).
**Smallest future test:** next batch: count self-QC passes overturned
by independent QC; target is a reported number, not zero (zero would
suggest QC is rubber-stamping).
**Likely effort or cost, if known:** one QC pass per group (parallel).
**Disposition:** keep
**Class:** READY TO ADOPT

**Rule ID:** R-05
**Lesson:** A show title never approves a clip; an episode-1 scout
(frames + transcript) decides, every time.
**Status:** tested
**Scope:** source-specific
**Trigger:** any new show entering a batch; any T2-style identification.
**Recommended action:** Scout ep1 (transcript + frames at 10s or finer
+ baked-sub reading) before cutting; record the window's evidence lines.
**What NOT to require:** scouting every episode of a show before using
ep1 (ep1 scout gates ep1 use; later episodes need their own scout).
**Exception or alternative:** none for approval; title classification
may still prioritize the scout queue (survey precedent).
**Fallback:** if ep1 cannot be fetched, the show is unscouted, not
approved by title.
**Supporting evidence:** T2 candidates eliminated on evidence after
title-based selection; survey's own "title is not a verdict" rule;
Witch window scoping (238–264s) vs episode-level costuming.
**Counterexample / regression risk:** none; scouting costs time but
prevents the most expensive error (building from the wrong show).
**Smallest future test:** next batch's scout packages must each cite
at least one frame range + one transcript/baked-sub range per claim.
**Likely effort or cost, if known:** one scout pass per episode.
**Disposition:** keep
**Class:** READY TO ADOPT

**Rule ID:** R-06
**Lesson:** Saliency reframe is a proposal, not a default; verify on
frames before building, and budget the manual window.
**Status:** tested
**Scope:** tool-environment-specific
**Trigger:** any landscape source entering a 9:16 build.
**Recommended action:** Frame-verify the reframe (subject whole, faces
whole, subtitles whole or explicitly pillarboxed) before cutting; if
saliency fails, use a manual subject-tracked window and record it.
**What NOT to require:** a saliency pass before a manual window when
the scene is dialogue-led (manual first is acceptable; record why).
**Exception or alternative:** pillarbox strip-over-blur when no crop
preserves subtitles (G2/G3 Crow precedent, scoped per clip).
**Fallback:** letterbox acceptance only by user decision (B3
precedent), never by default.
**Supporting evidence:** Crow doorway/corridor tracking, Primal
armor-mass tracking, G3 moves saliency failure — all caught on frames,
all fixed manually or by pillarbox.
**Counterexample / regression risk:** manual windows cost scout time;
mitigated by scouting windows, not full episodes, for reframe checks.
**Smallest future test:** next landscape batch: report saliency-accept
vs manual-window counts; a 100% saliency-accept rate should be treated
as suspicious, not successful.
**Likely effort or cost, if known:** scout time only.
**Disposition:** keep
**Class:** READY TO ADOPT

**Rule ID:** R-07
**Lesson:** Whisper detection is not a listening test; a VO file needs
one human listen before assembly.
**Status:** hypothesis
**Scope:** conditional craft guidance
**Trigger:** any VO-led clip before assembly.
**Recommended action:** Parent listens to the VO file once (delivery,
pacing, emotional fit, pronunciation of the brand name) and records
one line: "listened, natural / issues: …". Assembly does not start on
an unlistened VO.
**What NOT to require:** a full transcript re-check by ear (Whisper +
frame checks already cover wording); the listen is for delivery, not
dictation.
**Exception or alternative:** if no listener is available, record
"VO unlistened; delivery quality UNKNOWN" in the clip note (C2/C3
precedent for limits, applied to delivery).
**Fallback:** none — an unlistened VO ships with its limit stated, not
hidden.
**Supporting evidence:** zero listening tests on record for 16 VO
files (pilot + 15); C3 tone mismatch (suspense VO over candy comedy)
was caught on paper, not by ear — a listen might have caught it
earlier. (HYPOTHESIS: a listen would have caught it; the mismatch was
in fact caught by QC reading, so the incremental value is unproven.)
**Counterexample / regression risk:** listening costs parent time per
VO (~25s each — negligible) but adds a serial step; batch it (listen
to all VOs in one pass before assembly).
**Smallest future test:** next VO batch: listen to all VOs pre-assembly
and record whether any delivery issue was found that Whisper missed.
**Likely effort or cost, if known:** ~25s per VO + one note line.
**Disposition:** investigate
**Class:** PROVISIONAL

**Rule ID:** R-08
**Lesson:** Ducking and mix claims need archived stems + mix recipes,
because a finished mix cannot be re-measured for duck ratio.
**Status:** observed
**Scope:** tool-environment-specific
**Trigger:** any clip with ducked music or stem work.
**Recommended action:** Archive per clip: stems (or stem paths),
mix recipe (duck ratio, offsets, gains), and the VO file, in the
clip's work/ dir; cite the archive path in the QC report.
**What NOT to require:** archiving raw episode audio (source files
already exist); only the mix inputs + recipe.
**Exception or alternative:** single-native-mix clips (G6) need no
stems — record "no ducking, single mix" instead.
**Fallback:** if stems are lost, the QC note must say "duck ratio
unverifiable from final mix" (set-1 precedent), not repeat the recipe
figure as a measurement.
**Supporting evidence:** set-1 QC: "0.35 duck ratio cannot be
re-measured from a finished mix without stems"; C2/C3 duck claims rest
on build recipes.
**Counterexample / regression risk:** storage cost is small (stems
are short); the risk is archive sprawl — mitigate by keeping stems
inside the existing work/ dirs, not a new store.
**Smallest future test:** next ducked clip: verify stems + recipe are
on disk from the QC report's cited path alone, without asking the
builder.
**Likely effort or cost, if known:** negligible (files already exist
at build time; only the archiving step is new).
**Disposition:** investigate
**Class:** INVESTIGATE (method for verification still to be proven;
archiving itself is READY)

**Rule ID:** R-09
**Lesson:** Honesty over count: report a gap, never pad with a weak
clip; a recut beats a drop, a drop beats a pad.
**Status:** tested
**Scope:** universal honesty/safety
**Trigger:** any batch with a numerical target.
**Recommended action:** State the override in the brief before the
number; report gaps with what would fill them (episodes/scenes).
**What NOT to require:** hitting the number with held or flagged clips
(held clips do not count toward the target).
**Exception or alternative:** none; the user may explicitly order
padding, in which case the padded clips must be labelled as such.
**Fallback:** deliver the strong ones + a gap report.
**Supporting evidence:** batch-30: 36 built, 34 passed, 0 padded, 0
dropped; group-5 edit-3 scout: ZERO moments reported, not manufactured.
**Counterexample / regression risk:** a short batch may disappoint a
user expecting the number; mitigate by reporting the gap + fill plan
in the same delivery.
**Smallest future test:** next numerical batch: check the delivery
states passed count, held count, and gap (if any) separately.
**Likely effort or cost, if known:** none.
**Disposition:** keep
**Class:** READY TO ADOPT

**Rule ID:** R-10
**Lesson:** Every clip note starts with idea, promise, and payoff —
before specs — or the gates become the definition of quality.
**Status:** hypothesis
**Scope:** conditional craft guidance
**Trigger:** every clip note, every brief.
**Recommended action:** Note header: "Idea (one sentence). Promise
(first 3s). Payoff (last 5s). What the viewer learns or feels."
Weakest point stays mandatory, listed before gate figures.
**What NOT to require:** a long creative essay — four lines suffice.
**Exception or alternative:** none for the header; clips whose idea
cannot be stated in one sentence are flagged for re-scoping, not
automatically dropped.
**Fallback:** if the idea line is "same as the source scene," the note
must say what the edit added (selection, VO, gloss) or admit it added
nothing.
**Supporting evidence:** gate-passing clips with disclosed creative
weaknesses (cloudwhale, Primal, C1 Briggs) — all visible only in
weakest-point notes, never in gate tables (§11R/S).
**Counterexample / regression risk:** adds a small writing burden per
clip; risks becoming boilerplate ("exciting drama clip") — mitigate by
requiring the promise/payoff to name specific seconds and lines.
**Smallest future test:** next batch: audit 5 notes for specific
promise/payoff lines vs boilerplate; revise the header if boilerplate
dominates.
**Likely effort or cost, if known:** minutes per clip.
**Disposition:** keep
**Class:** READY TO ADOPT (as a note format; its effect on quality is
PROVISIONAL until the §13 test runs)

**Rule ID:** R-11
**Lesson:** A scout "drop first" warning must be overridden explicitly
or obeyed — never built silently.
**Status:** observed
**Scope:** conditional craft guidance
**Trigger:** any scout package containing a "drop first," "weakest
fit," or "if strictly X, drop" warning.
**Recommended action:** The assembly brief must either drop the clip
or record a one-line override ("building despite warning because …,
user decision dated …"). Silence is not an override.
**What NOT to require:** dropping every warned clip (warnings are
judgments, and the user may overrule them with reason).
**Exception or alternative:** user override, recorded.
**Fallback:** hold the clip for a ruling instead of building it.
**Supporting evidence:** B2 Primal scout ("drop PRIMAL first" if
strictly human clips wanted) → built anyway, delivered with
"weakest template fit" flagged. The flag is honest but post-hoc; the
decision should have preceded the build.
**Counterexample / regression risk:** may slow assembly by one ruling
per warned clip; warned clips are a minority, so the cost is bounded.
**Smallest future test:** next batch: count warned clips built without
a prior override line; target zero.
**Likely effort or cost, if known:** one line per warned clip.
**Disposition:** keep
**Class:** PROVISIONAL (process rule; its effect on outcomes untested)

**Rule ID:** R-12
**Lesson:** VO-led clips need a muted-viewing check: does the picture
alone cohere for a viewer who never hears the VO?
**Status:** hypothesis
**Scope:** conditional craft guidance
**Trigger:** every VO-led clip at QC.
**Recommended action:** One muted pass over the delivered file (frames
at hook/mid/payoff): record whether the picture tells a coherent
mini-story without audio, or depends entirely on the VO. A
VO-dependent picture is not a fail — it is a disclosed property that
affects caption strategy (if the picture cannot carry the story muted,
the captions must carry more of it).
**What NOT to require:** making every VO clip work muted (that would
ban VO-led storytelling); only disclosing the dependency.
**Exception or alternative:** none.
**Fallback:** if no muted pass is possible, record "muted coherence
UNKNOWN" in the note.
**Supporting evidence:** C1 Briggs (named character absent) and B4
missing reaction suggest partial muted incoherence, but no muted pass
is on record to confirm or bound it.
**Counterexample / regression risk:** adds one QC pass per VO clip;
risk of over-correcting (adding captions to "fix" a VO-led clip until
it becomes a text-led clip) — mitigate by disclosing, not by
mandating a fix.
**Smallest future test:** next VO batch: muted-pass 3 clips and check
whether any caption decision changes as a result.
**Likely effort or cost, if known:** minutes per clip.
**Disposition:** investigate
**Class:** PROVISIONAL

### Freedoms preserved (must not become compulsory styles)

The following remain available when a brief permits them, and no rule
in this debrief makes any single one mandatory:

- **An uninterrupted slow reveal** (C3 reaction-before-reveal is the
  precedent; B3's two-shot hold is another). Not tested as a standalone
  structure — available, not proven.
- **A wordless visual moment** (G6 visual/music-only clips prove the
  pipeline can deliver it; their story-dependence on captions is the
  disclosed price).
- **A dialogue joke with minimal graphics** — NOT delivered in this
  project under the caption-mandated system. Preserved as an untested
  freedom: a future brief may explicitly waive added captions for a
  dialogue-led clip, with the doubling rule still applying to any
  baked text present.
- **A narration-led explanation** (cinematic VO template — implemented
  12 times; the most-evidenced freedom, and the one most at risk of
  becoming the default by repetition — guard with R-11 and structural
  variety in the next brief).
- **A purposeful motion-heavy treatment** — NOT built in this project
  (§10 caps motion at one push/punch-in). Preserved as an untested
  freedom: a future brief may explicitly authorize a motion-heavy
  treatment for a suitable source, with the same QC gates, rather than
  treating §10's restraint as a ban.

No single style — centered captions, VO-led arcs, hook-first scene cuts,
or motion restraint — should become compulsory. The next brief should
name its intended variety (e.g., "this batch: 2 VO-led, 2 scene-led, 1
wordless, 1 dialogue-minimal") instead of letting one template fill the
batch by default.
