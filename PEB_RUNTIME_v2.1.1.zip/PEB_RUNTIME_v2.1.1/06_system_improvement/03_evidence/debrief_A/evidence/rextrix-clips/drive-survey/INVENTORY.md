# Drive survey — Edited Video Assets, full inventory (2026-10-29 ~16:27 PKT)

Method: Google Drive API, parent folder `1FA4pPfLGaEJp99ZpfFMpPtEEAaYcz5WB`.
105 parent items = 101 show folders + 4 mapping files (Drama ID Mapping
Sheets/xlsx). Every folder's top-level children enumerated; only Toilet Knight
has a subfolder (AWS Source Episodes - EP01-EP03). Folder IDs + per-file
details live in `parent_listing.json` and `children/<folder-id>.json` in this
directory. Title-based classification ONLY — a title is not a verdict; the
hook scout of episode 1 decides actual use.

## Counts (101 folders)
- Already used / batch-7 group 1 / touched world: 19
- Excluded (SHOW_LIST-named adult/romance): 28
- Empty (0 video files at top level): 13
- Check-first (ambiguous title, sample before use): 7
- Reserved (T2 hunt): 1 (Swapped at Birth)
- Promising new: 33

## Already used / group 1 / touched (do NOT present as new)
Panda BoBo S1, Phoenix Throne S1+S2, Echo of Derelict, Live Paranormal S1+S2,
NEON RIOT, Idiot Otter Gang, Rusty Teeth / Sand Scorpions variants, Toilet
Knight, The Strawberry Assistant's Secret, Star God's Obsession (same world as
the D/E/pilot star-god clips — reuse only different scenes, never as "new").
Batch-7 group 1 (held, hooks scouted): Giants in Chains, WILD KINGDOM,
CROWN OF THE CLOUDWHALE, I Can See Your Survival Rate, Echoes of the
Primeval, The Neon Alchemist.

## Excluded (adult/romance, SHOW_LIST-named — never cut from these)
Cheating's…, Her Loyal Hound, Marked & Knotted, Wife-Swap With My Father S1,
365 Nights with My Mafia Guardian (both), My Husband Put Me in Another Man's
Bed, My Silicone Girlfriend Came to Life, 30 Men of a Sex Addict, Tempted by
My Bad Stepbrother (both), In My Stepbrother's bed, Dom's Desire, Falling for
Mom's Friend, I Got Three Guys Obeying Me (both), Whip Queen, Brother's Cage
Kiss, The Heir Called Him Daddy, Swapped with My Mom, Claimed by the King
Nightly, Married for the Merger, Country Club Heat, The Alfa's Truth-scent
Mate, Blood-bound Bride, Her Wild Witness, Wrong Bride of Sable Cove.

## Empty (13 — no video files; skip)
Live Paranormal S2 duplicate, Rust Teeth：Ashes of the Scorpion (fullwidth
colon, ×2), TAMED (×2), Ashes of Dawn (×2), Vermin Metamorphosis (×2),
THE LAST DRAW, Toilet Knight: Sewer Vengeance, Havenwood Dawn,
Inter-species Desirous Surrender (also excluded by title).

## Check-first (7 — sample episode 1 before any use)
My Classmates Are Elite Agents (newest folder, Oct 29, 1 video 88 MB —
SHOW_LIST says "check before use"), The Scenting Wolf (14 videos, romance
trope in title), Endless Heatwave (4), Moonbound Beast King (6),
Rooming with Ice Kings (8), Wings (6, title unclear), Tempted by the master
(6, romance-leaning title).

## Promising new (33 — next step: episode-1 download + hook scout each)
- The Apocalypse Repeats Through My Death (6) — time-loop, strongest hook shape
- DON'T FEED THE ANIMALS (7) — horror/thriller
- I Raised Hell's Army (7) — fantasy army
- Crow-Ash Orphanage (7) — mystery
- Ice Road Rig (30 shorts, small files) — action volume
- The Witch Beneath the Gallows (12) — dark fantasy
- After Divorce Turns Out She's a Hidden Heiress (13) — family drama
- PRIMAL MACHINES (15) + PRIMAL MACHINES II (5) — sci-fi/action
- Human Reserve Prequel-Adrift (6) + Human Reserve - Redundancy (1) — sci-fi
- ZEROED: Human Preserve (6), THE UNSOLVED FILES (5) — mystery/sci-fi
- DOG OF THE WEST (5) — western, genre variety
- Mutant Garden Fiesta (6) — comedy/fantasy, variety
- Homebound Within the Painting (6), Four Shields (6), Odysseus (4),
  The Reaper (6), The Rat King Arrives (6), The Curse of Eclipse Wind (6),
  Dreams: Worse Than Death (3), TAKE OVER EARTH (5), Kill the Mafia King,
  I Became the Queen (6), Star Survival Alien Bond (6), NULL ANGEL (6) +
  NULL ANGEL II (6), When the Islands Fall (6), Across the Forbidden River
  (6), The Fabled Twin Stars (6)
- Gore/violence flags (sample with care, skip graphic material): Corpse
  Brother (7), Blood and Flesh (7), No One Leaves Alive (8), Kill the Mafia
  King (violence), Dreams / DON'T FEED (horror).

## Reserved
Swapped at Birth (20 videos) — T2 hunt only, not a batch pool show.

## Next step for both batches
Download episode 1 of the shortlisted promising shows (direct-download route,
tool-confirmed), hook-scout each (hook in 1–3s, complete thought, English,
baked-text check) BEFORE any cutting. Titles alone never green-light a clip.
