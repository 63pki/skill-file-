# Batch-7 edit-3 — visual-strength edits + review

Edits by a subagent, 2026-10-29. Originals untouched in `orig/` (sizes/mtimes verified
after the build). NOTHING uploaded or submitted — these are for parent QC and user review.

## Deliverables

- [c1_she_wanted_edit.mp4](sandbox://workspace/rextrix-clips/new-batch-7/edit-3/c1_she_wanted_edit.mp4) — 12.5 s
- [c2_not_your_rules_edit.mp4](sandbox://workspace/rextrix-clips/new-batch-7/edit-3/c2_not_your_rules_edit.mp4) — 12.3 s
- [c3_all_invented_edit.mp4](sandbox://workspace/rextrix-clips/new-batch-7/edit-3/c3_all_invented_edit.mp4) — 16.2 s

## Global choices (apply to all 3)

- **Captions, uniform:** DejaVu Sans Bold 54, white, 2 px black outline, centered,
  y=1400 (bottom edge ≈1464, above the y=1500 Shorts UI line). No caption ever
  coincides with baked source text; no two captions overlap; no caption is shown twice.
- **Caption placement note (deviation from CLIP_RULES §1, explained):** §1's pad
  placement assumes 640×360 strip-over-blur sources. These are full-frame 1080×1920
  sources with no pads, so captions sit in the lower third on the video. This matches
  how the earlier full-frame user-supplied clips carry their baked captions.
- **End cards:** original proper card kept at the END ONLY, trimmed to exactly 2.5 s
  (originals ran ~4.5–5 s), card audio pure silence (−91 dB measured). No start cards.
- **Render:** 1080×1920 30 fps, libx264 slow, CRF 16, yuv420p, AAC 192k, faststart
  verified (moov before mdat on all 3). drawtext via `textfile=` only. Concat-filter
  with fps normalisation + setsar=1. Full decode clean on all 3.
- **Audio — read this before describing it as "ducked":** NO true stem ducking was
  possible. demucs is not installed in this environment, and the install attempt
  DEFINITIVELY FAILED with a disk-full error ("No space left on device") during the
  pip install; the partial venv (15 MB) was removed afterwards, and the disk now
  shows 36 GB free, so a retry may succeed — but no retry was run after delivery,
  and stem ducking stays blocked until one is. The fallback that actually ran was:
  speech enhancement chain on all speech-bearing audio (highpass 80 Hz, light
  FFT denoise, +3 dB presence EQ @ 3 kHz, 3:1 compression, two-pass loudnorm to
  −16 LUFS / TP ≤ −1 dB); genuinely music-only spans level-matched −3 dB under
  speech (only C3's gates stretch qualifies — C1/C2 edits contain no music-only spans).
  Voice-vs-music separation inside mixed speech segments was NOT achieved. If true
  −9 dB stem ducking is wanted, re-run the audio pass once demucs installs
  (the build script at `/tmp/edit3/build_audio.py` auto-selects stems when available).
  Absolute RMS values below run ~2–3 dB lower than the originals because the target
  is −16 LUFS vs the originals' ~−14 LUFS — that is the loudnorm target, not a loss
  of enhancement (presence EQ + compression are what carry the clarity gain).

## C1 — she wanted (orig 22.06 s → edit 12.5 s: content 10.0 s + card 2.5 s)

### Exactly what changed (orig → edited timestamps)
- KEPT orig 0–3.0 (anime island castle → anime girl close-up; line "That's not an
  island" 1.58–2.78; baked hook text "SHE WANTED A LIFE WITH NO RULES" kept) → edited 0–3.0.
- CUT orig 3.0–10.0 (flying-craft landing, snow creature — 7 s of slow filler, no speech).
- KEPT orig 10.0–12.9 (lion; "greater power" line 10.08–12.42) → edited 3.0–5.9.
- KEPT orig 12.9–17.0 (Kai confrontation + bubble tableau; "Stay still" 12.94–13.60,
  "Your mind now little human" 14.32–15.80, "Three of them" 15.86–16.44) → edited 5.9–10.0.
- Card trimmed from ~5.0 s to exactly 2.5 s (orig card slice 18.0–20.5, silent) → edited 10.0–12.5.

### Hook choice and why
Anime girl close-up + baked "SHE WANTED A LIFE WITH NO RULES" (edited 0–3 s). It is
the clip's own sharpest premise line over a strong face in the first second. The
anime→realistic format switch now happens ONCE, at 3.0 s, after the hook lands, as a
hard shock cut to the lion — there is no switch inside the opening. The parent finding
(anime-to-realistic switch breaking the opening) is fixed this way rather than by
deleting the anime world, which would have removed the clip's premise and title meaning.

### Complete message
Wants freedom → a greater power appears → a god claims her ("your mind now, little
human") → "three of them" over the bubble tableau → card. Teaser-complete.

### Full caption list (edited time)
- 0–3.0: NONE (baked hook text on screen — adding one would double it).
- "A GREATER POWER" 3.1–5.4; "STAY STILL" 5.94–6.60; "YOUR MIND NOW, LITTLE HUMAN"
  7.32–8.80; "THREE OF THEM" 8.86–9.44.

### Audio before → after
- Full file: −14.04 LUFS / TP −1.81 → −16.02 LUFS / TP −2.11.
- Speech-span RMS (orig → edit): island line −16.8 → −18.4; greater-power line
  −14.8 → −17.4; Kai block −15.8 → −18.3 dBFS. (Absolute drop = loudnorm target change.)
- Cut filler music (orig 3–10 s, −16.5 dBFS) removed entirely.

### Could NOT be fixed
- The format switch still exists (once, after the hook) — see hook note above.
- The greater-power line's first word is garbled in transcription ("Dolly meets…"),
  so the caption uses the safe moment label "A GREATER POWER" instead of transcribing it.

## C2 — not your rules (orig 24.93 s → edit 12.3 s: content 9.8 s + card 2.5 s)

### Exactly what changed
- KEPT orig 0–4.0 (Kai + girl confrontation; "Your mind now little human" 0–1.8,
  "Let go of me" 1.8–2.9, "I don't even know who" 2.9–4.0 — cut exactly on the word
  boundary at 4.0) → edited 0–4.0.
- CUT orig 4.0–13.5 (mantis / boar / leopard / grassland montage + muddy narration,
  9.5 s — the retention drag).
- KEPT orig 13.5–15.6 ("In the wild" bridge 13.5–15.5, grassland tail + lion pride)
  → edited 4.0–6.1.
- KEPT orig 16.3–20.0 (palace robed figure + crowned girl; "Kai release her at once"
  16.3–18.0, "force will never win" 18.0–19.3, "three of them" 19.3–19.9) → edited 6.1–9.8.
- Card trimmed from ~4.9 s to exactly 2.5 s (orig card slice 21.0–23.5, silent)
  → edited 9.8–12.3.

### Hook choice and why
Opening UNCHANGED: Kai close-up confrontation ("Your mind now, little human"). It was
already hook-first with no format switch — the fix here is pacing (the 9.5 s montage
cut), not the hook. Verified against the file; the parent finding about a garbled
middle is resolved by cutting that middle, not by enhancing muddy narration.

### Complete message
Confrontation → "in the wild" (the wild has rules — the montage's theme survives in
2.1 s) → palace intervention → "three of them" → card.

### Full caption list (edited time)
- "YOUR MIND NOW, LITTLE HUMAN" 0–1.8; "LET GO OF ME" 1.8–4.0; "IN THE WILD" 4.0–6.1;
  "KAI, RELEASE HER AT ONCE" 6.1–7.8; "FORCE WILL NEVER WIN" 7.8–9.1;
  "THREE OF THEM" 9.1–9.7. No baked text exists in this clip, so no double risk.

### Audio before → after
- Full file: −14.02 LUFS / TP −1.61 → −16.16 LUFS / TP −4.54.
- Speech-span RMS (orig → edit): confrontation −15.5 → −17.8; bridge −20.8 → −23.1;
  palace −15.1 → −18.1 dBFS. Cut montage (orig −17.7 dBFS) removed.
- Note: the bridge "In the wild" stays relatively quiet (6.9 dB below file level,
  same as orig) — it is a quiet narrator line and enhancement did not lift it
  relative to the file, but output transcription hears it cleanly.

### Could NOT be fixed
- The cut montage's narration ("every hunt, every kingdom has a boundary") was
  garbled in transcription and is NOT transcribed or captioned anywhere — it left
  with the montage. Restoring that theme line would require re-adding the montage;
  judged not worth the 9.5 s drag.

## C3 — all invented (orig 24.03 s → edit 16.2 s: content 13.7 s + card 2.5 s)

### Exactly what changed (reorder — cold open)
- HOOK, moved to front: orig 8.2–9.7 (Kai close-up, "Stay still" 8.2–9.6) → edited 0–1.5.
- Then orig 0–4.0 (palace arrival, "I was just walking home. How did I fall into
  this…" 0–4.0) → edited 1.5–5.5.
- Then orig 10.2–14.3 (Kai + lion, "You're mild. Every survivor eventually meets."
  10.2–14.3, garbled — see below) → edited 5.5–9.6.
- Then orig 15.0–19.1 (gates closed → opening light → anime girl → man, "It's her"
  18.0–19.0) → edited 9.6–13.7.
- CUT: orig 4.0–8.2 (sitting / music gap, 4.2 s) and orig 14.3–15.0 (0.7 s transition).
- Card trimmed from ~4.5 s to exactly 2.5 s (orig card slice 20.5–23.0, silent)
  → edited 13.7–16.2.

### Hook choice and why
Kai "Stay still" cold open. The original's palace-floor arrival wide shot is slow
(girl small in frame) and repeats a previously uploaded clip's opening beat. The
confrontation close-up is the single strongest self-explanatory moment, and it sits
in the same realistic world as the following arrival shot, so there is no format
switch inside the opening (the anime switch comes later, at the gates). The structure
is a deliberate flash-forward: confrontation → how she got here → greater powers →
a door opens, someone recognises her.

### Complete message
Flash-forward teaser-complete: confrontation → arrival → greater powers → gates open
→ "It's her" → card.

### Full caption list (edited time)
- "STAY STILL" 0–1.5; "HOW DID I FALL INTO THIS?" 1.5–5.5; NONE 5.5–9.6 (garbled line,
  see below); "IT'S HER" 12.6–13.6.

### Audio before → after
- Full file: −14.10 LUFS / TP −1.36 → −16.24 LUFS / TP −1.03. (Pre-loudnorm peak hit
  −0.24 dB after enhancement; the two-pass loudnorm corrected it to −1.03.)
- Speech-span RMS (orig → edit): hook −16.8 → −19.6; arrival −14.0 → −19.3;
  survivor −14.2 → −17.1; "It's her" −22.9 → −20.3 dBFS. Relative to file level,
  "It's her" gained ~4.7 dB of presence (was 8.8 dB below file level, now 4.1 below)
  via compression — the quiet line is now audible.
- Music-only gates stretch (edited 9.6–12.6) level-matched at −23.4 dBFS RMS, under
  the speech sections. Cut gaps (orig 4.0–8.2 music −16.7, 14.3–18.0 music −20.8)
  partially removed with the cuts.

### Could NOT be fixed
- The survivor line (orig 10.2–14.3) could not be transcribed confidently by two
  models (tiny + base disagree; "You're mild" is certainly a mishear). The audio is
  enhanced and kept, but it carries NO caption rather than a guessed transcription.
- The Kai scene effectively appears twice (1.5 s cold-open hook + the later Kai+lion
  block) — inherent to the flash-forward structure; the shots differ (close-up vs
  wider + lion) and the hook is only 1.5 s.

## QC performed on the outputs (not trusted from the build)
- Full decode clean, all 3; specs 1080×1920 30 fps yuv420p; faststart verified.
- Opening / mid / card frames viewed for all 3: hooks, captions and cards all clean;
  caption bottoms above y=1500; no caption collides with baked text.
- Output speech check: C1 and C2 lines all detected intact; C3's hook ("Stay still")
  and "It's her" confirmed on the base model after the tiny model missed them
  (transcription limitation, not edit damage).
- Card audio −91 dB (silence) on all 3; card exactly 2.5 s, end-only.
- Originals verified untouched (same sizes and mtimes as before the build).

## STEM-DUCKING RETRY ADDENDUM (parent pass, 2026-10-29 ~12:50 PKT)
- demucs 4.1.0 installed (torch 2.15.0+cpu) in ~/workspace/demucs-venv, linked as
  ~/.venv-demucs. First retry failed on disk-full during the CUDA torch download;
  the working install used CPU-only torch with TMPDIR and pip cache on home storage.
  The builder's /tmp/edit3 workdir was lost in a runtime restart; the stem pass was
  recreated as stem_audio.py in this folder (same segment/span tables).
- Stem pass (htdemucs --two-stems vocals on original mixes; vocals enhanced; music
  stem ducked to 0.355 = -9 dB during every edited-timeline speech span; loudnorm
  two-pass; video stream copied from the fallback edits; card audio silent):
  C1 -16.00 LUFS / TP -1.96, 12.5 s; C2 -16.18 / TP -4.75, 12.3 s;
  C3 -16.27 / TP -1.04, 16.2 s. Card silence -91 dB on all 3; faststart verified.
- Parent QC on the stem versions: all speech lines detected intact by Whisper
  (English p=1.00); C3's survivor line now transcribes cleanly ("Every survivor
  eventually meets me") where the fallback left it uncaptioned. Honest limit:
  total mix level in speech spans moved only -0.1 to -0.3 dB vs the fallback,
  because vocals already dominated those spans — the -9 dB applies to the music
  stem itself, which is what lifts voice clarity. Music-only stretches run full,
  as specced (C3 gates stretch measures louder than the fallback's -3 dB version).
- The fallback (non-stem) versions are kept as *_edit_fallback.mp4. The *_edit.mp4
  files are now the stem-ducked versions.
