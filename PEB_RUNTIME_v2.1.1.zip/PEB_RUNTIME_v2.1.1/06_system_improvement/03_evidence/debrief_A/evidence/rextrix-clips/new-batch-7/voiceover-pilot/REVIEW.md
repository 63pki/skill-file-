# Voiceover pilot — REVIEW (self-QC, NOT uploaded / submitted / published)

File: vo_pilot_out_of_control.mp4 (27.9 MB, 29.47 s)
Voiceover: vo_pilot_voiceover.mp4 (ElevenLabs "Hope - upbeat and clear", Eleven v4,
24.84 s) — used as supplied, NOT regenerated, NOT substituted.
Build script: build_vo_pilot.sh (rerun v2 + TP-fix audio re-mux; v2 intermediate
kept at work/vo_pilot_v2_backup.mp4).

## Specs (verified)
- 1080x1920, 30 fps, H.264, AAC 192k, faststart YES, full decode clean.
- Duration 29.467 s = 24.967 s content + 4.5 s card. The +0.13 s vs the nominal
  29.34 s is frame rounding of the 7 trimmed segments (30 fps grid); the card
  itself is exactly 4.5 s (135 frames), audio ends at 29.34 s, last card frames
  silent — no padding, loops, freeze, or slow-mo added.
- Audio: content -16.04 LUFS, true peak -1.08 dB (spec ~-16 / TP <= -1: PASS).
  Card audio silence -91 dB. Voiceover lead; source bed at -22 dB (volume 0.08)
  under every spoken word — voice dominant, Whisper detects every line.
- Captions: DejaVu Sans Bold 54, white, 2 px black outline, lower third,
  bottoms at or above y=1500 (1-line y=1400, 2-line y=1350, 3-line y=1290).
  No added caption duplicates burned-in source text at the same time.

## Scene map (video timeline = voiceover timeline)
Voice lines (Whisper on the voiceover itself, EN p=1.00):
- 0.00-3.60 "AI entertainment is officially getting out of control."
- 4.20-7.64 "I found this app called RexTrix where you don't even have to code."
- 8.00-12.58 "You just type a sentence and it builds you a custom game or a short drama film."
- 12.96-16.80 "Look at what it generated when I typed, a world made of starlight."
- 17.22-21.00 "Where three powerful gods fight over one tiny human."
- 21.44-22.78 "And it's actually playable."
- 23.32-24.60 "Download link is in my bio."
Segments used (video start-end -> source start-end):
- 0.00-3.90   -> d1_star_god.mp4 0.0-3.9 (god + girl, golden starlight world; hook)
- 3.90-7.82   -> c3_all_invented_orig.mp4 0.0-3.92 (starlight palace arrival)
- 7.82-12.77  -> c1_she_wanted_orig.mp4 4.0-8.95 (palace + glider build)
- 12.77-17.01 -> d1_star_god.mp4 10.0-14.24 (blue starlight two-shot)
- 17.01-21.22 -> c2_not_your_rules_orig.mp4 0.0-4.21 (Kai confrontation + girl)
- 21.22-23.06 -> c2_not_your_rules_orig.mp4 18.0-19.84 (god palace walk, payoff)
- 23.06-24.84 -> c3_all_invented_orig.mp4 6.0-7.78 (Kai + girl two-shot)
- 24.97-29.47 -> end card (see below)
No segment lingers on sheer-costume close-ups; no source end-card frames leak
into content (all cuts end before each source's own card).

## End card (exactly 4.5 s, end only)
Authentic RexTrix logo graphic (frame taken from an edit-3 delivered card),
wording patched to the exact task wording: "Download the RexTrix app"
(white) / "— link in bio" (gold) + "AI-generated Games & Stories".
Verified on frame at t=27.0; patch seam invisible (bg matched at RGB 16,16,16).
No start card, no logo bumper at the start.

## Fixes made after v1 QC (both re-verified on frames)
1. Line-2 caption overflowed both frame edges at size 54 -> re-split into
   3 shorter lines at y=1290; now fully inside frame.
2. "Actually playable" segment first used c2 14.0-15.84, which is actually
   lions/savanna ("In the wild" bridge), not the palace walk -> replaced with
   c2 18.0-19.84 (god palace walk, verified on frame).
3. True-peak fix: v2 final measured TP -0.98 dB (0.02 over the -1 limit) ->
   audio re-muxed with TP target -1.2; final TP -1.08 dB, PASS.

## Known notes / not verified
- Baked source texts remain visible where they are part of the scene and do NOT
  duplicate the added captions: "FOUR GODS. FOUR CAGES." (hook shot, top of
  frame) and "SO SHE BUILT ONE" (glider shot). Different words from the
  voiceover captions, so not caption doubles — but flag if a stricter
  no-baked-text pass is wanted.
- Whisper renders the app name as "Rex Tricks"; the voiceover audio and the
  on-screen caption both say "RexTrix" (script wording, correct).
- Voice intelligibility judged via Whisper detection on the final mix
  (all 7 lines, EN p=1.00, timestamps matching the voiceover); no human
  listening test was run on the final mix.
- Loudnorm measurement note: a direct measure of the intermediate mix.wav
  read -23.72 LUFS, but the final file verifies at -16.04 LUFS / TP -1.08 dB
  (the loudnorm stage's dynamic fallback handled the gain); final-file
  numbers above are the ones that count.

## Compliance
No banned claims; no "free" / "unlimited" / "earn money" wording; no invented
features; no copyrighted characters; English-only audio and text; verbal CTA
("Download link is in my bio") + on-screen card CTA. NOT uploaded, submitted,
or published — awaiting parent/user approval of this exact version.

## v3 — viral caption rebuild (parent rebuild, 2026-10-29)
- Audio: unchanged from the silenced fix (voiceover only, I=-16.14, TP=-1.19, card silence -91 dB).
- Captions rebuilt per the viral spec (pilot-only experiment, CLIP_RULES §8): Montserrat Bold (real Bold installed from Google Fonts), white, 4px black outline, dead center (Y 50%), max 3 words per chunk, 26 events timed to Whisper word timestamps; brand spelled "RexTrix" in captions (Whisper mishears audio as "Rex Tricks").
- FIRST v3 render FAILED parent frame check: old lower-third captions were burned into the source video, so new centered captions doubled them. That render was discarded, never sent. Corrected v3 rebuilt from clean captionless scene segments (same 7 trims, no drawtext) + card + ASS captions. Frame check on corrected v3 (1.0s / 5.5s / 13.5s / 27.0s): ONLY centered captions visible, no lower-third text, card clean.
- Still open (not fixed in v3): baked "FOUR GODS. FOUR CAGES." vs three-gods voiceover on the hook shot; source-internal cuts at 0.87s / 2.23s / 10.4s landing mid-sentence (deep re-cut held pending continuous-footage check).
