# NEVER-REPEAT RULES — RexTrix clip mistakes ledger

Created 2026-10-30, on the user's order: mistakes seen in clips must never be
repeated, and every clip must get better than the last.

## Enforcement (binding on every future clip and upload)
- This ledger is required reading for every clip brief, fix loop, QC pass, and
  upload brief, alongside CLIP_RULES.md. A brief that does not cite it is
  incomplete.
- A clip that repeats a ledgered mistake FAILS QC automatically — no waivers
  by the builder or QC. Only the user can waive a ledger entry, per clip.
- After every batch, append newly found mistakes here BEFORE the next batch
  starts. That is the mechanism by which each batch gets better than the last:
  the ledger only grows, and a mistake fixed once stays fixed.
- Scoped exceptions (2.5s end card for the batch-15 cinematic template;
  centered viral captions for the voiceover pilot only) are NOT defaults and
  must never be generalized without the user's explicit word.

## Production mistakes
1. Caption sitting ON the video strip, or floating far from the strip edge.
   Rule: captions live in the pad just beyond the strip edge, ~24–32px gap,
   snug, bottom edge at/above y=1500. Check on rendered frames.
2. Doubled captions: same text twice, two added captions at once, or an added
   caption duplicating concurrent source text. Rule: if the source already
   says it, remove or retime the added caption. Check every captioned frame.
3. End card or logo bumper at the START. Rule: card end-only, always; cut
   source opening bumpers out before building.
4. Cutting mid-sentence or mid-enjoyment (batch-30 G2 "died three times":
   cut landed inside "I've watched the sky for 30 years"). Rule: extend to a
   real pause after a completed thought. Clean ending = final speech
   completes + pause before the cut + next sentence absent. A baked subtitle
   persisting at the last frame is NOT an incomplete ending.
5. Weak hook: a closing/resolution moment used as the opening, vague copy
   ("HIS CLOSING WORD"), or an angle/format switch inside the opening.
   Rule: first 1–3s carry the strongest self-explanatory moment; hook copy
   sharp, specific, tied to the visual in the same seconds.
6. Speaking fragments of 1–2s that land nothing. Rule: give a speaking scene
   its full thought, or cut the speech entirely.
7. Music competing with speech, or speech enhancement skipped on short lines
   (batch-6: closing lines left unenhanced). Rule: duck music LOW under ALL
   speech; enhance EVERY clip containing speech, including short closers.
8. Key message riding on small baked source text unreadable at phone size.
   Rule: crop/zoom to it, or restate it in a large readable added caption;
   verify readability on a rendered frame at phone scale.
9. 9:16 crop slicing full-width baked subtitles (batch-30 G3 Crow). Rule: when
   a crop would slice subtitles, use pillarbox/strip-over-blur with the full
   frame whole and cards in the pad; verify every baked line whole on frames.
10. Saliency reframe tracking the wrong subject or cutting faces (Crow
    doorway/corridor tracking; Primal armor-mass tracking). Rule: verify every
    reframe on frames BEFORE building; use manual subject-tracked windows
    when saliency fails; never trust a dead center-crop blindly.
11. Costume-centring failures (Witch cut_rope bridge frame centred the
    costume). Rule: sweep ALL frames; no frame centres a revealing costume;
    recut the segment — do not hope QC misses it. Face close-ups with costume
    at the bottom edge must be disclosed plainly, not hidden.
12. Family-safe flags softened or undisclosed (redundancy gun-to-temple was
    first described as a "robot hand" — the delivered crop shows no hand, the
    gun reads as unattended, which is starker; a seg1 scratch/blood trace was
    undisclosed at first). Rule: report flags plainly, never softened; verify
    flag frames yourself; a corrected flag is re-disclosed, not buried.
13. Voiceover defects (pilot v1: original audio bedded under the VO). Rule:
    SILENCE the original audio under a voiceover, never bed it. VO is never
    cut (cinematic); music ducked 65% under VO; a stem shorter than the VO
    gets a fade-out tail, never a loop.
14. Forcing unfitting music onto a clip (dark stems onto Dog/Mutant). Rule:
    never force it — hold the clip for a fitting track.
15. Treating Whisper gaps as silence (Phoenix ~80s quiet baked line missed;
    VAD merging 6.5–44.2s into one segment). Rule: transcript gaps are NOT
    silence; verify quiet lines on frames; use word timestamps for cut
    boundaries, never VAD-merged segments.
16. Faked studio UI / fake-typing builds (Before vs. After, Speedrun,
    Satisfying Split templates). Rule: BENCHED until genuine RexTrix studio
    screen recordings exist; never fake typing UI.
17. Title-based green-lights. Rule: a show title never approves a clip;
    episode-1 scout (frames + transcript) decides, every time.
18. Scope breach in fix loops (modifying clips that passed). Rule: a fix loop
    touches ONLY the failed clip(s); md5-check every other file unchanged.
19. Padding to hit a count. Rule: honesty over count — report a gap, never pad
    with a weak clip. A recut or extension beats a drop, but a drop beats a pad.
20. Claiming results nobody delivered (G3 hold-terminal; G2/G6-QC "completed"
    with no handoff). Rule: never claim a result until its report is delivered
    AND the file is verified on disk.

## Measurement mistakes (these caused false fails and false passes)
21. Full-file audio bitrate quoted as encode quality (G1 "91–149 kbps fail";
    G3 "130–168 kbps fail" — both artifacts of the silent card diluting the
    average). Rule: bitrate is CONTENT-ONLY (total minus the silent card).
22. Loudnorm measured with output-side -t (does NOT trim the filter).
    Rule: measure on pre-trimmed content or via atrim.
23. True peak measured on a mono downmix (inflates peaks up to ~1.75 dB).
    Rule: measure TP in stereo with oversampling, never downmixed.
24. Card silence judged by volumedetect's −91 dB floor. Rule: judge on
    sample-accurate PCM — exact zero after the ~4ms join transient.
25. TP boundary treated loosely (batch-15 B3: −0.9903 over a ≤−1 ceiling;
    ffmpeg's 2-decimal −1.00 cannot distinguish). Rule: gate at ≤−1.05 on
    oversampled measurement; fix = −0.1 dB audio-only gain + remux, video
    copied untouched, then re-measure.
26. Trusting builder self-declared QC (G1 audio, G3 audio, B3 TP all claimed
    pass and failed independent re-measurement). Rule: independent QC from
    scratch on rendered files — frames, decode, Whisper, measurements —
    never trust the builder's numbers.
27. Promoting partial or corrupt renders (G1 first final missing moov; G4
    seg0 files "moov atom not found"; B4 corrupt window file). Rule: null
    decode + moov/faststart check before promotion; quarantine corrupt files
    (rename, never delete).
28. Re-encoding video for invisible differences (96 kHz vs 48 kHz sample
    rate; 944:945 SAR). Rule: audio-only fixes where possible; never
    re-encode video for a difference no viewer can see.

## Upload and campaign mistakes
29. Submitting outside the 30-minute window, or re-uploading after a failed
    submit (scpzNCzCUoU: submit failed, window expired, video left unlisted).
    Rule: upload and Content Rewards-submit in ONE session per clip; on
    "couldn't confirm post time", wait 2 min and retry the SUBMISSION ONLY —
    never re-upload.
30. Uploading without the per-clip checklist: Public Short, not made for
    kids, AI-generated disclosure = Yes at upload time, related-video chain
    set, caption mentioning RexTrix in the first words, bio link live.
    Rule: every item verified per clip, not assumed from the last one.
    (Known gap: Motivational Zone still lacks the RexTrix bio link.)
31. Uploading at dead hours (12:00–14:25 PKT uploads ≈ 3–5am US Eastern drew
    ~10–20 views). Rule: post in the USA peak window; space uploads with
    good gaps so a channel never looks bot-run.
32. Campaign rejections already earned once: non-English clip (clip 15 v1),
    logo/CTA-download wording (clip 16 v1). Rule: English-only check BEFORE
    cutting; logo + download wording exactly as specified.
33. Anything that buys views, boosts, or bots. Rule: never, in any form —
    the 7 "bot activity" rejections cost ~7,366 views, and support will not
    disclose the flag metrics. Organic pacing only.
34. Delivering videos as split archives or browser-play links. Rule:
    directly playable .mp4 files via direct-download links; chat attachments
    only as fallback when hosts fail.

## How this ledger grows (the "better and better" rule)
- Every QC report, user correction, and campaign decision that reveals a new
  mistake gets a numbered entry here before the next batch starts, with the
  clip/batch that taught it.
- A builder brief that omits a relevant ledger entry is itself a mistake:
  the brief writer re-reads this file before writing the brief.
- When the user reverses a rule for a specific clip or batch, record the
  reversal as a scoped exception with its date — never silently rewrite the
  base rule.
