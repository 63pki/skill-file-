# RexTrix clip rules — standing, do not repeat past mistakes

Last updated 2026-10-29. Applies to every RexTrix clip (new batches and rebuilds) until the user changes a rule. When rules conflict, the newest dated rule wins.

## 1. Captions — placement (2026-10-28 correction)
- No added caption ever sits on the video content strip.
- Captions go in the blurred pad immediately beyond the strip edge: just below the strip's bottom edge preferred, with a small appropriate gap (~24–32px), snug to the edge — never floating far up or down. Above-strip fallback only if a block cannot fit below while keeping its bottom edge at/above y=1500.
- Every caption's bottom edge stays at/above y=1500 (Shorts bottom-UI line) on 1080×1920.
- Strip bounds for 640×360 sources: y 656–1263 (1080×608 strip). Measure per clip from the rendered file; never assume.

## 2. Captions — professional feel, no doubles (2026-10-28)
- Clean professional styling: one consistent sans-serif family, tasteful weight, subtle shadow or thin outline (no thick meme outlines), restrained size, no garish/neon colors, consistent placement.
- NO doubled captions: never the same caption text twice in one clip; never two added captions visible at the same time; never an added caption that duplicates on-screen source text (source subtitles, intro cards, UI text) saying the same thing at the same time — if the source already says it, remove or retime the added caption.
- Caption texts stay short, one idea per caption, timed to their content moments.

## 3. End card — 2.5s end-only FOR THE CURRENT BATCH (2026-10-28)
- For the current five clips (v3): RexTrix card ONLY at the end, exactly 2.5s, with the real RexTrix logo graphic + exact wording "Download the RexTrix app — link in bio".
- This 2.5s exception applies to this batch only. The earlier ≥4.5s end-card rule remains the default for future batches unless the user explicitly extends the 2.5s rule.
- NO card, bumper, or logo screen at the start, in any batch. Cut source opening bumpers/cards out (e.g., clip D's logo bumper).

## 4. Complete message (2026-10-28)
- Never cut a scene mid-enjoyment. Extend content with genuine source continuation until the scene's moment resolves (a sentence finishes, a performance phrase finishes, a demo point lands) before the card appears.
- Total duration ≤25s. No loops, freeze-frames, or slow-motion padding. If a source cannot complete a clip, report it — do not fake it.

## 5. Audio (2026-10-28)
- Speaking voices enhanced toward studio quality: light denoise, presence EQ, light compression, loudness ~-16 LUFS, true peak ≤-1 dB. No clipping or distortion.
- Honest limit: compressed social sources cannot become true studio quality; report before/after measurements, never claim otherwise.
- Music-only clips: leave audio alone except level-matching after an edit.

## 7. Hook strength, speaking scenes, ducking, hook copy, readability (2026-10-28, batch-6 feedback — user correction)
- Hook first: the first 1–3s must carry the strongest, self-explanatory moment — a payoff, a surprise, or a question. A closing/resolution moment alone is NOT a hook, and satisfying rule 4 (complete message) does not excuse a weak opening. No angle or format switch (e.g., portrait scene → wide scene) inside the opening that breaks the moment; the opening must read instantly, never feel random or irrelevant — Shorts viewers, gaming viewers included, decide in ~2s.
- Speaking scenes need room: if speech carries the point, use a full thought. A 1–2s speaking fragment cannot land an idea — either give the line its full length or cut the speech, never a fragment that leaves the viewer with nothing.
- Ducking is mandatory under speech: whenever a person speaks, background music is ducked LOW under the speech (real ducking, not just overall level-matching). Speech enhancement (rule 5) applies to EVERY clip containing speech, including short closing lines — it was wrongly skipped on batch-6 clips. Music-only clips stay exempt from ducking.
- Hook copy must be sharp, not just cleanly styled: vague labels (e.g., "HIS CLOSING WORD") are not hooks. Hook text must be specific, curiosity-driven, and tied to the visual in the same seconds. Professional = clean style AND sharp copy AND readable size.
- Readability of the message: never let the clip's key message ride on small baked source text. If source text (e.g., an explore-screen format list) is too small to read at phone size, either crop/zoom to it or restate it in a large readable added caption. Verify readability on a rendered frame viewed at phone scale.

## 6. Standing pipeline rules (unchanged)
- English-only sources and speech; check split-screen/creator strips and burned-in non-English subs BEFORE cutting.
- No banned claims; no invented features.
- 1080×1920, 30fps, libx264 slow, CRF 16, yuv420p, AAC 192k, faststart (moov first).
- Audio bitrate is measured on the CONTENT section only (total duration minus the silent end card): a silent card encodes near-zero bits, so a full-file average is diluted and must never be quoted as encode quality (2026-10-29: group-1's 91–149 kbps full-file "fail" was a test artifact; content-only rates were 193–201 kbps, true 192k).
- Measurement methods that have bitten before (2026-10-30): loudnorm must be measured on pre-trimmed content or via atrim — an output-side -t does NOT trim the filter's measurement, so "content-only" figures taken that way are whole-file figures; true peak must be measured in stereo, never on a mono downmix (downmixing inflates peaks by up to ~1.75 dB); card silence is judged on sample-accurate PCM (exact zero after the ~4 ms join transient), not volumedetect's −91 dB floor reading.
- 640×360 sources are presented as a 1080-wide strip over blurred pads (this scales the source up — never describe it as native HD).
- At upload: Public Short, not made for kids, AI-generated disclosure = Yes, related-video chain set, campaign-submit in the same session (30-min window).
- Nothing uploads or submits without the user's explicit word for that exact version.
- Independent QC on rendered files before delivery (frames, decode, Whisper, measurements) — never trust the builder's self-declared QC.
- Keep prior versions labelled at hand; never overwrite v1/v2 when building v3.

## 8. Pilot-only viral caption experiment + benched templates (2026-10-29, user decision)
- The "Viral Meta" caption spec (Montserrat Bold, white, 4px black outline, dead center, max 3 words per chunk, word-by-word) is an ISOLATED EXPERIMENT for the voiceover pilot only, to test short-form retention. It does NOT change the standing professional-caption defaults (§1–§2), which remain the baseline for everything else.
- Benched until genuine RexTrix studio screen recordings exist: Before vs. After, Speedrun Challenge, Satisfying Gameplay Split. Building them from drama scenes with faked typing UI would look artificial and trigger "fake ad" pushback — do not fake studio UI.
- Current no-voiceover focus: optimize the Addiction Loop, Debunk, and Split-Screen drafts from the drama/cinematic scenes already held.

## 9. Caption chunking — semantic phrases, not word counts (2026-10-29)
- Chunk captions at phrase/clause boundaries, never by raw word count alone. A 3-word cap is a ceiling, not a splitting rule — if the third word would fracture a phrase, the break moves.
- Never split a noun phrase across cards ("A STRAWBERRY ASSISTANT" stays whole) and never split a brand command from its brand ("DON'T DOWNLOAD REXTRIX" stays whole).
- Descriptive/noun-phrase cards dwell ~20–30% longer than short operational cards ("I TYPED:").
- Scope limit, stated plainly: this rule governs builds from sources. Text already baked into a supplied render cannot be re-chunked by editing a script — re-chunking a render requires its source project file or its raw source footage.

## 10. Human edit feel — engagement rule (2026-10-30, user direction)
- Edits must feel made by a human editor, not stamped by a template. A viewer
  should never feel the same edit pattern repeat clip to clip.
- Cut on beats, not intervals: cut on action, a line's landing, or a reaction
  — never at fixed time intervals, never metronomic. Vary shot lengths to
  the scene's energy.
- Let moments breathe: hold a reaction face a beat past the line so the
  emotion lands; let a line's tail and a half-second of room tone play before
  a cut; no hard clicks at joins (short audio fades).
- Emphasis, sparingly: one subtle punch-in or slow push on the payoff moment
  per clip at most — never constant zoom, never on every beat.
- Sound design, kept low: light SFX accents on transitions and impacts
  (whoosh into action, soft hit on a reveal) from the existing SFX library,
  ducked under speech, never competing with it.
- Pattern interrupts: one surprising angle, detail, or withheld payoff per
  clip — hold the reveal 1–2s behind a reaction so curiosity carries the
  viewer to the end.
- Never identical templates: vary openers (cold line, visual hook, question),
  vary card dwell within the allowed range, vary pacing per scene. Two clips
  must not share the same edit beat-for-beat.
- Human does not mean sloppy: mid-sentence cuts, glitches, doubles, and
  ledgered mistakes still fail. Naturalism is breaths, held glances, and
  room tone — not errors.
- Applies to every build from 2026-10-30 onward. Already-rendered clips are
  NOT retrofitted without a user-ordered rebuild.
