# CAMPAIGN BRIEF — RexTrix

source_platform: Content Rewards (Whop clipping) — https://contentrewards.com/c/campaigns/c92fdeb2-eaa6-42c1-84dd-c97964869cc5
reconciled_against:
- Campaign rules document, "RexTrix · Content Rewards Campaign Rules", §§1–10, read in full 2026-10-26 — https://docs.google.com/document/d/1rNwZaLVsEJTSxKj8Tglqc74olrDSJBsT5qOQg8WoOXo/edit
- Campaign page on Content Rewards (figures and submission behaviour verified live 2026-10-22/23; not re-read in this pass)
- Official assets Drive folder "Edited Video Assets" (folder list opened 2026-10-22; individual files NOT inspected)
- Operator's own run records (rejections 2026-10-23, Studio checks 2026-10-24/26) — labelled "NOT a campaign document" wherever cited; these never fill a campaign-rule slot
status: READY_FOR_MASTER_INTAKE — both AMENDMENT REQUIRED blocks confirmed by the operator as class: mandatory on 2026-10-27; attach gate lifted.

Standing rules applied: SCOUT_CORRECTION_NOTES.md (CR-1..CR-6), issued 2026-10-27 after master-intake verification of the first version of this brief. The v2 prompt file is not held by the scout; these notes win on every conflict with the v1 prompt.

ATTACH NOTE (CR-3): parts of this brief paraphrase the rules document. Before intake, the master MUST read the following sections of the source document verbatim, and must take its claims ledger, banned list, end-card definition, and CTA wording from those verbatim readings, not from any paraphrase in this brief:
- rules doc §4 (Talking Points) — feeds the claims ledger;
- rules doc §5 (The One Rule Every Video Must Pass) — feeds brand-mention and CTA requirements;
- rules doc §7 (Submitting Your Post) — feeds the submission and recording requirements;
- rules doc §8 (Why Posts Get Rejected) — feeds the banned list.
Contamination-critical strings (banned lists, end-card definition, CTA wording) are verbatim or MISSING in this brief — never paraphrased in depth. Where this brief says MISSING for such a string, the master reads it verbatim from the section above.

Quoting note: direct quotes from the rules document are kept to short load-bearing lines only. Every other requirement below is a close paraphrase with its section reference, so the master prompt can check it against the source document, which remains the full authority.

Gate verdict (Part 1): RexTrix passes all five gates — (1) RIGHTS: the campaign authorises downloading from its own socials and supplies an edited-assets Drive; (2) WRITTEN RULES: a full rules document exists and is readable; (3) REAL REWARDS: stated payout terms, no published deadline, budget-limited; (4) SOURCE QUALITY: partial — real gameplay assets supplied, but no resolution is stated in the document, so each asset must be verified before use; (5) LOW RISK: no health/finance/political claims, adult content banned, claims must be personally tested. Selected as the operator-requested campaign (already joined as "aze10"); no other campaign was briefed in this pass.

## 1. CAMPAIGN VALUES

- brand / product: RexTrix — an app for AI-generated games and interactive AI stories, made from a typed idea. — source: rules doc §§1, 3, 6 — class: mandatory (identity)
- objective: app installs driven through the bio download link, paid per qualified view. — source: rules doc §§2, 6, 7 — class: mandatory
- audience: 18+, on accounts with at least 40% US audience. — source: rules doc §2 — class: mandatory
- viewer_value: play a game or watch a story that AI generated from an idea — surprising, funny, or visually impressive content discovered or created inside RexTrix. — source: rules doc §6 — class: mandatory (content must be genuine RexTrix output)
- primary_mechanics: the seven formats in §3 of the rules document, presented there as inspiration, not templates; copying another creator's video 1:1 is prohibited. — source: rules doc §3 — class: mandatory (the no-copy rule); preference (choice among formats)
- optional_mechanics: MISSING — the document names no optional mechanics beyond the format list.
  - no fallback — operator must supply.
- platform_targets:
  - TikTok: public post; caption mentions RexTrix; bio link from day 1; under-1K-follower accounts add the bio line in §3 below. — source: rules doc §2; campaign page — class: mandatory
  - Instagram: public post; caption mentions RexTrix; bio link from day 1. — source: rules doc §2; campaign page — class: mandatory
  - YouTube (Shorts): public post; caption mentions RexTrix; bio link from day 1. — source: rules doc §2; campaign page — class: mandatory
  - X: public post; caption mentions RexTrix; bio link from day 1. — source: rules doc §2; campaign page — class: mandatory
  - Audio requirements per platform: MISSING in the document.
    - operator_default: keep each asset's original audio; add no external music or voiceover without separate clearance (source: operator safe fallback, NOT a campaign document).

## 2. DELIVERY REQUIREMENTS

- resolution: MISSING — the document states no resolution.
  - operator_default: 1080×1920 vertical (source: operator pipeline standard, NOT a campaign document).
- fps: MISSING — the document states no frame rate.
  - operator_default: 30fps (source: operator pipeline standard, NOT a campaign document; 60fps was used in one batch, but its approval is unproven, so it is not a default).
- runtime range: MISSING — the document states no length.
  - operator_default: 15–25s mini-arc (source: operator editor standard, NOT a campaign document).
- language_rule, spoken: MISSING in the document — no language rule is written there.
  - Covered by AMENDMENT REQUIRED — Language rule (below). Do not use a default for this rule.
- language_rule, burned-in text: MISSING in the document.
  - Covered by AMENDMENT REQUIRED — Language rule (below). Do not use a default for this rule.
- container / codec: MISSING — the document states none.
  - operator_default: MP4, H.264, yuv420p, AAC 192k, faststart (source: operator pipeline standard, NOT a campaign document).
- captions required or not: NOT required by the document. Captions appear only as an editing tip (use captions, zooms, quick cuts, clear visuals; remove unnecessary pauses). — source: rules doc §9 — class: preference
- placement: posts must stay publicly available throughout the campaign and review period. — source: rules doc §§8, 10 (visibility rule) — class: mandatory

## 3. BRANDING AND CTA

- end card: MISSING in the document — no end-card definition, logo requirement, or hold duration is written there.
  - Covered by AMENDMENT REQUIRED — End-card rule (below). Do not use a default for this rule.
- mandatory_inclusions:
  - Every video must clearly mention RexTrix in the caption, on-screen text, or video itself. — source: rules doc §5 — class: mandatory
  - "RexTrix" should appear within the first 3–4 words of the caption — stated as "ideally", i.e. a preference on position, while the mention itself is mandatory. — source: rules doc §5 — class: preference (position); mandatory (mention)
  - Add the RexTrix download link to the posting account's bio from day 1: https://rextrix.onelink.me/nJbb/dbj5fov3 — source: rules doc §2 — class: mandatory
  - TikTok accounts under 1K followers add this bio line: "AI games & stories: RexTrix". — source: rules doc §2 — class: mandatory (conditional)
  - A call to action in the video telling viewers to click the link in bio. — source: rules doc §2 — class: mandatory
  - A clear RexTrix connection in every video: real gameplay or content from RexTrix; generic AI clips with no meaningful RexTrix integration are a stated rejection ground. — source: rules doc §§5, 8 — class: mandatory
- cta_rules:
  - allowed actions: telling viewers to click the link in bio. — source: rules doc §2 — class: mandatory
  - approved destinations: the single bio link above. — source: rules doc §2 — class: mandatory
  - exact CTA wording: MISSING — the document gives no fixed wording.
    - operator_default: "Download the RexTrix app — link in bio" (source: operator standard wording, NOT a campaign document).
  - max requests per clip: MISSING.
    - operator_default: 1 bio-link CTA per clip (source: operator delivery standard, NOT a campaign document).

## 4. BANNED

Contamination-critical section (CR-3). The banned lists below are MISSING as reproduced strings in this brief by design: the master must read them verbatim from the source document sections cited, per the ATTACH NOTE at the top. No paraphrase of these lists appears here.

- banned_claims: MISSING — not reproduced here.
  - Read verbatim: rules doc §4 (claim classes and the "only demonstrate features personally tested" rule) and §8 (false claims about pricing, speed, rewards, or results; nonexistent features; fake or fabricated demonstrations).
- banned_patterns: MISSING — not reproduced here.
  - Read verbatim: rules doc §8 (competitor promotion, hard-sell spam, reposting without permission or meaningful contribution, copyright infringement, unrelated gaming or meme accounts, bought/botted/boosted engagement, manipulated analytics, edited or fabricated analytics).
- prohibited_associations: MISSING — not reproduced here.
  - Read verbatim: rules doc §8 (content targeting minors; explicit sexual content, graphic violence, hateful material).
- General ban rule (paraphrase of a non-list rule, covered by the ATTACH NOTE): do not invent features or make unsupported claims. — source: rules doc §4 — class: mandatory

## 5. OWNER MANDATES

Only mandates stated in writing in the campaign document. Nothing the operator "feels" is included here. (Paraphrases in this section are covered by the ATTACH NOTE; the master reads §§4, 5, 7, 8 verbatim before intake.)

- Every video must clearly mention RexTrix (caption, on-screen text, or video itself). — source: rules doc §5 — class: mandatory
- Bio download link from day 1 (URL in §3). — source: rules doc §2 — class: mandatory
- Call to action in the video to click the bio link. — source: rules doc §2 — class: mandatory
- Only show capabilities and results actually tested in RexTrix; only demonstrate features personally tested. — source: rules doc §§4, 6 — class: mandatory
- Show surprising, funny, or visually impressive content discovered or created inside RexTrix. — source: rules doc §6 — class: mandatory
- Posts stay publicly available throughout the campaign and review period. — source: rules doc §§8, 10 — class: mandatory
- Account must have at least 40% US audience. — source: rules doc §2 — class: mandatory
- Use the §3 formats as inspiration; do not copy other creators' videos 1:1. — source: rules doc §3 — class: mandatory
- "RexTrix" within the first 3–4 caption words, stated as "ideally". — source: rules doc §5 — class: preference
- Editing tips (captions, zooms, quick cuts, clear visuals; remove unnecessary pauses). — source: rules doc §9 — class: preference

## AMENDMENTS REQUIRED (CR-2, CR-6)

The two rules below are proven enforced by operator evidence but absent from the written rules document. They do NOT rest on defaults: the master must not treat them as optional. Each block states the rule, the evidence, and the mandatory wording. CONFIRMED by the operator as class: mandatory on 2026-10-27 — the attach gate is lifted and both blocks are now mandatory requirements of this brief.

### AMENDMENT REQUIRED — End-card rule

- Rule: every video must end with an end card carrying the RexTrix logo graphic and explicit download wording.
- Evidence (NOT a campaign document): clip 16 was rejected 2026-10-23 despite a full 4.0s text-only end card reading "Link in bio / to try RexTrix" with a top-right bug — the reviewer required the actual RexTrix logo graphic and wording that says users must download the app; "to try RexTrix" did not qualify. The operator's delivered end-card spec across batches 1–2 was 4.0s, so 4.0s is the enforced historical floor with zero margin (CR-1).
- Mandatory wording (confirmed by the operator 2026-10-27): "Every video must end with an end card of at least 4.5 seconds (4.0s enforced floor + 0.5s margin) carrying the RexTrix logo graphic and the wording 'Download the RexTrix app — link in bio'."
- CONFIRMED: operator confirmed class: mandatory on 2026-10-27.
- Closes §8 question Q3. The brief and this amendment state must never disagree (CR-6).

### AMENDMENT REQUIRED — Language rule

- Rule: every video's spoken audio and burned-in text must be English; non-English source material must be excluded, not captioned over.
- Evidence (NOT a campaign document): clip 15 was rejected 2026-10-23 for non-English content — its source creator spoke Arabic with burned-in Arabic subtitles, and English paraphrase captions did not save it. The rejection reason given was that content should be in English.
- Mandatory wording (confirmed by the operator 2026-10-27): "All spoken audio and burned-in text in every video must be English. Non-English source material must be excluded; English captions over non-English speech do not satisfy this rule."
- CONFIRMED: operator confirmed class: mandatory on 2026-10-27.
- Closes §8 question Q4. The brief and this amendment state must never disagree (CR-6).

## 6. ASSETS AND SOURCES

Link register (access status as checked):

| URL | Role | Access status | Notes |
|---|---|---|---|
| https://docs.google.com/document/d/1rNwZaLVsEJTSxKj8Tglqc74olrDSJBsT5qOQg8WoOXo/edit | Guidelines (the rules document) | Checked, read in full 2026-10-26 | §§1–10; source of every §-cited requirement above |
| https://contentrewards.com/c/campaigns/c92fdeb2-eaa6-42c1-84dd-c97964869cc5 | Campaign page / submission platform | Verified live 2026-10-22/23, not re-read in this pass | Source of the 500-view/$1.00 floor, the $200 per-clip cap, and the 30-minute submission validation |
| https://drive.google.com/drive/folders/1FA4pPfLGaEJp99ZpfFMpPtEEAaYcz5WB | Raw footage — "Edited Video Assets", per-show subfolders | Folder list opened 2026-10-22; individual files NOT inspected | Verify each asset's content and quality before building on it |
| https://www.tiktok.com/@rextrix_ai_studio | Raw footage (official social) | Listed in rules doc §6 | Downloading explicitly authorised by the document |
| https://www.instagram.com/rextrix_ai_info/ | Raw footage (official social) | Listed in rules doc §6 | Downloading explicitly authorised by the document |
| https://x.com/RextrixAI | Raw footage (official social) | Listed in rules doc §6 | Downloading explicitly authorised by the document |
| https://www.facebook.com/profile.php?id=61590029252777 | Raw footage (official social) | Listed in rules doc §6 | Downloading explicitly authorised by the document |
| https://www.linkedin.com/company/rextrix-ai/home/ | Raw footage (official social) | Listed in rules doc §6 | Downloading explicitly authorised by the document |
| YouTube "RexTrix AI" (channel, per operator brief) | Raw footage (official social) | Named in the operator brief, NOT a campaign document; not in the rules doc link list | Treat as official social source; verify handle before use |
| https://rextrix.ai/ | Reference (product site) | Link verified, not deep-inspected | Use to verify real features before claiming them |

- rights statement (paraphrase of rules doc §6, covered by the ATTACH NOTE): the campaign authorises downloading images and videos directly from RexTrix's own social media, and supplies the edited-assets Drive for clipping. That authorisation covers RexTrix's own materials only; it does not grant rights over stock footage, other games, or third-party content, and no such permission may be inferred from an asset being supplied.

## 7. SUBMISSION AND OPERATOR CHECKLIST

Submission flow as written in the document (§7):

1. After publishing, submit the post URL in the campaign support chat immediately.
2. Wait at least 24 hours after posting.
3. Send a screen recording of the post analytics showing views, reach, and audience information.
4. The team verifies the submission.
5. Approved qualified views become eligible for payout.

Submission behaviour on the platform (NOT a campaign document — operator evidence, verified in runs 2026-10-22/24): the campaign page validates that a post was made within the last 30 minutes at submission time, so in practice the URL is submitted on the campaign page in the same session as upload. The document's "support chat immediately" step and the page's 30-minute validation are two descriptions of the same immediacy requirement; the operator satisfies both by submitting on the page in-session and sending the analytics recording to the support chat after 24 hours. See §8, Q6.

- analytics reporting duty: "The 24-hour analytics screen recording is mandatory." — source: rules doc §7 — class: mandatory. Failing to submit it is a stated rejection ground. — source: rules doc §8 — class: mandatory
- audience requirement: account must have at least 40% US audience. — source: rules doc §2 — class: mandatory. Note: the recording shows each video's own geography, which is what a reviewer sees in practice (NOT a campaign document — operator evidence).
- review: "Every submission goes through manual review." — source: rules doc §6 — class: mandatory. Approval is not automatic on sending the recording; only approved qualified views become payable. — source: rules doc §§6, 7 — class: mandatory
- payout terms (quoted): "Payout: $2 per 1,000 qualified views, max $300 per post." — source: rules doc §6 — class: mandatory. Only authentic, verified views qualify. — source: rules doc §6 — class: mandatory
- payout floor and cap discrepancy: the document states no minimum view count; the campaign page shows payouts starting at 500 views ($1.00 minimum) and a max of $200 per clip. Plan and quote against the stricter page figures (500 views, $200) until the owner clarifies. See §8, Q1–Q2.

Operator checklist (per clip; all mandatory except where marked operator rule):
- [ ] Caption clearly mentions RexTrix (ideally first 3–4 words)
- [ ] Bio download link live from day 1
- [ ] Call to action to click the bio link
- [ ] Clear RexTrix connection (real gameplay/content, personally tested features only)
- [ ] No banned claims — banned lists read verbatim from rules doc §§4, 8 per the ATTACH NOTE; no competitor promotion, no minors targeting, no explicit/violent/hateful material
- [ ] Post stays public through campaign + review
- [ ] URL submitted on the campaign page within 30 minutes of posting
- [ ] Analytics screen recording (views, reach, audience) sent to the support chat after 24 hours
- [x] AMENDMENT REQUIRED blocks (end-card, language) confirmed by the operator as class: mandatory (2026-10-27)
- [ ] OPERATOR RULE (NOT a campaign document): nothing is sent to the support chat until the operator explicitly says send; recordings for clips under 500 views are not sent

## 8. UNRESOLVED QUESTIONS

1. Per-clip cap: the document says max $300 per post; the campaign page says max $200 per clip. Why it matters: earnings math and which figure to promise.
   - operator_default: plan and quote against $200 until clarified (source: campaign page figure, stricter of the two).
2. Minimum views for payout: MISSING in the document; the campaign page shows a 500-view / $1.00 floor. Why it matters: it decides which clips are worth recording.
   - operator_default: 500 views (source: campaign page).
3. End-card specification: MISSING in the document — no logo requirement, wording, or hold duration is written.
   - Closed by AMENDMENT REQUIRED — End-card rule (above), CONFIRMED by the operator as class: mandatory on 2026-10-27. No default is used for this rule (CR-2).
4. Language rule: MISSING in the document — no spoken or burned-in language rule is written.
   - Closed by AMENDMENT REQUIRED — Language rule (above), CONFIRMED by the operator as class: mandatory on 2026-10-27. No default is used for this rule (CR-2).
5. Delivery specs: resolution, fps, runtime, container/codec are all MISSING in the document. Why it matters: the master prompt cannot invent them as requirements.
   - operator_default: 1080×1920 vertical, 30fps, 15–25s, MP4/H.264/yuv420p/AAC 192k/faststart (source: operator pipeline standard, NOT a campaign document).
6. Submission destination: the document says submit the URL "in the campaign support chat immediately", while the platform validates a 30-minute window on the campaign page. Why it matters: the operator must not miss the window by using the wrong channel.
   - operator_default: submit on the page in-session AND send the recording to the support chat after 24 hours (source: current working practice, NOT a campaign document).
7. Campaign end date and remaining budget: MISSING in the document; the page showed a $1,000 budget with $85 used at the 2026-10-22 check (stale). Why it matters: prioritisation if the budget runs out.
   - operator_default: treat as budget-limited; prioritise the highest-view clips first (source: operator practice, NOT a campaign document).
8. Exact CTA wording: MISSING — the document requires a CTA but gives no fixed wording. Why it matters: wording affects conversion and reviewer acceptance.
   - operator_default: "Download the RexTrix app — link in bio" (source: operator standard wording, NOT a campaign document).
9. Per-video vs per-account US test: the document states the account must have 40%+ US audience, but review in practice sees each video's geography in its recording. Why it matters: a clip on a US-passing account can still show a non-US audience (observed: 9.7% US on one clip — NOT a campaign document, operator evidence). 
   - operator_default: judge each clip by its own recording's geography as well as the account's (source: operator practice, NOT a campaign document).

## 9. OPERATOR NOTES — NOT EDITING REQUIREMENTS

(The master prompt must ignore this section; it is for the human only.)

- Reward terms: $2 per 1,000 qualified views; document cap $300/post; page cap $200/clip; page floor 500 views / $1.00 minimum. Earnings accrue only after manual review approval; nothing accrues while a submission is Pending.
- Deadline: none published. Budget-limited ($1,000 total; $85 used at the 2026-10-22 check — stale, re-check before quoting).
- Competition level: not published. Operator's own run: 63 videos posted and submitted across three channels by 2026-10-26; 10 had crossed 500 views at the last full check; 2 confirmed 40%+ US audiences (Seedance clips at 92.6% and 87.7%); 1 confirmed fail (Cinema clip at 9.7% US); 7 geographies still blank in desktop Studio at that check. (All figures in this bullet: NOT a campaign document — operator evidence.)
- Selection rationale: RexTrix is the operator's active campaign, already joined, with supplied assets and a readable rule set; it passed all five gates with only the source-quality caveat (verify each asset; document states no resolution).
- Revision history: this brief was revised 2026-10-27 under SCOUT_CORRECTION_NOTES.md (CR-1..CR-6). Changes versus the first version: end-card default corrected from ≥3.5s to the AMENDMENT REQUIRED block at ≥4.5s (4.0s enforced floor + 0.5s margin) — the old default sat below enforced practice; end-card and language rules moved from optional defaults to AMENDMENT REQUIRED blocks; banned lists moved from paraphrase to MISSING with a verbatim-read directive (ATTACH NOTE added); every MISSING now carries an operator_default or an explicit "no fallback"; operator evidence now carries the "NOT a campaign document" label on every citation.
- 2026-10-27: operator confirmed both AMENDMENT REQUIRED blocks as class: mandatory; attach gate lifted; brief fully READY_FOR_MASTER_INTAKE.
- Corrections this brief makes to the operator's earlier brief (2026-10-22): format mapping corrected to the document — C is "Create Something Unexpected" and D is "Interactive Story / Plot Twist" (earlier brief had them swapped); the banned-claims list is longer than the earlier brief's three examples (the full list lives in rules doc §§4, 8 — read verbatim per the ATTACH NOTE); the document's submission flow names the support chat, while the 30-minute rule comes from the platform, not the document; language and end-card logo rules are reviewer enforcement observed in rejections, NOT written document rules, and are handled through the amendment path, not as defaults.
- Standing operator rules that are NOT campaign rules: nothing goes to the support chat until the operator explicitly says send; recordings are only made/sent for clips at 500+ views; finished videos go out as direct-download links; every upload sets YouTube's AI-generated disclosure to Yes; related-video chaining per channel.
