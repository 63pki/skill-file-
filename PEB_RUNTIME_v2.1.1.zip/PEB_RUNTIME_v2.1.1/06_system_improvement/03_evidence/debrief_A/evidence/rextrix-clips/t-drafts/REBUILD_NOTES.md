# T-draft rebuild — source notes (2026-10-29)

## Sources identified
- T3 (Toilet Kingdom) source show: plain "Toilet Knight" folder
  https://drive.google.com/drive/folders/1MZtePN6rX9TZLu7pq5ODpTTtmuWNZ1UJ
  NOTE: the folder literally named "Toilet Knight: Sewer Vengeance"
  (https://drive.google.com/drive/folders/1x8Q9n_YPWyhhO8uflQk9AO4k1dtAolq4)
  is EMPTY — it holds no episode videos.
  Episodes in the real folder (all Jul 7, owned by rextrix_mkt):
  TKSV-1.mov 254.5 MB; TKSV-2.mov 262.2 MB; TKSV-03.mov 263.1 MB;
  ToiletKnight_ep7.mov 260.7 MB; ep8 263.6 MB; ep9 261.7 MB; ep10 263.7 MB.
  No ep4/ep5/ep6 listed directly. Subfolder "AWS Source Episodes - EP01-EP03"
  (https://drive.google.com/drive/folders/1GxOLHFuQO7CZ9ZQy9-F_0XFY25w9dpqp):
  Toilet Knight - EP 01.mp4 132.2 MB; EP 02.mp4 146.8 MB; EP 03.mp4 125 MB.
- T1 (Strawberry Assistant) source show: "The Strawberry Assistant's Secret"
  https://drive.google.com/drive/folders/1VLyl0fi2VDpeti9yUC9BKvjjmzcsDagK
  30 episodes: ep1–ep6 .mov ~434–438 MB each (Aug 15); ep7–ep30 .mp4 ~85–88 MB each (Aug 19).
  Target first: The Strawberry Assistant's Secret_ep1.mov (436.3 MB).
- T2 (split-screen) top-panel show: NOT yet identified. Bottom panel likely
  Strawberry Assistant world; confirm from footage before cutting.

## Download history
- 2026-10-29 ~14:41–14:56 PKT: Drive UI Download route FAILED (virus-scan
  "Download anyway" clicks, download action "unknown" every time, nothing landed
  in ~/workspace/browser_downloads/ — verified by local check).
- Retry launched ~14:57 PKT: direct-download route (uc?export=download&id=<ID>)
  after extracting file IDs from preview URLs — the route that worked for batch 7.
- RETRY SUCCEEDED ~15:03–15:07 PKT (tool-confirmed downloads):
  - TKSV-1.mov — file ID 1AMqXvYRDxzkp7k8GOelY5o7Nz_Nr_Uw9 — 266,906,826 B —
    local: ~/workspace/browser_downloads/sess-784897735/browser-download-20261029T100044.951538411Z-0-TKSV-1.mov
    Probe: 1080x1920 30fps H.264, 183.6 s (vertical native).
  - The Strawberry Assistant's Secret_ep1.mov — file ID 13LVIKKT9g5ieVcPQTFkpJyvJ0hDSepEK —
    457,443,219 B — local: ~/workspace/browser_downloads/sess-784897735/browser-download-20261029T100425.960357663Z-1-The_Strawberry_Assistant_s_Secret_ep1.mov
    Probe: 1080x1920 30fps H.264, 302.8 s (vertical native).
- Scene scout running (transcript + frames across both episodes) to confirm ep1
  holds the draft scenes (toilet throne/rain/king; pear woman, strawberry
  assistant, secret; T2 top-panel angry girl) or more episodes are needed.
- SCOUT RESULT 2026-10-29 ~15:16 PKT (transcripts + 10s-interval frames, ±2–3s):
  - T3: ep1 SUFFICIENT. King 0.0–6.3s ("waste oil… three times over the limit"
    = draft opening audio); dark liquid 0–6s + ~40–50s; throne-in-rain ~40–50s
    (wide night street shot); sewer 60.0–67.0s ("surviving passages in the sewer").
    "I've been in here for 3 hours" is NOT spoken dialogue — it was baked text in
    the draft, so the rebuild carries equivalent text over the ~40–50s throne shot.
    Episode ends with a clean RexTrix card ~180s.
  - T1: ep1 SUFFICIENT. Pear woman 5.4–10.3s ("six-figure suit" line = draft
    opening audio, draft opening cut from 5.4–29.2s); strawberry assistant 0.0–5.4s
    + 45.9–56.6s ("You saw nothing" window); pomegranate man ~40s onward
    (41.5–45.9s debt line); secret beats 96.9–100.4s ("Check the timestamps.
    Someone edited the schedule manually"), 212.2–216.2s, 298.1–299.7s.
  - T2: top panel NOT in either ep1. No "plan"/"daughter" in either transcript;
    no human girl in any sampled frame (all characters fruit/object). Bottom-panel
    material exists in both, but the split pair cannot be completed from ep1s
    alone. Options: identify the kitchen-girl source show, or rebuild T2 with a
    changed top panel (TK-vs-SB split from held material).
- T2 HUNT RESULT 2026-10-29 ~15:51 PKT (top-panel frames + transcript, no downloads):
  - Top panel is a MONTAGE, not one shot: kitchen ~0–4s (blonde teen girl in grey
    hoodie shouting, plaid-shirt man, curly-haired apron woman), bedroom ~5s
    (adult blonde woman shocked), kitchen close-up ~8s (apron woman shocked).
    Live-action family ensemble. NO baked source subtitles in the top panel
    (TK/SB carry baked subs throughout) — weak evidence of a different,
    non-subtitled production. Only intelligible speech in the whole clip:
    0–7s "daughter. You want a plan." Baked draft cards: "ONE OF THESE WAS
    TYPED. NOT WRITTEN." (~0–4s), "SAME APP. DIFFERENT WORLDS" (~7–10s).
  - CORRECTION: T2's bottom panel at 5s is the Toilet Knight spiked cauldron
    with "G" crest in rain (matches TKSV-1 40–44s) — bottom is at least partly
    TOILET KNIGHT, not Strawberry as earlier assumed.
  - Candidates (title/theme fit ONLY, none confirmed, no episode sampled):
    (1) "Cheating's the least of our family's problems Season 1" — best fit
    (family show, kitchen argument + daughter line) BUT it sits on the
    family-safe EXCLUSION list (adult/romance-leaning): even if confirmed, use
    needs a sample-first safety check; the panel itself is non-sexual.
    (2) "Swapped at Birth" — family drama, mothers/daughters, two-household
    cutting fits; NOT on the exclusion list.
  - Confirmation task launched ~15:52 PKT: locate both folders in Edited Video
    Assets, list episodes, download ep1 of candidate (1) via direct-download
    route (fallback: candidate (2) ep1 if (1) folder missing).
- CONFIRMATION RESULT 2026-10-29 ~15:59 PKT (tool-confirmed):
  - "Cheating's the least of our family's problems Season 1" folder:
    https://drive.google.com/drive/folders/1qM-DlQPOZLvl4SY0m4GXNQmd0E1px2v5
    — contains ONLY ep1 (Cheating's…_ep1-.mov, 324 MB; file ID
    1DnZ05P571tQQ7F_XVBXCmMCYmQ1N-90i). Downloaded: 339,769,336 B, local
    ~/workspace/browser_downloads/sess-784897735/browser-download-20261029T105637.309380430Z-2-download.
    Probe: 1920x1080 LANDSCAPE 30fps, 235.4 s — if this IS the source, the T2
    top panel needs vertical reframing (the draft's top panel is a crop).
  - "Swapped at Birth" folder:
    https://drive.google.com/drive/folders/1ABdfsJq3beX1uq-qtMYtXjN-hQjOpFgX
    — Swapped at birth_ep1.mov 257.7 MB + ep2–ep6 (~244–262 MB) + SBE-07..13
    (~227–262 MB, each shown twice in the Drive listing — likely a listing
    quirk). NOT downloaded; fallback only.
  - Scene + safety scout running on Cheating's ep1 (kitchen scene + "You want a
    plan!" line + adult/romance content check).
- SCOUT RESULT 2026-10-29 ~16:04 PKT: Cheating's ep1 is NOT the source (full
  transcript + frames every 5s across 100% of 235s). No blonde teen girl at all
  (only a teen boy, car-crash sequence ~25–55s, blood on his shirt); no plaid
  shirt, no checkered cloth, no apron woman, no 3-person kitchen shouting scene;
  "plan" and "daughter" nowhere in the transcript. Safety note (now moot for
  sourcing): non-sexual family/marital drama — infidelity discussed ("that man,
  are you serious about him?", marriage-strain dialogue) but NO sexual content,
  nudity, or explicit material in any sampled frame/line; mild blood only.
- NEXT: Swapped at Birth ep1 fetch launched (~16:05 PKT, direct-download route);
  scene scout to follow on arrival. Swapped folder already located (see above).
- SWAPPED EP1 LANDED 2026-10-29 ~16:08 PKT (tool-confirmed): 270,177,900 B,
  file ID 1JC0sFavbrQZgWZoizm_IJYxqYW1GZk_2, local
  ~/workspace/browser_downloads/sess-784897735/browser-download-20261029T110642.839066611Z-3-Swapped_at_birth_ep1.mov.
  Probe: 1080x1880 (near-vertical, 40px short of 1920) 30fps, 184.9 s.
  Scene scout running (kitchen trio + "You want a plan!" line + content note).
- SCOUT RESULT 2026-10-29 ~16:11 PKT: Swapped ep1 ALSO eliminated (full transcript
  + 18 frames at 10s intervals). Dialogue is bone-marrow/ICU/identity only
  ("Does a penniless [person] even deserve to donate bone marrow…", "cut off
  all possibilities of Elena's ancestral identity"); "plan"/"daughter" absent.
  Settings: hospital, school, warehouse, night street — NO home kitchen. Teen
  girl wears a school uniform (not grey hoodie); men in suits (no plaid, no
  checkered cloth); no apron woman. Content family-safe on frames checked, but
  the scene is not in this episode. BOTH title candidates now eliminated;
  next needs user direction: show name from user, Swapped later episodes
  (ep2–6, SBE-07..13), other titles, or TK-vs-SB split fallback.
- REBUILDS DONE 2026-10-29 ~15:30 PKT (builder) + parent QC PASSED same session:
  - t1_rebuild.mp4 — 18.3s (13.8 content + 4.5 card). Cuts: pear hook 6.0–10.3s,
    strawberry window 50.0–56.0s, secret beat 96.9–100.4s. Cards: "TESTING THIS
    APP" / "I TYPED:" / "A STRAWBERRY ASSISTANT" / "WITH A SECRET".
  - t3_rebuild.mp4 — 20.5s (16.0 content + 4.5 card). Cuts: king hook 0.0–6.3s,
    cauldron in rain 40.0–44.1s, throne-in-rain 45.0–50.6s with 1.1x zoom.
    Cards: "DON'T DOWNLOAD REXTRIX" / "UNLESS..." / "ONE LINE TYPED" /
    "3 HOURS GONE". Sewer 60–67s NOT used (line spans window, would cut mid-line).
  - Parent QC: both 1080x1920 30fps, decode OK; T1 I −16.44/TP −1.42, T3
    I −15.66/TP −1.31; card sections −91.0 dB mean (T1 has only a faint fade
    residue in the first 0.5s per builder note); 8 frames checked — centered
    Montserrat cards whole, no shared words with concurrent baked subs, end
    cards clean. Delivered 2026-10-29 ~15:47 PKT, links expire 2026-10-31 ~15:47 PKT.
  - NOT uploaded — awaiting user review + explicit word + channel per clip.

## Rebuild spec (from user direction + pasted analyses, verified against frames)
- Semantic text cards: phrases kept whole, brand kept whole, descriptive
  phrases dwell ~20–30% longer than operational cards. Keep the drafts' existing
  Montserrat Bold centered look; fix structure, not style.
- T3: 1.1x slow zoom across the static window (already proven on the render).
- T2: mute ALL original audio, ONE royalty-free high-energy track across the
  timeline (Audio Library fetch pending engload23 2FA — user decision awaited).
- Audio: ~-16 LUFS, TP <= -1 dB, end-card silence. End cards >= 4.5 s.
- T1-fixed upload HELD — superseded by the rebuild; do not upload old versions.

## Swapped ep2–6 scout — ALL ELIMINATED (2026-10-29 ~16:43 PKT)
- ep2–6 downloaded + verified on disk (1080×1880 30fps, 181.9–187.7s) and
  scouted in full: Whisper transcript per episode + frames at 10s intervals
  (94 frames total). Evidence: t-drafts/swapped-scout/ (ep2–ep6 transcripts,
  frames, sheets). Parent re-verified: grep for plan/daughter/kitchen = 0 hits
  in all five transcripts.
- All five continue ep1's exact story (Elena, ICU/will, foundation, Pembroke
  family, diary) with the same cast (school-uniform girl, pink-dress blonde,
  suited men). No kitchen, no hoodie girl, no plaid shirt, no apron woman in
  any episode. Conclusion: Swapped episodes 1–6 are fully ruled out.
- Still unchecked: SBE-07 to SBE-13 files (separate naming batch, same folder).
  Awaiting user direction: SBE round 2, or the Toilet-vs-Strawberry rebuild
  fallback, or a show name from the user.
