# QC REPORT — c15_c2_dog (Dog of the West)
Self-QC by the assembly subagent, 2026-10-30. Parent verification still required.

## File
- `~/workspace/rextrix-clips/batch-15/finals/c15_c2_dog.mp4`
- 24.0s total = 21.5s content + 2.5s end card (720 frames = 645 + 75)
- 1080×1920, 30fps, H.264 slow CRF 16, yuv420p, AAC 192k @ 48kHz stereo, faststart (moov before mdat) — PASS
- Null decode: OK

## Content
- Picture: saliency-reframed source 58–68s (10s) + pillarbox title 68–70s (2s, full frame over blur, strip y656–1264) + saliency-reframed desert 72.5–80.5s (8s) + 1.10x punch-in 80.5–82s (1.5s, dog+stagecoach head-on).
- VO: vo_c2_dog.mp3, 20.92s, UNCUT, offset 0.0 (last word ends 20.60; 0.58s picture tail + 0.32s file silence = 0.90s breath before card).
- Music: "That's Right I'm Country" (YouTube Audio Library, no attribution required), ducked 0.35 under VO throughout, 0.5s tail fade into the card join.
- Source audio: silenced under VO. No baked-audio speech competes.
- SFX (synthesized with ffmpeg, gain 0.12 in mix — no verified licensed library found on disk; see build notes): whoosh at clip 5.0s (leap), soft hit at 10.0s (title reveal). Ducked low, never competing.
- End card: first 2.5s of batch-30 group-5 card source — logo + "Download the RexTrix app — link in bio" + "AI-generated Games & Stories", verified on frames, video-only.

## Measurements (own, per CLIP_RULES §6 methods)
- Content-only audio bitrate: 198.3 kbps (packet bytes, pts < 21.5) — PASS
- Loudnorm, content section (atrim): I −16.04 LUFS (gate ~−16 ±1), oversampled stereo TP −3.58 dB (gate ≤−1.05) — PASS
- Whole-file loudnorm: I −15.99, TP −3.58 — PASS
- Card silence: mix-side card is exact PCM zero (120,000 samples, max_abs 0). Final AAC-decoded card: 29/120,000 samples at ±1 LSB (−96.3 dBFS) — AAC codec noise floor, inaudible; equivalent to the prior batch's accepted −91 dB volumedetect observation. PASS with this note.
- Card frames: exactly 75 (720 total − 645 picture) — PASS

## Cards (ASS, Montserrat Bold, middle-centre, phrase chunks)
- 16 events, no overlaps, first 0.00, last ends 20.60.
- ONE documented exception: "DOG OF THE WEST" (0.70–1.98) is 4 words — the character name kept whole rather than split across cards. All other events ≤3 words.
- Gap 9.84–12.52 covers the pillarbox title (10.0–12.0) — no card over the title; no card duplicates the baked "get down it's not safe" (~4s) or "welcome / to the west" (~10–12s) lines at those moments.

## Frame checks (final file)
- 0.5s: living-room reframe, portal glow at right edge, "They call him" card — hook is the portal, not a face.
- 4.0s: dog bark close-up, no card (planned VO-only gap) — correct.
- 9.9s: owner on couch + TV portal (reframe) — owner IS visible late in the living-room segment.
- 10.1s / 11.9s: pillarbox title whole ("WELCOME TO THE WEST" + "to the west" sub), clean over blur pads — PASS.
- 12.1s: desert dog head-on, no card, NO sliced title — the boundary fix worked.
- 14.0s: desert dog + "be his last" card — PASS.
- 20.1s: punch-in dog+stagecoach + "Link in bio" card spanning the punch cut — clean.
- 23.0s: end card, logo + wording verified.

## Fixes applied during this build (honest record)
1. Title/desert boundary measured on exact-seek source frames: title runs to ~72.2, desert starts ~72.5 (the 1fps sheet's tile mapping was offset by ~1s in the middle). Desert segment moved from 16.0 to 16.5 (source 72.5), title tail 70–72.5 skipped (static, already read). Content shortened 22.0 → 21.5s, mix rebuilt, total 24.5 → 24.0s.
2. Stream-copy segment extraction (−ss + −c copy) produced a 22.17s concat for a 21.5s plan (keyframe seek imprecision) — the first picc2 build was DISCARDED, chain stopped, segments re-extracted with re-encode (frame-accurate), picc2 rebuilt. Final c2_pic is exactly 645 frames.

## Human-edit feel (§10)
- Opener: reaction/room first (portal intrigue), then escalation: bark → leap → owner-reaction hold → pillarbox title beat (pattern interrupt: format switch at the story hinge, entering the TV) → desert run → punch-in payoff. Openers/pacing differ from C3 (face-first vs garden-wide).
- Short audio fades at joins; no hard clicks (audio is continuous VO + continuous music bed; picture cuts are the only edits).

## Weakest point (honest)
- The owner's FACE never appears in the reframe's opening (the tracker held the portal/TV side at source 60); the owner appears only at ~9–10s (watching from the couch). The VO's "owner shouts" beat lands via the baked sub "get down it's not safe" (visible whole at ~4s) + the dog's reaction, not via an owner face. Same absent-character caveat as C1 (Briggs), but here the absence is crop-caused, so it is disclosed, not hidden. The clip still reads: dog ignores the warning, leaps in, western world.
- "outlaws" line rests on episode evidence outside the window (scout note, carried).

## Verdict: SELF-QC PASS (all gates met; flags above disclosed, none a ledger fail)
