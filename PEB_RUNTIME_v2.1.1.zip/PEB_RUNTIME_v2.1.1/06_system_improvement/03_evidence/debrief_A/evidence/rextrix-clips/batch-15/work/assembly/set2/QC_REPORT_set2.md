# INDEPENDENT QC — batch-15 cinematic set 2 (B2, B3, B4, B5, C1)

Independent verification from scratch. The builder's notes
(`NOTES_set2.md`), packages (`scouts/groupB/PACKAGE.md`,
`scouts/groupC/PACKAGE.md`) and template
(`EXECUTION_SCRIPT_CINEMATIC.md`) were read first, but every reading
below was reproduced by this QC run (ffprobe / ffmpeg decode /
loudnorm / 4×-oversampled true peak / tail-waveform analysis /
faster-whisper "small" transcripts of the finals / full-size frames).
No final was edited. Nothing was uploaded, published, submitted, or sent.

**Verdicts: B2 PASS · B3 FAIL · B4 PASS (flagged weakness) · B5 PASS
(flagged blemish) · C1 PASS.**

The 2.5 s end card on every clip is the template's own spec and a
deviation from the standing ≥4.5 s default, flagged here as in the
builder's notes. It is not counted as a fail in this report.

## Common results (all 5)

### Specs / decode / faststart
| clip | file | frames | duration | claim | video | audio |
|---|---|---|---|---|---|---|
| B2 | c15_b2_primal.mp4 | 809 | 26.967 s | 26.97 s | H.264 High, 1080×1920, 30/1 fps, yuv420p | AAC-LC, 48 kHz, mono |
| B3 | c15_b3_adrift.mp4 | 775 | 25.833 s | 25.83 s | H.264 High, 1080×1920, 30/1 fps, yuv420p | AAC-LC, 48 kHz, mono |
| B4 | c15_b4_redundancy.mp4 | 768 | 25.600 s | 25.60 s | H.264 High, 1080×1920, 30/1 fps, yuv420p | AAC-LC, 48 kHz, mono |
| B5 | c15_b5_zeroed.mp4 | 765 | 25.500 s | 25.50 s | H.264 High, 1080×1920, 30/1 fps, yuv420p | AAC-LC, 48 kHz, mono |
| C1 | c15_c1_unsolved.mp4 | 794 | 26.467 s | 26.47 s | H.264 High, 1080×1920, 30/1 fps, yuv420p | AAC-LC, 48 kHz, mono |

Frame counts are exact (ffprobe `-count_frames`); durations match
claims to ≤0.003 s. `ffmpeg -f null` decode: exit 0, no errors, on all
5. Faststart: moov at byte 36, before mdat (~29–31 kB), in all 5.

### Audio bitrate — encode setting AND measured averages
- Encode-setting evidence (builder's `assemble.sh`, corroborated, not
  trusted alone): `-c:a aac -b:a 192k -ar 48000` for every clip.
- Measured averages (audio stream re-extracted with `-c:a copy`,
  bytes×8/duration; container-inclusive, so these are ceilings, not
  exact codec rates):
  - Main (picture) section: B2 207.2, B3 206.7, B4 202.5, B5 205.3,
    C1 204.2 kbps — all above 192k.
  - Whole file (ffprobe header): B2 186.5, B3 185.7, B4 181.3,
    B5 183.6, C1 183.6 kbps — lower because the 2.5 s silent card
    dilutes the average, exactly as the builder claimed (B4's header
    figure sits 0.7 kbps below the builder's "182–186" band; the
    re-extracted whole-file average for B4 is 183.2 kbps, inside it).
- Judgement: **PASS on the 192k encode.** This is not a repeat of the
  prior batch's 91–149k failure: the VO section measures >200 kbps.

### Loudnorm (ffmpeg `loudnorm` print, reproduced exactly)
| clip | I (LUFS) | TP (dBTP, ffmpeg) | TP (independent 4× oversample) | verdict |
|---|---|---|---|---|
| B2 | −16.31 | −1.06 | −1.0593 | PASS |
| B3 | −16.47 | −1.00 | **−0.9903** | **FAIL (see B3)** |
| B4 | −16.28 | −1.10 | −1.0918 | PASS |
| B5 | −16.50 | −1.10 | −1.0897 | PASS |
| C1 | −16.38 | −1.07 | −1.0660 | PASS |

All builder-claimed I/TP values reproduced to 0.01 dB by ffmpeg's own
filter. Integrated loudness is ~−16 LUFS on all 5, per template.

### End card — exactly 75 frames, end only, content, silence
- Frame arithmetic: total frames − 75 = picture frames in every case
  (B2 734 = 24.467 s, B3 700 = 23.333 s, B4 693 = 23.100 s,
  B5 690 = 23.000 s, C1 719 = 23.967 s). Boundary frames confirm the
  picture→card transition at exactly total−2.5 s (frame at
  card−0.034 s is picture, frame at card+0.034 s is the card), and
  first-card vs mid-card frames are pixel-identical (static card).
  No card frame appears before the end section in any sampled
  hook/mid/last-picture frame.
- Content (viewed on full-size card frame, identical on all 5):
  RexTrix logo + "Download the RexTrix app — link in bio" +
  "AI-generated Games & Stories". Correct.
- **Silence — the −91 dB question, resolved precisely.** The builder's
  "−91.0 dB mean" is a volumedetect average, not a description of the
  card audio. Continuous-decode waveform analysis of the card section
  (decoding from 0.5 s before the boundary, so no seek artefact):
  - B2, B3, B4: **exact digital zero from the first card sample** to
    the end of the file.
  - B5, C1: a single 10 ms bin at the boundary at −84.3 / −80.8 dBFS
    peak (1–3 LSBs, AAC quantisation residue), then exact zero for
    the remaining ~2.49 s.
  - This is **NOT a fade tail bleeding into the card**: pre-card audio
    ends abruptly at the boundary (e.g. B3 holds −52 dBFS peak /
    −65 dBFS RMS right up to the boundary, then zero); there is no
    decay curve inside the card. The up-to-67 ms of −52 dBFS audio
    that `-sseof` and `-ss`-before-`-i` extractions show inside the
    card is an AAC frame-granularity artefact of input seeking
    (frames straddling the boundary are emitted whole); continuous
    decode disproves it.
  - Judgement: **card silence PASSES on all 5.** The set-1 literal
    "max 0" bar is met except for one inaudible 10 ms residue bin on
    B5/C1 (≤−80.8 dBFS). If the parent wants literal zero there too,
    the fix is to pad the silence from an exact frame boundary at
    remux; it is not a viewer-audible defect.
  - Side note: B2/B4 go silent 30–40 ms *before* the video card
    starts (last picture frame already silent) — inaudible, no action.

### VO — whole and uncut, no competing voice
faster-whisper "small", run on each final's decoded audio (PyAV is
broken on this box, so audio was decoded to 16 kHz mono PCM with
ffmpeg first and fed as an array). Transcripts, sentence-for-sentence
against the package monologues:
- B2: exact, every sentence, incl. "Link is in my bio."
- B3: exact, every sentence, incl. "Link is in my bio."
- B4: exact except Whisper hears "puts in near" where the monologue
  (and the card, correctly) reads "puts him near" — a Whisper
  mis-hearing the builder already corrected on the card, not a VO
  error. No sentence missing.
- B5: exact, every sentence, incl. "Link is in my bio" **in the audio**
  (the dropped items were the last two *cards*, not VO words — see
  B5 note). Whisper spells "Vane" as "Vayne"; the card correctly
  reads "Vane".
- C1: exact, every sentence, incl. "The cargo was untouched, but the
  lifeboat was missing."
- No second voice, no drama dialogue, and no extra lines appear in
  any transcript — source drama audio is absent (it would have
  transcribed, e.g. B3's baked dialogue lines do not appear). **PASS
  on all 5.**

### Cards — style, word count, sync
- ASS style line verified in all 5 files: `Montserrat Thin`, Bold=−1,
  68 pt, white (`&H00FFFFFF`), Outline 4, black outline, Alignment 5
  (middle-centre). `fc-match "Montserrat Thin:bold"` independently
  confirms Bold maps to `Montserrat-Bold.ttf`.
- Max words per event: 3 on all 5 (27 / 25 / 26 / 24 / 23 events for
  B2 / B3 / B4 / B5 / C1, matching builder counts). Phrase-whole
  chunks; on viewed frames the cards sit middle-centre, white bold
  with black outline, and match the spoken phrase at that time
  (checked against the transcripts and ASS timings).
- No added card duplicates a baked subtitle at the same moment on any
  frame examined (per-clip detail below).

### Grade legibility (all 5)
Dark cinematic grade is in effect and never crushes faces or key
action on any viewed full-size frame: B2 rex texture/eyes, B3 both
faces, B4 robot-woman face and cityscape, B5 device text and monitor
text, C1 doll/cabin detail all remain legible. C1's specified grade
is confirmed in the assembly script
(`eq=contrast=1.12:brightness=-0.01:saturation=1.08` applied in the
final pass for B2/B4/B5/C1; B3's window was pre-graded and is
deliberately not re-graded in the script, matching the notes).

---

## B2 Primal — PASS

- Specs/decode/faststart/bitrate/loudnorm (I −16.31 / TP −1.06) /
  card / VO / cards: all pass as above.
- Re-cut 126–152 s window: verified on frames — explosion dirt plume
  (final ~1 s, card "The Rex,"), rex face-close (final ~8.3 s, card
  "An open plane"), charge at the red-eyed machine line (final ~15 s,
  card "Now, each charge"), machine-rex reveal (final ~24.3 s,
  last-picture frame). All core beats present.
- Eyes: on the face-filling frame both orange eyes are fully clear
  above the card band; cards cross snout/jaw only, as the builder
  disclosed. No card covers a rex eye on any frame examined.
- Naming: "the rex" descriptor only throughout VO, cards and
  transcript; no invented name. Correct per the scout caveat.
- Weakest point (agreed with builder): weakest template fit — no named
  human character, descriptor-only CGI beast; middle-centre cards
  necessarily cross the face when the face fills the frame.

## B3 Adrift — FAIL (2 defects, both fixable)

Defect 1 — true peak over the ceiling (strict).
- ffmpeg loudnorm reports TP −1.00, which at 2-decimal precision
  cannot distinguish "at" from "over" the TP ≤ −1 dB ceiling.
- Independent 4×-oversampled true peak: **−0.9903 dBFS**, i.e. ~0.01 dB
  OVER the ceiling. Sample peak is exactly −1.0000 dBFS. This is not
  rounded into a pass: on the strict TP ≤ −1 dB rule, B3 fails by a
  hair. (The same 4× method reproduces the other four clips' ffmpeg
  TPs within 0.01 dB, so the method is not biased high.)
- **Fix:** apply the same −0.1 dB audio-only gain + remux (video
  stream copy) the other four clips already received, then re-measure;
  expected TP ≈ −1.09 dBTP, unambiguous pass. No picture change needed.

Defect 2 — letterboxed picture, not a full-frame reframe.
- Confirmed on full-size frames and by row-luminance measurement:
  the picture band is 1080×608 (first picture row ≈ y 656, last ≈
  y 1264); rows above and below are pure black (mean 0.0). Black bars
  occupy ~65.8% of the 1080×1920 canvas.
- The container meets "1080×1920" but the picture does not meet the
  full-frame reframe spec honestly: on a phone the clip plays as a
  small centred strip with large black bars, unlike the other four
  full-frame reframes.
- **Fix (parent decision required):** either (a) explicitly accept
  the letterbox as an exception for this clip — it is the only way to
  hold both faces full-width in one shot — in which case only the
  audio fix above is needed; or (b) re-render as a true tracked 9:16
  reframe, accepting that the two-shot will then alternate faces
  rather than holding both at once.
- Everything else on B3 passes and is verified: both faces held in
  the two-shot (final ~8.4 s frame: card "Could trap him" between the
  faces, baked "Kale this is untested" below, no clash, different
  wording and position); no card duplicates "I volunteer I will be
  the first", "Kale this is untested", "may not go dormant it may
  fight back", or "I've been fighting my whole life what's one more
  enemy" at their moments (the near-misses "Because he volunteers" /
  "First upload" and "Then I fight" differ in wording/time); closing
  cards over Kale's front-face close-up from ~19–20 s onward are as
  the builder disclosed and follow the template's non-negotiable
  middle-centre rule; VO whole; card silent (exact zero).
- Note: the builder's claim that the existing window was kept because
  "the fit-width pad preserves full width" is accurate as far as it
  goes — it just does not make the result a full-frame reframe.

## B4 Redundancy — PASS (flagged weakness: one-sided accusation beat)

- Specs/decode/faststart/bitrate/loudnorm (I −16.28 / TP −1.10) /
  card / VO / cards: all pass.
- Corrupt-window claim confirmed independently: the old
  `redundancy_window.mp4` fails ffprobe with "moov atom not found".
  The final does not use it — the assembly script uses the re-render
  `b4_reframe.mp4` (1080×1920, ~24.0 s), and the final's trim offset
  0.5 s keeps source ~86.5–109.6 s, so the 88–108 s core is intact.
- Accusation beat (final ~8.5 s frame): **the builder's disclosure is
  correct — Voss is out of frame** (only a dark edge of a second
  figure at frame left); the saliency track follows the robot woman
  alone. Judgement: the beat still reads *one-sidedly* — the robot's
  accusing face plus the baked line "…0.8 seconds at the plaz…" (itself
  edge-sliced by the crop) convey the accusation, and the VO at that
  point is "Everyone is born…", so nothing contradicts it — but
  Voss's reaction, the other half of the two-shot, is absent. This is
  a real weakening of the scene, not a spec failure; it is flagged,
  not failed. If the parent wants the two-shot, the fix is a
  re-render with a wider/looser track or a manual two-shot hold at
  the accusation moment.
- Baked bans respected: no card duplicates "you paused for 0.8
  seconds at the plaza", "your quota is near threshold 2", or "just a
  professional habit" at their moments (cards then read "Everyone is
  born" / "With 21" / "Now one paused" — different wording).
- No second logo: no gold source watermark is visible on any sampled
  reframe frame (checked at 4 s, 8.5 s, 23 s); the end-card logo is
  separate and after the picture. The city card "THE HUMAN
  P… / SECTOR Z…" is held at the end but is edge-sliced by the crop
  (readable from context) — a reframe artefact, noted.
- "Executioner's threshold" rests partly on Whisper, as the package
  flagged (baked line reads "threshold 2"); the card wording follows
  the monologue, not the baked line, so there is no duplication.

## B5 Zeroed — PASS (flagged blemish: "App." over the device's first 0.19 s)

- Specs/decode/faststart/bitrate/loudnorm (I −16.50 / TP −1.10) /
  card / VO / cards: all pass.
- Device beat: at final ~21.7 s the frame is **card-free**, the wrist
  device is fully framed, and "Poy counter" with waveform bars is
  legible. No card ever reads "Poy counter". Both task checks pass.
- **Correction to the builder's claim:** the device shot is NOT
  card-free for its whole 21.0–22.3 s span. At final 21.15 s the card
  "App." (ASS 21.07–21.26 s) sits **over the fully-framed device
  screen**, immediately right of the words "Poy counter" (it does not
  cover those words). So the overlap is real but small: 0.19 s, one
  word, not covering the key text, and the payoff beat at 21.7 s is
  clean. Judgement: blemish, not a fail.
  - Optional fix if the parent wants a strictly card-free device
    shot: drop the "App." card as well (cards then end at "Waiting
    inside the", 21.04 s); the VO audio still says the full closing
    sentence, as verified by transcript.
- The disclosed residual is otherwise accurate: the device is fully
  framed by ~21.0 s (21.3 s frame confirms), and the VO-length tail
  adds a monitor shot after the payoff (final ~22.3–23.0, "…VATION
  ERROR RATE: 0.03%" legible) — the clip does not end exactly on the
  device, as disclosed.
- Window timing (exact-seek basis, not fps/Whisper-derived, per the
  caveat): the final's picture runs from the 182–206 s reframe with
  0.5 s trim, consistent with the 184 s body-grip and 204 s device
  beats landing at final ~21.7 s for the device; the device frame
  itself confirms the beat.
- Cards cross Vane's lower face/mouth-chin on face-close shots, eyes
  never covered (per builder; consistent with the frames examined).

## C1 Unsolved — PASS

- Specs/decode/faststart/bitrate/loudnorm (I −16.38 / TP −1.07) /
  card / VO / cards: all pass.
- Grade: exactly the specified 1.12 / −0.01 / 1.08 lift is in the
  assembly script's final pass for C1, and the picture on frames is
  dark-cinematic without crushing (doll detail at final ~12 s, card
  "Found drifting with", fully legible; cabin/coat detail legible).
- Deliberate card gap verified twice: in the ASS file, no event spans
  14.08–16.42 s ("Every person gone" ends 14.08, "But the lifeboat"
  starts 16.42), covering the VO words "The cargo was untouched"
  (14.72–16.08 s); on frames at 14.9 s and 15.4 s there is no added
  card. Cards resume at "But the lifeboat" (final ~16.8 s frame
  confirms, card present over the cabin kit).
- Baked-subtitle slicing judged as **reframe artefact, not a double**:
  the saliency crop slices full-width baked lines at their edges —
  seen directly as "…ingle person was gone" (14.9 s) and "…gs were
  left behind" (16.8 s). In both cases the added card (when present)
  is middle-centre with different wording from the baked line at the
  bottom, so there is no duplicated phrase and no overlap. The sliced
  baked text is a cosmetic crop artefact inherent to 16:9→9:16 on wide
  subtitle lines.
- Briggs: no Briggs figure appears on any sampled frame (boarding
  party, cabin, doll, coat, kit); consistent with the package's
  "absent hero" caveat. This is a sampled-frames confirmation, not an
  exhaustive every-frame proof.
- Baked bans respected: no card duplicates a banned phrase at its
  moment; near-misses use different wording/time ("Ten people
  sailed" vs baked "10 people in total bound for Genoa Italy";
  "Every person gone" vs baked "every single person was gone";
  "The ship was" / "Found drifting with" vs baked "the ship was
  intact").

## Fix list (only B3 blocks shipment)

1. **B3 audio:** −0.1 dB audio-only gain + remux (video copy), then
   re-measure loudnorm; ship only when TP ≤ −1.05 dBTP (to leave
   margin, not just ≤ −1.00).
2. **B3 picture (parent decision):** accept the 1080×608 letterbox as
   an explicit exception, or re-render a true tracked 9:16 reframe
   (losing the simultaneous two-shot). Do not ship B3 as a
   "full-frame reframe" without that decision recorded.
3. Optional, B5: drop the "App." card (21.07–21.26 s) for a strictly
   card-free device shot.
4. Optional, B4: widen/hold the track at the accusation moment if the
   two-shot matters more than the saliency follow.
5. Optional, B5/C1: re-pad card silence from an exact frame boundary
   if literal sample-zero (max 0) over the whole 2.5 s is required;
   current residue is one 10 ms bin at ≤−80.8 dBFS, inaudible.

## Method note (for the parent)
- Loudnorm: ffmpeg `loudnorm` (print) + independent 4× polyphase
  oversampled peak from decoded float PCM. The 4× figure is what
  catches B3; ffmpeg's 2-decimal print alone would have hidden it.
- Card silence: continuous decode from before the boundary, per-10 ms
  peak/RMS bins, plus exact sample counts (nonzero/max_abs) — not
  volumedetect means and not seek-based extractions, both of which
  mislead here in opposite directions.
- Transcripts: faster-whisper "small" on ffmpeg-decoded 16 kHz mono
  PCM (direct file input fails on this box: PyAV `metadata_errors`
  incompatibility — same failure the builder hit).
- Frames: full-size 1080×1920 PNG grabs at hook / mid / beat /
  last-picture / card times listed per clip above; B3 letterbox also
  measured by row luminance (band y ≈ 656–1264, bars mean 0.0).
