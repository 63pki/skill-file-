# Batch-15 cinematic assembly — set 2 of 2 — NOTES

All 5 finals delivered. Nothing uploaded, published, submitted, or sent to anyone.
Work files: `~/workspace/rextrix-clips/batch-15/work/assembly/set2/` (cuts, reframes,
ASS, mixes, scripts, frame grabs). v1 files with marginal true-peak readings are
archived in that dir (`*_v1.mp4`); the files in `finals/` are the verified versions.

## Common spec (all 5, verified)

- Video: 1080x1920, 30 fps, H.264 High, libx264 slow, CRF 16, yuv420p, faststart
  (moov before mdat in every file). Audio: AAC-LC, 48 kHz, encoded at 192k
  (main-section averages 200–205 kbps; whole-file averages 182–186 kbps because
  the 2.5 s silent card dilutes the average — the VO section itself is ~192k+).
- Picture: graded dark-cinematic windows, source audio STRIPPED (final audio is
  VO + ducked stem only). Trimmed to the VO length from handle edges only —
  no payoff beat cut, no freeze/slow-mo padding. Faces verified not crushed.
- VO: whole file used, never cut internally. Trailing file silence kept
  (last spoken word ends 0.3–0.45 s before each VO file ends).
- Music: no-vocals campaign stems only, ducked to 35% (x0.35) under VO throughout.
  Short stems fade out over their final ~1.5 s — never looped, never stretched.
  Long stems trimmed at the tail. c2 (raw I −31.56) gained +12.5 dB BEFORE the
  duck so it does not vanish (pre-duck ~−19 LUFS, ducked ~−28 under VO).
- Cards: ASS subtitles, font file Montserrat-Bold.ttf via ASS Fontname
  "Montserrat Thin" Bold=-1 (fc-match confirms Bold maps to Montserrat-Bold.ttf),
  white, 4 px black outline, middle-centre (Alignment=5), max 3 words per event,
  phrase-whole chunks timed from faster-whisper word timestamps of the actual VO
  (PyAV is broken on this box, so VOs were decoded to PCM via ffmpeg first).
  Whisper mis-hearings corrected on cards: B4 "Vos" → "Voss", "puts in near" →
  "puts him near"; B5 "Vayne" → "Vane".
- End card: END ONLY, exactly 2.5 s (75 frames), silent. Source: first 2.5 s of
  `batch-30/group-5/work/card_fixed.mp4`, verified on frames (RexTrix logo +
  "Download the RexTrix app — link in bio" + "AI-generated Games & Stories",
  video-only stream). The v3 fallback was NOT needed.
- Card silence: verified by extracting each final's last 2.5 s to wav and
  running volumedetect: all measure −91.0 dB mean. (First-pass readings showed
  −52 dB peaks on B3/B5/C1 — those were a ~10 ms seek sliver of main-section
  tail at the boundary, not card audio: excluding the first 100 ms, all five
  read −91.0/−91.0. A direct `-ss`-after-`-i` volumedetect invocation also
  misreported full-level audio and was discarded after the wav-extraction
  check proved it wrong.)
- Loudnorm: final whole-file readings below (linear pass on the padded mix,
  then a −0.1 dB audio-only trim + remux, video copied, where v1 true peak
  exceeded −1 dB by 0.01–0.04 dB).

⚠️ 2.5 s-END-CARD DEVIATION FLAG (every clip): this template uses a 2.5 s end
card at END ONLY, NOT the standing ≥4.5 s default. This deviation applies to
this batch only, on the user's word via the template.

## B2 Primal — c15_b2_primal.mp4 — 26.97 s (picture 24.45 + card 2.5)

- Window: RE-RENDERED, not the old 24 s window (VO 24.45 s is longer than it).
  Source `primal_machines_ep1.mp4` cut 126–152 s, saliency reframe (`--no-face`,
  `--out-w 1080`) → 782 frames, 26.02 s, 1080x1920, probed clean. Final trim
  offset 0.5 s → all core beats kept (explosion, rex face-close, roar, charge,
  machine line ~142 s, machine-reveal ~146 s).
- Grade: contrast 1.12 / brightness −0.01 / saturation 1.08 (final pass).
- VO: `vo_b2_primal.mp3` whole. 27 cards. No baked subtitles anywhere in the
  window (verified) — no duplication possible. Descriptor-only "the rex" kept;
  no proper name invented.
- Music: c3 (I −17.29), ducked 0.35, shorter than VO (24.04 vs 24.45) → fade-out
  over final 1.5 s (22.54–24.04).
- Loudnorm final: I −16.31, TP −1.06 (v1: −16.20/−0.97 → −0.1 dB fix).
- Card silence: −91.0 mean / −76.3 max (AAC floor).
- Verified on frames: reframe holds explosion, face-close, charge, machine line,
  machine-rex reveal; the rex eye never enters the card band (y ~910–1010) in
  sampled frames (eyes at y ~510–700; machine eyes below/above the band);
  final mid frame shows card "An open plane" (white bold, black outline,
  middle-centre, 3 words) over the snout with both eyes clear.
- Weakest point: middle-centre cards necessarily cross the rex's snout/jaw
  during face-filling shots (the face IS the frame there); eyes are never
  covered. Also the weakest template fit overall (no named human character —
  descriptor-only CGI beast, per the scout caveat).
- ⚠️ 2.5 s end card flag (deviation from ≥4.5 s default).

## B3 Adrift — c15_b3_adrift.mp4 — 25.83 s (picture 23.33 + card 2.5)

- Window: existing `adrift_window.mp4` (26 s, already graded 1.15/−0.04/1.08 —
  NOT re-graded, to avoid a double grade). Final trim offset 1.0 s → source
  286.0–309.33, core 287–309 intact. Both faces verified held in the two-shot
  (window t02/t08/t15/t19): the fit-width pad preserves full width, so the
  task's re-render condition ("if it does not hold both faces") did not trigger.
- VO: `vo_b3_adrift.mp3` whole. 25 cards.
- Music: c2, +12.5 dB gain then 0.35 duck, tail trimmed (24.94 → 23.33).
- Loudnorm final: I −16.47, TP −1.00 (no fix needed).
- Card silence: −91.0/−91.0 (excluding seek sliver).
- Baked bans respected: no card duplicates "I volunteer I will be the first",
  "Kale this is untested", "may not go dormant it may fight back", or "I've
  been fighting my whole life what's one more enemy" at their moments.
  Near-misses kept (different wording and/or time, different screen position —
  added cards middle-centre, baked lines bottom): VO "Because he volunteers" /
  "First upload" vs the baked volunteer line; VO "Then I fight" (12.7–13.7 s)
  vs the baked fight line at window t21 (final ~20 s). Final mid frame (8 s)
  verified: two-shot, both faces, card "Could trap him" between the faces,
  baked "Kale this is untested" below, no clash.
- Verified on frames: two-shot through final ~19 s; Kale front-face from
  window ~t20–21 (final ~19–20) to the end — so the closing cards ("The story
  is" onward) sit over Kale's face. Kept per the template's non-negotiable
  middle-centre spec (the package's face note is acknowledged here).
- Weakest point: closing ~3 s of cards over Kale's front-face close-up; the
  single static two-shot lives/dies on VO + framing (scout caveat). Picture is
  letterboxed (1080x608 band centred, black bars) — unlike the full-frame
  reframes of the other four clips.
- ⚠️ 2.5 s end card flag (deviation from ≥4.5 s default).

## B4 Redundancy — c15_b4_redundancy.mp4 — 25.60 s (picture 23.07 + card 2.5)

- Window: the old `redundancy_window.mp4` was NOT used — confirmed CORRUPT
  (moov atom not found). Re-rendered from `human_reserve_redundancy_ep1_4.mov`
  cut 86–110 s, saliency reframe → 725 frames, 24.02 s, probed clean before use.
  Final trim offset 0.5 s → core 88–108 intact.
- Grade: contrast 1.12 / brightness −0.01 / saturation 1.08 (final pass).
- VO: `vo_b4_redundancy.mp3` whole. 26 cards.
- Music: c1 (I −17.56), ducked 0.35, shorter than VO (22.08 vs 23.07) → fade-out
  over final 1.5 s (20.58–22.08).
- Loudnorm final: I −16.28, TP −1.10 (v1: −16.17/−0.99 → −0.1 dB fix).
- Card silence: −91.0/−76.3.
- Baked bans respected: no card duplicates "you paused for 0.8 seconds at the
  plaza", "your quota is near threshold 2", or "just a professional habit" at
  their moments (VO cards then: "Everyone is born" / "With 21" / "Now one
  paused" — different wording). No second logo added: the source-baked gold
  RexTrix watermark (top-right) is cropped out of the reframe in sampled
  frames; the end-card logo is separate and after the picture.
- Verified on frames: quota screen "+0.096" (the "POY" unit text is cropped at
  the right edge by the vertical crop — the number itself is huge and legible);
  accusation beat tracks the robot woman (Voss is out of frame at that instant
  — the saliency track follows her face); city card "THE HUMAN PRESERVE" held.
- Weakest point: the accusation two-shot is lost to the saliency track at the
  key moment (robot woman only; Voss's reaction not visible at final ~8.5 s);
  montage window leans on the VO (scout caveat); "executioner's threshold"
  rests partly on Whisper (the baked line reads "threshold 2", a truncation
  artefact).
- ⚠️ 2.5 s end card flag (deviation from ≥4.5 s default).

## B5 Zeroed — c15_b5_zeroed.mp4 — 25.50 s (picture 22.99 + card 2.5)

- Window: rendered from `zeroed_ep1.mov` cut 182–206 s, saliency reframe →
  725 frames, 24.01 s, probed clean. Timing confirmed by EXACT-SEEK frames from
  source (184 s body-grip, 204 s "Poy counter" device) — never re-derived from
  fps frames or Whisper times, per the timing caveat. Final trim offset 0.5 s
  → core 184–204 intact, plus ~1.3 s tail (see weakest point).
- Grade: contrast 1.12 / brightness −0.01 / saturation 1.08 (final pass).
- VO: `vo_b5_zeroed.mp3` whole. 24 cards (26 planned minus 2 dropped, below).
- Music: c2, +12.5 dB gain then 0.35 duck, tail trimmed (24.94 → 22.99).
- Loudnorm final: I −16.50, TP −1.10 (v1: −16.39/−0.99 → −0.1 dB fix).
- Card silence: −91.0/−91.0 (excluding seek sliver).
- Baked: no baked subtitles in the window (verified); no card uses
  "Poy counter". Device-shot protection: the last two cards ("Link is in",
  "My bio.", 21.64–22.90 s) were DROPPED so the fully-framed device shot
  (final ~21.0–22.3) plays card-free; cards end at "App." (21.26 s). At the
  exact 204 s beat (final ~21.7 s) no card is on screen — verified on the
  final's last-picture frame (22.5 s: monitor shot, no card). Residual: up to
  ~0.3 s of "Waiting inside the"/"App." may overlap the device's entrance
  transition (device starts entering final ~20.5–21.0, fully framed ~21.0) —
  the transition, not the beat.
- Verified on frames: body-grip, face-close (Vane's eyes above the card band;
  cards cross lower face/mouth-chin only), tearful look-up, oscilloscope,
  wrist device "Poy counter" with waveform (fully framed, legible), monitor
  tail shot ("...VATION ERROR RATE: 0.03%").
- Weakest point: the VO-length tail adds a monitor shot after the device
  payoff (final ~22.3–22.99 picture, before the card) — the clip does not end
  exactly on the device. Middle-centre cards cross Vane's lower face during
  face-close shots (eyes never covered). The timing-caveat risk is retired by
  the exact-seek verification above.
- ⚠️ 2.5 s end card flag (deviation from ≥4.5 s default).

## C1 Unsolved — c15_c1_unsolved.mp4 — 26.47 s (picture 23.95 + card 2.5)

- Window: rendered from `unsolved_ep1.mov` cut 170–198 s, smart-reframe →
  845 frames, 28.02 s, probed clean. Final trim offset 2.0 s → source
  ~171.8–195.75; core 172–196 essentially intact (only the last ~0.25 s of the
  196 s edge is trimmed).
- Grade: contrast 1.12 / brightness −0.01 / saturation 1.08, per task.
- VO: `vo_c1_unsolved.mp3` whole. 23 cards (24 planned minus the gap below).
- Music: c2, +12.5 dB gain then 0.35 duck, tail trimmed (24.94 → 23.95).
- Loudnorm final: I −16.38, TP −1.07 (v1: −16.27/−0.96 → −0.1 dB fix).
- Card silence: −91.0/−91.0 (excluding seek sliver).
- Baked bans respected: no card duplicates any banned phrase at its moment.
  Deliberate GAP: no card for VO words "The cargo was untouched" (14.72–
  16.08 s) because the baked "the cargo was untouched" runs over the same
  span — cards resume at "But the lifeboat" (16.42 s). Near-misses kept with
  different wording/time: "Ten people sailed" vs baked "10 people in total
  bound for Genoa Italy" (baked ends final ~2 s, VO phrase ~9–10 s); "Every
  person gone" vs baked "every single person was gone"; "The ship was" /
  "Found drifting with" vs baked "the ship was intact".
- Verified on frames: rowing crew at 172 s, boarding party in the cabin,
  child's doll on the floor (final 12 s frame with card "Found drifting with"
  — doll detail legible, grade not crushing), provisions; end-card frame
  verified in a final.
- Weakest point: the saliency crop slices the left/right edges of full-width
  baked subtitles ("they found no one" → "hey found no one"; "child's toys…"
  → "hild's toys…") — inherent to 16:9→9:16 on wide subtitle lines; baked
  lines sit at the bottom, added cards middle-centre, so there is no
  overlap/duplication. Briggs never appears on screen in the window (absent
  hero — scout caveat).
- ⚠️ 2.5 s end card flag (deviation from ≥4.5 s default).

## Process notes (for the parent, not the viewer)

- First reframe round: B2/B4/B5 died mid-encode with BrokenPipeError (ffmpeg
  died while the script was piping; partial files had no moov atom and were
  discarded). C1 succeeded in the same round. No OOM evidence in the journal;
  likeliest cause is transient contention (several sibling agents encoding
  concurrently). A solo tracked retry was SIGTERM'd after ~60 s (cause
  unknown); a detached `setsid nohup` chain then completed all three cleanly
  (B5 exit 0, B4 exit 0, B2 exit 0, all probed).
- v1 true-peak readings (−0.96 to −1.00 dBTP) were within 0.04 dB of the −1 dB
  ceiling; the −0.1 dB audio-only fix brings all finals to −1.06…−1.10 dBTP
  with integrated loudness still ~−16 LUFS. Video streams are untouched by
  the fix (stream copy); v1 files are archived, not deleted.
- Durations run 0.01–0.03 s over picture+card nominal (concat frame rounding).
