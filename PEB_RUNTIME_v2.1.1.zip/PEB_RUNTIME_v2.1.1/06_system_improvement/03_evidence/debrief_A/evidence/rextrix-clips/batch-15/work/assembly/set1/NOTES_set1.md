# Batch-15 cinematic assembly — SET 1 notes (A1, A2, A3, A5, B1)

## Common spec applied to all 5

- Video: 1080x1920, 30fps, libx264 slow, CRF 16, yuv420p, faststart (all verified by ffprobe).
- Audio: AAC, 48kHz, encoded at `-b:a 192k` (measured stream averages 182.6–185.9k —
  native AAC ABR variance on mono sources; the encode parameter was 192k throughout).
  Audio is mono because every source (VO mp3s, stems) is mono; no channel was invented.
- Picture: existing graded windows only, trimmed from handle edges to the VO length
  (all trims inside the 2s handles; no payoff beat cut, no freeze/slow-mo padding).
  Windows probed video-only (no audio stream) — source drama audio is structurally
  absent, and finals carry only the VO + ducked-music mix.
- VO: whole, never cut internally. Timings for ASS cards came from faster-whisper
  (base) word timestamps run on the actual VO files. Where Whisper misheard, the card
  text uses the package monologue wording: A1 "want to" (not "wanna"), A5 "knight"
  (not "night"), B1 "sole surviving heir" (not "soul-surviving air").
- Music: no-vocals campaign stems only, ducked to x0.35 under VO throughout
  (VO is continuous, so constant duck). Short stems fade out over their final ~1.5s
  (never looped, never stretched); long stem trimmed at the tail. Every stem was
  loudnormed to -16 LUFS before ducking, so the duck ratio is consistent.
- Final mix: VO + ducked music, then the whole deliverable (VO + 2.5s silent card)
  loudnormed to ~-16 LUFS integrated, true peak ≤ -1 dB. Readings below are
  loudnorm measurements of the delivered files (not the intermediates).
- Cards: ASS, font file `~/.local/share/fonts/Montserrat-Bold.ttf`
  (fc-list family "Montserrat Thin", style Bold), Fontname "Montserrat Thin",
  Bold=-1, size 64, white, 4px black outline, Alignment=5 (middle-centre),
  max 3 words per event, phrase-whole chunks synced to VO phrases, verified on frames.
  Middle-centre follows this template's spec; the standing off-video caption-placement
  rule has no off-video area to use in a full-frame 9:16 clip.
- End card: END ONLY, exactly 2.5s = 75 frames in every clip (frame counts below),
  silent (card-section audio extracted to wav: max abs 0, RMS 0.0 in all 5).
  Source: first 2.5s of `batch-30/group-5/work/card_fixed.mp4`, verified on frames
  (0.5/1.25/2.0s) as the RexTrix logo + "Download the RexTrix app — link in bio",
  and the source file has no audio stream at all — the fallback pilot card was NOT needed.
- ⚠️ 2.5s-CARD FLAG (applies to every clip below): the 2.5s end-only card is this
  template's spec and a DEVIATION from the standing ≥4.5s end-card default,
  scoped to this batch only on the user's word via the template.
- Nothing was uploaded, published, submitted, or sent to anyone.

## Per-clip notes

### A1 Apocalypse — c15_a1_apocalypse.mp4 (26.30s, 789 frames)
- Window: `scouts/groupA/apocalypse_window.mp4` (26s, source 187–213s), trimmed
  start 1.50s / end 0.70s → 23.80s picture (VO length). VO: `vo/vo_a1_apocalypse.mp3`
  (23.80s, whole). Music: c1 (22.08s, shorter than VO) faded out over final 1.5s
  (fade starts 20.58s), padded to VO length.
- Loudnorm (delivered file): I -16.02, TP -1.49, LRA 2.4. Card silence: max abs 0, RMS 0.0.
- Verified on frames: window — gun standoff, baked "go if I die" at window ~6s,
  red-lit button-press face at window ~24s (payoff intact, faces legible, grade dark
  cinematic, not crushed); final — ASS "waits at" at 9.0s, bold white, middle-centre,
  synced to VO; end card frame at 25.0s shows logo + download wording.
  Baked bans respected: no ASS card duplicates "I know" / "go if i die" /
  "you reset press it" (final-timeline baked positions ~3.5–4.5s and ~5.5–6.5s carry
  unrelated cards "because every time" / "she wakes up").
- ⚠️ 2.5s-card flag: YES — this clip uses the template's 2.5s end-only card, NOT the ≥4.5s default.
- Weakest point: window opens mid-standoff, so the first ~2s lean on the VO for
  context; protagonist's spelled name remains unresolved, so the monologue (as
  packaged) avoids naming her.

### A2 Don't Feed — c15_a2_dontfeed.mp4 (25.10s, 753 frames)
- Window: `scouts/groupA/dontfeed_window.mp4` (26s, source 194–220s), trimmed
  start 1.90s / end 1.70s → 22.60s picture. VO: `vo/vo_a2_dontfeed.mp3` (22.60s, whole).
  Music: c2 (24.94s, longer than VO) trimmed at the tail to 22.60s, plus a 0.1s
  click-guard micro-fade at the cut only (disclosed; not a tail fade).
  c2 measured I -31.60 exactly as briefed — gained/normalised to -16 LUFS at
  assembly so it does not vanish under the duck (TP after gain -12.64, no clipping risk).
- Loudnorm (delivered file): I -16.12, TP -1.49, LRA 8.1. Card silence: max abs 0, RMS 0.0.
- Verified on frames: window — moth on phone at window ~13s, phone camera UI visible,
  no baked subtitle at that moment; final — ASS "But what it" at 11.30s, bold white,
  middle-centre, synced to VO; moth + phone legible.
  Baked bans respected: NO "hey little guy" card was created at all (the VO audio
  still says it; the card sequence jumps from "and says" to "and the creature" /
  "flies down" / "to him"). "what is that" does not appear in any card.
- ⚠️ 2.5s-card flag: YES — this clip uses the template's 2.5s end-only card, NOT the ≥4.5s default.
- Weakest point: the window's first ~6s (creature crouching/flying) are quiet before
  the man appears; the "hey little guy" beat has audio but deliberately no card.

### A3 Hell's Army — c15_a3_hellsarmy.mp4 (27.13s, 814 frames)
- Window: `scouts/groupA/hellsarmy_window.mp4` (26s, source 250–276s, vertical native),
  trimmed start 1.00s / end 0.39s → 24.61s picture (nominal; frame quantisation gives
  739 picture frames = 24.633s, i.e. +1 frame / +0.026s of silent picture after the VO
  ends — card itself is still exactly 75 frames). VO: `vo/vo_a3_hellsarmy.mp3`
  (24.61s, whole). Music: c3 (24.04s, shorter than VO) faded out over final 1.5s
  (fade starts 22.54s), padded to VO length.
- Loudnorm (delivered file): I -16.07, TP -1.49, LRA 3.1. Card silence: max abs 0, RMS 0.0.
- Verified on frames: window — banner-pole close-up + baked "so the dead have a
  banner again" at window ~13s, RexTrix watermark top-right; final — ASS
  "Now the valley" at 12.30s, middle-centre, with the baked banner line simultaneously
  visible bottom-centre. The two texts differ and sit in different positions, so this
  is NOT a doubled caption — but it is the busiest frame in the set (flagged honestly).
  No card sits over the top-right watermark at any checked frame.
  Baked bans respected: no card duplicates "you paid for 30 arrows with a memory"
  (not in the VO at all) or the full "so the dead have a banner again" line
  (the VO card "a banner again" at 5.36–6.20s is a different phrase at a different time).
- ⚠️ 2.5s-card flag: YES — this clip uses the template's 2.5s end-only card, NOT the ≥4.5s default.
- Weakest point: the simultaneous baked + ASS frame at ~12–14s (see above), and the
  window's first ~6s (tent/kneeling) are slow before the banner reveal.

### A5 Witch — c15_a5_witch.mp4 (26.45s, 794 frames)
- Window: `scouts/groupA/witch_window.mp4` (26s, source 238–264s, vertical native),
  trimmed start 1.50s / end 0.55s → 23.95s picture. VO: `vo/vo_a5_witch.mp3`
  (23.95s, whole). Music: c1 (22.08s, shorter than VO) faded out over final 1.5s
  (fade starts 20.58s), padded to VO length.
  HARD RULE KEPT: ONLY this window was used — the build's sole picture input is
  witch_window.mp4; no shot from elsewhere in the episode (outside 238–264s) appears.
- Loudnorm (delivered file): I -16.02, TP -1.43, LRA 6.7. Card silence: max abs 0, RMS 0.0.
- Verified on frames: window — red fire-tendril close-up at window ~24s (payoff
  intact), watermark top-right; final — ASS "of red fire" at 11.98s, middle-centre,
  beast-on-bridge + knight/witch legible, no baked subtitle at that moment.
  Baked bans respected: no card duplicates "what are you" (not in the VO) and no
  card is the exact line "kneel before the city" — the VO kneel phrase is chunked as
  "that she kneel" / "before the city", neither of which equals the baked line, and
  neither falls on the baked line's final-timeline position (~15.5s).
- ⚠️ 2.5s-card flag: YES — this clip uses the template's 2.5s end-only card, NOT the ≥4.5s default.
- Weakest point: the fire-ring payoff is a tight close-up at the very end of the
  window; the episode-level costuming risk flagged in the package sits entirely
  outside 238–264s and is NOT in this clip, but the parent still owns the
  show-level acceptability call.
- Process note: the first A5 build run was killed mid picture-encode when its
  background session was lost (orphaned 3.1MB partial file, no ffmpeg running).
  A5 was rebuilt cleanly from scratch and the delivered file passed all QC above;
  the partial file was overwritten by the rebuild.

### B1 After Divorce — c15_b1_afterdivorce.mp4 (26.14s, 784 frames)
- Window: `scouts/groupB/windows/after_divorce_window.mp4` (24s, source 97–121s),
  trimmed start 0.18s / end 0.18s → 23.64s picture. VO: `vo/vo_b1_afterdivorce.mp3`
  (23.64s, whole). Music: c1 (22.08s, shorter than VO) faded out over final 1.5s
  (fade starts 20.58s), padded to VO length.
  Window was already 1080x1920 (verified by ffprobe) — the source was 1080x1880
  and the window render already handled it (blur-pad in its render log), so no
  additional pad/scale was applied and nothing was stretched.
- Loudnorm (delivered file): I -16.03, TP -1.47, LRA 10.6. Card silence: max abs 0, RMS 0.0.
- Verified on frames: window — Victoria pressing the sealed document to the
  ex-husband's chest at window ~13s and face-to-face at ~20s (payoff intact,
  faces legible); final — ASS "and her accusers" at 11.82s, middle-centre, synced
  to VO; end card frame at 24.89s shows logo + download wording.
  Baked bans respected: no card duplicates "the seal number is personally filed by
  Mister Arthur" / "it is legally undeniable" / "five years for forging"
  (VO's "prison for forgery" card at 12.96–13.76s is a different phrase at a
  different time from the baked "five years for forging" at final ~17.8–20.8s).
- ⚠️ 2.5s-card flag: YES — this clip uses the template's 2.5s end-only card, NOT the ≥4.5s default.
- Weakest point: the window is a 4-shot montage including a brief rival-on-phone
  cut that momentarily leaves Victoria; mild bloodied-face makeup is visible in
  the face-to-face shots (makeup-level, as packaged).

## Work files (this set)

- `work/assembly/set1/make_ass.py` — ASS generator (asserts ≤3 words/event).
- `work/assembly/set1/cards_{a1,a2,a3,a5,b1}.ass` — the burned-in card files.
- `work/assembly/set1/build.sh` — full assembly pipeline (loudnorm → mix → picture → card → mux).
- `work/assembly/set1/qc.sh` + `qc_out.txt` — QC runs for a2/a3/a5/b1 (a1 QC run inline).
- `work/assembly/set1/frames_win/` — window verification frames; `frames_card/` — card source frames.
- `work/assembly/set1/qc_{a1,a2,a3,a5,b1}_{hook,mid,card}.png` — final verification frames.
- `work/assembly/set1/vo_{...}.json` — Whisper word timestamps for each VO.
- Intermediate `*_pic.mp4`, `*_card25.mp4`, `*_vid.mp4`, `*_mix_final.wav` etc. per clip.
- No clip was judged too weak to deliver: all 5 passed spec + decode + loudnorm +
  card-silence + frame checks. The honest weakest points are listed per clip above.
