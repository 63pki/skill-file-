# Execution script — Warning / addiction-loop voiceover template
## (Fast-paced, organic user-recommendation style)

## Template identity
First-person warning from a real user, not an ad. The joke is the warning itself:
"don't download this" = "you will not be able to stop." Campaign-compliant:
the campaign's own template family includes "DON'T DOWNLOAD REXTRIX UNLESS…",
so the addictive framing is sanctioned. Never add feature claims (no "free",
no "unlimited", no "earn money", no invented features).

## Voiceover master text (conversational, complete thoughts, ~60 words / ~22s)
> "Real warning. If you value your free time, do not download RexTrix before
> bed. I opened it for one quick game, and suddenly it was two in the morning.
> You type one sentence, and it builds you a game or a story you can actually
> play. It is that addictive. Link is in my bio, but don't say I didn't warn
> you."

Per-clip adaptation rule: keep the hook line and the payoff line intact. The
middle (what the app built) MUST describe the actual scene shown — swap in the
real game/story from the footage, never invent one. Sentences must resolve
grammatically; no fragments, no clipped thoughts.

## Edit rules
- Vertical 9:16, 1080x1920 30fps, H.264 slow CRF 16, yuv420p, AAC 192k.
- Picture cuts every 1.5–2s for momentum — BUT the voiceover track is NEVER
  cut. Cuts are picture-only; the VO runs continuous underneath. Never cut a
  spoken consonant. Keep a 0.15s silence buffer between sentences in the VO
  track (a gap in speech, not a picture cut).
- Original drama audio: SILENCED under voiceover (standing lesson — a source
  bed under VO is a defect). One music bed only, low, ducked under VO; royalty-
  free or campaign-footage stems only, never an unlicensed trending song.
- Text overlays: Montserrat Bold, white, 4px black outline, centered Y 50%,
  max 3 words per card, chunked at phrase boundaries, synced to VO phrases.
  Never duplicate a baked subtitle visible at the same moment; inspect baked
  text before cutting.
- End card: ≥4.5s at END ONLY (standing default — this template specifies no
  card length), real RexTrix logo + "Download the RexTrix app — link in bio",
  silent. The payoff line ("don't say I didn't warn you") must flow directly
  into the card — the card is the punchline landing, not a cold break.
- Audio: VO ~-16 LUFS integrated, true peak ≤ -1 dB. No clipping anywhere.

## Production method (per clip)
1. Pick a hook-first scene (strongest self-explanatory moment in 1–3s).
2. Write the clip's VO from the master text, swapping only the middle to match
   the real scene. Record via ElevenLabs "Hope" (signed in as engload23) or Fish
   Audio if credits return; verify the VO file (duration, no truncation) before
   cutting picture to it.
3. Cut picture to the VO (picture cuts on beats, never on words), lay phrase
   cards, silence source audio, duck music under VO, append the end card.
4. Independent QC (specs, decode, loudnorm, card silence, hook/mid/card frames,
   transcript vs VO, no doubles) → fix loop → honest note per clip.

## QC / honesty
No clip ships with a known unflagged defect. If the VO engine blocks, report
it — do not substitute a robotic TTS or a text-only version without flagging.
Never upload, publish, or submit. Ready-to-upload state only.
