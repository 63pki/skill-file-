# INDEPENDENT QC REPORT — Batch-15 cinematic SET 1 (A1, A2, A3, A5, B1)

**QC role:** independent verifier, NOT the builder. Every reading below was
reproduced from the delivered finals with fresh ffprobe/ffmpeg/Whisper runs;
builder files (NOTES_set1.md, cards_*.ass, build.sh, intermediates) were used
only as cross-references, never as evidence on their own.
**Finals examined (untouched — no edits, uploads, publishes, or submissions):**
`~/workspace/rextrix-clips/batch-15/finals/`
- c15_a1_apocalypse.mp4, c15_a2_dontfeed.mp4, c15_a3_hellsarmy.mp4,
  c15_a5_witch.mp4, c15_b1_afterdivorce.mp4

## VERDICTS — all 5 PASS, no fixes required

| Clip | Verdict | Duration (frames) | Card | Loudnorm I / TP |
|---|---|---|---|---|
| A1 Apocalypse | **PASS** | 26.300s (789 = 714 + 75) | 75 fr, end only, silent | -16.02 / -1.49 |
| A2 Don't Feed | **PASS** | 25.100s (753 = 678 + 75) | 75 fr, end only, silent | -16.12 / -1.49 |
| A3 Hell's Army | **PASS** | 27.133s (814 = 739 + 75) | 75 fr, end only, silent | -16.07 / -1.49 |
| A5 Witch | **PASS** | 26.467s (794 = 719 + 75) | 75 fr, end only, silent | -16.02 / -1.43 |
| B1 After Divorce | **PASS** | 26.141s container (784 = 709 + 75 video frames) | 75 fr, end only, silent | -16.03 / -1.47 |

Notes on the verdicts (none is a fail):
- The 2.5s end card is this template's own spec and a DEVIATION from the
  standing ≥4.5s default, scoped to this batch on the user's word via the
  template (flagged in the builder notes and repeated here for the parent).
  Judged against the template spec, all 5 pass; the deviation itself is the
  parent's call, not a QC defect in these files.
- A3's +1 frame and A5's duration rounding (see §9) are frame-quantisation
  effects, verified benign — the card is exactly 75 frames in every clip.
- Observations that are NOT fails are listed per clip in §8 (busiest frame,
  sliced baked subtitle tail, episode-level costuming call).

## 1. Specs (ffprobe + full decode, reproduced independently)

All 5: **1080x1920, 30/1 fps, H.264 High profile, yuv420p, level 50**;
exactly 2 streams (1 video + 1 AAC audio — no hidden second audio track).
`moov` is the 2nd top-level box (after `ftyp`) in all 5 = **faststart confirmed**.
Full `ffmpeg -f null -` decode: **OK, no errors, all 5**.

| Clip | Video bitrate | Frames (counted, nb_read_frames = nb_frames) | Container duration | Claim check |
|---|---|---|---|---|
| A1 | 6,402,496 | 789 | 26.300000 | claim 26.30s / 789 ✓ exact |
| A2 | 6,969,178 | 753 | 25.100000 | claim 25.10s / 753 ✓ exact |
| A3 | 8,365,543 | 814 | 27.133333 | claim 27.13s / 814 ✓ (27.1333 rounds to 27.13) |
| A5 | 8,390,036 | 794 | 26.466667 | claim 26.45s / 794 — frames ✓ exact; see §9 on the 0.012s rounding |
| B1 | 5,073,618 | 784 | 26.141000 | claim 26.14s / 784 ✓ (784/30 = 26.1333 video; +0.008s is AAC priming in container duration) |

## 2. Audio bitrate — encode parameter AND measured average (both reported)

- **Encode parameter evidence (read from build.sh, line 63):**
  final mux uses `-c:a aac -b:a 192k -ar 48000` for every clip.
- **Measured stream averages (ffprobe, reproduced):**

| Clip | Measured AAC bitrate | vs 192k target |
|---|---|---|
| A1 | 183,555 | -4.4% |
| A2 | 183,883 | -4.2% |
| A3 | 182,617 | -4.9% |
| A5 | 185,060 | -3.6% |
| B1 | 185,873 | -3.2% |

All audio: **AAC LC, 48 kHz, mono (1 channel)** — mono because every source
(VO mp3s, stems) is mono; no channel was invented.
**Judgement: PASS.** A measured average 3–5% below a 192k ABR target on mono
material is consistent with a 192k encode (the encoder does not pad to the
target); it is NOT consistent with a lower-bitrate encode — the prior failed
batch measured 91–149k, roughly half these values. Nothing here is
materially below 192k.

## 3. Loudnorm (ffmpeg loudnorm measure pass, reproduced independently)

Target: ~-16 LUFS integrated, true peak ≤ -1 dB. All pass.

| Clip | Integrated (I) | True peak (TP) | LRA | Threshold |
|---|---|---|---|---|
| A1 | -16.02 | -1.49 | 2.40 | -26.44 |
| A2 | -16.12 | -1.49 | 8.10 | -26.46 |
| A3 | -16.07 | -1.49 | 3.10 | -26.51 |
| A5 | -16.02 | -1.43 | 6.70 | -26.46 |
| B1 | -16.03 | -1.47 | 10.60 | -26.53 |

These reproduce the builder's claimed I/TP/LRA exactly (A1 -16.02/-1.49/2.4,
A2 -16.12/-1.49/8.1, A3 -16.07/-1.49/3.1, A5 -16.02/-1.43/6.7,
B1 -16.03/-1.47/10.6) — but they were re-measured, not copied.

## 4. End card — exactly 75 frames, END ONLY, silent, logo + wording visible

Frame arithmetic from the builder intermediates' header counts (independent
of the finals' totals) plus final frame counts:

| Clip | Picture frames (intermediate) | Card frames (intermediate) | Final total | Card start (frame-exact) |
|---|---|---|---|---|
| A1 | 714 (23.800s) | 75 (2.500s) | 789 | 23.8000s |
| A2 | 678 (22.600s) | 75 (2.500s) | 753 | 22.6000s |
| A3 | 739 (24.633s) | 75 (2.500s) | 814 | 24.6333s |
| A5 | 719 (23.967s) | 75 (2.500s) | 794 | 23.9667s |
| B1 | 709 (23.633s) | 75 (2.500s) | 784 | 23.6333s |

- **End only:** pre-card frames extracted just before each card start
  (A1 23.76s, A2 22.56s, A3 24.60s, A5 23.92s, B1 23.60s) are all picture,
  not card — A3's pre-card frame shows the bell-wagon procession. Hook and
  mid frames for all 5 are picture, never card. No ASS card event runs into
  the card section: last card event ends 0.33–0.39s before each VO ends.
- **Visible on frames:** card frames viewed for A1 (25.0s) and B1 (24.89s)
  show the RexTrix logo + "Download the RexTrix app — link in bio" (+
  "AI-generated Games & Stories" line). Card frames for A2/A3/A5/B1 are
  byte-identical PNGs (md5 ff7685cbacc0e66a4f03839e11fbed16); A1's differs
  only trivially (132,203 vs 132,172 bytes, same visual card, viewed).
- **Digitally silent (extracted from each final at its frame-exact card
  start, measured as PCM):** max_abs **0**, RMS **0.0** in all 5.
  Control: picture-section audio 10–11s is non-silent in all 5
  (RMS 3,686–5,734; max ~27.4–27.6k), so the silence is real, not a dead track.

## 5. Voiceover — whole and uncut; source drama audio absent

Method: local faster-whisper (base, CPU; wav-array route — direct file input
fails on the broken PyAV build) run on (a) each VO source mp3 and (b) each
final's mix over the VO duration. Both transcripts match the package
monologues sentence-for-sentence, including the closing "Link is in my bio"
in all 5. No sentence is missing or clipped in any final.

| Clip | Final-mix transcript vs package monologue |
|---|---|
| A1 | Full: "They call her the woman who has died three times … Link is in my bio." Whisper hears "wanna" for "want to" in the SOURCE too — the card correctly uses package wording "want to". |
| A2 | Full, incl. "and says, hey, little guy" in AUDIO (deliberately no card for it — see §7). |
| A3 | Full: "They call her the white-haired commander … which side she fights for … Link is in my bio." |
| A5 | Full. Whisper hears "night" for "knight" in source AND final — the card correctly uses "knight". |
| B1 | Full. Whisper hears "soul-surviving air" for "sole surviving heir" in source AND final — the card correctly uses "sole surviving heir". |

- **Source drama audio absent:** every picture window probes as video-only
  (single video stream, no audio); every final has exactly one audio stream.
  The final-mix transcripts contain ONLY the VO sentences — no second voice,
  no extra dialogue line, no lyric line. The ducked music bed does not clash:
  VO transcribes cleanly (language p = 1.000) through it in all 5.
- **Method limit, stated honestly:** the 0.35 duck ratio itself cannot be
  re-measured from the finished mix without the stems; what is verified is
  the audible result (single VO + bed, no competing voice, VO fully
  intelligible). The build pipeline's duck step (`volume=0.35` on the music)
  was read in build.sh and is consistent with that result.

## 6. Cards — style, word count, phrase-wholeness, sync

ASS style line (identical in all 5 card files): Fontname "Montserrat Thin",
Bold=-1 (i.e. Montserrat Bold via the Bold flag), size 64, white
(&H00FFFFFF), Outline 4, black outline (&HFF000000), Alignment 5
(middle-centre). This matches the template spec.
Word-count audit of every Dialogue event in all 5 ASS files: **max 3 words
per event, zero events over 3**. Cards are phrase-whole chunks of the
monologue (e.g. A1 "because every time" / "the world ends"; A3 "a banner
again"; B1 "sole surviving heir" / "now face prison" / "for forgery").
Frames checked at hook / mid / card for every clip (full-size unless noted):
- A1: hook 1.0s "the woman who" ✓; mid 9.0s "waits at" ✓ (as builder claimed);
  card 25.0s ✓.
- A2: hook 1.0s "moth in this" ✓; mid 11.30s "But what it" ✓; card 24.0s ✓.
- A3: hook 1.0s "the white-haired" ✓; mid/busy 12.30s "Now the valley" ✓;
  card 26.0s ✓.
- A5: hook 1.0s "the witch the" ✓; mid 11.98s "of red fire" ✓ (beast on bridge
  + knight/witch legible, no baked subtitle at that moment); card 25.20s ✓.
- B1: hook 1.0s "Victoria Pemberton" ✓; mid 11.82s "and her accusers" ✓
  (document-to-chest payoff legible); card 24.89s ✓.
All viewed cards are bold white, middle-centre, with black outline, and each
matches the VO phrase sounding at that time (cross-checked against the ASS
event times and the final transcripts).

## 7. Baked-ban compliance (frame + full ASS-text audit)

The ASS audit is global, not sampled: a case-insensitive grep of every card
file for every banned phrase returned **none** in all 5 clips. Frame checks
below confirm the simultaneous-text cases are different texts in different
positions, never doubles.

- **A1 — PASS.** No card duplicates "I know" / "go if i die" /
  "you reset press it" (grep: none). Frame at 4.0s: ASS "because every time"
  (centre) + baked "go if I die" (bottom-centre) — different texts, different
  positions, both legible; NOT a double. (Baked "I know" at source ~188s
  falls before the final's in-point of source 188.5s, so it is not in the clip.)
- **A2 — PASS.** NO "hey little guy" card exists at all (grep: none), and
  "what is that" appears in no card. The VO audio still says "hey, little
  guy" (transcript §5); the card sequence jumps from "and says" to
  "and the creature" / "flies down" / "to him" as the builder disclosed.
  Frame at 9.0s: ASS "and the creature" (centre) + baked "…e guy" tail
  (bottom-left) — the baked line is source text, not an added card, so the
  ban (no card duplicating it) holds. See observation §8 on the sliced tail.
- **A3 — PASS, with the disclosed busy frame judged.** No card duplicates
  "you paid for 30 arrows with a memory" (grep: none; phrase is not in the VO
  at all) or the full "so the dead have a banner again" (grep: none; the card
  "a banner again" at 5.36–6.20s is a different phrase at a different time).
  Frame at 12.30s viewed: ASS "Now the valley" (centre) + baked "so the dead
  have a banner again" (bottom-centre) — **different texts in different
  positions, both fully legible, key action (banner pole / armour) still
  legible. This is NOT a doubled caption** under the template rule (which
  bans duplicating a baked subtitle, not mere co-presence). It is the busiest
  frame in the set — noted, not failed. Hook frame 1.0s shows the same
  pattern with the other baked line: ASS "the white-haired" (centre) +
  baked "you paid for 30 arrows with a memory" (bottom) — again different
  texts, not a double. No card sits over the top-right RexTrix watermark on
  any checked frame.
- **A5 — PASS (incl. HARD window rule).** No card is the exact line
  "kneel before the city" (grep: none) and no card duplicates "what are you"
  (grep: none). The VO kneel phrase is chunked as "that she kneel" /
  "before the city", neither equalling the baked line, and neither falls on
  the baked line's final-timeline position (~15.5s). Frame at 15.5s viewed:
  ASS "and the bell" (centre) + baked "kneel before the city"
  (bottom-centre) — different texts, different positions, NOT a double.
  Hook frame 1.0s: ASS "the witch the" (centre) + baked "what are you"
  (bottom) — different texts, not a double.
  HARD RULE spot-check: final frames at 5.0s and 20.0s were compared against
  scouts/groupA/witch_window.mp4 at 6.5s and 21.5s (final + 1.50s trim offset)
  — identical shots (bell over chasm; witch with red fire arc), confirming
  picture comes from the 238–264s witch window at the claimed offset at both
  an early and a late point. No shot from outside that window was observed.
- **B1 — PASS.** No card duplicates "the seal number is personally filed by
  Mister Arthur" / "it is legally undeniable" / "five years for forging"
  (grep: none). The VO's "now face prison" / "for forgery" cards
  (11.92–13.76s) are a different phrase at a different time from the baked
  "five years for forging" (final ~17.8–20.8s). Frame at 19.0s viewed: ASS
  "to see what" (centre), face-to-face + sealed document legible, no baked
  subtitle visible at that exact moment and in any case no duplicate.

## 8. Grade legibility + per-clip observations

Grade on all viewed full-size frames: dark cinematic, high-contrast, faces
and key action legible in every clip — no crushing of faces or key action
into illegibility was observed (A1 red-haired woman / gun standoff, A2 moth +
phone camera UI, A3 banner-pole armour, A5 knight mask / beast / fire arc,
B1 judge + sealed document + face-to-face). No card covers a face at centre
in a way that hides the key action on checked frames; the top-right RexTrix
watermark is never covered by a card.

- **A1:** weakest point as disclosed — window opens mid-standoff, first ~2s
  lean on VO for context. Not a defect.
- **A2:** weakest point as disclosed — first ~6s are quiet creature shots
  before the man appears. Observation (not a fail): at 9.0s the baked
  "hey little guy" line is sliced at the frame edge ("…e guy") — a
  landscape-reframe artefact of the source window, not an added card, and
  not covered by any ban in this task. If the parent wants it tidier, the
  fix would be a window-level reframe decision, not a card fix.
- **A3:** busiest frame ~12.3s (see §7) — passes; first ~6s (tent/kneeling)
  are slow before the banner reveal, as disclosed.
- **A5:** fire-ring payoff is a tight close-up at the very end of the window,
  as disclosed. The episode-level costuming flag from the package sits
  entirely outside 238–264s and is NOT in this clip; the show-level
  acceptability call remains the parent's (out of QC scope). The in-window
  gown (plunging neckline, thigh slit, fully covering) is as the package
  described it.
- **B1:** 4-shot montage incl. a brief rival-on-phone cut, and mild
  bloodied-face makeup in the face-to-face shots — both as disclosed in the
  package; makeup-level, not gore.

## 9. Builder's disclosed quirks — independently verified and judged

- **A3 total 814 vs nominal 813 (+1 silent picture frame after VO ends;
  card still exactly 75): CONFIRMED and judged BENIGN — PASS.**
  VO ends 24.607313s; picture runs to 24.633333s (739 frames); card is
  exactly 75 frames after that; 739 + 75 = 814. The extra 0.026s window
  (24.6073–24.6333s) was extracted and measured: max_abs 0, RMS 0.0 —
  digitally silent, so there is no audio spill into the card boundary and
  no card-frame count error. Cause is frame quantisation of the 24.607313s
  VO length at 30 fps (24.607313 × 30 = 738.2 → 739 picture frames), not a
  mistimed card. No fix needed; do not "correct" the total to 813 by cutting
  a picture frame — that would change the picture/card boundary for no gain.
- **A5 duration rounding: NOTED, not a fail.** Builder notes say 26.45s;
  frame-exact total is 794 frames = 26.4667s (719 picture + 75 card).
  The 26.45s figure is VD + 2.5 (23.95425 + 2.5 = 26.45425) before the same
  frame quantisation (23.95425 × 30 = 718.6 → 719 picture frames). Frame
  count is the binding figure and matches the claim exactly (794).
- **A2 c2 stem gain (-31.60 LUFS as briefed, normalised at assembly):**
  cannot be re-verified from the finished mix alone; the finished clip's
  loudnorm (-16.12 / -1.49) and clean VO transcription are consistent with
  the disclosed treatment. No evidence of a problem.
- **A5 rebuild note (first run killed mid-encode, rebuilt from scratch):**
  no orphan/partial artefact in the delivered file — it decodes cleanly,
  counts exactly, and matches its window at two offsets. Nothing to fix.

## 10. Fixes required

**None.** No clip has a FAIL and no rebuild is needed for any of the 9
checks above. If the parent wants anything changed, it would be a preference
change, not a QC fix:
- (Optional, not required) A2's sliced baked-subtitle tail at ~9s could be
  revisited only with a window-level reframe decision.
- (Parent's call, not QC) the 2.5s-vs-≥4.5s end-card deviation and the A5
  show-level costuming acceptability.

## Methods & reproducibility

- ffprobe (streams, pix_fmt, profile, bitrate, duration, nb_frames,
  count_frames decode count), top-level box order for faststart, full
  `ffmpeg -f null -` decode, loudnorm measure pass, frame-exact card-start
  audio extraction + PCM max/RMS, ASS text/word-count/ban greps, ASS style
  line read, faster-whisper base transcripts of VO sources and final mixes,
  full-size frame viewing at hook/mid/card/ban/boundary positions, and
  window-vs-final frame comparison for A5. Builder intermediates were used
  only for the picture/card frame arithmetic cross-check.
- QC frame set extracted for this report (scratch, /tmp/qc1/frames):
  hook/mid/card/pre-card/ban frames per clip + A5 window comparisons +
  contact sheet of hooks. Finals were not modified.
