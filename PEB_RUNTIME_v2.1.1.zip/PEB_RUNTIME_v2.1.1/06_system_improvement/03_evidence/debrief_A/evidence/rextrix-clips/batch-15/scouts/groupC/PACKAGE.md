# Batch-15 Group C — scout packages (cinematic lore clips, VO BLOCKED)

Status: SCOUT + PACKAGE ONLY. No voiceover was recorded, faked, or substituted
(Fish Audio HTTP 402, credits exhausted; ElevenLabs needs a live browser session
a generic subagent cannot run). Final assembly (VO + ducked music + 2.5s end
card + QC) happens later by the parent. Nothing here is uploaded, published,
or submitted.

Downloads verified by BOTH bytes on disk AND ffprobe (dims/fps/duration).
THE UNSOLVED FILES was reused from the coordinator's in-progress download
once it completed (403,604,706 bytes, ffprobe-clean) — not re-downloaded.
All other files were downloaded via the Drive connector CLI only.
A VM restart mid-task killed the first download round; all four downloads
were relaunched from scratch and re-verified.

NO SHOW REJECTED. No Group C episode turned out to be romance/adult. All five
shows below are packaged. Two carry content flags the parent must see
(Reaper: mannequin nudity; Rat King: blood/horror) — flags are stated in
their packages, not hidden.

---

## 1. THE UNSOLVED FILES

- Source file: `~/workspace/rextrix-clips/batch-15/sources/unsolved_ep1.mov`
- Ep1 Drive file ID: `1CUCOUGaQYgO4KJxE84JHmLAQbspGHQsF`
- Probe: 1920x1080, 30 fps, 274.46 s, h264/aac, 403,604,706 bytes.
  LANDSCAPE — saliency reframe to 9:16 required at assembly (flagged).

### Chosen scene
- Window: in 172.0 s, out 196.0 s (24.0 s).
- What happens: the Mary Celeste segment's reveal. The Dei Gratia crew rows
  out to the drifting ship, climbs aboard by rope ladder, and walks an empty
  cabin: logbook open, a half-eaten meal on the table, a child's doll on the
  floor. The ship is intact; every person is gone.
- Character: Captain Benjamin Briggs. Trait: the experienced sailor who
  broke his own pattern and brought his family aboard this time.
- Visible evidence: baked subtitle + narration line "Captain Benjamin Briggs
  was an experienced sailor" (~154–159 s); "This time, he brought his wife
  and two-year-old daughter aboard" (~159–165 s) — the episode's own
  "this time" framing is the pattern-break evidence; "Ten people, in total,
  bound for Genoa, Italy" (~165–174 s); boarding + empty-cabin shots in
  the window itself (176–194 s).

### Monologue (66 words, est. ~24 s)
> "They call him Captain Benjamin Briggs, because this experienced sailor
> broke his own pattern and brought his wife and two-year-old daughter
> aboard. Ten people sailed for Genoa, and the ship was found drifting with
> every person gone. The cargo was untouched, but the lifeboat was missing.
> If you want to know why they left, the story is waiting inside the app.
> Link is in my bio."

### Transcript notes
- Language: English, Whisper p=1.000, 62 segments. Ep1 is an anthology:
  Dyatlov Pass (~0–140 s), then Mary Celeste (~142–274 s); the window is
  entirely inside the Mary Celeste segment.
- Key window lines (transcript): "When the crew of the Dei Gratia boarded
  her, they found no one" (174–179); "The ship was intact. The cargo was
  untouched. But every single person was gone" (180–188); "Their belongings
  were left behind. The child's toys. The captain's logbook" (188–197).
  (Whisper renders "Dei Gratia" as "day Gratia"; the baked subtitles read
  "Dei Gratia" — trust the frames.)
- Mid-sentence-cut risk: none inside the window; every window line resolves
  before 196 s. The next line ("Six months of food and water", 197–200 s)
  starts after the window closes.

### Baked-text notes (window)
- Bottom-centre white subtitles run almost continuously: "10 people in
  total bound for Genoa Italy" (tail to ~174 s); "when the crew of the Dei
  Gratia boarded her" (~174–180 s); "they found no one" (~180–182 s);
  "the ship was intact the cargo was untouched" (~182–188 s); "but every
  single person was gone" (~188–192 s); "their belongings were left behind"
  (~192–194 s); "the child's toys" (~194–196 s, edge).
- Added text cards must NOT duplicate those phrases at those moments;
  use different phrasing or time cards to the gaps.

### Family-safe verdict
- PASS. No gore, no sexual content, no bodies shown in the window. Deaths
  are implied only (a missing crew). The Dyatlov segment elsewhere mentions
  deaths but is outside the window. Eerie, not graphic.

### Music-bed pick
- c2 (quiet/sparse, 24.9 s) — matches the hushed empty-ship dread and
  covers the 24 s window without looping. c1/c3 (full dramatic) would
  overpower the quiet reveal.

### Picture window
- Cut 170–198 s (window + 2 s handles), graded, source audio stripped,
  NO end card, 1080x1920 30 fps CRF 16 via saliency reframe — NOT RENDERED
  (see Render status at the end of this file).

### Weakest point
- The hero (Briggs) never appears on screen in the window — he is the
  absent captain. Tension is carried by the boarding party's faces and the
  empty-cabin details, not by a hero close-up.
- 2.5s-END-CARD DEVIATION FLAG: this template uses a 2.5 s end card, NOT
  the standing ≥4.5 s default. Flagged per brief; applies to this batch
  only, on the user's word via the template.

---

## 2. DOG OF THE WEST

- Source file: `~/workspace/rextrix-clips/batch-15/sources/dog_ep1.mov`
- Ep1 Drive file ID: `1Z5-7OAy6LHR3j9K7ouQK-tMrpUejssQz`
- Probe: 1920x1080, 30 fps, 359.56 s, h264/aac, 544,923,377 bytes.
  LANDSCAPE — saliency reframe to 9:16 required at assembly (flagged).

### Chosen scene
- Window: in 58.0 s, out 80.0 s (22.0 s).
- What happens: the leap into the television. The owner stares, shocked,
  and shouts a warning; the brown-and-white house dog ignores him, leaps
  off the couch toward the TV, and the screen flips to "WELCOME TO THE
  WEST" — then the dog is running head-on through Monument Valley desert,
  tongue out, chasing the horizon.
- Character: the dog (no name is spoken or shown on screen — he is called
  only "the Dog of the West", from the show title, which is descriptive,
  not an invented name). Trait: the house dog who jumps into the western
  instead of staying safe on the couch.
- Visible evidence: owner shouting with baked subtitle "get down it's not
  safe" (~60 s); dog barking at a flying cowboy hat, then leaping at the
  TV (~62–66 s); "WELCOME TO THE WEST" title card on the TV (~68–70 s);
  dog running head-on through the desert (~72–80 s).

### Monologue (65 words, est. ~24 s)
> "They call him the Dog of the West, because when his owner shouts that
> it is not safe, he jumps into the television anyway. One leap, and he is
> running through the desert beside stagecoaches and outlaws. Now every
> ride could be his last. If you want to see where he runs next, the story
> is waiting inside the app. Link is in my bio."

### Transcript notes
- Language: visually English (baked subtitles); Whisper transcript is
  nearly empty — 112 of 114 segments are "." (music/SFX only), language
  forced "en" p=1.000. The only intelligible Whisper line is "Hey, that's
  mine" (349–355 s, final street scene).
- Whisper MISSED real dialogue that exists as baked subtitles in the
  coach scenes (e.g. "don't let him get the box", "are you serious right
  now", ~150–170 s; "well i'll be darned good dog", ~290 s). Do not quote
  the Whisper transcript as the episode's dialogue — use baked subtitles.
- Mid-sentence-cut risk: none in the window; the window carries no spoken
  dialogue at all (music/SFX only), so the new VO is the only voice.
- Ep1 context (verified on frames, outside the window): the dog guards a
  stagecoach box against a masked outlaw and riders; the box holds a map
  labelled "THE KING'S HAT" (~320–340 s). That is the source of the
  monologue's stakes line; it is ep1 evidence, not window evidence.

### Baked-text notes (window)
- "get down it's not safe" (~60 s, bottom-centre subtitle).
- "welcome" small subtitle + large baked title graphic "WELCOME TO THE
  WEST" on the TV (~68–70 s).
- Added cards must NOT duplicate "get down it's not safe" or "welcome to
  the west" at those moments.

### Family-safe verdict
- PASS. Comedic western action. Gunfire and bullet holes in coach glass
  appear later in ep1 (~110 s onward), but no blood is visible anywhere
  in the frames viewed (full 10 s sweep, 0–350 s). No sexual content, no
  romance/adult content.

### Music-bed pick
- "no stem fits — needs Audio Library track". All three stems are dark
  star-god drama scores; this is a sunny western adventure. Needs a
  western/adventure Audio Library track. Do not force c1/c2/c3 onto it.

### Picture window
- Cut 56–82 s (window + 2 s handles), graded, source audio stripped,
  NO end card, 1080x1920 30 fps CRF 16 via saliency reframe — NOT RENDERED
  (see Render status at the end of this file).

### Weakest point
- The window contains no spoken dialogue — the story is told purely
  visually, so the clip leans entirely on the new VO. The "outlaws" line
  rests on the masked outlaw on the train (~10 s) and coach chase
  (~120–230 s), both outside the window.
- 2.5s-END-CARD DEVIATION FLAG: this template uses a 2.5 s end card, NOT
  the standing ≥4.5 s default. Flagged per brief; applies to this batch
  only, on the user's word via the template.

---

## 3. Mutant Garden Fiesta

- Source file: `~/workspace/rextrix-clips/batch-15/sources/mutant_ep1.mov`
- Ep1 Drive file ID: `1kITCDDGGW8Wz0FNccSM_g6C_SKiypV7K`
- Probe: 1080x1920 (vertical native), 30 fps, 333.11 s, h264/aac,
  503,041,313 bytes. No reframe needed.

### Chosen scene
- Window: in 160.0 s, out 184.0 s (24.0 s).
- What happens: the garden braces for the giant glow spirit. The flower
  creatures line up at the garden gate, the young man and the curly-haired
  gardener look skyward, the gardener mixes a jug (stabilizer), and a boy
  cheers as the giant swirling glow spirit fills the sky over the garden.
- Character: the Gardener (descriptive only — no name is visually linked
  to him; the dialogue name "Cord" is spoken about someone who "messed up
  the formula", but no shot ties that name to the curly-haired man, so he
  is NOT called Cord here). Trait: he grows an army that fights for him
  instead of fighting giants himself.
- Visible evidence: flower creatures lined up at the gate (~164 s frame);
  "Flora units, form a gentle blocking line now" (transcript 166–168 s,
  and the same line as a baked subtitle later in ep1); giant glow spirit
  over the garden (~176–184 s frames); gardener mixing a jug and looking
  up worried (~168–176 s frames).

### Monologue (61 words, est. ~23 s)
> "They call him the Gardener, because he does not fight giants himself,
> he grows an army that lines up at his gate. At sunrise, a giant glow
> spirit drifts over his fence, and his flower soldiers form their
> blocking line. If you want to see whether the garden holds, the story
> is waiting inside the app. Link is in my bio."

### Transcript notes
- Language: English, Whisper p=1.000, 40 segments. Tone is comedy, not
  suspense: snacks/treats, "Cord really messed up the formula again"
  (repeated 3x), "Hey big glow spirit! Wanna try our honey treats?"
  (180–184 s).
- CAUTION: ep1 reprises shots and lines (the same "Cord" line and
  blocking-line shot recur later). The window above is anchored on
  dense-verified frames at 160–184 s, not on transcript times alone.
- Mid-sentence-cut risk: low. The window's baked line ("it's just a tiny
  fun mutation nothing serious", ~170 s) resolves inside the window.

### Baked-text notes (window)
- "it's just a tiny fun mutation nothing serious" (~170 s,
  bottom-centre). No other baked subtitles in the window.
- Added cards must NOT duplicate that phrase at that moment.

### Family-safe verdict
- PASS. Bright candy-coloured comedy. No gore, no sexual content. Notes
  for completeness: a blonde woman wears a crop top (~110 s, OUTSIDE the
  window); a young boy appears in the window cheering, clothed and
  non-sexualised. No romance/adult content.

### Music-bed pick
- "no stem fits — needs Audio Library track". The three stems are dark
  drama; this is upbeat whimsical comedy. Needs a light/whimsical Audio
  Library track. Do not force c1/c2/c3 onto it.

### Picture window
- Cut 158–186 s (window + 2 s handles), graded, source audio stripped,
  NO end card, 1080x1920 30 fps CRF 16 — NOT RENDERED (see Render status at
  the end of this file).

### Weakest point
- Tone mismatch with the cinematic-lore template: this is comedy, not
  suspense, and the window is a montage slice, not one continuous
  confrontation. The character also stays generic ("the Gardener")
  because "Cord" cannot be visually confirmed as him.
- 2.5s-END-CARD DEVIATION FLAG: this template uses a 2.5 s end card, NOT
  the standing ≥4.5 s default. Flagged per brief; applies to this batch
  only, on the user's word via the template.

---

## 4. The Reaper

- Source file: `~/workspace/rextrix-clips/batch-15/sources/reaper_ep1.mov`
- Ep1 Drive file ID: `1HChA0f2coftdqGnFLyXz-S4inuXOloKJ`
- Probe: 1080x1920 (vertical native), 30 fps, 325.80 s, h264/aac,
  490,128,087 bytes. No reframe needed.

### Chosen scene
- Window: in 144.0 s, out 166.0 s (22.0 s).
- What happens: the cracked shell in the forbidden room. In a dark red
  fleshy chamber, the chrome shell with a glowing gold crack across its
  face confronts a patrol of other shells; he drives a fist through a
  crackling energy barrier, and the patrol closes in as the wall text
  behind him reads like a warning the system tried to erase.
- Character: Reaper 0-9 ("Reaper Zero-Nine" spoken form). Trait: the one
  shell that remembers being someone — and remembering is forbidden.
- Visible evidence: gold crack across the shell's face in every window
  frame (dense-verified 144–160 s); "A crack means the shell remembers
  being someone" (transcript 30–33 s); "that the shell remembers is
  forbidden, anomaly-logged" (33–37 s); "I am not nine" (148–152 s);
  "Reaper 09. You are decommissioned. Return for reset" (159–164 s);
  "Reissued units who resist reset are erased, not corrected" (120–125 s).
  Note: the "I am not nine" / decommission lines are ep1 dialogue, not
  shots inside the window — the window shows the confrontation that
  follows from them.

### Monologue (64 words, est. ~24 s)
> "They call him Reaper Zero-Nine, because he is the one shell that
> remembers being someone, and remembering is forbidden. One crack across
> his face, and the system orders him back for reset. Now he must choose
> between forgetting everything or being erased for good. If you want to
> see what he chooses, the story is waiting inside the app. Link is in my
> bio."

### Transcript notes
- Language: English, Whisper p=1.000, 64 segments.
- CAUTION: ep1 reprises beats (the forbidden-room lines recur later in
  the episode). The window above is anchored on dense-verified frames at
  144–166 s, not on transcript times alone.
- Mid-sentence-cut risk: none in the window; baked lines resolve inside
  it ("we left because we were afraid" completes by ~152 s).

### Baked-text notes (window)
- "we left because we were afraid" (~144–152 s, bottom-centre, repeated
  across cuts).
- "you are in the place we agreed to forget" (~160–166 s, edge).
- Added cards must NOT duplicate those phrases at those moments.

### Family-safe verdict
- FLAG — FEATURELESS CHROME MANNEQUIN NUDITY. The shells are smooth,
  nude humanoid figures with NO genitalia detail and nothing sexual
  (mannequin-style), visible throughout ep1 including small full-figure
  shots in the window (e.g. the patrol wide shot). No blood, no sexual
  content, no sexualisation. Death/reset theme, no graphic violence in
  the window (energy-barrier effect only, no injury detail).
- Decision needed: the parent/user decides whether mannequin nudity
  clears the family-safe bar. The show is packaged, not hidden, with
  this flag attached.

### Music-bed pick
- c1 (22.1 s, full dramatic, I −17.6) — matches the crack, the
  confrontation, and the decommission threat beat-for-beat, and its
  length matches the 22 s window exactly.

### Picture window
- Cut 142–168 s (window + 2 s handles), graded, source audio stripped,
  NO end card, 1080x1920 30 fps CRF 16 — NOT RENDERED (see Render status at
  the end of this file).

### Weakest point
- The naming beat ("I am not nine") is ep1 dialogue, not a shot inside
  the window — the monologue's name claim rests on ep1-wide evidence,
  while the window itself sells the crack and the forbidden room
  visually. The nudity flag (above) is the other open item.
- 2.5s-END-CARD DEVIATION FLAG: this template uses a 2.5 s end card, NOT
  the standing ≥4.5 s default. Flagged per brief; applies to this batch
  only, on the user's word via the template.

---

## 5. The Rat King Arrives

- Source file: `~/workspace/rextrix-clips/batch-15/sources/ratking_ep1.mov`
- Ep1 Drive file ID: `16ruhgYLlfkGriaSCu1AcVuQ-sQ9eDqdM`
- Probe: 1080x1920 (vertical native), 30 fps, 283.17 s, h264/aac,
  425,916,297 bytes. No reframe needed.

### Chosen scene
- Window: in 65.0 s, out 87.0 s (22.0 s).
- What happens: the Piper calls the swarm. The masked piper — white
  plague mask, black feathered coat, bone flute — stands in a grand hall
  as rats mass across the floor; he raises the flute and plays at sunset
  while the swarm gathers around him and the hall fills.
- Character: the Piper (descriptive only — no name is spoken or shown;
  the crowned monster of the title, the Rat King, appears later in ep1
  and is NOT named as the piper). Trait: he does not chase the rats, he
  plays to them, and every note calls the swarm.
- Visible evidence: piper holding the bone flute in the hall (~65 s
  frame); rats massing across the hall floor (~67–70 s frames); piper
  playing the flute at sunset (~72 s frame); piper standing before a
  mound of rats in the hall (~75 s frame).

### Monologue (61 words, est. ~23 s)
> "They call him the Piper, because he does not chase the rats, he plays
> to them, and every note calls the swarm. One tune on his bone flute
> fills the hall with rats, and the swarm follows wherever he leads. If
> you want to see what he plays next, the story is waiting inside the
> app. Link is in my bio."

### Transcript notes
- Language: English, Whisper p=1.000, but only 16 segments, sparse and
  garbled (chant/music track — e.g. a repeated "rat man" chant at 0–52 s;
  "Fire! Fall back!" at 137–147 s). Do NOT rely on the transcript for
  this episode — the window is anchored on frames + baked subtitles.
- Mid-sentence-cut risk: low. The window's one baked line ("what is that
  what is that", ~72 s) resolves inside the window.

### Baked-text notes (window)
- "what is that what is that" (~72 s, bottom-centre).
- No other baked subtitles in the window.
- Added cards must NOT duplicate that phrase at that moment.

### Family-safe verdict
- FLAG — HORROR-FANTASY BLOOD. Visible blood in ep1: a bloodied hand on
  rubble (~60 s, OUTSIDE the window); blood on a wounded knight's armour
  (~100 s and ~260 s, OUTSIDE the window); the rat-swarm hall floors in
  the window (~67–75 s) show dark red fluid among the rats that reads as
  blood under the hall lighting (ambiguous at small size — verify at
  full size at assembly). The crowned Rat King creature itself is
  grotesque (fused-rat flesh mass, skull, glowing eyes) but is stylised
  fantasy, not realistic gore. No sexual content.
- Decision needed: the parent/user decides whether this clears the
  family-safe bar. The show is packaged, not hidden, with this flag
  attached. The window deliberately avoids the two explicit blood shots
  (60 s hand, 100 s/260 s knight).

### Music-bed pick
- c1 (22.1 s, full dramatic, I −17.6) — matches the swarm menace and the
  piper's reveal, and its length matches the 22 s window exactly.

### Picture window
- Cut 63–89 s (window + 2 s handles), graded, source audio stripped,
  NO end card, 1080x1920 30 fps CRF 16 — NOT RENDERED (see Render status at
  the end of this file).

### Weakest point
- The blood/horror flag above is the main risk: if the bar is "no blood
  at all", this show fails it and the window's rat-floor redness needs a
  full-size ruling at assembly. Secondary: the Rat King monster himself
  does not appear inside the window (he arrives later in ep1), so the
  title creature is sold by the swarm, not by his reveal.
- 2.5s-END-CARD DEVIATION FLAG: this template uses a 2.5 s end card, NOT
  the standing ≥4.5 s default. Flagged per brief; applies to this batch
  only, on the user's word via the template.

---

## Render status (picture windows)

- ALL FIVE: not rendered. Reason, stated honestly: the render queue was
  started (graded, audio-stripped, no end card, 1080x1920 30 fps CRF 16,
  slow preset), but the box is CPU-starved by concurrent agents' renders
  — a single 26 s Rat King window took 25+ minutes and still had not
  finished (only ~3:50 CPU time in 25 minutes wall). Per the brief
  ("if time runs short, the package alone is the deliverable — never
  sacrifice scout accuracy for renders"), the queue was killed and the
  partial file deleted rather than burn another hour on intermediates
  the final assembly will re-render anyway.
- Intended cuts (for assembly): Rat King 63–89 s; Mutant 158–186 s;
  Reaper 142–168 s; Unsolved 170–198 s (saliency reframe via
  smart-reframe); Dog 56–82 s (saliency reframe via smart-reframe).
  Grade: mild dark cinematic lift (contrast 1.12, brightness −0.01,
  saturation 1.08). Source audio STRIPPED. NO end card.

## No-copyright-characters check
- Unsolved: historical figures (Captain Benjamin Briggs, Mary Celeste) —
  public history, no fictional IP.
- Dog: generic western figures (dog, stagecoach driver, masked outlaw) —
  no identifiable copyrighted character; "WELCOME TO THE WEST" is a
  generic title card.
- Mutant: original garden creatures — no known IP.
- Reaper: original chrome-shell sci-fi figures — no known IP.
- Rat King: original piper/monster figures (plague-mask piper is a generic
  archetype, not a named IP character) — no known IP.
