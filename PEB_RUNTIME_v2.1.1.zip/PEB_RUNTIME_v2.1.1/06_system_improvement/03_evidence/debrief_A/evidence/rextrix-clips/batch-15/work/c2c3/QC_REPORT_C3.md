# QC REPORT — c15_c3_mutant (Mutant Garden)
Self-QC by the assembly subagent, 2026-10-30. Parent verification still required.

## File
- `~/workspace/rextrix-clips/batch-15/finals/c15_c3_mutant.mp4`
- 26.5s total = 24.0s content + 2.5s end card (795 frames = 720 + 75)
- 1080×1920, 30fps, H.264 slow CRF 16, yuv420p, AAC 192k @ 48kHz stereo, faststart (moov before mdat) — PASS
- Null decode: OK

## Content
- Picture: vertical-native source 160–176s (16s, normal) + 176–184s (8s, slow push 100% → 95% width, per-frame crop, no jitter at sampled points). No reframe (source already 1080×1920).
- VO: vo_c3_mutant.mp3, 20.77s, UNCUT, offset +0.5s (last word ends 21.27; 2.73s spirit-payoff tail before card).
- Music: "Silly Snickerdoodle" (YouTube Audio Library, no attribution required), ducked 0.35 under VO throughout, 0.5s tail fade into the card join.
- Source audio: silenced under VO.
- SFX (synthesized with ffmpeg, gain 0.12 in mix — no verified licensed library found on disk; see build notes): chime at clip 16.0s (spirit reveal). Ducked low, never competing.
- End card: first 2.5s of batch-30 group-5 card source — logo + "Download the RexTrix app — link in bio" + "AI-generated Games & Stories", verified on frames, video-only.
- Character: "the Gardener" is descriptive only — the dialogue name "Cord" is NOT visually linked to him in-window, so he is never called Cord.

## Measurements (own, per CLIP_RULES §6 methods)
- Content-only audio bitrate: 194.6 kbps (packet bytes, pts < 24.0) — PASS (the QC script's packet parser initially read ffprobe's columns in the wrong order and returned 0.0; parser fixed to handle both orders, figure re-measured).
- Loudnorm, content section (atrim): I −16.26 LUFS (gate ~−16 ±1), oversampled stereo TP −2.50 dB (gate ≤−1.05) — PASS
- Whole-file loudnorm: I −16.02, TP −2.50 — PASS
- Card silence: mix-side card is exact PCM zero (120,000 samples, max_abs 0). Final AAC-decoded card: 29/120,000 samples at ±1 LSB (−96.3 dBFS) — AAC codec noise floor, inaudible; equivalent to the prior batch's accepted −91 dB volumedetect observation. PASS with this note.
- Card frames: exactly 75 (795 total − 720 picture) — PASS

## Cards (ASS, Montserrat Bold, middle-centre, phrase chunks)
- 21 events, no overlaps, first 0.50, last ends 20.90. All events ≤3 words.
- No card uses the baked "tiny fun mutation" wording. "a giant glow" ends at 10.00 where the baked line sits — different text, middle vs bottom position — not a double.

## Frame checks (final file)
- 0.5s: garden-gate arch wide, "They call him" card — hook is the garden, not a face (differs from C2's opener by design).
- 10.0s: added "spirit drifts" (middle) + baked "it's just a tiny fun mutation nothing serious" (bottom, large) coexisting — different text, different position, no overlap. Per the C1 precedent (baked bottom vs cards middle-centre), this is NOT a double. Disclosed: the baked line persists ~10.0–12.5s (present at 12.0, gone at 13.0), so the dual-text window is ~2.5s; the baked line is the larger text block in those frames.
- 11.0s / 12.0s: mixing jars / gardener mixing + baked line still present; added cards "over his fence" (11.0) / none (12.0, planned gap) — correct.
- 13.0s: gardener looking skyward + "flower soldiers" card, baked line gone — clean.
- 16.5s: spirit reveal — giant glow spirit over garden, boy cheering at gate, "the garden holds" card — payoff lands on the chime.
- 23.0s: boy close-up looking up, gardener behind, no card — reaction held past the line (tail payoff).
- 25.5s: end card, logo + wording verified.

## Human-edit feel (§10)
- Opener: wide garden visual first (not face-first — differs from C2). Slow build: lineup → mixing → skyward look held 1–2s BEFORE the spirit reveal (pattern interrupt: reaction precedes the reveal) → spirit payoff with tail room. One slow push on the payoff (the clip's single push).
- Short audio fades at joins; no hard clicks (audio is continuous VO + continuous music bed).

## Weakest point (honest)
- Tone mismatch with the suspense template, as scouted: this is a bright candy comedy montage, not a suspense beat, and the character name is generic ("the Gardener"). The clip works as whimsy, not tension.
- The ~2.5s dual-text window (baked line + added cards, clip ~10–12.5s) is the busiest visual stretch; it passes the doubling rule as written but a strict "one text block at a time" bar would fail those frames.

## Verdict: SELF-QC PASS (all gates met; flags above disclosed, none a ledger fail)
