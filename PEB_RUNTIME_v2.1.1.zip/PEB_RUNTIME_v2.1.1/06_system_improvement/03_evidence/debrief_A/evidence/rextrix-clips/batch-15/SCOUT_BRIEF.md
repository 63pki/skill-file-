# Batch-15 scout brief — cinematic lore clips (VO BLOCKED: scout + package, do not finalize)
## Status (2026-10-29 ~16:30 PKT)
- Fish Audio: HTTP 402 Payment Required, re-confirmed by test call — credits
  exhausted, NOT a key problem. Do NOT retry Fish repeatedly.
- ElevenLabs "Hope" needs a live browser session (engload23) — generic
  subagents CANNOT do browser work. Do NOT attempt browser tasks, sign-ins,
  or any other TTS substitution. No voiceover is faked, borrowed, or swapped
  in silently.
- Therefore this phase delivers SCOUT PACKAGES + (if time permits) graded
  picture windows WITHOUT final VO mix. Final assembly (VO + ducked music +
  2.5s end card + QC) happens the moment a VO engine unblocks. The parent
  owns the ElevenLabs browser step.
- Execution script (rules stand): /home/hatch/workspace/rextrix-clips/batch-15/EXECUTION_SCRIPT_CINEMATIC.md

## Assignments (one clip per show, 15 shows, no show twice)
- Group A: The Apocalypse Repeats Through My Death | DON'T FEED THE ANIMALS |
  I Raised Hell's Army | Crow-Ash Orphanage | The Witch Beneath the Gallows
- Group B: After Divorce Turns Out She's a Hidden Heiress | PRIMAL MACHINES |
  Human Reserve Prequel-Adrift | Human Reserve - Redundancy | ZEROED: Human Preserve
- Group C: THE UNSOLVED FILES | DOG OF THE WEST | Mutant Garden Fiesta |
  The Reaper | The Rat King Arrives
- Episode-1 file IDs: see the coordinator's handoff (children/*.json in
  ~/workspace/rextrix-clips/drive-survey/). Download via the Drive connector
  CLI ONLY: /opt/hatch/bin/hatch_gws_cli drive files get --params
  '{"fileId":"<id>","alt":"media"}' --output <absolute path under home>.
  Tool-confirm every download: bytes on disk ≈ Drive size AND ffprobe reads
  dims/fps/duration. A click/claim without both is NOT a download.
- NEVER cut from: excluded shows (adult/romance list in
  ~/workspace/rextrix-clips/drive-survey/INVENTORY.md), empty folders,
  Swapped at Birth (T2 hunt only), the 30-batch's group-1 scenes, or any
  already-uploaded clip's exact scene.

## Per-show scout steps
1. Download ep1, probe (dims, fps, duration, codec). Note landscape vs
   vertical; landscape will need saliency reframe at assembly — flag it.
2. Full Whisper transcript (local faster-whisper via ffmpeg 16kHz mono wav;
   PyAV av.open is broken — use the ffmpeg route). Note language confidence.
3. Frames every 10s + at candidate moments, viewed at full size.
4. Pick ONE character-driven tension moment: a face, a choice, a reveal —
   NOT a generic action shot. The moment must support a ~18–22s picture
   window that can carry a ~22s monologue. Record exact in/out timestamps.
5. Verify before packaging: English-only; family-safe (flag blood/gore/
   sexual content honestly — skip graphic material, do not sanitize by
   hiding it in the note); baked text/subtitles inspected (added cards must
   never duplicate concurrent baked text); no copyrighted characters; no
   adult/romance content even if the title sounded safe (titles alone never
   green-light a clip — if ep1 turns out to be romance/adult, REJECT the
   show and say so, do not force a clip).
6. Write the clip's monologue from the master text (script file §Voiceover
   master text): structure name → rule-breaking trait → inciting sentence →
   stakes → invitation ("story is waiting inside the app. Link is in my
   bio."). ~60 words. EVERY sentence grammatically resolves. Character and
   trait must be REAL — described only by what the scene actually shows.
   Never invent names, powers, or plot points. Quote the scene evidence
   (line/shot) for each invented-looking claim.
7. Music-bed suggestion: pick the best-fit edit-3 no-vocals stem
   (~/workspace/rextrix-clips/new-batch-7/edit-3/stemwork/*/htdemucs/*/no_vocals.wav)
   by tone, or flag "no stem fits — needs Audio Library track". Never an
   unlicensed trending song.
8. If time permits AFTER all 5 shows are scouted: cut a graded picture
   window (dark cinematic high-contrast, faces/action legible on full-size
   frames; source audio STRIPPED; NO end card yet; 1080x1920 30fps, CRF 16)
   sized to the monologue estimate + 2s handles each side. If time runs
   short, the package alone is the deliverable — never sacrifice scout
   accuracy for renders.

## Per-show package (deliver exactly this, no more, no less)
- Show, source file, probe line, ep1 Drive file ID.
- Chosen scene: in/out timestamps, what happens, character name + trait +
  the visible evidence for both.
- Monologue text (full, ~60 words).
- Transcript notes: language, key lines, any mid-sentence-cut risk in window.
- Baked-text notes: what baked text exists in the window and when.
- Family-safe verdict + any gore/violence/sexual flag.
- Music-bed pick or "needs Audio Library track".
- Picture-window file path if rendered, or "not rendered".
- Honest weakest point + 2.5s-end-card deviation flag (this template uses
  2.5s, NOT the standing ≥4.5s default — flag it in every package).
