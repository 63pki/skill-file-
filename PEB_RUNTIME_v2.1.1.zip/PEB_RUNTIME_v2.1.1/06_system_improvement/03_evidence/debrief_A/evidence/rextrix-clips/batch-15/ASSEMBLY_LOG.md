# Batch-15 assembly log (coordinator)

## Inputs verified by coordinator before fan-out
- Execution script + Group A/B/C packages read in full.
- All 15 VOs on disk in batch-15/vo/ (durations 19-25s; the 10 for this batch:
  A1 23.80, A2 22.60, A3 24.61, A5 23.95, B1 23.64, B2 24.45, B3 23.33,
  B4 23.07, B5 22.99, C1 23.95).
- Windows: groupA 5/5 on disk; groupB after_divorce/primal/adrift on disk,
  redundancy_window.mp4 CORRUPT (moov not found, verified) — must re-render.
- GroupC windows not rendered — C1 must be rendered from source.
- End card: first 2.5s of batch-30/group-5/work/card_fixed.mp4 (4.5s card),
  builders must verify logo + download wording + silence on frames first,
  fallback = pilot v3 final card section.
- Font: ~/.local/share/fonts/Montserrat-Bold.ttf present; ffmpeg present.
- Music: c1/c2/c3 no-vocals stems in edit-3/stemwork (c2 I -31.6, needs gain).

## Batch scope (parent task)
ASSEMBLE ONLY (10): A1, A2, A3, A5, B1, B2, B3, B4, B5, C1.
HELD (do not assemble): A4 Crow-Ash, C4 Reaper, C5 Rat King (family-safe
rulings pending); C2 Dog, C3 Mutant (no fitting stem; need Audio Library
tracks — do NOT force dark stems onto them).

## Builders (spawned, one level)
- Set 1: A1, A2, A3, A5, B1 (all windows on disk; trim-only).
- Set 2: B2, B3, B4, B5, C1 (includes 3 renders: B2 extension, B4 re-render,
  B5 render, C1 render — 4 render jobs counting B2's extension).
- Known edge cases briefed: B2 VO (24.45s) LONGER than existing 24s window —
  extend source cut, never freeze/slow-mo, never bleed VO into card; B5
  ZEROED timing caveat (confirm 184-204s by direct play/exact-seek only);
  B4 corrupt window (do not trust); B3 two-shot reframe must hold both
  faces; C1 continuous baked subs (cards in gaps/different phrasing only);
  c1/c3 stems shorter than several VOs (fade-out tail, never loop);
  AAC 192k @ 48kHz explicit (prior batch failed QC on bitrate alone).

## Next
- Independent QC agents (different from builders) per set once delivered,
  then fix loop, then delivery to parent in groups with per-clip notes.
- No uploads, publishes, submits, or contacts at any stage.

## Set 1 delivered by builder (coordinator verified files on disk)
- Finals in batch-15/finals/: c15_a1_apocalypse.mp4 (26.30s), c15_a2_dontfeed.mp4
  (25.10s), c15_a3_hellsarmy.mp4 (27.13s), c15_a5_witch.mp4 (26.47s),
  c15_b1_afterdivorce.mp4 (26.14s) — all 1080x1920 30fps H.264 + AAC, durations
  match builder claims on probe. Notes: work/assembly/set1/NOTES_set1.md.
- Builder-claimed readings: I -16.02 to -16.12, TP -1.43 to -1.49; card exactly
  75 frames end-only + silent; AAC encode 192k @ 48kHz with measured stream
  averages 182.6-185.9k (ABR variance on mono, per builder — QC to judge).
- Disclosed quirks for QC: A3 814 vs nominal 813 frames (+1 silent picture
  frame, card still 75); A3 busy frame ~12.3s (ASS + baked simultaneously,
  different texts/positions); A2 deliberately has no "hey little guy" card;
  A5 rebuilt cleanly after a killed first run.
- Independent QC agent spawned for set 1 (verifies from scratch, incl. bitrate
  encode-vs-measured judgment, baked bans, Witch confinement, card silence).
- Set 2 builder still running at last check.
- SET 1 QC PASSED (independent, all 5, no fixes required):
  report work/assembly/set1/QC_REPORT_set1.md. Reproduced from scratch:
  1080x1920 30fps H.264 yuv420p faststart, decode clean, frame counts exact;
  AAC 192k encode parameter verified in build.sh, measured averages
  182.6-185.9k (ABR variance on mono, far above prior fail band 91-149k);
  loudnorm I -16.02 to -16.12 / TP -1.43 to -1.49 reproduced exactly; end
  card exactly 75 frames end-only + digitally silent in all 5; VO transcripts
  match package monologues sentence-for-sentence; ASS Montserrat Bold white
  4px outline middle-centre, max 3 words/event, zero banned-phrase hits;
  simultaneous-text frames judged NOT doubles (different texts/positions);
  A5 picture confirmed from the 238-264s window at early + late points.
  Quirks judged benign: A3 +1 silent picture frame (card still exactly 75);
  A5 duration 26.4667s frame-exact. Method limit noted: 0.35 duck ratio
  cannot be re-measured from a finished mix without stems (result consistent).
- NOTE: set 2 partial finals (b2_primal, b3_adrift) already visible in finals/
  but NOT delivered — builder has not reported and no QC has run on them.
- SET 2 BUILDER REPORTED (all 5 built, self-QC claimed):
  c15_b2_primal.mp4 (26.97s), c15_b3_adrift.mp4 (25.83s),
  c15_b4_redundancy.mp4 (25.60s), c15_b5_zeroed.mp4 (25.50s),
  c15_c1_unsolved.mp4 (26.47s) — coordinator verified all 5 on disk with
  durations matching claims, 1080x1920 30fps H.264 + AAC. Notes:
  work/assembly/set2/NOTES_set2.md.
- Builder-claimed readings: I -16.28 to -16.50, TP -1.00 to -1.10 (after a
  -0.1 dB audio-only fix, video untouched, v1 archived); AAC 192k encode,
  main-section averages 200-205 kbps; card exactly 2.5s end-only, claimed
  -91.0 dB mean on extracted tails (vs set 1's digital silence — QC must
  resolve precisely); c2 gained +12.5 dB before ducking; short stems faded
  (never looped); B2 re-cut 126-152s saliency-reframed; B3 existing window
  kept (both faces held); B4 re-rendered from source 86-110s (corrupt window
  not used); B5 rendered 182-206s via exact-seek confirmation; C1 rendered
  via smart-reframe at grade 1.12/-0.01/1.08.
- Disclosed quirks for QC: B3 TP exactly -1.00 (boundary — judge strictly);
  B3 letterboxed picture (vs four full-frame); B4 Voss out of frame final
  ~8.5s; B5 VO tail adds monitor shot after device payoff, ~0.3s "App."
  may overlap device entrance transition; C1 subtitle edge-slicing
  ("they found no one" -> "hey found no one"); B2 cards cross snout/jaw
  (eyes claimed uncovered); first reframe round failed (BrokenPipe, partial
  files discarded) + one tracked retry SIGTERM'd under contention.
- Independent QC agent spawned for set 2 (verifies from scratch, incl. TP
  boundary, card-silence precision, letterbox judgment, baked bans).
- SET 2 QC COMPLETE: B2 PASS, B3 FAIL (2 defects), B4 PASS (flagged
  weakness), B5 PASS (flagged blemish), C1 PASS.
  Report work/assembly/set2/QC_REPORT_set2.md (verified on disk by
  coordinator; verdicts match QC handoff).
  Reproduced: all 1080x1920 30fps H.264 yuv420p faststart, decode clean,
  frame counts exact; AAC 192k encode confirmed, main-section averages
  202-207 kbps (whole-file 183-188, diluted by silent card); loudnorm
  B2 -16.31/-1.06, B3 -16.47/-1.00, B4 -16.28/-1.10, B5 -16.50/-1.10,
  C1 -16.38/-1.07; card exactly 75 frames end-only on all 5; card silence
  PASSES on all 5 (continuous decode: B2/B3/B4 exact digital zero from
  first card sample; B5/C1 one 10ms bin at -84.3/-80.8 dBFS then exact zero
  for 2.49s; -sseof seek artefacts disproven, not fade tails); VO whole
  and uncut on all 5; cards Montserrat Bold white 4px outline
  middle-centre, max 3 words/event.
  B3 FAILS: (1) true peak -0.9903 dBFS at 4x oversampling, ~0.01 dB OVER
  TP ≤ -1 dB (ffmpeg's -1.00 at 2 decimals cannot distinguish); fix =
  -0.1 dB audio-only gain + remux, re-measure to ≤ -1.05. (2) LETTERBOX
  picture: band 1080x608 (y 656-1264), ~66% of canvas black — container
  is 1080x1920 but picture is not a full-frame reframe; fix needs PARENT
  DECISION: explicitly accept the letterbox (only way to hold both faces)
  or re-render a tracked 9:16 reframe (losing the simultaneous two-shot).
  B4 flagged (not failed): accusation beat one-sided, robot woman only at
  ~8.5s, Voss out of frame — reads via her face + baked line, Voss's
  reaction absent. B5 flagged blemish (not failed): "App." card
  (21.07-21.26s) sits over the fully-framed device at 21.15s (not covering
  the "Poy counter" words); optional fix = drop that card. C1: gap
  verified (no card 14.08-16.42s, resumes at "But the lifeboat"); sliced
  baked lines are reframe artefacts, not doubles.
- FINAL STATE: 9/10 assembled + QC-passed and delivered; B3 BLOCKED pending
  parent decision (letterbox accept vs full-frame re-render) + TP fix.
  Held (never assembled): A4 Crow-Ash, C4 Reaper, C5 Rat King (family-safe
  rulings pending); C2 Dog, C3 Mutant (need Audio Library tracks).

## PARENT VERIFICATION + DELIVERY — C2 Dog + C3 Mutant (2026-10-30 ~03:10–03:15 PKT)
- Parent independently reproduced every builder gate (not trusted): C2 1080x1920/30fps/H.264, AAC 48kHz stereo, 24.0s/720fr, content-only 198.3 kbps, loudnorm atrim I -16.04/TP -3.58, null decode OK, moov before mdat (faststart), card PCM max ±1 LSB; C3 same format, 26.5s/795fr, 194.6 kbps, I -16.26/TP -2.50, decode OK, faststart, card PCM max ±1 LSB. ASS re-parsed: C2 16 events (only "DOG OF THE WEST" over 3 words — proper-name exception, disclosed); C3 21 events, none over 3. Frames viewed by parent: C2 desert clean at 12.1s (no sliced title), C2/C3 cards clean with logo + download wording; C3 spirit reveal at 16.5s with "the garden holds" card, no doubling in frame.
- LIMIT (stated, not hidden): transcript re-verification impossible in-env — faster-whisper broken (av metadata_errors incompatibility, same as G2 QC precedent), no openai-whisper installed. VO verification rests on builder VO measurements + independently verified ASS texts + frame checks.
- VERDICT: both PASS, parent-verified. DELIVERED to user as the last 2 cinematic clips (12/15 delivered; A4/C4/C5 remain held for family-safe rulings).
- CAMPAIGN PAUSED: C2/C3 delivered READY-TO-UPLOAD ONLY — do NOT upload/submit while the RexTrix campaign is paused (same hold as batch-30 group 1), unless the user directs otherwise.
- Disclosed flags carried (not fails): C2 owner face absent in opening (appears ~9–10s); C3 dual-text window ~2.5s (busiest stretch, passes per C1 precedent); SFX are original ffmpeg-synthesized accents (no verified licensed SFX library found on disk), ducked low.
