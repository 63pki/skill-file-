# Queue — warning-template batch (user decision 2026-10-29 ~16:42 PKT)

Sequence: the 15 cinematic lore clips run FIRST. The warning-template batch
runs AFTER the 15 complete — NOT mixed into the 15.

Execution script (ready): EXECUTION_SCRIPT_WARNING.md in this directory.
Spec: first-person warning voiceover, picture cuts every 1.5–2s with the VO
track never cut (0.15s buffers between sentences), source audio silenced under
VO, end card ≥4.5s at end only (this template specifies no card length, so
the standing default applies).

Count: NOT yet specified by the user. Confirm the count when the 15 land
(or earlier if the user says). Do not assume 15.

Trigger: when the 15-clip cinematic batch is delivered, launch the warning
batch as its own coordinator with this script, then confirm the count with
the user before cutting.
