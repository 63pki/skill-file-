# Batch-15 Group A — scout packages (cinematic lore clips)

VO IS BLOCKED — scout + graded picture window only, no voiceover recorded or faked.
Fish Audio: HTTP 402 (credits exhausted). Generic subagents cannot use a browser
(ElevenLabs). Final assembly (VO + ducked music + 2.5s end card + QC) happens later
by the parent. Source audio is STRIPPED in all picture windows; NO end card is
appended yet. All windows are 1080x1920, 30fps, H.264 slow CRF 16, yuv420p, no audio.

⚠️ 2.5s-END-CARD DEVIATION FLAG (applies to every package below): this template
specifies a 2.5s end-only card, which DEVIATES from the standing ≥4.5s end-card
default. The deviation is scoped to this batch only, on the user's word via the
template. Final assembly must append the 2.5s card, not the ≥4.5s default.

Downloads (all tool-confirmed: bytes on disk = Drive size AND ffprobe reads
dims/fps/duration):
- apocalypse_ep1.mov — 608,789,596 bytes, 1920x1080, 30fps, 406.2s
- dontfeed_ep1.mov — 595,649,144 bytes, 1920x1080, 30fps, 396.9s
- hellsarmy_ep1.mov — 505,835,827 bytes, 1080x1920, 30fps, 336.9s
- crowash_ep1.mov — 631,300,972 bytes, 1920x1080, 30fps, 419.4s
- witch_ep1.mov — 459,819,225 bytes, 1080x1920, 30fps, 307.2s
Prior Group A progress reused: NONE usable — the previous apocalypse download was
truncated (188MB, no moov atom) and scouts/groupA/ was empty, so all 5 episodes
were re-downloaded fresh. No duplicate downloads were left running.
Transcripts: local faster-whisper (base, CPU), ffmpeg 16kHz mono wav route.
All 5 episodes: language English, probability 1.000.
No show was rejected: none of the 5 episodes is romance/adult. Content flags
below are honest and window-scoped.

---

## 1. The Apocalypse Repeats Through My Death

- Show: The Apocalypse Repeats Through My Death
- Source file: ~/workspace/rextrix-clips/batch-15/sources/apocalypse_ep1.mov
- Probe line: 1920x1080 (LANDSCAPE — saliency reframe required at assembly),
  30fps, H.264 + AAC, 406.2s
- Ep1 Drive file ID: 1hwWk0SENS1h4bwnxmQsCBNdD3E6mFohf

### Chosen scene
- Window: in 189.0s, out 211.0s (22.0s).
- What happens: in a dark facility corridor, a blond man holds a pistol on the
  red-haired woman while she tells him the reset rule; she runs down the
  corridor to a control console and presses a large red button with both hands
  as red light floods her face. The moment resolves on the press, not mid-action.
- Character + trait + visible evidence:
  - Character: the red-haired woman (no spelled name asserted — Whisper hears
    her name as "Miris" twice, 30–42s and 90–98s, and "Mira" once, 328–342s;
    no baked subtitle spelling of her name was found on full-size frames at
    36s, 42s, 95s, 330s, 340s, so the monologue uses an evidence-backed
    epithet instead of a guessed spelling).
  - Trait: she has died and reset before — she dies, the day restarts, and she
    remembers. Evidence: baked subtitle at 340s, "I'm taking you somewhere
    because I've died three times"; transcript 190–196s, "Go! If I die, you
    reset! Press it!"; transcript 312–314s, "We won't stay dead."
- Monologue text (74 words, ~24s estimate):
  > "They call her the woman who has died three times, because every time the
  > world ends, she wakes up and starts again. One red button waits at the end
  > of a corridor, and pressing it is her only way forward. Now every choice
  > she makes decides who lives through the next twenty-four hours. If you want
  > to see what she does next, the story is waiting inside the app. Link is in
  > my bio."
  - Evidence for each claim: "died three times" — baked subtitle 340s (above);
    "red button … pressing it" — frames 205–212s, both hands on the red button,
    button glowing red; "next twenty-four hours" — transcript 292–298s,
    "When I realized I only have 24 hours."
- Transcript notes: English, p=1.000, 54 segments. Key lines in/near window:
  188–190s "I know"; 190–196s "Go! If I die, you reset! Press it!" No
  mid-sentence-cut risk for the VO (source audio is silenced at assembly);
  the picture window ends on the completed button press, not mid-gesture.
- Baked-text notes: white subtitles at bottom-center: "I know" (~188s, window
  edge), "go if i die" (192–193s), "you reset press it" (194–195s). No baked
  text 196–211s. Assembly rule: no added text card may duplicate those three
  lines at those moments; cards must use non-duplicate phrasing or sit outside
  192–195s. No other baked text in the window.
- Family-safe verdict: PASS with notes. Window: a man aims a pistol in a
  standoff (no shot fired, no blood, no injury visible in the 1fps window
  frames). No sexual or romantic content anywhere in ep1 (mother/daughter and
  ally relationships only, per full transcript). Episode-level (NOT in window):
  burning-city disaster imagery and people lying on a street at 30–40s.
- Music-bed pick: c1 (22.1s, full dramatic) —
  ~/workspace/rextrix-clips/new-batch-7/edit-3/stemwork/c1_she_wanted_stems/htdemucs/c1_she_wanted_orig/no_vocals.wav
  — its length is a near-exact fit for the 22s window and its full dramatic
  tone matches the red-button climax. No vocals. (c1 is also used for the
  Witch window; beds are generic stems, reuse noted.)
- Picture-window file: ~/workspace/rextrix-clips/batch-15/scouts/groupA/apocalypse_window.mp4
  (window + 2s handles each side: 187–213s, 26s, graded dark cinematic, audio
  stripped, NO end card). LANDSCAPE source — window is saliency-reframed
  (smart-reframe) to 1080x1920, not center-cropped; the native crop is
  608x1080 upscaled to 1080 wide to meet the brief's 1080x1920 spec (flagged
  honestly: this is an upscale of the crop, not native 1080 width). Verify
  frames (window +2s/+13s/+24s): man with gun, running woman, and red-lit
  button-press face all stay in crop and legible.
- Honest weakest point: the protagonist's spelled name is unresolved
  (Miris vs Mira in Whisper; no baked-subtitle spelling found) — the monologue
  deliberately avoids the name; confirm the spelling before any assembly that
  wants a name card. Secondary: the window opens mid-standoff, so the first
  ~2s need the VO to carry context.
- 2.5s-end-card deviation flag: YES — this package uses the template's 2.5s
  end-only card, NOT the standing ≥4.5s default (batch-scoped deviation).

---

## 2. DON'T FEED THE ANIMALS

- Show: DON'T FEED THE ANIMALS
- Source file: ~/workspace/rextrix-clips/batch-15/sources/dontfeed_ep1.mov
- Probe line: 1920x1080 (LANDSCAPE — saliency reframe required at assembly),
  30fps, H.264 + AAC, 396.9s
- Ep1 Drive file ID: 1Ulj-yqf3R_bukImC08215LZ9nQdm-w9t

### Chosen scene
- Window: in 196.0s, out 218.0s (22.0s).
- What happens: a giant black moth creature crouches on a wet city street, then
  flies across the street to a young man filming on his phone; he calls it over,
  it lands on his phone, his phone screen cracks, and the creature slashes a car
  roof with its claw as the man's face turns to shock. The moment resolves on
  the slash + shocked face, not mid-action.
- Character + trait + visible evidence:
  - Character: the moth creature (no name is spoken or shown anywhere in ep1;
    referred to descriptively, never given an invented name).
  - Trait: it does not stay away when it is called — it comes to humans
    despite the warning. Evidence: baked subtitle 204–209s, "hey little guy",
    and the creature flies straight to the man's phone and lands on it
    (207–208s frames); the episode's title card at ~180s reads "DON'T FEED THE
    ANIMALS."
  - Stakes evidence (in-window): the phone screen is cracked (211s frame) and
    the car roof is slashed open (216–218s frames). Episode-level corroboration:
    transcript 351–379s, "You ate everything. Except what was alive?"
- Monologue text (73 words, ~24s estimate):
  > "There is a moth in this city that does not stay away when it is called.
  > One man looks up, holds out his phone, and says, hey, little guy, and the
  > creature flies down to him. But what it touches does not stay whole, and it
  > leaves a slashed roof and a broken screen. If you want to see what it eats
  > next, the story is waiting inside the app. Link is in my bio."
- Transcript notes: English, p=1.000, only 19 segments — the episode is mostly
  visual storytelling with sparse dialogue. Key lines in window: 201–219s
  "What is that? Hey, little guy?" No mid-sentence-cut risk for the VO
  (source audio silenced); picture ends on the completed slash.
- Baked-text notes: white subtitles at bottom-center: "what is that" (202s),
  "hey little guy" (204–206s, 209s). Phone camera UI is visible at 207–208s
  (not a text card). No other baked text in the window. Assembly rule: no added
  card may duplicate "what is that" / "hey little guy" at those moments.
- Family-safe verdict: PASS with notes. Window: no child, no gore, no sexual
  content; only property damage (cracked phone, slashed car roof) and a
  shocked face. Episode-level flag (NOT in window): the first half centers a
  young girl in horror-fantasy peril (toothy creatures crowding her, scared
  face at 140–170s); the window was deliberately chosen from the adult
  man/creature city section so no child appears in the clip.
- Music-bed pick: c2 (24.9s, quiet/sparse) —
  ~/workspace/rextrix-clips/new-batch-7/edit-3/stemwork/c2_not_your_rules_stems/htdemucs/c2_not_your_rules_orig/no_vocals.wav
  — quiet/sparse fits the hushed street encounter better than a full dramatic
  bed. No vocals. (c2 is also used for the Crow-Ash window; reuse noted.)
- Picture-window file: ~/workspace/rextrix-clips/batch-15/scouts/groupA/dontfeed_window.mp4
  (window + 2s handles each side: 194–220s, 26s, graded dark cinematic, audio
  stripped, NO end card). LANDSCAPE source — window is saliency-reframed
  (smart-reframe) to 1080x1920, not center-cropped; the native crop is
  608x1080 upscaled to 1080 wide to meet the brief's 1080x1920 spec (flagged
  honestly: this is an upscale of the crop, not native 1080 width). Verify
  frames (window +2s/+13s/+24s): creature with coin, creature on phone, and
  car-roof slash all stay in crop and legible.
- Honest weakest point: the creature has no name and almost no dialogue, so the
  monologue leans on the "hey, little guy" call as its inciting sentence; if
  the parent wants a named character, this show cannot supply one honestly.
  Secondary: the window's first 6s (creature crouching/flying) are quiet
  before the man appears.
- 2.5s-end-card deviation flag: YES — this package uses the template's 2.5s
  end-only card, NOT the standing ≥4.5s default (batch-scoped deviation).

---

## 3. I Raised Hell's Army

- Show: I Raised Hell's Army
- Source file: ~/workspace/rextrix-clips/batch-15/sources/hellsarmy_ep1.mov
  (Drive filename: RHA-1.mov)
- Probe line: 1080x1920 (VERTICAL native — no reframe needed), 30fps,
  H.264 + AAC, 336.9s
- Ep1 Drive file ID: 1BPZW2YIyL_7eL_LBwG7FoyfFwSdQBg9b

### Chosen scene
- Window: in 252.0s, out 274.0s (22.0s).
- What happens: an armored man says a debt was paid "for 30 arrows with a
  memory"; inside a tent a priest kneels before the white-haired woman; she
  stands in silver armor holding a banner pole, face to camera, as the line
  "so the dead have a banner again" lands; the window closes on a bell-wagon
  procession rolling forward under a red moon. The moment resolves on the
  procession moving, not mid-gesture.
- Character + trait + visible evidence:
  - Character: the white-haired commander (no name is spoken intelligibly or
    shown anywhere in ep1; referred to descriptively, never given an invented
    name).
  - Trait: she rallies the dead as an army instead of burying them. Evidence:
    baked subtitle 263–265s, "so the dead have a banner again", over her
    banner-pole close-up; transcript 255–266s carries the same line; episode
    corroboration: transcript 56–85s "hear them rise … let the purge begin"
    and 266–283s "there's your war".
  - Stakes evidence: transcript 203–225s, "don't flood the valley with dead"
    (the valley is what her army threatens).
- Monologue text (75 words, ~24s estimate):
  > "They call her the white-haired commander, because she does not bury the
  > dead, she gives them a banner again. One banner is raised before a kneeling
  > priest, and the dead begin to march behind it. Now the valley must face an
  > army that does not stay dead, and a war that has already started. If you
  > want to see which side she fights for, the story is waiting inside the app.
  > Link is in my bio."
- Transcript notes: English, p=1.000, 17 segments — but Whisper struggled with
  shouted/overlapping fantasy dialogue, so several segments are garbled merges
  (e.g. 0–10s, 30–56s); the window lines are corroborated by baked subtitles
  (below), which are the reliable source here. Key lines in window: 239–255s
  "you paid for 30 arrows with a memory"; 255–266s "so the dead have a banner
  again". No mid-sentence-cut risk for the VO (source audio silenced).
- Baked-text notes: white subtitles at bottom-center: "you paid for 30 arrows
  with a memory" (251–253s), "so the dead have a banner again" (263–265s).
  Baked "RexTrix" watermark top-right throughout the episode (not a subtitle;
  assembly must not place a card over it). Assembly rule: no added card may
  duplicate the two subtitle lines at those moments.
- Family-safe verdict: PASS WITH CAUTION. Window itself: no blood, no gore,
  no sexual content visible at 1fps inspection (armor, tent, banner, wagon).
  Episode-level flag (NOT in window): dark-fantasy battle violence elsewhere —
  battlefield bodies (~100s), a blood trail on stone (~20s), blood on the
  woman's neck/collar in the 170–171s blade-at-throat frames. The window was
  deliberately chosen to avoid all of those shots.
- Music-bed pick: c3 (24.0s, full dramatic) —
  ~/workspace/rextrix-clips/new-batch-7/edit-3/stemwork/c3_all_invented_stems/htdemucs/c3_all_invented_orig/no_vocals.wav
  — full dramatic tone matches the banner/army reveal. No vocals.
- Picture-window file: ~/workspace/rextrix-clips/batch-15/scouts/groupA/hellsarmy_window.mp4
  (window + 2s handles each side: 250–276s, 26s, graded dark cinematic, audio
  stripped, NO end card). Vertical native, no reframe. Verify frames (window
  +2s/+13s/+24s): armored man + full subtitle, banner-pole close-up + full
  subtitle, bell wagon — all legible, no cropping defects.
- Honest weakest point: no spoken name exists for the lead, and the transcript
  is the least reliable of the five (garbled shouted dialogue) — the package
  leans on baked subtitles, which were verified on frames. Secondary: the
  window's first ~6s (tent/kneeling) are slow before the banner reveal.
- 2.5s-end-card deviation flag: YES — this package uses the template's 2.5s
  end-only card, NOT the standing ≥4.5s default (batch-scoped deviation).

---

## 4. Crow-Ash Orphanage

- Show: Crow-Ash Orphanage
- Source file: ~/workspace/rextrix-clips/batch-15/sources/crowash_ep1.mov
  (Drive filename: CAO-1.mov)
- Probe line: 1920x1080 (LANDSCAPE — saliency reframe required at assembly),
  30fps, H.264 + AAC, 419.4s
- Ep1 Drive file ID: 1ZzgXB88y0RsN5bP4P_XRFGXnKn0wVjnx

### Chosen scene
- Window: in 340.0s, out 362.0s (22.0s).
- What happens: in a glasshouse, the boy's bound hands are untied by the pale
  woman as he says his shadow does whatever it wants; she tells him his shadow
  won't obey because it has been protecting him all along and that it will
  open the door for him; the window closes on the boy standing beside his own
  standing shadow-figure as the question "can you open doors" hangs. The moment
  resolves on the two-shot, not mid-sentence.
- Character + trait + visible evidence:
  - Character: the boy (no name is spoken for him in ep1 — "Leo" in the
    transcript is his brother, the 12th child trapped two years; the monologue
    does NOT call the boy Leo).
  - Trait: his shadow moves on its own, will not obey him, and protects him.
    Evidence: transcript 0–4s, "He's not normal. His shadow moves on its own";
    baked subtitle 342–345s, "I can't control it it does whatever it wants";
    baked subtitle 347–350s, "the reason your shadow won't obey is cause it's
    been protecting you all along"; baked subtitle 351–358s, "it will open the
    door for you".
  - Stakes evidence: transcript 294–299s, "Now the lockmaker knows your
    shadow"; transcript 252–256s, "Now the seal is nearly spent."
- Monologue text (77 words, ~25s estimate):
  > "They call him the boy whose shadow will not obey him, because his shadow
  > moves on its own and does whatever it wants. One locked door stands between
  > him and the truth, and his shadow is the only thing that can open it. Now
  > the lockmaker knows his shadow, and the seal it guards is nearly spent. If
  > you want to see whether he opens the door, the story is waiting inside the
  > app. Link is in my bio."
- Transcript notes: English, p=1.000, 54 segments, clean and dialogue-rich.
  Key lines in window: 320–347s "I can't control it. It does whatever it
  wants."; 347–351s "The reason your shadow won't obey is because it's been
  protecting you all along."; 351–358s "From now on, you can only rely on your
  shadow. It will open the door for you."; 358–373s "Can you open doors?"
  (question starts inside the window, completes just after it — no VO risk,
  source audio silenced; picture ends on the boy + shadow two-shot).
- Baked-text notes: white subtitles at bottom-center throughout the window:
  "I can't control it it does whatever it wants" (342–345s), "the reason your
  shadow won't obey" (347–349s), "is cause it's been protecting you all
  along" (349–350s), "from now on you can only rely on your shadow"
  (351–354s), "it will open the door for you" (355–356s), "can you open doors"
  (358–362s). Baked "RexTrix" watermark top-right throughout. Assembly rule:
  this is the most subtitle-dense window of the five — added cards must be
  timed into gaps or use non-duplicate phrasing; never stack a card over a
  concurrent baked subtitle.
- Family-safe verdict: PASS with notes. Window: gothic horror tension only —
  no gore, no sexual content. Flags, stated honestly: the protagonist is a
  child/teen boy, and his hands are shown bound with rope (341–345s) while
  being untied — restraint imagery, no violence shown. No adult/romance
  content in ep1.
- Music-bed pick: c2 (24.9s, quiet/sparse) —
  ~/workspace/rextrix-clips/new-batch-7/edit-3/stemwork/c2_not_your_rules_stems/htdemucs/c2_not_your_rules_orig/no_vocals.wav
  — quiet/sparse fits the hushed glasshouse dialogue better than a full
  dramatic bed. No vocals. (c2 is also used for the DON'T FEED window; reuse
  noted.)
- Picture-window file: ~/workspace/rextrix-clips/batch-15/scouts/groupA/crowash_window.mp4
  (window + 2s handles each side: 338–364s, 26s, graded dark cinematic, audio
  stripped, NO end card). LANDSCAPE source — window is saliency-reframed
  (smart-reframe) to 1080x1920, not center-cropped; the native crop is
  608x1080 upscaled to 1080 wide to meet the brief's 1080x1920 spec (flagged
  honestly: this is an upscale of the crop, not native 1080 width). VERIFIED
  DEFECT: the vertical crop slices wide baked subtitles at the sides — e.g.
  window +13s reads "n you can only re… / shadow" instead of the full line.
  Faces stay in crop and legible, but assembly must decide whether to accept
  partially-cut baked subtitles or cover the subtitle band; this cannot be
  fixed by re-framing, because no 608-wide crop contains a full-width subtitle.
- Honest weakest point: the boy has no spoken name (Leo is his brother — a
  name mix-up here would be a factual error, so the monologue stays
  descriptive), and the window is dialogue/subtitle-dense, which constrains
  added-card timing at assembly — compounded by the verified subtitle-slicing
  in the vertical crop (see picture-window note). Secondary: the protagonist
  is a minor in a horror-mystery context — parent to confirm comfort with
  that before upload.
- 2.5s-end-card deviation flag: YES — this package uses the template's 2.5s
  end-only card, NOT the standing ≥4.5s default (batch-scoped deviation).

---

## 5. The Witch Beneath the Gallows

- Show: The Witch Beneath the Gallows
- Source file: ~/workspace/rextrix-clips/batch-15/sources/witch_ep1.mov
  (Drive filename: 1-The Witch Beneath the Gallows.mov)
- Probe line: 1080x1920 (VERTICAL native — no reframe needed), 30fps,
  H.264 + AAC, 307.2s
- Ep1 Drive file ID: 16TUR2w0oEBAP98qz7wecIadev3p06waA

### Chosen scene
- Window: in 240.0s, out 262.0s (22.0s).
- What happens: a masked knight demands "what are you" beneath a giant bell
  over a chasm; the witch walks the bridge in a long black gown with soldiers
  behind her; a giant wolf-beast looms on the bridge; the knight orders her to
  kneel before the city; instead of kneeling she raises her hands and a ring
  of red fire forms, closing on red tendrils coiling around her arm. The moment
  resolves on her magic answering the demand, not mid-gesture.
- Character + trait + visible evidence:
  - Character: the witch (no spelled name asserted — Whisper hears a shouted
    name as "VARANORC" at 0–15s but no baked subtitle spelling was found on
    the full-size 10s frame, so the monologue uses an evidence-backed epithet
    instead of a guessed spelling).
  - Trait: she refuses to kneel — cast out by the city, she answers demands
    with her own magic. Evidence: transcript 0–15s, "The city casts you out!";
    baked subtitle 255s, "kneel before the city"; her answer on camera is the
    red fire ring forming in her hands (260–262s frames), not kneeling;
    transcript 270–280s, "No." (her refusal, just after the window).
  - Stakes evidence: transcript 162–180s, "Your dead cannot hide you";
    transcript 180–208s, "I know you" (the city knows her).
- Monologue text (78 words, ~25s estimate):
  > "They call her the witch the city cast out, because the city threw her out
  > and still demands that she kneel. One knight demands that she kneel before
  > the city, and her answer is a ring of red fire in her own hands. Now the
  > beast on the bridge and the bell above the chasm are only the beginning. If
  > you want to see what she does next, the story is waiting inside the app.
  > Link is in my bio."
- Transcript notes: English, p=1.000, only 13 segments — Whisper merged long
  stretches (chanting/music) into wide segments, so timings are coarse; the
  window lines are corroborated by baked subtitles (below). Key lines in
  window: 239–254s "What are you?"; 255–270s "Kneel before the city."
  (Whisper renders "Neil"; baked subtitle reads "kneel"). No mid-sentence-cut
  risk for the VO (source audio silenced); picture ends on the completed
  fire-ring formation.
- Baked-text notes: white subtitles at bottom-center: "what are you"
  (240–241s), "kneel before the city" (255s). Baked "RexTrix" watermark
  top-right throughout. Assembly rule: no added card may duplicate those two
  lines at those moments.
- Family-safe verdict: PASS WITH CAUTION — window-only. Window: the witch
  wears a long black gown (plunging neckline, thigh slit, but fully covering);
  no nudity, no gore, no sexual acts; the beast and bell are dark-fantasy
  imagery. Episode-level flags (NOT in window, stated honestly): the witch's
  other costume is a skeletal bone bikini-style top with bare shoulders and
  midriff, seen at 0s, 40s and 130–140s (verified on full-size frames at 10s
  and 140s); gallows/hanging imagery at ~20s; skeletons and demons elsewhere.
  The window was deliberately chosen to avoid every one of those shots.
  Parent to confirm the show is acceptable given the episode-level costuming,
  even though the window itself is clean. No adult/romance plot in ep1.
- Music-bed pick: c1 (22.1s, full dramatic) —
  ~/workspace/rextrix-clips/new-batch-7/edit-3/stemwork/c1_she_wanted_stems/htdemucs/c1_she_wanted_orig/no_vocals.wav
  — full dramatic tone matches the bell/beast confrontation and her fire-ring
  answer; length is a near-exact fit for the 22s window. No vocals. (c1 is
  also used for the Apocalypse window; reuse noted.)
- Picture-window file: ~/workspace/rextrix-clips/batch-15/scouts/groupA/witch_window.mp4
  (window + 2s handles each side: 238–264s, 26s, graded dark cinematic, audio
  stripped, NO end card). Vertical native, no reframe. Verify frames (window
  +2s/+13s/+24s): masked knight, beast on bridge, red fire-tendril close-up —
  all legible, no cropping defects.
- Honest weakest point: the episode-level sexualized costuming is the real
  risk for this show — the window is clean, but any assembly that pulls
  additional shots from this episode (e.g. an opening hook from 0–40s) would
  import that costuming. Keep all assembly shots inside 238–264s. Secondary:
  her spelled name is unresolved (Whisper "VARANORC" uncorroborated), so the
  monologue stays descriptive.
- 2.5s-end-card deviation flag: YES — this package uses the template's 2.5s
  end-only card, NOT the standing ≥4.5s default (batch-scoped deviation).

---

## Assembly notes for the parent (all 5)

- VO: BLOCKED — no voiceover exists for any package. Do not substitute, borrow,
  or fake one. Final assembly needs ElevenLabs "Hope" (browser) or Fish Audio
  if credits return.
- End card: NONE appended yet. Append the template's 2.5s end-only card at
  final assembly (deviation flagged in every package above).
- Music: all picks are no-vocals stems from campaign footage (edit-3 stemwork);
  no unlicensed trending song is suggested anywhere. c1/c2 reuse across two
  clips each is noted per package.
- Reframing caveats (verified on window frames): the three landscape windows
  are saliency-reframed crops upscaled 608→1080 wide to meet the 1080x1920
  spec; the Crow-Ash window additionally slices wide baked subtitles at the
  sides in vertical crop — assembly must decide how to handle the subtitle
  band for that clip.
- No clip is uploaded, published, or submitted. Ready-to-assemble state only.
- No copyrighted characters observed in any episode; all characters appear to
  be original AI-generated RexTrix characters.
- No show rejected. If the parent judges the Witch episode-level costuming or
  the Crow-Ash child protagonist unacceptable, those two are the ones to cut —
  the other three carry no such flag.
