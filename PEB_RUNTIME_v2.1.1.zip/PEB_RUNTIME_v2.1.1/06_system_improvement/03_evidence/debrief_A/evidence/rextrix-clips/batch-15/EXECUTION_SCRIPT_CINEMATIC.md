# Execution script — Cinematic lore / character-driven template
## (Dark, high-contrast, story-first promotional clip)

## Template identity
A suspenseful character monologue that makes the viewer want to follow one
person's story inside RexTrix. This is STORYTELLING about the world on screen,
not feature claims: never claim the app does something it doesn't, never
invent a character name, power, or plot point that isn't visible in the chosen
footage. The prompt's example ("They call her 'The Editor' because she
literally changes the rules of the game") is a SHAPE, not a fact — the
clip's character must be a real character from its scene, described by what
the scene actually shows.

## Voiceover master text (continuous suspenseful monologue, ~60 words / ~22s)
> "They call her the Editor, because she doesn't just play the game, she
> rewrites its rules while everyone else is still following them. One sentence
> typed into RexTrix, and her whole world changed. Now every choice she makes
> pulls someone else's story apart. If you want to see what she does next, the
> story is waiting inside the app. Link is in my bio."

Per-clip adaptation rule: keep the monologue structure (name → rule-breaking
trait → inciting sentence → stakes → invitation). Replace the character and
the trait with the REAL character/trait of the chosen scene. Every sentence
must grammatically resolve — no fragments, no clipped statements.

## Edit rules
- Vertical 9:16, 1080x1920 30fps, H.264 slow CRF 16, yuv420p, AAC 192k.
- Grade: dark, cinematic, high-contrast layers. Lift contrast WITHOUT crushing
  faces or key action into illegibility; verify the grade on full-size frames.
- Pacing: picture cuts match dramatic beats. SLOW DOWN during dialogue beats —
  let the viewer absorb the character's expression before switching angles.
  Never cut mid-sentence in the VO.
- Audio safety (zero-clipping rule): background music ducks 65% (to 35% level)
  whenever voiceover is active. Keep a 0.18s room-tone pad around all dialogue
  cuts so the voice never sounds aggressively truncated. VO ~-16 LUFS, true
  peak ≤ -1 dB.
- Original drama audio: SILENCED under voiceover (standing lesson). Music bed
  = royalty-free track, or a no-vocals stem from campaign footage (edit-3
  stems), ducked 65% under VO. Never an unlicensed trending song.
- Text overlays: Montserrat Bold, white, 4px black outline, centered Y 50%,
  max 3 words per card, phrase-whole chunks synced to monologue phrases.
  Never duplicate a baked subtitle visible at the same moment.
- End card: 2.5s at END ONLY, clean RexTrix logo + download call-to-action,
  silent. NOTE: 2.5s is this template's own spec and a DEVIATION from the
  standing ≥4.5s default — applied to this batch only, on the user's word via
  this template. Flag it in every clip note.

## Production method (per clip)
1. Pick a character-driven tension moment (a face, a choice, a reveal — not a
   generic action shot). Name the character from the footage.
2. Write the clip's monologue from the master text, swapping character/trait
   to the real scene. Record via ElevenLabs "Hope" (engload23) or Fish Audio
   if credits return; verify duration and no truncation before cutting.
3. Cut picture to dramatic beats (slow on dialogue), grade cinematic, silence
   source audio, duck music 65% under VO, append the 2.5s end card.
4. Independent QC (specs, decode, loudnorm, card silence, hook/mid/card
   frames, grade legibility, transcript vs VO, no doubles) → fix loop →
   honest note per clip.

## QC / honesty
No clip ships with a known unflagged defect. If the VO engine blocks, report
it — do not substitute silently. Never upload, publish, or submit.
Ready-to-upload state only.
