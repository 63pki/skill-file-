# Batch-30 Group 4 — GROUP SUMMARY (recovery delivery, 2026-10-29)

## What passed (6/6 planned clips, all in group-4/)
| Clip | Content + card | Content I / TP | Card tail | Verdict |
|---|---|---|---|---|
| g4_divorce_prison.mp4 | 10.00 + 4.50 = 14.50 s | −15.99 / −5.08 | −91.0 / −59.2 dB | PASS |
| g4_divorce_heir.mp4 (v2) | 18.50 + 4.50 = 23.00 s | −16.05 / −1.46 | −91.0 / −63.1 dB | PASS |
| g4_primal_shark_charge.mp4 (v2 audio) | 15.47 + 4.50 = 19.97 s | −16.65 / −1.64 | −91.0 / −84.3 dB | PASS |
| g4_primal_roar_siege.mp4 | 16.00 + 4.50 = 20.50 s | −16.06 / −3.46 | −91.0 / −70.3 dB | PASS |
| g4_primal_gets_up.mp4 | 17.97 + 4.50 = 22.47 s | −16.09 / −3.23 | −91.0 / −55.3 dB | PASS |
| g4_primal2_tiny_life.mp4 (v2 audio) | 16.00 + 4.50 = 20.50 s | −16.51 / −2.94 | −91.0 / −67.4 dB | PASS |

Every clip: 1080×1920 30 fps, libx264 slow CRF 16, yuv420p, AAC 192k,
faststart verified (moov before mdat), full null-decode OK, end card exactly
4.5 s (135 frames) at END ONLY, all added cards frame-verified (whole, centered,
readable, no doubles, no shared words with any baked subtitle visible at the
same moment). No clip exceeds 25 s of content. Full per-clip detail, sources,
timestamps, and fixes: NOTES.md in this directory.

## What was fixed (recovery found real defects, not just unfinished work)
1. **Heir v1 card overlap (material):** the previous cut list placed THE DOCUMENT
   at clip 7.5–10.0, which maps to source 36.0–38.5 — overlapping the baked
   "your honor, this is notice document no. RO037" subtitle AND sharing the word
   DOCUMENT. Rebuilt as v2 with the card at 5.6–7.8 (verified sub-free window);
   frame-verified that the baked line now plays alone. v1 quarantined in work/,
   not delivered.
2. **Shark v1 audio (material):** TP +0.08 dB (over the −1 ceiling) and a 0.03 s
   audio overhang into the silent card (mix 15.50 s vs video 15.47 s). Rebuilt
   audio with gain-to-−16 + limiter 0.70 + exact-duration trim + fade-out.
   This also exposed the loudnorm two-pass undershoot on peaky SFX, so the
   audio method was replaced for all later clips.
3. **Tiny-life reframe trajectory (material):** the default saliency track
   followed armor/body mass (shoulder-only opening; dark fur with neither face
   in the payoff window). Reframed with --center-weight 0.6 and moved the second
   card 11–14 → 13–15.5 onto the verified tiny-visible stretch.
4. **Tiny-life v1 audio:** content I −18.35 (quiet source, limiter ate the
   first gain). Iterated to +11 dB gain → content I −16.51, TP −2.94.
5. **Restart damage:** the previous builder's seg0 files were corrupt (moov
   missing); two further VM restarts during recovery killed the shark reframe
   and the gets_up ASS encode, and a gets_up reframe died silently under load
   ~13. All were rebuilt from verified intermediates; nothing unfinished was
   counted. Quarantined intermediates are preserved in work/ (never deleted).

## What is still weak (honest)
- Primal clips have no dialogue — retention rests on creature action alone.
- Gets_up: the rolling Rex's head touches the left frame edge at ~3 s.
- Shark mid-chase frames blur (fast source motion, not a crop defect).
- Tiny-life: a ~1 s dark-fur passage precedes the payoff (the card now starts
  at 13 s, after it); heavy peak limiting was needed on a quiet source.
- Gets_up card-tail max −55.3 dB (AAC frame smear at the fade boundary;
  ~30 dB below dialogue, effectively silent, but the highest tail peak in the group).
- Divorce clips: baked subtitles carry the dialogue; added cards are sparse
  by design, and the heir clip has a hard scene jump (5.5 s → courtroom).

## What was NOT done
- No downloads (all three episode-1 sources were already on disk and verified).
- No uploads, publishing, submissions, or messages to anyone.
- Backup cut g4_primal2_parade NOT built — the 6-clip target was met without it,
  and padding was forbidden.
- No BLOCKED downloads: none encountered (nothing needed downloading).

## Files
- Deliverables: the six `g4_*.mp4` files in this directory.
- Notes: `NOTES.md` (this directory). Build scripts, QC frames, logs, and
  quarantined intermediates: `work/` (intermediates never in /tmp).
