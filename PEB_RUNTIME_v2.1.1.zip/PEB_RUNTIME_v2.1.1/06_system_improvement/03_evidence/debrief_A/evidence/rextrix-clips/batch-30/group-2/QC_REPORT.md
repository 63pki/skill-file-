# Batch-30 Group 2 — INDEPENDENT QC REPORT

**QC role:** independent verifier. I did not build these clips. Nothing was modified,
uploaded, published, submitted, or sent to anyone. No live browser was used.
All numbers below were measured fresh from the delivered files in
`/home/hatch/workspace/rextrix-clips/batch-30/group-2/`.

**Overall: 5 PASS, 1 FAIL** — `g2_apoc_died_three_times.mp4` FAILS on a mid-sentence
cut at the end of content (see Clip 2). The other five pass, with flags disclosed.
The builder's self-QC numbers reproduced exactly wherever I re-measured them — except
for Clip 2's ending, which the builder's NOTES misdocuments (see below).

## Method (and the Group 3 error, avoided)

- **Bitrate the CORRECT way:** per the task's critical rule, the verdict figure is
  **content-only** (audio packets with `pts < content_duration`, summed, ÷ content
  duration). Full-file ffprobe figures are reported as reference only — every clip
  carries 4.5 s of silent end card, which dilutes the full-file average by design.
- Probe: `ffprobe` streams + `-count_frames` frame counts; atom scan for moov-before-mdat.
- Decode integrity: `ffmpeg -v error -f null` full decode per clip.
- Loudness: `loudnorm` measurement on the **content section only** (`-t <content_dur>`).
- Card silence: `volumedetect` on the full 4.5 s card and on the card-first-0.5 s slice.
- End card: verified by **frame number** (`select=eq(n,…)`), not timestamp seeks —
  last-content frame, first-card frame, mid-card and last frame extracted per clip.
- Cards vs baked subs: word-audited on frames I viewed myself (not on Whisper).
  Whisper was attempted for an independent transcript check but is **unavailable in
  this environment** (`faster-whisper` fails on an `av` library incompatibility:
  `open() got an unexpected keyword argument 'metadata_errors'`). Transcript
  verification therefore rests on baked subtitles read on frames, plus source-file
  cross-checks for the ending boundaries. For Hell's Army no Whisper line is quoted,
  per the task.
- Ending-boundary check (applied to all six after the Clip 2 finding): last-0.5 s
  content level + source frame 0.5 s past the cut, to distinguish a clean ending
  (sub gone, new scene, or music-only tail) from a straddled subtitle line.

## Shared results (all six)

| Check | Result |
|---|---|
| Dimensions / fps / codec | 1080×1920, 30 fps, H.264, all six |
| Audio codec / sample rate | AAC, 96 kHz, stereo, all six — consistent, no sample-rate issue |
| Faststart | moov before mdat in all six (atom scan: `ftyp, moov, free, mdat`) |
| Null decode | Clean, exit 0, no errors, all six — no encode damage despite Clip 3's 5-kill build history |
| End card | Exactly 135 frames, end only, in all six (frame numbers in per-clip tables) |
| Card silence | Full-card mean −91.0 dB in all six; boundary peaks −58.1 to −91.0 dB — **no −38.5 dB transient remains on any clip** (Clip 1's fix confirmed) |
| Content duration | All ≤ 25 s (14.0 / 14.0 / 18.0 / 24.0 / 24.9 / 16.0 s) |
| English | Yes throughout (frame-read baked subs; no non-English line observed) |
| Added cards | Whole, readable, no doubled captions found in any sampled frame |

## Per-clip results

### Clip 1 — `g2_apoc_24hours.mp4` — PASS

- Window: Apocalypse 288–302. Total 18.5 s, 555 frames = 18.5×30 ✓.
- Content 14.0 s; card frames 420–554 (first card frame n=420 viewed: full end card;
  last content frame n=419 viewed: helicopter city shot, no sub).
- Loudnorm (content): **I −16.63, TP −1.27** — reproduced exactly. 0.37 LU from −16 ✓, TP ✓.
- Bitrate: full-file 147.7 kbps (reference only, diluted) vs **content-only 193.8 kbps** ✓ ≈192.
- Card: mean −91.0 dB; first-0.5 s mean −91.0 dB, peak −69.5 dB ✓.
- Frames viewed: n=30 — top-bar card "ONLY 24 HOURS" readable; baked sub
  "when did you become so fearless" whole inside the video area; shared words: none.
  n=419 — "THE ESCAPE PLAN" over the helicopter shot, no concurrent sub, no doubling.
- Transcript: hook in 1–3 s ✓ (fearless question at 1 s); dialogue resolves before the
  card (source frame 0.5 s past the cut shows the same helicopter shot, no sub;
  post-cut audio is music, not speech) — clean ending, no mid-sentence cut ✓.
- **Weakest point:** the top bar is very dark in the hook shot (card still legible);
  the cockpit close-up cuts the man's face at the source frame edge (source framing,
  not a pillarbox crop).

### Clip 2 — `g2_apoc_died_three_times.mp4` — FAIL

- Window: Apocalypse 338–352 (as built). Total 18.5 s, 555 frames = 18.5×30 ✓.
- Content 14.0 s; card frames 420–554 (first card frame n=420 viewed: full end card).
- Loudnorm (content): **I −15.36, TP −1.68** — reproduced exactly. 0.64 LU from −16,
  inside the 1 LU gate ✓ (near edge, as the builder admitted); TP ✓.
- Bitrate: full-file 148.1 kbps (reference) vs **content-only 194.3 kbps** ✓ ≈192.
- Card: mean −91.0 dB; first-0.5 s mean −91.0 dB, peak −67.4 dB ✓.
- Frames viewed: n=60 (2 s) — baked sub "I'm taking you somewhere because I've died
  three times" whole; hook on screen at 2 s ✓. n=210 (7 s) — "SHE CAME BACK" in the
  top bar with **no baked sub beneath it: the speech-gap placement is confirmed**.
  n=270 (9 s) — "THE SKY TURNS" + baked "something's coming tonight" whole;
  shared words: none.
- **The failure — mid-sentence cut at the end, and NOTES misdocuments the ending:**
  The builder's NOTES dialogue ends at "Yes. How did you know?" — but the delivered
  clip's last content frame (n=419) shows a further baked line the NOTES never
  mentions: **"I've watched the sky for 30 years"**. Source-file check proves the cut
  lands inside that line: the sub is already on screen at source 351.5 s, still on
  screen at 352.0 s (the cut), 352.5 s and 353.0 s, and only changes to a new sentence
  ("if it comes it'll be red") at ~353.5 s. Speech is active across the boundary
  (clip last-0.5 s mean −17.1 dB; source 352.0–353.0 s means −15.1 to −13.1 dB, with a
  pause only around 353.0 s). The viewer therefore hears the answer to
  "How did you know?" begin and get cut off mid-utterance as the card arrives.
  The payoff is interrupted, not delivered. This fails the "complete thought, no
  mid-sentence cut, payoff before card" criterion.
- **Weakest point (beyond the fail):** "SHE CAME BACK" is an interpretive gloss, not
  a quote — but it is accurate (the speaker is alive recounting three deaths) and is
  not misleading; the fail is the ending cut, not the card.
- **Fix (see Fix list):** extend the window so the final line completes.

### Clip 3 — `g2_apoc_built_not_disaster.mp4` — PASS

- Window: Apocalypse 373–391. Total 22.5 s, 675 frames = 22.5×30 ✓.
- Content 18.0 s; card frames 540–674 (first card frame n=540 viewed: full end card).
- Loudnorm (content): **I −16.90, TP −2.44** — reproduced exactly. 0.90 LU from −16:
  **inside the 1 LU gate, but only just** (the builder's near-edge admission is
  accurate). TP ✓ with margin.
- Bitrate: full-file 155.4 kbps (reference) vs **content-only 193.1 kbps** ✓ ≈192.
- Card: mean −91.0 dB; first-0.5 s mean −90.3 dB, peak −58.1 dB ✓ (matches the
  builder's "−90.3 to −91" range; no transient).
- Null decode clean — the 5-kill encode history left **no detectable damage** in the
  delivered file (exact frame count, clean decode, single moov-before-mdat).
- Frames viewed: n=30 (1 s) — "THEY'RE COMING DOWN" readable over the red blurred
  bar; baked "do you see that something's falling" whole; shared words: none; hook
  visual (falling objects/vortex over the city) in 1–3 s ✓. n=450 (15 s) —
  "A PLAN, NOT CHANCE" + baked "no" (start of "No. Your world built it.");
  shared words: none. n=539 (last content) — baked "your world built it", the
  closing line, complete; source frame 0.5 s past the cut shows the same shot with
  no sub — clean ending ✓.
- **Weakest point:** loudness sits 0.90 LU below −16 (a stricter ±0.5 LU gate would
  flag it, but the task's gate is 1 LU and it passes); the red-sky falling-objects
  shot is visually dense on a small screen until the dialogue resolves it.
- Note on the closing card: "A PLAN, NOT CHANCE" is a third interpretive gloss in
  this group (it paraphrases "Your world built it" and echoes a later episode line,
  "Not a disaster. A plan.", which is NOT in this clip). Accurate to the clip's own
  closing line, not misleading — but disclosed here because it is not a quote.

### Clip 4 — `g2_feed_moth_city.mp4` — PASS (v2, with family-safe flag disclosed)

- Window: Feed 196–220. Total 28.5 s, 855 frames = 28.5×30 ✓.
- Content 24.0 s; card frames 720–854 (first card frame n=720 viewed: full end card).
- Loudnorm (content): **I −15.61, TP −1.17** — reproduced exactly. 0.39 LU from −16 ✓,
  TP ✓ (v2 rebuild; see item 6).
- Bitrate: full-file 166.4 kbps (reference) vs **content-only 196.7 kbps** ✓ ≈192
  (2.4% over target; within "≈192").
- Card: mean −91.0 dB; first-0.5 s mean −91.0 dB, peak −66.8 dB ✓.
- Frames viewed: n=30 (1 s) — "SOMETHING HUGE FLIES" + front moth shot (see flag
  judgment below). n=240 (8 s) — "IT'S COMING CLOSER", moth flying distant, man
  filming. n=285 (9.5 s) — same card + baked "hey little guy" whole; shared words:
  none. n=600 (20 s) / n=660 (22 s) — "IT'S FEEDING NOW" + proboscis driven into a
  car roof (car only, no gore, no person). n=719 (last content) — man's shocked
  reaction, no sub; source frame past the cut shows feeding still on the car roof —
  the visual arc (moth → filming → feeding → reaction) is complete, no sentence
  straddles the cut ✓.
- The phone in the man's hand is diegetic source content (a character filming),
  not an added overlay — no faked studio UI ✓.
- **Weakest point / flag:** the moth is an unclothed humanoid form (see scrutiny
  item 2). The 1 s front shot is the most exposed framing in the clip. If the
  coordinator enforces a zero-humanoid-body policy, drop this clip; the other five
  stand alone.

### Clip 5 — `g2_feed_title_drop.mp4` — PASS

- Window: Feed 372–396.9. Total nominal 29.4 s; **delivered video is 881 frames
  (29.367 s), one frame short of the nominal 882** — content video 746 frames
  (24.867 s) vs nominal 24.9 s, while content audio is 24.9 s. A 33 ms shortfall,
  immaterial: card is still exactly 135 frames (746–880), content still ≤ 25 s.
  Reported here for exactness, not as a fail.
- Card frames 746–880 (first card frame n=746 viewed: full end card).
- Loudnorm (content): **I −16.21, TP −1.11** — reproduced exactly. 0.21 LU from −16 ✓,
  TP ✓.
- Bitrate: full-file 151.7 kbps (reference) vs **content-only 178.2 kbps** — the one
  figure below ≈192, explained, not a setting error: the 0–20 s content measures
  **192.7 kbps** (spot-on 192k), while the 20–24.9 s quiet black-screen title section
  measures 119.1 kbps — the native AAC encoder sheds bits on near-silence. The
  encode target is demonstrably 192k; the average dip is content-driven. PASS on
  bitrate with this note recorded.
- Card: mean −91.0 dB; first-0.5 s mean −91.0 dB, peak −91.0 dB — the cleanest card
  boundary of the six ✓.
- Frames viewed: n=15 (0.5 s) — single card "SOMETHING SURVIVED" over the forest
  temple + distant moth (tiny, back view); no dialogue runs under it, no doubling.
  n=600 (20 s) — title drop mid-fade (center text partly dimmed: source animation).
  n=660 (22 s) — center baked text fully bright: "MAYBE WE WERE NEVER THE WORLD.
  DON'T FEED THE ANIMALS." + bottom baked sub "maybe we were never the world
  don't feed the animals" whole; **no added card competes** — no doubling, no
  triple text (see item 5). n=745 (last content) — the episode's own RexTrix logo
  outro ("Turn Every Idea Into Playable Entertainment"); silent tail (−91.0 dB
  last-0.5 s); the window ends at the episode file's own end (396.9 s), so there is
  no cut to straddle — clean ending ✓.
- **Weakest point:** the title-drop tail is quiet and static (~5 s of black-screen
  text); "SOMETHING SURVIVED" is the only hook for the first 4 seconds. The gloss
  card is accurate (it anticipates "except what was alive", the line at ~376–380 s)
  and is not misleading.

### Clip 6 — `g2_hells_guard_hungry.mp4` — PASS (v2)

- Window: Hell's Army 239–255, vertical-native. Total 20.5 s, 615 frames = 20.5×30 ✓.
- Content 16.0 s; card frames 480–614 (first card frame n=480 viewed: full end card;
  last content frame n=479 viewed: tent scene, "WHAT DID IT COST" still up, no
  baked sub — the line already resolved; source frame past the cut shows a new
  scene with no sub — clean ending ✓).
- Loudnorm (content): **I −16.17, TP −1.44** — reproduced exactly. 0.17 LU from −16 ✓,
  TP ✓ (v2 rebuild; see item 6).
- Bitrate: full-file 151.8 kbps (reference) vs **content-only 193.2 kbps** ✓ ≈192.
- Card: mean −91.0 dB; first-0.5 s mean −91.0 dB, peak −80.8 dB ✓.
- Frames viewed (dialogue from baked subs only — no Whisper line quoted, per task):
  n=60 (2 s) — centered "A DARK BARGAIN" between the two faces + baked "guard the
  hungry nothing else" whole; shared words: none; RexTrix logo top-right untouched.
  n=270 (9 s) — "SOMETHING IS HIDDEN" + baked "where did he hide the seal" whole;
  "hidden" vs "hide" are different words — no shared word ✓. n=390 (13 s) —
  "WHAT DID IT COST" + baked "you paid for 30 arrows with a memory" whole;
  shared words: none; young knight under a blood moon, no gore beyond a small cheek
  scratch on the woman (seen at 2 s) ✓.
- **Weakest point:** the centered 2 s card crowds the confrontation framing (see
  item 3) — faces stay readable, so this is a composition compromise, not a defect.

## Explicit scrutiny items — judgments

1. **Pillarbox deviation (landscape clips: 1–5) — JUSTIFIED, not a fail.**
   Every baked line I sampled is whole inside the video area (listed per clip above);
   a 9:16 center crop (~608 px of the 1920 px source width) would slice these
   full-width lines, violating "frame around baked text, never crop through." The
   top-bar cards are readable in every sample (white + outline on the blurred bar;
   darkest in Clip 1's hook shot, still legible), sit outside the video area per the
   standing caption rule, and share no words with any concurrent baked sub. The
   deviation is disclosed in NOTES.md, not silent. The brief's centered-Y-50% cards
   assume vertical-native sources; for these landscape sources the pillarbox +
   top-bar treatment is the correct trade. Minor cost: blurred figures sometimes
   show through the top bar (Clip 2) — slightly busy, not distracting.
2. **Moth humanoid flag (Clip 4) — PASS with the flag disclosed.**
   Frames checked across the window: 1 s front crouch, 9.5 s distant flight,
   18 s distant full-body standing on a car, 22 s feeding head/proboscis on a car
   roof. The creature is a dark, unclothed humanoid with butterfly wings, but at no
   checked frame is there visible genitalia detail or sexualized posing — crouch,
   flight and feeding poses read as monster/creature design, not sexual content.
   The 260 s close-up is outside this window (196–220) and was not used. Under the
   task's criterion (FAIL only if a frame is sexually suggestive or explicit), this
   passes. Caveat stands: a strict zero-humanoid-body policy would still drop it.
3. **Hell's centered card at ~2 s — faces stay readable.**
   The card sits between the two faces over the background wagon and touches
   neither face; both profiles (eyes, noses, mouths) are fully visible. The
   builder's compromise claim holds. It crowds the middle ground but does not break
   the moment.
4. **Interpretive-gloss cards — accurate, not misleading; all three flagged.**
   "SHE CAME BACK" (Clip 2) glosses "I've died three times" — the speaker is alive
   recounting deaths, so the gloss is true to the adjacent dialogue. "SOMETHING
   SURVIVED" (Clip 5) anticipates "except what was alive" a few seconds later —
   true to the immediately following line. "A PLAN, NOT CHANCE" (Clip 3) paraphrases
   "Your world built it" and echoes a later episode line not in the clip — accurate
   to the clip's own closing line. None invents a claim the dialogue contradicts;
   none is presented as a quote. Disclosed, not failed.
5. **Feed title drop (Clip 5) — verified.**
   The closing baked text sequence is carried through the pillarbox with no added
   card competing: the only added card runs 0.5–3.5 s at the start. At 22 s the
   center title text is fully bright and legible and the bottom sub is whole; at
   20 s the center text is mid-fade (source animation, resolves by 22 s). No
   doubling, no triple text. The black title screen blends with the pillar bars.
6. **TP-fix history — fully confirmed.**
   Delivered files are the v2 files, not the v1 tpFAIL files in `work/`:
   different md5s (delivered `g2_feed_moth_city.mp4` 7abcf71d… vs v1 557776e0…;
   delivered `g2_hells_guard_hungry.mp4` 40e6b5bb… vs v1 4e331c2b…), newer
   timestamps (15:38 vs 15:09/15:26). Re-measured v1 content TP: moth **−0.64 dB**
   (fail) and hells **−0.98 dB** (fail by 0.02 dB) — exactly as the builder reported.
   Delivered content TP: moth **−1.17 dB** and hells **−1.44 dB** — both ≤ −1 dB ✓.
   The −1.5 dB loudnorm rebuild worked as documented.

## Summary table

| File | Frames | Content | I / TP | Content-only kbps (full-file ref) | Card mean / boundary peak | Verdict |
|---|---|---|---|---|---|---|
| g2_apoc_24hours.mp4 | 555 | 14.0 s | −16.63 / −1.27 | 193.8 (147.7) | −91.0 / −69.5 | **PASS** |
| g2_apoc_died_three_times.mp4 | 555 | 14.0 s | −15.36 / −1.68 | 194.3 (148.1) | −91.0 / −67.4 | **FAIL** (mid-sentence end cut) |
| g2_apoc_built_not_disaster.mp4 | 675 | 18.0 s | −16.90 / −2.44 | 193.1 (155.4) | −91.0 / −58.1 | **PASS** |
| g2_feed_moth_city.mp4 | 855 | 24.0 s | −15.61 / −1.17 | 196.7 (166.4) | −91.0 / −66.8 | **PASS** (flag disclosed) |
| g2_feed_title_drop.mp4 | 881 | 24.9 s | −16.21 / −1.11 | 178.2* (151.7) | −91.0 / −91.0 | **PASS** |
| g2_hells_guard_hungry.mp4 | 615 | 16.0 s | −16.17 / −1.44 | 193.2 (151.8) | −91.0 / −80.8 | **PASS** |

\* Clip 5: 192.7 kbps over the 0–20 s non-quiet content; 119.1 kbps over the quiet
20–24.9 s title tail (see Clip 5 section). Encode target is 192k.

## Fix list (one fail)

**Clip 2 — `g2_apoc_died_three_times.mp4` (FAIL):**
1. Rebuild the window as Apocalypse **338–~353.2 s** (content ~15.2 s, total ~19.7 s)
   so the final line "I've watched the sky for 30 years" completes: the line's speech
   runs ~351.4–353.0 s in source time with a pause around 353.0–353.25 s, before the
   next sentence ("if it comes it'll be red") starts. End the content in that pause;
   do not extend into the next sentence.
2. Keep the existing cards and their timings (re-check "THE SKY TURNS" 8–12 s against
   the unchanged mid-section; the extension only affects the tail).
3. Re-run loudnorm on the new content and confirm I within 1 LU of −16 and TP ≤ −1 dB
   (the current build is −15.36 / −1.68; the added ~1.2 s of quiet-tailed speech
   should not push it out, but verify, don't assume).
4. Re-verify the 4.5 s / 135-frame end card by frame number and the card silence
   (mean −91 dB, boundary slice) on the rebuilt file.
5. Correct NOTES.md: the Clip 2 dialogue list must include the final line
   "I've watched the sky for 30 years" — the current list ends a line early and
   misdescribes what the delivered clip contains.
6. Alternative if the coordinator prefers no extension: trim to ~351.3 s (content
   ~13.3 s), ending right after "How did you know?" — but that ends on an unanswered
   question and loses the payoff answer, so the extension in (1) is recommended.

No fixes required for the five passing clips. Notes for the coordinator (not fails):
- Clip 3 loudness (−16.90) sits 0.10 LU inside the 1 LU gate — closest to the edge.
- Clip 4 carries the disclosed humanoid-body flag; drop only under a
  zero-humanoid-body policy.
- Clip 5's content-only bitrate average (178.2 kbps) reflects the quiet title tail,
  not a wrong encoder setting (192.7 kbps over non-quiet content).
- Clip 5's video is one frame short of nominal (881 vs 882); immaterial.
