# Batch-30 Group 5 — GROUP SUMMARY (RECOVERY BUILD, 2026-10-29)

Recovery note: a previous builder completed clips 1–3 and the scouting/crops for
clips 4–6 before dying in a runtime restart drain (its `z1_a/v.mp4` reframe is
corrupt — moov atom missing — and was NOT reused). This recovery run re-verified
clips 1–3 from scratch, re-ran the reframes, and built clips 4–6. Nothing here
was uploaded, published, submitted, or sent to anyone. All durations and audio
readings below are MEASURED on the delivered files, not predicted.

## Deliverables (group-5/)

| # | File | Content | Total | Frames |
|---|------|---------|-------|--------|
| 1 | g5_prequel_wormhole.mp4 | Prequel-Adrift: shields failing, wormhole gamble | 29.20s | 876 (741 content + 135 card) |
| 2 | g5_unsolved_mary_celeste.mp4 | UNSOLVED: Mary Celeste found, every person gone | 27.30s | 819 (684 + 135) |
| 3 | g5_prequel_aegis.mp4 | Prequel-Adrift: "What is Aegis?" / five crew dead | 20.20s | 606 (471 + 135) |
| 4 | g5_zeroed_building.mp4 | ZEROED: "That's my building" / "Do not approach" / "What she touched" | 26.37s | 791 (656 + 135) |
| 5 | g5_zeroed_talking.mp4 | ZEROED: "She is not gone" / "Something is talking" / "Six in two years" | 16.37s | 491 (356 + 135) |
| 6 | g5_redundancy_redundant.mp4 | Redundancy: "Redundant asset" / "Resisting failed" / "Child who hid" | 20.07s | 602 (467 + 135) |

All six: 1080x1920, 30fps, H.264, AAC, faststart, end card exactly 135 frames
(4.5s) at END ONLY, silent. Content lengths for clips 4–6 run 1–2 frames longer
than the planned segment sums (fps rounding at concat joins); audio was cut to
the measured content durations, so A/V match exactly. See NOTES.md for per-clip
timings, audio readings, cards, fixes, and weakest points.

## Verification of pre-existing clips 1–3 (done from scratch, not trusted)

- Probe: all 1080x1920, 30fps, H.264; faststart confirmed (moov before mdat).
- Null decode: all pass. Frame counts exact: aegis 606, wormhole 876, mary 819.
- Card boundary (frame-exact): last content frame vs first card frame checked
  on frames — aegis 470/471, wormhole 740/741, mary 683/684 — so each card is
  exactly 135 frames at the end only (606−471, 876−741, 819−684).
- Loudnorm (full file): aegis I=−16.01 / TP=−1.08; wormhole I=−16.01 / TP=−1.32;
  mary I=−16.39 / TP=−1.13 — all within 1 LU of −16, TP ≤ −1 dB.
- Card silence: mean −91.0 dB on all three (aegis max −67.4 dB, mary max
  −90.3 dB — encoder noise floor only).
- Transcripts (Whisper base, finals): all complete, English, hooks in first
  3s, payoff before card, no mid-sentence cuts. Wormhole's shouted "Move!"
  tail is present in audio (24.0–24.7s: mean −16.2 dB, max −3.4 dB) but Whisper
  misses the single word — a transcription limit, not edit damage.
- Frames: cards centred/readable, no doubles vs baked subs, end cards clean,
  nothing important below y=1500 except in-source content.
- NO fixes needed for clips 1–3. Two documented non-issues, NOT re-rendered:
  (a) aegis + mary carry SAR 944:945 (0.1% off square, constant through file,
  visually identical; wormhole is 1:1) — re-encoding to fix SAR would cost a
  lossy generation for zero visible benefit;
  (b) average audio bitrates read 155–166 kbps because the 4.5s of card
  silence compresses to near nothing — the encoder setting was 192k, and the
  content portion is at 192k.
- Flag carried forward (parent to judge): aegis's final content frame is a
  handgun close-up (in-source prop, no firing, no blood/gore in the clip).

## New builds 4–6 (this recovery run)

- Sources: all four ep1s were already on disk (no downloads needed, nothing
  BLOCKED): prequel_adrift_ep1.mov (394s), redundancy_ep1.mov (628s),
  zeroed_ep1.mov (315s), unsolved_ep1.mov (274s).
- Landscape sources carry baked subtitles in a bottom band; every landscape
  clip was pre-cropped to y=0–840 (subtitle band excluded, verified
  subtitle-free on reframed frames) before reframe, then upscaled 472→1080
  with lanczos. Added cards are then the only text.
- REFRAME DECISION (applies to all of clips 4–6): the saliency reframes were
  REJECTED on frames — windows sat systematically too far right (faces cut at
  the left edge, z2_a showed knobs instead of the waveform screen, z2_b man's
  face half out). They were replaced with manual subject-tracked windows
  measured on source frames (window plans in work/window_plans.json; still
  subject-following, NOT dead centre-crops — a centre window would exclude the
  subjects entirely). Every manual window was verified on frames before the
  build. The saliency files remain on disk, unused.
- REDUNDANCY carries an in-source "RexTrix" watermark at the top-right corner
  of the full frame; reframe windows were kept off that corner (all windows
  end at x≤1536, watermark starts ~x1700) — verified watermark-free on every
  reframed frame and every delivered RED frame.
- RED seg3 was deliberately ended at 607.54 ("I was the child who hid"),
  excluding the 611.22 "Do it" / 613.48 "I taught you how" tail (menacing
  ambiguity; the clip resolves cleanly without it).
- Previous builder's planned cards violated the max-3-words rule in four
  places ("SHE IS NOT GONE", "SIX IN TWO YEARS", "YOU KILLED MY PARENTS",
  "THE CHILD WHO HID"); this build trims them to "SHE'S NOT GONE",
  "SIX IN TWO", "KILLED MY PARENTS", "CHILD WHO HID" (audible lines unchanged).
- Previous builder's corrupt `work/z1_a/v.mp4` was left untouched on disk and
  NOT reused; reframes were re-run to new filenames. A second restart drain
  killed the first manual-reframe run after z1_a only; the remaining three
  were re-run and verified (z1_a's completed file was probed and frame-checked
  rather than re-rendered).
- FIXES during QC of the new builds (both audio-only, video streams copied):
  (a) Z2's first final measured TP −0.99 (0.01 over) — −0.2 dB safety trim,
  re-measured I=−16.25 / TP=−1.18;
  (b) Z1's first final measured TP −1.00 (zero margin) — same −0.2 dB trim,
  re-measured I=−16.46 / TP=−1.22.
  RED needed no trim (I=−16.00 / TP=−1.55). Lesson: never encode AAC into a
  .wav container — the first Z2 trim attempt did that and produced a corrupt
  0.27s file; the trim was redone via PCM wav and verified before promotion.
- Final loudnorm (delivered files): Z1 I=−16.46 / TP=−1.22; Z2 I=−16.25 /
  TP=−1.18; RED I=−16.00 / TP=−1.55. Card silence −91.0 dB mean/max on all
  three. Null decode clean, frame counts exact (791 / 491 / 602).
- Final transcripts (Whisper base, delivered files): all complete, English,
  hooks in first 3s, payoffs before card, no mid-sentence cuts. Two known
  transcription limits, not edit damage: Z1's "Kira, wait / I'm going to get
  you" garbled as "Cure a weight" (minor line, no card uses it); RED's final
  "hid" heard as "hit me" (same class as wormhole's "Move!").

## Flags for the parent (judge, don't auto-approve)

- RED seg3 opens on a gun held to the man's temple (in-source, robot hand, no
  firing, no blood) — a step beyond aegis's handgun close-up; flagged here and
  in NOTES.md, not hidden. If it fails the family-safe bar, the fallback is
  the Prequel-Adrift overflow clip below.
- Aegis handgun close-up flag (from clips 1–3 verification) still stands.

## Still weak / honest gaps

- Group target was 5–6 clips; delivered 6. No padding was needed and no weak
  clip was added to hit the number.
- Weakest visuals, honestly: Z1's 3–10s no-speech camera move over the
  building/city (slowest beat); Z2's static 2.18s oscilloscope opener; RED's
  two close-up reaction shots are wider than the 472px window, so one eye sits
  at the frame edge in the man-reaction shot and the blonde close-up (one full
  glowing eye reads clearly in both, but neither shows both eyes complete).
- Overflow candidates scouted but NOT built (available if a clip is dropped):
  Prequel-Adrift 294.32–310.96 ("untested… Then I fight… What's one more
  enemy?", ~16.6s, strong) and Prequel-Adrift 242.48–266.68 ("This is not
  science. This is theft…", ~24.2s, also strong); UNSOLVED 188.34–208.46
  (Mary Celeste belongings / lifeboat beat, ~20s; same story as clip 2, so a
  near-duplicate risk).
- Edit-3 scouting (work/SCOUTING_HOLD.md) yielded 0 strong clean moments and
  was not built from, per the brief.
- Zeroed unused spans: no further strong moments (fragments, weak lines only).
