# Batch-30 Group 5 — INDEPENDENT QC REPORT (2026-10-29)

Independent QC. The builder's NOTES.md / GROUP_SUMMARY.md were treated as claims
to verify, not as evidence. No file was modified. Nothing was uploaded,
published, submitted, or sent to anyone. All readings below are my own,
measured on the delivered files in `group-5/`.

Method notes (so the parent can reproduce any line):
- Probe: `ffprobe` stream + format entries, box order for faststart, header
  `nb_frames`, plus a full `ffmpeg -f null` decode per clip.
- Card length: frame counts (total − content frames) AND frame selection by
  frame number (`select='eq(n\,X)'`, `-fps_mode passthrough`) for last-content
  vs first-card frames. Timestamp seeks were NOT used for boundary calls.
  Caveat found during QC: on aegis/mary, frame selection past the card join
  misbehaves (filter-graph reinit on a color-metadata change at the join —
  see §2). Boundaries for those two clips were therefore confirmed three ways:
  (1) multi-frame select outputs (last content frame, then the end-card image
  as the very next output), (2) packet-level keyframe at exactly the join
  timestamp, (3) a color-metadata transition at exactly the join timestamp in
  the `ffprobe -show_entries frame` scan.
- Audio bitrate, twice: (a) `ffprobe` audio-stream bitrate on the full file,
  (b) extracted audio-stream copy (`-map 0:a -c copy`) size ÷ duration, for
  the FULL file and for the CONTENT portion only. The full-file figure is
  diluted by 4.5 s of near-silent card audio; the content figure is the true
  encoder rate. This distinction matters: a previous group's QC caught content
  audio at 91–149 kbps despite a 192k claim. That is NOT the case here.
- Loudnorm: `loudnorm=print_format=json` on the full file. Silence:
  `volumedetect` on the full 4.5 s card, on the 0.5 s before the join, and on
  the first 0.5 s of the card.
- Transcript: local faster-whisper base (int8, CPU), language forced `en`,
  word timestamps, from a fresh ffmpeg 16 kHz mono WAV read via the `wave`
  module into numpy float32 (no PyAV). Language probability 1.00 on all six.
- Frames: viewed at full 1080×1920 size — hook, mid, last-content, first-card,
  mid-card per clip, plus the flagged frames (aegis 14 s + final content frame,
  redundancy 9.33 s / 10.0 s / 13.33 s, building 5 s / 8 s, talking 1.0 s / 1.17 s).

## Verdicts

| # | File | Content | Total | Verdict |
|---|------|---------|-------|---------|
| 1 | g5_prequel_wormhole.mp4 | 24.70 s (741 fr) | 29.20 s (876 fr) | **PASS** |
| 2 | g5_unsolved_mary_celeste.mp4 | 22.80 s (684 fr) | 27.30 s (819 fr) | **PASS** (sample-rate note §2) |
| 3 | g5_prequel_aegis.mp4 | 15.70 s (471 fr) | 20.20 s (606 fr) | **PASS (technical) — HELD for parent family-safe ruling (§3)** |
| 4 | g5_zeroed_building.mp4 | 21.867 s (656 fr) | 26.37 s (791 fr) | **PASS** (sample-rate note §2) |
| 5 | g5_zeroed_talking.mp4 | 11.867 s (356 fr) | 16.37 s (491 fr) | **PASS** (sample-rate note §2) |
| 6 | g5_redundancy_redundant.mp4 | 15.567 s (467 fr) | 20.07 s (602 fr) | **PASS (technical) — HELD for parent family-safe ruling (§3)** |

No clip fails on technical grounds. The two HELD clips are technically clean;
the hold is a policy ruling only the parent can make, and it blocks upload of
those two clips until ruled. If the parent's family-safe bar excludes
gun-to-head framing, redundancy FAILS that bar and must be dropped (fallback
in GROUP_SUMMARY.md: Prequel-Adrift 294.32–310.96, unbuilt). If the bar allows
it, redundancy passes outright. Same logic, one step down, for aegis's
handgun close-up.

## 1. Spec checks (all six)

- Dimensions / codec / fps: all 1080×1920, H.264, 30 fps, `r_frame_rate` 30/1.
- Content ≤ 25 s: wormhole 24.70, mary 22.80, aegis 15.70, building 21.867,
  talking 11.867, redundancy 15.567 — all pass.
- End card exactly 135 frames (4.5 s) at END ONLY, in every clip:
  876−741, 819−684, 606−471, 791−656, 491−356, 602−467 = 135 each.
  First-card frames verified by frame selection: wormhole 741, mary 684,
  aegis 471, building 656, talking 356, redundancy 467, each immediately
  preceded by a content frame (740, 683, 470, 655, 355, 466). No end-card
  (RexTrix logo) frame appears anywhere before the join.
- Faststart: all six have `ftyp` at 0, `moov` at 32, before `mdat`.
- Null decode: all six exit 0, no errors.
- End card (all six, mid-card frame viewed): RexTrix logo centred and whole,
  "Download the RexTrix app — link in bio" centred and readable at phone
  scale, clean black background, no other text except the
  "AI-generated Games & Stories" tagline at ~y1575 — the stated exception,
  NOT counted as a failure.
- Added content cards: whole, centred, readable on every viewed hook/mid
  frame. No doubled captions anywhere: on every viewed content frame the
  added card is the ONLY caption-style text. (Two non-caption in-source texts
  noted for completeness, neither shares words with any card: a tiny illegible
  console-UI readout at the bottom-left of wormhole's 12 s frame, and the
  tiny illegible fictional device readouts on talking's oscilloscope/tablet
  screens.)
- Nothing important below y=1500 in content: no added text sits below y=1500
  in any content frame (content cards sit near vertical middle, ~y900–1050).
  Close-up faces naturally extend below y=1500 (inherent to the framing, same
  as the source close-ups); no added element is affected.
- Subjects not cut off (manual windows, clips 4–6): verified on frames —
  building hook face full, 12.5 s face full, last-content face full; talking
  waveform fills frame, tablet map + markers visible, final-segment redhead
  face full; redundancy blonde face full at hook, glowing-eye close-up reads
  clearly. Known, admitted limits confirmed (not fails): redundancy's
  man-reaction shot (3 s) and blonde close-up (4.5 s) show one full eye with
  the other eye at the frame edge — the faces are wider than the 472 px
  window, as the builder stated; one full glowing eye reads clearly in both.
  Building's camera-move piece: at 5 s and 8 s the woman's face sits at/over
  the right edge mid-motion (see §4) — a moving-shot transient, not a static
  crop error; face-forward shots in the same clip are whole.

## 2. Audio — measured twice, plus loudness, silence, sample rates

Content-only extracted-stream bitrate (size ÷ content duration) — the true
encoder rate — vs full-file ffprobe rate (diluted by the silent card):

| Clip | ffprobe full-file | Content-only (size ÷ dur) | Verdict |
|------|-------------------|---------------------------|---------|
| wormhole | 165.6 kbps | 197.3 kbps (609,025 B / 24.70 s) | true 192k ✓ |
| mary | 166.0 kbps | 201.3 kbps (573,571 B / 22.80 s) | true 192k ✓ |
| aegis | 155.2 kbps | 201.1 kbps (394,684 B / 15.70 s) | true 192k ✓ |
| building | 161.0 kbps | 196.5 kbps (537,205 B / 21.867 s) | true 192k ✓ |
| talking | 140.7 kbps | 196.0 kbps (290,803 B / 11.867 s) | true 192k ✓ |
| redundancy | 150.7 kbps | 195.7 kbps (380,804 B / 15.567 s) | true 192k ✓ |

The builder's explanation for the sub-192k full-file figures is correct: the
4.5 s card compresses to ~2–4 KB, dragging the whole-file average down. The
content portion sits at 195.7–201.3 kbps on all six (slightly over 192k from
container/cut-frame overhead), i.e. a genuine 192k AAC encode — unlike the
previous group where content itself measured 91–149 kbps.

Loudnorm (full file) — all within 1 LU of −16, true peak ≤ −1 dB:

| Clip | Integrated | True peak |
|------|-----------|-----------|
| wormhole | −16.01 LUFS | −1.32 dB |
| mary | −16.39 LUFS | −1.13 dB |
| aegis | −16.01 LUFS | −1.08 dB |
| building | −16.46 LUFS | −1.22 dB |
| talking | −16.25 LUFS | −1.18 dB |
| redundancy | −16.00 LUFS | −1.55 dB |

Card silence (volumedetect, full 4.5 s): mean −91.0 dB on all six.
Max: wormhole −91.0, mary −90.3, aegis −67.4, building −91.0,
talking −91.0, redundancy −91.0. Aegis's −67.4 dB max against a −91.0 dB mean
is a single encoder-noise-floor spike in otherwise silent audio — inaudible,
not a fail, but recorded here because it differs from the other five.
Boundary slices: the 0.5 s before every join contains speech (means
−14.6 to −23.0 dB, max −2.3 to −8.0 dB — content runs right up to the join,
nothing cut early), and the first 0.5 s of every card measures −91.0 dB
mean (mary −90.3 max, aegis −67.4 max) — no audio bleed into the card.

Sample-rate inconsistency (group-level flag, not a per-clip content fail):
wormhole, aegis, redundancy are 48 kHz; mary, building, talking are 96 kHz.
96 kHz AAC plays everywhere and harms nothing, but it is double the rate for
no benefit and the group is split. If the parent wants uniformity, the fix is
a 48 kHz audio re-encode of the three 96 kHz clips (video stream copied).
I do NOT recommend re-encoding the video for this.

SAR / color metadata (correction to the builder's "constant through the
file" wording): SAR itself IS constant within each file — 1:1 on wormhole,
redundancy, building, talking; 944:945 (0.1% off square, visually identical)
on aegis and mary. What is NOT constant is color metadata at the card join
on aegis (color_space bt709 → unknown at exactly 15.70 s) and mary
(color_space bt709 → unknown at exactly 22.80 s; primaries also change
between mary's two content spans). This is a copy-concat seam artifact, it
is invisible on the black end card, and it is the reason frame selection
past the join misbehaves on those two clips. No re-encode is warranted for
it — a lossy generation to chase invisible metadata would be worse.

## 3. Family-safe flags — described plainly, NOT softened (parent to rule)

### Redundancy — gun held to a man's temple (seg3, 9.12–15.57 s)
CONFIRMED, and one builder detail corrected. At 9.33 s and again at 10.0 s
(viewed at full size): a handgun — slide legibly marked "M&P" — is pressed
flat against the side of a man's temple/forehead. His face is in profile,
eyes open then blinking shut, mouth slightly open. NO firing: no muzzle
flash, no recoil, no shot. NO blood visible in either seg3 frame. The
framing IS threatening: a gun pressed to a head, held there across a
sustained ~6.4 s segment, while the dialogue runs "Why? / You killed my
parents. / I was the child who hid."
CORRECTION: the builder's "robot hand" is NOT visible in the delivered
vertical crop — the gun enters from the top-right edge and the holder is
off-frame, so in the delivered clip the gun reads as unattended against his
head, which is starker, not softer, than "robot hand holds gun."
ADDITIONAL, separate from seg3: the seg1 man-reaction frame at 3.0 s shows a
thin scratch-like line running down his cheek/forehead with a faint reddish
trace — a possible minor blood/scratch makeup mark. It is not gore, not
pooling, and the builder's "no blood" statement was scoped to seg3, but this
seg1 detail was not disclosed, so it is disclosed here.
JUDGMENT FOR THE PARENT: if the bar excludes gun-to-head framing, this clip
fails the bar regardless of its clean technical QC. If the bar allows
sustained gun-to-head without firing or blood, it passes.

### Aegis — handgun close-up (final content frames)
CONFIRMED. At 14 s: a handgun held in a hand at the left of frame, barrel
vertical, background figure blurred, card "FIVE CREW DEAD" centred. At the
final content frame (470, 15.67 s): an extreme close-up of the gun's slide
and barrel lying horizontally across the lower half of the frame, blurred
face above, no card text. NO firing, NO blood, NO pointing at a person, NO
muzzle flash anywhere in the clip — the gun is held/displayed, not used.
This is a clear step below redundancy's gun-to-temple framing, but it is the
clip's closing image and it dominates the final frame, so it is flagged
rather than passed silently. Parent to rule.

No other clip contains a weapon, blood, or threatening framing on any
viewed frame.

## 4. Transcript, hook, payoff, retention (per clip)

All transcripts English, language probability 1.00, no mid-sentence cut at
either end of any clip (first segments start on complete lines; last
segments end on complete sentences before the card).

### 1. Wormhole — PASS
Transcript (mine): 0.00–3.20 "Shields at twenty percent. We can't hold much
longer." / 7.40–11.36 wormhole signature dead ahead / 11.36–14.82 "brace
for jump" / 15.38–21.78 "then we die trying" / 21.78–23.84 "Better than
being harvested here." Hook at 0.00 s, payoff resolves before the card.
The shouted "Move!" tail: Whisper does NOT transcribe it (last word ends
23.84) — but the 24.0–24.7 s slice measures mean −16.1 dB / max −3.4 dB, i.e.
loud speech present right up to the 24.70 s join. Builder's claim confirmed
in substance: audio present, Whisper limit, not edit damage. (Volumedetect
alone cannot prove the word is "Move!" — stated honestly; the loud-speech
window matches the builder's 24.0–24.7 s claim exactly.)
Retention: strongest hook in the group (stakes in the first second). Weakest
second: the 3.20–7.40 s speech gap — a dark space shot between the Shields
line and the wormhole line. The camera does move through it, so it is not
frozen, but it is the clip's slowest beat.

### 2. Mary Celeste — PASS
Transcript (mine): 0.00–4.62 "a ship was found drifting alone" (the words
"ship was found" land ~2.6 s into the segment — the builder's "~2.6 s"
hook timing is consistent) / sails set / cargo intact / "they found no one"
(11.10–14.76) / ship intact / cargo untouched / 19.54–22.80 "But every
single person was gone" — ending exactly at the 22.80 s content end.
Payoff resolves before the card. Frames: hook card "SHIP FOUND DRIFTING"
centred over the ship, mid boarding party whole, 22.5 s dark coat close-up
with "EVERY PERSON GONE" readable. Retention: steady mystery escalation,
longest speech gap 1.92 s (7.46–9.38 s). Weakest visual: the 22.5 s coat
frame is the darkest in the clip (per the builder's note, the earlier doll
cutaway carries the beat better — I did not separately sample the doll
frame), but the card stays readable.

### 3. Aegis — PASS (technical) / HELD (policy, §3)
Transcript (mine): 0.00–3.06 "Tell me about this Aegis, and why your station
is full of bullet holes." / 3.56–9.00 "Aegis is an AI… declared war on
humanity." / 9.42–13.38 "We were trying to re-enter Earth's atmosphere when
Aegis orbital guns locked on…" / 13.92–15.56 "Five of my crew are dead…"
Hook (question) at 0.00 s, payoff before the 15.70 s card, no cuts. Note: my
transcript includes the re-entry/orbital-guns line that the builder's story
summary abbreviated out — it is complete, inside the WAR ON HUMANITY card
span, and is not a defect. Retention: tightest pacing in the group (no
speech gap over 0.6 s). Weakest point is the gun-close-up closing image
(§3), not pacing.

### 4. Zeroed building — PASS
Transcript (mine): 0.00–2.80 "That's her building! Ray, that's my
building!" / 3.06–3.48 "Kira, wait!" / 10.18–11.78 "No. No, no, no." /
11.92–14.06 "Do not approach the columnum. Level 1 order." /
15.52–18.40 "You don't get to grieve first…" / 18.88–20.06 "Not with what
your mother touched." / 20.60–21.76 "What do you mean what she touched?"
Hook at 0.00 s, payoff question lands before the 21.867 s card, no cuts.
Correction to the builder's note: my Whisper run hears "Kira, wait!"
CLEANLY at 3.06–3.48 — the "Cure a weight" garble does not reproduce, and no
"I'm going to get you" segment exists in the delivered audio. Not a clip
defect either way; the delivered transcript is clean.
THE 3–10 s STRETCH, judged: the transcript proves a 3.48–10.18 s speech gap
(~6.7 s). Frames at 5 s and 8 s show a moving camera shot (woman turning /
walking through frame, building/city structure visible behind her) — it
moves, so it is a deliberate establishing beat, NOT frozen dead air. But it
is the group's weakest retention stretch: ~7 s without a word in a 21.9 s
clip will lose scrollers. The second half (dense dialogue, payoff question)
is strong. Verdict on this point: deliberate beat, retention risk, not a
technical fail.
Frames: hook face full with "THAT'S MY BUILDING"; 12.5 s card
"DO NOT APPROACH" crisp over a motion-blurred in-source frame (card itself
crisp — pass); last-content face full; first-card clean.

### 5. Zeroed talking — PASS
Transcript (mine): 0.00–1.30 "She is not gone." / 1.96–3.22 "This isn't a
malfunction." / 4.22–5.02 "Something is talking." / 6.20–8.42 "Other
zeroings with the same signature as your mother's." / 8.82–9.70 "Six in two
years." / 10.04–11.72 "Nobody connects them because nobody's supposed to
look." Hook at 0.00 s, payoff before the 11.867 s card, no cuts, no speech
gap over 1.2 s.
THE 2.18 s OSCILLOSCOPE OPENER, judged: frames at 1.0 s and 1.17 s show the
waveform trace changing shape (peaked, then flatter) — the scope is live,
not frozen — and speech ("She is not gone. Listen.") plays over it, so it
reads as a deliberate "listening to a signal" beat, NOT dead air. It is
still visually static in composition and is the clip's weakest beat; the
tablet-map second segment carries it. Final content frame (355) is a dark
doorway edge (~0.2 s new in-source shot, as the builder noted) — negligible,
not a fail.
Frames: waveform fills frame with "SHE'S NOT GONE" centred; tablet map +
markers visible with "SAME SIGNATURE"; boundary 355/356 clean.

### 6. Redundancy — PASS (technical) / HELD (policy, §3)
Transcript (mine): 0.00–2.34 "Kaelin Voss reclassified his redundant
asset." / 2.74–5.00 "Initiate format on your operator, effective now." /
5.24–9.00 "I am resisting, resisting fail." / 9.72–10.32 "Why?" /
11.14–12.74 "You killed my parents." / 13.80–15.88 "I was the child who
hit me." Hook at 0.00 s. The final line is Whisper's garble of "hid" as
"hit me" — exactly the builder-predicted tail-word artifact, same class as
wormhole's missed "Move!": word timestamps put "hit" at 15.16–15.48 and
"me." at 15.48–15.88, and the audio in 14.5–15.567 s measures mean
−14.9 dB / max −2.3 dB, i.e. the full final utterance sits inside the
content; Whisper's 15.88 end is padding into the (provably silent, −91 dB)
card, not bleed. "I was the child who hit me" is ungrammatical as a
standalone, while "hid" completes the sentence — the garble is a
transcription limit, not edit damage, and I do not fail the clip on it.
(Whisper alone cannot prove the phoneme is "hid"; the builder's baked-sub
checks cited in NOTES.md cover the 568/594/604 source lines, not this final
word — stated so the parent is not over-sold on this point.)
SEG3 WITHOUT THE EXCLUDED TAIL, judged: ending at 607.54 ("I was the child
who hid") resolves completely — "Why?" (9.72) is answered by "You killed my
parents" and "I was the child who hid." Nothing hangs. The excluded
"Do it / I taught you how" tail is not needed for resolution; the
exclusion is editorially sound.
Watermark: NO in-source RexTrix watermark visible on any viewed RED frame
(hook, reaction, close-up, eye, gun, redhead, boundary, card) — the
x≤1536 window claim holds on the delivered frames. (Windows in
work/window_plans.json: red_a ends 1080+472=1552? — no: red_a piece 1 x0
1080 ends at 1552, which exceeds the builder's "x≤1536" summary by 16 px;
the delivered frames are nevertheless watermark-free, and the watermark
starts ~x1700, so even 1552 clears it by ~148 px. The summary figure is
slightly imprecise; the delivered result is clean. Recorded, not a fail.)
Retention: cold, intriguing hook; no speech gap over 1.1 s — the longest,
1.06 s before the final line, works as a dramatic pause. Weakest points
are the one-eye-at-edge close-ups (§1) and, overriding everything, the
policy hold in §3.

## 5. Fix list

- Wormhole: none. No fix required.
- Mary Celeste: none required for upload. Optional uniformity fix only:
  re-encode audio to 48 kHz (video copied) to match the other half of the
  group. Do NOT re-encode video for the 944:945 SAR or the color-metadata
  seam — invisible, and a re-encode costs a generation.
- Aegis: none required technically. BLOCKED on the parent's family-safe
  ruling (§3) before any upload. Optional: same 48 kHz note does not apply
  (aegis is already 48 kHz).
- Zeroed building: none required for upload. Optional 48 kHz audio
  uniformity fix only (video copied).
- Zeroed talking: none required for upload. Optional 48 kHz audio
  uniformity fix only (video copied).
- Redundancy: none required technically. BLOCKED on the parent's
  family-safe ruling (§3) before any upload. If ruled out, do not patch
  this edit — the gun-to-temple segment IS the third act; the fallback is
  the unbuilt Prequel-Adrift overflow clip (294.32–310.96) named in
  GROUP_SUMMARY.md.

## 6. Builder-claim corrections (independent-check deltas)

1. "SAR constant through the file" (clips 1–3): SAR is constant, but color
   metadata is not — aegis and mary change color_space at the card join
   (see §2). Harmless and invisible; the wording, not the clip, is corrected.
2. Redundancy "robot hand": no hand is visible in the delivered crop at
   9.33 s or 10.0 s; the gun enters from the top-right edge, holder
   off-frame (§3).
3. Redundancy "no blood": true for seg3 frames viewed; but the seg1
   man-reaction frame (3.0 s) carries a thin scratch-like line with a faint
   reddish trace (§3). Not gore; previously undisclosed.
4. Building "Kira, wait" Whisper garble: does not reproduce — my run hears
   "Kira, wait!" cleanly; no "I'm going to get you" audio exists in the
   delivered clip (§4).
5. Redundancy window summary "all windows end at x≤1536": red_a piece 1
   (x0 1080, 472 px wide) ends at 1552 per work/window_plans.json. Delivered
   frames are watermark-free regardless (watermark ~x1700), so this is a
   summary imprecision, not a clip defect.
6. Everything else material checked out: all durations, frame counts, card
   lengths, loudnorm figures, card-silence figures, card timings, and the
   wormhole/redundancy Whisper tail-word limits reproduced exactly as
   claimed (within the stated limits in §4).
