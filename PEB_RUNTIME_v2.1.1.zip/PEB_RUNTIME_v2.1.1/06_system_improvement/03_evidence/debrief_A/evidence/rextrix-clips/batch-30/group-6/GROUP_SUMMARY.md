# Batch-30 Group 6 — GROUP SUMMARY

## Delivered: 6 clips (target 5–6 met, no padding)

All in `/home/hatch/workspace/rextrix-clips/batch-30/group-6/` as
`g6_<slug>.mp4` (versioned renders kept alongside: fall v1/v2/v3, others v1).
Every clip: 1080x1920, 30fps, libx264 slow CRF 16, yuv420p, AAC 192k,
faststart, content + exactly 4.5s silent RexTrix end card at END ONLY
(card source verified 4.500s, used as-is). Nothing uploaded, published,
submitted, or sent anywhere.

| Clip | Source window | Total | Audio I / TP | Verdict |
|---|---|---|---|---|
| g6_dog_fall.mp4 (v3) | DOG ep1 102.8–117.3 | 19.0s | -16.14 / -1.35 | PASS — best hook in group |
| g6_dog_chase.mp4 (v1) | DOG ep1 136.8–150.0 | 17.7s | -16.05 / -4.44 | PASS |
| g6_dog_map.mp4 (v1) | DOG ep1 325.0–338.1 | 17.6s | -16.06 / -1.31 | PASS — cleanest audio |
| g6_mutant_night.mp4 (v1) | Mutant ep1 66.6–77.2 | 15.1s | -15.83 content / -1.29 | PASS |
| g6_mutant_glow.mp4 (v1) | Mutant ep1 101.33–109.0 | 12.2s | -16.03 content / -1.42 | PASS — tightest card/shot sync |
| g6_mutant_creature.mp4 (v1) | Mutant ep1 297.83–306.6 | 13.3s | -15.93 content / -1.37 | PASS |

(I = LUFS integrated; night/glow/creature I quoted content-only because the
4.5s silent card dilutes full-file integrated loudness — full-file figures
are in NOTES.md. All TP ≤ -1 dB. All cards silent at -91 dB beyond the
first 0.1s; inaudible boundary blips ≤ -64 dB on night/glow/creature, and a
single ≤1-frame transient on fall v3 — see NOTES.md.)

## What passed
- All six: probe (dims/fps/codec/duration), ffmpeg null decode, loudnorm,
  card silence, hook/mid/card frames (cards whole + centered + readable, no
  doubles, end card clean, nothing important below y=1500), English
  transcript check (no dialogue in clips by design — see below), hook in
  1–3s, payoff before card.
- Both downloads tool-verified by exact byte count against the survey
  manifest. No BLOCKED downloads.

## What was fixed
- **Baked subtitles on both shows**: every dialogue scene in both ep1s
  carries burned-in subtitles. All six clips were rebuilt from verified
  speech-free windows only (frames checked subtitle-free) with our own cards
  — no caption doubling anywhere. Consequence: all six clips are
  visual/music-only; there is no speech to enhance and no Demucs work was
  needed (single source music/SFX bed per clip).
- **Fall audio, twice**: v1 TP -0.85 + 0.2s card tail → v2 (alimiter + exact
  atrim) → v3 (alimiter 0.85 remux, video copy): TP -1.35, card silent.
- **Chase assemble**: first attempt failed on an empty afade parameter
  (operator patched the build script while the chain was executing it —
  lesson recorded in NOTES.md); retry OOM-killed under 8 GB VM pressure
  (~14 concurrent ffmpegs); final retry with `-threads 1` succeeded.
- **Mutant download**: first curl died silently at 131 MB; resumed with
  `curl -C -`, verified by exact byte count (503,041,313).
- **Mutant chain shell died once** after the night trim with no error trail;
  re-ran with logging; all three Mutant builds then completed.
- **Card-boundary transients**: afade tail (last 0.1s) + exact atrim +
  volume gate added to the assemble chain; map/chase/night/glow/creature
  cards measure silent including the boundary slice (fall v3 predates the
  afade fix and keeps one ≤1-frame transient — disclosed, not hidden).

## What is still weak (honest list)
- Dog clips are upscaled from the 608x1080 saliency-crop (landscape source)
  to 1080x1920 per the task spec — slightly softer than native-vertical
  Mutant clips. Nothing important is lost; faces/action stay dominant.
- Fall v3: single ≤1-frame boundary transient at the card join (see above).
- Glow is the shortest clip (7.67s content); carried by beat density.
- Chase aerial wide is slightly distant in vertical crop; still reads at
  phone size.
- No dialogue-driven clips exist in this group (baked-subtitle rule). The
  strongest unused dialogue lines are listed in NOTES.md under "Gaps" if a
  future brief allows baked-sub-only clips.
- Family-safety: no sexual content, no blood/gore in any delivered clip.
  (Dog train-car bullet holes are set dressing, no gore shown.)

## Per-clip detail
See NOTES.md (sources + exact timestamps, cards + timings, audio readings,
what was fixed, weakest point per clip).
