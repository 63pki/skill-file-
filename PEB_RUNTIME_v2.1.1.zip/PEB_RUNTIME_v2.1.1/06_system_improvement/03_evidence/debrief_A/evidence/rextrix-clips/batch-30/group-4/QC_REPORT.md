# Batch-30 Group 4 — INDEPENDENT QC REPORT (not the builder)

- QC date: 2026-10-29 (evening PKT). QC agent did NOT build these clips.
- Scope: the six `g4_*.mp4` deliverables in this directory only. No file was
  modified, uploaded, published, submitted, or sent to anyone.
- Method note on two measurements (read before the verdicts):
  1. **Audio bitrate — full-file average CANNOT be 192 kbps on a clip with a
     silent end card, by arithmetic.** Silence encodes at ~4 kbps. Every clip's
     content-only audio measures 194.5–195.7 kbps (true 192k nominal, ffmpeg
     AAC slightly over), and the full-file average is exactly the
     content/silence weighted mean (e.g. prison: (195.7×10 + ~4×4.5)/14.5 =
     136.2, which is the measured full-file figure). The encoder setting in
     `work/build_g4_v2.py` is `-b:a 192k`. Judging the content rate is the
     correct test; a literal "full-file average must be 192k" would fail any
     correctly built clip with a silent card. Content rates pass on all six.
  2. **End-card frame selection.** The task's frame-selection method fails at
     the content/card join on these files for a real technical reason: the
     content segment is bt709 and `card_v` is colour-space "unknown", so the
     filter graph reconfigures at the join and `select eq(n,…)` returns
     nothing past the join. I instead proved the card by (a) full-sequence
     extraction for prison (frames 1–435, boundary exactly between f0300 last
     content and f0301 first card), (b) pixel-identity: prison f0301 MD5 =
     `card_v` frame 0, prison card-mid MD5 = `card_v` frame 67, and all five
     other clips' card-mid frames are MD5-identical to each other, and
     (c) total-frame arithmetic (below). The card is `card_v` on all six.
  3. **Loudness figure judged is content-only** (atrim to content duration),
     matching the builder's own "Content I" column. It reproduces the
     builder's content-I values exactly (to 0.01 LU) on all six, which
     cross-validates the method. Full-file loudnorm on the shortest clip
     (prison) reads −17.42 because the 4.5 s of digital silence shifts that
     filter's integrated figure on a 10 s clip; the content viewers actually
     hear is −15.99. True peak is identical content vs full on every clip,
     confirming the tail adds nothing.

## Verdicts — 6/6 PASS, no fix list

| Clip | Total (frames) | Content + card | Content I / TP | Content audio | Card tail | Verdict |
|---|---|---|---|---|---|---|
| g4_divorce_prison.mp4 | 14.50 s (435) | 10.00 + 4.50 | −15.99 / −5.08 | 195.7 kbps | mean −91.0 dB, smear −56.5 dBFS in first 50 ms only, then exact zero | PASS |
| g4_divorce_heir.mp4 | 23.00 s (690) | 18.50 + 4.50 | −16.05 / −1.46 | 195.5 kbps | mean −91.0 dB, smear −60.5 dBFS in first 50 ms only, then exact zero | PASS |
| g4_primal_shark_charge.mp4 | 19.97 s (599) | 15.47 + 4.50 | −16.65 / −1.64 | 195.4 kbps | mean −91.0 dB, smear −82.2 dBFS in first 50 ms only, then exact zero | PASS |
| g4_primal_roar_siege.mp4 | 20.50 s (615) | 16.00 + 4.50 | −16.06 / −3.46 | 194.5 kbps | mean −91.0 dB, smear −67.4 dBFS in first 50 ms only, then exact zero | PASS |
| g4_primal_gets_up.mp4 | 22.47 s (674) | 17.97 + 4.50 | −16.09 / −3.23 | 195.3 kbps | exact digital zero throughout (see note) | PASS |
| g4_primal2_tiny_life.mp4 | 20.50 s (615) | 16.00 + 4.50 | −16.51 / −2.94 | 195.4 kbps | mean −91.0 dB, smear −65.7 dBFS in first 50 ms only, then exact zero | PASS |

All six: 1080×1920, 30 fps, H.264 High, yuv420p, AAC 48 kHz stereo,
faststart (moov before mdat, verified by atom parse), full null-decode OK,
content ≤ 25 s, end card exactly 135 frames at END ONLY, no added card
anywhere else (verified on hook/mid/card frames + ASS timings in `work/*.ass`).

Frame arithmetic (total − 135 = content frames): prison 435−135=300 (10.00 s);
heir 690−135=555 (18.50 s); shark 599−135=464 (15.47 s); roar 615−135=480
(16.00 s); gets_up 674−135=539 (17.97 s); tiny 615−135=480 (16.00 s).
Gets_up/shark totals differ from the rounded durations by 0.004/0.003 s
(674/30 = 22.467, 599/30 = 19.967) — rounding only, not a defect.

## Quarantine check — PASS

- Delivered MD5s differ from every quarantined v1 file: heir delivered
  `3e209f4e…` vs v1-defective `651487c6…`; tiny delivered `912fb5ec…` vs
  v1-quiet `836ca0f3…`; shark delivered `af9b380f…` vs v1-TP-tail
  `b2419104…`.
- The five `*.CORRUPT_*` files in `work/` genuinely fail probing with
  "moov atom not found" — the quarantine labels are real, and none of those
  files is among the six deliverable names.
- No deliverable is a copy of a corrupt segment: all six null-decode clean.

## Per-clip evidence

### 1. g4_divorce_prison.mp4 — PASS
- Probe/decode: 435 frames, decode OK, faststart OK.
- Audio: content 195.7 kbps (ffprobe stream 134.0 kbps full-file = dilution,
  see method note); content I −15.99 (within 0.01 of −16), TP −5.08.
  Tail: volumedetect mean −91.0 / max −59.2 dB; sample-level: first-50 ms
  smear −56.5 dBFS, exact zero thereafter. Boundary slice (0.5 s either side
  of 10.00 s) is loud content ending (−3.8 dBFS max) then silence — the
  card itself is silent; the 0.05 s fade-out did its job, no audible overhang.
- Frames (by frame number): hook frame 30 shows baked "need a prison
  reservation?" (speech starts clip ~0.14 s — hook is immediate, not late);
  frames 87 (2.9 s), 97 (3.23 s), 105 (3.5 s), 120 (4.0 s) all show added
  "SHE TAKES CONTROL" whole, centred (~y960), readable, with NO baked
  subtitle visible at any of them; precard frame 300 shows the payoff baked
  line "are you crazy cutting off our fuel supply" with shocked reaction;
  frame 301 is the RexTrix end card, whole and centred, "Download the
  RexTrix app — link in bio" + "AI-generated Games & Stories" tagline.
- Transcript (faster-whisper small, own run): English only, 3 segments —
  "Need a prison reservation?" 0.0–1.94, "Are you crazy?" 6.04–7.60,
  "Cutting off our fuel supply?" 8.10–9.74. Ends 0.26 s before the 10.00 s
  cut: complete thought, no mid-sentence cut at either end (clip starts
  before speech). Hook lands immediately; payoff resolves before the card.
- Gap check (honest): my full-clip run finds NO speech in the 1.94–6.04 s
  gap. A windowed run on clip 2.0–6.0 s hallucinated generic closings
  ("Thank you for watching." with zero-duration words, "Have a good day.",
  "Bye.") — that is a Whisper-on-music hallucination signature, NOT reliable
  evidence for the builder's quiet "Thank you." at ~119.9 s source
  (clip ~2.9 s). What IS verified: RMS in the gap bumps at clip 3.0–3.5 s
  (−16.8 dB, vs −24 dB around it), so something audible happens there, but
  no frame in the gap shows a baked subtitle, and the card words
  SHE/TAKES/CONTROL share no word with THANK/YOU under either reading.
  The no-double conclusion passes regardless of whether the quiet line's
  exact words are "Thank you." — the builder's wording claim itself is
  NOT independently confirmed by my audio/frame evidence, and I do not
  pretend otherwise.
- Retention: hook strong; weakest second ~4–5 s (phone close-up, no
  dialogue, card only). Shortest clip (10 s content) — payoff is the
  question + reaction, card does the framing.

### 2. g4_divorce_heir.mp4 (v2) — PASS
- Probe/decode: 690 frames, decode OK, faststart OK.
- Audio: content 195.5 kbps; content I −16.05, TP −1.46 (inside the −1
  ceiling with 0.46 dB margin — the tightest TP in the group, but passing).
  Tail: mean −91.0 dB; sample-level smear −60.5 dBFS in first 50 ms only,
  then exact zero.
- Frames: hook frame 60 shows baked "think you deserve my family 's
  alimony" (first speech clip ~1.18 s, hook in 1–3 s ✓); frame 201 (6.7 s)
  shows "THE DOCUMENT" ALONE over the judge holding the document, NO baked
  sub — this is the v2 window (5.6–7.8), and it proves the delivered file
  is v2, not the quarantined v1; frame 277 (9.23 s) shows the baked line
  "your honor, this is notice document no. RO037" ALONE, no added card —
  the v1 overlap (shared word DOCUMENT) is gone; frame 525 (17.5 s) shows
  "SOLE HEIR" ALONE over documents/gavel, no baked sub. End card (seek
  frame, MD5-identical to the other clips' card frames) whole, centred,
  readable.
- Transcript: English only, 4 complete segments — "I think you deserve my
  family's alimony." / "Take this and get out of New York." /
  "Your Honor, this is Noticized Document Noro Zero Three Seven." /
  "Ms. Victoria Pemberin is the sole surviving heir." ending clip 15.18.
  (Whisper pads the first word's start to 0.0; the audible first word is
  at clip ~1.18 s, so there is no mid-sentence cut at the start.)
  The 5.5 s → 34 s scene jump is a hard courtroom cut, as disclosed.
- Tail check: windowed run on clip 15.0–18.5 s finds ONLY "hair."
  0.0–0.22 s — the tail of "heir" (source ~43.5–43.7 s), exactly the
  builder's fragment. Frame 450 (15.0 s) shows the baked "…sole surviving
  heir" line with courtroom reaction. No new sentence starts after
  15.18 s; the 18.5 s cut lands on music/reaction, NOT mid-sentence. ✓
- Retention: hook strong; weakest stretch is the 15.18–18.5 s reaction
  tail (no speech, documents close-up + SOLE HEIR card at 16.5–18.3 s)
  and the hard scene jump at 5.5 s. Payoff (the heir reveal) resolves
  well before the card.

### 3. g4_primal_shark_charge.mp4 — PASS
- Probe/decode: 599 frames, decode OK, faststart OK.
- Audio: content 195.4 kbps; content I −16.65 (0.65 LU from −16, within
  1 LU), TP −1.64. Tail: mean −91.0 / max −84.3 dB; sample-level smear
  −82.2 dBFS in first 50 ms only, then exact zero — the v1 0.03 s
  overhang is GONE; no audible overhang remains.
- Frames: frame 45 (1.5 s) "MACHINE SHARK" over jaws filling the frame —
  strong hook, readable; frame 150 (5.0 s) "CHARGING REX" is sharp and
  readable over a heavily motion-blurred charge frame (source motion, not
  a crop defect — the card itself is fully legible at phone scale);
  frame 240 (8.0 s) mid-chase prey rear view is coherent with blurred
  foreground grass (motion, not a defect); frame 405 (13.5 s)
  "FACE TO FACE" over a sharp, whole Rex face, readable. No baked subs
  anywhere (PM1 has none) — no doubles possible.
- Transcript: 0 segments — dialogue-free, confirmed. Visual-led clip;
  cards carry the hook (jaws at 0.5 s, charge, face-to-face payoff).
- Retention: hook very strong; weakest second ~5 s (blurred charge
  frame). In motion the charge reads; as a still it is the group's
  weakest single frame, but it is not a fail — the card is legible and
  the blur is source motion.

### 4. g4_primal_roar_siege.mp4 — PASS
- Probe/decode: 615 frames, decode OK, faststart OK.
- Audio: content 194.5 kbps; content I −16.06, TP −3.46. Tail: mean
  −91.0 / max −70.3 dB; sample-level smear −67.4 dBFS in first 50 ms
  only, then exact zero.
- Frames: frame 60 (2.0 s) "OUTNUMBERED" over Rex vs the machine army
  line — Rex body foreground-right is partially out of frame by reframe
  composition, but the army line and the Rex-vs-line setup read clearly;
  frame 210 (7.0 s) "HE ROARS ANYWAY" over a cannon barrel close-up —
  abstract as a still (as disclosed), reads in motion as a gun swinging
  onto target, card readable; frame 390 (13.0 s) is the source targeting
  sensor/lens close-up (show content, not added UI); frame 450 (15.0 s)
  "SURROUNDED" sits ABOVE the red reticle on Rex's chest with no overlap,
  card whole and readable, front Rex sharp. No baked subs — no doubles.
- Transcript: 0 segments — dialogue-free, confirmed.
- Retention: hook strong (outnumbered setup); weakest seconds ~7 s
  (cannon close-up) and ~13 s (sensor close-up), both abstract as
  stills but coherent in motion. No dead air; the siege action is
  continuous.

### 5. g4_primal_gets_up.mp4 — PASS
- Probe/decode: 674 frames, decode OK, faststart OK.
- Audio: content 195.3 kbps; content I −16.09, TP −3.23.
  Tail: **better than the builder claimed.** Builder disclosed card-tail
  MAX −55.3 dB ("AAC smear, effectively silent"). On the delivered file,
  sample-level analysis shows EXACT DIGITAL ZERO throughout the entire
  4.5 s tail (volumedetect −91.0/−91.0, the filter floor), and the
  boundary slice (17.47–18.47 s) is loud content (−4.7 dBFS max) up to
  17.97 s then silence. The −55.3 figure must have come from a
  boundary-inclusive window or an intermediate; whatever its origin, the
  delivered card is perfectly silent. PASS on the silent-card rule with
  margin, not on a technicality.
- Frames: frame 90 (3.0 s) "KNOCKED DOWN" over the downed, rolling Rex —
  the head IS at the left edge and the snout tip IS cropped (as
  disclosed), but the head profile, open mouth, eye region and the whole
  dominant body read clearly, and in motion the head rolls through the
  frame; this is a transient rolling position, not a failing crop of a
  static subject. Frame 270 (9.0 s) downed Rex foreground + machine in
  dust — the slowest beat, no card on screen, but dust/camera motion is
  present. Frame 480 (16.0 s) "HE GETS UP" over the rising head/eye,
  dominant and readable. No baked subs — no doubles.
- Transcript: 0 segments — dialogue-free, confirmed.
- Retention: hook good (knocked-down fall + card at 2.5 s); weakest
  second ~9–10 s (downed Rex, no card, dust motion only). Payoff (rising
  head/eye + HE GETS UP) resolves before the card.

### 6. g4_primal2_tiny_life.mp4 — PASS
- Probe/decode: 615 frames, decode OK, faststart OK.
- Audio: content 195.4 kbps; content I −16.51 (0.51 LU from −16, within
  1 LU), TP −2.94. Stereo sample peak 0.713 (−2.94 dBFS, exactly the
  true peak); ZERO samples ≥ 0.9; only 217 samples at/above the 0.70
  limiter threshold, longest run ≥ 0.69 is 53 samples (~1.1 ms) — no
  clipping, no sustained flat-topping. The +11 dB gain on a quiet source
  did NOT produce measurable distortion artifacts beyond honest source
  limits. (An early mono-downmix peak of −0.2 dBFS was a downmix
  artifact — channels summing in the mix — not clipping in the
  delivered stereo file, and is not a finding.)
  Tail: mean −91.0 / max −67.4 dB; sample-level smear −65.7 dBFS in
  first 50 ms only, then exact zero.
- Frames — reframe fix VERIFIED: frame 45 (1.5 s) "THE GIANT" over the
  giant ape's face, eye dominant — NOT shoulder-only (the v1 defect is
  gone; the nose tip touches the right edge but the face is dominant);
  frame 120 (4.0 s) tiny face close-up, whole face, eyes/mouth clear;
  frame 270 (9.0 s) baked "you're so small" ALONE, no added card, and
  neither added card shares a word with it (THE/GIANT, A/TINY/LIFE vs
  YOU'RE/SO/SMALL); frame 369 (12.3 s) dark fur passage, no face, NO
  card on it (as designed — card starts 13.0 s); frames 420 (14.0 s)
  and 450 (15.0 s) "A TINY LIFE" over the tiny cradled by the giant,
  tiny visible and whole (face, body, foot) — the payoff frame works.
  The tiny is at the left edge in profile at 14–15 s but is whole and
  readable, not cropped out.
- Transcript: exactly 1 segment, English — "You're so small." 6.94–9.58 s,
  matching the baked sub at ~9 s. It sits between the two cards
  (0.5–3.0, 13.0–15.5) with no overlap and no shared words. The clip is
  otherwise visual-led; the giant-face hook lands at 0.5–1.5 s.
- Retention: hook strong (giant face + THE GIANT at 0.5 s); weakest
  second ~12.3 s (dark fur, no face, no card) — a ~1 s passage immediately
  before the payoff, mitigated because the card starts only after the
  tiny reappears. No dead air beyond that passage.

## Cross-cutting observations (not fails)

- **Added cards:** all whole, centred (~y960, ASS Alignment 5), white
  with black outline, readable at phone scale on every frame checked,
  ≤ 3 words each, chunked at phrase boundaries. No doubled captions
  anywhere: no added card ever shares a word with a baked subtitle
  visible at the same moment (checked frame-by-frame at every card
  window, including the heir v2 window and the prison gap).
- **y=1500 — one measurement to be aware of, not a fail.** Source-baked
  subtitles in the divorce clips are centred at about y1500 (measured:
  the heir "…sole surviving heir" block centres at y≈1500, so its
  second line extends slightly below). That is the source show's own
  subtitle placement, unmovable without re-cropping the show, and the
  brief explicitly relies on baked subs to carry the divorce payoffs.
  All ADDED cards sit at y≈960, well clear, and the only below-1500
  element I am asked to except — the end card's "AI-generated Games &
  Stories" tagline at ~y1575 — is present and correct. If y1500 were
  applied strictly to source-baked subs, both divorce clips would need
  a different source treatment; that is a batch-level source decision
  for the parent, not a group-4 build defect, and I do not fail the
  clips for it.
- **No frozen/static windows** were observed in any viewed frame set
  (distinct shots at hook/mid/card/precard on all six); I did not
  re-run the builder's mean-abs-diff motion check, so this is a
  frame-based observation, not a re-measurement.
- **Sample rates** are consistent: 48 kHz stereo on all six.
- **Builder claims that checked out exactly:** all six content-I/TP
  pairs (to 0.01 LU/dB), all card timings in `work/*.ass` (verified on
  frames), the heir v2 window, the tiny reframe fix, the shark
  overhang fix, the gets_up head-edge description. Two builder
  statements did NOT reproduce literally but the delivered files are
  as good or better: gets_up tail is digital zero, not −55.3 dB max;
  and the "Thank you." wording in the prison gap is not confirmed by
  my transcript/frames (see prison note) — but the no-double
  conclusion it supported holds either way.
- **No fix list.** Nothing in this QC requires a rebuild. The only
  items for the parent are the two judgment notes above (baked-sub
  y1500; prison-gap wording unconfirmed but no-double passing) — both
  are disclosed, neither blocks a PASS.

## Files

- This report: `QC_REPORT.md` in this directory (group-4/).
- Deliverables verified (unchanged): the six `g4_*.mp4` files in this
  directory.
