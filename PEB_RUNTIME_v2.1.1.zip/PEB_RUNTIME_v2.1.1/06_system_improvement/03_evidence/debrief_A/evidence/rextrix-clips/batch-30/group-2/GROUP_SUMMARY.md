# Batch-30 Group 2 — GROUP_SUMMARY.md

## What was delivered

6 clips, all from the three NEW shows, all self-QC'd (probe, null decode, loudnorm,
card silence, hook/mid/card frames, transcript/baked-sub check). Nothing was uploaded,
published, submitted, or sent to anyone.

| File | Show / window | Total | Loudnorm I / TP | Verdict |
|---|---|---|---|---|
| g2_apoc_24hours.mp4 | Apocalypse 288-302 | 18.5 s | -16.63 / -1.27 | PASS |
| g2_apoc_died_three_times.mp4 | Apocalypse 338-353.2 | 19.7 s | -15.22 / -1.68 | FIXED 2026-10-30, pending independent re-QC (was FAIL: mid-sentence end cut) |
| g2_apoc_built_not_disaster.mp4 | Apocalypse 373-391 | 22.5 s | -16.90 / -2.44 | PASS |
| g2_feed_moth_city.mp4 | Feed 196-220 | 28.5 s | -15.61 / -1.17 | PASS (v2) |
| g2_feed_title_drop.mp4 | Feed 372-396.9 | 29.4 s | -16.21 / -1.11 | PASS |
| g2_hells_guard_hungry.mp4 | Hell's Army 239-255 | 20.5 s | -16.17 / -1.44 | PASS (v2) |

All six: 1080x1920, 30 fps, h264/AAC, 4.5 s silent end card at end only, card means
-91 dB (AAC silence floor). All integrated loudness within 1 LU of -16; all true
peaks ≤ -1 dB in the delivered files. Clip 2 was rebuilt 2026-10-30 after failing
independent QC (see "What was fixed" item 5); its PASS is NOT claimed until
independent re-QC says so.

## What passed outright

- The Apocalypse dialogue trio: three complete, hook-first exchanges, each with
  frame-verified baked subtitles and word-audited cards.
- The Feed title drop: the episode's closing baked text sequence, carried cleanly
  through the pillarbox with no added card competing against it.
- The Hell's Army exchange: clean window, three frame-verified baked lines, cards
  that share no word with any concurrent line.

## What was fixed

1. Card-boundary audio transient: v1 of clip 1 showed a -38.5 dB single-sample peak
   in the first 0.5 s of the end card. A 50 ms post-loudnorm fade-out on content
   audio was added to the build; boundary peaks are now -58 to -81 dB.
2. True-peak overshoot (2 clips): moth v1 TP -0.64 dB, hells v1 TP -0.98 dB — both
   past the -1 dB limit because AAC encoding overshoots the loudnorm -1.0 dB target
   on music/transient-driven audio. Both were rebuilt with a -1.5 dB loudnorm TP
   target (video unchanged, frames re-verified). The failed v1 files are kept in
   work/ with `tpFAIL` names for audit; they are NOT deliverables.
3. Scouting corrections (both caught before cutting, not after):
   - Feed was first thought to have no baked subtitles; 1 fps frame checks proved
     it does in dialogue moments (and the closing title text is baked). All Feed
     cards were word-audited against frame-verified subs, not against the
     "no subs" assumption.
   - Hell's Army Whisper output was garbled; no Whisper line was quoted. All hells
     dialogue comes from baked subtitles read on frames.
4. Built-clip encode failures (5 kills, then success): the 18 s Apocalypse clip's
   encode was killed 5 times — twice at threads 4, once at threads 2, once at
   threads 1, once tracked — while sibling batch groups ran 7-16 concurrent
   1080x1920 slow encodes on an 8 GB machine with no swap (available memory
   repeatedly under 1 GB, once 176 MB). A 5 s ultrafast test of the same segment
   succeeded, proving the segment and pipeline were sound. The delivered file is
   a clean single encode that succeeded in a high-availability window (≥1.8 GB
   free) with threads 4. Lesson recorded: threads count does not reduce x264 slow
   memory at 1080p (threads-1 still used ~970 MB RSS) — speed (short exposure)
   and a free-memory window matter more than thread count.

5. Mid-sentence end cut, clip 2 (independent QC FAIL, fixed 2026-10-30, pending
   re-QC): the 338-352 build cut inside "I've watched the sky for 30 years" — the
   line was on screen at the 352.0 s cut and speech was active across it, and the
   old NOTES dialogue list ended a line early. Rebuilt as Apocalypse 338-353.2
   (15.2 s content + 4.5 s card = 19.7 s, 591 frames) with the identical pillarbox +
   top-bar treatment, cards and timings; the content now ends in the pause after
   "years" completes (~353.0-353.2 s, source tail -30.5 dB) and before "if it comes
   it'll be red" (~353.5 s). Fix-build self-measurements: loudnorm I -15.22 /
   TP -1.68, content-only audio 194.4 kbps, card mean -91.0 dB / boundary peak
   -78.3 dB, null decode clean, end card frames 456-590, last content frame n=455
   shows the completed final line whole. The pre-fix file is kept in
   work/pre-fix/g2_apoc_died_three_times_midcut.mp4; the work build is
   work/g2_apoc_died_three_times_fix2.mp4. NOTES.md Clip 2 corrected (final line
   added, new window/duration/readings). No PASS claimed for clip 2 until
   independent re-QC. The alternative trim to ~351.3 s was NOT used — the extension
   proved possible, so the payoff is kept.

## What is still weak (honest)

- Pillarbox deviation: landscape clips use pillarbox + top-bar cards, not the
  brief's centered-Y-50% cards, because a 9:16 crop would slice baked subtitles.
  This is a documented deviation with a stated reason, not a silent change.
- Moth creature design: the Feed moth is a nude-stylized humanoid. Only distant /
  front shots are used; the 260 s close-up was avoided. If the coordinator wants
  zero humanoid-body shots, drop clip 4 — the other five stand alone.
- Hells centered card crowds the confrontation framing at 2 s (sits between the
  two faces over the background wagon). Faces stay readable; it is a composition
  compromise of the centered-card spec, not a defect.
- Died clip's "SHE CAME BACK" and close clip's "SOMETHING SURVIVED" are interpretive
  glosses of adjacent dialogue, not quotes. Both are accurate to the immediately
  surrounding lines and are flagged as such in NOTES.md.
- Loudness: clip 2 (-15.22 after the fix rebuild) and clip 4 (-15.61) sit ~0.4-0.8 LU
  above -16; clip 3 (-16.90) sits ~0.9 LU below. All are within the "~-16 LUFS"
  tolerance, but a strict ±0.5 LU gate would flag clips 2 and 3. No further
  normalization was applied because re-normalizing would re-risk the true-peak
  margin that was just fixed.
- The full-Feed word-timestamp job (faster-whisper small over all 397 s) died
  under the same memory pressure and was not restarted: the targeted samples
  (180-260 s moth window, 340-397 s closing window) already covered every window
  that was cut. No clip depends on the missing middle word timestamps.

## Gaps

- None against the 5-6 target: 6 strong clips delivered.
- No gap-fill from Toilet Knight / Strawberry was needed or used.
- No downloads blocked.
