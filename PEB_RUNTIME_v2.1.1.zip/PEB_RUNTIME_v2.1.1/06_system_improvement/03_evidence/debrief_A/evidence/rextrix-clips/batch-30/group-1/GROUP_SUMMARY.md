# Batch-30 Group 1 — Summary

6 clips built, 0 dropped. All pass the shared spec: 1080x1920, 30fps,
h264, AAC 192k, faststart, ffmpeg null-decode clean, end card exactly
4.5s silent at END ONLY, hook card whole/centered/readable on final
frames, no doubled captions, no mid-sentence cuts, no invented claims.
Final audio: every clip within 1 LU of -16 LUFS integrated, true peak
≤ -1 dB, end-card window effectively silent (mean -91 dB everywhere).

## What passed on first build
- Neon: levels, silence, frames all clean on v1 (no fix needed).
- All six hook cards: whole, centered, readable at Y 50% on final frames.
- All six end cards: clean RexTrix logo + "Download the RexTrix app —
  link in bio" frame, silent.
- All six transcripts: complete thoughts, English, hook card visible in
  the 1–3s window, payoff before the card.

## What was fixed (all re-verified after fixing)
- Survival: first final was a partial write (aborted build, missing
  moov atom) — rebuilt in full; 0.2s end-fade added for card silence.
- Wild: v1 loudnorm landed 1.28 LU low (I -17.28) — rebuilt with
  measured two-pass loudnorm (final I -15.61, TP -2.14).
- Cloudwhale: TP overshot twice (single-pass -0.89; AAC re-encode
  -0.89 again) — two-pass loudnorm + 0.2s end-fade + -0.5 dB gain
  (final I -16.43, TP -1.40).
- Primeval: saliency reframe REJECTED (serpent cut off, watermark
  sliver) — replaced with a justified center crop; AAC re-encode
  shifted TP to -0.42 — -1.0 dB gain pass (final I -16.91, TP -1.48).
- Giants: cut correction — the 142.63 scene-detect figure was wrong;
  the true hard cut is at 141.7–141.8s, so the clip ends at 141.70 and
  excludes 0.87s of a daylight shot the earlier plan would have kept.
- Primeval, giants, survival, wild: a short content tail (≤0.10s)
  crossing into the card window was silenced with a 0.2s end-fade;
  card windows now measure silent.
- Baked-subtitle cleaning, all verified on frames: survival delogo
  (worked); primeval + giants blur strips (delogo failed twice each);
  neon solved by timing instead (card ends 0.54s before speech onset,
  no card ever shares words with a visible baked subtitle).

## What is still weak (honest, in order of concern)
1. Giants: darkest clip + heavy source action blur around 140s.
   Payoff frame at 141.5 holds crisp; the mid-action second does not.
2. Cloudwhale: shortest content (3.87s) + 720p upscale softness —
   never to be called HD.
3. Primeval: visible blur-band edge across the lower frame + a 0.33s
   tail after "slumber" before the card.
4. Neon: hook card dwell is only 2.0s (forced by the speech onset) —
   one clean read, not two.
5. Survival: delogo smear at the very bottom edge (phones in the
   opening frame); hook and faces are clean.
6. Wild: leopard payoff arrives at clip ~12s; the boar opening must
   carry the first 10 seconds.

## Gaps / drops
None. No hook was dropped and no weak clip was padded in. The
unverified 70s giants cage-march fallback was not used.

## Files delivered (group-1/)
- g1_survival_rate.mp4 (15.80s)
- g1_neon_alchemist.mp4 (13.30s)
- g1_wild_kingdom.mp4 (17.83s)
- g1_primeval.mp4 (10.17s)
- g1_cloudwhale.mp4 (8.37s)
- g1_giants_in_chains.mp4 (10.70s)
- NOTES.md, GROUP_SUMMARY.md (this file)

Prior versions kept labelled: `work/v1/` (first finals), `work/v2/`
(second finals, primeval/cloudwhale only). Nothing was uploaded,
published, submitted, or sent to anyone.

## Audio-fix pass (2026-10-29, after independent QC)
QC failed all six on one systematic ground only: audio averaged
91–149 kbps whole-file with un-normalised sample rates (96 kHz ×5,
44.1 kHz ×1). Fix: audio re-encoded at `-b:a 192k`, 48 kHz, video copied
bit-for-bit; verified first in `work/audiofix/`, then promoted; pre-fix
files kept in `work/pre-audio-fix/`. Post-fix: AAC 48 kHz on all six,
content portions at 193–201 kbps, loudness within 1 LU of -16, TP ≤ -1 dB,
card mean -91 dB, decode clean, faststart, frame counts unchanged (end
card still exactly 135 frames). Read the whole-file-average caveat in
NOTES.md before re-quoting bitrate: 4.5s of digital silence per clip
makes a whole-file 192 kbps average arithmetically impossible, and the
content-portion rate is the honest measure of the encode.
