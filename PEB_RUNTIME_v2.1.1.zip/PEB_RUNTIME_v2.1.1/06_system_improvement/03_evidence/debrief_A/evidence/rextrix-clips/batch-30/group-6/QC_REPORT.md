# Batch-30 Group 6 — Independent QC Report

**QC agent:** independent (did not build these clips). All readings below are the QC agent's own measurements and frame observations. Builder claims in `NOTES.md` / `GROUP_SUMMARY.md` were used only as slicing references and were verified, not assumed. Where a builder claim did not reproduce, that is stated plainly.

**Scope:** `g6_dog_fall.mp4`, `g6_dog_chase.mp4`, `g6_dog_map.mp4`, `g6_mutant_night.mp4`, `g6_mutant_glow.mp4`, `g6_mutant_creature.mp4` in this directory. No file was modified. No upload, publish, submission, or contact was made.

**Method notes (important for interpreting the numbers):**
- Card sections were measured by exact frame selection (`select='eq(n,N)'`), never timestamp seeks.
- Audio bitrate was verified twice per clip: (a) ffprobe stream bitrate, (b) extracted-stream size ÷ duration, computed separately for the full file and for the content section only. The full-file average is diluted by the 4.5 s silent card and is **not** the encoder rate (see "Group findings").
- Card silence was verified sample-accurately (decoded audio to 16-bit PCM, scanned in 5 ms windows). Pre-input `-ss` volumedetect readings were found to be seek artifacts (they pull in the tail of the last content AAC frame) and were discarded.
- Baked-subtitle scan: every content frame of every clip was scanned in two bands (y1320–1920 and y1050–1320) for near-white (luma > 240) pixel fraction; every hot range was then confirmed or cleared on a full-size frame. Added cards sit at y≈950–1000 and are outside both bands, so the scan cannot confuse added cards with baked subtitles.
- Speech check: full content audio of all six clips transcribed with faster-whisper (base model, English). See per-clip notes.

## Verdicts

| Clip | Verdict | One-line reason |
|---|---|---|
| `g6_dog_fall.mp4` (19.0 s) | **PASS** | All checks met; builder's disclosed boundary transient does not exist in the file. |
| `g6_dog_chase.mp4` (17.7 s) | **PASS with flagged 1-frame defect** | All checks met; frame 0 alone is a stray shot (see below). Optional 1-frame trim. |
| `g6_dog_map.mp4` (17.6 s) | **PASS** | Clean on every check. |
| `g6_mutant_night.mp4` (15.1 s) | **PASS with flagged 3-frame defect** | All checks met except frames 0–2 carry a baked subtitle (0.10 s, pre-card, no doubling, no speech audio). Optional 3-frame head trim. |
| `g6_mutant_glow.mp4` (12.2 s) | **PASS** | Shortest content confirmed complete via beat density. |
| `g6_mutant_creature.mp4` (13.3 s) | **PASS** | Clean on every check. |

No clip is failed. Two head-trim defects are flagged prominently below; they are judged as non-failing because each is sub-0.11 s, precedes all added cards, produces no doubled caption, and is imperceptible in normal playback. **If a strict zero-tolerance rule on stray/subtitle frames is applied, flip Chase and Night to FAIL and apply the fixes in § "Fix list" — the fixes are trivial (drop 1 / 3 head frames).**

## Group findings

### Format / probe — all six PASS
1080×1920, 30 fps, H.264 video + AAC audio, faststart (moov before mdat) in all six. Exact frame counts: fall 570 (19.0 s), chase 531 (17.7 s), map 528 (17.6 s), night 453 (15.1 s), glow 366 (12.2 s), creature 399 (13.3 s). Content = total − 135 frames (4.5 s card): fall 435 (14.5 s), chase 396 (13.2 s), map 393 (13.1 s), night 318 (10.6 s), glow 231 (7.7 s), creature 264 (8.8 s). All content durations ≤ 25 s. ffmpeg null decode: clean, no errors, all six (including Chase, whose OOM-kill/retry history left no encode damage).

### Audio bitrate — all six PASS on the correct test
Full-file ffprobe averages (fall 148, chase 144, map 144, night 136, glow 123, creature 129 kbps) are diluted by the silent card, exactly as predicted by 192 × content/total. Content-only extracted-stream size ÷ duration proves true 192k encoding in every clip: fall 196.3, chase 194.7, map 196.1, night 195.5, glow 195.0, creature 195.5 kbps (slight excess = container overhead + packet-boundary truncation). **A literal full-file 192k requirement is physically incompatible with a silent end card under ffmpeg's native AAC encoder** (silent frames encode near-zero bits); content-only measurement is the correct test. The previous group's "91–149 kbps" catch is consistent with full-file dilution alone.

### Loudnorm — all six PASS (within ±1 LU of −16, true peak ≤ −1 dB)
Fall I −16.14 / TP −1.35; chase I −16.05 / TP −4.44; map I −16.06 / TP −1.31; night I −16.75 / TP −1.29; glow I −16.11 / TP −1.42; creature I −16.32 / TP −1.37. Builder's content-only claims for night (−15.83) and creature (−15.93) did **not** reproduce (own content-only readings −16.75 and −16.32); both still pass tolerance. Glow claim (−16.03) vs own −16.11: close, passes.

### Card silence — all six PASS, including Fall
All six cards are **exact digital zero from the content/card join onward** (card-full and card-first-0.1 s peak −inf dBFS in the sample-accurate test). **The builder's disclosed "≤1-frame boundary transient" in Fall does not exist in the delivered file** — Fall's last content windows are 14.490–14.495 s peak −12.2 dB, 14.495–14.500 s peak −41.6 dB, then all samples 0 from 14.500 s. This is an independent-QC catch in the builder's favor; the earlier pre-input `-ss` reading that suggested a transient was a seek artifact. Night's content audio fades to zero ~10.55 s, just before its 10.6 s join.

### End card — all six PASS
Viewed full-size (fall n435; all mid-card frames; PSNR ~56 dB first-vs-mid-vs-last card frame in every clip = visually identical static card from first to last frame). Clean, whole, centered: "RexTrix" logo, "Download the RexTrix app — link in bio", small grey tagline "AI-generated Games & Stories" at ~y1575 (the allowed exception). No "HD" claim anywhere in any clip. First-card frames are byte-identical within each build chain (dog chain: fall/chase/map share one hash; mutant chain: night/glow/creature share one hash).

### Added content cards — all six PASS
White bold text with black outline, centered ~y950–1000, whole and readable at phone scale in every hook/mid frame checked. No added card duplicates another. No content card sits below y=1500. No clip shows two text layers at once in any frame except as noted for Night's head (below).

### Baked subtitles — full-content scan
- **Night only: frames 0–2** carry the baked subtitle "the mutated pods will lure / even more rifts over" (lowercase white, y≈1370–1470). Frame 0 = speaking man; frames 1–2 = garden shot with the subtitle persisting across the cut. Fraction drops to exactly 0.0 from frame 3. Duration 0.10 s, ending 0.30 s before the first added card (0.40 s) → **no doubled caption**.
- **All other clips: zero baked-subtitle frames** in either scan band across full content. Every hot range in the scan was visually confirmed as scenery brightness (fall: sky through roof hole / window light; night n273: lotus-petal glow; glow: child's glow / mist), not text.
- Map's scene print ("THE KING'S H…", "…'S AT") is dark text printed on the map prop, not a subtitle, and shares no words with the added cards.

### Speech — all six PASS (speech-free)
Whisper base, full content audio: night 0 segments; chase 0; map 0; creature 0; fall 1 segment (0.0–2.0 s, " Oh") and glow 1 segment (0.0–2.0 s, " Oh") — both are single-syllable artifacts on musical/crash SFX, not dialogue (no words, no sentence, and no baked subtitle accompanies them in the corresponding frames). No dialogue line exists in any clip's audio. Night's 3-frame subtitle has no corresponding speech audio in the clip (its line falls outside the trimmed window).

### Sample-rate inconsistency — flagged, not failed
Fall, map, night, creature at 96,000 Hz; chase and glow at 44,100 Hz. No target sample rate was specified in the QC task, and AAC at either rate is valid for Shorts, so this is recorded as a build inconsistency, not a per-clip fail. Recommendation: standardize (e.g. 48 kHz) in future builds.

### Reframe / sharpness (dog clips)
Dog clips are visibly softer than the native-vertical Mutant clips (upscale from a 608×1080 crop, as expected), but subjects and card text read clearly at phone scale in every checked frame. No dog-clip subject is cut off in a way that breaks the moment (see per-clip notes for edge cases). These are never called HD, and no HD claim appears in any clip.

### y=1500 rule
All added cards are centered ~y960. In content frames, nothing critical sits below y=1500 except background (garden path, desert, train floor) and scene print (map text). The only y>1500 text is the end card's own tagline (~y1575), the allowed exception.

---

## Per-clip evidence

### g6_dog_fall.mp4 — PASS
- Specs: 570 frames / 19.0 s; content 435 frames / 14.5 s; card exactly 135 frames, first card frame n435, last content n434 (empty train interior + desert, content confirmed). Decode clean.
- Audio: content 196.3 kbps; I −16.14 / TP −1.35; card exact digital zero from 14.500 s (disclosed transient disproved — see above).
- Frames: hook n45 (1.5 s) dog mid-fall through roof, upside down, face to camera, "THROUGH THE ROOF" — strongest hook in the group, dog dominant, not cut off. Mid n240 (8 s) dog + driver inside car, "NOW HE'S INSIDE" — moment resolved. n38 (1.27 s) and n180 (6 s) confirmed no baked subtitle (hot scan ranges = sky/window light). Card n435 + n480 + n569 clean (PSNR ~56 dB).
- Visual hook: lands at 1.5 s, resolves by ~8 s. No dead air (continuous motion throughout).
- Weakest second: ~13–14.5 s — after the dog-inside beat the camera drifts to window/desert/bird views and the dog leaves the frame for the last ~6 s; moving landscape, not dead air, but the subject is gone. Also n180 is a motion-blurred frame (dog moving fast) — source motion, not encode damage.
- Reframe: upscale softness visible in fur, but face/eyes read clearly at phone scale.

### g6_dog_chase.mp4 — PASS with flagged 1-frame defect
- Specs: 531 frames / 17.7 s; content 396 frames / 13.2 s; card exactly 135 frames, first card n396 (byte-identical to fall's verified card frame), last content n395 (coach + riders in full chase, content confirmed). Decode clean — no damage from the OOM-kill/`-threads 1` retry history.
- Audio: content 194.7 kbps; I −16.05 / TP −4.44; card exact digital zero.
- Frames: hook n30 (1 s) aerial chase, coach + 6 riders, "STAGECOACH UNDER ATTACK" — distant but legible; side riders partially cut at frame edges, coach + centre riders dominant. Mid n240 (8 s) closer chase, "BANDITS EVERYWHERE" — reads clearly. Card n450 clean. Subtitle scan: zero hot frames anywhere.
- **Defect (flagged, not failed): frame 0 alone is a dog lying on a train-car floor — a different shot from the aerial chase in frames 1+. Extent: exactly 1 frame (33 ms), before any card text (first card 0.40 s), no subtitle in frame 0. Most plausible cause: the 136.8 s trim point landed 1 frame before the source cut into the aerial shot. Builder's "single sustained aerial shot" claim is therefore technically inaccurate by 1 frame.**
- Visual hook: lands at 1 s, moment (sustained chase) holds through the card. No dead air.
- Weakest second: the 1 s hook is a distant aerial (riders small) before closer chase shots; still legible. The stray frame 0 is the clip's only true defect.
- Reframe: aerial group reads at phone scale despite upscale softness; edge riders cut by the crop, centre action intact.

### g6_dog_map.mp4 — PASS
- Specs: 528 frames / 17.6 s; content 393 frames / 13.1 s; card exactly 135 frames, first card n393 (byte-identical to fall's verified card frame), last content n392 (map close-up, "THE KING'S H…" scene print, content confirmed). Decode clean.
- Audio: content 196.1 kbps; I −16.06 / TP −1.31; card exact digital zero.
- Frames: hook n30 (1 s) dog by chest, "HE FOUND SOMETHING" — dog face at right edge, nose/face fully visible, ear tip at edge. Mid n240 (8 s) dog sniffing map, "A HIDDEN MAP" — payoff lands here. Card n450 clean. Subtitle scan: zero hot frames anywhere; scene print is not a subtitle.
- Visual hook: lands at 1 s via the card (map itself not visible until ~8 s) — by design, and the card carries it. Moment resolves at the map reveal. No dead air.
- Weakest second: ~1–3 s (dog by chest before the map appears; card-dependent hook).
- Reframe: dog face fully visible despite right-edge placement; map print legible at phone scale.

### g6_mutant_night.mp4 — PASS with flagged 3-frame defect
- Specs: 453 frames / 15.1 s; content 318 frames / 10.6 s; card exactly 135 frames, first card n318, last content n317 (giant lotus + mist, content confirmed). Decode clean. Native-vertical sharpness (fine flower/face detail, visibly crisper than dog upscales).
- Audio: content 195.5 kbps; I −16.75 / TP −1.29 (builder claimed −15.83 — not reproduced, still passes); card exact digital zero; content fades to zero ~10.55 s. Whisper base full-content: 0 segments — no speech audio.
- Frames: hook n30 (1 s) glowing sky figure on cupcake, "THE GARDEN TRANSFORMS" — sharp, immediate. Mid n210 (7 s) night garden, giant lotuses + moon, "WHEN NIGHT FALLS" over bright petals — outline keeps it readable. n273 (9.1 s) lotus close-up confirmed no baked subtitle (scan hot range = petal glow). Card n375 clean.
- **Defect (flagged, not failed): frames 0–2 carry the baked subtitle "the mutated pods will lure / even more rifts over" (n0: speaking man; n1–n2: garden shot, subtitle persisting across the cut). Extent: exactly 3 frames (0.10 s); scan fraction drops to 0.0 from frame 3. The first added card starts at 0.40 s (frame 12), so there is NO overlap and NO doubled caption. There is also NO corresponding speech in the audio (Whisper: 0 segments). Builder's "verified subtitle-free on frames" claim is false for these 3 frames. In normal playback the flash is imperceptible (0.10 s, pre-card); frame-by-frame it is visible.**
- Visual hook: lands at 1 s (glowing figure), moment (garden transforming to night) resolves across the lotus bloom before the card. No dead air.
- Weakest second: 0–0.1 s (the subtitle flash, on a strict frame-level reading); in viewing terms, the ~9–10.5 s lotus-closeup stretch is the softest beat — static bloom, still beautiful.

### g6_mutant_glow.mp4 — PASS
- Specs: 366 frames / 12.2 s; content 231 frames / 7.7 s; card exactly 135 frames, first card n231, last content n230 (honey jar spilling at girl's feet, content confirmed). Decode clean. Native-vertical sharp.
- Audio: content 195.0 kbps; I −16.11 / TP −1.42 (builder claimed −16.03 — close, passes); card exact digital zero. Whisper base: 1 artifact segment (" Oh", 0.0–2.0 s, musical swell) — not dialogue.
- Frames: hook n30 (1 s) trio before giant lotus, "THE LOTUS OPENS" — immediate. n90 (3 s) wide night garden, lotus blooming, trio below — beat 2. n120 (4.0 s) glow-child emerging, still "THE LOTUS OPENS" (card change at 4.20 s = frame 126, consistent with builder timings). n126 (4.2 s) glow-child close-up landing exactly on "A GLOW SPIRIT" — builder's card/shot-sync claim verified. n145 (4.83 s) glow-child close-up, no baked subtitle (scan hot range = child's glow). n150 (5 s) mist vortex, "A GLOW SPIRIT" — beat 3. n230 honey spill — final beat. Card n300 clean.
- Visual hook: lands at 1 s. **Shortest content (7.7 s) confirmed complete via beat density — 5 beats (trio → wide garden/lotus → glow child → mist vortex → honey spill), no padding, no dead air.** Builder's beat-density claim verified.
- Weakest second: ~5 s mist-vortex beat (abstract mist, no character) — brief and transitional.

### g6_mutant_creature.mp4 — PASS
- Specs: 399 frames / 13.3 s; content 264 frames / 8.8 s; card exactly 135 frames, first card n264 (byte-identical to night's card frame), last content n263 (creature in mist over garden, content confirmed). Decode clean. Native-vertical sharp.
- Audio: content 195.5 kbps; I −16.32 / TP −1.37 (builder claimed −15.93 — not reproduced, still passes); card exact digital zero. Whisper base: 0 segments.
- Frames: hook n30 (1 s) giant swirling purple/gold creature over garden at sunset, "SOMETHING HUGE ARRIVES" — immediate. Mid n180 (6 s) creature beside giant pink lotus, "OVER THE GARDEN" — sharp, readable. Card n330 clean. Subtitle scan: zero hot frames anywhere.
- Visual hook: lands at 1 s, moment (creature arrival over garden) holds and resolves in mist before the card. No dead air.
- Weakest second: ~8.77 s tail (creature dissolving into mist, less defined) — still on-theme.

## Fix list

No FAILs, so no mandatory fixes. Optional fixes, only if the parent applies a strict rule or wants the defects gone:

1. **Chase (optional):** drop frame 0 — re-trim the source 1 frame later (start 136.8 s + 1 frame) and re-encode; re-verify frame count (530 frames / 17.67 s), card = last 135 frames, loudnorm, and card silence. Cost: one re-encode.
2. **Night (optional):** drop frames 0–2 — re-trim the source to start at frame 3 (or at the garden-shot cut) and re-encode; re-verify frame count (450 frames / 15.0 s), card = last 135 frames, loudnorm, card silence, and a re-run of the subtitle scan (must show zero hot frames). Cost: one re-encode.
3. **Future builds (process, not per-clip):** standardize audio sample rate (48 kHz suggested); add a head-frame check (frames 0–2) to the builder's subtitle-free verification, since trims landing 1–3 frames before a scene cut produced both defects in this group; note that full-file bitrate must not be used as the 192k test when a silent card is present — use content-only extraction.

## Builder-claim corrections (for the record)
- Fall "≤1-frame boundary transient": **does not exist in the delivered file** (exact digital zero from the join).
- Chase "single sustained aerial shot": **false by 1 frame** (frame 0 is a different shot).
- Night "verified subtitle-free": **false by 3 frames** (frames 0–2 carry a baked subtitle).
- Night content loudnorm −15.83 claimed vs −16.75 measured; creature −15.93 claimed vs −16.32 measured; glow −16.03 claimed vs −16.11 measured — all still within tolerance.
- All other builder claims checked (durations, card lengths, card timings, card/shot sync in glow, decode cleanliness, card silence, sharpness difference) reproduced.
