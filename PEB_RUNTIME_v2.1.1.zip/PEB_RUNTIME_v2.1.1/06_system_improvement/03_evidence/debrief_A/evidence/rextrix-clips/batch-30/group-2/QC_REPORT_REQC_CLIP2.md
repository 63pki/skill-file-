# Batch-30 Group 2 — INDEPENDENT RE-QC, CLIP 2 ONLY

**QC role:** independent re-verifier. I did NOT build or fix this clip. Nothing was
modified, uploaded, published, submitted, or sent to anyone. No live browser was
used. All numbers below were measured fresh from the delivered file and from the
source file `work/apocalypse_ep1.mov`. This report does NOT overwrite
`QC_REPORT.md` (the original QC, in which this clip FAILED) and does NOT re-QC
the other five clips' content — their md5s were checked for untouched status only.

**File:** `g2_apoc_died_three_times.mp4` (rebuilt; claimed Apocalypse 338.0–353.2 s)

## Verdict: PASS

The original failure — a mid-sentence end cut inside "I've watched the sky for
30 years" at source 352.0 s — is fixed. The rebuilt clip ends in the pause after
that line completes, before the next sentence begins. Every other gate below
also passes on my own measurements, which reproduce the fixer's claimed figures
exactly except for two small, immaterial timing/level differences noted in
§5 (neither changes any verdict).

## 1. Probe, decode, frame count

| Check | Measured | Required / claimed | Result |
|---|---|---|---|
| Dimensions / fps / codec | 1080×1920, 30 fps, H.264 High, yuv420p | 1080×1920, 30 fps, H.264 | ✓ |
| Audio | AAC LC, 96 kHz, stereo, stream bitrate 151.0 kbps (full-file reference only) | — | ✓ (matches claim) |
| Faststart | Atom order `ftyp, moov, free, mdat` — moov before mdat | moov before mdat | ✓ |
| Null decode | `ffmpeg -v error -f null -`, exit 0, no errors | clean | ✓ |
| Total duration / frames | 19.70 s, 591 frames (`-count_frames`: nb_read_frames = 591) | 19.7 s, 591 = 19.7×30 | ✓ exact |
| Content duration | 15.2 s (frames 0–455) | ≤ 25 s | ✓ |
| End card | Frames 456–590 inclusive = **135 frames**, 4.5 s, at end only | exactly 135, end only | ✓ |

End-card proof is by frame number (`select=eq(n,…)`), not timestamp seeks:
n=454 and n=455 are both content (two women face-to-face, baked line
"I've watched the sky for 30 years" whole, no added card); n=456 is the full
RexTrix end card ("Download the RexTrix app — link in bio"); n=520 (mid-card)
and n=590 (last frame) are the same full end card. The boundary is therefore
exactly between n=455 and n=456, and 591 − 456 = 135 frames.

## 2. Loudness and bitrate (content-only method)

- **Loudnorm, content only** (`atrim=0:15.2`): **I −15.22 LUFS, TP −1.68 dB**.
  0.78 LU from −16 — inside the 1 LU gate; TP ≤ −1 dB with 0.68 dB margin.
  Reproduces the fixer's claim exactly. (Note on method: a first attempt using
  output `-t 15.2` instead of `atrim` gave I −15.51; the `atrim` measurement is
  the one that matches the original-QC method and the fixer, and it is the
  figure judged here. Either figure passes the 1 LU gate.)
- **Bitrate, content-only** (audio packets with `pts_time < 15.2`, summed ÷ 15.2 s):
  **194.4 kbps** (1,426 packets, 369,427 bytes) — reproduces the claim exactly,
  ≈192 kbps target. Full-file stream figure 151.0 kbps is reference only,
  diluted by the silent card as expected; the full-file error was NOT repeated.

## 3. Card silence

- Full card (15.2–19.7 s): **mean −91.0 dB, max −78.3 dB**.
- Card-first-0.5 s boundary slice (15.2–15.7 s): **mean −91.0 dB, max −78.3 dB**.
  Both reproduce the fixer's claim exactly. No transient at the boundary.

## 4. Added cards (frames viewed by me)

Pillarbox + top-bar treatment preserved, as claimed. Cards sit in the top
blurred bar, outside the video area; no added card sits on the video area.

- n=60 (2 s): baked "I'm taking you somewhere because I've died three times"
  whole inside the video area; no added card at this time — hook on screen ✓.
- n=120 (4 s): no added card (correct — first card starts at 5.0 s).
- n=210 (7 s): **"SHE CAME BACK"** in the top bar, whole and readable, with **no
  baked sub beneath it** — the speech-gap placement is confirmed.
- n=270 (9 s): **"THE SKY TURNS"** in the top bar + baked "something's coming
  tonight" whole; shared words: none.
- n=390 (13 s): no added card (correct — second card ends at 12.0 s); baked
  "how did you know" whole.
- No doubled captions observed in any sampled frame; no added card duplicates
  a concurrent baked line; English throughout.

"SHE CAME BACK" remains an interpretive gloss of "I've died three times", not
a quote — accurate (the speaker is alive recounting three deaths), disclosed
in NOTES.md, and not a fail (same judgment as the original QC).

## 5. THE DECISIVE CHECK — the ending

### 5a. On the delivered file's last content frames

- n=454 and n=455 (last two content frames): baked line **"I've watched the sky
  for 30 years" whole** inside the video area, both women's mouths closed/at
  rest — the line is displayed, not mid-utterance.
- Delivered audio tail: last 0.5 s of content (14.7–15.2 s) mean −18.0 dB;
  last 0.2 s (15.0–15.2 s) mean **−25.7 dB** (fixer claimed −25.4 dB; 0.3 dB
  slice difference, same conclusion: a quiet tail, not active speech).
- The next sentence, "if it comes it'll be red", appears **nowhere** in the
  delivered clip — not as speech, not as a baked subtitle, in any frame I
  viewed (n=60, 120, 210, 270, 390, 454, 455).

### 5b. On the source (`work/apocalypse_ep1.mov`)

- Speech for the final line is active through ~353.0 s (source 352.7–353.0 s
  mean −13.3 dB), then drops: 353.0–353.1 s mean −20.7 dB, 353.1–353.2 s mean
  −31.5 dB (fixer claimed −19.7 / −30.5 dB; ~1 dB slice differences, same
  pause). The content cut at 353.2 s therefore lands **inside that pause**,
  ~0.2 s after speech ends.
- Source frame at 353.2 s: still "I've watched the sky for 30 years", speaker
  at rest — identical in content to delivered n=455, confirming the window
  end.
- Source frame at 353.5 s: already "if it comes it'll be red". The subtitle
  switch therefore happens **between 353.2 s and 353.5 s** — i.e. after the
  cut, not at it. (Small correction to the fixer's wording: the next sentence
  is "first on screen at source ~353.5 s" in the sense that 353.5 s is the
  first sampled frame showing it; the switch itself is somewhere in
  353.2–353.5 s. This does not affect the verdict, because the cut at
  353.2 s precedes the whole interval.)
- Source audio after the cut rises again (353.3–353.4 s max −6.3 / −3.6 dB),
  consistent with the next sentence starting just after the cut — none of
  that audio is in the clip, whose audio ends at 353.2 s.

### 5c. JUDGMENT ON THE SUBTITLE-PERSISTS NUANCE — stated plainly

**Standard applied:** a clean ending means (i) the final sentence's speech
completes, (ii) a pause follows before the cut, and (iii) the next sentence
appears neither as speech nor as subtitle inside the clip. Subtitle
disappearance is NOT required, because in this source the baked subtitle is
a caption hold: it stays on screen after speech ends until the next sentence
replaces it. Demanding that it vanish before the cut would be impossible
here without either cutting before "years" finishes (re-creating the
original mid-sentence fail) or extending past the next sentence's start
(including the very sentence the fix must exclude).

On that standard, this clip **passes, and the pass is not a silent wave-through**:
the subtitle does persist at the final frame (delivered n=455 and source
353.2 s both show it), and I am recording that fact rather than hiding it.
What proves the ending clean is the speech pause (§5b) plus the absence of
the next sentence (§5a) — exactly the proof the fixer disclosed. Conversely,
failing the clip merely because the caption hold is still visible would
punish the source's caption timing, not a cut error: the pre-fix FAIL was
speech active across the cut (clip last-0.5 s −17.1 dB, source speech
−15.1 to −13.1 dB across 352.0 s); here speech is silent across the cut.
The two situations are materially different, and the verdict differs for
that reason, not by leniency.

**Caveat (honest, not a fail):** the margin on the subtitle side is tight —
the switch falls within 0.3 s after the cut. The cut as delivered is on the
correct side of it, frame-verified, so this is a note for any future
re-encode (do not shift the window later), not a defect in this file.

## 6. Untouched check — other five Group 2 files

All five md5s match the fixer's list exactly. No content re-QC was performed
on them, and none was needed (no md5 differed, so no scope breach).

| File | Measured md5 | Listed md5 | Match |
|---|---|---|---|
| g2_apoc_24hours.mp4 | 0beee7b07c9427c78245e8953ee25924 | 0beee7b07c9427c78245e8953ee25924 | ✓ |
| g2_apoc_built_not_disaster.mp4 | 6942d0dc157f4fdd6fe010b3a1f21c54 | 6942d0dc157f4fdd6fe010b3a1f21c54 | ✓ |
| g2_feed_moth_city.mp4 | 7abcf71d0bd0496327e2d577f4ac3594 | 7abcf71d0bd0496327e2d577f4ac3594 | ✓ |
| g2_feed_title_drop.mp4 | dd8d340e58f63a55270b4c603642aaa7 | dd8d340e58f63a55270b4c603642aaa7 | ✓ |
| g2_hells_guard_hungry.mp4 | 40e6b5bbe7b65071c33d95280f124573 | 40e6b5bbe7b65071c33d95280f124573 | ✓ |

For the audit trail: the rebuilt clip itself measures
**aaa1829694e5b6f287e4d9402fd16565** (matches the fixer's promoted-file md5),
identical to `work/g2_apoc_died_three_times_fix2.mp4`; the pre-fix file
`work/pre-fix/g2_apoc_died_three_times_midcut.mp4` measures
**0b3018cbdf5cf1a40a3d57ca453371b0** (matches the fixer's pre-fix md5).

## 7. Fix list

None. No fix is required for clip 2.

## Summary table (my measurements)

| Item | Value |
|---|---|
| File | g2_apoc_died_three_times.mp4 |
| Window | Apocalypse 338.0–353.2 s (15.2 s content) |
| Total / frames | 19.7 s / 591 frames = 19.7×30 |
| Format | 1080×1920, 30 fps, H.264, faststart (moov before mdat) |
| Null decode | Clean, exit 0 |
| Loudnorm (content-only) | I −15.22 / TP −1.68 (0.78 LU from −16; TP ≤ −1 dB ✓) |
| Bitrate (content-only) | 194.4 kbps (full-file 151.0 kbps reference only) |
| Card | 135 frames (456–590), end only; mean −91.0 dB; first-0.5 s peak −78.3 dB |
| Ending | Final line completes; pause 353.0–353.2 s; next sentence absent from clip |
| Other five files | All md5s match — untouched, no scope breach |
| **Verdict** | **PASS** |
