# Batch-30 Group 6 — NOTES

## Sources (tool-confirmed)

- DOG OF THE WEST ep1 — Drive file `1Z5-7OAy6LHR3j9K7ouQK-tMrpUejssQz`
  (`DOG OF THE WEST_ep1.mov`), 544,923,377 bytes — exact manifest match.
  1920x1080 landscape, 30fps, 359.56s, h264 + AAC.
  Whisper: English p=1.00, but dialogue is SPARSE. Every dialogue line carries a
  BAKED-IN lowercase subtitle at the bottom of frame (verified on frames at
  32s, 39s, 69s, 119s, 127s, 171s, 294s). Therefore NO clip uses a dialogue
  segment: all Dog clips are built from speech-free windows, where frames were
  verified subtitle-free, with only our own cards added. No doubled captions.
- Mutant Garden Fiesta ep1 — Drive file `1kITCDDGGW8Wz0FNccSM_g6C_SKiypV7K`
  (`Mutant Garden Fiesta_ep1.mov`), 503,041,313 bytes — exact manifest match.
  1080x1920 VERTICAL already, 30fps, 333.11s, h264 + AAC. No reframe needed.
  Whisper: English p=1.00, dialogue DENSE (a line roughly every 10s). Dialogue
  scenes also carry baked-in subtitles (verified at 60s: "we have to reinforce
  the garden before sundown"). All Mutant clips likewise use speech-free
  windows only, verified subtitle-free on frames.
- End card: `new-batch-7/voiceover-pilot/work/card_v.mp4` — verified 1080x1920,
  30fps, exactly 4.500s, used as-is (no pad/trim needed).
- Audio design note: all six clips are visual/music-only by construction (the
  only clean windows are speech-free). Source music/SFX bed kept as the single
  audio design; no speech to enhance, no competing tracks, no Demucs needed.
  Loudnorm target -16 LUFS, TP ≤ -1 dB (see per-clip readings).
- Landscape reframe: Dog clips use the smart-reframe saliency-tracked crop
  (608x1080 native crop) upscaled with lanczos to 1080x1920 in the assemble
  pass, per the task's 1080x1920 output spec. The upscale-from-crop is the
  honest quality caveat for the Dog clips (see weakest points).
- Card-silence measurement note: volumedetect with pre-input `-ss` is the
  trusted method here (post-input `-ss`/`-to` with volumedetect returned
  whole-file stats in this ffmpeg build). A ≤1 AAC-frame boundary transient
  at the exact content→card join is possible; QC criterion applied: card
  region from content-end +0.1s onward must read -91 dB (digital silence).

## Per-clip notes

<!-- filled in as each clip passes QC -->

### g6_dog_fall — DOG OF THE WEST, 102.8–117.3 (14.5s) + 4.5s card = 19.0s
- Moment: empty train car → dog crashes head-first through the roof → dog
  inside the car with the driver. Shot boundary at ~106.1 is the impact flash,
  not a scene change; the sequence is one continuous action.
- Cards: 0.40–5.20 "THROUGH THE ROOF"; 5.20–14.30 "NOW HE'S INSIDE".
- QC: 1080x1920, 30fps, h264 + AAC, null decode OK. Hook frame (1.5s): dog
  mid-fall through the roof, card centered/readable, dog dominant in the
  saliency crop. Mid frame (8s): dog + driver inside car, no baked subs.
  Card frame (16s): clean RexTrix end card.
- Audio: v1 measured I -16.10 / TP -0.85 (TP 0.15 dB over) and a 0.2s tail
  (-18.5 dB peak) bleeding into the card head. v2 (alimiter 0.891 + exact
  atrim) fixed the tail to -25.8 dB peak in the first 0.1s of card and
  -91 dB after, but TP still -0.96. v3 (video copy of v2 + alimiter 0.85
  audio remux): I -16.14 / TP -1.35, card -91 dB from content-end +0.1s,
  single boundary-frame transient only. v3 is the delivered version.
- Weakest point: the ≤1-frame boundary transient at the card join (see note
  above); otherwise the strongest hook in the group.

### g6_dog_chase — DOG OF THE WEST, 136.8–150.0 (13.2s) + 4.5s card
- Moment: aerial stagecoach chase — bandits on horseback pursuing the coach
  across desert. Single sustained aerial shot (scene cuts at 136.8 and 150.0).
- Cards: 0.40–6.00 "STAGECOACH UNDER ATTACK"; 6.00–13.00 "BANDITS EVERYWHERE".
- QC: 1080x1920, 30fps, h264 + AAC, 17.7s, null decode OK. Audio I -16.05 /
  TP -4.44; card fully silent (-91 dB) including the boundary slice. Hook
  frame (1s): aerial chase with coach + riders all in the saliency crop,
  card centered/readable. Mid frame (8s): closer chase, "BANDITS EVERYWHERE".
  Card frame (15s): clean RexTrix end card.
- Build note: first assemble failed (afade `st` empty — build script was
  edited mid-execution by the operator's own patch; see "What was fixed"),
  retry failed again (OOM kill under 8 GB VM pressure with ~14 concurrent
  ffmpegs), final retry with `-threads 1` succeeded. v1 is the delivered
  version (no v2 needed).
- Weakest point: aerial wide shot is slightly distant in the vertical crop;
  the action still reads clearly at phone size.

### g6_dog_map — DOG OF THE WEST, 325.0–338.1 (13.1s) + 4.5s card
- Moment: dog beside an open chest, sniffing a large old map ("THE KING'S…"
  legible on the map). Single shot ending at the 338.1 cut, just before the
  next dialogue line (339.9) and its baked subtitle.
- Cards: 0.40–6.50 "HE FOUND SOMETHING"; 6.50–12.90 "A HIDDEN MAP".
- QC: 1080x1920, 30fps, h264 + AAC, 17.6s, null decode OK. Audio I -16.06 /
  TP -1.31; card fully silent (-91 dB) including the boundary slice — the
  afade-tail fix works, no boundary transient on this clip. Hook frame (1s):
  dog by the chest, card centered/readable (saliency crop favors the dog's
  face; the map itself is revealed at 8s). Mid frame (8s): dog sniffing the
  map, "A HIDDEN MAP" readable; the map's own printed text ("…S AT") is scene
  print, not a subtitle, and shares no words with our card. Card frame (15s):
  clean RexTrix end card.
- Weakest point: hook frame shows dog + chest but not yet the map (payoff
  lands at 8s); acceptable for a discovery beat.

### g6_mutant_night — Mutant Garden Fiesta, 66.6–77.2 (10.6s) + 4.5s card
- Moment: glowing sky figure on a cupcake → night garden with giant glowing
  lotuses. Ends before the abstract extreme close-up at 77.2.
- Cards: 0.40–5.60 "THE GARDEN TRANSFORMS"; 5.60–10.40 "WHEN NIGHT FALLS".
- QC: 1080x1920 (native vertical, no reframe), 30fps, h264 + AAC, 15.1s,
  null decode OK. Audio content-only I -15.83 / TP -1.29 (full-file I
  -16.75 is silence-diluted by the 4.5s card); card silent (-91 dB after
  the first 0.1s, -64 dB max blip in the boundary slice — inaudible).
  Hook frame (1s): glowing sky figure on a cupcake, card readable. Mid
  frame (7s): night garden, giant lotuses + moon, "WHEN NIGHT FALLS"
  readable over petals. Card frame (12.5s): clean RexTrix end card.
- Weakest point: mid card sits over bright lotus petals; the 4px outline
  keeps it readable, verified on frame.

### g6_mutant_glow — Mutant Garden Fiesta, 101.33–109.0 (7.67s) + 4.5s card
- Moment: trio before a giant glowing lotus → floating glow child → garden
  mist → spilled honey jar button. Starts at the 101.33 shot boundary so the
  hook (trio + giant lotus) lands in frame 1; the weaker bottles/couple shots
  before it were cut.
- Cards: 0.40–4.20 "THE LOTUS OPENS"; 4.20–7.50 "A GLOW SPIRIT" ("glow spirit"
  is in-show vocabulary, dialogue at 181.14).
- QC: 1080x1920 (native vertical, no reframe), 30fps, h264 + AAC, 12.2s,
  null decode OK. Audio I -16.11 full-file / -16.03 content-only, TP -1.42;
  card silent (-91 dB after the first 0.1s, -78.3 dB max blip in the
  boundary slice — inaudible). Hook frame (1s): trio before the giant lotus,
  card readable. Frame (3s): wide night garden with floating glow creatures.
  Frame (4.2s): glow-child close-up landing exactly on the "A GLOW SPIRIT"
  card. Frame (5s): pink mist vortex. Card frame (10s): clean RexTrix end
  card. Note: the 0.4-threshold scene pass missed one internal cut in the
  102.7–106.27 span (wide garden → child close-up); both shots verified on
  frames, sequence coherent.
- Weakest point: shortest clip in the group (7.67s content); the density of
  the beats (trio → garden → child → mist → honey) carries it.

### g6_mutant_creature — Mutant Garden Fiesta, 297.83–306.6 (8.77s) + 4.5s card
- Moment: giant swirling purple/gold creature over the garden at sunset →
  garden sunrise → creature beside a giant pink lotus → flaming close-up.
- Cards: 0.40–4.80 "SOMETHING HUGE ARRIVES"; 4.80–8.60 "OVER THE GARDEN".
- QC: 1080x1920 (native vertical, no reframe), 30fps, h264 + AAC, 13.3s,
  null decode OK. Audio I -16.32 full-file / -15.93 content-only, TP -1.37;
  card silent (-91 dB after the first 0.1s, -74.7 dB max blip in the
  boundary slice — inaudible). Hook frame (1s): giant swirling creature
  over the garden, card readable. Mid frame (6s): creature beside the
  giant pink lotus, "OVER THE GARDEN". Card frame (11s): clean RexTrix end
  card.
- Weakest point: none material; the sunrise-garden beat between the wide
  creature shot and the lotus close-up is brief but reads as a camera move
  within one continuous arc.

## What was fixed during the build
- Dog/Mutant dialogue segments rejected (baked subtitles) — all clips rebuilt
  from verified speech-free windows instead of layering cards over captions.
- Fall v1 TP + card-tail issues → v2 → v3 (see fall note).
- Mutant download died silently at 131 MB (curl process gone); resumed with
  `curl -C -` and verified by exact byte count.
- Dog scene detection over the full episode was too slow under load; redone
  windowed (per candidate gap) with 0.4 threshold.
- Mutant frame sweep (full decode) crawled under load; replaced with
  seek-based frames.

## Gaps / things not done
- No dialogue-driven clips: both shows burn subtitles into every speech
  scene, so no captioned-dialogue clip could meet the no-double-caption rule.
  If a future brief allows dialogue clips WITHOUT added cards, the strongest
  unused lines are Dog "Stop looking at my rope. I'm the dangerous one here."
  (169.48–171.94) and Mutant "We have to reinforce the garden before sundown."
  (58.12–60.50) — both would ship with baked subs only.
- Dog backup moments NOT built (kept as spares, not padded in): desert run
  72.4–81.2 (dog charging camera), town portrait 301.5–310.9 (dog at sunset
  holding cloth; static shot would need the 1.1x slow zoom), train-roof
  montage 192.6–206.8.
