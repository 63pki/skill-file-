# Batch-30 Group 3 — NOTES

All clips: 1080x1920, 30 fps, h264 (slow, CRF 16, yuv420p), AAC 192k, faststart.
End card = exactly 4.5 s (135 frames) at END ONLY, silent, from
`new-batch-7/voiceover-pilot/work/card_v.mp4` (RexTrix logo + "Download the
RexTrix app — link in bio"). Added cards: Montserrat Bold, white, 4 px black
outline, centred Y 50%, max 3 words, chunked at phrase boundaries.
Audio: loudnorm to ~-16 LUFS, true peak ≤ -1 dB; Demucs vocal stems enhanced,
music ducked -9 dB under speech; a 0.3 s fade-out ends content audio exactly
at the card boundary so no splice energy lands in the card.
Sources: `work/crow_ep1.mov` (1920x1080 landscape, 419.40 s),
`work/witch_ep1.mov` (1080x1920, 307.22 s, source already carries the RexTrix
watermark top-right), `work/ice_ep1.mp4` (1080x1920, 60.28 s — a vertical short,
not a full episode; no reframe needed).
All cuts are single continuous segments; starts/ends fall in speech gaps
(no mid-sentence cuts). QC per clip: probe, null decode, loudnorm I/TP,
volumedetect on last 4.5 s, frames at hook/mid/card, frame count = duration×30.

## 1. g3_crow_shadow_moves.mp4 — 13.5 s (9.0 content + 4.5 card), 405 frames
- Source: Crow-Ash Orphanage ep1, 0.0–9.0 s.
- Speech: "He's not normal. His shadow moves on its own. This is the seventh
  family. If no one takes him, it's the adult shelter." (0.9–8.3 s).
- Card: [0.3–3.2] "SEVENTH FAMILY". Baked sub at the same moment is "he's not
  normal his shadow moves on its own" — no shared words.
- Audio: I=-16.06, TP=-3.90. Card: mean -91.0 dB, max -70.3 dB (silent).
- What was fixed: v1 used the default saliency reframe, which tracked the
  bright doorway/empty corridor and left the boy out of frame entirely; a
  --center-weight 0 re-run was worse (window further right, watermark sliced).
  Rebuilt with a subject-locked crop (x=196, 608 px wide, static camera) so
  the boy stays in frame with headroom throughout — verified on frames.
- Honest weakest point: any 9:16 crop of this landscape frame slices the
  wide baked subtitle lines (e.g. "this is th…" at 5 s); the spoken lines are
  complete in audio. The reframe crop is also softer than native (608 px
  upscaled to 1080).

## 2. g3_crow_shadow_knocks.mp4 — 18.0 s (13.5 content + 4.5 card), 540 frames
- Source: Crow-Ash Orphanage ep1, 28.0–41.5 s.
- Speech: "Why do you have to move?" (28.0–29.9) then "It's knocking. Have
  you ever let it knock? Shadows don't knock. Yours does. You've just never
  opened the door for it." (32.8–41.0).
- Card: [2.0–4.8] "SHADOWS DON'T KNOCK" over the captionless corridor stretch
  (source 30.0–32.8 s, frame at 31 s verified captionless) — no concurrent
  baked sub at all.
- Audio: I=-16.00, TP=-1.43. Card: mean -91.0 dB, max -76.3 dB (silent).
- What was fixed: none needed beyond the standard pipeline; the saliency
  reframe tracked the shadow figure on the wall correctly (mid-frame shows
  the knocking shadow large and centred).
- Honest weakest point: same sliced-baked-sub caveat as clip 1 on dialogue
  beats (e.g. "…s don't knock yo…" at mid); audio lines complete. Softness
  from the 608 px upscale as in clip 1.

## 3. g3_crow_ability_doors.mp4 — 20.0 s (15.5 content + 4.5 card), 600 frames
- Source: Crow-Ash Orphanage ep1, 369.0–384.5 s.
- Speech: "Your ability isn't to your shadow. Your ability is doors. You can
  open anything, including time, including seals, including the locksmith."
  (373.3–384.4). The 363–373 s gap was verified truly silent by a no-VAD
  Whisper pass before the card window was placed.
- Card: [1.0–4.0] "HIS REAL POWER" over the captionless conservatory stretch
  (source 370–373 s, frame at 370 s verified captionless).
- Audio: I=-15.97, TP=-2.22. Card: mean -91.0 dB, max -66.8 dB (silent).
- What was fixed: none beyond the standard pipeline; saliency reframe kept
  boy + shadow figure apart in frame (card frame) and tracked the boy's
  close-up at mid.
- Honest weakest point: sliced baked subs on the dialogue beat (e.g. "…n
  open anything" at mid) + upscale softness, as in clips 1–2. Payoff line is
  the show's core reveal, so this is the strongest Crow clip despite that.

## 4. g3_witch_cut_rope.mp4 — 23.0 s (18.5 content + 4.5 card), 690 frames
- Source: The Witch Beneath the Gallows ep1, 58.0–76.5 s (already vertical).
- Speech: "Cut the rope" (59.1–59.9), then baked "alive" (74.9–75.4) as the
  knight finds her alive on the bridge.
- Card: [1.0–3.8] "SHE SURVIVES". Overlaps baked "cut the rope" but shares
  no words with it.
- Audio: I=-16.47, TP=-1.21. Card: mean -91.0 dB, max -80.8 dB (silent).
- What was fixed: none beyond the standard pipeline.
- Honest weakest point: the witch's costume is revealing (bone bodice, bare
  midriff) in some frames; this clip uses face close-ups and the bridge
  action beat, never lingers on the costume, but the flag stands. Also
  sparse dialogue — the clip is visual/action-driven.

## 5. g3_witch_dead_hide.mp4 — 24.501 s (20.0 content + 4.5 card), 735 frames
- Source: The Witch Beneath the Gallows ep1, 162.5–182.5 s (already vertical).
- Speech: "Your dead cannot hide you" (162.8–165.5), "I know you"
  (179.8–181.6). Baked subs are the dialogue record here (Whisper misheard
  the later "kneel before the city" line; this window's lines verified on
  frames).
- Card: [1.5–4.2] "THEY FOUND HER". Overlaps baked "your dead cannot hide
  you" but shares no words with it.
- Audio: I=-16.15, TP=-1.49. Card: mean -91.0 dB, max -76.3 dB (silent).
- What was fixed: (a) first final encode overshot TP (-0.86 after AAC);
  limiter 0.85 fixed it (TP -1.49). (b) A -40.8 dB transient sat in the first
  0.5 s of the card (content→card splice); a 0.3 s fade-out ending at the
  content boundary removed it — final card measures -91.0 mean / -76.3 max,
  and -91.0 after 20.5 s. The fade step was then added to the builder for
  all later clips.
- Honest weakest point: sparse dialogue (visual-driven march/confrontation);
  the card-boundary fix above is verified, not assumed.

## 6. g3_ice_fix_arc.mp4 — 29.2 s (24.7 content + 4.5 card), 876 frames
- Source: Ice Road Rig ep1, 15.2–39.9 s (already vertical; the "episode" is a
  60 s short).
- Speech: phone lookup advice (15.4–20.3), "That one's for plumbing"
  (26.4–27.2), clamp instruction + "I know where barrels go" (34.3–39.6).
- Cards: [0.5–3.5] "LOOK IT UP" (phone moment), [20.5–23.0] "NOT THE BARREL"
  (paraphrase of "not around the barrel"). Ice has no baked dialogue subs
  anywhere checked, so no doubling is possible.
- Audio: I=-15.89, TP=-1.41. Card: mean -91.0 dB, max -80.8 dB (silent).
- What was fixed: none beyond the standard pipeline.
- Honest weakest point: a mounted machine gun is present/handled throughout
  (repair context, no violence against people in any checked frame) — flagged,
  not hidden. Some voiceover lines sound dubbed; the fix arc (problem →
  lookup → instruction) is coherent regardless.

## Held backup (NOT built, do not count toward the 6)
- Witch defiance, 248.0–272.5 s (~24.5 s): root-beast reveal → baked "kneel
  before the city" (256 s) → defiant "no" (271 s). Held because the payoff
  frame carries the chest-vein/costume flag; build on coordinator request.
- Other usable backups: Crow 92.9–97.4 ("This orphanage doesn't take normal
  children. You're already qualified."), Crow 403.1–413.2 (contract/defiance),
  Ice 43.5–60.0 (payoff: "Well, that worked" + grinning gun shot), Ice
  0.5–9.8 (hammer taunt).

## FIX LOOP — 2026-10-30 (coordinator overturned QC's audio FAIL; fixes by a
separate agent, NOT the original builder)
- QC's full-file bitrate FAIL is OVERTURNED: QC measured the full-file
  average, which the 4.5 s silent end card dilutes arithmetically. The
  coordinator's content-only method (content audio size ÷ content
  duration) measures 196.7–198.3 kbps on all six clips — true 192k AAC.
  No audio was re-encoded on any untouched clip, and the rebuilt clips'
  content-only rates were re-measured the same way (see below). The
  ffprobe stream bitrates quoted below are the DILUTED reference only
  and must never be quoted as the verdict.
- Pre-fix originals preserved byte-identical in `work/pre-fix/`; all fix
  work in `work/fix/` (builder `work/fix/build_fix.py`, verifier
  `work/fix/verify_audio.py`); replacements were promoted only after full
  verification (verify-first-then-promote, md5-matched on promotion).
- g3_witch_dead_hide.mp4 and g3_ice_fix_arc.mp4 were NOT touched (their
  only QC notes are source-property flags, not fails; they PASS once the
  audio method is corrected).

### FIX 1 — Crow x3 rebuilt as pillarbox strip-over-blur (Group 2 precedent)
- DEVIATION RECORDED (with reason): added cards are NO LONGER centred
  Y50% over the video. The full 1920x1080 landscape frame is preserved
  whole as a 1080x608 strip centred at y=656 over a blurred cover fill
  (no 9:16 crop at all), and the added cards sit in the BOTTOM blur pad
  (ASS Alignment 8 top-centre, MarginV=1290 — strip bottom 1264 + 26 px
  snug gap), never on the strip itself. Reason: the standing baked-text
  rule ("frame around baked text, never crop through") cannot be met by
  any crop of these wide subtitle lines; the strip is the only treatment
  that keeps every baked line whole. This deviation applies to these
  three clips only, because their source is landscape with wide baked
  subs — it is not a new default for vertical sources.
- Same source windows, same speech, same card wording (except knocks
  timing, below). Crow audio reused unchanged (original norm_lim.wav,
  same windows) — final encode libx264 slow CRF 16 yuv420p, AAC 192k,
  forced 48 kHz, faststart.
- Frame verification (full-size frames, by frame number):
  - moves: n30 baked "he's not normal his shadow moves on its own"
    WHOLE (two lines); n135 baked "this is the seventh family" WHOLE
    (was "this is th…"); n240 baked "if no one takes him it's the
    adult shelter" WHOLE (was "if no one takes …"); boy + moving
    shadow both whole in frame; "SEVENTH FAMILY" [0.3–3.2] whole in
    the bottom pad, no shared words with concurrent baked sub.
  - knocks: n60 (2.0 s) baked "why do you have to move" WHOLE, no
    added card yet; n90 (3.0 s) "SHADOWS DON'T KNOCK" whole in the
    bottom pad over a captionless corridor stretch; n150 baked "it's
    knocking have you ever let it knock" WHOLE (was sliced at both
    edges), no added card on that frame; n200 whole likewise.
  - doors: n30 boy + shadow figure whole, "HIS REAL POWER" [1.0–4.0]
    whole in the bottom pad over the captionless stretch; n232 baked
    "your ability is doors" WHOLE (was "…bility is doors"); n360
    payoff baked "including time including seals including the
    locksmith" WHOLE on two lines (was sliced at both edges).
  - All Crow baked subs now end at y≈1250 (inside the strip) and all
    added cards sit at y≈1290–1380 — nothing important below y=1500 in
    content on any Crow clip, except the end card's own tagline.
  - End-card boundaries re-checked by frame number on all three:
    last content frame is content, first card frame is the RexTrix
    card; card is exactly 135 frames, end only.
- KNOCKS CARD-TIMING CORRECTION (found during fix verification, not in
  the original task text): shifting the card start to 3.0 s while
  keeping the 4.8 s end was NOT enough — a first fix build with
  [3.0–5.8] overlapped the baked line at 5.0 s ("it's knocking… let
  it knock"), which shares the word "knock" with "SHADOWS DON'T
  KNOCK". The shipped card is [3.0–4.8] (1.8 s): it sits entirely
  inside the captionless stretch (n90 captionless, n143 last card
  frame still captionless, n150 baked with no card), so the
  "captionless stretch" claim is now literally true AND no shared
  words occur. The 1.8 s duration is short for 3 words but the card
  is large, bold, and fully legible at phone scale on the n90/n143
  frames.
- Honest weakest points (Crow, post-fix): the blur pads carry a faint
  blurred echo of the frame's own baked subtitle (inherent to a blur
  fill — illegible smudge, not readable text); the sharp added card
  reads cleanly above it, but the echo is visible on still frames.
  Strip scale is a 1920→1080 DOWNSCALE, so these clips are actually
  sharper than the old 608 px upscale — softness is no longer the
  weak point; the blur-pad echo is. Moves' dark opening frame is
  unchanged (source property).

### FIX 2 — witch_cut_rope RECUT (not dropped — a clean recut preserves
hook + payoff + complete message)
- Source survey (1 fps over 58.0–76.5 s) mapped the costume-centred
  stretch: torso close-ups ~65–66 s, full-body bridge walk ~67 s (QC
  n277), large falling-body shots ~68–71 s. All of 62.5–72.0 s was cut
  out, including the distant bridge-walk shots at 63–64 s (excluded on
  the strict reading, even though the knight foreground dominates
  those two frames).
- Shipped recut: 58.0–62.5 s (face close-up + "Cut the rope" hook +
  knights running + empty bridge wall) + 72.5–76.5 s (knight alone
  over the splash + baked "alive" payoff + legs/boots alive beat).
  Content 8.5 s + 4.5 s card = 13.0 s total, 390 frames. Cuts fall in
  speech gaps (only speech is the hook at ~59 s and "alive" at
  ~74.9 s); no mid-sentence cuts; the jump from knights running to
  the knight over the splash reads as she-fell-then-found-alive.
- Audio rebuilt from the original Demucs stems cut at the same
  points (original-clip times 0–4.5 + 14.5–18.5), same enhancement /
  ducking (speech spans 1.1–1.9, 6.9–7.4) / loudnorm / 0.85 limiter
  chain, forced to 48 kHz (the original witch file's 96 kHz came from
  its 192 kHz norm wav — fixed here). Fresh faster-whisper tiny pass
  on the recut content audio: English p=1.00, "Cut the rope." +
  "A live." — hook and payoff both survive.
- Frame verification (1 fps sweep + boundary frames by number): face
  close-ups centre the FACE (bodice visible at the bottom edge of
  those frames is inherent to the source face framing, not centred);
  knights running (clip ~2 s) clean; cut point n134 = empty bridge
  wall, n135 = knight + splash (a hair/head sliver of the witch sits
  at the extreme bottom-right corner of this one frame — NO costume
  visible in it, gone within ~0.5 s); baked "alive" frame (clip ~7 s)
  is a knight beat; last content frame n254 = legs/boots underwater
  (action beat, no bodice/midriff in frame); first card frame n255 =
  RexTrix card. NO delivered frame centres the revealing costume.
- Honest weakest points (cut_rope, post-fix): 8.5 s is short and the
  middle action is now implied by the splash rather than shown; the
  face close-ups still show the bodice at the bottom edge (source
  framing, face-centred); the witch baked subs sit at the source-
  native ~y1483–1515 straddle QC already flagged as marginal —
  unchanged by this recut (vertical source, no reframe), not a new
  defect. The ~12.5 s speech gap of the original is gone with the
  cut; the recut's gap is ~5 s (hook → alive).

### FIX 3 — Audio verification (rebuilt clips, BOTH methods)
| Clip | Total | Content | Frames | ffprobe (diluted ref) | Content-only (VERDICT) | I / TP | Card 4.5 s mean/max | Card 1st 0.5 s |
|---|---|---|---|---|---|---|---|---|
| crow_shadow_moves | 13.5 s | 9.0 s | 405 | 130 kbps | 196.7 kbps (221,276 B / 9.0 s) | -16.06 / -3.90 | -91.0 / -70.3 | -91.0 / -70.3 |
| crow_shadow_knocks | 18.0 s | 13.5 s | 540 | 147 kbps | 197.1 kbps (332,530 B / 13.5 s) | -16.00 / -1.43 | -91.0 / -76.3 | -91.0 / -76.3 |
| crow_ability_doors | 20.0 s | 15.5 s | 600 | 152 kbps | 197.1 kbps (381,913 B / 15.5 s) | -15.97 / -2.22 | -91.0 / -66.8 | -91.0 / -66.8 |
| witch_cut_rope | 13.0 s | 8.5 s | 390 | 128 kbps | 197.6 kbps (209,965 B / 8.5 s) | -16.80 / -1.40 | -91.0 / -80.8 | -91.0 / -80.8 |
- Content-only method: `ffmpeg -t <content> -c:a copy` stream
  extraction, size ÷ content duration. All four land at 196.7–197.6
  kbps — true 192k AAC, matching the coordinator's overturn range.
  The ffprobe figures are quoted ONLY as the diluted reference;
  quoting them as the verdict would repeat QC's error.
- All four: 1080x1920, 30 fps, H.264, 48 kHz AAC, null decode clean,
  faststart (moov @36, before mdat), frame count = duration × 30,
  end card exactly 135 frames end-only, boundary slices clean
  (energy on the content side only, card side silent).
- Witch I=-16.80 is within 1 LU of -16 (0.80 LU below target) and
  TP=-1.40 passes — passing, but the closest to the loudnorm edge in
  the group; flagged, not hidden.
- Nothing was dropped. Nothing was uploaded, published, submitted,
  or sent to anyone in this fix loop.

## Content flags (all clips)
- No sexual content, no gore, no banned claims, no invented features, no
  faked UI, no copyrighted characters. Flags carried honestly: witch costume
  (clips 4–5), ice mounted gun (clip 6), crow reframe softness + sliced baked
  subs (clips 1–3). Nothing important sits below y=1500 in any checked frame.
