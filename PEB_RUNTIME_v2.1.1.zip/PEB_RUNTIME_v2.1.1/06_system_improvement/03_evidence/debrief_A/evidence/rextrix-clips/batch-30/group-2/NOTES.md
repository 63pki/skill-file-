# Batch-30 Group 2 — NOTES.md

Six clips, all from NEW shows only (per hold release). No Toilet Knight / Strawberry
moments were used. No clip was uploaded, published, submitted, or sent to anyone.

## Shared build facts

- Output: 1080x1920, 30 fps, libx264 slow, CRF 16, yuv420p, AAC 192k, faststart.
- End card: exactly 4.5 s (135 frames) at END ONLY, silent (anullsrc audio).
  Source: `new-batch-7/voiceover-pilot/work/card_v.mp4`, prepared as `work/card_45.mp4`.
- Text: Montserrat Thin (Bold style) — the installed Montserrat-Bold file reports family
  "Montserrat Thin" — white, 4 px black outline, max 3 words per card, chunked at phrase
  boundaries, never splitting a noun phrase or a brand command.
- Audio: loudnorm on content, then a 50 ms post-loudnorm fade-out at the
  content/card boundary (added after v1 of clip 1 showed a single-sample -38.5 dB
  transient in the first 0.5 s of the card; after the fade, boundary peaks are
  -58 to -81 dB and card means are -91 dB = the AAC silence floor).
- Two clips (moth, hells) were rebuilt with a loudnorm true-peak target of -1.5 dB
  instead of -1.0 dB, because the first builds measured TP -0.64 dB and -0.98 dB
  (AAC overshoot past the -1.0 dB target). After the rebuild both measure TP ≤ -1.1 dB.
  All other loudnorm settings are unchanged; this is documented, not hidden.
- Pillarbox (landscape sources — Apocalypse, Feed): the 1920x1080 frame is scaled to
  1080x608 and centered vertically (video area y 656-1264) over a darkened, blurred
  still background. Rationale: a 9:16 crop window (~608 px wide) would slice through
  full-width baked subtitles, violating "frame around baked text, never crop through."
  Consequence, stated honestly: this deviates from the brief's "cards centered Y 50%"
  (which assumed vertical-native sources). For pillarbox clips, cards use ASS
  Alignment 8 (top-center), MarginV 540 — snug in the top blurred bar just above the
  video area, consistent with the standing user rule that captions must not sit on
  the video area. For vertical-native Hell's Army, cards are centered (Alignment 5).
- RHA-1.mov is treated as Hell's Army episode 1: the folder lists RHA-1 through RHA-6
  plus RHA-long with no explicit "ep1" label, so the first video file was taken and
  this assumption is noted here.
- Apocalypse character name: the baked subtitle reads "Mira" (Whisper often renders
  "Miris"). "Mira" is used in these notes; the name appears in no card.
- Feed and Hell's Army Whisper transcripts were NOT trusted for dialogue: Feed's base
  segments were coarse (up to ~20 s) and Hell's Army's were garbled by shouted/chanted
  dialogue over battle music. All quoted lines below are either small-model
  word-timestamped or read from baked subtitles on frames inside the clip window.

## Clip 1 — g2_apoc_24hours.mp4 — PASS

- Source: `work/apocalypse_ep1.mov` 288.0-302.0 (14.0 s content + 4.5 s card = 18.5 s).
- Dialogue (English, complete thought): "When did you become so fearless?" /
  "When I realized I only have 24 hours." / "Then I'll fly you there."
  Hook (fearless question + 24-hour reveal) lands in 1-3 s; payoff before the card.
- Cards (pillar top-bar): [1.0-4.0] "ONLY 24 HOURS" — over the "fearless" line,
  shares no word with it; [11.0-14.0] "THE ESCAPE PLAN" — over "Then I'll fly you
  there.", no shared word.
- QC: 1080x1920 30 fps h264/AAC, null decode OK, loudnorm I -16.63 / TP -1.27,
  card mean -91 dB (boundary peak -69.5 dB, single sample). Hook/mid/card frames
  checked: baked subtitle whole inside the video, cards readable, end card clean.
- Fixed: v1's -38.5 dB card-boundary transient fixed with the 50 ms boundary fade.
- Weakest point: the cockpit close-up cuts the man's face at the source frame edge
  (source framing, not a pillarbox crop); the top bar is very dark in the hook shot.

## Clip 2 — g2_apoc_died_three_times.mp4 — FIXED 2026-10-30, pending independent re-QC (was FAIL in QC_REPORT.md)

- Source: `work/apocalypse_ep1.mov` 338.0-353.2 (15.2 s content + 4.5 s card = 19.7 s,
  591 frames). Previous build was 338.0-352.0 (14.0 s + 4.5 s = 18.5 s) and FAILED
  independent QC on a mid-sentence end cut; the pre-fix file is kept labelled in
  work/ as `work/pre-fix/g2_apoc_died_three_times_midcut.mp4` (md5
  0b3018cbdf5cf1a40a3d57ca453371b0) for audit, not deleted.
- Dialogue: "Don't go to work today. I'm taking you somewhere because I've died three
  times." / "Something's coming tonight. Not a meteor. The end. Is it red?" /
  "Yes. How did you know?" / "I've watched the sky for 30 years." Hook ("died three
  times") is on screen at ~2 s. The final line is the payoff answer that the
  pre-fix cut interrupted: the old NOTES list ended a line early and is corrected
  here. The clip does NOT extend into the next sentence ("if it comes it'll be
  red", first on screen at source ~353.5 s).
- Ending evidence (fix build, measured fresh): source speech for the final line runs
  to ~353.0 s (source 352.7-353.0 s mean -13.0 dB), then a pause (source 353.0-353.1 s
  mean -19.7 dB, 353.1-353.2 s mean -30.5 dB); the content ends at 353.2 s inside
  that pause, before the next sentence. Delivered last-0.2 s of content (15.0-15.2 s)
  mean -25.4 dB, quiet. Delivered last content frame n=455 shows "I've watched the
  sky for 30 years" whole inside the video area; no new sentence appears in the clip.
  The baked subtitle itself stays on screen past the end of speech until the next
  sentence replaces it (~353.5 s), so the cut is proven by the speech pause + the
  absence of the next sentence, not by the subtitle disappearing.
- Cards (unchanged treatment, re-verified on the rebuilt file): [5.0-7.5] "SHE CAME
  BACK" — placed in the 342-346 s speech gap and frame-verified (n=210 at 7 s shows
  no baked sub under the card); [8.0-12.0] "THE SKY TURNS" — over "Something's
  coming tonight..." (n=270: baked line whole, no shared word). Pillarbox + top-bar
  treatment unchanged from the original build (same ASS, same blurred background
  still, same card source).
- QC (fix build, self-measured; independent re-QC still pending, so no PASS claimed):
  1080x1920 30 fps, 591 frames, null decode OK, faststart (ftyp, moov, free, mdat),
  loudnorm on content only I -15.22 / TP -1.68 (0.78 LU from -16, within 1 LU; TP ≤ -1 dB),
  content-only audio 194.4 kbps (full-file stream figure 151.0 kbps, reference only
  — diluted by the silent card), card mean -91.0 dB, card-first-0.5 s mean -91.0 dB /
  peak -78.3 dB (no transient). End card exactly 135 frames at end only (frames
  456-590; n=456 first card frame viewed, n=590 last frame viewed, both full end
  card). Frames checked: hook n=60 (baked "I'm taking you somewhere because I've
  died three times" whole), gap card n=210, sky card n=270, last content n=455,
  end card n=456/n=590.
- Weakest point: "SHE CAME BACK" glosses "I've died three times" (she died and
  returned) — accurate to the loop premise, but an interpretation, not a quote.
  The mid-frame top bar shows blurred figures (the static blurred midpoint frame is
  the current shot), slightly busy but not distracting.

## Clip 3 — g2_apoc_built_not_disaster.mp4 — PASS

- Source: `work/apocalypse_ep1.mov` 373.0-391.0 (18.0 s + 4.5 s = 22.5 s).
- Dialogue: "Do you see that? Something's falling. Not rocks. Something else." /
  "People. Machines. They're riding them down." / "It's not a natural disaster." /
  "No. Your world built it." Hook (falling objects over the city) lands in 1-3 s.
- Cards: [1.0-4.0] "THEY'RE COMING DOWN" — over "Something's falling...", no shared
  word; [15.0-18.0] "A PLAN, NOT CHANCE" — over "No. Your world built it.", no shared
  word. The second card foreshadows the later ep1 line "Not a disaster. A plan.",
  which is NOT included in this clip.
- QC: 1080x1920 30 fps, null decode OK, loudnorm I -16.90 / TP -2.44,
  card mean -90.3 to -91 dB (boundary peak -58.1 dB). Frames checked: hook card
  readable over the red blurred bar, baked subs whole ("not rocks something else",
  "people machines they're riding them down"), end card clean.
- Fixed: this clip's encode was killed 5 times by system memory pressure (see
  GROUP_SUMMARY.md) before succeeding in a high-availability window with threads 4.
  The delivered file is a clean single encode, not a patched or joined file.
- Weakest point: the red-sky falling-objects shot is visually dense; on a small phone
  screen the "machines" read as falling debris until the dialogue lands. The dialogue
  resolves it within the clip.

## Clip 4 — g2_feed_moth_city.mp4 — PASS (v2, TP-safe rebuild)

- Source: `work/feed_animals_ep1.mov` 196.0-220.0 (24.0 s + 4.5 s = 28.5 s).
- Arc: moth creature flies over the city → a man films it ("What is that?"
  199.6-202.4, "Hey, little guy?" 204.1-205.9, both word-timestamped) → the moth lands
  and drives its proboscis into a car roof (frame-verified 218 s; car only, no gore)
  → "Hey!" (218.4). Self-contained, payoff before the card.
- Baked subs frame-verified at 1 fps in-window: "hey little guy" at 204 s; none at
  199 s or 218 s. Correction to earlier scouting: Feed DOES carry baked subtitles in
  dialogue moments — the sparse dialogue hid this in the 20 s survey frames.
- Cards: [1.0-4.0] "SOMETHING HUGE FLIES" (no dialogue under it); [8.0-11.0] "IT'S
  COMING CLOSER" (over baked "hey little guy", no shared word); [20.0-24.0] "IT'S
  FEEDING NOW" (over the feeding + "Hey!", no shared word with "hey").
- QC (v2): 1080x1920 30 fps, null decode OK, loudnorm I -15.61 / TP -1.17,
  card mean -91 dB (boundary peak -66.8 dB). Hook/mid/card frames re-verified after
  the rebuild (video identical to v1).
- Fixed: v1 measured TP -0.64 dB (AAC overshoot past the -1.0 dB target on
  music-driven audio). Rebuilt with loudnorm TP target -1.5 dB; v2 measures -1.17 dB.
  The v1 file is kept in work/ as `g2_feed_moth_city_tpFAIL.mp4` for audit only.
- Weakest point / honest flag: the moth creature is a nude-stylized humanoid with
  butterfly wings. This clip uses distant/front shots only (moth over the city, man
  filming, proboscis in a car roof) — the body reads as a dark creature design, not
  sexualized, and no genitalia detail is visible. The 260 s traffic-light close-up,
  where the torso form is prominent, was deliberately NOT used. If the coordinator
  wants zero humanoid-body shots, drop this clip — the other five stand alone.

## Clip 5 — g2_feed_title_drop.mp4 — PASS

- Source: `work/feed_animals_ep1.mov` 372.0-396.9 (24.9 s + 4.5 s = 29.4 s).
- Arc: forest temple + moth (385 s frame) → "You ate everything, except what was
  alive." (word-verified 376.0-380.7) → black screen with baked center text
  "MAYBE WE WERE NEVER THE WORLD." and baked bottom subtitle "maybe we were never
  the world don't feed the animals" (word-verified 391.0-393.9, frame-verified 392 s).
- Cards: single card [0.5-3.5] "SOMETHING SURVIVED" over the pre-dialogue visual
  (anticipates "except what was alive"; no dialogue runs 372-376, so no shared-word
  risk). NO card over the title drop itself, to avoid triple text (center baked text
  + bottom baked sub + added card).
- QC: 1080x1920 30 fps, null decode OK, loudnorm I -16.21 / TP -1.11,
  card mean -91 dB at every slice including the boundary. Hook/mid/card frames plus
  an extra title-drop frame at 20.0 s checked: baked title text whole and centered,
  bottom sub whole, no added card overlapping, black screen blends with pillar bars.
- Weakest point: the title-drop moment is quiet and static (black screen, ~5 s of
  text). It lands as an ending beat, but viewers who skip early will miss the setup
  line; the "SOMETHING SURVIVED" card is the only hook for the first 4 seconds.

## Clip 6 — g2_hells_guard_hungry.mp4 — PASS (v2, TP-safe rebuild)

- Source: `work/hells_army_ep1.mov` 239.0-255.0 (16.0 s + 4.5 s = 20.5 s), vertical native.
- Baked subs frame-verified at 1 fps in-window: "guard the hungry nothing else"
  (~240 s), "where did he hide the seal" (~248 s), "you paid for 30 arrows with a
  memory" (~253 s). The Whisper transcript for this show is garbled and was NOT quoted.
- Visuals: face-to-face confrontation (239 s), woman crouching with a sack (243 s),
  young knight under a blood moon (253 s). Clean: only a small cheek scratch visible;
  no blood pools in this window. The baked RexTrix logo (top-right, every frame) is
  untouched; centered cards do not overlap it.
- Cards (vertical, centered): [1.0-4.0] "A DARK BARGAIN" (over "guard the hungry
  nothing else", no shared word); [9.0-12.0] "SOMETHING IS HIDDEN" (over "where did he
  hide the seal", no shared word — "hidden" vs "hide" are different words);
  [13.0-16.0] "WHAT DID IT COST" (over "you paid for 30 arrows with a memory", no
  shared word).
- QC (v2): 1080x1920 30 fps, null decode OK, loudnorm I -16.17 / TP -1.44,
  card mean -91 dB (boundary peak -80.8 dB). Hook/mid/card frames re-verified after
  the rebuild (video identical to v1).
- Fixed: v1 measured TP -0.98 dB (0.02 dB over the limit). Rebuilt with loudnorm TP
  target -1.5 dB; v2 measures -1.44 dB. The v1 file is kept in work/ as
  `g2_hells_guard_hungry_tpFAIL.mp4` for audit only.
- Weakest point: the centered card at 2 s sits between the two faces and partially
  overlaps the background wagon — per the centered-card spec, but it crowds the
  confrontation framing. The faces themselves stay readable.

## Flags reported (not hidden)

- Hell's Army gore windows SKIPPED: 0 s blood pools + bodies on a platform; 40 s
  bloody hand/armor; 200 s battlefield aftermath with bodies and blood pools;
  320 s large foreground blood pool + skeletal creature + woman kneeling in blood.
  The 309-333 s window was skipped entirely despite the "say his name" line.
- Feed horror flag: no gore was found in any chosen window (the moth feeds on a car,
  not a person). The 260 s close-up was avoided for the humanoid-torso reason above.
- No sexual content, no banned claims, no invented features, no faked studio UI
  (the phone camera UI in clip 4 is diegetic source content — a character filming —
  not an added overlay), no copyrighted characters, English only throughout.

## Blocked downloads

- None. All three episode-1 files downloaded via curl and verified by size + ffprobe:
  Apocalypse 608,789,596 bytes / 406.19 s / 1920x1080; Feed 595,649,144 bytes /
  396.90 s / 1920x1080; Hell's Army 505,835,827 bytes / 336.90 s / 1080x1920.
