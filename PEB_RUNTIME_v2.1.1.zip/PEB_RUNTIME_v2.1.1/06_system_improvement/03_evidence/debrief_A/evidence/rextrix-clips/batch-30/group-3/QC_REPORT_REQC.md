# Batch-30 Group 3 — INDEPENDENT RE-QC REPORT (the four changed clips only)

Re-QC by an independent agent that did NOT build or fix these clips.
No clip file was modified. No upload, publish, submission, or contact
was made. Every number below is this agent's own measurement: ffprobe,
ffmpeg null decode, frame-number selection (never timestamp seeks),
loudnorm on content-only audio, volumedetect via `atrim` (see method
note), content-only bitrate (content audio size ÷ content duration),
fresh faster-whisper tiny pass (16 kHz mono wav → numpy float32,
content-only audio, language en), and full-size frame inspection.

This report does NOT overwrite `QC_REPORT.md` (the original QC).

## HEADLINE VERDICT: 4 of 4 PASS — 0 FAIL

| Clip | Total | Content | Frames | Verdict |
|---|---|---|---|---|
| g3_crow_shadow_moves.mp4 | 13.5 s | 9.0 s | 405 | **PASS** |
| g3_crow_shadow_knocks.mp4 | 18.0 s | 13.5 s | 540 | **PASS** |
| g3_crow_ability_doors.mp4 | 20.0 s | 15.5 s | 600 | **PASS** |
| g3_witch_cut_rope.mp4 | 13.0 s | 8.5 s | 390 | **PASS** |

The fixer's claims reproduce on every hard gate. The two original-QC
failures that these rebuilds targeted — Crow sliced baked subtitles
and the cut_rope costume-showcase beat — are both resolved on the
stated criteria (see the explicit-scrutiny section for the two
judgment calls behind those passes, stated plainly so the coordinator
can apply a stricter bar if one is held).

## Measurements (re-QC's own readings)

| Clip | Video | Audio | Content-only bitrate | Loudnorm I / TP | Card 4.5 s mean/max | Card 1st 0.5 s |
|---|---|---|---|---|---|---|
| crow_shadow_moves | 1080×1920, 30 fps, H.264 | AAC 48 kHz | 197.1 kbps (221,746 B / 9.0 s) | −16.06 / −3.90 | −91.0 / −70.3 | −91.0 / −70.3 |
| crow_shadow_knocks | 1080×1920, 30 fps, H.264 | AAC 48 kHz | 197.7 kbps (333,633 B / 13.5 s) | −16.00 / −1.43 | −91.0 / −76.3 | −91.0 / −76.3 |
| crow_ability_doors | 1080×1920, 30 fps, H.264 | AAC 48 kHz | 197.8 kbps (383,298 B / 15.5 s) | −15.97 / −2.22 | −91.0 / −66.8 | −91.0 / −66.8 |
| witch_cut_rope | 1080×1920, 30 fps, H.264 | AAC 48 kHz | 198.0 kbps (210,366 B / 8.5 s) | −16.80 / −1.40 | −91.0 / −80.8 | −91.0 / −80.8 |

- Frame counts equal duration × 30 on all four. Content on all four
  is ≤ 25 s.
- Null decode is clean on all four. Faststart holds on all four
  (moov at offset 32, before mdat).
- End card is exactly 135 frames, end-only, on all four, verified by
  frame number: last content frame is content and first card frame is
  the RexTrix card in every case (moves 269/270, knocks 404/405,
  doors 464/465, cut_rope 254/255); last frames are card (moves 404,
  knocks 539, doors 599, cut_rope 389). All four first-card frames
  are byte-identical (same md5), i.e. the same card asset.
- Card audio is silent on all four (mean −91.0 dB throughout; worst
  peak −66.8 dB, doors). Boundary slices are clean: energy sits on
  the content side only (e.g. moves content-last-0.5 s −30.9/−20.0,
  knocks −22.7/−8.5, doors −22.3/−12.4, cut_rope −25.4/−13.8) with
  the card side silent — no splice transient leaks into any card.
- ffprobe full-file stream bitrates (130/147/152/128 kbps) are the
  DILUTED reference only and are NOT the verdict — the 4.5 s silent
  card dilutes them arithmetically. The verdict method is
  content-only, as the coordinator directed. This re-QC does not
  repeat the original QC's error.
- Content-only bitrates measured here run 0.4–0.7 kbps above the
  fixer's (196.7/197.1/197.1/197.6) — extraction-boundary / AAC-frame
  padding, immaterial. Same verdict: true 192k AAC on all four.
- Loudnorm: all four within 1 LU of −16 and TP ≤ −1 dB.
  Cut_rope at −16.80 is 0.80 LU from target — inside the gate, but
  the closest edge in the group, exactly as the fixer flagged. It
  PASSES as measured; any future re-encode of this clip must not
  drift further down (see fix list note).

### Method note (a trap caught, not repeated)

An output-position `-ss` on the volumedetect calls was silently
ignored by ffmpeg and returned whole-file statistics (e.g. moves
card window reading −20.9/−3.9, i.e. content levels). All card and
boundary figures above were re-measured with `atrim` and cross-checked
with input-position `-ss`; both correct methods reproduce the
fixer's −91.0 dB figures exactly. Anyone re-checking card silence
should use `atrim`, not output `-ss`.

### Fresh transcripts (re-QC's own Whisper tiny, content-only, en p=1.00)

- moves: "He's not normal. His shadow moves on its own." +
  "This is the seventh family. If no one takes him, it's the adult
  shelter." Complete thoughts, no mid-sentence cut at either end,
  hook speech at 0 s, payoff resolves before the 9.0 s card boundary.
- knocks: "Why do you have to move?" (hook at 0 s) +
  "It's knocking. Have you ever let it knock?" +
  "Shadows don't knock." + "Yours does. You've just never opened
  the door for it." (payoff resolves before the 13.5 s boundary;
  the 2.0–5.0 s speech gap is real and unchanged).
- doors: "Your ability isn't to your shadow." + "Your ability is
  doors." + "You can open anything, including time, including seals,
  including the locksmith." Payoff resolves before the 15.5 s
  boundary. First speech lands at ~4 s (see per-clip note) — the
  4 s speech-free cold open from the original QC stands.
- cut_rope: "Cut the rope." + "A live." (Whisper's rendering of the
  baked "alive" payoff). Hook and payoff both survive the recut; no
  mid-sentence cut at either end; the splice at 4.5 s falls in a
  speech gap (hook ends ~1.9 s, "alive" starts ~6.9 s).

## EXPLICIT SCRUTINY — judged, not waved through

### 1. Crow pillarbox: every baked line whole; pad cards whole, no doubling

CONFIRMED on full-size frames, by frame number:

- moves: n30 baked "he's not normal his shadow moves on its own"
  whole on two lines; n135 "this is the seventh family" whole (was
  "this is th…"); n240 "if no one takes him it's the adult shelter"
  whole (was "if no one takes …"). Boy + moving shadow both whole
  in frame at n240/n269.
- knocks: n60 baked "why do you have to move" whole, no added card
  yet; n150 "it's knocking have you ever let it knock" whole (was
  sliced at both edges), no added card on that frame; n200 whole
  likewise.
- doors: n232 baked "your ability is doors" whole (was "…bility is
  doors"); n360 payoff "including time including seals including
  the locksmith" whole on two lines (was sliced at both edges).
- No baked line on any checked frame is cut through at any edge,
  including the payoff lines. The strip is a true full-frame
  preserve, not a crop: 1080/608 = 1.776 vs source 1920/1080 = 1.778
  (rounding only); row-sharpness analysis puts the sharp strip at
  exactly y656–1264 (gradient 0.9–3.6 vs 0.02–0.29 in the pads),
  i.e. the strip is vertically centred (centre y960), spanning
  y656–1264. The fixer's phrase "centred at y=656" is loose wording
  for "top edge 656, vertically centred" — geometry confirmed,
  wording clarified, not a defect.
- Added cards are whole, bold, readable at phone scale, and sit in
  the bottom pad, never on the strip: moves "SEVENTH FAMILY" [0.3–3.2]
  (present n30, gone n96 — window exact), knocks "SHADOWS DON'T
  KNOCK" [3.0–4.8] (see §3), doors "HIS REAL POWER" [1.0–4.0]
  (present n30, gone n120 — window exact). Measured card glyph rows
  are y1309–1340 on all three card frames: the fixer's "MarginV=1290"
  is the ASS offset, and the glyph top lands 19 px below it (font
  ascent), giving a 45 px glyph gap below the strip bottom (1264),
  not 26 px. Still snug, still below the strip, never on it.
  No added card shares a word with any concurrent baked subtitle:
  moves card vs "he's not normal…", cut_rope card "SHE SURVIVES" vs
  baked "cut the rope" — no shared words in either case.
- Nothing important sits below y=1500 in Crow content: measured
  baked subs end at y1150–1194 (better than the fixer's conservative
  "~1250"), cards at y1309–1340. Only the end card's own tagline
  sits below y=1500, per the standing exception.

### 2. Blur-pad echo: illegible smudge, NOT a doubled caption — PASS with caveat

CONFIRMED as disclosed, and judged as follows. The blur pads do
carry a faint blurred echo of the frame's own baked subtitle. On
full-size frozen stills, with prior knowledge of the sharp line
directly above it, fragments of the echo are guessable (the most
decipherable case seen is moves n30's second line "own"). But the
echo is heavily blurred, low-contrast, and smeared; in motion and at
phone scale it reads as a blur smudge, not as text, and no viewer
reads it as a second caption. A doubled caption means two legible
captions; this is one legible caption plus its own blur artefact.
That distinction is what the pass rests on, and it is recorded here
so the coordinator can see exactly how close the call is: if the
coordinator's bar were "zero decipherable echo on a frozen still",
no blur-fill treatment could ever pass, and these three would fail
on that bar. On the doubling rule as written, they pass. The echo
is the Crow clips' honest weakest point (see per-clip notes).

### 3. Knocks 1.8 s card: enough for one clean read — PASS

CONFIRMED frame-exact: n89 no card, n90–n143 card, n144 no card —
exactly [3.0–4.8]. Every card frame checked (n90, n120, n143) sits
over a captionless corridor stretch (strip bright-row analysis on
n90 finds no baked text at all), and n150 carries the baked "knock"
line with no card on it. The "captionless stretch literally true"
claim is now CORRECT, and no shared word ("knock") occurs between
card and any concurrent baked sub — the [3.0–5.8] attempt's overlap
is gone. On duration: 1.8 s = 54 frames of large, bold, three-word
type ("SHADOWS DON'T KNOCK") is comfortably enough for one clean
read at phone scale (a three-short-word read takes well under a
second at this size). It is the shortest card in the group and
there is no margin to shorten it further, but as shipped it passes.

### 4. Cut_rope recut: NO delivered frame centres the revealing costume — PASS

Swept at 1 fps across all 8.5 s of content plus boundary frames by
number (n134, n135, n150, n254, n255), and the result is:

- Segment A (clip 0–4.5 s): face close-ups (~0–2 s) + knights running
  (~2–4 s) + empty bridge wall (~4–4.5 s). No torso close-up, no
  full-body bridge walk, no falling-body shot survives in segment A.
- Segment B (clip 4.5–8.5 s): knight over the splash + knight beats
  + baked "alive" frame (n210: knight beat, "alive" whole, no witch
  in frame) + legs/boots underwater beat (n254: action beat, no
  bodice/midriff in frame).
- The excised 62.5–72.0 s stretch (torso close-ups, full-body bridge
  walk, falling-body shots) is genuinely out — none of it appears
  in the 1 fps sweep or the boundary frames.
- Face close-ups: judged as acceptable source framing, NOT
  costume-showcase. The face is centred (eyes, forehead mark, and
  expression are the shot's subject); the bone bodice and bare
  midriff ARE visible across the lower frame — this is stated
  plainly, not minimised — but they sit in the lower third, below
  the centred face, as the source's face framing dictates. The
  stated FAIL criterion is "centres the costume"; no frame does
  that. If the coordinator holds a stricter "no revealing costume
  visible at all" bar, these face frames would fail it — but that
  bar would also fail any use of this source's face shots, and it
  is not the criterion set for this re-QC.
- First segment-B frame (n135): knight + splash confirmed, and the
  hair/head sliver at the extreme bottom-right corner is confirmed
  on an enlarged corner crop (top of dark hair + a sliver of face,
  partly behind splash). NO costume is visible in it. By n150
  (0.5 s later) the sliver is gone — corner crop shows water/splash
  only. "Gone within ~0.5 s" holds.
- Splice coherence: n134 = empty bridge wall/parapet (no person),
  n135 = knight looking down at the splash. The cut reads as an
  ellipsis — knights running, then the knight already at the water
  where she fell — and the splash + "alive" + moving legs/boots
  close the loop. Audio splice check: 0.1 s slices around 4.5 s run
  −19 to −24 dB mean with no transient spike, and the splice falls
  in a speech gap, so there is no audible click and no cut word.
- Completeness judgment: the 8.5 s recut DOES read as a complete
  message, not a confusing jump. Hook ("Cut the rope." + knights
  running) → implied fall (empty wall → splash) → payoff ("alive"
  + legs/boots moving underwater). The middle action is implied by
  the splash rather than shown — that is the clip's weakest point,
  disclosed, not hidden — but a first-time viewer follows it:
  she cut the rope, fell, and is found alive. It is short and
  elliptical, not confusing.

### 5. Cut_rope baked subs at y1483–1515: unchanged, not worsened — NOT newly failed

Measured on full-size frames: "cut the rope" y1483–1516 (n30),
"alive" y1484–1515 (n210) — identical within 1 px to the original
QC's ~y1483–1515. The straddle of the y=1500 line is a source-native
property (vertical source, no reframe); the recut did not move,
enlarge, or re-render these subs. Marginal, as originally flagged;
not worsened; not a new failure on its own, per the original QC's
own judgment.

### 6. Untouched check: dead_hide and ice_fix_arc UNCHANGED — no scope breach

- g3_witch_dead_hide.mp4: mtime 2026-10-29 15:03:19, size
  21,961,977 bytes — predates the 19:28:06 rebuilds.
- g3_ice_fix_arc.mp4: mtime 2026-10-29 16:25:54, size 22,606,790
  bytes — predates the 19:28:06 rebuilds.
- Corroboration: both untouched files still report 96 kHz audio,
  while all four rebuilt files report 48 kHz — the rebuilds went
  through the new encode path and these two did not.
- Per instructions, content of these two clips was NOT re-QC'd;
  only timestamps/sizes (plus the sample-rate corroboration) were
  checked. Neither was modified. No scope breach to report.

## Per-clip verdicts

### 1. g3_crow_shadow_moves.mp4 — PASS
- Probe/decode/card: PASS (405 frames; card frames 270–404; decode
  clean; faststart).
- Audio: PASS — content-only 197.1 kbps (true 192k); I/TP
  −16.06/−3.90; card silent −91.0/−70.3; boundary clean.
- Baked subs: PASS — all lines whole (n30 two lines, n135, n240);
  strip full-frame, no crop; subs end y≤1194; card in bottom pad
  y1309–1340, no shared words.
- Transcript: PASS — English p=1.00, complete, hook at 0 s, payoff
  before the card.
- Honest weakest point: the blur-pad echo (§2) — faintly
  guessable on frozen stills, a smudge in motion; plus the dark
  opening frame (source property, unchanged).

### 2. g3_crow_shadow_knocks.mp4 — PASS
- Probe/decode/card: PASS (540 frames; card frames 405–539; decode
  clean; faststart).
- Audio: PASS — content-only 197.7 kbps; I/TP −16.00/−1.43; card
  silent −91.0/−76.3; boundary clean.
- Baked subs / hook card: PASS — all lines whole (n60, n150, n200);
  hook card [3.0–4.8] frame-exact over a literally captionless
  stretch, no shared words; 1.8 s is enough for one clean read (§3).
- Transcript: PASS — English p=1.00, complete, hook question at
  0 s, payoff before the card.
- Honest weakest point: the 1.8 s card has no margin to shorten
  further, and the ~3 s speech gap (2.0–5.0 s) over the corridor
  still leans on the card visually; plus the blur-pad echo (§2).

### 3. g3_crow_ability_doors.mp4 — PASS
- Probe/decode/card: PASS (600 frames; card frames 465–599; decode
  clean; faststart).
- Audio: PASS — content-only 197.8 kbps; I/TP −15.97/−2.22; card
  silent −91.0/−66.8; boundary clean.
- Baked subs / hook card: PASS — "your ability is doors" (n232)
  and the two-line payoff (n360) whole; "HIS REAL POWER" [1.0–4.0]
  whole in the bottom pad over a captionless stretch (n30), gone
  by n120, no shared words.
- Transcript: PASS — English p=1.00, complete, payoff resolves
  before the card.
- Honest weakest point: the ~4 s speech-free cold open stands
  (captionless at n30 and n120; the 0–1 s audio energy is music,
  not speech) — viewers are held by the boy+shadow visual and the
  card alone until ~4 s; plus the blur-pad echo (§2).

### 4. g3_witch_cut_rope.mp4 — PASS
- Probe/decode/card: PASS (390 frames; card frames 255–389; decode
  clean; faststart). Content 8.5 s + card 4.5 s = 13.0 s total, as
  claimed (recut from the original 23.0 s).
- Audio: PASS — content-only 198.0 kbps; I/TP −16.80/−1.40
  (within 1 LU of −16, closest edge — see headline note); card
  silent −91.0/−80.8; splice at 4.5 s clean, in a speech gap.
- Costume: PASS on the stated criterion — no delivered frame
  centres the revealing costume (§4). Face close-ups centre the
  face with the bodice in the lower frame (source framing);
  n135 sliver is hair/head only, no costume, gone by n150.
- Baked subs: PASS with the standing marginal note — y1483–1516
  straddle unchanged from the original, not worsened (§5).
- Transcript: PASS — English p=1.00, "Cut the rope." + "A live.",
  hook and payoff survive, no mid-sentence cut.
- Honest weakest point: the middle action is implied by the splash
  rather than shown, and 8.5 s is short — the clip is elliptical
  by construction. It still reads complete (§4), but it has the
  least margin of the four if a viewer misses the splash beat.

## What the fixer got right (verified, not assumed)

- Dimensions, frame rate, codec, sample rate (48 kHz), faststart,
  frame counts, content durations, and the exact 135-frame end card
  on all four: all reproduce exactly.
- Content-only bitrates ≈197–198 kbps on all four: true 192k AAC
  by the correct method.
- Loudnorm I/TP and card-silence figures reproduce exactly
  (including cut_rope −16.80/−1.40, flagged not hidden).
- Crow strip geometry (y656–1264, full frame, no crop), pad-card
  placement (glyphs y1309–1340, never on the strip), and every
  claimed whole baked line: all confirmed on full-size frames.
- Knocks card correction: [3.0–4.8] is frame-exact, captionless
  throughout, and free of the "knock" overlap that sank [3.0–5.8].
- Cut_rope recut: excised stretch genuinely out, splice points
  exactly as claimed (n134 empty wall, n135 knight + splash,
  n254 legs/boots, n255 card), hook + payoff survive.

## What the fixer got slightly wrong or loose (none of it a failure)

1. "Strip centred at y=656" — the strip spans y656–1264 and is
   centred at y960 (canvas centre); 656 is its top edge. Geometry
   right, wording loose.
2. "Cards at y1290–1380 / strip bottom 1264 + 26 px gap" — the ASS
   MarginV is 1290, but measured glyph tops are y1309, i.e. a 45 px
   glyph gap below the strip. Still snug, still below the strip.
3. "Baked subs end ~y1250" — measured ends are y1150–1194, i.e.
   better (higher) than claimed.
4. Content-only bitrates run 0.4–0.7 kbps above the fixer's quoted
   figures — immaterial, same verdict.
5. The blur-pad echo is described as "illegible smudge". That is
   true in motion/at phone scale, but on frozen full-size stills
   fragments are guessable with prior knowledge (§2). The
   description is fair as a viewing judgment, incomplete as a
   still-frame description — hence the recorded caveat.

## Fix list

No clip fails, so no fix is required before these four are treated
as shippable on QC evidence. Two notes, not fixes:

1. Cut_rope loudnorm (−16.80, 0.80 LU from target): passes, but do
   NOT re-encode this clip's audio without re-measuring — any
   further downward drift would breach the 1 LU gate.
2. Judgment calls for the coordinator to own (not QC failures):
   (a) the blur-pad echo (§2) and (b) the face-close-up bodice
   visibility in cut_rope (§4). Both pass on the criteria as
   written; if the coordinator holds a stricter bar on either,
   that is a policy call, not a missed defect — and it would need
   a different treatment (not a blur fill, / not this source's face
   shots), not a rebuild of these files.

Nothing was uploaded, published, submitted, or sent to anyone during
this re-QC. No clip file was modified; this report is the only file
written.
