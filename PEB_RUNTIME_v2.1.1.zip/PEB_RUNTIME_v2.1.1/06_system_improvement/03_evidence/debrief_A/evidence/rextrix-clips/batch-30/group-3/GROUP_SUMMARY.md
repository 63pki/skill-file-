# Batch-30 Group 3 — GROUP SUMMARY

6 clips delivered (target met, no padding). All 6 pass self-QC: 1080x1920,
30 fps, h264/AAC, null decode OK, frame count = duration × 30, loudnorm
I between -15.89 and -16.47, true peak ≤ -1.21 dB, end-card audio silent
(mean -91.0 dB on every clip), cards whole/centred/readable on frames, no
added card shares words with any concurrent baked subtitle, no mid-sentence
cuts, hook card lands in 1–3 s on every clip, payoff before the card.

| Clip | Content | Total | I / TP | Card audio |
|---|---|---|---|---|
| g3_crow_shadow_moves | 9.0 s | 13.5 s | -16.06 / -3.90 | -91.0 / -70.3 |
| g3_crow_shadow_knocks | 13.5 s | 18.0 s | -16.00 / -1.43 | -91.0 / -76.3 |
| g3_crow_ability_doors | 15.5 s | 20.0 s | -15.97 / -2.22 | -91.0 / -66.8 |
| g3_witch_cut_rope | 18.5 s | 23.0 s | -16.47 / -1.21 | -91.0 / -80.8 |
| g3_witch_dead_hide | 20.0 s | 24.501 s | -16.15 / -1.49 | -91.0 / -76.3 |
| g3_ice_fix_arc | 24.7 s | 29.2 s | -15.89 / -1.41 | -91.0 / -80.8 |

## What passed
- All three shows yielded strong clips; Ice Road Rig ep1 turned out to be a
  60 s vertical short, and its fix arc still makes a complete 24.7 s clip.
- Card-wording discipline held everywhere: crow cards sit on verified
  captionless stretches (knocks, doors) or share no words with the concurrent
  baked sub (moves, both witch clips); ice has no baked dialogue subs.
- Transcript discipline held: baked subs treated as the dialogue record for
  Witch (Whisper misheard "kneel before the city"); a no-VAD pass verified
  the doors clip's silent gap; Whisper's no-VAD hallucination loop over
  witch music ("The city costs you out!") was identified and discarded.

## What was fixed
- **True-peak overshoot (all clips):** loudnorm to TP=-1.0 on wav, then AAC
  re-encode, overshoots by ~0.1–0.15 dB. Builder now hard-limits at 0.85
  (measured TP -1.49 on the worst case) — every delivered clip passes.
- **Card-boundary transient (witch_dead_hide):** a -40.8 dB splice transient
  in the first 0.5 s of the card. Fixed with a 0.3 s fade-out ending exactly
  at the content boundary; the step is now in the builder for all clips.
- **Saliency reframe failure (crow_shadow_moves):** default reframe tracked
  the bright doorway/empty corridor and left the boy out of frame; a
  --center-weight 0 re-run was worse. Rebuilt with a subject-locked crop
  (x=196, static camera) — boy in frame throughout, verified on frames.
  The other two crow clips' saliency tracks were verified good on frames
  (knocks: shadow figure centred; doors: boy + shadow figure apart).
- **Pipeline robustness:** final encodes now use `-threads 2` +
  `-x264-params threads=2` with real exit-code + moov checks after an OOM
  kill and a piped-exit-code false pass earlier in the session.
- **VM restarts:** the chain was killed twice by VM restarts (uptime
  confirmed) and relaunched from the next unbuilt clip each time; the
  builder is idempotent, so no clip was corrupted by a restart.

## What is still weak (honest)
- **Crow clips (1–3):** any 9:16 crop of these landscape frames slices the
  wide baked subtitle lines (audio lines are complete; the visible fragments
  look cut). The 608 px crop upscaled to 1080 is also softer than native.
  If the coordinator wants baked subs fully intact, the batch-6
  strip-over-blur treatment is the alternative — it was NOT used here
  because this brief mandates saliency reframe.
- **Witch clips (4–5):** revealing costume in some frames (face/action
  framings chosen; no lingering costume shots); dialogue is sparse, so both
  clips lean on visuals.
- **Ice clip (6):** mounted gun present throughout (repair context, no
  violence against people); some lines sound dubbed.
- **Held backup:** witch defiance (248.0–272.5 s) unbuilt for the
  chest-vein/costume flag — available on coordinator request.

## Downloads
No BLOCKED downloads. All three episode-1 files downloaded via curl and
verified by exact byte size + ffprobe (Crow 631,300,972; Ice 93,643,588;
Witch 459,819,225). Two curls died simultaneously mid-download and were
range-resumed to exact size.

## Nothing uploaded
No clip was uploaded, published, submitted, or sent to anyone. Delivery is
the 6 mp4s + NOTES.md + this summary in `group-3/` only.

## FIX LOOP — 2026-10-30 (separate fix agent; QC's audio FAIL overturned by
the coordinator — see NOTES.md for the full record)
- QC's 0/6 verdict rested on full-file bitrate (130–168 kbps), which the
  4.5 s silent end card dilutes. Content-only measurement (content audio
  size ÷ content duration) gives 196.7–198.3 kbps on all six — true 192k
  AAC. dead_hide and ice_fix_arc were NOT touched and now PASS on that
  corrected method; their only QC notes are source-property flags.
- REBUILT (4 clips, verified before promotion, originals in
  `work/pre-fix/`):
  - crow_shadow_moves: strip-over-blur rebuild, same 9.0 s content,
    13.5 s total, 405 frames; content-only 196.7 kbps, I/TP -16.06/-3.90.
  - crow_shadow_knocks: strip-over-blur rebuild, same 13.5 s content,
    18.0 s total, 540 frames; hook card corrected to [3.0–4.8] (the
    [3.0–5.8] first attempt overlapped the baked "knock" line and
    shared a word — caught on frame check and fixed); content-only
    197.1 kbps, I/TP -16.00/-1.43.
  - crow_ability_doors: strip-over-blur rebuild, same 15.5 s content,
    20.0 s total, 600 frames; payoff baked line now whole;
    content-only 197.1 kbps, I/TP -15.97/-2.22.
  - witch_cut_rope: RECUT (not dropped) — 58.0–62.5 + 72.5–76.5 s,
    8.5 s content, 13.0 s total, 390 frames; the 62.5–72.0 s
    costume-showcase stretch (torso close-ups, full-body bridge walk,
    falling-body shots) is out; hook "Cut the rope" + "alive" payoff
    both survive (Whisper tiny, English p=1.00); content-only
    197.6 kbps, I/TP -16.80/-1.40 (within 1 LU, closest to the edge —
    flagged in NOTES.md).
- Crow deviation recorded in NOTES.md: added cards sit in the bottom
  blur pad (snug below the strip edge), NOT centred Y50% over the video
  — required by the baked-text rule for landscape sources, scoped to
  these three clips only.
- All four rebuilt clips: 1080x1920, 30 fps, 48 kHz, null decode clean,
  faststart, frame count = duration × 30, end card exactly 135 frames
  end-only, card audio silent (mean -91.0 dB), boundary slices clean.
- Honest weakest points post-fix: faint blurred subtitle echo in the
  Crow blur pads (illegible smudge, not readable text); knocks card
  now only 1.8 s; cut_rope is short (8.5 s content) with the middle
  action implied by the splash, and its face close-ups still show the
  bodice at the bottom edge (face-centred, source framing).
- Nothing dropped, nothing uploaded, published, submitted, or sent.
