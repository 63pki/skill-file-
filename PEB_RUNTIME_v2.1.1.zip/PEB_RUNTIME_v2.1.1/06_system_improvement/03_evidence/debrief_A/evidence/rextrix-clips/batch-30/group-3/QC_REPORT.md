# Batch-30 Group 3 — INDEPENDENT QC REPORT (not the builder's self-QC)

QC by an independent agent. No clip file was modified. No upload, publish,
submission, or contact was made. All measurements below are the QC agent's
own: ffprobe, ffmpeg null decode, loudnorm, volumedetect, frame-number
selection (not timestamp seeks), and a fresh faster-whisper tiny pass
(ffmpeg 16 kHz mono wav → numpy float32, content-only audio, language en).

## HEADLINE VERDICT: 0 of 6 PASS — 6 of 6 FAIL

Every clip fails on the same hard spec item: **audio is NOT true 192 kbps
AAC**, by both measurement methods, on all six files. The builder's
"192k" claim is contradicted by its own files. Three Crow clips fail a
second, independent hard item: **baked subtitles are visibly sliced
through** (cut-through partial words), against the brief's baked-text
rule ("frame around baked text, never crop through"). One further
coordinator-risk item is NOT cleared: the witch revealing-costume flag
on cut_rope.

Nothing here is softened. A clip marked FAIL below must be fixed and
re-verified before it is treated as shippable, even where everything
else on that clip passes.

## Measurements common to all clips (QC's own readings)

| Clip | Total | Content | Frames | Video | Faststart | Decode |
|---|---|---|---|---|---|---|
| g3_crow_shadow_moves | 13.500 s | 9.0 s | 405 | 1080×1920, 30 fps, H.264 | moov @36, before mdat | clean |
| g3_crow_shadow_knocks | 18.000 s | 13.5 s | 540 | 1080×1920, 30 fps, H.264 | moov @36, before mdat | clean |
| g3_crow_ability_doors | 20.000 s | 15.5 s | 600 | 1080×1920, 30 fps, H.264 | moov @36, before mdat | clean |
| g3_witch_cut_rope | 23.000 s | 18.5 s | 690 | 1080×1920, 30 fps, H.264 | moov @36, before mdat | clean |
| g3_witch_dead_hide | 24.501 s* | 20.0 s | 735 | 1080×1920, 30 fps, H.264 | moov @36, before mdat | clean |
| g3_ice_fix_arc | 29.200 s | 24.7 s | 876 | 1080×1920, 30 fps, H.264 | moov @36, before mdat | clean |

\* dead_hide: 735 frames = exactly 24.5 s of video; the 24.501 s container
duration is a 1 ms audio-stream rounding artefact. Not a failure.

Frame counts equal duration × 30 on all six. Content on all six is
≤ 25 s. End card on all six is exactly 135 frames (4.5 s) at the end
only, verified by frame number: first card frame = content×30, last
frame = total−1, and the frame before the card is content in every
case (moves 269/270, knocks 404/405, doors 464/465, cut_rope 554/555,
dead_hide 599/600, ice 740/741). No end-card frame was seen anywhere
except the final 135 frames. End cards are whole, centred, readable at
phone scale: RexTrix logo + "Download the RexTrix app — link in bio",
plus the "AI-generated Games & Stories" tagline at ~y1575 — that
tagline is the card's own design and is NOT counted as a failure, per
the brief exception. Added hook cards are whole, centred, readable,
≤ 3 words, and share NO word with any concurrent baked subtitle on any
checked frame (see per-clip notes).

### Audio — the batch-wide FAIL (measured twice, both methods agree)

| Clip | ffprobe stream bitrate | Extracted-stream size ÷ duration | Sample rate | Loudnorm I / TP | Card last 4.5 s (mean / max) | Card first 0.5 s (mean / max) |
|---|---|---|---|---|---|---|
| crow_shadow_moves | 130 kbps | 132.4 kbps (223,455 B / 13.5 s) | 48 kHz | −16.06 / −3.90 | −91.0 / −70.3 | −91.0 / −70.3 |
| crow_shadow_knocks | 147 kbps | 148.7 kbps (334,665 B / 18.0 s) | 48 kHz | −16.00 / −1.43 | −91.0 / −76.3 | −91.0 / −76.3 |
| crow_ability_doors | 152 kbps | 153.6 kbps (384,048 B / 20.0 s) | 48 kHz | −15.97 / −2.22 | −91.0 / −66.8 | −91.0 / −66.8 |
| witch_cut_rope | 158 kbps | 161.0 kbps (462,938 B / 23.0 s) | 96 kHz | −16.47 / −1.21 | −91.0 / −80.8 | −91.0 / −80.8 |
| witch_dead_hide | 160 kbps | 163.1 kbps (499,633 B / 24.501 s) | 96 kHz | −16.15 / −1.49 | −91.0 / −80.8 | −91.0 / −76.3 |
| ice_fix_arc | 165 kbps | 168.4 kbps (614,518 B / 29.2 s) | 96 kHz | −15.89 / −1.41 | −91.0 / −80.8 | −91.0 / −80.8 |

Required: true 192 kbps AAC by BOTH methods. Measured: 130–168 kbps.
**FAIL on all six.** This is not a rounding or metadata quirk — the
extracted audio streams are physically smaller than a 192 kbps encode
of the same duration would be, on every clip. The builder's "AAC 192k"
claim is therefore false as delivered, whatever encoder flag was
intended. (The previous group's QC caught the same class of error at
91–149 kbps; this group is better but still not 192k.)

Loudnorm otherwise PASSES everywhere: integrated −15.89 to −16.47 LUFS
(all within 1 LU of −16) and true peak −1.21 to −3.90 dB (all ≤ −1 dB);
the builder's I/TP figures reproduce exactly. Card audio is silent on
all six (mean −91.0 dB throughout; worst peak −66.8 dB, doors). The
±0.5 s boundary slices show energy only on the content side (e.g.
dead_hide content-last-0.3 s: mean −39.0 / max −25.9 dB), with the card
side silent — no splice transient leaks into any card.

Sample-rate inconsistency (also a fix item): Crow clips are 48 kHz,
Witch and Ice clips are 96 kHz. 96 kHz is non-standard for this
pipeline and the split shows the batch was not encoded on one path.

## Sliced baked subtitles — Crow clips: FAIL on this point, all three

The builder admitted any 9:16 crop slices the wide Crow subtitle lines.
QC confirms the slices are not unobtrusive: they are cut-through
partial words at the frame edges, plainly visible at full size, on
multiple frames of every Crow clip. Under the brief's rule ("frame
around baked text, never crop through") this is a defect, not a
passable artefact. Audio lines are complete, but the visible text is
mutilated. Judgment per clip:

- **crow_shadow_moves — SLICED-SUB POINT: FAIL.** Frame n135 (4.5 s):
  baked "this is th…" — the word is cut mid-word at the right edge.
  Frame n240 (8 s): "if no one takes …" — trailing word cut at the
  right edge. Frame n30 (1 s) shows the full line "he's not normal"
  only because that line is short; the longer lines are sliced.
- **crow_shadow_knocks — SLICED-SUB POINT: FAIL.** Frame n60 (2.0 s):
  "…u have to move" — left-truncated ("Why do you" cut to "u").
  Frame n200 (6.7 s): "…g have you ever…" — sliced at BOTH edges.
  Frame n150 (5 s): "…e you ever let it…" — sliced at both edges.
- **crow_ability_doors — SLICED-SUB POINT: FAIL.** Frame n232 (7.7 s):
  "…bility is doors" — left-truncated ("Your ability" cut to
  "bility"). Frame n360 (12 s, on the payoff line itself):
  "…including seals in… / …he locksmith" — two lines sliced at
  both edges, on the clip's core reveal.

Compounding measurement: Crow baked subtitles sit at y ≈ 1610–1700
(measured bright-row ranges: moves n30 1500–1650, moves n135 1607–1701,
knocks n60 1629–1702, doors n232 1606–1702) — i.e. their bottom edge is
~200 px BELOW the y=1500 line, where Shorts bottom UI sits. The
builder's "nothing important below y=1500" claim is therefore incorrect
for baked subtitles on the Crow clips. (Witch baked subs straddle the
line at ~y1483–1515 — marginal, not failed on this point alone.)

The builder's note that the brief mandates saliency reframe (not
strip-over-blur) is acknowledged, but it does not convert a FAIL into
a pass: either the coordinator waives the baked-text rule for these
three clips explicitly, or they are rebuilt with the batch-6
strip-over-blur treatment so subtitle lines survive whole. QC does not
waive it for them.

## Per-clip verdicts

### 1. g3_crow_shadow_moves.mp4 — FAIL
- Probe/decode/card: PASS (405 frames; card frames 270–404; decode clean).
- Audio bitrate: FAIL — 130 / 132.4 kbps, not 192k. Loudnorm PASS
  (−16.06 / −3.90). Card silent PASS.
- Sliced subs: FAIL (see above: "this is th…", "if no one takes …").
- Subject-lock reframe: PASS — the boy is in frame and whole on every
  checked frame (n30, n90, n135, n240, n269): seated, headroom intact,
  and boy + moving shadow both in frame at n240/n269. The mandated
  saliency reframe's failure is real (builder's v1 history is
  plausible given the doorway/corridor brightness), and the static
  x=196 crop fixes the framing problem. It does NOT fix the subtitle
  slicing. Softness from the 608 px upscale is visible but not failed
  on its own.
- Doubling: PASS — "SEVENTH FAMILY" (n30, n90) vs concurrent baked
  "he's not normal": no shared words.
- Transcript (QC's own Whisper): PASS — English, p=1.00: "He's not
  normal. His shadow moves on its own." (0.94–4.18) + "This is the
  seventh family. If no one takes him, it's the adult shelter."
  (4.66–8.18). Complete thoughts, no mid-sentence cut at either end,
  hook speech at 0.94 s, payoff resolves before the card.
- Retention: hook strong (speech <1 s + card at 0.3 s); weakest
  second is the very dark opening frame (n30: boy barely visible in
  shadow) and the sliced sub at 4.5 s.
- FIX: re-encode audio at true 192 kbps CBR, 48 kHz, then re-verify
  bitrate both ways + I/TP; AND resolve sliced subs (strip-over-blur
  rebuild or explicit coordinator waiver of the baked-text rule).

### 2. g3_crow_shadow_knocks.mp4 — FAIL
- Probe/decode/card: PASS (540 frames; card frames 405–539; decode clean).
- Audio bitrate: FAIL — 147 / 148.7 kbps, not 192k. Loudnorm PASS
  (−16.00 / −1.43). Card silent PASS.
- Sliced subs: FAIL (see above: "…u have to move", "…g have you
  ever…", "…e you ever let it…").
- Saliency tracking: PASS with a qualification — at n240 (8 s) the
  shadow figure is large on the left and the boy is in frame on the
  right (the pair is tracked, not lost); at n200 (6.7 s) the corridor
  two-shot puts the woman full-left and the boy partial-right, which
  is a dialogue framing, not a lost subject. No frame checked loses
  the subject entirely.
- Doubling: PASS on words — "SHADOWS DON'T KNOCK" shares no word with
  any concurrent baked sub. BUT the builder's "card over a captionless
  stretch" claim is overstated: at n60 (2.0 s, card start) the baked
  tail "…u have to move" is still on screen; the stretch is only
  captionless from ~n90 (3.0 s) onward (n90, n120 both clean). The
  card window [2.0–4.8] therefore overlaps a baked sub for roughly its
  first second. Minor on its own (no shared words), but the claim as
  written is inaccurate.
- Transcript (QC's own Whisper): PASS — English, p=1.00: "Why do you
  have to move?" (0.00–2.00), "It's knocking. Have you ever let it
  knock?" (5.00–7.52), "Shadows don't knock." (8.22–9.24), "Yours
  does. You've just never opened the door for it." (9.74–12.56).
  Complete, payoff resolves at 12.56 s, before the 13.5 s card boundary.
- Retention: hook question lands at 0 s; weakest stretch is the
  ~3 s speech gap (2.0–5.0 s) over the empty corridor — the card
  carries it visually, but it is dead air in audio.
- FIX: same audio re-encode + re-verify as clip 1; same sliced-sub
  resolution; optionally shift the hook card start to ~3.0 s so the
  "captionless stretch" claim becomes literally true.

### 3. g3_crow_ability_doors.mp4 — FAIL
- Probe/decode/card: PASS (600 frames; card frames 465–599; decode clean).
- Audio bitrate: FAIL — 152 / 153.6 kbps, not 192k. Loudnorm PASS
  (−15.97 / −2.22). Card silent PASS.
- Sliced subs: FAIL (see above: "…bility is doors", payoff-line
  "…including seals in… / …he locksmith").
- Saliency tracking: PASS — n30 (1 s) shows boy + shadow figure both
  whole, apart, centred ("HIS REAL POWER" over a captionless frame);
  n232/n360 show the boy's close-up centred. No lost-subject frame
  in the checked set.
- Doubling: PASS — "HIS REAL POWER" sits on a captionless stretch
  (n30 clean; no concurrent baked sub).
- Transcript (QC's own Whisper): PASS — English, p=1.00: "Your
  ability isn't to your shadow." (4.00–6.28), "Your ability is
  doors." (7.06–8.28), "You can open anything, including time,
  including seals, including the locksmith." (9.36–15.00). Complete
  payoff, resolves at 15.00 s before the 15.5 s card boundary. Note
  the 4.0 s speech-free cold open (the verified silent gap) — the
  card at 1.0–4.0 s covers it visually, but first speech lands at
  4.0 s, outside the 1–3 s hook ideal.
- Retention: strongest payoff in the group (the core reveal), but
  weakest opening: 4 s of silence before any speech; viewers must be
  held by the boy+shadow visual and the card alone.
- FIX: same audio re-encode + re-verify as clip 1; same sliced-sub
  resolution (most regrettable here, because the slicing hits the
  payoff line itself).

### 4. g3_witch_cut_rope.mp4 — FAIL
- Probe/decode/card: PASS (690 frames; card frames 555–689; decode clean).
- Audio bitrate: FAIL — 158 / 161.0 kbps, not 192k; sample rate 96 kHz
  (inconsistent with Crow's 48 kHz). Loudnorm PASS (−16.47 / −1.21).
  Card silent PASS.
- Doubling: PASS — "SHE SURVIVES" (n30) vs concurrent baked "cut the
  rope": no shared words; the baked line is intact (native vertical
  source, no slicing).
- Revealing-costume flag: NOT CLEARED. The builder's "face/action
  framings only" description understates what the frames show. n30
  (1 s, face close-up) already shows the bone bodice and bare
  shoulders/midriff across the lower frame. n277 (9.2 s, bridge walk)
  is a full-body shot in which the bone bodice, bare midriff, and
  high-slit skirt are the visual centre of the frame — that IS a
  costume-emphasising framing, even though the witch is walking
  (action) rather than posing. n540/n554 (legs/boots close-up, the
  "alive" beat) are action shots, not costume lingers. Verdict on
  this point: the clip contains at least one prominent
  costume-showcase beat, so the flag cannot be marked resolved; it
  needs a coordinator decision (accept, or recut to face/knight
  beats only and drop the full-body bridge walk).
- Transcript (QC's own Whisper): PASS with sparseness noted — English,
  p=1.00: "Cut the rope." (0.00–1.98), then nothing until "A live"
  (14.44–17.24; the baked "alive" beat). Both are complete utterances,
  no mid-sentence cut; the clip is visual/action-driven, which the
  builder disclosed honestly.
- Retention: hook immediate ("Cut the rope" at 0 s + card at 1 s);
  weakest stretch is the ~12.5 s speech gap (2.0–14.4 s) — the bridge
  action must carry retention alone.
- FIX: audio re-encode at true 192 kbps CBR, unified to 48 kHz, +
  re-verify; AND coordinator ruling on the costume beat (or recut
  without the n277 full-body bridge shot).

### 5. g3_witch_dead_hide.mp4 — FAIL (audio only)
- Probe/decode/card: PASS (735 frames; card frames 600–734; decode clean).
- Audio bitrate: FAIL — 160 / 163.1 kbps, not 192k; sample rate 96 kHz.
  Loudnorm PASS (−16.15 / −1.49). Card silent PASS.
- TP / card-boundary fix: CONFIRMED. The old −40.8 dB card transient
  is gone: card-first-0.5 s measures mean −91.0 / max −76.3 dB
  (matching the builder's claimed −76.3), and the full last 4.5 s
  measures mean −91.0 / max −80.8 dB. (The −76.3 peak sits in the
  first ~1 ms at the boundary — a single fade-residual sample at most
  — and is inaudible; it is not a recurrence of the transient.)
  Boundary ±0.5 s energy is content-side only. TP −1.49 dB passes
  with margin. This fix holds.
- Doubling: PASS — "THEY FOUND HER" (n45) vs concurrent baked "your
  dead cannot hide you": no shared words; baked line intact.
- Costume: no costume-emphasising close-up in checked frames —
  n45 face profile + marching knights, n300 boot foreground with the
  witch small/distant in centre, n599 wide confrontation (witch in
  long dress, back view, not a costume linger). Less exposed than
  cut_rope; the flag is not raised further by this clip.
- Transcript (QC's own Whisper): PASS with sparseness noted — English,
  p=1.00: "Your dead cannot hide you." (0.00–2.00), "I know you."
  (17.50–18.74). Complete lines, payoff resolves before the 20.0 s
  card boundary; ~15.5 s speech gap is visual march/confrontation.
- Retention: hook line at 0 s + card at 1.5 s; weakest stretch is the
  long speech gap (2.0–17.5 s), with the payoff ("I know you") landing
  late at 17.5 s, only 2.5 s before the card.
- FIX: audio re-encode at true 192 kbps CBR, unified to 48 kHz, +
  re-verify bitrate both ways + I/TP. Nothing else on this clip
  requires a fix on QC's evidence.

### 6. g3_ice_fix_arc.mp4 — FAIL (audio only)
- Probe/decode/card: PASS (876 frames; card frames 741–875; decode clean).
- Audio bitrate: FAIL — 165 / 168.4 kbps, not 192k (closest in the
  group, still 24 kbps short); sample rate 96 kHz. Loudnorm PASS
  (−15.89 / −1.41). Card silent PASS.
- Doubling: PASS — "LOOK IT UP" (n15, phone moment) and "NOT THE
  BARREL" (n630, gun-repair moment) are whole, centred, readable;
  Ice has no baked dialogue subs on any checked frame, so no doubling
  is possible. "NOT THE BARREL" is a paraphrase of "not around the
  barrel", not a verbatim duplicate — acceptable under the
  paraphrase discipline, and it does not duplicate any on-screen text.
- Mounted-gun flag: REPAIR CONTEXT CONFIRMED on checked frames —
  n15: gun mount/turret in the background while two men look at a
  phone over a tools case; n370: mount barrel in the background
  during the tools beat; n630/n740: a man handling the mount
  mechanism with a chain, smiling, working on it — no aiming at a
  person, no firing, no violence against people in any checked frame.
  The flag stands as disclosed context, not as a violation found.
- Transcript (QC's own Whisper): PASS with an intelligibility caveat
  — English, p=1.00: phone-lookup advice (0.00–5.46; Whisper garbles
  the opening line — consistent with the builder's "some lines sound
  dubbed" note), "That one's for plumbing." (10.90–12.12), "Clamp
  behind the feed guide, not around the barrel." (19.12–21.44),
  "I know where barrels go." (22.68–24.22). Complete final line
  resolves 0.5 s before the 24.7 s card boundary. Opening line
  intelligibility is the clip's audio weak point, separate from the
  bitrate failure.
- Retention: hook card at 0.5 s + phone beat is clear; weakest
  stretches are the speech gaps (5.5–10.9 s, and the dubbed-sounding
  opening). The fix arc (problem → lookup → instruction → payoff)
  is coherent regardless.
- FIX: audio re-encode at true 192 kbps CBR, unified to 48 kHz, +
  re-verify bitrate both ways + I/TP. Nothing else on this clip
  requires a fix on QC's evidence. (Opening-line intelligibility is
  a source property; a re-encode will not fix it — flag to the
  coordinator if a cleaner take exists, but do not hold the clip for
  it beyond the bitrate fix.)

## What the builder got right (verified, not assumed)

- Dimensions, frame rate, codec, faststart, frame counts, content
  durations, and the exact 135-frame end card: all reproduce exactly.
- Null decode is clean on all six — the twice-killed chain left no
  encode damage in the delivered files.
- Loudnorm I/TP and card-silence figures reproduce exactly (except
  the dead_hide full-card max nuance above, which resolves to the
  builder's −76.3 in the card-first-0.5 s window).
- The dead_hide TP and card-boundary fixes genuinely hold.
- The moves subject-lock crop genuinely keeps the boy in frame (the
  saliency failure it replaced is credible).
- No added card shares a word with a concurrent baked subtitle.
- Transcripts are English-only, complete thoughts, no mid-sentence
  cuts at either end; payoffs resolve before the card on all six.

## What the builder got wrong or overstated

1. "AAC 192k" — false on all six by both measurement methods
   (130–168 kbps). This is the batch's central failure.
2. "Nothing important below y=1500" — false for Crow baked subtitles
   (bottom edge ~y1700).
3. Knocks "card over a captionless stretch" — true only from ~3.0 s,
   not from the card's 2.0 s start (lingering baked tail at 2.0 s).
4. Cut_rope "face/action framings only" — understates the full-body
   bridge shot, which centres the revealing costume.
5. Sample rates are split 48 kHz (Crow) / 96 kHz (Witch, Ice) — the
   batch was not encoded on one consistent path, which plausibly
   explains the bitrate miss.

## Fix list (in order)

1. ALL SIX: re-encode audio as true AAC 192 kbps CBR at 48 kHz
   (investigate why the builder's 192k setting produced 130–168 kbps
   — e.g. a VBR default or a flag not applied — before re-running),
   re-mux without touching video, then re-verify: ffprobe stream
   bitrate AND extracted-stream size ÷ duration both ≈ 192 kbps,
   plus loudnorm I (≈ −16 LUFS) and TP (≤ −1 dB), plus card silence.
   Do not re-claim 192k from the encoder setting alone.
2. CROW ×3: resolve sliced baked subtitles — rebuild with
   strip-over-blur (batch-6 treatment) so subtitle lines survive
   whole, OR obtain an explicit coordinator waiver of the baked-text
   rule for these three clips. Until one of those happens, these
   three are not shippable even after the audio fix.
3. CUT_ROPE: coordinator ruling on the costume beat — accept the
   full-body bridge shot as disclosed, or recut it out (face/knight
   beats only).
4. KNOCKS (minor, optional): shift the hook card start from 2.0 s to
   ~3.0 s so the "captionless stretch" claim is literally true.
5. Re-run this QC's checks on the fixed files (bitrate ×2, loudnorm,
   card silence, and a frame check of the Crow subtitle lines) before
   any upload or submission.

## Retention summary (honest, per clip)

- moves: strongest hook in the group; weakest = dark opening frame +
  sliced sub at 4.5 s.
- knocks: strong hook question; weakest = ~3 s speech gap over the
  empty corridor (2.0–5.0 s).
- doors: strongest payoff; weakest = 4 s speech-free cold open.
- cut_rope: immediate hook; weakest = ~12.5 s speech gap, visuals only.
- dead_hide: strong hook line; weakest = ~15.5 s speech gap, payoff
  late at 17.5 s.
- ice: clearest arc; weakest = garbled/dubbed-sounding opening line
  and the 5.5–10.9 s speech gap.

No clip was uploaded, published, submitted, or sent to anyone during
this QC. No clip file was modified; this report is the only file
written.
