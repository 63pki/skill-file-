# Batch-30 Group 1 — INDEPENDENT RE-QC REPORT (POST-AUDIO-FIX)

Re-QC performed from scratch by an agent that did not build or fix these
clips. The builder's and fixer's claims in NOTES.md / GROUP_SUMMARY.md
were treated as claims to verify, not as evidence. No clip file was
modified; no upload, publish, submission, or contact was made. All QC
extracts live in /tmp (not in the delivery folder). This report does NOT
overwrite the original QC_REPORT.md — it supersedes its verdict only on
the audio-bitrate item, for the reason in the method correction below.

## Batch verdict: ALL SIX PASS — no fix required

| Clip | Verdict | Content-only bitrate (verdict metric) | Full-file bitrate (reference only) |
|---|---|---|---|
| g1_survival_rate.mp4 | **PASS** | 193.2 kbps | 137.2 kbps |
| g1_neon_alchemist.mp4 | **PASS** | 196.2 kbps | 128.9 kbps |
| g1_wild_kingdom.mp4 | **PASS** | 200.5 kbps | 148.8 kbps |
| g1_primeval.mp4 | **PASS** | 199.0 kbps | 110.3 kbps |
| g1_cloudwhale.mp4 | **PASS** | 195.2 kbps | 89.8 kbps |
| g1_giants_in_chains.mp4 | **PASS** | 193.2 kbps | 111.2 kbps |

The original QC's FAIL on all six is reversed, not because the files
changed their character, but because the original test was wrong (see
method correction). The audio-fix pass did what it claimed: content
audio now encodes at ≈192 kbps, sample rate normalised to 48 kHz, and
every other previously-passing check still passes. Nothing regressed.

## CRITICAL METHOD CORRECTION (why the original FAIL does not stand)

The original QC measured FULL-FILE audio bitrate (91–149 kbps) and
failed all six against 192 kbps. That test is arithmetically invalid
for these files: every clip carries 4.5 s of digitally silent end card.
Silence carries almost no bits, so it dilutes any whole-file average —
Cloudwhale is 54% silence, Primeval 44%, Giants 42%. No legitimate
encode can make a file that is up to 54% digital silence average
192 kbps; the only way to inflate that number would be to put noise in
the card, which would break the silence spec.

The CORRECT test (the Group 5 / Group 6 QC method, applied here):
extract the content-section audio only (total duration minus the final
4.5 s), stream-copied with no re-encode, and compute extracted-stream
size ÷ content duration. That figure must be ≈192 kbps. All six pass
it (193–201 kbps; the encoder is ABR, so small variance around the
target is the correct reading of "192 kbps AAC").

Full-file ffprobe figures are reported in this report as REFERENCE
ONLY and must not be re-quoted as a failure: they still read 90–149
kbps, exactly as arithmetic predicts for files with 4.5 s of silence.
Anyone re-measuring whole-file and failing these clips is repeating
the original QC's error.

## Shared measurements (all six, independently re-measured)

- **Video:** 1080x1920, 30 fps, H.264, yuv420p on every clip. ✓
- **Video copied bit-for-bit (fixer claim VERIFIED):** video-stream
  bitrates are IDENTICAL pre-fix vs post-fix on all six (Survival
  6480354, Neon 7463922, Wild 6210418, Primeval 3364719, Cloudwhale
  5348161, Giants 4226100 bps), and frame counts are unchanged from
  the original QC (474/399/534/305/251/321). No re-cut, reframe,
  re-caption, or out-point move is detectable, and every visual weak
  point below was re-judged from the post-fix files themselves. ✓
- **Frame count = duration × 30:** Survival 474 = 15.80×30; Neon 399 =
  13.30×30; Wild 534 = 17.80×30 (video; audio 17.83 s, see Wild note);
  Primeval 305 = 10.167×30; Cloudwhale 251 = 8.367×30; Giants 321 =
  10.70×30. ✓ Content lengths all ≤25 s (longest: Wild 13.33 s). ✓
- **Decode:** `ffmpeg -f null` clean on every clip, no errors. ✓
- **Faststart:** moov before mdat on every clip (moov offset 36 <
  mdat offset on all six). ✓
- **Streams:** exactly 2 per clip (1 video + 1 audio). No second or
  competing audio track on any clip. ✓
- **Sample rate:** 48 kHz on all six post-fix (fixer claim VERIFIED).
  Pre-fix files in work/pre-audio-fix/ still show the old split
  (96 kHz ×5, 44.1 kHz Wild), confirming the delivered files are the
  re-encoded ones, not the pre-fix files. ✓
- **End card — EXACTLY 135 frames at END ONLY, by frame number:**
  proved two independent ways. (1) Frame-number selection: last
  content frame is content and first card frame is the full end card
  on every clip (viewed). (2) Per-frame mean-absolute-difference
  against a reference card frame over a full streamed decode:
  exactly 135 card-like frames per clip, starting exactly at the
  expected frame, ZERO card-like frames before it, max MAD inside the
  card range 0.006 (encoder noise) vs minimum MAD in the content
  range 18.48–66.56 (unambiguous separation):
  - Survival: content 0–338, card 339–473 (474 total)
  - Neon: content 0–263, card 264–398 (399)
  - Wild: content 0–398, card 399–533 (534)
  - Primeval: content 0–169, card 170–304 (305)
  - Cloudwhale: content 0–115, card 116–250 (251)
  - Giants: content 0–185, card 186–320 (321)
  Card frames are pixel-identical across all six in lossless PNG
  (first-card and last-frame PNGs: mean difference 0.000, max 0;
  mid-card PNGs identical except a 1-LSB difference on <0.005% of
  pixels in two clips — encoder noise, not content). Card: RexTrix
  logo + "Download the RexTrix app — link in bio", whole, centered,
  readable. No start card on any clip (frame 0 is content; MAD scan
  finds no card-like frame before the boundary). ✓
- **End-card tagline:** "AI-generated Games & Stories" at ~y1575 —
  the allowed exception to the y=1500 rule, by the card's own design.
  Not failed. ✓
- **Loudness / true peak (ffmpeg loudnorm, whole file AND content
  only):** all within 1 LU of −16 LUFS and TP ≤ −1 dB on BOTH
  measures. Post-fix TPs moved only slightly vs pre-fix and none
  crossed −1 dB (the re-encode TP-shift risk the task warned about
  did NOT materialise this time):
  - Survival I −15.68 / TP −3.29 (whole); −15.66 / −3.29 (content)
  - Neon I −15.58 / TP −1.22; −15.75 / −1.22
  - Wild I −15.63 / TP −2.14; −16.04 / −2.14
  - Primeval I −16.93 / TP −1.52; −16.94 / −1.52
  - Cloudwhale I −16.46 / TP −1.43; −16.20 / −1.43
  - Giants I −15.60 / TP −1.81; −15.61 / −1.81
  Primeval is the tightest at 0.93–0.94 LU from target — passes, but
  closest to the edge, exactly as before the fix. ✓
- **Card silence (atrim volumedetect, card window):** mean −91.0 dB
  on all six. Boundary-slice check (card-first-0.5 s): the entire
  above-floor peak on every clip is confined to that first 0.5 s
  slice, and the card's LAST 4.0 s measures −91.0 / −91.0 dB on all
  six — i.e. the peak is the fade tail's last samples straddling the
  boundary, not sound inside the card:
  - Survival card max −76.3 dB (boundary slice −76.3; last 4.0 s −91.0)
  - Neon card max −90.3 dB (boundary −90.3; last 4.0 s −91.0)
  - Wild card max −91.0 dB (boundary −91.0; last 4.0 s −91.0)
  - Primeval card max −71.2 dB (boundary −71.2; last 4.0 s −91.0)
  - Cloudwhale card max −74.7 dB (boundary −74.7; last 4.0 s −91.0)
  - Giants card max −84.3 dB (boundary −84.3; last 4.0 s −91.0)
  All boundary peaks are ≤ −71 dB (inaudible). Silencedetect at
  −50 dB shows silence starting at or before the content end on all
  six (Survival 11.297 vs 11.30; Neon 8.765 vs 8.80; Wild 13.284 vs
  13.33; Primeval 5.662 vs 5.67; Cloudwhale 3.865 vs 3.87; Giants
  6.183 vs 6.20) and holding to end of file. ✓
- **Content-only bitrate (VERDICT metric, stream-copied .m4a
  extract, size ÷ content duration; raw ADTS extract in brackets):**
  - Survival 193.2 kbps [193.8] over 11.304 s
  - Neon 196.2 kbps [196.6] over 8.801 s
  - Wild 200.5 kbps [201.2] over 13.333 s
  - Primeval 199.0 kbps [198.9] over 5.676 s
  - Cloudwhale 195.2 kbps [194.7] over 3.871 s
  - Giants 193.2 kbps [193.2] over 6.201 s
  All ≈192 kbps. These reproduce the fixer's figures (193.3 / 196.2 /
  200.6 / 199.2 / 194.6 / 193.2) within 0.6 kbps. ✓
- **Transcripts (local faster-whisper base, English, 16 kHz mono WAV
  → numpy float32, word timestamps):** language English p=1.00 on
  every clip. The word-timestamp pass reproduces the original QC's
  timings to within 0.02 s (a first pass without word timestamps gave
  chunk-quantised segment times and is discarded as a method
  artefact — see method note). No mid-sentence cut on any speech
  clip; hook card visible inside the 1–3 s window on every clip
  (verified on frames at 1.2–2.0 s); payoff resolves before the card
  on every clip. ✓
- **Hook cards:** whole, centered at Y ~50%, readable at full size
  on every clip; size/contrast carry to phone scale. No added card
  duplicates another added card, and no added card shares words with
  a baked subtitle visible at the same moment (Neon shares words
  only non-concurrently; Primeval's baked line is blurred illegible
  — see Primeval caveat). ✓
- **Pre-fix labelling / no unverified overwrite:** all six pre-fix
  files remain labelled in work/pre-audio-fix/ (timestamps 12:17–
  12:19, sizes distinct from delivered files at 12:42). Delivered
  files' measurements match the fixer's post-fix readings and their
  video streams match the pre-fix files exactly — consistent with
  the claimed audio-only re-encode, NOT with a swap. ✓
  - Gap (documentation only, not a file defect): NOTES.md says the
    fix was "verified first in work/audiofix/", but no
    work/audiofix/ folder exists in group-1/. The intermediate
    folder cannot be independently confirmed. The verdict rests on
    the delivered files' own measurements, which pass — but the
    missing folder should be noted, not papered over.

## Per-clip findings

### 1. g1_survival_rate.mp4 — PASS
- Total 15.804 s (video 15.800 s, 474 frames); content 11.30 s + card
  4.5 s. End card frames 339–473, verified by MAD scan + viewed
  boundary (f338 doll content, f339 full card). ✓
- Hook card "MOVE AND / YOU DIE" at 1.5 s: whole, centered, highly
  readable. ✓
- Transcript (word timestamps): 0.86–8.78 "Game 1, Granma's
  footsteps, move only when she turns around, those who move while
  she's watching dies." Complete thought, no cut. The claimed
  "Please!" at ~8.92 was again not picked up as speech; silence
  does not start until 11.297, so audio stays alive through the
  doll-reaction hold — the hold is visual only, not dead air. ✓
- Delogo smear — RE-VERIFIED, unchanged by the audio-only re-encode:
  at 0.5 s and 1.5 s the bottom ~150 px shows vertical streaking
  (sand/boot/phone area). Confined to the bottom strip; faces, hook
  card, and action are clean. Weakness, not a fail. ✓
- Audio: I −15.68, TP −3.29, card mean −91.0 / max −76.3 dB
  (boundary-confined), content-only 193.2 kbps, 48 kHz. ✓

### 2. g1_neon_alchemist.mp4 — PASS
- Total 13.301 s (399 frames); content 8.80 s + card 4.5 s. End card
  frames 264–398. ✓
- Hook card "YOU CAN'T TAKE / MY COLORS" at 1.2 s: whole, centered,
  very readable against the billboard. ✓
- Card dwell 2.0 s (0.30–2.30) — RE-VERIFIED readable in one clean
  read: large, high-contrast, fully legible in a single read.
  Frame at 2.4 s shows the card gone and no baked subtitle yet;
  Whisper speech onset is 2.90 s, i.e. 0.60 s after the card ends.
  The card shares words ("take", "colors") with the later baked
  line, but never with a baked subtitle visible at the same moment.
  No doubling. ✓
- Baked subtitles KEPT whole (mid frame 6.0 s: "you stole my name
  but you can never take my colors away", readable, below y=1500).
  Source subtitle text, not an added caption; the keep-reason
  (blurring would damage the heroine/dress area) is visible on the
  frame. Flagged, not failed — same as original QC. ✓
- Transcript: 2.90–4.66 "You stole my name." + 5.42–7.98 "But you
  can never take my colors away." Complete, English, no cut; ends
  0.82 s before the card. ✓
- Audio: I −15.58, TP −1.22, card −91.0 / −90.3 dB, content-only
  196.2 kbps, 48 kHz. ✓

### 3. g1_wild_kingdom.mp4 — PASS
- Total 17.833 s container (video 17.800 s, 534 frames; audio
  17.833 s — the 0.03 s video/audio offset noted pre-fix PERSISTS
  unchanged, inaudible, not a fail). Content 13.33 s + card 4.5 s.
  End card frames 399–533. ✓
- Hook card "EVERY HUNT / IS CALCULATED" at 1.5 s over the boar
  emerging from the icy cave: whole, centered, readable. ✓
- Transcript: boar 0.00–5.20, "But the forest has changed."
  6.02–7.80, leopard "For the snow leopard, every hunt is a
  calculation." 8.76–12.96. Complete arc, no mid-sentence cut;
  ends 0.37 s before the card. ✓
- Leopard — RE-VERIFIED: at 12.0 s the leopard IS dominant on the
  ridge with boar foreground, head/face fully visible, body cut at
  the right frame edge. "Dominant" holds; "whole animal" would not
  — same nuance as original QC. ✓
- Retention (honest, unchanged): the headline animal genuinely does
  not arrive until ~12 s; a viewer who bounces early never sees
  the leopard. Weakest retention profile in the group after
  Cloudwhale's brevity. Not a spec failure. ✓
- Audio: I −15.63, TP −2.14, card −91.0 / −91.0 dB, content-only
  200.5 kbps, 48 kHz. ✓

### 4. g1_primeval.mp4 — PASS (blur-strip caveat carried, not worsened)
- Total 10.176 s (video 10.167 s, 305 frames); content 5.67 s + card
  4.5 s. End card frames 170–304. ✓
- Center crop — RE-VERIFIED: at 1.5 s and 2.5 s the serpent is whole
  and centered in the valley with the glowing palace behind, and NO
  watermark sliver is visible anywhere (including top-right). The
  center crop remains the correct frame here. ✓
- Blur strip — RE-JUDGED from post-fix frames: the strip fully
  covers the baked subtitles (no legible baked text at 1.5, 2.5, or
  4.5 s), BUT at full 1080-frame inspection the blurred band still
  shows faint word-shaped blobs — at 2.5 s the shapes vaguely
  suggest the narration words, and at the 4.5 s close-up the strip
  cuts through the serpent's neck. A cold viewer cannot read text
  there, and at phone scale the blobs are not readable as text, so
  this passes the no-doubling rule as written (the hook card
  "ANCIENT CREATURES / ARE WAKING" shares words with the baked
  line, but the baked line is not visible as text at the same
  moment). This is the same borderline judgment as the original QC,
  unchanged by the audio-only re-encode. If a reviewer judges the
  ghost blobs legible, this clip would fail on doubling instead —
  that judgment call is flagged here rather than hidden. ✓ (pass
  with caveat)
- Transcript: 1.00–5.34 "Long-forgotten ancient creatures wake from
  their long-time slumber." Complete; 0.33 s tail to the card at
  5.67 s is negligible. (First-word start 1.00 vs original QC's
  0.00 is a word-alignment quirk; end time 5.34 matches exactly.)
  ✓
- Audio: I −16.93 (0.93 LU from target — inside tolerance, closest
  to the edge), TP −1.52, card −91.0 / −71.2 dB (boundary-confined;
  last 4.0 s −91.0), content-only 199.0 kbps, 48 kHz. ✓

### 5. g1_cloudwhale.mp4 — PASS
- Total 8.371 s (video 8.367 s, 251 frames); content 3.87 s + card
  4.5 s. End card frames 116–250. ✓
- Hook card "SHE CARRIES / A FORBIDDEN LETTER" at 2.0 s: whole,
  centered, readable; noun phrase kept whole. Card starts 0.90 s,
  after the opening letter close-up, and is on screen through the
  1–3 s hook window. ✓
- Mid frame 2.0 s: girl dangling holding the sun-seal letter — the
  beat is unambiguous. ✓
- 720p upscale softness — RE-VERIFIED and honestly soft: edges and
  clouds are soft throughout, as expected from a 720→1080 upscale.
  At phone scale the letter, seal, face, and braid all read
  clearly, so readability passes. No "HD" claim appears anywhere in
  the clip itself. (Do not describe this clip as HD in any
  listing/copy.) ✓
- Speech: a non-VAD Whisper pass hallucinated "Huh?" on the
  music/SFX (three segments); a VAD-filtered pass returns NO
  segments — confirming no intelligible speech, music/SFX only, so
  there is nothing for music to compete with. The hallucination is
  reported here rather than hidden; it does not change the verdict.
  ✓
- Retention: 3.87 s of content is the shortest in the group — a
  single beat plus card, no room for a second beat or a slow
  reader. Brevity risk, not a spec fail. ✓
- Audio: I −16.46, TP −1.43, card −91.0 / −74.7 dB
  (boundary-confined), content-only 195.2 kbps, 48 kHz. ✓

### 6. g1_giants_in_chains.mp4 — PASS
- Total 10.701 s (321 frames); content 6.20 s + card 4.5 s. End card
  frames 186–320. ✓
- Hook card "SOMETHING GOT OVER / THE WALL" at 1.5 s: whole,
  centered, readable over the dark torchlit warrior. ✓
- Payoff — RE-VERIFIED: at 6.0 s the warrior is flat on his back
  (lower right, face visible) with the pale giant looming over him,
  torchlit. It is NOT daylight. The last content frame (185) is
  still the torchlit scene — no daylight leak, no daylight
  warrior-with-axe shot anywhere in the content. The out-point
  decision is preserved and correct. ✓
- Mid-action blur — RE-VERIFIED as source blur, not render defect:
  at 4.0 s the giant-throwing-warrior action is heavily
  motion-blurred but the giant figure and torches remain
  discernible; the payoff frame at 6.0 s holds crisp by
  comparison. Darkness is inherent to the source. ✓
- Blur strip at the very bottom: no legible fragment survives in
  the final frames checked (6.0 s, last content frame). ✓
- Transcript: 1.08–2.36 + 2.82–3.48 "They're flanking!" ×2.
  Complete exclamation, no cut; no speech after, action carries to
  the payoff. ✓
- Audio: I −15.60, TP −1.81, card −91.0 / −84.3 dB
  (boundary-confined), content-only 193.2 kbps, 48 kHz. ✓

## Fix list

None. No content, encode, caption, or out-point fix is required on
any clip. The single systematic failure from the original QC (audio
bitrate, as originally — incorrectly — measured) is resolved by the
content-only measurement on the post-fix files.

## Fixer-claim audit (claims checked, not assumed)

- "Audio re-encoded at -b:a 192k, 48 kHz, video copied bit-for-bit":
  CONFIRMED on all six (content-only 193–201 kbps; 48 kHz everywhere;
  video bitrates identical to pre-fix; frame counts unchanged). ✓
- Post-fix loudness/TP/card-silence figures: reproduced within
  rounding on all six (Primeval card max −71.2 here vs fixer's
  −66.8 — slightly better; Survival −76.3 vs −73.4 — slightly
  better; all other card maxima match exactly; all loudness/TP
  figures match to 0.02). ✓
- "Pre-fix files kept in work/pre-audio-fix/": CONFIRMED (all six
  present, labelled, distinct from delivered files). ✓
- "Verified first in work/audiofix/": NOT CONFIRMABLE — that folder
  does not exist in group-1/. Documentation gap only; it does not
  affect the delivered files' verdict. ⚠
- "Whole-file average will still read 92–151 kbps — arithmetic, not
  an encode failure": CONFIRMED (my whole-file ffprobe reads
  89.8–148.8 kbps; the small differences from the fixer's 92–151
  range are ffprobe-vs-extract rounding, same conclusion). ✓
- All pre-fix content judgments (Primeval crop, Giants out-point,
  Wild leopard, Neon dwell, Survival smear, Cloudwhale softness):
  RE-VERIFIED unchanged on the post-fix files. ✓

## Method note

- Frame boundaries rest on frame-number selection
  (`select=between(n,…)` equivalents) plus a full per-frame
  MAD-vs-reference-card scan — not on timestamp seeks, which the
  original QC already showed land ~1 frame late on these files.
- Card silence rests on `atrim` volumedetect, not on `-ss` seeking:
  an initial `-ss`-based volumedetect pass returned content levels
  for the card window (seek not applied as expected) and was
  discarded; the `atrim` pass and the silencedetect pass agree.
- Transcripts rest on the word-timestamp Whisper pass. A first pass
  without word timestamps returned chunk-quantised segment times
  (e.g. Neon speech "starting" at 0.00) and is discarded; the
  word-timestamp pass reproduces the original QC's timings to
  within 0.02 s on every speech clip.
- Bitrate rests on stream-copied content-only extracts (both .m4a
  and raw ADTS containers agree within 0.6 kbps). Whole-file
  ffprobe bitrates are reference only — see method correction.
