# Batch-30 Group 1 — INDEPENDENT QC REPORT

QC performed from scratch by an agent that did not build these clips.
Builder claims in NOTES.md / GROUP_SUMMARY.md were treated as claims to
verify, not as evidence. No clip file was modified; no upload, publish,
submission, or contact was made. Frame/audio extracts used for QC live
only in /tmp (not in the delivery folder).

## Verdict summary

| Clip | Verdict | Scope of failure |
|---|---|---|
| g1_survival_rate.mp4 | **FAIL** | Encode spec only: AAC bitrate (see below). All content checks pass. |
| g1_neon_alchemist.mp4 | **FAIL** | Encode spec only: AAC bitrate. All content checks pass. |
| g1_wild_kingdom.mp4 | **FAIL** | Encode spec only: AAC bitrate. All content checks pass. |
| g1_primeval.mp4 | **FAIL** | Encode spec only: AAC bitrate. All content checks pass (blur-strip caveat noted, not failed). |
| g1_cloudwhale.mp4 | **FAIL** | Encode spec only: AAC bitrate. All content checks pass. |
| g1_giants_in_chains.mp4 | **FAIL** | Encode spec only: AAC bitrate. All content checks pass. |

This is a single systematic failure, not six different ones: **every clip's
audio stream measures well below the specified 192 kbps AAC**, contradicting
the builder's "AAC 192k" claim in NOTES.md. No content rework is needed for
any clip. The parent can either require the mechanical re-encode in the fix
list below, or explicitly waive the 192k line knowing the files are
otherwise clean — but QC does not pass a listed spec item that measurably
failed.

## Shared measurements (all six, independently re-measured)

- **Video:** 1080x1920, 30 fps, H.264, yuv420p on every clip. ✓
- **Decode:** `ffmpeg -f null` clean on every clip, no errors. ✓
- **Faststart:** moov before mdat on every clip. ✓
- **End card:** exactly 135 frames (4.5 s) at END ONLY on every clip,
  verified by frame number, not by timestamp seek (timestamp seeks landed
  ~1 frame late on these files and are misleading):
  - Survival: frames 0–338 content, 339–473 card (474 frames total)
  - Neon: 0–263 content, 264–398 card (399)
  - Wild: 0–398 content, 399–533 card (534)
  - Primeval: 0–169 content, 170–304 card (305)
  - Cloudwhale: 0–115 content, 116–250 card (251)
  - Giants: 0–185 content, 186–320 card (321)
  Card frames are byte-identical in character across clips (mean luma 21.5):
  RexTrix logo + "Download the RexTrix app — link in bio", whole, centered,
  readable. No end card at the start of any clip; mid-content frames show
  no card. ✓
- **End-card tagline:** "AI-generated Games & Stories" sits at ~y1575 on
  the card — the allowed exception to the y=1500 rule, by the card's own
  design. Not failed on any clip. ✓
- **Loudness / true peak (ffmpeg loudnorm, whole file):** all within 1 LU
  of −16 LUFS and TP ≤ −1 dB. Builder's figures reproduced exactly:
  - Survival I −15.64, TP −3.22 | Neon I −15.56, TP −1.36
  - Wild I −15.61, TP −2.14 | Primeval I −16.91, TP −1.48
  - Cloudwhale I −16.43, TP −1.40 | Giants I −15.56, TP −1.88
  Primeval at −16.91 is 0.91 LU from target — inside the 1 LU band, but
  the closest to the edge. ✓
- **Card-window silence (volumedetect, last 4.5 s):** mean −91.0 dB on all
  six; max −91.0 dB (Neon, Wild, Primeval), −90.3 dB (Survival, Giants),
  −84.3 dB (Cloudwhale). All effectively silent. Note: my Primeval card
  window measured max −91.0 dB, better than the builder's stated −76.3 dB
  (method difference in seek handling); either way it is silent. ✓
- **Transcripts (local faster-whisper base, English, 16 kHz mono WAV →
  numpy float32; file-path input failed on a PyAV/ctranslate2 argument
  error, array input worked):** language English p=1.00 on every clip.
  No mid-sentence cut at either end on any speech clip; hook card visible
  inside the 1–3 s window on every clip; payoff resolves before the card
  on every clip. No second/competing audio track on any clip (single
  native mix throughout); speech is intelligible in every Whisper pass,
  so no demucs re-mix is indicated. ✓
- **AAC bitrate — THE FAILURE:** single audio stream per clip; measured
  stream bitrates (ffprobe AND extracted-stream size ÷ duration agree):
  - Cloudwhale 91 kbps | Primeval 110 kbps | Giants 112 kbps
  - Neon 131 kbps | Survival 139 kbps | Wild 149 kbps
  Spec and builder claim: 192 kbps. All six fail this item. Sample rates
  are also un-normalised (96 kHz on five clips, 44.1 kHz on Wild), which
  points to the audio never having passed through a fixed 192k encode
  step in the final mux. Audible impact is expected to be nil at these
  rates for this material (AAC-LC, loudness/TP clean), but that does not
  make the spec pass.
- **Hook cards:** whole, centered at Y ~50%, readable at full size on
  every clip. No added card duplicates another added card. ✓
- **Below y=1500 in content:** added hook cards sit at y~880–1040, above
  the zone. Two source-level observations, neither failed: (a) Neon's
  baked subtitles sit at y~1550–1780 (source subtitles, kept deliberately
  rather than blurred over the dress — see Neon section); (b) blur strips
  on Primeval/Giants and the delogo smear on Survival occupy the bottom
  edge but carry no readable information.

## Per-clip findings

### 1. g1_survival_rate.mp4 — FAIL (encode spec only)
- Total 15.804 s (video 15.800 s, 474 frames); content 11.30 s + card 4.5 s. ✓
- Hook card "MOVE AND / YOU DIE" at 1.5 s: whole, centered, highly
  readable. ✓
- Transcript (clip-relative): 0.84–8.78 "Game 1, Grandma's footsteps, move
  only when she turns around, those who move while she's watching dies."
  Complete thought, no cut. The builder's claimed "Please!" at clip ~8.92
  was NOT picked up by Whisper; RMS in 8.8–9.0 s is −21.5 dBFS (quieter
  than the main speech at −16 dBFS), so it is either very quiet or a
  doll sound — this is a missing exclamation, not a cut sentence, and
  does not change the verdict.
- Delogo smear — VERIFIED, as admitted but slightly stronger than
  "mild": at 0.5 s and 1.5 s the bottom ~150 px shows clear vertical
  streaking (sand/boot/phone area smeared vertically). It is confined
  to the bottom strip; faces, hook card, and action are clean. Weakness,
  not a fail: nothing important is obscured.
- Mid frame 6.0 s: hero face clean, doll structure behind, no readable
  baked subtitle surviving. ✓
- Retention: strongest hook in the group. Weakest stretch is the
  post-speech doll-reaction hold (speech ends 8.78 s, content to 11.30 s);
  audio stays alive through it (RMS −15 to −29 dBFS, no dead air), so
  the hold is visual only, not silent.
- Audio: I −15.64, TP −3.22, card mean −91.0 / max −90.3 dB. Bitrate
  139 kbps — FAILS the 192k item.

### 2. g1_neon_alchemist.mp4 — FAIL (encode spec only)
- Total 13.300 s (399 frames); content 8.80 s + card 4.5 s. ✓
- Hook card "YOU CAN'T TAKE / MY COLORS" at 1.2 s: whole, centered,
  very readable against the billboard. ✓
- Card dwell 2.0 s (0.30–2.30) — VERIFIED readable in that time: the
  card is large, high-contrast, and fully legible in a single read.
  The builder's "one clean read, not two" is accurate and acceptable;
  it is not a fail.
- No-doubling — VERIFIED: frame at 2.4 s shows the card gone and no
  baked subtitle yet; Whisper speech onset is clip 2.88 s, i.e. 0.58 s
  after the card ends. The card shares words ("take", "colors") with
  the later baked line, but never with a baked subtitle visible at the
  same moment. ✓
- Baked subtitles KEPT whole (mid frame 6.0 s: "you stole my name but
  you can never take my colors away" at y~1550–1780, readable). This is
  source subtitle text below y=1500; it is not an added caption and the
  builder's reason for keeping it (blurring would damage the
  heroine/dress area) is visible on the frame. Flagged, not failed.
- Transcript: 2.88–4.68 "You stole my name." + 5.44–7.98 "But you can
  never take my colors away." Complete, English, no cut. ✓
- Audio: I −15.56, TP −1.36, card digital silence (−91.0/−91.0 dB).
  Bitrate 131 kbps — FAILS the 192k item.

### 3. g1_wild_kingdom.mp4 — FAIL (encode spec only)
- Total 17.830 s container (video 17.800 s, 534 frames; audio 17.830 s —
  the builder's noted 0.03 s video/audio offset is real and inaudible).
  Content 13.33 s + card 4.5 s. ✓
- Hook card "EVERY HUNT / IS CALCULATED" at 1.5 s over the boar
  emerging from the icy cave: whole, centered, readable. ✓
- Transcript: boar 0.00–5.18, then 6.16–12.96 ("but the forest has
  changed. For the snow leopard, every hunt is a calculation.").
  Complete arc, no mid-sentence cut; the ~1 s narration gap between
  sentences is music/nature sound, not dead air. ✓
- Leopard — VERIFIED, with a nuance: at 12.0 s the leopard IS dominant
  on the ridge with boar foreground, as claimed, but the leopard's body
  is cut at the right frame edge (head/face fully visible). "Dominant"
  holds; "whole animal" would not. Not failed.
- Retention (honest): the hook holds the first 3 s on the boar
  emergence + card + narration, but the headline animal genuinely does
  not arrive until ~12 s. A viewer who bounces early never sees the
  leopard. This is a retention risk the builder already admitted, not
  a spec failure — the narration arc justifies the structure, but it
  is the weakest retention profile in the group after Cloudwhale's
  brevity.
- Audio: I −15.61, TP −2.14, card silence −91.0/−91.0 dB. Bitrate
  149 kbps (and the only 44.1 kHz audio stream in the group) — FAILS
  the 192k item.

### 4. g1_primeval.mp4 — FAIL (encode spec only)
- Total 10.177 s (video 10.167 s, 305 frames); content 5.67 s + card 4.5 s. ✓
- Center crop — VERIFIED, and the builder's rejection of the saliency
  reframe is supported: at 1.5 s and 2.5 s the serpent is whole and
  centered in the valley with the glowing palace behind, and NO
  watermark sliver is visible anywhere (including top-right). The
  center crop is the correct frame here. ✓
- Blur strip — VERIFIED, with a borderline caveat: the strip fully
  covers the baked subtitles (no legible baked text at 1.5, 2.5, or
  4.5 s), BUT at full 1080-frame inspection the blurred band still
  shows faint word-shaped blobs — at 2.5 s the shapes vaguely suggest
  the narration words. At phone scale these blobs are not readable as
  text, so this passes the no-doubling rule as written (the hook card
  "ANCIENT CREATURES / ARE WAKING" shares words with the baked line,
  but the baked line is not visible as text at the same moment).
  If a reviewer judges the ghost blobs legible, this clip would fail
  on doubling instead — that judgment call is flagged here rather than
  hidden. The strip's soft edge is conspicuous: a full blurred bar
  across the lower ~17% of frame, cutting through the serpent's neck
  in close-up (4.5 s frame) — visible, but it does not obscure the
  face or the hook card, and it is strictly better than the delogo
  ghosts the builder reported. Acceptable, not clean.
- Transcript: 0.00–5.34 "Long forgotten ancient creatures wake from
  their long-time slumber." Complete; 0.33 s tail to the card at
  5.67 s is negligible. ✓
- Audio: I −16.91 (0.91 LU from target — inside tolerance, closest to
  the edge), TP −1.48, card silence −91.0/−91.0 dB by my measurement.
  Bitrate 110 kbps — FAILS the 192k item.

### 5. g1_cloudwhale.mp4 — FAIL (encode spec only)
- Total 8.371 s (video 8.367 s, 251 frames); content 3.87 s + card 4.5 s. ✓
- Hook card "SHE CARRIES / A FORBIDDEN LETTER" at 2.0 s: whole,
  centered, readable; noun phrase kept whole. Card starts 0.90 s,
  after the opening letter close-up (0.3 s frame: giant letter + sun
  seal, no card) and is on screen through the 1–3 s hook window. ✓
- Mid frame 2.0 s: girl dangling holding the sun-seal letter — the
  beat is unambiguous. ✓ No speech in range (Whisper: no segments),
  music/SFX only, so there is nothing for music to compete with. ✓
- 720p upscale softness — VERIFIED and honestly soft: edges and clouds
  are soft throughout, as expected from a 720→1080 upscale. At phone
  scale the letter, seal, face, and braid all read clearly, so
  readability passes. No "HD" claim appears anywhere in the clip
  itself. ✓ (Do not describe this clip as HD in any listing/copy.)
- Retention: 3.87 s of content is the shortest in the group — the clip
  is a single beat plus card. It lands, but there is no room for a
  second beat or a slow reader; this is brevity risk, not a spec fail.
- Audio: I −16.43, TP −1.40, card mean −91.0 / max −84.3 dB (silent).
  Bitrate 91 kbps — the lowest in the group — FAILS the 192k item.

### 6. g1_giants_in_chains.mp4 — FAIL (encode spec only)
- Total 10.701 s (321 frames); content 6.20 s + card 4.5 s. ✓
- Hook card "SOMETHING GOT OVER / THE WALL" at 1.5 s: whole, centered,
  readable over the dark torchlit warrior. ✓
- Payoff — VERIFIED: at 6.0 s the warrior is flat on his back (lower
  right, face visible) with the pale giant looming over him, torchlit.
  It is NOT daylight. No daylight warrior-with-axe shot appears in
  the content frames; the last content frame (185) is still the
  torchlit scene. The builder's cut correction (hard cut at
  141.7–141.8 s in source terms, clip ending 141.70) is consistent
  with what is on screen — no daylight leak. ✓
- Mid-action blur — VERIFIED as source blur, not render defect: at
  4.0 s the giant-throwing-warrior action is heavily motion-blurred
  but the giant figure and torches remain discernible; the payoff
  frame at 6.0 s holds crisp by comparison. Darkness is inherent to
  the source; faces and the hook card remain readable. ✓
- Blur strip at the very bottom (baked subs at ~139 s source): no
  legible fragment survives in the final frames checked. ✓
- Transcript: 1.10–2.34 + 2.80–3.48 "They're flanking!" ×2 (builder
  worded it "The flanks!"; Whisper's "They're flanking" matches the
  baked subtitle's "they're flanking" better). Complete exclamation,
  no cut; no speech after, action carries to the payoff. ✓
- Audio: I −15.56, TP −1.88, card silence −91.0/−90.3 dB. Bitrate
  112 kbps — FAILS the 192k item.

## Fix list (applies to all six clips — one systematic fix)

1. **Re-encode audio at a true 192 kbps AAC** (explicit `-b:a 192k`,
   single audio stream) in the final mux for every clip, and
   normalise sample rate consistently (the current 96 kHz ×5 /
   44.1 kHz ×1 split shows the final mux never enforced one).
2. **Re-verify after the re-encode, per clip:** loudnorm integrated
   within 1 LU of −16 LUFS, true peak ≤ −1 dB, card-window mean
   −91 dB, decode clean, faststart, and end-card frame count still
   exactly 135. (The builder's own history shows AAC re-encodes shift
   true peak — e.g. Primeval −1.26 → −0.42 on re-encode — so this
   re-check is not optional.)
3. **No content changes required:** no re-cut, reframe, caption, or
   transcript fix is needed on any clip. Do not re-open the Primeval
   reframe decision or the Giants out-point; both verified correct.
4. **Copy note (not a file fix):** never describe Cloudwhale as HD;
   it is a 720p upscale.

## Builder-claim audit (claims checked, not assumed)

- Loudness/TP/card-silence figures: reproduced exactly on all six. ✓
- Durations, content lengths, card 4.5 s: confirmed by frame count. ✓
- Primeval center crop + no watermark: confirmed. ✓
- Giants cut correction + no daylight leak: confirmed. ✓
- Wild leopard at ~12 s: confirmed (with right-edge body crop noted). ✓
- Neon 2.0 s dwell readable + card ends before speech: confirmed. ✓
- Survival delogo smear: confirmed, slightly stronger than "mild". ✓
- Primeval blur strip "fully unreadable": mostly confirmed, with the
  ghost-blob caveat above. ⚠
- "AAC 192k": CONTRADICTED on all six (91–149 kbps measured). ✗
- Primeval card-window max −76.3 dB: my measurement is −91.0 dB
  (better; method difference, not a dispute that matters).
- Survival "Please!" at clip ~8.92: not confirmed by Whisper (quiet or
  absent as speech); does not affect any verdict.

## Method note

Timestamp-based frame grabs (`-ss` before `-i`) returned the first
card frame ~1 frame early on these files; all boundary claims above
rest on frame-number selection (`select=between(n,…)`) and mean-luma
classification (content vs card mean 21.5), cross-checked against
nb_frames from ffprobe.
