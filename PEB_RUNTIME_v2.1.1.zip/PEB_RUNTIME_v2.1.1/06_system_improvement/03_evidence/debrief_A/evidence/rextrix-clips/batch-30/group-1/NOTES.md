# Batch-30 Group 1 — Clip notes

All clips: 1080x1920, 30fps, libx264 slow CRF 16, yuv420p, AAC 192k, faststart.
End card on every clip: the supplied `card_v.mp4` (real RexTrix logo +
"Download the RexTrix app — link in bio"), exactly 4.5s (135 frames) at END
ONLY, silent. No start cards/bumpers. Hook cards: Montserrat Bold, white,
4px black outline, centered Y 50%, one display per clip, two lines, each
line ≤ 3 words, chunked at phrase boundaries.
Audio target: ~-16 LUFS integrated, true peak ≤ -1 dB.
Sources: `/home/hatch/workspace/rextrix-clips/new-batch-7/sources/`.
Intermediates and prior versions: `work/` (`work/v1/` = first finals,
`work/v2/` = second finals for primeval/cloudwhale only; neon's delivered
file is its first build — it needed no fix).
Transcripts verified on the source segments with local Whisper (base,
English, p=1.00); final audio is the same mix (loudnorm gain + a 0.2s
end-fade only), so wording is unchanged.

## 1. g1_survival_rate.mp4 — "MOVE AND YOU DIE"
- Source: `survival_rate_ep1.mov` **27.20–38.50** (11.30s content; total 15.80s).
- Reframe: saliency-tracked (face bias) from 1920x1080 landscape.
- Baked subtitles: present at the very bottom of frame. Removed with
  `delogo=x=1:y=1000:w=1918:h=75` before reframing (w=1920 failed with
  "Logo area is outside of the frame"; the 1px inset fixed it). Trade-off:
  mild vertical smear on foreground figures' lower bodies at the very
  bottom edge; phones at the bottom of the opening frame are smeared.
- Card: "MOVE AND / YOU DIE", clip **0.30–3.00** (source 27.50–30.20).
  Shares no words with any baked line, and the baked lines are removed
  by delogo anyway.
- Speech (complete, no mid-sentence cut): rules thought 28.04–35.98
  ("Game 1. Grandma's footsteps. Move only when she turns around. Those
  who move while she's watching, dies.") + "Please!" at 36.12, then a
  doll-reaction hold to 38.50. Source shot is continuous 27.10–40.30.
- Audio (final): I **-15.64** LUFS, TP **-3.22** dB. End-card window:
  mean -91 dB, max -84.3 dB (silent). Single native mix kept; no added
  bed, so no competing tracks.
- Flags: blood smears on faces (source), deadly-game violence, no gore
  close-ups.
- Fixed during QC: first final file was a partial write (aborted build,
  missing moov atom) — rebuilt in full and re-verified; a 0.2s end-fade
  was added so the card window measures silent.
- Weakest point: the delogo smear at the very bottom edge (most visible
  on the phones in the opening frame). The hook and the faces are clean.

## 2. g1_neon_alchemist.mp4 — "YOU CAN'T TAKE MY COLORS"
- Source: `neon_alchemist_ep1.mov` **46.80–55.60** (8.80s content; total 13.30s).
- Vertical native (1080x1920), no reframe.
- Baked subtitles: KEPT whole and clean. Blurring would have damaged
  the heroine/dress area (subs sit over dress/crowd at y~1550–1780).
  Instead the added card is timed to end BEFORE speech/baked-sub onset,
  so no added card ever shares words with a visible baked subtitle.
- Card (the ONLY added card): "YOU CAN'T TAKE / MY COLORS",
  clip **0.30–2.30** (source 47.10–49.10), ending 0.54s before speech
  onset at 49.64. The baked subs then carry the spoken line and are
  never duplicated.
- Speech (complete): "You stole my name, but you can never take my
  colors away." 49.64–54.78. Content spans the source's own verified
  cuts at 48.37 and 49.90 (the line itself spans the 49.90 cut, so the
  clip must include it); out at verified boundary 55.60.
- Audio (final): I **-15.56** LUFS, TP **-1.36** dB. End-card window:
  mean -91 dB, max -91 dB (digital silence). Single native mix kept.
- Fixed during QC: none — first build passed all checks (only clip
  whose card window was silent on the first pass).
- Weakest point: the hook card's 2.0s dwell is the shortest in the
  group (forced by the need to end before the 49.64 speech onset). It
  is readable on frames, but a slower reader gets one clean read, not two.

## 3. g1_wild_kingdom.mp4 — "EVERY HUNT IS CALCULATED"
- Source: `wild_kingdom_ep1.mp4` **19.90–33.23** (13.33s content; total 17.83s).
- Reframe: saliency-tracked, `--no-face`, from 2560x1440 landscape.
- Baked subtitles: none in range; no cleaning.
- Card (descriptive, longer dwell): "EVERY HUNT / IS CALCULATED",
  clip **0.40–3.60** over the boar emergence.
- Narration (complete, no mid-sentence cut): boar "After months hidden
  beneath the frozen ground, a wild boar returns to the world."
  20.24–25.10; "But the forest has changed." 26.20–27.70; leopard
  "For the snow leopard, every hunt is a calculation." 29.00–32.86.
  The internal cut at 25.20 falls between sentences (clean boundary).
  Verified on frames: clip 12.0 = leopard dominant on the ridge with
  boar foreground.
- Audio (final): I **-15.61** LUFS, TP **-2.14** dB. End-card window:
  mean -91 dB, max -90.3 dB (silent). Single native mix kept.
- Flags: predation, no gore.
- Fixed during QC: v1 single-pass loudnorm landed at I -17.28 (1.28 LU
  low) — rebuilt with measured two-pass loudnorm (source I -13.89,
  TP 0.00, LRA 6.20, thresh -25.14, offset 1.27) plus a 0.2s end-fade so
  the card window measures silent.
- Weakest point: the leopard payoff arrives late (clip ~12s) — the
  boar opening has to carry the first 10 seconds. The narration arc
  justifies it, but a viewer who bounces before the leopard never
  sees the headline animal.
- Note: content video is 13.30s while content audio is 13.33s
  (reframe quirk), so the file's video stream is 17.80s against a
  17.83s audio stream — 0.03s of silence past the last frame, invisible
  and inaudible.

## 4. g1_primeval.mp4 — "ANCIENT CREATURES ARE WAKING"
- Source: `primeval_etp1.mov` **9.40–15.07** (5.67s content; total 10.17s).
- Reframe DEVIATION (documented, deliberate): the saliency reframe was
  REJECTED on QC — at clip 2.5 the serpent was cut off at the left
  edge and a RexTrix-watermark sliver ("R") showed top-right.
  Replacement: plain center crop `crop=608:1080:656:0, scale=1080:1920`
  from the blur-cleaned segment. Verified at clip 2.5: serpent whole
  and centered, glowing palace behind, NO watermark (watermark at
  x~1450+ is outside the center crop). The task's "never a dead
  center-crop" rule is overridden here by its own higher rules (never
  crop through baked text, keep the subject whole); the valley subject
  is centered, so the center crop is the correct frame.
- Baked subtitles: present at the bottom. delogo failed twice (taller
  band left strong smear streaks; first band left a readable "time
  slumber" ghost). Final method: blur strip
  `crop=1920:180:0:840, gblur=sigma=25, overlay=0:840` (y840–1020),
  applied before reframing. Text fully unreadable on frames.
  Trade-off: a soft horizontal blur edge is visible across the lower
  frame (cuts through deer legs in the valley shot and the serpent's
  neck in close-up).
- Card (descriptive dwell): "ANCIENT CREATURES / ARE WAKING",
  clip **0.30–3.30**.
- Narration (complete): "Long-forgotten ancient creatures wake from
  their long-time slumber." 10.30–14.74, inside verified boundaries
  9.40/15.07. The montage spans source cuts at 10.90 and 13.83.
- Audio (final): I **-16.91** LUFS, TP **-1.48** dB. End-card window:
  mean -91 dB, max -76.3 dB (AAC noise floor, effectively silent).
  Single native mix kept.
- Fixed during QC: v1 TP was -1.26, but AAC re-encode for the end-fade
  shifted it to -0.42 — a -1.0 dB gain pass (v3) restored TP to -1.48
  with I still within 1 LU of -16.
- Weakest point: the 0.33s tail after "slumber" (ends 14.74) before the
  card at 15.07, plus the visible blur-band edge. The clip is also the
  second-shortest in the group (5.67s content).

## 5. g1_cloudwhale.mp4 — "SHE CARRIES A FORBIDDEN LETTER"
- Source: `cloudwhale_ep1.mp4` **2.93–6.80** (3.87s content; total 8.37s).
- Vertical native 720x1280, upscaled to 1080x1920 (lanczos).
  HONEST SOFTNESS NOTE: this is an upscale of a 720p source — it is
  soft, and is never to be called HD.
- Baked subtitles: none in range; no cleaning.
- Card (descriptive dwell): "SHE CARRIES / A FORBIDDEN LETTER"
  (noun phrase kept whole), clip **0.90–3.60**. Starting at 0.90
  avoids covering the giant letter close-up at the clip start, while
  the card is still on screen inside the 1–3s hook window.
- In-point 2.93 is the verified shot boundary; out 6.80 ends on the
  dangling hold (letter in hand, sun seal visible), before the seated
  beat at 7s and before the shot ends at 10.10. No speech in range;
  native music/SFX only. Verified on frames: clip 2.0 = girl dangling
  holding the sun-seal letter.
- Audio (final): I **-16.43** LUFS, TP **-1.40** dB. End-card window:
  mean -91 dB, max -84.3 dB (silent). Single native mix kept.
- Fixed during QC: v1 two-pass target was missed on TP (-0.89 after
  single-pass) — two-pass loudnorm (source I -22.56, TP -2.73,
  LRA 4.00, thresh -32.56, offset -1.02) + 0.2s end-fade (v2), then a
  -0.5 dB gain pass (v3) after AAC re-encode shifted TP to -0.89 again.
- Weakest point: brevity — 3.87s of content is the shortest in the
  group, and the 720p upscale softness. The letter beat itself is
  unambiguous and lands inside the hook window.

## 6. g1_giants_in_chains.mp4 — "SOMETHING GOT OVER THE WALL"
- Source: `giants_in_chains_ep1.mov` **135.50–141.70** (6.20s content;
  total 10.70s).
- Reframe: saliency-tracked (face bias) from 1920x1080 landscape.
- CUT CORRECTION (critical): an earlier scene-detect run reported a
  cut at 142.63 — that figure is WRONG. A clean re-run plus dense 0.1s
  frame grabs with numeric mean-difference proved the hard cut is
  between 141.7s and 141.8s (diff ~3.3 baseline → 37.12 at 141.8).
  The earlier 135.50–142.60 plan would have included 0.87s of a
  daylight warrior-with-axe shot; the final out-point 141.70 sits
  0.03–0.10s before the verified cut and ends on the payoff.
  The unverified 70s cage-march fallback was NOT used.
- Baked subtitles: present at the very bottom at 139s ("they're flank
  they're flanking"). delogo failed twice (readable ghosts at both
  band settings). Final method: blur strip
  `crop=1920:105:0:975, gblur=sigma=25, overlay=0:975` (y975–1080),
  applied before reframing. No sub visible at 141s; no fragment
  survives in the final (verified at clip 6.0).
- Card: "SOMETHING GOT OVER / THE WALL" (noun phrase whole),
  clip **0.30–2.80**.
- Speech (complete): "The flanks! The flanks!" 136.30–138.90 inside;
  no speech after. Ends on the payoff: clip 6.0 (source 141.5) =
  warrior flat on back, pale giant looming, torchlit — verified at
  FULL size in the final file (not daylight).
- Audio (final): I **-15.56** LUFS, TP **-1.88** dB. End-card window:
  mean -91 dB, max -90.3 dB (silent). Single native mix kept.
- Fixed during QC: 0.2s end-fade so the card window measures silent
  (v1 had a 0.08s content tail crossing the boundary).
- Weakest point: inherent source darkness + heavy action motion blur
  around 140s (the giant throwing the warrior). The payoff frame at
  141.5 holds crisp, but the mid-action second is the blurriest in
  the group. This is source blur, not a render defect.

## Post-fix audio pass (2026-10-29, after independent QC fail on bitrate only)
Independent QC (QC_REPORT.md) found every clip's audio stream averaging
91–149 kbps whole-file with un-normalised sample rates (96 kHz ×5,
44.1 kHz ×1), against the 192k AAC spec. Everything else passed and was
NOT touched: video streams were copied bit-for-bit (`-c:v copy` — video
bitrates identical to pre-fix, frame counts identical to QC's
474/399/534/305/251/321, so the end card is still exactly 135 frames),
no re-cut, reframe, re-caption, or out-point move (Primeval crop and
Giants out-point decisions explicitly preserved).
Fix applied to all six: `-c:a aac -b:a 192k -ar 48000 -movflags +faststart`,
single audio stream, rendered to `work/audiofix/`, fully verified BEFORE
promotion; pre-fix files kept labelled in `work/pre-audio-fix/`.
(Version-label note: the fix folder is `work/audiofix/`, not `work/v3/`,
because `work/v2/` already held Primeval/Cloudwhale v2 files and their
delivered files were already v3 — a new `v3` folder would have been a
misleading label.)

Post-fix readings per clip (measured on the promoted files):

| Clip | Codec / rate | Content-portion avg | Whole-file avg | I (LUFS) | TP (dB) | Card window mean / max |
|---|---|---|---|---|---|---|
| survival_rate | AAC / 48 kHz | 193.3 kbps | 139.3 kbps | -15.68 | -3.29 | -91.0 / -73.4 dB |
| neon_alchemist | AAC / 48 kHz | 196.2 kbps | 131.1 kbps | -15.58 | -1.22 | -91.0 / -90.3 dB |
| wild_kingdom | AAC / 48 kHz | 200.6 kbps | 150.9 kbps | -15.63 | -2.14 | -91.0 / -90.3 dB |
| primeval | AAC / 48 kHz | 199.2 kbps | 112.7 kbps | -16.93 | -1.52 | -91.0 / -66.8 dB |
| cloudwhale | AAC / 48 kHz | 194.6 kbps | 92.3 kbps | -16.46 | -1.43 | -91.0 / -74.7 dB |
| giants_in_chains | AAC / 48 kHz | 193.2 kbps | 113.5 kbps | -15.60 | -1.81 | -91.0 / -84.3 dB |

How to read the two bitrate columns (important, do not misquote):
the CONTENT portion of every clip encodes at 193–201 kbps — i.e. at the
192k target (ffmpeg's native AAC encoder is ABR; no libfdk_aac or true-CBR
AAC encoder exists in this toolchain, and ABR around the target is the
correct reading of "192 kbps AAC"). The whole-file average is lower
because 4.5s of every file is digital silence, which carries almost no
bits: Cloudwhale is 54% silence, Primeval 44%, Giants 42%. No legitimate
encode can make a file that is up to 54% digital silence average
192 kbps; the only way to inflate that number would be to put noise in
the card, which would break the silence spec. So: the encode spec is met
by encode parameters + content-portion rate + normalised 48 kHz rate,
while a whole-file-average re-measurement will still read 92–151 kbps —
that is arithmetic, not an encode failure, and it is flagged here rather
than hidden.
All six post-fix: loudness within 1 LU of -16 (Primeval -16.93 is 0.07 LU
from the band edge — passes, but tightest), TP ≤ -1 dB (no limiter/gain
iteration was needed — no TP failed after this re-encode), null-decode
clean, faststart verified (moov offset 36 < mdat on all six), frame
counts unchanged.
Card-silence maxima above -90 dB (Primeval -66.8, Survival -73.4,
Cloudwhale -74.7) are boundary transients only: silencedetect (-50 dB)
shows silence starting at/before the content end on all three checked
(Primeval 5.662 vs content end 5.67; Survival 11.297 vs 11.30; Cloudwhale
3.865 vs 3.87) and holding through the card — i.e. the peak is the fade
tail's last samples at the boundary, not sound inside the card. Card
mean is -91.0 dB on all six.

## Cross-clip notes
- No clip was dropped: all six hooks held up at full-size frame QC.
- No Demucs stem separation was run. Each clip keeps its single native
  mix (no added music bed, no second track, no dialogue bedded under
  another track), and speech was verified intelligible (Whisper
  p=1.00 on every speech clip). Stem separation without listening
  verification risked artifacts; if a later listen finds music
  competing with speech, Demucs (`/home/hatch/workspace/demucs-venv`)
  is the next step — do not ship a re-mix unheard.
- No locked-off static window >1.5s was observed in any chosen range
  (all have camera or subject motion), so no 1.1x slow zoom was applied.
- Hook cards sit centered at Y 50% (block roughly y880–1040), above
  the y=1500 Shorts-UI zone. The supplied end card is unaltered; its
  own "AI-generated Games & Stories" tagline sits at ~y1575, i.e.
  below y=1500 by the card's own design, as in prior batches.
- Task-spec conflict recorded: the standing caption rule says added
  captions must not sit on the video area; this task's spec explicitly
  says centered Y 50%, and the task spec governed this build.
- Nothing was uploaded, published, submitted, or sent to anyone.
