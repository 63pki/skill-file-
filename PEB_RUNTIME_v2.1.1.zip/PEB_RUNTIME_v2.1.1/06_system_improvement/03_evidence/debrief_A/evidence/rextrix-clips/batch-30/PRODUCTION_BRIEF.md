# Batch-30 production brief — 30 retention-optimized RexTrix clips (2026-10-29)

## Goal
30 professional, intentional clips that earn full watch-through: hook in the first
1–3 seconds, a complete thought that resolves before the end card, no dead air,
no mid-sentence cuts, no gimmick padding. Delivered READY TO UPLOAD — built,
independently QC'd, reviewed, fixed — but NOT uploaded, published, or submitted.
Uploads happen only on the user's explicit word for each exact version.

## Honesty rule (overrides count)
If the held footage cannot yield 30 STRONG clips, deliver the strong ones and
report the gap plus what would fill it (which episodes/scenes are missing).
Never pad the batch with weak clips to hit 30. No clip is delivered with a known
defect that is not flagged in its note. Retention is optimized, never guaranteed:
no edit can force a human to watch to the end.

## Source pool (held footage ONLY — no new downloads)
- Batch-7 episode 1s: ~/workspace/rextrix-clips/new-batch-7/sources/
  giants_in_chains_ep1.mov, cloudwhale_ep1.mp4, wild_kingdom_ep1.mp4,
  survival_rate_ep1.mov, primeval_etp1.mov, neon_alchemist_ep1.mov
- Toilet Knight ep1: ~/workspace/browser_downloads/sess-784897735/browser-download-20261029T100044.951538411Z-0-TKSV-1.mov
- Strawberry Assistant ep1: ~/workspace/browser_downloads/sess-784897735/browser-download-20261029T100425.960357663Z-1-The_Strawberry_Assistant_s_Secret_ep1.mov
- Drive episodes: ~/workspace/rextrix-clips/drive-sources/ (Panda BoBo, Phoenix
  Throne, Echo of Derelict). EXCLUDE Her Loyal Hound (adult romance).
- Local sources: ~/workspace/rextrix-clips/sources/src_*.mp4 (19 files).
- Edit-3 originals: ~/workspace/rextrix-clips/new-batch-7/edit-3/orig/ (c1/c2/c3
  star-god). Cut DIFFERENT moments — do not recreate the rejected edit-3 edits.
- EXCLUDE: Cheating's ep1 (exclusion-list show), Swapped ep1 + ep2–6 (reserved
  for the T2 hunt), the already-uploaded T1/T3 rebuilds and pilot (no duplicates),
  the 7 rejected clips' exact edits. Prefer FRESH moments; if a show is reused,
  use different scenes and say so in the note.

## Group 1 (first 6 — hooks already scouted, use these)
1. I Can See Your Survival Rate ~30–34s — "MOVE AND YOU DIE" (arena, frozen
   players; full rules thought ~28–39s; landscape → reframe).
2. The Neon Alchemist ~50–55s — "YOU CAN'T TAKE MY COLORS" (defiant heroine;
   line 50.16–54.80s; vertical native).
3. WILD KINGDOM ~30–33s — "EVERY HUNT IS CALCULATED" (snow leopard stalk;
   landscape → reframe).
4. Echoes of the Primeval ~11.5–14s — "ANCIENT CREATURES ARE WAKING" (serpent
   rises; landscape → reframe).
5. CROWN OF THE CLOUDWHALE ~3.5–5.5s — "SHE CARRIES A FORBIDDEN LETTER"
   (girl + glider + sealed letter; vertical native, 720p — never call it HD).
6. Giants in Chains ~140–143s — "SOMETHING GOT OVER THE WALL" (giant overpowers
   warrior; darkest/most motion-blurred — verify frames at full size; landscape).
Groups 2–6: coordinator picks the strongest hook-first moments from the rest of
the pool by the same bar (hook in 1–3s, self-explanatory, complete thought).

## Per-clip spec (non-negotiable)
- 1080x1920 30fps, libx264 slow CRF 16, yuv420p, AAC 192k, faststart.
- Content ≤25s + end card EXACTLY 4.5s at END ONLY (real RexTrix logo +
  "Download the RexTrix app — link in bio", silent). No start cards/bumpers.
- Text: Montserrat Bold (font ~/.local/share/fonts/Montserrat-Bold.ttf,
  registers as "Montserrat Thin" Bold), white, 4px black outline, centered Y 50%,
  max 3 words per card, chunked at PHRASE boundaries (never split a noun phrase
  or a brand command). Descriptive cards dwell ~20–30% longer.
- Audio: ~-16 LUFS integrated, true peak ≤ -1 dB. Speech enhanced; music ducked
  LOW under all speech; split-screen = ONE track only, never competing tracks.
- Landscape sources: saliency-tracked reframe (smart-reframe), never a dead
  center-crop. 720p/640x360 sources: strip-over-blur or honest softness note —
  never claim native HD.
- English only (check creator strips + burned-in subs BEFORE cutting). No banned
  claims, no invented features, no faked studio UI/screen recordings, no
  copyrighted characters. Family-safe: no sexual content; flag blood/gore and
  skip or report it; adult/romance titles excluded outright.

## Lessons-learned checklist (mistakes this batch must NOT repeat)
1. Doubled captions: NEVER layer new captions over video that already carries
   captions — rebuild from clean captionless segments first (the v3-first-render
   failure). Verify on frames, not on specs.
2. No competing audio: never bed original dialogue/music under a voiceover or
   another track (the pilot v1 defect). These clips are text-led: one clean
   audio design per clip.
3. No mid-sentence cuts: cut only on thought completion or a verified shot
   boundary. Source-internal mid-sentence cuts are NOT fixed by re-chunking
   text — pick continuous shots instead.
4. Static windows >1.5s get a 1.1x slow zoom; verify the zoom on frames.
5. No unconfirmed claims: a download/upload/submission exists only with tool
   confirmation (file on disk + probe, public link + Studio check, submission
   ID + Pending status). Never report otherwise.
6. Baked text: inspect every source for baked graphics/text BEFORE writing the
   cut list; frame around them, never crop through; added cards must never
   share words with the baked subtitle visible at the same moment.
7. No loops/freeze/slow-mo padding to reach length. If a moment cannot resolve
   completely, report it — don't fake it.
8. Never trust a builder's self-declared QC. Every clip gets independent QC
   (below) before delivery.

## QC + review protocol (per clip, before it leaves the builder)
- Probe: dims, fps, codec, duration. Decode check (ffmpeg null). Loudnorm
  (I, TP). Card-section silence (volumedetect on last 4.5s).
- Frames at hook, mid, and card: cards whole + centered + readable at phone
  scale; no doubles; end card clean; no important content below y=1500
  (Shorts UI zone); zoom verified where applied.
- Transcript check: English, complete thought, no mid-sentence cut, hook lands
  in 1–3s, payoff before the card.
- Retention review (honest): hook strength, dead air, repetition vs the rest
  of the batch, weakest second. Issues → fix → re-QC. Loop until clean or
  flagged.
- Keep prior versions labelled; never overwrite. Each clip ships with a note:
  source + timestamps, cards, audio readings, what was fixed, and its honest
  weakest point.

## Delivery (to the parent, group by group)
Groups of 5–6 clips. Per group: the mp4 files + per-clip notes + a group
summary (what passed, what was fixed, what is still weak). The parent does a
final independent verification before anything reaches the user. Do NOT upload,
publish, submit, or contact anyone.

## Scope update 2026-10-29 ~16:25 PKT (user order: check EVERY corner of Drive)
Full Drive survey in progress via the Drive API (inventory + per-folder episode
lists in ~/workspace/rextrix-clips/drive-survey/). Group 1 proceeds on held
footage. Groups 2–6 HOLD final source selections until the survey lands — the
user wants NEW, unused shows in the batch. Survey classifies each folder as:
already-used / excluded (adult/romance) / empty / unexplored-promising.
Coordinator update sent to hold Groups 2–6 picks pending survey results.
