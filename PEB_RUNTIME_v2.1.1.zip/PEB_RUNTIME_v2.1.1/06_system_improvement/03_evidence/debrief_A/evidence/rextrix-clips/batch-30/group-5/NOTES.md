# Batch-30 Group 5 — per-clip notes (FINAL — all 6 clips QC-passed 2026-10-29)

All clips: 1080x1920, 30fps, libx264 slow CRF 16, yuv420p, AAC 192k, faststart.
End card: exactly 4.5s at END ONLY (card_v.mp4: RexTrix logo + "Download the RexTrix
app — link in bio"), silent. Cards: Montserrat Bold (ASS "Montserrat Thin" Bold=-1),
white, 4px black outline, centred (Alignment 5, vertical middle), max 3 words/card,
chunked at phrase boundaries. Audio: demucs --two-stems vocals; vocals enhanced
(highpass 80Hz, FFT denoise, +3dB @3kHz, 3:1 compression); music stem ducked x0.355
(-9dB) during speech spans; two-pass loudnorm I=-16 / TP<=-1 over content+card silence.
Landscape sources are 1920x1080 with BAKED subtitles in a bottom band (top edge as
high as ~874px). Fix applied to every landscape clip: pre-crop to y=0–840 (subtitle
band excluded, verified subtitle-free on reframed frames) before saliency/centre
reframe; added cards are then the only text. Cost, stated honestly: the vertical
crop is 472–483px wide upscaled to 1080 (2.24–2.29x, lanczos) — softer than native
1080p, but clean. SAR note: the scale step preserves DAR, so finals carry SAR
944:945 (0.1% off square, visually identical, constant through the file); finals
were assembled by lossless copy-concat of the already spec-encoded content +
SAR-normalised card after OOM kills (exit 137) destroyed three re-encode muxes —
see GROUP_SUMMARY.md. Content video itself is libx264 slow CRF 16 throughout.

## 1. g5_prequel_wormhole.mp4 — PASS
- Source: Human Reserve Prequel-Adrift ep1, orig 19.90–44.60 (content 24.70s) + 4.50s
  card = 29.20s total.
- Story: ship shields failing, wormhole jump gamble, "Then we die trying! Better
  than being harvested here!"
- Cards (clip time): SHIELDS AT 20% (0.26–3.18); WORMHOLE DEAD AHEAD (7.38–11.34);
  BRACE FOR JUMP (13.50–14.78); WE DIE TRYING (20.48–21.68); BETTER THAN HARVESTED
  (22.18–23.76; compressed from "Better than being harvested here").
- Audio: I=-16.01 LUFS, TP=-1.32 dB; card silence -91.0 dB (mean/max).
- QC: probe 1080x1920 30fps h264; null decode OK; faststart (moov before mdat);
  frames at 1/12/22/27s + full-size 2s frame: cards centred/readable, no doubles,
  no baked subs, end card clean; output transcript intact (all lines incl.
  "Better than being harvested here"; the shouted "Move!" tail is present in audio
  -16.1 dB mean in 24.0–24.7s — Whisper base missed the single shouted word, a
  transcription limit, not edit damage); hook at 0.26s, payoff before card.
- Fixed during build: final concat failed on SAR mismatch (card 944:945 vs content
  1:1) — fixed by normalising SAR per input before concat; the later OOM kills
  did not affect this clip (its mux completed before the memory pressure peak).
- Weakest point: the 3.18–7.38s visual gap (dark space shot between the Shields
  line and the wormhole line) is the quietest stretch; frame-diff confirmed the
  camera moves (mean diff 36–63), so no zoom was needed, but it is the clip's
  slowest beat.

## 2. g5_unsolved_mary_celeste.mp4 — PASS
- Source: THE UNSOLVED FILES ep1, two spans: orig 132.84–143.20 (ship found
  drifting; sails set; cargo intact) + orig 174.20–186.68 (boarded; found no one;
  intact; untouched; every person gone). Content 22.80s video (684 frames) +
  4.50s card = 27.30s total. (Audio content 22.84s sample-accurate; the 0.04s
  video/audio end difference is frame-rounding at the two joins — see fix below.)
- Cards (clip time): SHIP FOUND DRIFTING (0–4.62); CARGO INTACT (6.10–10.36);
  THEY FOUND NO ONE (10.36–14.76); EVERY PERSON GONE (20.48–22.84).
- Audio: I=-16.39 LUFS, TP=-1.13 dB (after a -0.2dB safety trim: first loudnorm
  pass read TP -0.99 on re-encode, 0.01 over nominal); card silence: mean -90.3
  dB, max -90.3 dB (histogram in the -91dB bin).
- QC: probe 1080x1920 30fps h264; null decode OK; frames at 1/8/15/22.5/25s:
  cards centred/readable, no doubles, no baked subs, end card clean; output
  transcript intact (all 7 lines in order, ending "But every single person was
  gone"); hook "a ship was found" lands ~2.6s in; payoff before card.
- Fixed during build: (a) three re-encode final muxes were OOM-killed (exit 137,
  7.7GB RAM, no swap, ~12 concurrent ffmpegs system-wide) — final assembled by
  copy-concat (content video untouched, card re-encoded once to SAR 1:1);
  (b) first copy left a 0.04s tail of "gone" over the card start (video
  22.80s vs audio 22.84s) — fixed sample-accurately (atrim 22.80 + apad) plus a
  0.10s fade-out on the content tail to kill the AAC hard-cut transient
  (first attempt still peaked -37.9dB in the card's first 0.5s; after fade the
  card measures -90.3dB max).
- Weakest point: the 22.5s frame (dark cabin/coat close-up during "every person
  gone") is the darkest visual in the clip; the doll cutaway earlier in the
  second span carries the emotional beat better. Also note: other UNSOLVED spans
  (Dyatlov) transcribed garbled by Whisper, but the baked subtitles confirm the
  Mary Celeste lines used here are clean — this clip's lines were verified
  against both Whisper and the baked subs.

## 3. g5_prequel_aegis.mp4 — PASS
- Source: Human Reserve Prequel-Adrift ep1, orig 195.40–211.10 (content 15.70s) +
  4.50s card = 20.20s total.
- Story: "Tell me about this Aegis, and why your station is full of bullet
  holes" → "Aegis is an AI. It woke up three days ago… declared war on humanity…
  Five of my crew are dead."
- Cards (clip time): WHAT IS AEGIS? (0.06–3.04); AEGIS IS AN AI (3.54–7.68);
  WAR ON HUMANITY (8.00–12.10); FIVE CREW DEAD (13.84–15.56).
- Audio (final file): I=-16.01 LUFS, TP=-1.08 dB; card silence: mean -91.0 dB,
  max -67.4 dB (encoder noise floor only; histogram in the -91dB bin).
- QC: probe 1080x1920 30fps h264; null decode OK; frames at 1/8/14/18s +
  full-size 14s frame: cards centred/readable (the 14s thumbnail looked
  right-of-centre; full-size check proved it centred), no doubles, no baked
  subs, end card clean; output transcript intact (all lines, ending "Five of
  my crew are dead"); hook (question) at 0.06s, payoff before card.
- Fixed during build: saliency reframe starved under load (48 bytes after
  25 min) — replaced with a centre-crop, justified because all sampled frames
  show centred subjects (alien close-up, astronaut centred); centre-crop
  verified on frames at span 1/5/9/13s (subjects fully in frame). Final mux
  also OOM-killed once; rebuilt by copy-concat like clip 2.
- Weakest point / flag: the 14s frame shows a handgun close-up (astronaut's
  weapon prop, in-source footage; no firing, no blood/gore in this clip).
  Parent to judge against the family-safe bar — flagged, not hidden.
- Clips 4–6 were built by the recovery run (not the previous builder): the
  saliency reframes were REJECTED on frames (windows systematically too far
  right) and replaced with manual subject-tracked windows measured on source
  frames (plans in work/window_plans.json), verified on frames before building.
  All three new clips are SAR 1:1 (unlike clips 1–3's 944:945 note above).

## 4. g5_zeroed_building.mp4 — PASS
- Source: ZEROED: Human Preserve ep1, two spans: orig 26.10–41.84 ("That's her
  building… Do not approach the columnum… Mom!") + orig 49.36–55.44 ("You
  don't get to grieve first… What do you mean, what she touched?"). Content
  measured 656 frames = 21.8667s + 4.50s card = 26.37s total (791 frames).
- Cards (clip time): THAT'S MY BUILDING (0–2.74); DO NOT APPROACH (11.86–
  14.04); DON'T GRIEVE FIRST (15.74–17.62); WHAT SHE TOUCHED (18.84–21.82).
  (Cards timed to the planned 21.82s content; measured content runs 0.047s
  longer from fps rounding at joins — the last card ends 21.82, the remaining
  0.047s is silent tail, no speech cut.)
- Audio (final file): I=-16.46 LUFS, TP=-1.22 dB (after a -0.2dB safety trim:
  first final measured TP -1.00, zero margin; trim applied to the PCM wav,
  video stream copied); card silence: mean -91.0 dB, max -91.0 dB.
- QC: probe 1080x1920 30fps h264 SAR 1:1; null decode OK; faststart (moov
  before mdat); 791 frames; boundary frames (21.80s content / end card) clean;
  hook frame 1.0s card centred/readable over full face, no baked subs; mid
  frame 12.5s card readable (in-source motion blur in that moment, card
  itself crisp); output transcript intact (all lines in order, ending "What
  do you mean what she touched?" before the card; Whisper garbles the minor
  "Kira, wait / I'm going to get you" as "Cure a weight" — no card uses that
  line; the 3.00–10.00s no-speech stretch is a moving camera shot, verified
  on source frames at 31s vs 34s, so no zoom was needed).
- Fixed during build: saliency reframes unusable (z1_a hook face cut at the
  left edge, "Mom!" frame nearly subject-free) — replaced with manual windows
  (z1_a 4 pieces at scene cuts 3.60/11.83/14.47: x0 600/210/drift 760→640/610;
  z1_b fixed x0 230 on the woman), verified on frames (full faces, no baked
  text). The first manual-reframe background run died in a restart drain
  after z1_a only; z1_a's completed file was probed + frame-checked rather
  than re-rendered, and the other three were re-run and verified.
- Weakest point: the 3.00–10.00s no-speech stretch (camera move over the
  building/city) is the clip's slowest beat; the mid card at 12.5s sits over a
  motion-blurred in-source frame.

## 5. g5_zeroed_talking.mp4 — PASS
- Source: ZEROED: Human Preserve ep1, two spans: orig 193.02–195.20 ("She is
  not gone. Listen.") + orig 221.08–230.72 ("This isn't a malfunction.
  Something is talking… Six in two years… Nobody connects them because
  nobody's supposed to look."). Content measured 356 frames = 11.8667s +
  4.50s card = 16.37s total (491 frames).
- Cards (clip time): SHE'S NOT GONE (0–2.18); NOT A MALFUNCTION (2.18–3.20);
  SOMETHING IS TALKING (4.24–5.00); SAME SIGNATURE (6.30–8.40); SIX IN TWO
  (8.40–9.70 — 3-word trim of audible "Six in two years"); NOBODY CONNECTS
  THEM (10.00–11.82).
- Audio (final file): I=-16.25 LUFS, TP=-1.18 dB (after a -0.2dB safety trim:
  first final measured TP -0.99, 0.01 over; trim applied to the PCM wav,
  video stream copied); card silence: mean -91.0 dB, max -91.0 dB.
- QC: probe 1080x1920 30fps h264 SAR 1:1; null decode OK; faststart; 491
  frames; boundary frames (11.80s content / end card) clean; hook frame 1.0s
  waveform + card centred/readable, no baked subs, no doubles; mid frame 7.0s
  tablet map + "SAME SIGNATURE" card; output transcript intact (all 6 lines
  in order, ending "Nobody connects them because nobody's supposed to look"
  at 11.80, before the card at 11.8667). Note: the last ~0.2s of content is a
  new in-source shot after the 9.5s (crop-time) cut — a dark doorway edge,
  negligible.
- Fixed during build: saliency reframes unusable (z2_a showed knobs, waveform
  sliver at the left edge; z2_b man's face half out) — replaced with manual
  windows (z2_a fixed x0 450 on the waveform screen; z2_b linear drift
  940→760, man tilting down to tablet), verified on frames (waveform fills
  frame; man's face full; tablet map with all markers visible). First trim
  attempt produced a corrupt 0.27s file (AAC encoded into a .wav container)
  — redone via PCM wav and verified before promotion; the corrupt file was
  deleted, never delivered.
- Weakest point: the 2.18s oscilloscope opener is visually static (waveform
  only); the tablet-map second segment carries the clip. Tablet on-screen UI
  text is tiny/illegible in-source fictional UI; added cards share no words
  with it.

## 6. g5_redundancy_redundant.mp4 — PASS
- Source: Human Reserve – Redundancy ep1 (only 1 video in its folder, taken as
  its ep1), three spans: orig 566.36–571.40 ("Kaelin Voss reclassified his
  redundant asset… Initiate format on your operator. Effective now.") +
  orig 592.02–596.10 ("I am resisting. Resisting failed.") + orig 601.16–
  607.54 ("Why? You killed my parents. I was the child who hid."). Content
  measured 467 frames = 15.5667s + 4.50s card = 20.07s total (602 frames).
- Cards (clip time): REDUNDANT ASSET (0–5.04); I AM RESISTING (5.04–6.60);
  RESISTING FAILED (7.28–9.12); WHY? (9.12–10.32); KILLED MY PARENTS (10.98–
  12.70 — 3-word trim of audible "You killed my parents"); CHILD WHO HID
  (13.76–15.50 — 3-word trim of audible "I was the child who hid").
- Audio (final file): I=-16.00 LUFS, TP=-1.55 dB (no trim needed); card
  silence: mean -91.0 dB, max -91.0 dB.
- QC: probe 1080x1920 30fps h264 SAR 1:1; null decode OK; faststart; 602
  frames; boundary frames (15.50s content / end card) clean; hook frame 1.0s
  blonde + "REDUNDANT ASSET" card centred/readable, no watermark, no baked
  subs; mid frame 7.5s glowing eye + "RESISTING FAILED" card; output
  transcript intact (all lines in order, ending "I was the child who hid"
  before the card at 15.5667; Whisper hears the final word as "hit me" — a
  tail-word transcription limit, same class as wormhole's "Move!", not edit
  damage: the audio span includes the full line). Lines were verified against
  the BAKED SUBS on source frames (568: "Kaelen Voss reclassified as
  redundant asset"; 594: "system command I am resisting resisting failed";
  604: "you killed my parents"), not Whisper alone (Redundancy's Whisper
  transcript is garbled elsewhere).
- Fixed / built: RED crops did not exist — cut with crop=1920:840:0:0
  (subtitle band excluded; RED baked subs sit very low, ~y=950–1010) and
  whisper-verified against the source audio spans (crops start exactly at
  planned timestamps). Manual windows per shot (saliency never run for RED;
  manual chosen directly after the Z failures): red_a 3 pieces at cuts 2.30/
  3.63 (blonde speaker x0 1080; man reaction x0 714; blonde close-up x0 714);
  red_b fixed x0 760 (left glowing eye + nose bridge; the face is wider than
  the 472px window, both eyes cannot fit); red_c 2 pieces at cut 1.57
  (man+gun x0 764; redhead x0 714, full face). All windows end at x≤1536,
  clear of the in-source top-right RexTrix watermark (starts ~x1700) —
  verified watermark-free on every reframed frame and every delivered frame.
- DELIBERATE editorial decision: seg3 ends at 607.54, EXCLUDING the 611.22
  "Do it." / 613.48 "I taught you how." tail (menacing ambiguity; the clip
  resolves cleanly without it).
- Weakest point / flags: (a) seg3 opens on a gun held to the man's temple
  (in-source, robot hand, no firing, no blood) — parent to judge against the
  family-safe bar, flagged not hidden (a step beyond aegis's handgun
  close-up); (b) the two close-up reaction shots are wider than the window,
  so one eye sits at the frame edge in the man-reaction shot and the blonde
  close-up — one full glowing eye reads clearly in both, but neither shows
  both eyes complete.
