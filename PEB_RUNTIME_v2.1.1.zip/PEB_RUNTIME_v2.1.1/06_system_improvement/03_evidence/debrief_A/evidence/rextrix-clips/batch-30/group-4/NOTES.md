# Batch-30 Group 4 — NOTES (COMPLETED by recovery builder, 2026-10-29)

## Recovery status
- Previous builder died in a runtime restart drain mid-build. Recovery audit
  (2026-10-29) found: NO deliverable mp4s at group-4/ top level; all three
  episode-1 sources already on disk and verified (see below); the previous
  seg0 files were corrupt (moov atom not found — quarantined, NOT deleted:
  `*.CORRUPT_PREV_BUILDER`, `*.CORRUPT_RESTART2`, `*.CORRUPT_RETRY1`,
  `*.CORRUPT_RESTART3` in work/).
- Two further VM restarts hit the recovery itself (15:55 UTC killed the shark
  reframe; 17:36 UTC killed the gets_up ASS encode). All builds after that
  were launched detached (setsid/nohup) and resumed from verified
  intermediates; every delivered file was re-probed/decoded from scratch.
- No downloads were needed in recovery (all sources already on disk, sizes
  match the Drive survey exactly). Nothing was uploaded, published, submitted,
  or sent to anyone.

## Sources (all tool-verified)
- After Divorce Turns Out She's a Hidden Heiress ep1 — `work/divorce_ep1.mov`,
  1080×1880, 30 fps, h264+aac, 182.93 s, 270,144,316 bytes (exact survey size).
  English dialogue, baked dialogue subtitles throughout dialogue scenes.
  Content flag: both leads show minor bruises/cuts (violence aftermath, no graphic
  gore, no sexual content). Padded 20 px top/bottom to 1080×1920 (source is 1880 tall).
- PRIMAL MACHINES ep1 — `work/primal_machines_ep1.mp4`, 2560×1440 landscape,
  30 fps, h264+aac, 204.08 s, 458,267,462 bytes (exact survey size).
  No detectable dialogue (Whisper: 0 segments); music/SFX bed only; no baked subs
  observed. Landscape → saliency-tracked reframe (smart-reframe, `--out-w 1080`).
  CGI creature action, no gore observed.
- PRIMAL MACHINES II ep1 — `work/primal_machines2_ep1.mov`, 1920×1080 landscape,
  30 fps, h264+aac, 293.52 s, 442,022,325 bytes (exact survey size).
  Sparse dialogue (Whisper: 1 line, "I'll get someone" 29.2–30.2 s) but baked subs
  appear for dialogue Whisper missed (e.g. "you're so small" ~67 s) — cards were
  placed only in verified sub-free windows and share no word with any baked sub
  visible at the same moment. Minor blood on the mech ape's chin in the tiny-life
  beat (flagged, not gore).

Card rule honored throughout: no added card shares a word with a baked subtitle
visible at the same moment. Divorce cards sit only in verified sub-free windows;
baked subs themselves carry the spoken payoff lines.

Shared build facts: every clip 1080×1920 30 fps, libx264 slow CRF 16, yuv420p,
AAC 192k, faststart (moov-before-mdat verified on all six). End card = card_v
(verified: 1080×1920, 30 fps, exactly 135 frames = 4.5 s) at END ONLY, silent,
concat-copied (no re-encode). Cards: Montserrat Bold (ASS "Montserrat Thin",
Bold=-1), white, 4px black outline, centered Y 50%, max 3 words, chunked at
phrase boundaries. Motion check (mean abs-diff over 1.5 s windows): PM1 33–75,
PM2 9.7–15.3, DIV 35–72 — no frozen/static window found, so no 1.1× slow zoom
was applied anywhere (PM2's 9.7 is a live close-up with head/camera drift,
not a freeze).

## Per-clip notes (QC readings are final, post-fix)

### g4_primal_shark_charge — PASS
- Source: PRIMAL MACHINES ep1, 18.0–33.5 s (single continuous source sequence).
- Cards: (0.5–3.0) MACHINE SHARK / (3.5–6.0) CHARGING REX / (12.0–15.0) FACE TO FACE.
  All three verified on frames (hook jaws, charging Rex, face-to-face Rex).
- Fix applied: opening was moved from 14.5 s to 18.0 s after reframe QC showed the
  14.5–19.5 s shark face close-up reframing to unrecognizable skin texture; the
  jaws shot at ~19 s reframes cleanly and is a stronger hook.
- Recovery fixes: (1) v1 audio FAILED — content TP +0.08 dB (over the −1 ceiling)
  and card-tail mean −57.5 dB (a 0.03 s audio overhang: mix 15.50 s vs video
  15.47 s). Rebuilt audio as gain-to-−16 + lookahead limiter 0.70 + atrim to exact
  content duration + 0.05 s fade-out. (2) The loudnorm two-pass method was
  replaced for all later clips after it undershot I on peaky SFX (mix −16.09 →
  norm −17.32); see build_g4_v2.py.
- QC (delivered file): 1080×1920 30 fps h264, 19.97 s (15.47 + 4.50), decode OK,
  faststart OK. Content I −16.65 / full-file I −16.00, TP −1.64. Card tail mean
  −91.0 dB / max −84.3 dB (silent). Reframe verified: hook jaws fill frame;
  mid-chase frames carry source motion blur (not a crop defect).
- Weakest point: mid-chase single frames blur (fast source motion); retention
  rests on creature action, no dialogue.

### g4_primal_roar_siege — PASS
- Source: PRIMAL MACHINES ep1, 92.0–108.0 s.
- Cards: (1.0–4.0) OUTNUMBERED / (5.5–8.5) HE ROARS ANYWAY / (14.0–15.8) SURROUNDED.
  All three verified on frames.
- Note: source targeting-HUD graphic (red reticle on Rex, ~104–106 s) is show
  content, not an added UI; the SURROUNDED card sits above it with no overlap,
  and no added card duplicates it. Reframe verified: Rex-vs-line at 1 s, cannon
  close-up at 7 s, front Rex + reticle at 15 s.
- QC: 1080×1920 30 fps h264, 20.50 s (16.00 + 4.50), decode OK, faststart OK.
  Content I −16.06, TP −3.46. Card tail mean −91.0 dB / max −70.3 dB (silent).
- Weakest point: the 7 s cannon close-up is abstract as a still (reads clearly
  in motion as a gun swinging onto target); no dialogue.

### g4_primal_gets_up — PASS
- Source: PRIMAL MACHINES ep1, 115.0–133.0 s.
- Cards: (2.5–5.5) KNOCKED DOWN / (14.5–17.5) HE GETS UP. Both verified on frames.
- Recovery note: first reframe attempt died silently under load ~13 (ffmpeg
  exited non-zero with no error text, 11.8 MB truncated segment); retry
  succeeded unchanged. A later VM restart killed the ASS encode; the verified
  reframed segment survived and the ASS pass was re-run.
- QC: 1080×1920 30 fps h264, 22.47 s (17.97 + 4.50), decode OK, faststart OK.
  Content I −16.09, TP −3.23. Card tail mean −91.0 dB / max −55.3 dB
  (effectively silent; the −55.3 peak is AAC frame smear at the fade boundary,
  ~30 dB below dialogue level). Reframe verified: downed Rex dominant at 3 s,
  rising head/eye dominant at 16 s.
- Weakest point: at 3 s the rolling Rex's head sits at the left frame edge
  (partially cropped); the body is dominant and the shot reads clearly in motion.

### g4_primal2_tiny_life — PASS (after trajectory + audio fixes)
- Source: PRIMAL MACHINES II ep1, 58.0–74.0 s.
- Cards: (0.5–3.0) THE GIANT / (13.0–15.5) A TINY LIFE. Both verified on frames.
- Baked sub "you're so small" visible ~66–68 s (clip rel ~8–10); both added cards
  sit outside that window and share no word with it (verified: 9 s frame shows
  the baked line alone, no added card).
- Recovery fixes: (1) Default saliency trajectory (center-weight 0.35) FAILED —
  it tracked armor/body mass: 1.5 s showed shoulder only, and the 11–14 s window
  showed dark fur with neither face. Reframed with --center-weight 0.6 (still
  saliency-tracked): 1.5 s giant face dominant, 4 s tiny face close-up, 13–15 s
  tiny cradled by giant. (2) Second card moved 11.0–14.0 → 13.0–15.5 so its whole
  dwell sits on the verified tiny-visible stretch. (3) v1 audio FAILED on
  loudness: content I −18.35 (mix was quiet, −24.24; +8.24 dB gain was eaten by
  the limiter). Iterated to +11 dB gain + limiter 0.70.
- QC (delivered file): 1080×1920 30 fps h264, 20.50 s (16.00 + 4.50), decode OK,
  faststart OK. Content I −16.51 / full-file I −16.06, TP −2.94. Card tail mean
  −91.0 dB / max −67.4 dB (silent). End card verified whole on the promoted file.
- Weakest point: 12–12.5 s passes through dark fur before the tiny appears at
  13 s (the card now starts at 13 s, so the card itself never sits on the dark
  passage); heavy peak limiting was needed on a quiet source (dialogue/bed
  unaffected, only rare peaks squashed).

### g4_divorce_heir — PASS (v2; v1 quarantined as defective)
- Source: After Divorce ep1, 7.0–12.5 s + 34.0–47.0 s (concat on shot boundaries).
- Transcript: 8.18–12.50 "Think you deserve my family's alimony? Take this and get
  out of New York"; 36.52–43.72 "Your honor, this is [notarized] document no. RO037.
  Ms. Victoria Pemberton is the sole surviving heir."
- Cards: (5.6–7.8) THE DOCUMENT — over the sub-free judge-holds-document window
  (source 34.1–36.3, frames at 34.5/35/36.2 show no baked sub; speech starts
  36.52); (16.5–18.3) SOLE HEIR — over sub-free reaction (source 45–46.8,
  documents + gavel, verified on frames). Neither shares a moment with a baked sub.
- Recovery fix (material): v1 card (7.5–10.0) was WRONG — seg0 is 5.5 s, so clip
  7.5–10.0 = source 36.0–38.5, overlapping the baked "your honor, this is notice
  document no. RO037" sub from 36.52 AND sharing the word DOCUMENT. v1 frame at
  9.25 s proved the double. v1 quarantined as
  work/g4_divorce_heir_v1_DEFECTIVE_CARD_OVERLAP.mp4; v2 rebuilt with the
  corrected timing and frame-verified (6.7 s card alone over document, 9.23 s
  baked line alone, 17.5 s SOLE HEIR alone).
- Transcript-gap check: Whisper on 43.5–47.5 found only a "here." fragment at
  43.5–43.7 (tail of the heir sentence); no new sentence starts before the 47.0
  cut, which lands on music/reaction, not mid-sentence. The −24.4 dB mean in that
  window is music swell + gavel, not missed speech.
- QC (v2): 1080×1920 30 fps h264, 23.00 s (18.50 + 4.50), decode OK, faststart OK.
  Content I −16.05, TP −1.46. Card tail mean −91.0 dB / max −63.1 dB (silent).
- Weakest point: baked subtitles carry the whole first half (added cards are
  deliberately sparse); the 5.5 s → 34 s scene jump is a hard courtroom cut.

### g4_divorce_prison — PASS
- Source: After Divorce ep1, 117.0–127.0 s.
- Transcript: 117.14–118.94 "Need a prison reservation?"; 123.36–126.78 "Are you crazy
  cutting off our fuel supply?" (ends on the completed question + shocked reaction;
  the garbled 127.18+ tail was cut — cut at 127.0 lands 0.22 s after "supply?" and
  0.18 s before the next utterance, a clean thought completion).
- Card: (2.0–6.0) SHE TAKES CONTROL — over the verified sub-free gap (source
  119–123, confrontation close-up + phone + walking shots, verified on frames);
  shares no word with either baked line.
- Transcript-gap check: Whisper on 119–123 found a quiet line the full transcript
  missed — "Thank you." at ~119.9 — with NO baked subtitle (frames confirm). The
  card shares no word with it (SHE/TAKES/CONTROL vs THANK/YOU) and does not layer
  over any caption. The gap's loudness (mean −23.2 dB) is dramatic score +
  footsteps, not missed dialogue.
- QC: 1080×1920 30 fps h264, 14.50 s (10.00 + 4.50), decode OK, faststart OK.
  Content I −15.99, TP −5.08. Card tail mean −91.0 dB / max −59.2 dB (silent).
  Card verified on frames (mid-frame, walking shot, no baked sub).
- Weakest point: shortest clip (10 s content); the payoff is the question +
  reaction, with the card doing the framing work.

## Backup (cut list ready, NOT built — group target of 6 already met)
- g4_primal2_parade: PRIMAL MACHINES II ep1, 4.0–24.0 s (machines parade, ending
  before the source title card at ~26 s). Cards: (0.5–3.0) MACHINE APE /
  (4.5–7.5) MACHINE TRICERATOPS / (14.5–17.0) MACHINE REX. Not built: all six
  planned clips passed, and the task forbids padding with extra clips.

## Honest weakest points (confirmed in QC)
- Primal clips are visual/music-only (no dialogue) — retention rests on the
  creature action, not a spoken hook.
- Divorce clips carry baked subtitles throughout dialogue; added cards are
  deliberately sparse (sub-free windows only) to avoid doubles.
- Build note: two early smart-reframe runs failed with BrokenPipeError while the
  VM was thrashing (load ~28, <500 MB free RAM); the same script succeeded
  unchanged once load eased — contention, not a script defect. Intermediate
  trims carry a silent audio track.
- Recovery build note: the ffmpeg loudnorm two-pass filter undershoots I on
  peaky SFX and can let post-AAC TP exceed −1; the recovery audio method is
  measure-mix-I → linear gain to −16 → lookahead limiter 0.70 → atrim to exact
  content duration + 0.05 s fade-out → silence (build_g4_v2.py). Divorce clips
  built with the old method still pass every threshold and were kept.
