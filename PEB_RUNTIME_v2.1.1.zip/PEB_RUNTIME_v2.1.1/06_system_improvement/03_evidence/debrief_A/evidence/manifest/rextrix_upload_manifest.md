# RexTrix Upload+Submit Manifest (2026-10-19)
Source of truth for the rextrix-upload-retry cron. Worker: process clips in file
order, one at a time (upload → IMMEDIATE Whop submit, 30-min rule). Mark done
clips SUBMITTED with URL. All channels are engload23@gmail.com (signed in).
Campaign: https://contentrewards.com/c/campaigns/c92fdeb2-eaa6-42c1-84dd-c97964869cc5
($2.00/1K YouTube, account aze10 Joined — verify each run before submitting).
All three channels already carry the RexTrix bio link (verified 2026-10-19).
Upload specs per clip: Title/Description EXACT, NOT made for kids, Public.

Cron skip rules (2026-10-19): only process Status PENDING. Statuses the cron
must NOT touch: SUBMITTED, USER_UPLOADING_IN_PROGRESS (user is handling the
upload manually — do not re-upload; only flip back to PENDING or SUBMITTED
on the user's explicit report or a verified public-channel audit).

## DONE (reference only — do not reprocess)
- 01 QubeEase https://youtube.com/shorts/zvoDPWJYNzk SUBMITTED
- 03 Seedance https://youtube.com/shorts/H6SmvjnxLOQ SUBMITTED
- 04 QubeEase https://youtube.com/shorts/qC-6ai36NXo SUBMITTED
- 06 Seedance https://youtube.com/shorts/UhthixXEG7g SUBMITTED
- 07 QubeEase https://youtube.com/shorts/0--XHoxE0q8 SUBMITTED
- 09 Seedance https://youtube.com/shorts/WkxtMwPXm6w SUBMITTED

## PENDING

### Clip 10 → QubeEase — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_10_partner_swap.mp4
- Title: She Just Dropped a Bombshell on RexTrix AI Drama
- Description:
```
"We are enforcing a mandatory partner swap." RexTrix AI dramas don't hold back. Link in bio for more.

#rextrix #aidrama #aistory
```
- URL: https://youtube.com/shorts/UTsRg9iJi0o

### Clip 17 → QubeEase — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_17_one_match_rain.mp4
- Title: RexTrix made one match look like a movie 🔥 #rextrix #shorts
- Description:
```
RexTrix turns any idea into playable entertainment — even one match in the rain. Link in bio to try it. #rextrix #aivideo #shorts
```
- URL: https://youtube.com/shorts/VdayUuKxmN0

### Clip 18 → QubeEase — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_18_proof_its_real.mp4
- Title: RexTrix is a REAL app — here's the proof 📱 #rextrix #shorts
- Description:
```
RexTrix is a real app on the App Store — turn any idea into a playable game, then join the Brainrot Party. Link in bio to try it. #rextrix #mobilegame #shorts
```
- URL: https://youtube.com/shorts/sFPSL_1Kves

### Clip 21 → QubeEase — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_21_dragon_morph.mp4
- Title: This RexTrix AI helicopter just became a DRAGON 🐉
- Description:
```
RexTrix turned a military helicopter into an armored dragon mid-flight — watch the exact frame the fuselage tears into scales. Link in bio to try it. #rextrix #aiart #dragon #helicopter #aivideo
```
- URL: https://youtube.com/shorts/MkhXPOzM8Yc

### Clip 26 → QubeEase — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_26_gladiator_charge.mp4
- Title: RexTrix Made a Gladiator Series — Win or Die 🗡️
- Description:
```
RexTrix's new AI drama series "Blood and Flesh" drops you straight into the arena — she charges, she falls, the queen watches. Link in bio to try it.
#rextrix #aivideo #gladiator #aifilm #shorts
```
- URL: https://youtube.com/shorts/3lSkwJ0mywY

### Clip 27 → QubeEase — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_27_giant_foot.mp4
- Title: RexTrix Brainrot Party: A GIANT FOOT Just Fell From the Sky 🦶
- Description:
```
RexTrix's Brainrot Party trailer is pure chaos — a giant foot falling from the sky is only the beginning. Link in bio to try it. #rextrix #brainrot #aivideo #weird #shorts
```
- URL: https://youtube.com/shorts/fymN8izZZgk

### Clip 02 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_02_drama_twist.mp4
- Title: This RexTrix AI Story Took a Wild Turn
- Description:
```
This RexTrix AI story took a wild turn — the partner swap nobody saw coming. Link in bio to make your own.

#rextrix #aidrama #aistory
```
- URL: https://youtube.com/shorts/nFB1Xw0ezMw

### Clip 05 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_05_real_app.mp4
- Title: She Built a Game on Her Phone With RexTrix
- Description:
```
She built a game on her phone with RexTrix — no coding, just words. Link in bio to try it.

#rextrix #aigames #mobilegames
```
- URL: https://youtube.com/shorts/JbxaeQHOXKg

### Clip 08 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_08_money_rain.mp4
- Title: It Started With a Meteor…
- Description:
```
A RexTrix AI story: a meteor, money raining from the sky, then a robot guarding treasure. Link in bio to make your own.

#rextrix #aistory #brainrot
```
- URL: https://youtube.com/shorts/taz5q_JqOLo

### Clip 11 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_11_typing_demo.mp4
- Title: RexTrix Turns Your Typed Idea Into a Playable Game 🤯
- Description:
```
RexTrix turns anything you type into a playable game — watch: type an idea, tap generate, and your game library appears. Link in bio to try it.
#rextrix #aigames #gamedev #mobilegames #aitools
```
- URL: https://youtube.com/shorts/1Krm-kX1FC4

### Clip 13 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_13_golden_arrival.mp4
- Title: RexTrix Arrives: Turn Any Idea Into a Playable Game ✨
- Description:
```
RexTrix — turn any idea into a playable game. Type an idea, get a game. Any genre, any style, any time. Link in bio to try it.
#rextrix #aigames #gamedev #aitools #mobilegames
```
- URL: https://youtube.com/shorts/_BZ9ERsk0vE

### Clip 14 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_14_solemn_stove.mp4
- Title: RexTrix Brainrot: The Hero Brought a Tiny Stove 😂
- Description:
```
RexTrix brainrot at its finest — chaos everywhere, and the hero shows up with a tiny stove for the penguin. Link in bio to try it.
#rextrix #brainrot #aivideo #funny #meme
```
- URL: https://youtube.com/shorts/0e72mHZB-oA

### Clip 19 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_19_texting_apocalypse.mp4
- Title: RexTrix POV: texting through the apocalypse 📱😂 #rextrix #shorts
- Description:
```
RexTrix turns any idea into a playable game — even texting through the end of the world. Link in bio to try it. #rextrix #aigame #shorts
```
- URL: https://youtube.com/shorts/zSe4zTWqCvI

### Clip 20 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_20_dare_to_imagine.mp4
- Title: RexTrix: she DARES you to imagine this 🎮 #rextrix #shorts
- Description:
```
RexTrix lets anyone turn an idea into a playable game — she made hers and dares you to imagine yours. Link in bio to try it. #rextrix #gamedev #shorts
```
- URL: https://youtube.com/shorts/i0TvNCWl_qE

### Clip 22 → Dreamina Cinema Shorts — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_22_teacher_mech.mp4
- Title: RexTrix made the fake mobile game ad REAL 🤖
- Description:
```
RexTrix's Brain Rot Party: teachers turn into literally anything — including a giant flaming mech — and students gotta find them before it's too late. Link in bio to try it. #rextrix #gaming #mobilegame #aiart #brainrot
```
- URL: https://youtube.com/shorts/9y_sv0e-h2Q

### Clip 12 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_12_nose_to_nose_dare.mp4
- Title: RexTrix AI Drama: She Dared Him Nose-to-Nose 😳
- Description:
```
RexTrix makes AI dramas like this — the deal is set, she gets nose-to-nose and dares him… then Maya walks in. Link in bio to try it.
#rextrix #aidrama #plotwist #aistory #aireels
```
- URL: https://youtube.com/shorts/4HoPVDvyNR4

### Clip 15 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_15_trick_shot_cascade.mp4
- Title: RexTrix Game: These Trick Shots Are Insane 🎯
- Description:
```
RexTrix lets anyone build games like this — trick shot after trick shot, made by a creator on her phone. Type an idea, get a game. Link in bio to try it. #rextrix #aigames #trickshot #mobilegames #gamedev
```
- URL: https://youtube.com/shorts/ITuJojfvs40

### Clip 16 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_16_hallway_panic.mp4
- Title: RexTrix: SOMETHING'S COMING 😱 #rextrix #shorts
- Description:
```
RexTrix turns any idea into a playable game — this panic scene was AI-generated. Link in bio to try it. #rextrix #aigame #shorts
```
- URL: https://youtube.com/shorts/o3-wfyhi778

### Clip 23 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_23_egg_eddie_cole.mp4
- Title: RexTrix AI: an office rooster laid Eddie Cole's replacement 🥚
- Description:
```
RexTrix's Sky Goose short: Eddie Cole got replaced by an egg, and the egg rooster is now on full pay. Link in bio to try it. #rextrix #aiart #wesanderson #comedy #shortfilm
```
- URL: https://youtube.com/shorts/eLPvpeIhpe0 (vertical Short, replaced 2026-10-22; old landscape https://www.youtube.com/watch?v=_pV3SRuEDrI set UNLISTED)

### Clip 24 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_24_countdown_chaos.mp4
- Title: RexTrix AI: 3… 2… 1… MONEY RAIN 💸
- Description:
```
RexTrix's Brain Rot Party teaser: the countdown ends and the sky pays out. Link in bio to try it. #rextrix #money #countdown #aiart #brainrot
```
- URL: https://youtube.com/shorts/t6CBgAalVWo

### Clip 25 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_25_tutu_monster.mp4
- Title: RexTrix AI made a JACKED blue monster in a tutu 🩰
- Description:
```
RexTrix's Brain Rot Party teaser #1: blue head, pink tutu, falling meteor. Pure AI brainrot. Link in bio to try it. #rextrix #aiart #brainrot #monster #comedy
```
- URL: https://youtube.com/shorts/hweRQaBKiFg

### Clip 28 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_28_two_of_25_card.mp4
- Title: RexTrix Gave Away a 2-of-25 Signed Card — João Pedro's Mystery Box 🎁
- Description:
```
RexTrix teamed up with João Pedro for a mystery-box giveaway — a hand-signed card, limited to 2 of 25. Watch the reveal. Link in bio to try it.
#rextrix #unboxing #mysterybox #joaopedro #shorts
```
- URL: https://youtube.com/shorts/JHASuKOeWqY (vertical Short, replaced 2026-10-22; old landscape https://www.youtube.com/watch?v=FIPYKFcRIiQ set UNLISTED)

### Clip 29 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_29_ai_built_game.mp4
- Title: RexTrix Built This Game in Seconds — Type a Prompt, Play Instantly 🎮
- Description:
```
RexTrix turns a typed prompt into a playable game in seconds — watch the plane game build itself, then the platformer play. Link in bio to try it.
#rextrix #aigames #gamedev #ai #shorts
```
- URL: https://youtube.com/shorts/bHivNeilgF0 (vertical Short, replaced 2026-10-22; old landscape https://www.youtube.com/watch?v=tTvfbUeFP-k set UNLISTED)

### Clip 30 → Dreamina Seedance — SUBMITTED
- File: ~/workspace/rextrix-clips/review/rextrix_30_spiderman_game.mp4
- Title: He Made a Spider-Man Game on RexTrix 😂 — João Pedro Can't Believe It
- Description:
```
RexTrix ambassador João Pedro typed one idea on the beach and got a Spider-Man game back — his reaction says everything. Link in bio to try it.
#rextrix #spiderman #aigames #joaopedro #shorts
```
- URL: https://youtube.com/shorts/eXvkjwC9ISw (vertical Short, replaced 2026-10-22; old landscape https://www.youtube.com/watch?v=GAMLCiNdfyw set UNLISTED)

### Clip 15 v2 (re-upload after rejection) → Dreamina Seedance — SUBMITTED 2026-10-23
- File: ~/workspace/rextrix-clips/review/rextrix_15_trick_shot_cascade_v2.mp4
- Fix: English-only re-cut (split-screen creator strip cropped out, Arabic-sub segments removed); App Store end card "Link in bio / Download the RexTrix app"
- Title: RexTrix Game: These Trick Shots Are Insane 🎯
- URL: https://youtube.com/shorts/H8lSULyrbi0
- Status: Pending (submitted 2026-10-23 ~18:46 PKT); 24h analytics recording due ~2026-10-24 18:46 PKT

### Clip 16 v2 (re-upload after rejection) → Dreamina Seedance — SUBMITTED 2026-10-23
- File: ~/workspace/rextrix-clips/review/rextrix_16_hallway_panic_v2.mp4
- Fix: gold RexTrix wordmark across clip + new end card "Download RexTrix / Link in bio to get the app"
- Title: RexTrix: SOMETHING'S COMING 😱 #rextrix #shorts
- URL: https://youtube.com/shorts/GfqW9m60Abs
- Status: Pending (submitted 2026-10-23 ~18:46 PKT); 24h analytics recording due ~2026-10-24 18:46 PKT

## Batch: single + Drive 10-pack (uploaded + submitted 2026-10-24 ~04:55 PKT)
All Public Shorts, campaign-submitted immediately after upload ("Clip submitted" confirmed). Related-video chains set except on Dreamina Cinema Shorts (YouTube requires phone verification on that channel to link related videos — pending user verification).
| Clip | Channel | URL | Related → |
|---|---|---|---|
| Single: Live Paranormal S1 | Dreamina Seedance | https://youtube.com/shorts/EJJvE-URBo4 | H8lSULyrbi0 (15 v2) |
| B1-01 Egg office | QubeEase | https://youtube.com/shorts/URnh-c2hDnQ | fymN8izZZgk (clip 27) |
| B1-02 AI employee | Dreamina Seedance | https://youtube.com/shorts/yFbKbc51jRU | EJJvE-URBo4 |
| B1-03 Normal kid | Dreamina Cinema Shorts | https://youtube.com/shorts/_pnkIf5KmFg | NOT SET (phone verification) — intended 9y_sv0e-h2Q |
| B1-04 Ancient giants | QubeEase | https://youtube.com/shorts/uQ7t45qhlgI | URnh-c2hDnQ |
| B1-05 Who can they trust | Dreamina Cinema Shorts | https://youtube.com/shorts/PyszBjywaMw | NOT SET (phone verification) — intended _pnkIf5KmFg |
| B1-06 One player survives | Dreamina Seedance | https://youtube.com/shorts/Wf1_exNOcAY | yFbKbc51jRU |
| B1-07 AI band | QubeEase | https://youtube.com/shorts/TKzOnPQm3JY | uQ7t45qhlgI |
| B1-08 Bring her back | Dreamina Cinema Shorts | https://youtube.com/shorts/Rp1Npx1yX9Q | NOT SET (phone verification) — intended PyszBjywaMw |
| B1-09 Never meant to be found | Dreamina Cinema Shorts | https://youtube.com/shorts/X9TrjgW5C1g | NOT SET (phone verification) — intended Rp1Npx1yX9Q |
| B1-10 Strongest survive | Dreamina Seedance | https://youtube.com/shorts/3ItSYDJDwqU | Wf1_exNOcAY |
24h analytics recordings for these 11 due ~2026-10-25 ~05:00 PKT — user records, HOLD until user says send.

## Batch 2: clips 11-20 (uploaded + submitted 2026-10-24 ~05:25 PKT)
All Public Shorts, campaign-submitted immediately after upload ("Clip submitted" confirmed; items 1 and 6 needed one retry after ~2 min). Related-video chains set on QubeEase + Seedance; Cinema blocked by phone verification (pending user).
| Clip | Channel | URL | Related → |
|---|---|---|---|
| B2-11 Flying bed | QubeEase | https://youtube.com/shorts/vULYdqRNLAI | TKzOnPQm3JY (B1-07) |
| B2-12 Above the clouds | QubeEase | https://youtube.com/shorts/8VOe8BIzztU | vULYdqRNLAI |
| B2-15 Tiny neighbours | QubeEase | https://youtube.com/shorts/jYtENcGWuKQ | 8VOe8BIzztU |
| B2-16 Secret room | QubeEase | https://youtube.com/shorts/1niChWdRUhU | jYtENcGWuKQ |
| B2-13 Sand scorpions | Dreamina Seedance | https://youtube.com/shorts/uqBspysu1ls | 3ItSYDJDwqU (B1-10) |
| B2-18 Mission | Dreamina Seedance | https://youtube.com/shorts/RMAyDGK42VQ | uqBspysu1ls |
| B2-19 Ancient creatures | Dreamina Seedance | https://youtube.com/shorts/Xt8Du6o1lDI | RMAyDGK42VQ |
| B2-14 Dino date | Dreamina Cinema Shorts | https://youtube.com/shorts/Y-nqa-jjpsY | NOT SET (phone verification) — intended X9TrjgW5C1g |
| B2-17 Paris | Dreamina Cinema Shorts | https://youtube.com/shorts/_z6Er_2dw7E | NOT SET (phone verification) — intended Y-nqa-jjpsY |
| B2-20 The message | Dreamina Cinema Shorts | https://youtube.com/shorts/ylzoBbUcsuQ | NOT SET (phone verification) — intended _z6Er_2dw7E |
24h analytics recordings for these 10 due ~2026-10-25 ~05:25 PKT — user records, HOLD until user says send.

## Chaining + AI disclosure (completed 2026-10-24 ~06:13 PKT)
- Related-video chains VERIFIED link-by-link against the full map: Dreamina Seedance 21/21 links OK, QubeEase 16/16 links OK (one continuous loop per channel, incl. rejected v1s 15/16 pointing at their v2 rebuilds). Zero mismatches, zero fixes needed.
- AI-generated disclosure ("Yes, AI was used") SET on all 53 RexTrix videos: Seedance 21/21, QubeEase 16/16, Cinema 16/16. Zero failures.
- Cinema Shorts related-video chain SET + VERIFIED 2026-10-24 ~06:44 PKT after the user completed phone verification: 9y_sv0e-h2Q → nFB1Xw0ezMw → JbxaeQHOXKg → taz5q_JqOLo → 1Krm-kX1FC4 → _BZ9ERsk0vE → 0e72mHZB-oA → zSe4zTWqCvI → i0TvNCWl_qE → _pnkIf5KmFg → PyszBjywaMw → Rp1Npx1yX9Q → X9TrjgW5C1g → Y-nqa-jjpsY → _z6Er_2dw7E → ylzoBbUcsuQ → back to 9y_sv0e-h2Q. 16/16 read back and matched. ALL THREE CHANNELS now fully chained + AI-labeled.

## Batch 3 HD: clips 21-30 (uploaded 2026-10-24; run 10:37-18:12 PKT, 7h35m — slow: Content Rewards server errors + a long browser takeover mid-run + a sign-out dialog on item 10)
All Public Shorts, AI disclosure Yes on all 10, related videos set per chain plan. 9/10 campaign submissions confirmed.
| Clip | Channel | URL | Related → | Submission |
|---|---|---|---|---|
| B3-24 Office gaming (first upload) | QubeEase | https://youtube.com/shorts/scpzNCzCUoU | 1niChWdRUhU (B2-16) | FAILED — Content Rewards server error on 6 attempts; 30-min window expired. Now UNLISTED (2026-10-24 18:53 PKT) after the fresh re-upload succeeded. |
| B3-24 Office gaming (RE-UPLOAD) | QubeEase | https://youtube.com/shorts/p9uIuPkTD1s | 1niChWdRUhU (B2-16) | Confirmed 2026-10-24 18:53 PKT; AI disclosure Yes; vacuum clip tTQGRgQHnSE re-pointed to this new URL. |
| B3-26 Vacuum | QubeEase | https://youtube.com/shorts/tTQGRgQHnSE | scpzNCzCUoU | Confirmed |
| B3-27 Pool | QubeEase | https://youtube.com/shorts/eolzUKuKt0Y | tTQGRgQHnSE | Confirmed |
| B3-30 Pineapple | QubeEase | https://youtube.com/shorts/_GrYGoLKkRA | eolzUKuKt0Y | Confirmed (retry after 2-min wait) |
| B3-21 Bullets | Dreamina Seedance | https://youtube.com/shorts/IGx_Jbde6QM | Xt8Du6o1lDI (B2-19) | Confirmed |
| B3-22 Arena | Dreamina Seedance | https://youtube.com/shorts/fl1ZqWhZMI4 | IGx_Jbde6QM | Confirmed |
| B3-23 Otters | Dreamina Seedance | https://youtube.com/shorts/i4J4RCU3AI4 | fl1ZqWhZMI4 | Confirmed |
| B3-25 Grandma's dress | Dreamina Cinema Shorts | https://youtube.com/shorts/lC49XWd5VAE | ylzoBbUcsuQ (B2-20) | Confirmed |
| B3-28 Choice game | Dreamina Cinema Shorts | https://youtube.com/shorts/AcexdV8l7Is | lC49XWd5VAE | Confirmed |
| B3-29 Normal game | Dreamina Cinema Shorts | https://youtube.com/shorts/3oRIxdf5fZE | AcexdV8l7Is | Confirmed |
| New teacher game (re-cut of Normal Game, 18.93s) | Dreamina Cinema Shorts | https://youtube.com/shorts/0HDRj24QvAc | 9y_sv0e-h2Q | Confirmed 2026-10-27 ~23:31 PKT; AI disclosure Yes; Normal Game (3oRIxdf5fZE) re-pointed to this URL; Submission ID 633a7c21-a840-4ed8-8bc3-ee2227906d02, Pending |

## Appeals check (2026-10-28): NO in-UI appeal route found on Content Rewards for rejected submissions (cards, rejection-reason dialogs, payout-details dialogs, campaign brief, settings, full "If a clip is rejected" help text — which states a rejected post can never be submitted again; only a new post is contemplated). No appeals filed. Submission IDs for the 7 bot-activity rejections, for any support-chat appeal request:
- Choice Game https://youtube.com/shorts/AcexdV8l7Is — 5f280e99-4f37-490b-a793-14b81c08995d
- clip 25 https://youtube.com/shorts/lC49XWd5VAE — d8bb04d8-a8aa-4d94-8b32-5462afbcb919
- Never Meant https://youtube.com/shorts/X9TrjgW5C1g — 51c70950-9b83-44c0-9566-77d09d6881e2
- Bring Her Back https://youtube.com/shorts/Rp1Npx1yX9Q — 9ca0943d-602e-4d47-a5a7-06b1b809e235
- One Player https://youtube.com/shorts/Wf1_exNOcAY — 46e79325-86c5-4da8-92f7-f207ef31b861
- Trust https://youtube.com/shorts/PyszBjywaMw — e715cd23-bf48-472e-bc78-85bd46d35b8d
- Normal Kid https://youtube.com/shorts/_pnkIf5KmFg — 63ddafb3-13a2-4e68-b5a7-7d75d3ba1eae
24h analytics recordings for batch 3 due ~2026-10-25 across the day (each ~24h after its post time) — user records, HOLD until user says send. B3-24's recording is now due ~2026-10-25 ~18:53 PKT (re-upload time).

## Batch 5 v3 uploads — 2026-10-28 (browser task 16:40–19:24 PKT)
All 5 uploaded Public, not made for kids, English, AI disclosure Yes verified. Chain inserts verified.
- A NEON RIOT → Cinema — https://youtube.com/shorts/59STanwwggw (0:25) — SUBMITTED Pending, ID c17efa4f-17e7-4087-9f37-12fa7d6e742e. Related set 9y_sv0e-h2Q. Teacher clip 0HDRj24QvAc re-pointed 9y → 59STanwwggw. Clip 1 later re-pointed 9y → BDh5eArwW94.
- B Tina → Seedance — https://youtube.com/shorts/QUKqwfoh-KA (0:18) — SUBMITTED Pending, ID 76348c15-4e12-4406-9c70-db8507471460. Related set fl1ZqWhZMI4 (was i4J4RCU3AI4's related). i4J4RCU3AI4 re-pointed fl1ZqWhZMI4 → QUKqwfoh-KA.
- C AGI Summit → QubeEase — https://youtube.com/shorts/0rPzmUm20zo (0:25) — SUBMITTED Pending, ID 4b0bc0fb-15be-4fb4-aa72-e7aff5214826. Related set eolzUKuKt0Y (was _GrYGoLKkRA's related). _GrYGoLKkRA re-pointed eolzUKuKt0Y → 0rPzmUm20zo.
- D João creator → Cinema — https://youtube.com/shorts/BDh5eArwW94 (0:14) — UPLOADED, SUBMISSION FAILED (no ID): "We couldn't confirm exactly when this post went live" at 14:11 UTC + retry 14:13 UTC same message; NOT re-uploaded per instruction. Related set 9y_sv0e-h2Q. Clip 4 later re-pointed 9y → rh2JH9Ur_KY.
- E João showcase → Cinema — https://youtube.com/shorts/rh2JH9Ur_KY (0:25) — UPLOADED, SUBMISSION FAILED (no ID): same message at 14:21–14:22 UTC + retry 14:24 UTC; NOT re-uploaded. Related set 9y_sv0e-h2Q confirmed on Studio edit page, Visibility Public.
- Final Cinema tail verified: 0HDRj24QvAc → 59STanwwggw → BDh5eArwW94 → rh2JH9Ur_KY → 9y_sv0e-h2Q (D/E adjacent as required).
- RETRY launched ~19:25 PKT (new browser task) for D + E submissions only, inside the 30-min post windows (D window ~until 19:38–19:41 PKT, E ~until 19:50 PKT); result pending.
- RETRY RESULT ~19:30 PKT: BOTH SUCCEEDED — D (BDh5eArwW94) SUBMITTED Pending, ID 4422420c-19f5-45b8-9c2c-3190679f607b; E (rh2JH9Ur_KY) SUBMITTED Pending, ID 4bbc28f5-3ef3-4e74-a39c-a829e105b8ea (first retry attempt same "couldn't confirm" message, second attempt ~19:29 PKT succeeded). IDs verified against linked URLs on Submissions page. All 5 v3 clips now uploaded + submitted Pending. No re-uploads.
- APPEAL SENT ~21:57 PKT (support): appeal message for the 7 bot-activity rejections SENT to the existing Content Rewards support thread with Emy (account aze10). Composer cleared + verified empty before sending; mid-draft corruption of item 5 repaired and items 5–7 re-verified; sent message shows in thread marked "Just now". No reply from support yet at send time. Manager appeal (Clip Brand via Discord) still pending — Discord sign-in in progress.

## Batch 6 clips 3–5 uploads — night of 2026-10-28 → 2026-10-29 PKT (browser task 22:52–00:52 PKT)
All 3 uploaded Public, not made for kids, English, AI disclosure Yes verified, no verification code requested, no re-uploads, no submission retries needed. Chain inserts verified ("Changes saved").
- 6c Panda BoBo → Seedance — https://youtube.com/shorts/zB5SFItra2A — SUBMITTED Pending, ID d8e7774b-e2d3-471a-aee4-85de015f91b1. Related set fl1ZqWhZMI4. QUKqwfoh-KA re-pointed fl1ZqWhZMI4 → zB5SFItra2A.
- 6d Phoenix Throne → Cinema — https://youtube.com/shorts/quafh_FFmXI — SUBMITTED Pending, ID ba7365f1-e32f-4f17-9149-a88cab594d66. Related set 9y_sv0e-h2Q. rh2JH9Ur_KY re-pointed 9y_sv0e-h2Q → quafh_FFmXI.
- 6e Echo of Derelict → QubeEase — https://youtube.com/shorts/u0jxasxjAEU (0:25) — SUBMITTED Pending, ID 599d6ef0-7c0d-4dca-9210-1d63fcef33f3. Related set eolzUKuKt0Y. 0rPzmUm20zo re-pointed eolzUKuKt0Y → u0jxasxjAEU. Public page verified: exact title, @QubeEase, "AI: Content was made with AI" label.
- Current tails after these inserts: Seedance newest zB5SFItra2A → fl1ZqWhZMI4; Cinema newest quafh_FFmXI → 9y_sv0e-h2Q; QubeEase newest u0jxasxjAEU → eolzUKuKt0Y.
- Batch-6 v2 rebuilds (6a/6b) NOT uploaded — held for Adobe Podcast Enhance audio (Adobe task pending sign-in at last check); no-sign-up alternatives verified 2026-10-28 (Submind, SoundTools) with a switch decision pending from the user.

## Batch 6 v2/v3 uploads — 2026-10-29 ~02:09–02:38 PKT (browser task)
Both uploaded Public, not made for kids, English, AI disclosure Yes verified. No re-uploads.
- 6a v3 → Seedance — https://youtube.com/shorts/TVUnWajuV_g (0:11) — SUBMITTED Pending, ID 43ec32a1-de31-48af-a259-56424a853282. Related set fl1ZqWhZMI4. zB5SFItra2A re-pointed fl1ZqWhZMI4 → TVUnWajuV_g.
- 6b v2 → Cinema — https://youtube.com/shorts/IZC0aX1VCaM (0:22) — UPLOADED, SUBMISSION FAILED (no ID): "We couldn't confirm exactly when this post went live. Try again in a few minutes." on first attempt + single retry after 2 min; NOT re-uploaded per instruction. Related set 9y_sv0e-h2Q. quafh_FFmXI re-pointed 9y_sv0e-h2Q → IZC0aX1VCaM. Submissions list checked: no 6b entry. RETRY task launched ~02:38 PKT for 6b submission only, inside the 30-min window if still open (same playbook as the v3 D/E retry that succeeded); result pending.
- RETRY RESULT ~02:41 PKT: 6b SUBMITTED Pending, ID 561fc60c-3327-4f9e-abf4-5eb3daac60cc — verified in Submissions (29 Oct 2026, YouTube clip, 0 views at check). Video was "5 minutes ago" at ~02:39 PKT, well inside the window. No re-upload, no second retry needed. All batch-6 clips (6a v3, 6b v2, 6c, 6d, 6e) now uploaded + submitted Pending.
- Current tails after these inserts: Seedance newest TVUnWajuV_g → fl1ZqWhZMI4; Cinema newest IZC0aX1VCaM → 9y_sv0e-h2Q.

## Full submissions audit (2026-10-29 ~03:04 PKT)
- Live Content Rewards submissions list (Rextrix-filtered, all pages): 78 total = 3 Approved + 66 Pending + 9 Rejected. Matches manifest record.
- Diff of manifest upload IDs vs live list: ONLY gap is scpzNCzCUoU (B3-24 first upload — submission failed, 30-min window expired, now UNLISTED, replaced by submitted p9uIuPkTD1s). No live/public video lacks a submission.
- 4 live-list IDs absent from the manifest's shorts/ grep (FIPYKFcRIiQ, GAMLCiNdfyw, _pV3SRuEDrI, tTvfbUeFP-k) are the old LANDSCAPE versions of clips 23/28/29/30, recorded in the manifest as watch?v= links, all UNLISTED and replaced by submitted vertical Shorts. Not gaps.
- Timing caveat: the dashboard shows dates only, so minute-level "within 30 min" cannot be re-proven from it for old batches. The only known window expiry is scpzNCzCUoU (neutralized); v3 D/E and 6b retries are documented as inside their windows.
- The 3 new Drive clips (D2/D3/D4) were still uploading when this list was read and are not in this snapshot; their submission status comes from the upload task.

## Drive clips batch (uploaded 2026-10-29, verified 2026-10-29 ~11:54 PKT)
- D2 blind box date outfit → QubeEase — https://youtube.com/shorts/Z5Z36DpJ7UE — SUBMITTED Pending (29 Oct 2026); submission ID not captured in verification read. Chain edit (u0jxasxjAEU → Z5Z36DpJ7UE) UNVERIFIED (public pages don't show related videos).
- D3 normal kid / orphanage → Cinema — https://youtube.com/shorts/OzLpnHn8XXs — SUBMITTED Pending (29 Oct 2026); submission ID not captured. Chain edit (IZC0aX1VCaM → OzLpnHn8XXs) UNVERIFIED.
- D4 only one player survives → Seedance — https://youtube.com/shorts/IbEUm7GumGg — SUBMITTED Pending (29 Oct 2026); submission ID not captured. Chain edit (TVUnWajuV_g → IbEUm7GumGg) UNVERIFIED.
- D1 four gods / four cages → Cinema — https://youtube.com/shorts/n8VyIRA5XTE — SUBMITTED Pending (29 Oct 2026), ID 7701003a-25b4-408b-8cc6-1b1a023d1115, 0 views at check; Public, not made for kids, English, AI disclosure Yes; related 9y_sv0e-h2Q; chain edit OzLpnHn8XXs → n8VyIRA5XTE saved. No timestamp error, no re-upload. All 4 Drive clips now uploaded + submitted. Live totals after D1: 82 clips = 3 Approved + 70 Pending + 9 Rejected.

## Star-god pair E1/E2 (uploaded 2026-10-29, reported ~12:26 PKT)
- E1 arrival "She Fell Into a World Made of Starlight" → Cinema — https://youtube.com/shorts/TiXIj3WBOz8 (0:23) — SUBMITTED Pending, ID 644fdbbb-00cb-406d-8147-02dd6cd3cf57, 0 views at check; Public, not made for kids, English, AI disclosure Yes; related 9y_sv0e-h2Q; chain edit n8VyIRA5XTE → TiXIj3WBOz8 saved.
- E2 confrontation "Two Powerful Gods Fighting Over One Tiny Human" → Cinema — https://youtube.com/shorts/DWAUrG_OAtc (0:25) — SUBMITTED Pending, ID 04c16a6e-f31c-49eb-bced-8d014d5b023c, 0 views at check; Public, not made for kids, English, AI disclosure Yes; related 9y_sv0e-h2Q; chain edit TiXIj3WBOz8 → DWAUrG_OAtc saved.
- Live totals after E1/E2: 84 clips = 3 Approved + 72 Pending + 9 Rejected. All 6 user-supplied Drive clips from 2026-10-29 (D2/D3/D4/D1/E1/E2) now uploaded + submitted.

## Voiceover pilot v3 (uploaded 2026-10-29 ~14:16–14:25 PKT, browser task)
- Pilot v3 (viral captions: Montserrat Bold, white, 4px black outline, centered, max 3 words/chunk; audio = voiceover only, silenced original) → Cinema — https://youtube.com/shorts/vWnVzQvNpCY (0:29) — SUBMITTED Pending, ID 7efa2a79-84b3-47a8-afc6-4a5467c868a6, 0 views at check; Public, not made for kids, AI disclosure Yes verified in Studio; title "AI is officially out of control — RexTrix built this from one sentence".
- Chain edits verified saved: new Short related set to 9y_sv0e-h2Q; DWAUrG_OAtc re-pointed to the new Short. Cinema tail now: vWnVzQvNpCY → 9y_sv0e-h2Q.
- Submission: first attempt returned "couldn't confirm exactly when this post went live" → waited 2 min, retried once, succeeded ("Clip submitted"), no re-upload.
- COUNT NOTE: the upload task's submissions-list read showed 108 clips / 93 Pending → 109 / 94 Pending, which conflicts with this manifest (84 → 85 expected). The pilot's own submission (ID + Pending) is verified; the list totals need a RexTrix-filtered re-read to reconcile — do not overwrite manifest totals with the task's unfiltered-looking counts until reconciled.

## T-draft rebuilds T1/T3 (uploaded 2026-10-29 ~15:50–16:02 PKT, browser task)
Rebuilt from source episodes (Strawberry ep1, Toilet Knight ep1) with semantic phrase-whole cards, Montserrat Bold centered; T3 with 1.1x zoom on the throne window. Both Public, not made for kids, AI disclosure Yes; neither re-uploaded.
- T1 strawberry rebuild → Seedance — https://youtube.com/shorts/EAWT8VvUKhI (0:18) — SUBMITTED Pending, ID 879fbe74-eb89-4452-a6cb-fa6e00d84e8c; title "Testing if RexTrix makes anything you type". Chain: new → fl1ZqWhZMI4; IbEUm7GumGg re-pointed → new Short. Seedance tail now: EAWT8VvUKhI → fl1ZqWhZMI4.
- T3 toilet rebuild → Cinema — https://youtube.com/shorts/9vPek15mKcw (0:20) — SUBMITTED Pending, ID 86780392-4b71-44eb-8902-7368283fd578; title "Don't download RexTrix unless you want to lose 3 hours in a toilet kingdom"; first submission attempt succeeded, no retry needed. Chain: new → 9y_sv0e-h2Q; vWnVzQvNpCY (pilot) re-pointed → new Short. Cinema tail now: 9vPek15mKcw → 9y_sv0e-h2Q.

## Batch-30 group 1 upload — CAMPAIGN PAUSED (2026-10-30 ~02:46–02:58 PKT, browser task)
- CAMPAIGN PAUSED: Rextrix campaign page (https://contentrewards.com/c/campaigns/c92fdeb2-eaa6-42c1-84dd-c97964869cc5) shows "Joined · Paused" — "Paused by the brand since Oct 30. Scheduled payouts still go out. Your views keep counting, and new earnings settle when the brand resumes." Submit clip button DISABLED. This is why Rextrix is absent from "Your campaigns" / "Active campaigns" / Discover search, despite 87 prior Rextrix clips in history. Submissions page has no new-submission button; submit dialog has no campaign selector.
- Clip 1 g1_survival_rate.mp4 → Cinema — https://youtube.com/shorts/iJNXlOHq8Dc — UPLOADED, NOT SUBMITTED (no ID). Public, not made for kids, AI disclosure Yes; title "RexTrix | MOVE AND YOU DIE"; description hook + "Made with RexTrix. Download link in bio: https://rextrix.onelink.me/nJbb/dbj5fov3"; new Short's related set to previous Cinema RexTrix Short ("Don't download RexTrix unless you want to lose 3 hours in a toilet kingdom"). Published ~02:46 PKT; 30-min window ends ~03:16 PKT. NOT submitted to ZEDS DEAD or Split-Screen UGC (their dialogs opened for inspection only, cancelled). Re-point of the previous Short to this new Short NOT confirmed in the task report.
- Clips 2–6 NOT STARTED (no uploads, no submissions) — held deliberately: each clip must be submitted within 30 min of its upload, and submission is impossible while paused. Do NOT upload further clips until the campaign resumes or the user directs otherwise. If the campaign resumes after clip 1's window, clip 1 may no longer be submittable under the 30-min rule — do NOT re-upload without new user instructions.

## Clip Brand clipper-chat check — Whop (2026-10-30 03:25–03:28 PKT, read-only)
- Whop clipbrand #Chat (27–30 Oct), home feed, Forums, visible support thread READ: in-chat search 0 results for "RexTrix" and for "paused". NO clipper discussion of the RexTrix pause, reason, duration, resume date, views-during-pause, late submissions, payouts, or RexTrix rejections in any readable place.
- Only RexTrix reference: 22 Oct analytics submission in the support thread, answered by Natia Kurdadze with "Thanks Ali" — no pause discussion.
- No brand/mod statement about the pause or a resume date. Latest brand post: Natia, 30 Oct 02:19 PKT, generic approval guidance ("How to Create Content That Gets Approved (So You Get Paid!)") — no RexTrix/pause mention.
- LIMITS: sidebar Bounties + Announcements locked (opened a product/sign-up page, not a readable feed); START HERE + FAQ showed loading/Access Denied — a separate announcements channel could NOT be verified. Discord NOT checked: invite screen only (13 online, 361 members), join/sign-in not attempted per instructions — same blocker as the manager appeal.
- Other #Chat issues (regular members): slow/absent admin replies (Anmol; Muhammad Hassan on Overglow AI analytics, "not responding or viewing the dm messages"); newcomer confusion; questions (UTM link for SAI, "on screen text" meaning); legitimacy doubts ("Is this server even legit"); self-promo/off-topic offers; a different live campaign promoted instead (Wiped, $1.5K budget, $1 CPM).
- Implication: the pause question still rests on the Content Rewards support message (in flight); the chat gives no answer, and slow admin replies seen in #Chat suggest support may be slow to answer.

## Support message about the pause — SENT (2026-10-30 03:31 PKT)
- Sent verbatim to the Content Rewards Support conversation (same thread as the Emy bot-activity appeal; thread was still open, no reopen needed), as aze10, under "October 30", marked "Just now". No file/screenshot/recording attached. No campaign submission touched.
- Text: pause since Oct 30 + Submit disabled; clip 1 https://youtube.com/shorts/iJNXlOHq8Dc public but unsubmittable; asked (1) why paused + expected duration, (2) whether views during pause count on resume, (3) late submission vs re-upload for clip 1, (4) whether to hold further uploads.
- Awaiting support reply. Note: Whop #Chat shows clippers complaining about slow/absent admin replies, so a fast answer is not guaranteed.

## aze748692 sign-in — RESOLVED by user takeover (2026-10-30 ~03:49 PKT)
- BOTH ACCOUNTS NOW CONFIRMED WORKING for upload access. Nothing uploaded/published; no setting or password changed by the agent.
- engload23@gmail.com (Eng Load): QubeEase (@QubeEase, 5 subs), Dreamina Seedance (@Dreaminaseedancellab, 3), Dreamina Cinema Shorts (@DreaminaCinemaShorts, 3). Upload dialog opens.
- aze748692@gmail.com (ali aze): Studio https://studio.youtube.com/channel/UCNxlxQG_ELPDuan8LbX5OoA — Motivational Zone (@Qoutebyme, 14 subs, selected) + Dreamina Realism Clips (@DreaminaRealClips, 3). Upload dialog opens. Both accounts coexist in the window (aze switcher lists engload23 under "Other accounts"); neither signed out.
- Path: saved vault login rejected twice ("Wrong password"), so the user signed in directly + completed YouTube's "Verify that it's you" check themselves in a separate tab. CAVEAT: the vault's saved aze password is still the rejected one — a future fresh sign-in via the saved login would fail again; vault separation (2 google.com entries) still NOT achieved at last credentials.list check.

## Hold + pause watch + next campaign (user decisions 2026-10-30 ~03:52 PKT)
- HOLD: all made clips (batch-30 groups, batch-15 finals, incl. uploaded-but-unsubmitted clip 1) stay held until the RexTrix campaign goes live again. No uploads until resume or user direction.
- PAUSE WATCH cron (id rextrix-pause-watch, goal-owned): interval 12h, timezone Asia/Karachi, first run Fri 2026-10-30 ~15:53 PKT; covers Oct 30–Nov 2 (about 8 checks). Read-only campaign-page check; silent while paused; messages this chat immediately on resume; final summary + self-removal after Nov 2 if still paused. Log: hidden_files/rextrix_pause_watch.log. NOTE: the schedule tool cannot express an end date, so the 4-day stop is enforced by the job body (self-removal) — remove manually if it ever overruns.
- NEXT CAMPAIGN: discovery browser task launched (Whop discover + Content Rewards open campaigns) for a shortlist; nothing joined, nothing submitted. Shortlist to be presented for user pick.

## Next-campaign discovery — Content Rewards Discover (2026-10-30 03:52–04:03 PKT, read-only)
- Real list: https://contentrewards.com/c/discover ("54+ campaigns"). The Whop link https://whop.com/discover/app/app_QRxsQodZgK1r4D/ resolves only to the Content Rewards app page, not a campaign list. Signed in as aze10. NOTHING joined, submitted, or messaged.
- SHORTLIST (public page; AI rule hidden until joining unless noted): Backyard Breaks (ClipHouse) $2.00/1K TT/IG/YT, $10,284 left, 329 creators; ForgeGUI Basic Clipping (BloxClips) $1.00/1K TT/IG + $0.50 YT, $24,088 left (largest), provided footage; Call of Duty MW4 Launch (Clipping Culture) $1.75 TT / $1.25 IG, $20,135 left, launched 29 Oct, 51 creators, TT/IG only; Boxabl Phase 2 (Clip Farm) $1.00/1K TT/IG/YT/X/FB, $7,076 left, 34 creators (+ Boxabl Official $0.50/1K, ~$63,200 left, 871 creators, not detail-checked); FOLD (ClipHaus) $1.25/1K TT/IG/YT + $0.75 X, $8,753 left, 25 creators, Bitcoin product; Bumblebee AI explainers (Async) $0.40/1K, $1,000 untouched, 1 creator — ONLY one explicitly asking for AI explainers; HardScope x ClipFarm group $1.00/1K, ~$9,800 left group-wide, 586 creators, sub-campaigns not detail-checked.
- ALREADY KNOWN: ZEDS DEAD already joined, "Almost full", $93 left, may fill before review; Split-Screen UGC English already joined ($3.00/1K TT/IG/X, $1.50 YT, $4,129 left) but UGC + own-photo pfp + tier-1 targeting friction; Split-Screen Non-English open ($1.00/1K, $7,811 left, 407 creators); Swiss NOT FOUND (0 campaigns); RexTrix NOT OPEN to join (0 in Discover + 0 in Your campaigns) — matches paused status.
- SKIP: Scover Cheating Drama $7.00/1K by application — requires face on camera + real co-creator actor + photo/name pre-submission + draft pre-approval; does not fit faceless AI clips.
- NO page checked stated a Pakistan exclusion, follower minimum, or US/CA/AU verification requirement; only audience flag was Split-Screen English tier-1 targeting.
- UNVERIFIED (from discovery report, NOT yet confirmed by parent): a support line that a video that cannot be submitted "will not count toward earnings" — verification browser task launched to read the support thread directly; do NOT treat as confirmed until verified.

## Support reply to pause message — Ghuffran (2026-10-30, verified by read-only thread check 04:03–04:05 PKT)
- Reply to the Oct 30 pause message, from Ghuffran, in full: "Only the campaign moderators can provide details about the pause and manually handle submissions. Please contact them through the campaign support chat to clarify these questions. If your video cannot be submitted, its views will not count toward earnings."
- What it does NOT answer: pause reason, pause duration, late submission vs re-upload, or whether to hold uploads — all deferred to campaign moderators via "the campaign support chat".
- CONFIRMED CONSEQUENCE: clip 1 (https://youtube.com/shorts/iJNXlOHq8Dc) views will NOT count unless it gets submitted somehow — needs late/manual submission or re-upload + submission after resume. "Manually handle submissions" hints moderators may be able to handle clip 1 manually.
- Emy bot-activity appeal — NO decision yet. Last support message on it: Emy (1d, i.e. Oct 29): "Can you send a screenshot of the flagged?" Only later message was a generic Content Rewards Support check-in (17h, Oct 29). Screenshot NOT sent yet — sending needs user approval (standing rule).
