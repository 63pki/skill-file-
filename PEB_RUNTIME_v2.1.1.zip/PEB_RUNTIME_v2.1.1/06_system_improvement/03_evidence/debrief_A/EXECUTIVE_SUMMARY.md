# Executive summary — RexTrix editing debrief (2026-10-30)

Retrospective only. No clip was rendered, uploaded, published, or bought for
this debrief. No provider was called. All findings come from files, logs,
measurements, and delivery records already on disk, re-read on 2026-10-30.

## Whose work this is

The "agent" in this debrief is the main agent in this conversation. Its actual
job was: writing briefs and rules, coordinating subagent builders and
independent QC agents, doing parent (independent) verification of delivered
files, delivering files to the user, and running uploads/submissions. It did
not personally render most clips; builders did. Where a finding is a
builder's claim, it is labelled as such until parent verification reproduced
it. That distinction is the single most valuable habit in this project, and
it is also where the project repeatedly failed before adopting it.

Evidence labels used throughout: OBSERVED (file, measurement, inspected
frame, recorded feedback, analytics on record), TESTED (a bounded test
supports it, scope stated), HYPOTHESIS (plausible, not established),
UNKNOWN (evidence missing or contradictory).

## Most important supported successes

1. **Independent QC caught real defects that builder self-QC missed, three
   separate times.** OBSERVED: batch-30 group 1 failed independent QC on
   audio bitrate (91–149 kbps full-file) and was fixed by audio-only
   re-encode; group 2's died_three_times failed on a mid-sentence end cut
   and was fixed by extending to 353.2s; batch-15 B3 failed on true peak
   −0.9903 dBFS at 4x oversampling and was fixed by −0.1 dB audio-only gain
   + remux (final −1.078). Sources: `batch-30/COORDINATOR_LOG.md`,
   `batch-15/ASSEMBLY_LOG.md`.
2. **The measurement methods were corrected in public, with arithmetic, not
   by waiving gates.** OBSERVED: full-file audio bitrate is diluted by the
   silent end card (content-only 193–201 kbps vs full-file 91–149 kbps);
   output-side `-t` does not trim loudnorm; mono downmix inflates true peak
   by up to ~1.75 dB; card silence must be judged on PCM, not volumedetect's
   −91 dB floor. These four corrections are now in `CLIP_RULES.md` §6 and
   `NEVER_REPEAT_RULES.md` entries 21–25. TESTED scope: batch-30 groups
   1–6 and batch-15 sets 1–2 + C2/C3.
3. **Honesty-over-count held under a 30-clip target.** OBSERVED: brief
   (2026-10-29) ordered strong clips or a reported gap, never padding.
   Result: 36 built, 34 QC-passed, 0 dropped, 0 padded; target exceeded by 4
   before any held-clip ruling. The two held clips (gun framing) were held
   for a human ruling, not quietly shipped. Source: coordinator log final
   tally.
4. **Source identification was done by elimination, not by title.**
   OBSERVED: T1 (Strawberry) and T3 (Toilet Knight) rebuilds were sourced
   from verified episodes and passed parent QC; T2's two title candidates
   were eliminated on full transcripts + frames (Cheating's ep1: no blonde
   teen girl, no plaid shirt, no apron woman, "plan"/"daughter" absent;
   Swapped ep1–6: same story throughout, grep 0 hits). Source:
   `t-drafts/REBUILD_NOTES.md`.
5. **Restraint protected quality in at least three places.** OBSERVED:
   pilot v1's bedded source audio was silenced, not defended; Dog/Mutant
   were held rather than forced onto unfitting dark stems, then built once
   fitting YouTube Audio Library tracks arrived; the batch-30 group-5
   edit-3-originals scout reported ZERO strong clean moments instead of
   manufacturing clips from a rejected edit.

## Most important supported failures

1. **46 delivered clips have zero audience evidence.** OBSERVED: batch-30
   (34 passed) + batch-15 (12 passed) were delivered ready-to-upload only
   and are held by the campaign pause. No views, no retention, no A/B test
   exists for any of them. Every retention claim about them — hook-first,
   human-edit-feel, viral captions, cinematic arc — is HYPOTHESIS, not
   TESTED. The only audience evidence in the project belongs to older
   uploaded clips (3 approved, 9 rejected, pending-view pattern).
2. **The newest template (cinematic VO arc) was built 12 times despite its
   own scouts warning it did not fit.** OBSERVED: scout packages flagged
   B2 Primal as "weakest fit… drop PRIMAL first" if strictly human
   character clips were wanted, C3 as "bright candy comedy, not suspense,"
   and C1's named character (Briggs) as never on screen. All three were
   built and delivered anyway, with flags. The template's name-slot forced
   narration about people the picture does not show.
3. **Caption systems diverged across one campaign without a decision.**
   OBSERVED: edit-3/pilot use DejaVu Sans Bold 54, lower-third y=1400;
   batch-30/15 use Montserrat Bold, centered Y 50%; group-2/group-3 Crow
   use pillarbox pads. Three placement systems, two fonts. A viewer watching
   the channel in sequence sees inconsistent captions. No record shows this
   was chosen; it accreted per batch.
4. **Ducking ratios are claimed from build recipes, not measured on
   finals.** OBSERVED: set-1 QC notes the 0.35 duck ratio "cannot be
   re-measured from a finished mix without stems." The same applies to
   every ducked mix delivered. If stems are lost, the duck claim becomes
   unverifiable. No final-mix duck verification method exists on record.
5. **The upload run started without a campaign-status pre-flight.**
   OBSERVED: batch-30 group-1 clip 1 was uploaded 2026-10-30 ~02:46 PKT and
   could not be submitted because the campaign had paused; the pause was
   verified ~02:58 PKT. Per support's reply, its views will not count
   unless manually handled. A one-line status check before the first upload
   would have held the whole run. This is the main agent's failure, not a
   builder's.
6. **A blanket user verdict killed reusable learning.** OBSERVED: edit-3
   was rejected as "these are not good clips still" with no per-clip defect
   on record. The originals were retained as source material (good), but
   nothing in the verdict distinguishes failed treatment from weak source,
   so the rebuild loop had no defect to fix. Compare the G2 fix loop, where
   one named defect produced one exact fix.

## Biggest prompt/system mismatch

**The system rewarded passing written gates, while the user asked for videos
a human watches to the end — and the two were never connected by evidence.**
Briefs specified 1080x1920, CRF 16, −16 LUFS, TP ≤ −1, exactly 135/75 card
frames, max 3 words per card. QC verified exactly those things, rigorously.
Nothing in the pipeline measured whether a human watched to the end, because
the delivered clips were never posted and no retention pull was ever run on
comparable posted clips. The gates are necessary (they prevent technical
rejection) but they are not a proxy for retention, and several gate-passes
coexist with disclosed creative weaknesses (late leopard at ~12s, 3.9s of
content, action-led "character" clip, absent protagonist). The mismatch is
not that the gates are wrong; it is that gate-passing was treated, in
delivery language, as quality, while the actual quality questions (does the
first 3 seconds promise what the last 5 seconds pay off? does the viewer
learn anything?) were answered only by the builder's own note.

Second mismatch, narrower: **scoped exceptions became the norm by
accumulation.** The 2.5s card (batch-5 v3, then batch-15 template), centered
captions (pilot-only), pillarbox pads (group-2, then group-3 Crow) each began
as a dated, scoped exception. Each was correctly flagged at the time. But no
rule ever expired an exception or forced a decision to adopt or retire it,
so the rulebook now carries parallel systems (see failure 3).

## Highest-value next test

**Post a small, controlled comparison the moment the campaign (or a
replacement campaign) allows submissions — do not build another 30 first.**

- 4 clips, same show family, same posting window, same channel, spaced with
  gaps: (a) one scene-led clip with paratextual brand (title + card only);
  (b) one VO-led clip with narrated brand ("inside the app" + card);
  (c) one scene-led clip with the caption system unified to Montserrat
  centered; (d) one repeat of an already-approved older clip's structure
  with fresh footage (control for channel/time effects).
- Measure: views at 24h/72h/7d, and, if Studio access allows, average view
  duration / retention at the card join. Pre-register the comparison before
  posting: the question is whether narrated brand and caption system change
  retention, not whether any single clip "did well."
- Cost: 4 uploads + submissions in one session each (30-min window rule);
  no new renders needed if held clips are used (pick from delivered
  batch-30/15 finals, noting their card lengths differ — that difference
  itself must be recorded as a confound, not hidden).
- Why this beats more building: it is the only proposed test that can turn
  the project's largest HYPOTHESIS (retention claims) into TESTED, using
  clips that already exist.

## What we should stop doing

1. **Stop treating a builder's self-QC "PASS" as a result.** Every pass in
   this project that mattered was reproduced independently. Self-QC is an
   input to QC, not a verdict.
2. **Stop quoting full-file audio bitrate, volumedetect card floors,
   mono-downmix true peak, or output-side `-t` loudnorm.** All four are
   retired methods (ledger entries 21–24). Any report still using them is
   wrong on arrival.
3. **Stop building a clip whose own scout says "drop first" without an
   explicit, recorded override.** B2 Primal is the case. A scout warning
   that is built anyway, silently, is worse than no scout.
4. **Stop accepting blanket verdicts ("not good") without one named defect
   per clip.** Ask for the defect before rebuilding. It costs one message
   and saves a rebuild cycle.
5. **Stop starting an upload run without a campaign-status check.**
   Pre-flight: campaign page status + submit-button state, recorded with
   timestamp, before the first upload of a run.
6. **Stop letting scoped exceptions accumulate.** Every exception gets an
   expiry: adopt, retire, or re-scope in writing before the next batch.
7. **Stop describing upscaled crops as HD, and stop describing 608-wide
   pillarbox strips as full-frame.** The honest wording already exists in
   the logs ("upscale of the crop, not native 1080 width"); use it in
   user-facing notes too.
8. **Stop claiming SFX come from "the existing SFX library."** No verified
   licensed SFX library was found on disk for C2/C3; the accents used were
   ffmpeg-synthesized. Name the actual asset and its license status.

## Coverage limits (read this before reusing the report)

- Files re-read in full for this debrief: `CLIP_RULES.md`,
  `NEVER_REPEAT_RULES.md`, batch-30 brief + coordinator log, batch-15
  assembly log + both execution scripts + queue note + group-A scout
  package (full) + group-B/C packages (weakest-point and window lines),
  T-draft rebuild notes, edit-3 review, pilot review, C2/C3 QC reports,
  Drive survey inventory (head + counts).
- Not re-read for this debrief: batch-5/batch-6 per-clip QC reports,
  batch-15 set-1/set-2 QC reports (summarized in the assembly log, which
  was read), per-group NOTES.md files (summarized in the coordinator log),
  and the upload manifest (spot-checked for submission totals only).
  Findings about those batches rest on the logs/manifest, not on a fresh
  read of their QC files.
- Analytics figures (approved 3, rejected 9, pending highs) are carried
  from the prior session's manifest and Studio reads, not re-pulled today;
  the campaign is paused and no new analytics were fetched for this
  retrospective.
- No viewer, no listener test, and no second model was consulted for this
  debrief. "Parent verification" below means the main agent's own
  independent re-measurement and frame checks, not a human review.
