# Open questions — RexTrix editing debrief (2026-10-30)

Distinguished as requested: **needs a human judgment** (a person must
decide; no file or test decides it), **needs source evidence** (a file,
frame, transcript, or show must be found), **needs technical testing**
(a tool, method, or environment check), **needs actual analytics**
(posted clips + retention/view data).

Nothing here is a task to execute now. This debrief was read-only; the
items below are the questions a next session should pick up, in rough
priority order within each class.

## Needs a human judgment

1. **Gun rulings (batch-30 group 5):** drop `g5_redundancy_redundant`
   (gun to temple ~6.4s, holder off-frame, plus a seg1 scratch/blood
   trace), keep `g5_prequel_aegis` (handgun close-up as closing image),
   drop both, or keep both? If redundancy is dropped, is the unbuilt
   Prequel-Adrift fallback (294.32–310.96s) to be built? Asked
   2026-10-30 ~00:37 PKT; unanswered.
2. **Family-safe rulings (batch-15 held 3):** Crow-Ash (child/teen
   protagonist + rope-restraint imagery), Reaper (featureless chrome
   mannequin nudity, non-sexual), Rat King (dark red fluid among rat
   swarms reading as blood) — keep or drop each? VOs are recorded and
   ready if cleared. Asked 2026-10-29 21:19 PKT; unanswered.
3. **Blur-pad echo bar:** phone-scale illegibility vs frozen-still
   zero-decipherable-echo for blur-fill clips (G3 Crow precedent)? The
   choice decides whether blur-pad clips pass at all.
4. **Caption-system unification:** one system for the next campaign, or
   per-template systems kept deliberately (Montserrat centered vs
   DejaVu lower-third vs pillarbox pads; 4.5s vs 2.5s cards)? Includes
   expiring or adopting each scoped exception.
5. **Ledger severity tiers:** tag NEVER_REPEAT entries as
   COMPLIANCE/SAFETY, MEASUREMENT, or CRAFT (debrief proposal F-23)?
   Content unchanged; only the enforcement tier is decided.
6. **Warning-template batch count:** not specified by the user (queue
   note: "Do not assume 15"). Confirm before cutting.
7. **T2 fallback decision:** scout SBE-07..13, rebuild T2 as
   Toilet-vs-Strawberry split from held material, or wait for the user
   to supply the show name? (See also source-evidence items.)
8. **Next-campaign pick:** Backyard Breaks / ForgeGUI / Call of Duty
   MW4 / another campaign from the shortlist — and, after joining, the
   rules read to confirm AI clips are allowed before any clip work.
9. **Clip 1 settlement (after resume):** late/manual submission via
   campaign moderators vs re-upload + fresh submission for
   `iJNXlOHq8Dc`? Do not re-upload without user instruction.
10. **Moth-city vs dontfeed overlap:** `g2_feed_moth_city` and
    `c15_a2_dontfeed` share the same source window (196–220s) — only
    one treatment should be uploaded. Settle before either's turn.
11. **G4 divorce_prison optional +1.4 dB lift, G6 head trims (chase
    frame 0, night frames 0–2), B5 optional "App." card drop:** small
    fixes offered, none required; user decides strictness per item.
12. **Vault separation:** re-save aze's password under aze's username
    so two google.com logins exist (browser will then ask which login
    to use at sign-in — expected behavior)?

## Needs source evidence

13. **T2 top-panel show identity:** the kitchen trio (blonde teen girl
    in grey hoodie, plaid-shirt man, apron woman) + bedroom shot +
    "daughter. You want a plan." — which show and episode? Both title
    candidates eliminated; SBE-07..13 unchecked; no other candidate
    queue exists.
14. **SBE-07..13 contents:** do any of them contain the T2 kitchen
    scene? Requires downloading + full transcript + frame scout of 7
    files (same Swapped folder).
15. **Second-wave shows:** 14 shows held from the Drive survey
    (Homebound, Four Shields, Odysseus, Reaper, Rat King, Curse of
    Eclipse Wind, Dreams, TAKE OVER EARTH, Kill the Mafia King, Star
    Survival, NULL ANGEL + II, When the Islands Fall, Across the
    Forbidden River, Fabled Twin Stars) + 7 check-first folders —
    unscouted. Any next batch drawing from them needs ep1 scouts first.
16. **7 rejection screenshots for Emy:** Emy asked (Oct 29) for "a
    screenshot of the flagged" for the 7 bot-activity rejections. Pull
    from the Content Rewards submissions pages; sending needs user
    approval (support-message rule).
17. **Submissions-count reconciliation:** manifest 87 vs dashboard
    108→109 clips / 93→94 Pending during the pilot upload. Needs a
    RexTrix-filtered re-read of the submissions list; do not quote a
    new total until reconciled.
18. **Chain-edit verifications:** D2/D3/D4 chain edits unverified
    (public pages do not show related videos); clip-1's chain re-point
    unconfirmed. Needs a Studio-side check, not a public-page check.
19. **Batch-5/6 per-clip QC reports:** exist on disk, not re-read for
    this debrief. Any claim about them beyond the manifest should be
    re-verified from those files first.

## Needs technical testing

20. **Duck-ratio verification method:** can stems + mix recipe archives
    (debrief rule R-08) actually verify a finished mix's duck ratio?
    Test on one already-built ducked clip by reconstructing from its
    stems (if archived) or declare the method unproven.
21. **Whisper environment fix:** verify faster-whisper in the exact QC
    environment, or install openai-whisper there, and record the result.
    Do not assume scout-env availability transfers (F-12).
22. **Muted-viewing check (R-12):** run a muted pass on 3 VO-led clips
    and check whether any caption decision changes as a result.
23. **VO listening check (R-07):** listen to all 15 batch-15 VOs +
    pilot VO pre-assembly style and record whether any delivery issue
    (tone, pacing, brand pronunciation) was found that Whisper missed.
24. **Machine-readable clip index (F-22):** build `clips.json` for one
    batch (clip → source window → VO → music → card → script → QC →
    hash) and verify one revision can be located from the index alone.
25. **SFX asset list:** replace the "existing SFX library" phrase with
    a verified list (synthesized accents + any newly licensed files
    with license terms); verify each path exists.
26. **End-card length as house vs campaign rule:** confirm from the
    campaign rules doc whether card length is campaign-specified at
    all; if it is house-only, record that so future deviations are
    judged at the right level.
27. **Fish Audio status re-test:** before any Fish re-run, test with a
    small call (credits may have been topped up since the 402s); do
    not assume the 402 persists, and do not assume a top-up happened.

## Needs actual analytics

28. **The section-13 comparison (highest value):** 4 clips, same show
    family, same posting window, same channel, spaced with gaps:
    scene-led paratextual brand vs VO-led narrated brand vs unified
    caption system vs a control repeating an approved older clip's
    structure with fresh footage. Pre-register the question (does
    narrated brand / caption system change retention?) and measure
    views at 24h/72h/7d + average view duration / retention at the
    card join if Studio allows. Blocked until a campaign accepts
    submissions again.
29. **Viral vs professional captions:** does the pilot's centered
    Montserrat system retain differently from the professional
    lower-third/pad systems? No view data on record separates caption
    system from clip, channel, and posting time. Needs the comparison
    in (28), not a new claim.
30. **Hook-first vs template arc:** does the batch-30 hook-first
    structure retain differently from the batch-15 VO arc? Same
    confounding as (29); same test.
31. **Posting-window causality:** does the 10 PM–1 AM PKT window cause
    higher views, or is the dead-hours pattern explained by age +
    channel? Needs an in-window vs out-of-window comparison on the
    same channel at comparable age, with the disproof condition
    pre-registered (an in-window Cinema clip at comparable age drawing
    ~10–20 views disproves the window as the main cause).
32. **US-audience effect:** does the 40%+ US audience rule, chaining,
    or related-video linking measurably change US share or views?
    Needs Studio traffic-source reads on posted clips (offered before,
    never taken up).
33. **Bot-activity trigger:** support will not disclose flag metrics.
    No analytics on record can identify the trigger. The only honest
    routes are a support disclosure (unlikely, per Emy) or a controlled
    comparison the project has no ethical way to run (it must not test
    by buying views or botting). Record as UNKNOWN unless disclosed.
34. **Pending-clip 500-view watch:** highest pending at last full read
    (2026-10-28): 263 views (t6CBgAalVWo), then 169, 145, 118, 103.
    Any crossing 500 becomes recording-eligible under the user's rule
    (only 500+ clips); check on the next Studio read, not from memory.
35. **Swiss payout check:** campaign ended 2026-10-14; payout check was
    due Oct 24 and is tracked by the swiss-view-monitor cron (latest
    run 2026-10-30: total 4,073 views, eligible rows 2,630, no crossings).
    Still open as a payout question, separate from RexTrix editing.
