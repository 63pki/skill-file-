# RexTrix — unresolved questions and proposed checks

No check below was executed for this debrief. Proposal is not permission to render, call a provider, publish or buy anything. Prior conditional permissions are not expanded by this list.

## Needs source evidence — resolve before consequential C04 editing

1. **Highest-value dependency: B08 source80–104s.** What are the complete camera remark and conditional ending, complete command and explicit referent/qualifications, and following response/overlap? The saved model answer fails the third question and cannot independently certify the first two. Obtain reliable listening/transcription/annotation against the existing source excerpt. If onset/completion lies outside it, identify the needed handle before any expanded inspection. [F10–F11]
2. **Cloudwhale source23.7–27.6s versus v02 output~1.333–2.333s.** Does the omitted24.2–27.033333 shot/sound remove words or necessary context? Determine whether restoration is needed, not whether more footage is automatically safer. A new restoration export would be a separate action. [F17]
3. **P02 source28.133333–45.2s plus boundary handles.** Actual wording/speakers, opinions/weld dependency and reaction completion remain unverified; the zero-lag checks do not answer this. [F02–F03,F12]
4. **Campaign rights/provenance:** Are exact supplied story assets, characters/likenesses and embedded sound/music cleared for this use? Is identified story-spotlight treatment accepted as meaningful contribution, and is current app availability relevant/confirmed? Access/download permission and a logo do not settle these. [F06]
5. **Recovery assets:** Recover C01 MP4/hash/QC/EDL/graphics, batch source register/slate/checkpoint and the historically adopted PEBv1.3.2 package. Current absence is not proof of permanent loss. Do not reconstruct a production EDL from incomplete code snippets. [F01,F23]

## Needs human editorial judgment

1. After B08 sound is reliable, does C04 fairly compare framing versus categorization, or do qualifications contradict the premise? A quiet creature is not proof of harmlessness or an unjustified order. Stop the concept if contradicted; do not delete the qualification. [F10]
2. Does P03v01’s disclosed city-detail question create worthwhile anticipation, or does its static entry/long approach add friction? Is v02’s moving entry preferable once sound is safe? Saved images support questions, not audience preference. [F04–F05]
3. Does P02’s delivery make the local joke sufficient with minimal graphics? A restrained scene may be valid even though it is not a demonstration of elaborate authorship. [F03,F26]
4. Once C01 is recovered, does its authored scale observation add enough versus the source alone? Compare clarity/contribution/finish, not a subjective numerical score or tool count. User retained it as a candidate. [F09]
5. What truthful motivation connects each discovery/joke to RexTrix beyond mandatory attribution/card? A real product demonstration is one optional route, not a requirement invented by this editor. [F06,F08]
6. Are the actual encoded native mixes intelligible on phone/headphones, and do transitions sound intentional? Quiet measured loudness is not itself an audible failure. [F21]

## Needs technical testing — only under later applicable authority

1. **Offline semantic validation:** Feed the saved B08 answer into a validator that distinguishes required response coverage from parse success; reject repeated command as response/overlap evidence and scalar time as a requested span. This can be tested without media/provider upload. Do not force every valid free-form answer into the same schema. [F11]
2. **Fresh-session recovery audit:** Resolve relative paths/hash records, current manifest supersession and missing-file handling in a clean workspace; do not inherit tests merely from package labels. [F19,F23]
3. **Vision module:** The inherited dedicated negative V2 fixture is unavailable/not passed; hook instruction following and timestamp precision also need distinct evaluation. Any future provider invocation requires scope/budget; a second model is not automatic ground truth. [F20]
4. **Narration route:** Content was approved for one specific pilot, not a new provider or batch. Confirm an actual available authorized TTS implementation and conditions before generation; then assess the rendered line’s pacing/pronunciation/emotion/ducking. Proposal pricing is historical, not actual spend or current quote. [F22]
5. **Landscape adaptation:** C02–C04 source-screen/two-subject phone legibility was unresolved at plan stage. Test only the chosen method if that concept proceeds, not a whole motion/alpha catalog. [F10,F19]
6. **Actual release preview:** Platform safe areas, actual audio perception/full English speech and burned-in-text eligibility, final encoded loudness/true peak where required and rights/claims approval remain open. Technical file decode is not release clearance. [F17–F18,F21]

## Needs actual analytics — not inferable from existing private exports

- No matched views, reach, retention, watch time, completion, rewatch, CTR, install conversion or audience geography exists for these private files. Other uploads described in the brief are not treatment evidence here. [F25]
- If later publication/comparison is authorized, predeclare one changed variable, exact versions, same observation age, exposure/account/audience context and real metric denominators. A comprehension test can precede distribution but cannot substitute for audience behavior.
- Unknown distribution or audience effects could explain any eventual low views. Do not convert an observed association into a causal editing claim or a universal template rule.

## Decision order, not an execution plan

Source sound/premise → editorial judgment → only the missing implementation/test → one authorized output → actual-file review → separately approved distribution/analytics. Stop when the current question is answered; do not automatically produce C04, restore Cloudwhale, render the batch or rewrite the prompt.
