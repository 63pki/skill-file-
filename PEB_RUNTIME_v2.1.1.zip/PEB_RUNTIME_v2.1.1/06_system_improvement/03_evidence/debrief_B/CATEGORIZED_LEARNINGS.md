# RexTrix — categorized editing learnings

## 1. Evidence method and boundaries

**OBSERVED:** This debrief examined existing project briefs, plans, render decisions, saved decoded pictures, QC results, prompts, sanitized model final answers/receipts, package records and bounded conversation history. Four locally present creative MP4 hashes were recomputed against their respective QC records; all matched. B08 original/excerpt/video-proxy/audio-proxy hashes also matched. No new encode, extraction, listening, ASR, model call, provider upload, installation, publication or platform preview was performed. Saved P03v01/v02 storyboards, P03v02 phone opening and P02 actual-tail sheet were visually re-inspected. [F01, F23–F24; index identity cross-checks]

**Important distinction:** “OBSERVED” can mean a file contains a claim, not that the claim’s underlying event is true. “Model returned a fall” is observed; “the vehicle fell” is not. Historical assistant claims about absent C01 media are weaker than current-file evidence. “TESTED” below refers to an existing bounded test, never a newly executed one. Root causes are hypotheses unless independently demonstrated; the ledger labels their status separately.

**UNKNOWN:** There was no new continuous picture-and-sound audition, human transcript, campaign release decision or matched audience analytics. “No evidence” is not a failure verdict on the material. Legacy package/builder results are attributed, not claimed as this editor’s own tests.

Every material finding has a structured ledger entry with project, references, source/output times, what happened, consequence, uncertainty, root-cause certainty and disposition. This document groups those findings rather than repeating all28 cards. Relative evidence paths and hashes are in `EVIDENCE_INDEX.json`.

## 2. Actual scope, outputs and tools

### Assignment and audience
**OBSERVED:** Initial work was Mode B intake/source inspection and one pilot proposal using PEB_PORTABLEv1.1.1, not a permission to build a general engine or publish. The brief sought app installs through a bio link and qualified adult attention:18+ and accounts with at least40% US audience. Later explicit work included bounded source inspection, P02/P03 private drafts/revisions, a separate narration pilot proposal, then ten distinct private batch concepts with one calibration export before scaling. The batch objective was intentional top-of-funnel entertainment/discovery, not fabricated product testing. [F01, F22, F27; `PROJECT_RECORD.md`; brief§1; history2162]

**OBSERVED:** Recorded prompt lineage is preserved core v3.1.1/test-freeze within PEB_PORTABLEv1.1.1; later PEB_CONTINUITYv1.3.1 consolidated rules were adopted. History later names v1.3.2/CREATIVE_TREATMENT_GATEv1.0 for substantive creative resets/batch planning. That later package is absent now; it is not silently replaced by v1.3.1 or claimed to have been freshly audited. Archived packages are references, not evidence this editor executed their historical campaigns. [F19, F23, F26]

### Compact output inventory
| Project/version | Mechanism and state | Actual range/duration | Evidence limit |
|---|---|---|---|
| P01 “The husky detail” | Proposed recognition replay/callout; rejected before creative export | SRC01~6–15.6s plus proposed~2s replay | Picture samples; comic/audio relationship unresolved |
| P02 assembly / “The last connection” | Paper compression of practical end state; superseded | Proposed source30.133333–34.633333 +40.033333–49.933333 | Never exported as that assembly cut |
| P02 private original | Dialogue-led continuous scene plus card; delivered | Source28.133333–49.933333;26.300s/789frames | Technical QC; no human speech or campaign pass |
| P02 revision02 | Same scene ending at visible response; delivered | Source28.133333–45.2;21.566667s/647frames | Native picture endpoint remains speech-provisional |
| Cloudwhale P03v01 | Disclosed later city-detail question→continuous reveal/reaction; delivered |2s still +source25–43.433333 +4.5s card;24.933333s/748frames | Static teaser/long approach concern; no audience result |
| Cloudwhale P03v02 | Moving route→compressed native reveal/reaction; delivered |[22.366667,24.2)+[27.033333,43.433333);22.733333s/682frames | Join at output1.833333s speech-unverified |
| Cloudwhale narration B | Editorial observation “The whale isn’t the whole reveal”; approved single-pilot content, blocked at route | Proposed source36.4–43.433333 +4.5s card;11.533s | No TTS invoked, no VO export, permission unused |
| Batch C01v01 “The scale trick” | Specific framing observation→native relative-size reveal/reactions; historically delivered | B04source75.7–93.433333;22.233333s/667frames | Media/full checkpoint absent locally; no fresh C01 inspection |
| Batch C02–C10 | Nine further development concepts, not nine finished drafts | Candidate ranges only | Conditional speech/crop/ending checks; C10 narration route/permission missing |
| C04 “The image versus the order” | Order-first comparison storyboard; approval conditional | Candidate~82–102s; focused source check80–104s | No render; response/overlap still unresolved |
| B08 source-review excerpt | Review asset with synchronized scene sound, not creative output | Source80–104s;24s | H.264/AAC re-encode, disclosed in provenance |

**OBSERVED:** That is five historically evidenced creative export versions across three concepts, not five distinct successful campaigns. Four export files are currently local. Synthetic timing media, source-review excerpts, catalog previews and unrendered storyboards are excluded from the count. [F01]

### Inspection breadth and modalities
- **OBSERVED:** Initial SRC01 used5-second source samples, denser6–18s and tail checks. Round2 sequentially decoded SRC01/02/03 and inspected2fps sheets/native cut neighbors; this was not continuous perception or listening. Complete source durations were about60.3s each. Initial audio checks were decode-only; no installed local Whisper/Vosk route was found in the recorded check. [source inspection JSONs; `review_round2/CANDIDATE_REVIEW_AND_P02.md`]
- **OBSERVED:** Existing joint AV calls later covered SRC01/SRC02 complete episodes plus focused contexts; SRC03/P02 used a23.8s excerpt. Selection pass02 sampled three new sources for exactly180 distinct seconds;24s NEW01 follow-up repeated already-inspected content, not extra distinct footage. Cloudwhale originals extend beyond those60s samples; no whole-episode AV claim is justified. [F12–F14; `selection_pass_02/PASS_RECORD.json`]
- **OBSERVED, historical coverage claim:** Later batch plan records12 additional sources: eight longform stories sampled every12s, four later Cloudwhale episodes every4s, focused windows every2s and denser C01 boundaries. This is sparse visual breadth, not complete dialogue/story understanding; complete source-register/contact-sheet files are absent now. [history2469/2565]
- **OBSERVED:** Final B08 check used only source80–104s. Provider received complete aligned silent video and corresponding16kmonoWAV in one request. Embedded MP4 soundtrack ingestion remained untested. [F11, F24]

**HYPOTHESIS:** The problem was not simply “inspect more.” Relevant sound was too shallow for dialogue-dependent choices, while successive summaries added less than a reliable narrow check. **UNKNOWN:** No time/effort log establishes excessive total inspection or its opportunity cost. A12-source sparse survey can be appropriate for scouting; it cannot lock utterances. [F02, F13–F15, F28]

### Tools actually used versus listed
**OBSERVED:** Project evidence supports FFmpeg/ffprobe7.0.2-static, Python, Pillow13, OpenCV, NumPy, fontconfig/installed Arial, local hashing/JSON/ZIP utilities, public HTTP source/rules retrieval and the NVIDIA chat-completions adapter. The original project record also has Notion save/update receipts; no Notion content was modified for this debrief. The tool inventories were read, not all executed. [F19; `routing.json`, `development_p02/environment.json`, project receipts]

**OBSERVED:** HyperFrames/20HTML styles, Lottie, NullMotion, CAP19/SR40 caption styles, legacy ASR/OCR/alpha pipelines and ElevenLabs were references, conditional routes or unexecuted proposals here. No animation/TTS/caption engine gets a feature-tested claim from being in the registry. The new vision module was reported INSTALLED in the inherited package; fixture INCOMPLETE_NOT_PASSED. [F19–F20]

### Permissions and blockers
**OBSERVED:** Approval evolved by named action: read-only inspection; bounded fixture/development; individual private provisional exports; one Cloudwhale narration exception; later batch development/one calibration; conditional C04 comparison. Posting/submission/accounts, new provider, installation, paid service and unapproved uploads did not follow automatically. Original sound was the default, not a universal VO prohibition. C04 native-dialogue reordering still had to preserve event/utterance meaning. [F15, F22, F27; histories2087/2162/2628/2652]

### Strongest and weakest examples
**OBSERVED choice, not a rating:** Of the currently recoverable outputs, **P03v02 has the strongest documented technical/editorial finish**: integrated moving entry, restrained attribution, visible creature→city→native response, intact image mapping and preserved audio tail. It is the most reviewable continuation candidate, not proven best-performing or sufficiently original. Its speech splice remains unresolved. [F05, F17]

**OBSERVED choice:** **Original P02 has the clearest supported edit-specific weakness**: after the visible smile,4.733333s of hook handling started another physical beat. The revision removes that tail. **HYPOTHESIS:** This is a stronger comic ending; the unverified sound could still justify some of the tail. It would be wrong to call hook handling intrinsically weak—the assembly concept specifically needed it. [F02–F03]

**UNKNOWN:** C01 cannot fairly be ranked from new viewing because its export is missing locally. Its historical opening is more specific than a generic hook, but its review acknowledged source-led structure, an exaggerated/blurred reaction and abrupt silent ending. No strongest audience performer is identifiable. [F09, F25]

## 3. Creative development and source understanding

### How “what the video is about” was chosen
**OBSERVED:** P01 began with a distinctive husky image; the “recognition aid” rationale came after selecting it. P02 then selected a bounded mechanical end state from sampled picture evidence. Later provisional words reframed it as character banter. Cloudwhale’s question was explicitly built around an already-inspected city/creature reveal. C01’s cinematic-craft audience angle was written around selected macro/human-reference footage; no independent audience study preceded selection. [F02, F04, F07, F09; original plan/reassessment/history2469]

**HYPOTHESIS:** Source-led discovery is not inherently a flaw, but recording the audience insight afterward can rationalize a convenient scene. The missing discipline was testing whether the selected scene supports the claimed reason to watch—not requiring an abstract audience insight before anyone may browse footage.

| Serious concept | Opening promise | Actual supported payoff | Context that had to survive | Editorial contribution beyond the source |
|---|---|---|---|---|
| P01 husky detail | Notice an incongruous mouth/object detail | Detail already visible for seconds | Unknown dialogue/object function; no “dog drives” inference | Proposed replay/leader; ultimately redundant and unrendered |
| P02 assembly | A small task reaches its depicted end state | Hands withdraw, hook/cable arrangement remains | Dialogue may explain/reframe work; no repair-success claim | Proposed compression/omission; suspended when comic dependency surfaced |
| P02 comedy | Tools/measurement exchange develops into personifying tools and weld callback | Model-supported callback plus visible smile | Opinions setup, response, qualification and necessary reaction | Focused excerpt and later tail removal; source supplies joke/acting |
| P03v01 | “What is this city built on?” | City visibly belongs on the creature | Disclosed later detail; approach/reaction; no solved mission | Selective crop, question and teaser/reveal information order |
| P03v02 | Moving pilot/strange route invites discovery | Creature→city relation→response | Native action/speech dependencies and chronological sound | Moving entry, one omission, modest provenance; most structure source-owned |
| C01 | “A close-up can hide the scale.” | Human/ladder gives relative size, followed by source reactions | Complete captioned scenes and actual audio endpoints | Specific visual framing observation, not measurement or original animation |
| Narration B | “The whale isn’t the whole reveal.” | City appears after immediately showing the whale | Whole retained utterances/reaction; no fake answer withholding | Proposed editorial observation and major approach removal, never auditioned |
| C04 | Categorical order versus camera image | Contrasting framings, then native recipient response | All qualifications, referent, following speech, event relationship | Proposed command-first order and motivated two-view comparison; conditional |

All table entries are **OBSERVED plans/picture evidence**, except exact comic/dialogue meanings which remain **model-returned provisional claims**. Times and refs are in F02–F11/F22; no promised result is upgraded by the table.

### Brand role, source ownership and rejected possibilities
**OBSERVED:** The truthful connection supported here is supplied RexTrix campaign story provenance. Cinematic footage and fictional screens did not establish an app input, generation process, personal test, playability or current in-app availability. No real product demonstration was produced. [F06, F19, F22]

**HYPOTHESIS:** A distinctive story spotlight could motivate app discovery; its persuasive bridge was not established by a download card. The campaign’s meaningful-contribution requirement is separate from whether a clean scene is enjoyable. Adding effects cannot settle either question.

**OBSERVED correction challenging earlier reasoning:** SRC02’s gap reveal did not need a successful crossing to be a local suspense payoff. The earlier “incomplete escape” concern risked rejecting a valid scene. The later record recognized that correction. Similarly, SRC01’s redundant dog replay was a failed treatment, not proof that the hammer joke or source was poor. [F07–F08]

**OBSERVED:** Titles/episode adjacency helped choose where to inspect, but the records explicitly rejected inferring repair causality from adjacent episodes or object function from names. **UNKNOWN:** Selection bias from titles/thumbnails is not experimentally excluded. The more demonstrable bias was source/model-summary anchoring: initial P02 was about assembly before sound; the SRC02 model invented a fall. Those claims were not adopted as proof. [F02, F12–F13]

### Where the workflow became excerpt→line→card
**OBSERVED:** P02’s delivered versions are essentially chronological scene plus card. P03v01 added a teaser/question but retained the source approach; v02 removed the slide and one shot. C01 added a specific opening observation to a continuous source scene. The operator explicitly requested a contrasting calibration after C01, not cosmetic changes. [F03–F05, F09, F26]

**HYPOTHESIS:** Our implementation comfort zone narrowed authorship. **Counterweight:** Continuous scene-led comedy or a slow reveal can be the right choice. P02’s complete exchange/reaction and P03’s uncaptioned payoff are examples where restraint protected source performance. The error would be claiming those restrained versions had demonstrated originality, persuasive brand integration or audience success—not merely making them restrained.

## 4. Template and story-structure learning

**OBSERVED:** These are the methods actually proposed, implemented or exported. A reference recipe is not treated as an exported template test.

| Method | Information mechanism; source suitability | Assets/permissions | Implemented vs actual demonstration | Failure mode / future boundary |
|---|---|---|---|---|
| Detail replay + static leader, P01 | Makes a missed detail newly legible; unsuitable when already held clearly | Source frame/replay sound continuity; original-audio scope | A06-style recipe consulted; no creative export | Redundancy, duplicated dialogue; require a specific missed fact, not mandatory replay |
| Chronological process compression, P02 paper | Removes intermediate material to expose an end state | Accurate action/utterance map; no fictitious repair claim | Paper EDL only; two-piece assembly cut not rendered | Conversation was meaning-bearing; establish sound before omission |
| Scene-led dialogue comedy, P02 exports | Setup→response→callback→reaction | Corresponding native sound, complete exchange, official card | FFmpeg contiguous trim/card implemented; actual QC supports mapping | Source owns joke; do not pad with unrelated work or claim engineering proof |
| Mystery/detail-first, P03v01 | Restricts framing, asks a concrete question, later reveals relationship | Source40s still crop; disclosure label; native audio; static graphic |60frame teaser plus553scene frames exported; image readable in saved phone views | A poster-like opening and inherited long wait may weaken anticipation; not a universal still ban |
| Moving chronological discovery, P03v02 | Orientation→anomaly→discovery→response | Frame/sample map, omission permission, sound semantics, attribution | Two-segment graph exported; picture/audio tail mapping checked | Numeric continuity does not establish the omitted utterance is dispensable |
| Specific visual observation, C01 | Human reference corrects macro scale reading | Native captions/audio, opening panel, portrait source, card | Historically exported once; current media absent | More specific than generic text, but still source-led; contribution not proven by a hook |
| Narration-led editorial opening, B | Whale is not the complete reveal; city completes argument | One scoped VO exception + working authorized TTS + preserved utterances |11.533s storyboard only; one TTS option proposed | Cannot judge voice/delivery without audio; no silent text substitute or automatic batch exception |
| Order-first comparison, C04 | Reorders evidence and categorization; pairs real views then restores response | Reliable complete dialogue, exact source labels, phone-readable enlargement; no added audio | Storyboard approved conditionally; no comparison export | Misleading chronology, recorded-status labels, shared-knowledge inference and omitted qualification |
| A12-inspired logo/CTA card | Makes a required action readable | Real retrieved logo, exact copy, installed font and measured hold | Pillow PNG + exported135frame holds | A compliance mechanism, not narrative payoff or originality evidence |

**OBSERVED:** P03v01’s crop/question genuinely changes what information is initially available; P03v02’s omission changes timing; C01’s observation changes the viewing frame modestly. Attribution/card changes identity/action communication, not story causality. No decorative animation was implemented to claim deeper understanding. [F04–F06, F09–F10, F18]

**UNKNOWN:** No “viral template” in the consulted catalogs or supplied-reference claims is backed here by matched original post/analytics evidence. None can be called a million-view mechanism. No genuine product test, transformation demonstration, before/after, completed split-screen comparison, reaction transplant, forced loop or motion-heavy production was exercised. These methods should remain available when source/permissions warrant them; their absence is not failure evidence. [F19, F25]

## 5. Concrete robotic-editing diagnosis

| Symptom | Evidence status and example | Likely mechanism / consequence | What is not established |
|---|---|---|---|
| Repeated source-led packaging | **OBSERVED:** P02/P03/C01 all rely heavily on native scene entertainment [F26] | **HYPOTHESIS:** easiest safe graph became default; distinct sources can mask structural sameness | No audience metric proves repetition hurt performance |
| Long inherited setup | **OBSERVED:** P03v01 question at0–2s, decisive city relation~16–17s [F04] | **HYPOTHESIS:** added question waits through much of original approach; anticipation may decay | Slow buildup is not inherently bad; no timed comprehension/retention test |
| Redundant aftermath | **OBSERVED:** P02 original hook-handling output17.066667–21.8s [F03] | Another physical beat follows visible comic response | Sound may still require context; no claim the source action is bad |
| Abrupt advertising ending | **OBSERVED:** P03 visible response hard-cuts to black download card; C01 historical review similarly flags it [F06,F09] | Story payoff and app request have only provenance between them | No install effect measured; card itself is required |
| Native blurred/exaggerated reaction | **OBSERVED as historical review:** C01 around output12–14s [history2565] | Source-baked motion/style, not added editor shake/zoom | Actual artifact type and current full-resolution defect not re-inspected |
| Overclaiming labels | **OBSERVED:** C04 FIELD RECORDING/EARLIER labels required correction [F10] | Editor language could turn inference into fact | Proposed only, not a delivered false graphic |
| Fake certainty in AV results | **OBSERVED:** impossible times, inferred speech absence, repeated B08 response [F11–F14] | Confidence/valid JSON can substitute for meaning checks | Source dialogue is not disproven just because model is unreliable |

**OBSERVED absence in the accessible rendered plans:** No added VO, external music/SFX, beat-zoom barrage, shake/flash transitions, blind per-word caption animation, artificial loops or repeated reaction transplant. P03v01’s declared still is intentional, not an accidental freeze; black cards are intentional, not missing pictures. P02/P03 are portrait originals, not blur-padded landscape. [EDLs/filter graph; F18–F22]

**UNKNOWN rather than invented fault:** Robotic pronunciation/emotion, audio masking, clicks, clipped syllables, all-frame generative artifacts, sound-transition quality and source subtitle accuracy were never fully auditioned. Those cannot be listed as confirmed defects. Liking a quieter/cleaner style is taste; unreadable detail, false chronology or unverified speech would be different problems.

## 6. Picture, motion, graphics and captions

### Composition and source constraints
**OBSERVED:** IceRoad sources were1080×1920; Cloudwhale01 was720×1280/30fps. Upscaling it to1080×1920 does not add detail. The P03v01 city crop was720×660 source pixels, enlarged1.25× into a900×825 panel, equivalent to300×275 at360px phone width. It was not aggressively cropped to full-screen portrait. P03v02 uses the native portrait picture plus a lower-left attribution for105frames. Saved phone opening shows route/face with no label over the face. [F04–F05; opening layout; EDL; `phone_frame_000.png`]

**OBSERVED:** C01 was also a full-portrait source treatment in its historical records. C02/C03/C04 had unresolved landscape/two-subject or prop-screen readability issues at plan stage. **UNKNOWN:** No landscape-adaptation export here demonstrates that a safe crop, enlargement or split screen succeeds. Therefore there is no supported claim of an exported “excessive blur-padding” failure. [history2469/2625]

### Effect removal test
| Used/proposed treatment | What viewers would lose if removed | Boundary |
|---|---|---|
| P03v01 selective city crop/question | Specific prediction and selective withholding of creature relationship | **OBSERVED mechanism; HYPOTHESIS value.** Removing it may improve entry or lose useful framing; not settled |
| P03v01 “Later in this scene” | Explicit disclosure that the detail is a later shot | **OBSERVED honesty function.** Do not remove disclosure while retaining potentially misleading reorder |
| P03v02 attribution backing | Phone contrast and source/product identification | **OBSERVED identity function.** It does not explain app features or fix story pacing |
| C01 four-second opening panel | Qualified scale-reading lens and early attribution | **Historical OBSERVED plan/export claim.** Human reference remains in the source, so basic scene survives |
| Actual logo/CTA card | Required brand/download instruction | **TESTED mandatory function**, not an artistic need in every campaign |
| P01 replay/leader | Nothing clearly new in the inspected source | **OBSERVED reason to abandon proposal**; a truly missed detail would differ |
| C04 comparison/enlargement | Explicit contrast and phone legibility of actual prop image | **HYPOTHESIS**, not exported; use only if dialogue supports the relation |
| ROAD/WHALE/CITY pointers | No established extra information beyond visible objects | **OBSERVED removal instruction**; never an exported tested benefit |

### Typography, timing, captions and color
**TESTED narrowly:** End-card artwork initially failed clearance at60px type;56px fit. Exact English copy/em dash glyphs, bounds, conservative safe envelope, contrast and phone previews were checked. Logo geometry was preserved through blank-margin crop/proportional scale. Full encoded135frame holds were checked; no entrance/exit shortened readability. This supports the exported card, not a universal font/word-count rule or actual platform UI masking. [F18]

**OBSERVED:** No speech captions were authored for P02/P03. C01/B08 have relevant source-baked English-looking subtitles in historical inspection; they were not retyped or promoted into verified transcripts. C01’s authored panel was scheduled to disappear before native dialogue-caption scenes. **UNKNOWN:** Heard-word agreement, referents, emphasis and full English eligibility remain unverified. If future added captions are used, they need verified words, phrase grouping and source→output mapping; seeing English text does not prove English audio. [F09, F11, F21]

**OBSERVED:** No animated easing/hierarchy system was exercised. Motion came from native imagery; graphics were static. Proposed comparison labels had an information role; decorative timing/easing rules would be unearned here. Core caption presets remained references. No evidence supports “three words always” or “zoom every1.5s.” [F19, F26]

**TESTED/OBSERVED scope:** Used FFmpeg graphs explicitly converted still/full-range artwork toward limited BT.709/yuv420p and tagged output. Lossy static-card pixels varied slightly; that was recorded, not called pixel-identical. P03 graph verifier initially assumed1/30 checksum timebase; it was corrected to actual1/1000000 without repeating FFmpeg processing. **UNKNOWN:** Tags do not certify signal color, there was no colorimeter/platform display test, and no alpha-intermediate compositor failure was demonstrated. The attribution overlay used alpha, but a general alpha pipeline was not feature-tested. [development reports/graph checks; F16,F18–F19]

## 7. Audio and narration

### What was actually verified
- **OBSERVED:** Listening was unavailable to the editing agent; no human audition of delivered files is recorded as passed. Decode/nonzero streams, waveform mapping, known synthetic markers, packet continuity and selected loudness measurements were performed. Local ASR was not implemented. NVIDIA joint/audio-only analyses were provisional semantic evidence, not hearing by this agent. [F12,F17,F21]
- **TESTED narrowly:** P03v02’s six saved waveform windows correlate at least0.99966 at measured zero lag; packet gaps zero;17frames of chronological original sound extend under the card. This establishes sampled source correspondence, not speaker identity, whole words or perceptual lip sync. [F17]
- **OBSERVED:** P02 proposed17.066667s body measured−23.6LUFS and about−4.7dB true peak; it was not normalized. Historical C01 encoded review reported−23.2LUFS/−2.6dBTP. The first is a source/body measure, not every final export’s loudness. **UNKNOWN:** Neither number establishes phone intelligibility or a platform failure. [F21]
- **OBSERVED:** No new score, VO, SFX, fake ambience or native-sound crossfade was added in the recovered P02/P03 outputs. Native dialogue/music/ambience/SFX were not reliably separated into stems or identified. Original-audio permission does not independently clear soundtrack rights. [F17,F21–F22]

### Errors and boundaries
**OBSERVED:** Early P02’s picture-based omission preceded sound understanding. Later records correctly refused to treat mouth movement, native cuts, low boundary energy or model times as speech proof. P03v02 was explicitly approved as private/provisional with an unresolved join; the record preserves that uncertainty rather than claiming the prior NVIDIA requirement passed. It is not a release-quality listening pass. [F02,F17; `AUTHORIZATION.json`/EDL]

**OBSERVED:** P03v02 already illustrates why picture and audio OUT may differ: picture ends source43.433333s, original audio continues to44s under the first0.566667s of the card. This is mapped chronological carry-over, not proof that44s is semantically complete or that the sound is a gasp/whale call. [F17]

**OBSERVED production-handback error:** The narration storyboard asked the user for a clean personal recording before the subsequent inventory check. The user explicitly made personal recording optional and required one inventory check/one provider proposal. That was the agent’s mistake, not missing creative permission. Content permission existed for one authored-VO pilot; an implemented authorized route/new provider approval did not. [F22; history2111/2114]

**UNKNOWN:** No narration delivery, accent, emotion, pacing, pronunciation, ducking result or generated-voice license purchase was tested. Missing TTS stopped that method, not proof that narration was a worse concept. No new provider was called. Do not say another platform’s normalization would repair quiet/poor speech automatically.

## 8. Vision / audiovisual model reliability

### Actual model route
**OBSERVED:** The established hosted route was `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning` at `https://integrate.api.nvidia.com/v1/chat/completions`. Request receipts identify inputs/prompts by hash. Video analysis used aligned silent MP4 plus full corresponding WAV in the same message; a separate audio-only P02 call was also made. Embedded MP4 sound ingestion, word-perfect transcription, forced alignment and comprehensive perception were not established. [F11–F14,F24]

| Existing usage | Identity/time map and question | Useful evidence | Failure and decision impact |
|---|---|---|---|
| P02 supplied initial joint + audio-only evidence | SRC03 source28.133333–51.933333;23.8s; source=input+28.133333. Is omitted conversation dispensable? | Core provisional metric/opinions/weld phrases suggested comedy | Joint repeated phrase, described up to25s; timing conflicted. Old omission suspended, not model EDL adopted |
| P02 boundary check | Delivered draft-derived inputs; what ends at reaction versus hook insert? | Successful retry supplied provisional callback/tail assessment | First500 was server failure, not rejected key. Preferred17.066667 endpoint stayed provisional |
| SRC01/SRC02 full + focused | Complete~60.3s or documented local offsets; find local joke/reveal | Hammer banter hypothesis; local visual candidates | One referred to supplied transcript when none existed; SRC02 transcript was narration, fall unestablished,60–65s impossible on60.3s source. Unsafe conclusions rejected |
| New-source pass | Three0–60s samples; NEW01 extra20–44s | Cloudwhale discovery hypothesis supported actual-picture selection | NEW02/NEW01-targeted200 but JSON parse failure; NEW03 bounded503s. Unusable answers stayed evidence gaps, not weak-source verdicts |
| P03 boundary20–44s | source=input+20; check speech near24–29/39–44 and reaction endpoint | Model suggested44s handle; native picture cut independently inspected | Compressed answer omitted needed alignment detail; follow-up final unparseable. OUT was not certified from model |
| Final B08 | source80–104s; input24s; source=input+80; complete remark/command/response only | Model returned two candidate sentences and separated command’s explicit monsters from inferred visible creatures | Following response repeats command; scalar times instead of spans, required fields missing. C04 stayed paused |

**OBSERVED independent checks:** Native picture sequences/cut neighbors, actual source duration, frame/sample maps, inspected phone images and saved QC could contradict or limit model statements. No independent heard transcript verified the returned words. Same model in another modality or a second prompt is not independent ground truth. [F12–F14,F17]

**OBSERVED B08 precise failure:** The final answer says “If people saw this gentle side, they would change their minds” and “All these monsters must be wiped out without exception,” then repeats the second sentence in both response fields. Those are **model claims**, not verified source quotations. Its claim of complete/uncertain:none is not confidence evidence. The answer does not establish the following response, all qualifications or complete time spans. No check of source content outside80–104s was performed in that request. [F11; copied final answer in `evidence/`]

### V1, V2, V3 usefulness and limits
**OBSERVED:** In this project, V1-style local picture inspection helped source selection; V2-style checking constrained authored observation/attribution claims; V3 scoped fallback inspected saved actual output images and exact export hash alongside local measurements. These were useful narrow checks, not claims that the new module/model ran at every stage. P03v02’s model stage explicitly remains not_checked. [F20]

**OBSERVED inherited test, not this agent’s new experiment:** The v1.3.1 module fixture recognized blue-square/rightward action and a planted wrong red-circle caption in V1/V3; the dedicated V2 negative request ended in two503s, so fixture remained INCOMPLETE_NOT_PASSED. Model times misplaced a2s oracle event at1.5/1.12s; V3 confused absence of a red circle with absence of any moving hook despite visible blue square. This validates neither timing nor general QC. [F20; fixture verdict]

**OBSERVED distinction:** Final answer saved versus semantically consumed are different. P02 phrases changed the proposed treatment; Cloudwhale’s broad discovery reading supported a picture-grounded concept; erroneous events/times were excluded. Parse-failed results were not source-selection negatives. B08 was saved and explicitly reported inadequate; it did not trigger a render. A model “retain/pass” recommendation was not creative authority. [F02,F11–F14]

### Transport versus authentication versus result quality
**OBSERVED:** Reviewed records separately contain absent runtime credential,500server failure,503ResourceExhausted capacity,200parse failure and200with incomplete semantic answer. The later B08 request succeeded once after explicitly authorized history access. None of these facts establishes past key rejection. Earlier adapters allowed up to three attempts; adopted v1.3.1 rules specify a two-attempt maximum and B08 used a reduced ceiling. Do not retroactively claim all historical calls followed the later ceiling. Exact spend/account quota is unknown. [F14–F15]

## 9. Implementation, recovery and efficiency

### Capability ladder and minimal adaptations
| Capability | Documented | Installed | Existing feature evidence | Project approval |
|---|---|---|---|---|
| FFmpeg trim/concat/card | Yes | Yes, recorded7.0.2 | Synthetic source-ID/marker fixture and actual P02/P03 encoded QC | Named private outputs, not publication |
| Pillow raster graphics + Arial | Yes | Yes, recorded Pillow13 | Logo/glyph/layout/phone/contrast/card checks | Approved artwork within pilot scope |
| OpenCV/Pillow inspection | Yes | Yes, invoked | Sequential decode/contact sheets/decoded picture inspection | Authorized read-only source/QC |
| Joint NVIDIA adapter | Yes | Working historical calls | Aligned silent-video/WAV route succeeded; imperfect answers | Authorized named sources/tasks, not blanket uploads |
| New vision module | Yes | Reported INSTALLED in inherited build | Fixture incomplete, dedicated negative V2 unavailable | Fallback/not_checked on actual P03v02, not universal release tool |
| Caption/ASR/OCR/alpha/HyperFrames/Lottie/etc. | Mixed recipe/helper/catalog entries | Not established as used project backends | No relevant production fixture in this work | Not automatically approved by registry presence |
| Narration TTS | Proposed | No implemented authorized route found in one recorded check | None; no voice generated | One-pilot creative exception, not provider/batch approval |

**TESTED:** The cadence repair was the smallest useful adaptation, not a framework build. P03’s graph was a small source-specific extension for teaser/multiple segments/card/audio mapping, with checksum dry-run and later encoded QC. Parser timebase assumptions were corrected without another render. AAC padding was distinguished from program duration; zero extra waveform lag was not called human lip sync. [F16–F19]

**OBSERVED:** There is no basis to claim all package legacy scripts, repositories or motion styles were installed/exercised. Old absolute paths/provider assumptions were not portable capability. Actual scripts preserve this project’s source paths; a new workspace needs path resolution, not a claim of one-click portability. **HYPOTHESIS:** Repeated external-runner handoffs added friction after a working route already existed. **UNKNOWN:** Time/cost saved by a different implementation is not measured. [F15,F19,F28]

### Fresh-session recovery audit
- **OBSERVED — Locate originals/exports:** Local IceRoad01–04/Cloudwhale01–02, P02 original/revision and P03v01/v02 exist with hashed identities; B08 original/excerpt/proxies exist. Current original B08/excerpt/proxy hashes match saved provenance. C01 and other batch source/register assets are missing locally. [F23–F24; index]
- **OBSERVED — Reconstruct mapping:** P02/P03 EDLs, render commands/filter graphs, frame-exclusive bounds and audio mappings exist. P03v02 can be revised from these files; C01 cannot reliably be rebuilt from current local files alone. [F17,F23]
- **OBSERVED — Recover decisions:** P03 opening code/layout, attribution PNG, card PNG/logo, scripts and QC remain. There are no verified speech captions to recover; uncertainty is itself a recorded decision. Narration B/C04 have historical storyboards but not implemented outputs. [F18,F22–F23]
- **OBSERVED — Understand authority:** Individual output approval is consumed; final C04 render remains unused and conditional; remaining batch paused; publication not authorized. Old resume paragraphs are superseded where later explicit user instructions differ. [history2628/2652; F01,F23]
- **UNKNOWN — Full recovery:** Current ACTIVE_CONTINUITY/RESUME point to older state; later v1.3.2/batch checkpoint reportedly delivered in history is absent. Why it is missing is unknown. A fresh agent must not trust the old pointer as complete current truth. [F23]

Precisely missing: C01 MP4 and hash/QC; C01 EDL/render/opening assets; full batch slate/manifest/source register/contact sheets/checkpoint; local v1.3.2 creative gate; locally saved C04 proposal record; independently verified transcripts/phrase alignments; actual platform preview; release rights/contribution acceptance; real post analytics. The index differentiates missing files from checks never evidenced. No large media library is duplicated in this handoff.

## 10. Prompt and operator-pressure audit

Each item distinguishes the actual instruction, my interpretation, affected decision, real conflict versus mistake, smallest amendment and protection to retain.

### P1 — Simplicity versus authorship
**Exact core quote:** “The smallest sufficient treatment is not necessarily the fewest cuts.” Core integration note4 also says restraint is not a ban on ambitious design. Note7 says “A source excerpt + caption + logo is not automatically a sufficient creative treatment.”
- **OBSERVED interpretation/output:** P02/P03 and C01 repeatedly stayed close to a native excerpt/card graph. **HYPOTHESIS:** implementation safety became a proxy for editorial sufficiency. [F26]
- **Conflict:** Not a real command to avoid authorship; my execution underused the freedom already present.
- **Smallest correction:** Require one sentence naming what information/interpretation the edit changes, not an effects quota or three treatment reports per clip.
- **Keep:** No fabricated evidence; clean dialogue/held shots remain valid choices.

### P2 — Professional does not mean more effects
**Exact user quote:** “Motion graphics, reframing, zooms, split screens, captions and narration are available creative options—not mandatory ingredients.” [history2162]
- **OBSERVED:** I did not add a barrage of effects. The weakness was reliance on source progression, not over-animation. ROAD/WHALE/CITY pointers were proposed then explicitly removed; they did not become an export. [F19,F22,F26]
- **Conflict:** No supported evidence that this instruction caused clutter; do not agree automatically with an “over-effects” diagnosis.
- **Smallest correction:** Ask what viewers lose without a graphic; permit purposeful motion if it answers a real information need.
- **Keep:** Legibility/meaning, not tool-count or visual-busyness targets.

### P3 — Autonomy and approval loops
**Exact user quote:** “If it is executable within existing permissions, render that first pilot without asking again for routine production steps.” [history2162]
- **OBSERVED:** Batch C01 was rendered and then paused as required; that was proper scoped autonomy. Earlier phases genuinely separated development/tests/render. Later secret-setter loops were not necessary creative approvals. [F01,F15,F27]
- **Conflict:** Publication/new provider/install/cost permissions were genuinely separate; routine cuts were not new gates after pilot authorization.
- **Smallest correction:** Maintain an action-specific authority matrix and ask once only at a new boundary.
- **Keep:** No silent escalation to posting, purchases, uploads or another output.

### P4 — Ten clips and duration defaults
**Exact quote:** “If fewer than 10 genuinely supported concepts exist, report the eligible number and specific evidence gap. Do not manufacture filler to satisfy the count.” [history2162]
**Brief exact default:** “15–25s mini-arc.” [brief§2]
- **OBSERVED:** Ten development concepts were presented, not ten cleared cuts; C09/C10 conditional and C02/C08 over-range flags remained. Narration B’s11.533s was explicitly below default, without padding. [F27]
- **Conflict:** No real instruction to meet a count by filler or cut qualifications to25s. **HYPOTHESIS:** announcing ten may still have created completion pressure; that is not proven causation.
- **Smallest correction:** Report readiness counts separately, avoid “ten strong drafts” language before execution evidence exists.
- **Keep:** Mandatory brief requirements and honest duration exceptions; do not make defaults hard universal laws.

### P5 — Compliance displacement
**Exact user feedback:** “The current Cloudwhale draft passes basic technical checks but does not yet meet the intended creative standard.” [history1744]
- **OBSERVED:** Exact CTA, frame cadence, hashes and source mapping were worked out while brand motivation and sound semantics stayed open. [F05–F06,F17–F18]
- **Conflict:** These checks were necessary, not the cause of all weak decisions. My mistake would be treating completion of them as creative success.
- **Smallest correction:** Show four separate statuses and a brief actual-file creative judgment; no new master-prompt rewrite.
- **Keep:** Do not remove honest measurement, permissions or campaign rules to speed up production.

### P6 — Hallucination avoidance versus useful interpretation
**Exact user quote:** “A joke, discovery or understandable suspense beat can be a payoff; a successful rescue or app interaction is not mandatory.” [history2162]
- **OBSERVED:** An earlier source comparison leaned toward needing a more resolved result/real app interaction; later record correctly accepted the bridge gap as a suspense reveal and Cloudwhale discovery as local payoff. [F08]
- **Conflict:** It was my overrestrictive editorial interpretation, not a prohibition on clearly labeled scene analysis.
- **Smallest correction:** Name the promised local beat; permit inference as labeled interpretation without presenting it as fact.
- **Keep:** Do not invent crossing, rescue, engineering safety or app functionality.

### P7 — Reuse tools, but do not invent availability
**Exact core quote:** “Check reusable implementations before planning a new component; no suitable resource is a valid outcome.” [integration note1]
- **OBSERVED:** FFmpeg/Pillow were appropriate; the30fps repair and P03 graph extension were small justified adaptations. Narration route was not already implemented just because catalogs discussed VO. [F16,F19,F22]
- **Conflict:** “Reuse” did not ban a small implementation; neither did installed tools license unapproved providers.
- **Smallest correction:** Inspect inventory once, separate documented/installed/tested/approved and implement only the missing exercised feature when authorized.
- **Keep:** Do not rebuild a general engine, install the registry or cite decorative skills to prove professionalism.

### P8 — Handing production back prematurely
**Exact assistant quote:** “Please attach a clean recording of:” followed by the proposed narration line. [history2111]
**Exact correction:** “A personal recording is optional—not the default task you hand back to me. Do not silently replace narration with text.” [history2114]
- **OBSERVED:** I asked for a recording before the subsequent inventory check and specific TTS proposal. This was an execution failure; the user had approved one narration pilot’s content. [F22]
- **Real missing permission:** New provider/data/cost action; not blanket narration permission. Existing pilot exception did not transfer to the batch.
- **Smallest correction:** Check once, propose one concrete route if missing, wait only for that genuinely new boundary.
- **Keep:** No unapproved provider call, cloned identity or silent substitution of text for approved VO.

### P9 — Secret-interface loop
**Exact user correction:** “If the credential genuinely is unavailable, stop asking me to configure a secret setter that this environment does not provide.” [history2652]
- **OBSERVED:** My earlier response invoked an applicable secure runtime-secret setter instead of resolving the explicit one-time historical-access question. The later authorized runtime lookup/request succeeded. [F15]
- **Conflict:** Secret safety is genuine; the assumed interface was my mistake. A successful later lookup does not establish earlier availability or authorize future secret fishing.
- **Smallest correction:** Identify only currently supported authorized methods; one explicit check, then the provided excerpt/provenance fallback. Continue unrelated authorized tasks.
- **Keep:** Never print/persist secrets, put them in artifacts, or test authentication separately without need.

### P10 — Frustration, overagreement and creative resets
**Exact user quote:** “This is a comparison between two creative approaches—not another master-prompt rewrite or demand for effects everywhere.” [history2594]
- **OBSERVED:** Feedback retained C01 and asked for contrast, not wholesale rejection. Cloudwhale instructions similarly requested one substantive revision rather than another general treatment report. [F09,F28]
- **UNKNOWN:** No controlled evidence establishes that frustration itself caused overpromising. The observable risk is replacing one unproven claim with another, e.g. asserting the next treatment is “genuinely stronger” before hearing/seeing it.
- **Smallest correction:** Preserve sound decisions, label new treatment value a hypothesis and assess the actual result; stop re-opening completed selection/setup absent a concrete gap.
- **Keep:** Specific feedback can legitimately change direction; do not defend a weak output just to preserve consistency.

**Bottom line — OBSERVED:** The instructions already contained many correct protections and creative freedoms. We should remove redundant compulsory paperwork and unavailable-interface asks, not weaken truthfulness or demand effects everywhere. No existing severity tiers were changed by this debrief.

## 11. Adversarial spot-check answers

1. **A — If added captions vanished, is there still an idea?** **OBSERVED:** P02 retains the source’s banter; P03v02 retains visual discovery. P03v01 loses its specific prediction question, but the native reveal survives. C01’s relative-size change survives historically, though its editorial framing line disappears. **UNKNOWN:** Whether cold viewers identify the intended angle without text. [F03–F05,F09]
2. **B — Remove decorative effects: what is lost?** **OBSERVED:** No decorative animation was exported in recovered plans. Removing attribution loses identification; removing the mandatory card loses compliance; removing the disclosed teaser changes information order. Those are different functions, not decoration. [F18–F19]
3. **C — Remove the logo: does it still belong?** **OBSERVED:** Source provenance ties it to the supplied campaign library. **UNKNOWN:** Whether that alone is persuasive or satisfies meaningful contribution. It is not current app-use evidence. [F06]
4. **D — Promise different from ending?** **OBSERVED:** P03v01’s city question receives a city-on-creature answer; C01’s scale observation receives a human reference in historical records. Their story payoff and sales ending are separate. **HYPOTHESIS:** Transition motivation is weak; no install result proves it. [F04,F06,F09]
5. **E — Easiest qualification/reaction to remove?** **OBSERVED:** P02’s opinions response before the weld callback; P03’s native reaction/source sound after43.433333; C04’s conditional remark completion/command qualification and subsequent turn. Exact words are provisional, not recut from estimated model times. [F02,F10–F12,F17]
6. **F — Did a CTA become a payoff?** **OBSERVED:** Records explicitly distinguish them, but the polished required card could make an unfinished creative rationale look complete. The actual payoff is joke/discovery/contrast; a download instruction cannot replace it. **HYPOTHESIS:** That technical polish contributed to false completion pressure. [F06,F26]
7. **G — Source variety called creative variety?** **OBSERVED:** Slate mechanisms differ on paper, but C01 alone cannot validate the batch. The user’s retained-candidate/not-direction feedback is justified. **UNKNOWN:** Whether all unrendered mechanisms would genuinely differ in execution. [F09,F27]
8. **H — “Narrative-led” while leaving source structure unchanged?** **OBSERVED:** P03v02 is better described as source-led compression, not a new explained narrative. C01 is source-led with an observation. C04’s proposed reorder/paired view is more authored but unrendered. [F05,F09–F10]
9. **I — Strongest reason not to follow our compression recommendation?** **OBSERVED:** The source24.2→27.033333 omission may remove necessary speech/action meaning; slow buildup may be purposeful. **UNKNOWN:** Whether the cut actually harms speech. Do not restore or cut more automatically; check the narrow context. [F17]
10. **J/K — Apparently weak choice that may be right / best practice contradicted?** **OBSERVED:** Uninterrupted quiet reaction protects comedy/discovery. The project contradicts a universal demand for faster cuts or extra graphics, not the value of purposeful pacing. **HYPOTHESIS:** A still teaser could work better for an attentive fantasy audience despite v01 concerns. [F03–F05,F26]
11. **L/M — Invisible problem solved while visible problem remained?** **TESTED:** Frame IDs/cadence/AAC padding/card holds protect trustworthy delivery. **OBSERVED:** They did not answer brand motivation or uncertain dialogue. Viewers may never notice the prevented cadence error, but could notice a poorly motivated ending. [F06,F16–F18]
12. **N — Decision easiest to implement?** **OBSERVED:** P02’s contiguous source + card uses the smallest tested graph; P03v01 main interval is also continuous. **HYPOTHESIS:** Ease contributed to preserving approach rather than designing around changing information; there is no logged counterfactual. [F26,F28]
13. **O — Did unreliable model output prove footage weak?** **OBSERVED:** No such conclusion is warranted. SRC02 fall/traction claims were rejected; parse/capacity failures did not reject NEW02/NEW03. Earlier incomplete-escape reasoning was too narrow; the suspense reveal remained useful. [F08,F13–F14]
14. **P/Q — What disproves weak-performance explanation / fair comparison?** **UNKNOWN:** No performance explanation is established. A fair future comprehension comparison would hold footage ending/branding/audio intelligibility constant while changing one opening-information strategy; real retention/install tests need comparable distribution and post ages. Different audience exposures could overwhelm style. [F25]
15. **R/S — What did a validator or technical success miss?** **OBSERVED:** B08 final JSON passed parsing while response fields merely repeated the command. **TESTED:** P03v02 mapping passed while speech semantics stayed unknown. Neither determines whether the story is compelling. [F11,F17]
16. **T — Where did criticism reject valid restraint?** **OBSERVED challenge to the premise:** Accessible feedback did not ban restraint: it retained C01 and explicitly denied a demand for effects everywhere. P02 source comedy may still deserve a minimal edit. **UNKNOWN:** No audience evidence establishes that this restrained option was unfairly rejected; I will not invent such a case to defend it. [history2594; F09,F26]
17. **U/V — Genuine/invented permission and missing actual-file check?** **OBSERVED:** New TTS provider/batch VO permission was missing; one-pilot narration content permission existed. Routine C01 production after authorization did not need another ask. **UNKNOWN:** Delivered speech, full English eligibility, perceptual sound and live platform preview never passed. [F15,F17,F22]
18. **W/X — Remove what; keep editorial?** **HYPOTHESIS:** Retire repeated general reports/runner asks and unavailable secret-setter instructions at resolved stages. Keep slow reveals, wordless moments, minimal-graphic dialogue, narration and purposeful heavy motion as choices. Do not retire measured honesty, rights boundaries or meaningful source understanding. [F26–F28]

## 12. Reusable learning proposals — not a new master prompt

The following proposals do not edit any active prompt, severity tier, package or approval. Status describes the supporting evidence; classification describes readiness to adopt the scoped action. Costs below are not provider quotes or time estimates.

### R01 — READY TO ADOPT
- **Rule ID:** R01
- **Lesson:** A saved/parseable model answer is not automatically a usable answer.
- **Status:** observed
- **Scope:** universal honesty/safety
- **Trigger:** A decision depends on structured model output.
- **Recommended action:** Check required questions, field semantics, time bounds and unresolved contradictions before consumption; preserve a not_checked reason.
- **What NOT to require:** A second provider, repeated general prompt, or one universal schema for all editorial tasks.
- **Exception or alternative:** Free-form notes may be useful as provisional clues without driving a consequential decision.
- **Fallback:** Use source/provenance and state the exact unresolved question; do not render from a failed premise.
- **Supporting evidence:** F11–F14; B08 repeated response; SRC02 impossible time; HTTP200 parse failures.
- **Counterexample / regression risk:** An overstrict parser can discard useful qualified prose; preserve final-only usable notes without promoting them to transcript.
- **Smallest future test:** Offline run saved B08 answer through a question-completeness validator; expect response/overlap unresolved.
- **Likely effort or cost, if known:** Small offline implementation; no new provider cost needed for this test. No duration estimate established.
- **Disposition:** keep

### R02 — READY TO ADOPT
- **Rule ID:** R02
- **Lesson:** Technical audio continuity is distinct from complete speech and perceived sound.
- **Status:** tested
- **Scope:** universal honesty/safety
- **Trigger:** Cut, omission or picture OUT touches dialogue/reaction.
- **Recommended action:** Record exact source→output map; separately mark waveform/packet results, heard-word boundaries and perceptual review.
- **What NOT to require:** A full re-transcription of unchanged scenes or a mandatory listening claim the agent cannot perform.
- **Exception or alternative:** A genuinely wordless passage can be assessed through appropriate sound evidence without invented words.
- **Fallback:** Preserve explicitly provisional boundaries or more context within scope; do not certify release.
- **Supporting evidence:** F02,F12,F17; P03v02 output1.833333s/source24.2→27.033333.
- **Counterexample / regression risk:** Overconservative handles can weaken pacing; more footage is not inherently safer or better.
- **Smallest future test:** Listener compares source23.7–27.6s to existing output1.333–2.333s; no render required.
- **Likely effort or cost, if known:** Human listening/annotation; cost and availability unknown.
- **Disposition:** keep

### R03 — READY TO ADOPT
- **Rule ID:** R03
- **Lesson:** Label comparison, chronology and inference only as specifically as evidence supports.
- **Status:** observed
- **Scope:** universal honesty/safety
- **Trigger:** Reordering, paired views or graphics imply recording, timing, causality or shared knowledge.
- **Recommended action:** Use truthful role labels; preserve qualifications and return to the actual response; distinguish prop evidence from product evidence.
- **What NOT to require:** Onscreen disclaimers for every simple chronological cut or a ban on editorial argument.
- **Exception or alternative:** Specific recording/time claims are appropriate when established by source.
- **Fallback:** Use CAMERA VIEW / PRECEDING SCENE or omit unsupported inference; stop concept if its premise is contradicted.
- **Supporting evidence:** F10–F11; operator correction history2628.
- **Counterexample / regression risk:** Excess labels can obstruct comprehension; use only those preventing a real misreading.
- **Smallest future test:** Human review of source dialogue first; later ask viewers what the comparison implies.
- **Likely effort or cost, if known:** Label amendment small; export test would require new scoped authorization.
- **Disposition:** amend

### R04 — PROVISIONAL
- **Rule ID:** R04
- **Lesson:** Name the edit’s useful contribution before choosing its implementation.
- **Status:** hypothesis
- **Scope:** conditional craft guidance
- **Trigger:** New concept or substantive creative reset, especially another excerpt-plus-line/card treatment.
- **Recommended action:** State audience reason, truthful promise, source payoff, qualification/reaction and what ordering/framing adds; compare one genuine alternative only when useful.
- **What NOT to require:** Three route reports for every clip, motion quota, app demonstration or VO as proof of authorship.
- **Exception or alternative:** A strong dialogue joke/wordless reveal may need nearly no intervention; say source-led honestly.
- **Fallback:** Retain as a scene-led candidate or technical reference without claiming contribution acceptance.
- **Supporting evidence:** F04–F06,F09,F26; history1744/2594.
- **Counterexample / regression risk:** Forcing visible authorship can make an already strong source worse and overload it with commentary.
- **Smallest future test:** Cold-viewer comparison of one restrained version and one supported authored alternative, with matched ending and sound.
- **Likely effort or cost, if known:** Existing-file judgment may be low effort; new treatment/test scope and costs unknown.
- **Disposition:** amend

### R05 — READY TO ADOPT
- **Rule ID:** R05
- **Lesson:** A complete local discovery/joke/suspense beat need not resolve the larger story.
- **Status:** observed
- **Scope:** conditional craft guidance
- **Trigger:** Candidate is rejected because rescue, crossing, mission or whole episode is unresolved.
- **Recommended action:** Judge the actual opening promise and resulting information/emotional turn, not an invented success criterion.
- **What NOT to require:** A rescue, working repair, app interaction or fully resolved plot for every short.
- **Exception or alternative:** A result claim or tutorial must supply the promised result/proof.
- **Fallback:** Reframe as honest discovery/suspense or reject the treatment, not the whole source by default.
- **Supporting evidence:** F07–F08; SRC02 bridge gap, not successful crossing; rejected husky replay.
- **Counterexample / regression risk:** Calling every unresolved fragment suspense can excuse missing payoff.
- **Smallest future test:** Ask viewers what was promised and what they learned/felt at the actual ending; no platform analytics substituted.
- **Likely effort or cost, if known:** Small human comprehension check; no reliable cost estimate.
- **Disposition:** amend

### R06 — DO NOT GENERALIZE
- **Rule ID:** R06
- **Lesson:** Do not add sound processing from a quiet LUFS number alone.
- **Status:** hypothesis
- **Scope:** source-specific
- **Trigger:** Native mix is measured quiet or has uncertain phone intelligibility.
- **Recommended action:** Audition actual encoded delivery and assess dialogue/noise/dynamics; propose licensed, scoped processing only when needed, then remeasure.
- **What NOT to require:** Universal−14LUFS, automatic gain, music bed, source muting or faith in platform normalization.
- **Exception or alternative:** A genuine clipping or technical spec violation needs appropriate repair, not aesthetic debate.
- **Fallback:** Keep unprocessed provisional mix and document the missing perceptual check.
- **Supporting evidence:** F21; P02 source−23.6LUFS and historical C01−23.2LUFS.
- **Counterexample / regression risk:** Blind gain can raise noise/peaks and change intended dynamics; no established intelligibility failure here.
- **Smallest future test:** Phone/headphone audition of actual exports; only then a bounded processing comparison if approved.
- **Likely effort or cost, if known:** Human audition first; actual processing effort unknown.
- **Disposition:** investigate

### R07 — DO NOT GENERALIZE
- **Rule ID:** R07
- **Lesson:** Keep exact campaign requirements separate from defaults and universal craft.
- **Status:** tested
- **Scope:** campaign-specific
- **Trigger:** RexTrix ending, language requirement or duration choice is evaluated.
- **Recommended action:** Use current confirmed exact logo/CTA/4.5readable seconds; track15–25s as recorded default, and English amendment as mandatory for this brief.
- **What NOT to require:** A4.5s card for all campaigns, filler to reach15s, or cutting qualifications to25s.
- **Exception or alternative:** A later explicit brief amendment or real contractual requirement changes the applicable constraint.
- **Fallback:** Flag exception/eligibility instead of silently waiving a hard requirement or promoting a default.
- **Supporting evidence:** F18,F27; brief amendments and actual135frame export checks.
- **Counterexample / regression risk:** Historic enforcement anecdotes can become stale or be imported into another campaign.
- **Smallest future test:** Read current brief/owner amendments at next campaign; actual ending check on chosen export only.
- **Likely effort or cost, if known:** Existing records and bounded QC; no fresh testing needed for this retrospective.
- **Disposition:** keep

### R08 — READY TO ADOPT
- **Rule ID:** R08
- **Lesson:** Reuse evidence and exercised capabilities, not catalog prestige.
- **Status:** observed
- **Scope:** tool-environment-specific
- **Trigger:** A route/resource is selected or an environment changes.
- **Recommended action:** Track DOCUMENTED/INSTALLED/FEATURE-TESTED/APPROVED separately and adapt only the missing feature for the selected concept.
- **What NOT to require:** Installing a registry, auditing every reference, exercising all styles or inheriting builder tests as local production passes.
- **Exception or alternative:** A changed codec/graph/input can justify one relevant fixture even when base tool worked.
- **Fallback:** Small tested local route or explicitly unimplemented method.
- **Supporting evidence:** F16,F19–F20; FFmpeg fixture, static A12 adaptation, incomplete vision fixture.
- **Counterexample / regression risk:** Overformal capability paperwork can itself delay routine production.
- **Smallest future test:** One minimal changed-path fixture with source IDs/known oracle; do not rerun unchanged paths ceremonially.
- **Likely effort or cost, if known:** Bounded local test; no general framework estimate.
- **Disposition:** keep

### R09 — RETIRE
- **Rule ID:** R09
- **Lesson:** Do not ask for unavailable secret interfaces or hand routine production to the user before checking the existing route.
- **Status:** observed
- **Scope:** tool-environment-specific
- **Trigger:** Runtime secret or narration implementation appears unavailable.
- **Recommended action:** Check the current supported authorized route once; separate content/provider/cost/data scope; identify one real gap and continue independent work.
- **What NOT to require:** Chat secrets, credential-in-artifact, auth probe, another runner ZIP or personal recording as the default.
- **Exception or alternative:** A user may choose personal recording; historical credential lookup is allowed only with appropriate explicit authority, never presumed.
- **Fallback:** Authorized excerpt/provenance plus exact unanswered questions, or one specific provider proposal without invocation.
- **Supporting evidence:** F15,F22; history2111/2114/2652 and B08 receipt.
- **Counterexample / regression risk:** Past success can create unsafe assumptions of persistent access; do not expose or duplicate credentials.
- **Smallest future test:** Offline routing fixture with unavailable tool, scoped prior permission and absent credential cases.
- **Likely effort or cost, if known:** Small decision-path check; no live provider test required.
- **Disposition:** remove

### R10 — READY TO ADOPT
- **Rule ID:** R10
- **Lesson:** One pilot calibrates the treatment, not the whole slate.
- **Status:** observed
- **Scope:** conditional craft guidance
- **Trigger:** A multi-output batch is requested.
- **Recommended action:** Distinguish developed/executable/rendered/cleared counts; stop at explicit calibration and preserve unresolved candidates.
- **What NOT to require:** Ten fillers, cosmetic source swaps or automatic rejection of restrained work.
- **Exception or alternative:** Established, approved repeatable format may scale under its stated authority without reopening everything.
- **Fallback:** Deliver eligible count and concrete evidence gaps; hold others without inventing failure.
- **Supporting evidence:** F09,F27; C01 retained, nine not rendered; C10 permission/route gap.
- **Counterexample / regression risk:** Excess calibration can become another indecision loop after direction is approved.
- **Smallest future test:** Evaluate one truly contrasting supported approach against retained candidate before expanding; not effects everywhere.
- **Likely effort or cost, if known:** A new comparison export requires scoped approval; no cost estimate.
- **Disposition:** keep

### R11 — READY TO ADOPT
- **Rule ID:** R11
- **Lesson:** Recovery must identify exact current files and supersession, not just accumulate histories.
- **Status:** observed
- **Scope:** universal honesty/safety
- **Trigger:** Delivery, revision, workspace/package migration or fresh-session handoff.
- **Recommended action:** Save small current manifest with relative paths, hashes, EDL/audio/graphic decisions, approvals, missing checks and delivered file references.
- **What NOT to require:** Duplicate full source/media libraries, preserve secrets, or reconstruct edit intent from chat alone.
- **Exception or alternative:** Large media may stay in an authorized asset store if identity/retrieval route is recorded.
- **Fallback:** Mark missing file/hash explicitly and rely on historical claims only at their weaker evidence level.
- **Supporting evidence:** F01,F23–F24; P03 recoverable, C01/current batch package absent.
- **Counterexample / regression risk:** A manifest without checked resolution can look authoritative while pointing to absent files.
- **Smallest future test:** Read-only manifest resolution/hash audit in a fresh workspace; recover absent checkpoint before revision.
- **Likely effort or cost, if known:** Hashing/indexing local files; retrieval effort/availability unknown.
- **Disposition:** amend

### R12 — READY TO ADOPT
- **Rule ID:** R12
- **Lesson:** Do not turn style preferences, compliant endings or low views into causal performance evidence.
- **Status:** unknown
- **Scope:** universal honesty/safety
- **Trigger:** A draft is rated strong/weak or a template is described as viral.
- **Recommended action:** State whether judgment concerns technical correctness, comprehension, campaign fit or actual audience outcome; retain no_data when appropriate.
- **What NOT to require:** A performance test before every editorial judgment or a view guarantee.
- **Exception or alternative:** A bounded controlled audience/analytics comparison may support a scoped finding with real denominators.
- **Fallback:** Use a labeled creative hypothesis and specify the smallest fair future test.
- **Supporting evidence:** F25; no matched post analytics for private outputs; unrelated brief anecdotes excluded.
- **Counterexample / regression risk:** Overcaution can stop useful craft decisions; judgment is permitted if not presented as proven performance.
- **Smallest future test:** Predeclare one treatment variable and comparable audience/post-age/exposure measures after separate publication approval.
- **Likely effort or cost, if known:** Distribution/test costs unknown; no metrics or prices fabricated.
- **Disposition:** keep

## Handoff boundary

**OBSERVED:** These are proposals, not adopted edits to the frozen core or current campaign files. No severity taxonomy was silently changed. Ready-to-adopt honesty/routing rules are narrow; craft recommendations remain conditional. The freedom to use an uninterrupted slow reveal, a wordless visual moment, minimally graphed dialogue, narration-led explanation or purposeful motion-heavy treatment is preserved.
