# Adoption decisions v2.0 — delta on the v1.4.0 matrix

v1.4.0 consolidated the two debriefs (52 attributed findings) into ten change
groups and an operating overlay. v2.0 keeps those decisions and adds the
following, each tied to observed evidence that survived v1.4.0's review:

| # | Change | Evidence that motivates it | Where it lives | Counterexample guard |
|---|---|---|---|---|
| A1 | Actual-export creative review becomes a required record entry at delivery (opening/payoff/sound observed, headline-removal answer, biggest defect, verdict) | Debrief A "biggest mismatch": gate-passing was treated as quality; the creative question "was answered only by the builder's own note". A required, structured entry makes the §6C pass leave a trace | Master prompt v4.0 §6; record v2.0 `reviews`; validator v2 | "no headline used; scene stands on its own" is a valid answer — a scene-led minimal record passes (governance tests); the validator checks presence, never taste |
| A2 | Scoped exceptions get an explicit decision lifecycle (adopt / retire / re-scope; pending blocks publish) | Debrief A failure 3 + mismatch 2: caption systems and card lengths diverged because no rule ever expired an exception | Master prompt §7; record v2.0 `exceptions`; validator v2 (publish stage) | Delivery stage does not block on pending; only publication forces the decision |
| A3 | Recorded overrides for weak-fit warnings and their storytelling-cost note | Debrief A §3: B2 Primal built despite its own scout's "drop first"; B4's stronger payoff excluded without recording the cost | Master prompt §3; playbook v1.1 "Scouting and scope"; record `overrides` + `creative.fit_warning_override` | Overrides validate only when present; a record with no warnings needs none |
| A4 | Retired measurement methods named in the active docs | Debrief A: four retired methods (full-file bitrate, volumedetect floors, mono-downmix TP, post-trim loudnorm) repeatedly reappeared; R-03 READY TO ADOPT | Master prompt §9; playbook v1.1 (method strings beside figures) | Methods are hygiene, not new hard gates; no numeric thresholds added |
| A5 | Per-batch authority mode line (per-file / blanket(list,expiry) / autonomous(scope)) | Debrief A §10.7–8: blanket upload word ambiguity; authority leaks are the fragile point | Master prompt §1; record v2.0 `authority_mode` | Ambiguity resolves to per-file, not to asking repeatedly |
| A6 | Campaign-state pre-flight with timestamp before upload runs | Debrief A failure 5: clip 1 uploaded into a paused campaign (02:46 vs 02:58 PKT) | Master prompt §1 (one line) | Once per run, not per clip |
| A7 | Blanket-verdict protocol (ask once for one named defect; else record hypothesis, rebuild = experimental) | Debrief A failure 6: edit-3 rejection had no defect on record; G2 fix loop shows one defect → one fix | Master prompt §7 | Asking once, not per clip essay; honors "infer from evidence" of the overlay |
| A8 | Reordering-allowed honesty line | Debrief A §10.2: "keep it simple" was misread as "don't touch order" | Master prompt §4 | Faking is never allowed; meaning-preservation is the test |
| A9 | Vary-or-omit clause for rhythm devices | Debrief A §10.4: §10's devices risk becoming the next template | Playbook v1.1 | Explicit: a clip with no punch-in and no interrupt passes if pacing serves the scene |
| A10 | Scope decisions record storytelling cost; surveys run before briefs | Debrief A §3 (B4 upgrade excluded), §10.6 (mid-batch scope churn) | Playbook v1.1 "Scouting and scope" | Discipline benefit and storytelling cost are both written down |
| A11 | Title-never-approves + saliency-as-proposal made explicit | R-05/R-06 READY TO ADOPT | Master prompt §2; playbook v1.1 | Ep1 scout gates ep1 use; later episodes need their own scout |
| A12 | Standalone master prompt (v4.0) with required/optional separation and campaign-number guard | The consolidated deliverable lacked a single standalone instruction file; precedence was spread over 6+ docs | `05_master_prompt/PRO_EDITOR_BRAIN_v4.0.md`; `test_standalone_prompt.py` asserts it stays campaign-agnostic | v4.0 absorbs the v1.4.0 overlay wholesale; nothing active is lost |
| A13 | Entry-point repair: banners on 11 historical/superseded docs + historical README for RexTrix area + new START_HERE precedence table | A fresh agent could still follow `00_continuation/FRESH_AGENT_PROMPT.md` into expired render instructions | Root `START_HERE.md`; bannered bodies preserved unaltered | Historical manifests list original bytes; v2.0 manifest lists bannered bytes; both are auditable |

## Deliberately not adopted / not built (and why)

- No independent-QC subagent mandate (R-04): v1.4.0's boundary stands —
  separation of build and review is required; *who* reviews is environmental.
  Master prompt §7 phrases it as "another agent, or your own independent
  re-measurement with stated methods".
- No word-safe speech-verification tool, no ducking-verification method
  (R-08 INVESTIGATE): both need authorized ASR/stems work that this task
  cannot exercise. The honest workflows are documented in the master prompt
  §2/§9; the capability gap is stated in CAPABILITY_STATUS.md.
- No second model configuration, no new provider, no numeric universal
  thresholds, no caption-system unification ruling (that is a per-campaign
  human decision — debrief A open question 4), no NEVER_REPEAT re-tiering of
  historical entries (open question 5): both remain human decisions and are
  listed as such.
- No new effects requirements, no mandatory VO, no universal durations:
  confirmed against both debriefs; the v1.4.0 "deferred / not adopted" list
  stands verbatim.
