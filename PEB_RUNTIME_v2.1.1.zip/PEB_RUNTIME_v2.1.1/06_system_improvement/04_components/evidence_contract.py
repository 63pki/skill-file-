#!/usr/bin/env python3
"""Validate declared records and evidence identity, NOT truth, media or taste.

v2.0 additions: delivery/publish records must carry actual-export review
entries covering every output; exceptions carry an explicit decision lifecycle
(pending blocks publish); overrides and creative.fit_warning_override are
validated when present. Structure and identity only — never taste, truth,
rights or release authority.

v2.1 additions (bounded review-integrity patch, ported from the v1.4.2 branch
and reconciled onto this v2.0 baseline): review rows are bound to the output's
current SHA-256 (missing or mismatched review hashes are rejected); verdicts
use approved|hold|revise|provisional_draft, with 'deliver' accepted as the
documented v2.0-era alias of 'approved' (same gate behavior); unresolved
hold/revise verdicts block publish validation until an approved review of the
SAME bytes declares resolved_by; a clearly labeled provisional_draft may still
be delivered but is never a publish verdict; requirement scopes referencing
nonexistent output ids are rejected so a target typo cannot make a mandatory
check silently disappear. The contract still validates declared structure and
artifact identity only."""
import argparse, hashlib, json, math
from pathlib import Path

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def validate(record, root, stage='delivery'):
    errors=[];root=Path(root).resolve()
    def problem(text): errors.append(text)
    def artifact(ref):
        if not isinstance(ref,str) or not ref.strip(): return None
        p=(root/ref).resolve()
        if not p.is_relative_to(root) or not p.is_file() or not p.stat().st_size: return None
        return p
    if stage not in ('plan','delivery','publish'): return ['Invalid stage']
    if not record.get('project_id'): problem('Missing project id')
    requirements=record.get('requirements',[])
    if not isinstance(requirements,list): return ['requirements must be a list']
    ids=[r.get('id') for r in requirements]
    if not ids or any(not x for x in ids) or len(set(ids))!=len(ids):problem('Declare unique effective requirement ids; empty requirements do not pass')
    if record.get('open_requirement_conflicts'): problem('Unresolved requirement conflict')
    expected=record.get('expected_output_ids',[]);outputs=record.get('outputs',[])
    if not isinstance(expected,list):problem('expected_output_ids must be a list');expected=[]
    if not isinstance(outputs,list):problem('outputs must be a list');outputs=[]
    if stage=='plan':known_ids=set(x for x in expected if isinstance(x,str))
    else:known_ids=set(x for x in expected if isinstance(x,str))|set(o.get('id') for o in outputs if isinstance(o,dict) and o.get('id'))
    for r in requirements:
        if not r.get('source_ref'):problem('Missing requirement provenance')
        if r.get('enforcement') not in ('mandatory','default','preference'):problem('Invalid enforcement')
        if not r.get('applies_to'):problem('Missing requirement scope')
        elif r.get('applies_to')!='all_outputs' and r.get('applies_to') not in known_ids:problem('Requirement scope references nonexistent output id: '+str(r.get('applies_to')))
        if r.get('metric'):
            if not r.get('unit'):problem('Numeric requirement needs units')
            for key in ('min','max'):
                if key in r and (not isinstance(r[key],(int,float)) or isinstance(r[key],bool) or not math.isfinite(r[key])):problem('Invalid numeric bound')
            if 'min' in r and 'max' in r and isinstance(r['min'],(int,float)) and isinstance(r['max'],(int,float)) and r['min']>r['max']:problem('Contradictory numeric bounds')
    c=record.get('creative',{})
    for k in ('audience','angle','opening_picture_sound','promise','payoff_before_cta','editorial_contribution','brand_connection','selected_route','selection_reason'):
        if not c.get(k):problem('Missing creative decision: '+k)
    beats=c.get('beats',[])
    if not beats:problem('No source-linked beats')
    for b in beats:
        for k in ('id','source_ref','information_change','picture','sound'): 
            if not b.get(k):problem('Beat missing '+k)
        sr=b.get('semantic_review',{})
        if sr.get('status') not in ('reviewed','not_checked'):problem('Missing semantic review status')
        if not sr.get('reason'):problem('Semantic review needs scope or reason')
    changes=record.get('learning_changes',[])
    for change in changes:
        if change.get('action') not in ('append','supersede'):problem('Invalid learning change')
        if change.get('action')=='supersede' and not change.get('supersedes'):problem('Supersession needs old rule reference')
    if stage=='plan':return errors
    if not expected or len(set(expected))!=len(expected):problem('Expected nonzero unique output set required')
    outids=[o.get('id') for o in outputs]
    obyid={o.get('id'):o for o in outputs if isinstance(o,dict)}
    if len(set(outids))!=len(outids) or set(outids)!=set(expected):problem('Actual output ids differ from expected set')
    if not outputs:problem('No outputs; empty comparison cannot pass')
    exceptions=record.get('exceptions',[])
    if exceptions and not isinstance(exceptions,list): return ['exceptions must be a list']
    for ex in exceptions or []:
        if not ex.get('id') or not ex.get('scope'): problem('Exception needs id and scope')
        if ex.get('decision') not in ('pending','adopted','retired','re_scoped'): problem('Exception decision invalid: '+str(ex.get('id')))
        if stage=='publish' and ex.get('decision')=='pending': problem('Pending exception must be adopted, retired or re-scoped before publishing: '+str(ex.get('id')))
    overrides=record.get('overrides',[])
    if overrides and not isinstance(overrides,list): return ['overrides must be a list']
    ovids=set()
    for ov in overrides or []:
        if not ov.get('id') or not ov.get('overrides_ref') or not str(ov.get('reason') or '').strip():
            problem('Override needs id, target reference and reason')
        else: ovids.add(ov.get('id'))
    if len(ovids)!=len(overrides or []): problem('Duplicate override ids')
    fwo=(record.get('creative') or {}).get('fit_warning_override')
    if fwo and fwo not in ovids: problem('fit_warning_override references undeclared override')
    for o in outputs:
        p=artifact(o.get('path'))
        if not p:problem('Missing/nonlocal/empty output: '+str(o.get('id')))
        elif digest(p)!=o.get('sha256'):problem('Output hash mismatch: '+str(o.get('id')))
        checks=o.get('checks',[])
        cids=[x.get('requirement_id') for x in checks]
        if len(cids)!=len(set(cids)):problem('Duplicate check rows')
        for check in checks:
            if check.get('requirement_id') not in ids:problem('Check refers to unknown requirement')
            if check.get('status') not in ('pass','fail','not_checked'):problem('Invalid check status')
            if check.get('status')=='pass':
                if check.get('output_sha256')!=o.get('sha256'):problem('Stale check output hash')
                if not check.get('method') or not check.get('scope'):problem('Pass lacks method/scope')
                if not artifact(check.get('evidence_ref')):problem('Pass lacks present nonempty evidence')
            elif not check.get('reason'):problem('Non-pass needs reason')
        for r in requirements:
            if r.get('enforcement')!='mandatory' or r.get('applies_to') not in ('all_outputs',o.get('id')):continue
            row=next((x for x in checks if x.get('requirement_id')==r.get('id')),None)
            if not row or row.get('status')!='pass':problem('Mandatory requirement not passed: '+str(r.get('id')))
            metric=r.get('metric')
            if metric:
                measurement=o.get('measurements',{}).get(metric,{})
                value=measurement.get('value')
                if not isinstance(value,(int,float)) or isinstance(value,bool) or not math.isfinite(value):problem('Missing/invalid measurement: '+metric);continue
                if measurement.get('unit')!=r.get('unit'):problem('Measurement unit mismatch: '+metric)
                if not artifact(measurement.get('evidence_ref')):problem('Measurement lacks evidence: '+metric)
                if 'min' in r and isinstance(r['min'],(int,float)) and value<r['min']:problem('Below minimum: '+metric)
                if 'max' in r and isinstance(r['max'],(int,float)) and value>r['max']:problem('Above maximum: '+metric)
    if stage in ('delivery','publish'):
        reviews=record.get('reviews',[]);resolved_ok=set();by_id={};vnorm={}
        if not isinstance(reviews,list) or not reviews:
            problem('Delivery requires at least one actual-export review entry')
        else:
            reviewed=set()
            for rv in reviews:
                if not isinstance(rv,dict):problem('Review row must be an object');continue
                rid=rv.get('id')
                if not rid:problem('Review missing id');continue
                if rid in by_id:problem('Duplicate review id: '+str(rid));continue
                by_id[rid]=rv
                v=rv.get('verdict')
                if v=='deliver':v='approved'
                vnorm[rid]=v
                oid=rv.get('output_id');o=obyid.get(oid) if isinstance(oid,str) else None
                if oid not in outids:problem('Review refers to unknown output: '+str(oid))
                else:reviewed.add(oid)
                if not rv.get('output_sha256'):problem('Review missing output hash binding: '+str(rid))
                elif o is not None and rv.get('output_sha256')!=o.get('sha256'):problem('Review hash mismatch against current output bytes: '+str(rid))
                if rv.get('basis')!='actual_export': problem('Review must be based on the actual export: '+str(oid))
                for k in ('opening_observed','payoff_observed','sound_observed','headline_removal','biggest_defect'):
                    if not str(rv.get(k) or '').strip(): problem('Review missing '+k+': '+str(oid))
                if v not in ('approved','hold','revise','provisional_draft'): problem('Review verdict invalid: '+str(oid))
            for oid in outids:
                if oid not in reviewed: problem('Output lacks actual-export review: '+str(oid))
            for rid,rv in by_id.items():
                res=rv.get('resolved_by')
                if res is None:continue
                rr=by_id.get(res) if isinstance(res,str) else None
                if rr is None or rr is rv or vnorm.get(res)!='approved' or rr.get('output_id')!=rv.get('output_id') or rr.get('output_sha256')!=rv.get('output_sha256'):problem('Invalid resolved_by reference: '+str(rid))
                else:resolved_ok.add(rid)
    if stage=='publish':
        if record.get('campaign_state')!='active':problem('Campaign not confirmed active')
        if not any(a.get('action')=='publish' and a.get('active') is True and a.get('reference') for a in record.get('authorizations',[])):problem('No active scoped publication authorization')
        for rid,rv in by_id.items():
            v=vnorm.get(rid)
            if v=='approved':continue
            if v in ('hold','revise') and rid in resolved_ok:continue
            if v=='provisional_draft':problem('Provisional review draft is not a publish verdict: '+str(rid));continue
            problem('Unresolved '+str(v)+' review blocks publish: '+str(rid))
    return errors

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('record',type=Path);p.add_argument('--stage',choices=['plan','delivery','publish'],default='delivery');a=p.parse_args()
    try: errors=validate(json.loads(a.record.read_text()),a.root,a.stage)
    except Exception as e:errors=['Record could not be validated: '+type(e).__name__]
    print(json.dumps({'record_checks_passed':not errors,'errors':errors,'scope':'Declared record, nonempty coverage, artifact identity, hash-bound review rows and verdict gates; no creative quality, speech, measurement-truth, rights or release certification'},indent=2));return int(bool(errors))
if __name__=='__main__':raise SystemExit(main())
