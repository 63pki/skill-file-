#!/usr/bin/env python3
"""Probe identity plus positive/negative fixtures; not proof of all FFprobe features."""
import argparse,hashlib,json,shutil,subprocess,tempfile
from pathlib import Path

def inspect(executable, fixture, expected_width, expected_height, expected_sha256=None):
    located=shutil.which(executable)
    if not located:return {'status':'not_checked','reason':'executable_not_found'}
    path=Path(located).resolve();sha=hashlib.sha256(path.read_bytes()).hexdigest()
    result={'resolved_path':str(path),'sha256':sha,'identity_status':'pinned_match' if expected_sha256==sha else 'unpinned' if expected_sha256 is None else 'pin_mismatch','scope':'Selected fixture metadata and invalid-input rejection only; no frame-count/audio/true-peak/creative certification'}
    def run(args):return subprocess.run([str(path),*args],capture_output=True,text=True,timeout=25)
    try:
        version=run(['-version']);result['version_first_line']=version.stdout.splitlines()[0] if version.stdout else '';result['version_exit']=version.returncode
        args=['-v','error','-show_entries','stream=codec_type,width,height','-of','json']
        good=run([*args,str(fixture)]);result['positive_exit']=good.returncode
        try:streams=json.loads(good.stdout).get('streams',[])
        except (ValueError,AttributeError):streams=[]
        positive=good.returncode==0 and any(s.get('codec_type')=='video' and s.get('width')==expected_width and s.get('height')==expected_height for s in streams)
        with tempfile.TemporaryDirectory() as tmp:
            invalid=Path(tmp)/'invalid.mp4';invalid.write_bytes(b'NOT A VALID MEDIA FILE\n');bad=run([*args,str(invalid)])
        result['negative_exit']=bad.returncode
        result['fixture_features_passed']=positive and bad.returncode!=0 and version.returncode==0
        result['status']='feature_tested_scoped' if result['fixture_features_passed'] and result['identity_status']!='pin_mismatch' else 'failed'
    except (OSError,subprocess.TimeoutExpired) as e:result.update(status='not_checked',reason=type(e).__name__)
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('fixture',type=Path);p.add_argument('--executable',default='ffprobe');p.add_argument('--width',type=int,required=True);p.add_argument('--height',type=int,required=True);p.add_argument('--expected-sha256');a=p.parse_args()
    r=inspect(a.executable,a.fixture,a.width,a.height,a.expected_sha256);print(json.dumps(r,indent=2));return int(r.get('status')!='feature_tested_scoped')
if __name__=='__main__':raise SystemExit(main())
