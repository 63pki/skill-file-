# Registry and implementation inventory — v2.1

Active components (state, honest scope):
- `05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md`: ACTIVE master prompt. DOCUMENTED
  and wired into root START_HERE + NEXT_CAMPAIGN_STARTUP; standalone by test
  (7 guard tests incl. the v2.1 patch-lock). Not audience-tested (no such
  test exists for prose instructions). v4.0 preserved below a SUPERSEDED banner.
- `06_system_improvement/04_components/evidence_contract.py` v2.1:
  FEATURE-TESTED (offline: 30 contract + 21 governance + 20 review/scope-gate
  tests). Local stdlib validation of declared records, artifact identity,
  hash-bound review rows, verdict publish gates, exception lifecycle and
  overrides. NOT a media inspector, creative judge or release authority.
  Exit 0 means record checks passed, never campaign cleared.
- `06_system_improvement/04_components/inspect_probe.py`: FEATURE-TESTED
  (scoped: version, one positive fixture, malformed-input rejection). Binary
  UNPINNED; a plausible version string is not trusted identity.
- `01_preserved_system/PEB_PORTABLE_v1.1.1/05_components/inspect_media.py`:
  metadata/hash only; carried with the frozen core.
- `04_vision_stages/05_components/vlm_scan.py` + `vision_contract.py`:
  INSTALLED; the new-capability fixture remains INCOMPLETE_NOT_PASSED (V2
  negative check ended in two HTTP 503s; V3 misread a hook; model times
  inaccurate). The existing authorized NVIDIA route stays available for
  provisional source evidence within its scope. Project use needs existing
  route/upload/cost approvals.
- `02_nvidia/tools/analyze_av.py`: stdlib helper, syntax-checked, NOT
  API-runtime-tested in this build. Optional; never run by packaging.
- Playbook v1.2, record template v2.0 + guide v2.1, startup instruction:
  DOCUMENTED, offline-tested where mechanically checkable; editorial behavior
  unverified until the first authorized pilot.

Historical compatibility (do not use as active instructions):
- `04_vision_stages/05_components/creative_gate.py` + its three-route template:
  retained for archived-record validation only; superseded by v4.x §3.
- `06_system_improvement/01_instructions/ACTIVE_MASTER_PROMPT.md` (v1.4.0
  overlay): absorbed into v4.0, then v4.1.
- `05_master_prompt/PRO_EDITOR_BRAIN_v4.0.md`: superseded by v4.1 (banner).
- `06_system_improvement/02_playbook/INTENTIONAL_EDITING_METHODS_v1.1.md`,
  `06_system_improvement/05_templates/RECORD_GUIDE_v2.0.md`: superseded by
  playbook v1.2 / guide v2.1 (banners).
- Bannered continuation docs: history.
- Branch-B-only artifacts not carried into v2.1 (documented in
  `06_system_improvement/07_status/PATCH_REPORT_v2.1.md` §2; each ABSENT by
  design): `measure_media.py` — ABSENT (branch-B only) — + tests;
  `ACTIVE_CAPABILITY_MAP.md` — ABSENT (branch-B only);
  `PRECEDENCE_AND_CONFLICTS.md` — ABSENT (branch-B only); v1.4.x overlay
  lineage, branch banner/status variants.

Pending (unchanged, requires future authorization or a human ruling):
1. Incorporating the v4.x rules into a future core release — PENDING; v2.x
   solves precedence by authority ordering, not by editing the frozen core.
2. VLM fixture completion (needs provider authorization).
3. Word-safe speech verification method and final-mix duck verification
   (needs authorized ASR/stems work; capability gap documented, not solved).
4. Caption-system unification and NEVER_REPEAT severity tiering (per-campaign
   human rulings; debrief A open questions 4–5).
5. Next campaign and audience performance: not tested; no active production
   authorization.

**Release state: FROZEN for the first authorized pilot.** Further creative
changes follow observed editing behavior — not another speculative rewrite.
