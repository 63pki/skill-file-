# Build verdict — v1.4.0
## Completed
- Active entry point and operational prompt overlay, practical technique playbook, compact project template and explicit historical compatibility rule.
- Both attached final debriefs preserved; 52 attributed findings linked to 10 scoped change groups. Pasted retrospective claims with different populations are flagged, not silently adopted as verified.
- 35 new offline unit tests passed: empty reference/expected set, missing/empty artifacts, output/version mismatch, incomplete mandatory coverage, measurement units/bounds, card-only repair with bad runtime, paused publication, scoped amendments, preference versus hard gate, learning supersession, and deceptive probe fixtures.
- 17 inherited offline vision/creative tests passed. These are regression checks of the preserved components; the old three-route creative checker is historical compatibility, not the active planning requirement.
- Actual installed ffprobe path, hash, version, positive640x360 fixture metadata and malformed-input rejection inspected. Selected features passed. Binary is UNPINNED; this is not approved identity provenance or a frame/audio/true-peak measurement test.
- Preserved core and baseline integrity comparison, full-package manifest and credential-pattern scan: see PACKAGE_VERIFICATION_v1.4.0.json.

## Not established
No new creative pilot, human listening, VLM call, complete VLM fixture pass, rights verification, release permission or audience performance. The14 editorial scenarios are documented regression cases, not executed taste tests. Structural validators cannot prove that evidence is truthful or a video compelling. No automatic gate threshold claims to predict views.

## Next use
Give the editing agent this package and tell it: “Use START_HERE.md and the active v1.4.0 overlay. Treat RexTrix as paused. For the next authorized campaign, establish its effective brief and scope once, develop a source-grounded idea, and build/review the authorized calibration pilot before scaling. Do not restart the old campaign or ask for another retrospective.”
