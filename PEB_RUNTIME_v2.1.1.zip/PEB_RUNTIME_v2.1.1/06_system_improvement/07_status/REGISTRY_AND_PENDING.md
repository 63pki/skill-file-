# Registry and implementation inventory addendum
- Operational overlay/playbook: DOCUMENTED and wired into START_HERE. Not audience-tested.
- `04_components/evidence_contract.py`: local stdlib record/reference validation; offline negative tests only. Not a media inspector, creative judge or release authority. Run with project root and record path. Exit0 means record checks passed, never campaign cleared.
- `04_components/inspect_probe.py`: local executable path/hash/version + positive metadata and malformed-input fixture inspector. Tests only exercised ffprobe features. A plausible version string is not trusted identity. Known hash pin must come from a separately reviewed executable, not auto-created trust.
- Existing vision adapter unchanged. Inherited VLM fixture remains INCOMPLETE_NOT_PASSED; no new cloud request or model installation. Project use needs its existing route/upload/cost approvals.
- Incorporating overlay into frozen core: PENDING a future core release.
- Historical pasted verifier/30clip allegations: unresolved provenance; no hard finding against missing code.
- Next campaign and audience performance: not tested; no active production authorization.
