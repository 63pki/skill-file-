# Build verdict — v2.1

## What this build is
Reconciliation release: the operator-reviewed v2.0 consolidated package as
the byte-preserved base, plus the six directed review-integrity fixes from
the separately-patched v1.4.2 branch, ported and merged (branch comparison by
content and SHA-256 documented in `PATCH_REPORT_v2.1.md`).

## Completed and verified this build
- Incoming packages re-hashed: v1.4.0 (523/523 manifest entries), v2.0 and
  v1.4.1/v1.4.2 trees extracted and diffed file-by-file (504 shared identical,
  19 differing — each diff inspected, 14 of them banner/status wording only).
- Merged `evidence_contract.py` v2.1: v2.0's full machinery (review coverage
  with five observed fields, exceptions lifecycle, overrides, publish
  authorization gates) + branch B's hash binding, verdict publish gates,
  resolution links and requirement-scope integrity. Verdict vocabulary
  unified: approved|hold|revise|provisional_draft, `deliver` accepted as the
  documented v2.0-era alias (test-pinned).
- Active prompt `PRO_EDITOR_BRAIN_v4.1.md` (v4.0 + §1 campaign-brief boundary
  + §6 hash-binding/verdict-gate rules); v4.0 preserved below a SUPERSEDED
  banner. Playbook v1.2 (brand-removal diagnostic line); RECORD_GUIDE v2.1.
- End-to-end CLI checks with real contract invocations: provisional draft →
  delivery PASS; publish on draft-only → BLOCKED (named error); corrected
  hash-bound publication record → publish PASS; scope typo → rejected at plan
  and delivery.
- Tests: **100/100 pass** (evidence contract 30, record governance 21,
  standalone-prompt guard 7, review/scope gates 20, probe 5, vision contracts
  12, creative gate 5). Logs packaged beside the suites.
- Frozen core byte-identity re-verified (249/249 vs v2.0 and v1.4.0).
- Credential-pattern scan: 0 hits. No credential packaged.

## Not established (unchanged truthfulness boundary)
No creative pilot, no human listening, no VLM call, no rights verification,
no release permission, no audience performance. Structural validators cannot
prove evidence truthful or a video compelling; verdicts are recorded, not
re-judged. The VLM fixture remains INCOMPLETE_NOT_PASSED. The 52 debrief
findings remain attributed reports. Editorial behavior of a fresh agent under
v4.1 is unproven until the first authorized pilot observes it.

## Release state
**FROZEN for the first authorized pilot.** Further creative changes follow
observed editing behavior from that pilot — not another speculative rewrite.

## Next use
Give the editing agent this package plus the new campaign brief and footage,
using the instruction block in `NEXT_CAMPAIGN_STARTUP.md`.
