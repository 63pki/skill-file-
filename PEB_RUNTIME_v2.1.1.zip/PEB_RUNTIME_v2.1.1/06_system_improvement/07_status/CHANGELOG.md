# v1.4.0 change log
- Recovered v1.3.2 baseline and preserved frozen core and all baseline files except the root entry point; historical entry point saved as START_HERE_v1.3.2_HISTORY.md.
- Added one active operational overlay, optional technique playbook, effective-project record, evidence contract checker, executable identity/fixture inspector, regression cases and build evidence.
- Replaced compulsory three-route paperwork with brief consequential route comparison; routine approved revisions do not restart development. This supersedes the conflicting continuation default, not rights/claims rules.
- RexTrix paused; no legacy NEXT_ACTIONS, expired pilot approvals or request budgets are active authorization.
- Imported both final debriefs as attributed historical evidence. Preserved their original labels but did not promote them to independently verified facts.
- Separated pasted retrospective assertions not supported by the supplied bundles. Deferred source-code accusations and causal performance claims.
- Added no provider, cost, production render, publishing action, new effects requirement or VLM approval.
