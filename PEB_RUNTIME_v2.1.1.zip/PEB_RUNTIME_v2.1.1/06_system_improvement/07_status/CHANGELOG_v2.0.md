# v2.0 change log

Consolidation release. The frozen core (01_preserved_system/PEB_PORTABLE_v1.1.1)
remains byte-identical (re-verified: 249/249 files); every v1.4.0 file is
carried forward with zero removals; fourteen files have intentionally changed
bytes (3 functional + 11 banner lines, listed under "Changed") — each original
preserved in the v1.4.0 upload archive and its manifest.

## Added
- `05_master_prompt/PRO_EDITOR_BRAIN_v4.0.md` — standalone consolidated master
  prompt (single active authority below the campaign brief).
- `NEXT_CAMPAIGN_STARTUP.md`, `CHANGE_REPORT_v2.0.md`, `CAPABILITY_STATUS.md`.
- Record schema v2.0 (`PROJECT_RECORD_TEMPLATE_v2.0.json`), `RECORD_GUIDE_v2.0.md`.
- `ADOPTION_MATRIX_v2.0.md` (13 delta decisions + explicit non-adoptions).
- Tests: `test_record_governance.py` (21), `test_standalone_prompt.py` (6).
- `06_system_improvement/07_status/{BUILD_RESULT_v2.0,CHANGELOG_v2.0,REGISTRY_AND_PENDING_v2.0}.md`.
- `03_current_project/HISTORICAL_README.md`.
- Root `MANIFEST_v2.0.json`, `PACKAGE_VERIFICATION_v2.0.json`, this changelog,
  `BUILD_RESULT_v2.0.md`.

## Changed (intentional byte changes vs v1.4.0)
- `START_HERE.md` — replaced with the v2.0 single entry point + precedence
  table (v1.4.0 content preserved in the v1.4.0 ZIP and summarized here).
- `06_system_improvement/04_components/evidence_contract.py` — v2 validations
  (reviews/exceptions/overrides); docstring and scope line updated.
- `06_system_improvement/06_tests/test_evidence_contract.py` — fixture gains
  one review entry so all 30 original cases remain meaningful under v2 rules.
- 11 documents gained a leading banner line (bodies preserved unaltered):
  00_continuation/{FRESH_AGENT_PROMPT, NEXT_ACTIONS, CURRENT_STATE_AND_APPROVALS,
  CURRENT_STATE_v1.3, CREATIVE_TREATMENT_GATE_v1.0,
  PEB_CREATIVE_DIRECTION_ADDENDUM_v1.0, AGENT1_LESSONS_AND_ROUTING_RULES_v1.0,
  RECOVERY_AND_MISSING}.md; 06_system_improvement/01_instructions/
  ACTIVE_MASTER_PROMPT.md; 02_playbook/INTENTIONAL_EDITING_METHODS.md;
  05_templates/RECORD_GUIDE.md.

## Superseded / retired (kept for lineage, no longer active instructions)
- The v1.4.0 overlay (`ACTIVE_MASTER_PROMPT.md`) → absorbed into v4.0 §0–§10.
- The compulsory three-route creative gate + creative_gate.py planning
  requirement → historical compatibility (validator kept for archived
  records); active idea-selection rules are v4.0 §3 with the compact record.
- `INTENTIONAL_EDITING_METHODS.md` v1.0 → v1.1. `RECORD_GUIDE.md` v1.4 → v2.0.
- `00_continuation/FRESH_AGENT_PROMPT.md` and `NEXT_ACTIONS.md` → bannered
  historical; replaced by root START_HERE + NEXT_CAMPAIGN_STARTUP.md.

## Unchanged truthfulness boundaries carried forward
RexTrix paused; no render/upload/provider/publication authorization; VLM
fixture INCOMPLETE_NOT_PASSED; 52 debrief findings remain attributed, not
independently reproduced; no view/retention claims; no credentials packaged.
