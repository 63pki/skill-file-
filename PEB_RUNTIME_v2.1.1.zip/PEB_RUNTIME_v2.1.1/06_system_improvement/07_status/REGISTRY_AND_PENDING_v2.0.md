# Registry and implementation inventory — v2.0

Active components (state, honest scope):
- `05_master_prompt/PRO_EDITOR_BRAIN_v4.0.md`: ACTIVE master prompt. DOCUMENTED
  and wired into root START_HERE + NEXT_CAMPAIGN_STARTUP; standalone by test.
  Not audience-tested (no such test exists for prose instructions).
- `06_system_improvement/04_components/evidence_contract.py` v2: FEATURE-TESTED
  (offline: 30 inherited + 21 governance tests). Local stdlib record/reference/
  review/exception/override validation; NOT a media inspector, creative judge
  or release authority. Exit 0 means record checks passed, never campaign
  cleared.
- `06_system_improvement/04_components/inspect_probe.py`: FEATURE-TESTED
  (scoped: version, one positive fixture, malformed-input rejection). Binary
  UNPINNED; a plausible version string is not trusted identity.
- `01_preserved_system/PEB_PORTABLE_v1.1.1/05_components/inspect_media.py`:
  metadata/hash only; carried with the frozen core.
- `04_vision_stages/05_components/vlm_scan.py` + `vision_contract.py`:
  INSTALLED; the new-capability fixture remains INCOMPLETE_NOT_PASSED (V2
  negative check ended in two HTTP 503s; V3 misread a hook; model times
  inaccurate). The existing authorized NVIDIA route stays available for
  provisional source evidence within its scope. Project use needs existing
  route/upload/cost approvals.
- `02_nvidia/tools/analyze_av.py`: stdlib helper, syntax-checked, NOT
  API-runtime-tested in this build. Optional; never run by packaging.
- Playbook v1.1, record v2.0, startup instruction: DOCUMENTED, offline-tested
  where mechanically checkable; editorial behavior unverified until the first
  authorized pilot.

Historical compatibility (do not use as active instructions):
- `04_vision_stages/05_components/creative_gate.py` + its three-route template:
  retained for archived-record validation only; superseded by v4.0 §3.
- `06_system_improvement/01_instructions/ACTIVE_MASTER_PROMPT.md` (v1.4.0
  overlay): absorbed into v4.0.
- Bannered continuation docs: history.

Pending (unchanged, requires future authorization or a human ruling):
1. Incorporating the overlay/v4.0 rules into a future core release — remains
   PENDING; v2.0 solves precedence by authority ordering, not by editing the
   frozen core.
2. VLM fixture completion (needs provider authorization).
3. Word-safe speech verification method and final-mix duck verification
   (needs authorized ASR/stems work; capability gap documented, not solved).
4. Caption-system unification and NEVER_REPEAT severity tiering (per-campaign
   human rulings; debrief A open questions 4–5).
5. Next campaign and audience performance: not tested; no active production
   authorization.
