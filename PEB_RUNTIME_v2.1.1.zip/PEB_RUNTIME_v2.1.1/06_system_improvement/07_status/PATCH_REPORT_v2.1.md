# Patch report — PEB_EDITORIAL_SYSTEM v2.0 → v2.1 (branch reconciliation + bounded review-integrity patch)

Date: 2026-10-30 · Author role: reconciliation and bounded-patch executor per operator directive ·
RexTrix remains **paused**; this work authorized system improvement only. No render, provider
call, upload, or publication occurred. No new creative paperwork was added.

---

## 0. The discrepancy, resolved by content and hashes (not labels)

Two independent branches existed after the audited v1.4.0 baseline
(`PEB_EVIDENCE_LED_EDITOR_v1.4.0.zip`, SHA-256 `ec264ba291cb90c89d78cdfc882ab1ae2935d9dd1e9156cc5e1c4338fc6b93a8`,
523/523 manifest hashes verified, 52/52 tests reproduced this build):

- **Branch A (operator-reviewed):** `PEB_EDITORIAL_SYSTEM_v2.0.zip`
  (SHA-256 `526103578a138e176ffe3582afdcbaeb08f68a26d29ebd93312bcebd2aa3a076`)
  with standalone prompt `PRO_EDITOR_BRAIN_v4.0.md`
  (SHA-256 `671cf4a22e6e54bbfa355103b54645f44c3b8fdbedb6a52a4814edf3da9c76f2`),
  79/79 tests (record governance 21, standalone-prompt guard 6, evidence
  contract 30, probe 5, vision contracts 12, creative gate 5).
- **Branch B (later patch lineage):** `PEB_CONTINUITY_v1.4.1.zip`
  (SHA-256 `e2aacf0f23e74a5af3cefb5cca5c69d8e6096b39cf3a9aebf3bacfc362f61fad`,
  72/72 tests) → `PEB_CONTINUITY_v1.4.2.zip`
  (SHA-256 `d67f0293e9922069f2d8c186ffbb58052642165d432929b498f6898bff430424`,
  90/90 = 72 inherited + 18 review/scope gates). The operator-directed
  six-point bounded patch had landed here, on a tree that lacked v2.0's
  consolidation (no `05_master_prompt/`, no record-governance suite, no
  standalone-prompt guard, different verdict vocabulary).

Both trees were extracted and compared file-by-file by SHA-256: **504 files
byte-identical shared; 24 files only in v2.0; 4 files only in v1.4.2; 19 files
differing** (3 functional code/template files, 2 instruction files, and 14
banner/status variants — each diff inspected: the continuation-doc differences
are banner wording only, pointing at each branch's own entry point; the
protective function is identical). Nothing unique to v1.4.1 existed that
v1.4.2 did not also contain.

**Resolution:** v2.0 (the reviewed package) is the base; the six directed
fixes from the v1.4.2 bounded patch are ported onto it. This release is
v2.1. No conflicting active versions remain: one entry point, one active
master prompt (`PRO_EDITOR_BRAIN_v4.1.md`), one record contract.

## 1. The six directed changes — where they now live

| # | Operator directive | Implementation in v2.1 |
|---|---|---|
| 1 | Bind each actual-export review to the output's current SHA-256; reject missing/mismatched review hashes at delivery/publish validation | `evidence_contract.py` v2.1: every review row requires `output_sha256` equal to the output's current bytes; missing or stale bindings are rejected. Prompt §6 and RECORD_GUIDE_v2.1 state the rule |
| 2 | Unresolved hold/revise verdicts block publish acceptance; preserve clearly labeled provisional review draft delivery | Publish gate: `hold`/`revise` block unless an `approved` review of the SAME bytes declares `resolved_by`; `provisional_draft` is a legal delivery verdict and never a publish verdict (named error). Delivery never blocks on verdicts |
| 3 | Reject requirement scopes referencing nonexistent output IDs | `applies_to` values other than `all_outputs` must reference a declared output id (`expected_output_ids` at plan; actual outputs at delivery/publish) — at every stage |
| 4 | Campaign briefs control campaign parameters — not permission to fabricate evidence, misrepresent rights or exceed authorization | Prompt §1 sentence (and closing line); RECORD_GUIDE_v2.1 requirements bullet |
| 5 | Brand-removal counterfactual diagnostic, not a universal rejection rule | Playbook v1.2 regression question ("diagnostic, not a rejection rule"); prompt §3 already carried the counterfactual as a question; the only universal-rejection formulation (historical `CREATIVE_TREATMENT_GATE_v1.0.md` line) is explicitly superseded by name in root START_HERE — historical bytes untouched, banner discipline preserved |
| 6 | Positive and negative tests incl. valid provisional delivery and corrected hash-bound publication record; update ZIP, standalone MD, manifests, change log | `test_review_and_scope_gates.py` ported and adapted (20 tests; both required positives included); all suites re-run 100/100; `MANIFEST_v2.1.json`, `PACKAGE_VERIFICATION_v2.1.json`, this report, `CHANGELOG_v2.1.md`; ZIP rebuilt; standalone `PRO_EDITOR_BRAIN_v4.1.md` exported byte-identical |

## 2. Reconciliation decisions (each documented, none silent)

- **Base tree = v2.0, byte-identical** except the declared changes in §4.
  Nothing from v2.0 was removed or weakened; the frozen core remains
  byte-identical (verified against the v1.4.0 and v2.0 trees).
- **Verdict vocabulary unified:** v2.0 used `deliver`; branch B used
  `approved`/`provisional_draft`. The v2.1 contract canonicalizes
  `approved|hold|revise|provisional_draft` and accepts `deliver` as a
  documented v2.0-era alias of `approved` (identical gate behavior, pinned by
  a test). v2.0's two suites were updated to the canonical token — a declared
  edit, listed in §4.
- **Review row shape unified:** v2.0's five observed fields
  (`opening_observed`, `payoff_observed`, `sound_observed`, `headline_removal`,
  `biggest_defect`) + `basis: actual_export` are kept as the required findings
  surface; branch B's generic `findings` string is not needed and is not
  required. Hash binding, unique review ids, and `resolved_by` come from
  branch B.
- **v2.0 machinery kept in full:** exceptions decision lifecycle (pending
  blocks publish), overrides + `fit_warning_override`, per-output review
  coverage, campaign/publish authorization gates — none of branch B's changes
  removed any of these.
- **Branch-B-only items deliberately NOT carried** (documented, not silent):
  `measure_media.py` — ABSENT (branch-B only) — + its 9 tests;
  `ACTIVE_CAPABILITY_MAP.md` — ABSENT (branch-B only);
  `PRECEDENCE_AND_CONFLICTS.md` — ABSENT (branch-B only); plus the v1.4.x
  overlay lineage and banner variants, branch-B status/manifest files.
  Rationale: v2.0's active prompt
  already carries the §3 scout-override and §7 exception-expiry rules in
  stronger form; capability truth lives in `CAPABILITY_STATUS.md` and prompt
  §REQUIRED ENVIRONMENT/OPTIONAL PACKAGED TOOLS; precedence lives in root
  START_HERE's four-rank table; adding a measurement tool was not part of the
  directed six and would expand the reviewed package's active surface. The
  measurement methods themselves remain documented in playbook v1.2 (§Retired
  measurement methods) exactly as v2.0 had them.
- **Brand-removal conflict resolution recorded** in root START_HERE
  (Precedence section) rather than a new instruction file — the smallest
  sufficient placement, consistent with the v2.0 structure.

## 3. Verification (offline, this build)

- Tests from the clean staging tree: **100/100 pass** —
  evidence contract 30, record governance 21, standalone-prompt guard 7
  (gains the patch-lock test), review/scope gates 20 (all 18 v1.4.2 tests
  ported — one negative re-expressed from a generic `findings` field to the
  v2.0 observed-field shape — plus one wrong-basis negative and the
  `deliver`-alias positive), probe 5,
  vision contracts 12, creative gate 5. Logs: `06_system_improvement/06_tests/` `*_v21.log`,
  `04_vision_stages/tests/contract_tests_v21.log`,
  `04_vision_stages/tests/creative_gate_tests_v21.log`.
- End-to-end CLI checks (real invocations, separate fixtures): labeled
  provisional draft → delivery PASS; publish on draft-only review → BLOCKED
  with named error; corrected hash-bound publication record → publish PASS;
  scope typo → rejected at plan and delivery.
- Frozen core `01_preserved_system/PEB_PORTABLE_v1.1.1`: byte-identical to
  v2.0 and v1.4.0 (verified).
- Credential-pattern scan over all packaged text files: 0 hits (pattern scan,
  not universal secret detection). ffprobe identity remains UNPINNED.
- Truthfulness boundary unchanged: no creative pilot, no human listening, no
  VLM call, no rights verification, no audience performance, no claim that
  structural tests prove compelling videos. The VLM fixture remains
  INCOMPLETE_NOT_PASSED. The 52 debrief findings remain attributed, not
  independently reproduced.

## 4. Complete list of byte changes vs v2.0 (everything else identical)

Added:
- `05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md` (active prompt; v4.0 body + §1
  boundary sentence + §6 hash-binding/verdict-gate paragraph + change note)
- `06_system_improvement/02_playbook/INTENTIONAL_EDITING_METHODS_v1.2.md`
  (v1.1 body + one diagnostic line, marked [v2.1])
- `06_system_improvement/05_templates/RECORD_GUIDE_v2.1.md`
- `06_system_improvement/06_tests/test_review_and_scope_gates.py` (ported)
- `06_system_improvement/07_status/{BUILD_RESULT_v2.1,CHANGELOG_v2.1,REGISTRY_AND_PENDING_v2.1,PATCH_REPORT_v2.1}.md`
- `06_system_improvement/06_tests/*_v21.log`, `04_vision_stages/tests/{contract_tests_v21,creative_gate_tests_v21}.log`
- Root `MANIFEST_v2.1.json`, `PACKAGE_VERIFICATION_v2.1.json`

Changed (intentional):
- `START_HERE.md` — v2.1 entry point (prompt/playbook/guide references,
  brand-removal supersession note, freeze declaration)
- `NEXT_CAMPAIGN_STARTUP.md` — package + prompt version references; step 5
  notes the review-entry hash binding
- `06_system_improvement/04_components/evidence_contract.py` — merged v2.1
  contract (docstring, scope-integrity block, review hash binding + verdict
  gates, scope line)
- `06_system_improvement/06_tests/test_evidence_contract.py` — review fixture
  gains `id`/`output_sha256`; verdict canonicalized to `approved` (30 tests
  otherwise unchanged)
- `06_system_improvement/06_tests/test_record_governance.py` — same fixture
  update (21 tests otherwise unchanged)
- `06_system_improvement/06_tests/test_standalone_prompt.py` — pins
  `PRO_EDITOR_BRAIN_v4.1.md`; adds the patch-lock token test
- Banner added (body preserved unaltered): `05_master_prompt/
  PRO_EDITOR_BRAIN_v4.0.md`,
  `06_system_improvement/02_playbook/INTENTIONAL_EDITING_METHODS_v1.1.md`,
  `06_system_improvement/05_templates/RECORD_GUIDE_v2.0.md`

## 5. Release state — FROZEN

v2.1 is **frozen for the first authorized pilot** (declared in root
START_HERE, `BUILD_RESULT_v2.1.md`, `REGISTRY_AND_PENDING_v2.1.md`,
`CHANGELOG_v2.1.md`). Further creative changes follow observed editing
behavior from that pilot — not another speculative rewrite. Still open
(all pre-existing): VLM fixture completion (needs authorized provider call);
NVIDIA key provisioning (awaiting user); core incorporation decision;
per-campaign caption-system and card-length rulings; unresolved historical
verifier allegations.
