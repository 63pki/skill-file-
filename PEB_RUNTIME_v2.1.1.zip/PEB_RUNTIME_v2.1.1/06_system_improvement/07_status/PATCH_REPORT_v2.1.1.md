# v2.1.1 — narrow diagnostic wording patch
Basis: user-supplied PEB_EDITORIAL_SYSTEM_v2.1.zip. Its563 manifest entries were rehashed successfully before copying.

Changed the active prompt §3 itself, not just an optional playbook. Headline-removal and brand-removal counterfactuals are diagnostic, not automatic rejection rules. Truthful campaign story spotlights may remain eligible without app demonstration or added narration. Existing rights, claims, branded-element and contribution requirements remain intact.

Updated root entry point and the startup package name where present. The active prompt retains its existing filename to preserve internal references; its status identifies this patch. Added three narrow text regression checks, new test logs, fresh verification and a full-package manifest. All other baseline files are retained, with content changes itemized in the new verification record.

No validator, model route, project permission or production timeline was changed. The frozen core remains unchanged. No installation, provider request, media render or publication occurred. Test results concern mechanics and wording, not creative quality, listening, rights clearance or performance. No API credential is included by this patch.
