# v2.1 change log

Reconciliation release: v2.0 (operator-reviewed) as byte-preserved base +
the six directed fixes from the v1.4.2 bounded patch, merged and documented
in `PATCH_REPORT_v2.1.md`. Zero files removed; frozen core untouched
(249/249 byte-identical re-verified).

## Added
- `05_master_prompt/PRO_EDITOR_BRAIN_v4.1.md` — active master prompt
  (v4.0 + §1 campaign-brief boundary + §6 review hash-binding and verdict
  publish gates + change note).
- `06_system_improvement/06_tests/test_review_and_scope_gates.py` — 20 tests
  ported from the v1.4.2 patch, adapted to the v2.0 review shape; includes
  the two required positives (valid provisional delivery; corrected hash-bound
  publication record) and the `deliver`-alias pin.
- `06_system_improvement/02_playbook/INTENTIONAL_EDITING_METHODS_v1.2.md` —
  v1.1 + the brand-removal counterfactual as an explicit diagnostic
  (not a rejection rule) [v2.1].
- `06_system_improvement/05_templates/RECORD_GUIDE_v2.1.md` — hash-bound
  review rows, verdict gates, scope-integrity and brief-boundary lines.
- `06_system_improvement/07_status/{PATCH_REPORT_v2.1,BUILD_RESULT_v2.1,
  CHANGELOG_v2.1,REGISTRY_AND_PENDING_v2.1}.md`; fresh `*_v21.log` test logs.
- Root `MANIFEST_v2.1.json`, `PACKAGE_VERIFICATION_v2.1.json`.

## Changed (intentional)
- `06_system_improvement/04_components/evidence_contract.py` → v2.1: review
  rows bound to the output's current SHA-256 (missing/mismatched rejected);
  verdicts approved|hold|revise|provisional_draft with `deliver` as documented
  v2.0-era alias; unresolved hold/revise block publish unless resolved by an
  approved review of the same bytes (`resolved_by`); provisional_draft never a
  publish verdict; requirement scopes referencing nonexistent output ids
  rejected at every stage. v2.0's exceptions/overrides/coverage machinery
  unchanged.
- `06_system_improvement/06_tests/test_evidence_contract.py` and
  `test_record_governance.py`: review fixtures gain `id`/`output_sha256`;
  verdict canonicalized to `approved`. Counts unchanged (30 and 21).
- `06_system_improvement/06_tests/test_standalone_prompt.py`: pins v4.1; adds
  patch-lock token test (7 tests).
- `START_HERE.md`, `NEXT_CAMPAIGN_STARTUP.md`: v2.1/v4.1 references,
  brand-removal supersession note, freeze declaration, step-5 hash-binding note.
- Banner added (bodies preserved unaltered): `PRO_EDITOR_BRAIN_v4.0.md`,
  `INTENTIONAL_EDITING_METHODS_v1.1.md`, `RECORD_GUIDE_v2.0.md`.

## Superseded / resolved conflicts (explicit, by name)
- `00_continuation/CREATIVE_TREATMENT_GATE_v1.0.md` universal brand-removal
  rejection line → counterfactual diagnostic (playbook v1.2, prompt §3);
  historical bytes untouched.
- `PRO_EDITOR_BRAIN_v4.0.md` → superseded by v4.1 (lineage preserved).
- Verdict token `deliver` → alias of `approved` (backward-compatible).

## Frozen
v2.1 is frozen for the first authorized pilot. Further creative changes
follow observed editing behavior from that pilot — not another speculative
rewrite. RexTrix remains paused; no render, upload, provider call or
publication is authorized by this package. No credential is packaged.
