> **SUPERSEDED (banner added v2.1).** The active guide is `RECORD_GUIDE_v2.1.md` (adds hash-bound review rows, the approved|hold|revise|provisional_draft verdict set with 'deliver' as documented v2.0-era alias, resolved_by, scope-integrity and campaign-brief boundary lines). Body preserved unaltered below.

# One record, reused — v2.0 guide

Fill the v2.0 template or map equivalent existing fields. Empty template is deliberately not a pass.
Historical v1.4.0 records stay readable as history; new deliveries validate under v2.0.

- authorizations: {action, reference, active}; action values e.g. analyze, render, external_upload, publish.
- authority_mode: one line per batch — per-file, blanket(version list, expiry), or autonomous(scope). A blanket word with no version list/expiry is treated as per-file.
- requirements: {id, source_ref, enforcement: mandatory|default|preference, applies_to, metric?, unit?, min?, max?, amendment_of?}. One effective row per id. Unresolved conflicts stay explicit; only actual numeric bounds use metric/min/max. Campaign-specific numbers live here and in the brief — never in the master prompt.
- creative.beats: {id, source_ref, information_change, picture, sound, text?, semantic_review: {status: reviewed|not_checked, reason}}. Source refs are provenance, not proof that a claim is true.
- creative.fit_warning_override: when a recorded scouting/fit warning was overridden to build anyway, set it to the id of an entry in overrides. {overrides: [{id, overrides_ref, reason}]} — an override without a recorded reason is not a decision, it is a hope.
- exceptions: [{id, scope, decision: pending|adopted|retired|re_scoped, note?}]. Every scoped exception (card length, caption placement, pad system, waived gate) is decided explicitly before the next batch. Pending exceptions block the publish stage.
- outputs: {id, path, sha256, measurements: {metric:{value,unit,evidence_ref}}, checks: [{requirement_id,status:pass|fail|not_checked,output_sha256,method,scope,evidence_ref,reason?}]}. Every mandatory applicable requirement needs one row on every submitted output. Measurements are reports, not freshly reproduced by the contract checker.
- reviews: at least one entry per output at delivery/publish, basis "actual_export": {output_id, basis, opening_observed, payoff_observed, sound_observed, headline_removal, biggest_defect, verdict: hold|revise|deliver}. These are the section-6C cold-viewer conclusions in compact form — what you actually observed on the delivered file, the headline-removal counterfactual answer ("no headline used; scene stands on its own" is a valid answer), and the biggest remaining defect or "none" with what was checked. A review entry is a claimed observation, not an independently reproduced fact; keep the honest separation.
- learning_changes: {id, action: append|supersede, supersedes?}. Learned rules carry an enforcement tier (compliance/safety, measurement, craft/diagnostic). Preserve prior versions.
- Vision module interplay: when the V1/V2/V3 vision workflow is used, its artifacts attach under outputs[].checks/measurement evidence_refs and reviews; projects that adopt the full vision record format additionally run `04_vision_stages/05_components/vision_contract.py` on that record. The compact record never requires the vision format.

Run: `python 06_system_improvement/04_components/evidence_contract.py PROJECT_ROOT RECORD.json --stage plan|delivery|publish`
Delivery checks records/evidence coverage, review presence and artifact identity; publish additionally needs active campaign + publish authority + no pending exceptions. It does not inspect rights, meaning, credentials, pixels or sound, and never certifies quality. A material unverified mandatory requirement stays held; diagnostics/preferences do not become hard gates.
