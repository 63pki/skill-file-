> **SUPERSEDED (banner added v2.0).** Use `RECORD_GUIDE_v2.0.md` (adds reviews, exceptions, overrides, authority_mode). Body preserved unaltered below.

# One record, reused—not a new form for every edit
Fill the project template or map equivalent existing fields. Empty template is deliberately not a pass.
- authorizations: {action, reference, active}; action values e.g. analyze, render, external_upload, publish.
- requirements: {id, source_ref, enforcement: mandatory|default|preference, applies_to, metric?, unit?, min?, max?, amendment_of?}. Require one effective row per id. Unresolved conflicts remain explicit; do not resolve by convenient code comment. Only actual numeric bounds use metric/min/max.
- creative.beats: {id, source_ref, information_change, picture, sound, text?, semantic_review: {status: reviewed|not_checked, reason}}. Source refs are provenance, not proof that a claim is true.
- outputs: {id, path, sha256, measurements: {metric:{value,unit,evidence_ref}}, checks: [{requirement_id,status:pass|fail|not_checked,output_sha256,method,scope,evidence_ref,reason?}]}. Every mandatory applicable requirement needs one row on every submitted output. Measurements are reports, not freshly reproduced by the contract checker.
- reviews: human/agent actual-export observations and limitations. Do not call automatic structure validation creative acceptance.
- learning_changes: {id, action: append|supersede, supersedes?}. Preserve prior versions.
Run: `python 06_system_improvement/04_components/evidence_contract.py PROJECT_ROOT RECORD.json --stage plan|delivery|publish`
Delivery checks records/evidence coverage; publish additionally needs active campaign+publish authority. It does not inspect rights, meaning, credentials, pixels or sound. A material unverified mandatory requirement remains held; diagnostics/preferences do not become hard gates.
