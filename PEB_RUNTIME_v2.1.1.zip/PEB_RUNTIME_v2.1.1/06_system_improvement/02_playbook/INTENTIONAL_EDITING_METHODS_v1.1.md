> **SUPERSEDED (banner added v2.1).** The active playbook is `INTENTIONAL_EDITING_METHODS_v1.2.md` (adds the brand-removal diagnostic line). Body preserved unaltered below.

# Practical editing playbook v1.1 — options, not quotas
(v1.1 adds: retired measurement methods, scope-decision storytelling cost, vary-or-omit clause. Changes marked.)

## Start with the experience
Choose an audience promise supported by the footage. The opening should offer specific action, contradiction, emotion, visual novelty or a comprehensible question. Do not delay useful footage with a generic silent title slide by default. Text-first, stills and silence remain valid when the material and reading need justify them.

## Methods and their failure tests
| Method | When it helps | Implementation focus | Reject or revise when |
|---|---|---|---|
| Scene-led joke/reveal | Source already has compelling setup and payoff | Speech-aware compression, action/reaction rhythm, clear context | Trimming removes the joke's mechanism or a new headline supplies no meaningful angle |
| Commentary / authored narrative | A supported observation changes how we see the evidence | Script around an actual contrast; use purposeful selects; leave space for proof | VO merely describes visible objects, claims personal use, or invents a generated result |
| Result-first / two-stage reveal | Immediate interest can coexist with a further reveal | Show enough to orient; preserve a second information change | Teaser spends the only payoff or falsely relocates an outcome |
| Comparison / split screen | Two things have a supported relationship | Match readable, relevant moments; control attention and competing sound | Pairing is arbitrary, both panels are too small, or juxtaposition invents shared knowledge |
| Motion graphics / annotations | A relationship, quantity, sequence or detail is otherwise hard to understand | Use real referents and timing; reveal hierarchy; retain context | Labels name the obvious or a fabricated interface masquerades as product evidence |
| Reframe / zoom | A meaningful face, object or action is too small | Check all selected movement on frames; preserve referents/subtitles; prefer a mixed layout when crop fails; budget the manual verification window | Tracking loses the subject, crop hides a qualification, or repeated zooms replace progression |
| VO + designed opening | A concise, credible lens makes the footage more interesting | Permission, factual support, natural phrasing, performance, pauses, intelligibility | Generic hype, fake testimony, competing dialogue, breathless constant speech |
| Native sound / pause / held reaction | Delivery, consequence or surprise needs time | Preserve complete response and meaningful ambience | It becomes dead travel or holds continue after information is exhausted |
| Captions / typography | Speech needs readable access or emphasis | Accurate phrasing, qualifiers, contrast, consistent hierarchy, phone-size review | Styled text conflicts with source subtitles, blocks action, or claims more than picture/audio supports |
| Audio transitions / effects | A meaningful action or contrast benefits | Whole speech, fades/room tone where appropriate, licensed sounds, measured final mix | Synthetic accents are applied at every cut or source dialogue is chopped to match picture |

Rhythm devices (punch-ins, pattern interrupts, reaction holds) are a menu with a vary-or-omit clause: omit any device that does not serve this clip; a clip with no punch-in and no interrupt still passes if its pacing serves its scene. A device checklist asked per clip becomes the next template.

## Scouting and scope
- A show title never approves a clip; scout the episode (frames + transcript/baked-sub evidence) before cutting. Saliency/auto reframe is a proposal, not a default — verify on frames before building.
- When scouting notes flag a candidate as the weakest fit, follow the flag or record an explicit override (record field: overrides + creative.fit_warning_override) before building. A warning built anyway, silently, is worse than no scout.
- A scope decision that protects discipline but costs storytelling (e.g. restricting to opening episodes when the stronger payoff is later) records its storytelling cost at the time, in the record — so the cost is a decision, not a surprise.
- Survey phases run before briefs; a brief freezes its pool. New material enters the next brief, not the running one, unless the operator explicitly orders a mid-batch re-scope and accepts the churn.

## Reference learning protocol
1. Record the observable opening, information changes, payoff, audio/visual responsibilities and brand bridge.
2. Performance is UNKNOWN unless a matching post and contextual analytics are supplied. A reference called 'working' is not causal proof.
3. Transfer the mechanism only if the new sources support it. 'I typed', 'I made this', 'playable' and time-spent claims need evidence.
4. Test one material hypothesis in an authorized pilot, not a stylistic clone batch.

## Phone and sound finishing
Inspect opening, busiest graphic state, important motion, all cut joins, reveal/reaction and mandatory ending on the encoded output. Readability depends on actual rendered size and platform UI, not nominal font size alone. Do not enlarge tiny landscape subtitles and call them legible without inspection. Avoid blur-pad text echoes and competing text blocks; layout choice is contextual, not a universal ban.
Measure final loudness/true peak when relevant, but do not normalize to a magic number to replace listening. Quiet LUFS alone does not establish unintelligibility. Preserve mix recipes/stems only when needed to reproduce consequential claims; a ducking ratio that exists only in the recipe is "built-as", not "verified-on-final".

### Retired measurement methods (wrong on arrival; master prompt §9 carries the rationale)
- Full-file audio bitrate as a gate when a silent end card dilutes it → measure the content region; quote full-file only as a diluted reference.
- Volume-floor detector output as proof of card silence → judge silence on decoded PCM.
- Mono-downmix true peak → measure true peak on the actual channel layout, oversampled as the campaign requires.
- Loudness normalization applied after an output-side trim → trim first, then measure/normalize the region that counts.
Quote the method string beside every figure (content-only / atrim / stereo-oversampled / PCM), with units. Re-measure before re-encoding when a measurement is disputed.

## Fast creative regression questions
- With the headline removed, is there still a coherent experience? If not, is the text genuinely adding an authored idea or concealing arbitrary footage?
- Does each caption refer to the visible/heard content at that time?
- What happens before the sales card that actually pays the opening off?
- Is the brand bridge truthful and relevant without fake app evidence?
- Would removing a graphic improve clarity? Would adding one solve a specific comprehension gap?
- Does the final sound support the idea? Which parts were actually heard versus inferred?
These questions guide judgment. They are not automatic pass/fail taste rules.
