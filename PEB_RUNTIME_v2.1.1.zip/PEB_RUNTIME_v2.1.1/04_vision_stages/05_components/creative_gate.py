#!/usr/bin/env python3
"""Creative decision-record validation, not a taste score or automatic approval."""
import argparse,json
from pathlib import Path
REQUIRED=('audience','angle','opening_picture_sound','promise','payoff','source_evidence','editorial_contribution','brand_connection','treatment_reason')
def validate(plan,phase='plan'):
 errors=[]
 if plan.get('trigger')=='routine_revision':
  if not plan.get('existing_approved_treatment'):errors.append('Routine revision must reference existing approved treatment')
  return errors
 if plan.get('trigger') not in ('new_pilot','substantive_creative_reset'):errors.append('Declare a valid gate trigger')
 options=plan.get('treatments',[]);routes={t.get('route') for t in options}
 for route in ('scene_led','narrative_led','demonstration_led'):
  if route not in routes:errors.append('Missing route consideration: '+route)
 for t in options:
  if t.get('status') in ('unavailable','requires_permission') and not t.get('reason'):errors.append('Missing limitation reason: '+str(t.get('id')))
  if t.get('status') not in ('feasible','unavailable','requires_permission'):errors.append('Invalid feasibility status')
  if t.get('status')!='unavailable':
   for key in REQUIRED:
    if not t.get(key):errors.append('Missing '+key+' in '+str(t.get('id')))
 selected=next((t for t in options if t.get('id')==plan.get('selected_treatment_id')),None)
 if not selected or selected.get('status')=='unavailable':errors.append('Select an evidenced non-unavailable treatment for planning')
 if not plan.get('selection_reason'):errors.append('Missing selection rationale')
 if not plan.get('storyboard'):errors.append('Selected storyboard required')
 for beat in plan.get('storyboard',[]):
  for key in ('beat_id','picture','sound','viewer_understanding','source_or_asset','treatment_reason'):
   if not beat.get(key):errors.append('Storyboard beat missing '+key)
 if phase=='render':
  if not plan.get('execution_authorized'):errors.append('No recorded render authorization')
  if selected and selected.get('status')!='feasible':errors.append('Selected treatment still requires permission')
  if not plan.get('permission_clearance_reference'):errors.append('Missing scope/permission reference')
  if plan.get('unresolved_execution_permissions'):errors.append('New execution permissions unresolved')
 return errors
def main():
 p=argparse.ArgumentParser();p.add_argument('plan',type=Path);p.add_argument('--phase',choices=['plan','render'],default='plan');a=p.parse_args();e=validate(json.loads(a.plan.read_text()),a.phase)
 print(json.dumps({'record_valid':not e,'errors':e,'scope':'Decision/permission record structure only; not creative quality, factual truth or campaign approval'},indent=2));return bool(e)
if __name__=='__main__':raise SystemExit(main())
