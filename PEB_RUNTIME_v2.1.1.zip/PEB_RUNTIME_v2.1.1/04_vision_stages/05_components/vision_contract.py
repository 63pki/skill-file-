#!/usr/bin/env python3
"""Validate downstream use of evidence; never change timelines or promote model findings to passes."""
import argparse,json
from pathlib import Path
V3_IDS=['hook_presence','pacing_coherence','caption_visual_match','visual_defects','mandatory_elements']
def check_pointer(x,base,errors,label):
 if not isinstance(x,dict):errors.append(label+': missing evidence record');return None
 if x.get('status')=='not_checked':
  if not x.get('reason'):errors.append(label+': missing fallback reason')
  return None
 p=x.get('artifact')
 if not p:errors.append(label+': missing artifact');return None
 try:a=json.loads((base/p).read_text())
 except Exception:errors.append(label+': artifact unreadable');return None
 if a.get('status')!='model_returned':errors.append(label+': claimed evidence but adapter did not return usable evidence')
 checks=(a.get('structured_answer') or {}).get('checks',[])
 if any(c.get('finding') not in ('supported','contradicted','uncertain','not_applicable') for c in checks):errors.append(label+': malformed model finding; cannot consume as checked evidence')
 if not a.get('input') or not a.get('invocation') or not a.get('questions') or not a.get('final_answer_verbatim'):errors.append(label+': incomplete reproducibility record')
 return a
def validate(record,base,phase="structure"):
 errors=[]
 if phase in ('paper_edit','delivery') and not record.get('paper_edit'):errors.append('paper_edit required at this phase')
 if phase=='delivery' and not record.get('deliverables'):errors.append('actual deliverables required at delivery')
 sources={s['source_id']:s for s in record.get('vision_sources',[])}
 for sid,s in sources.items():
  a=check_pointer(s.get('vlm_scan'),base,errors,'V1 '+sid)
  if a and a.get('mode')!='pre_edit':errors.append('V1 artifact mode mismatch '+sid)
  if a and s.get('sha256') and a.get('input',{}).get('kind')=='video' and a['input'].get('sha256')!=s['sha256']:errors.append('V1 source hash mismatch '+sid)
 for beat in record.get('paper_edit',[]):
  sid=beat.get('source_id');s=sources.get(sid)
  if not s:errors.append('paper_edit references source without V1/fallback record');continue
  if s.get('vlm_scan',{}).get('status')=='model_returned' and beat.get('scan_artifact')!=s['vlm_scan'].get('artifact'):errors.append('paper_edit does not consume its V1 artifact')
  b=beat.get('boundary_verification',{})
  if b.get('status')=='verified' and (not b.get('method') or not b.get('evidence') or b.get('method','').lower() in ['vlm','nvidia','model']):errors.append('model timestamps alone cannot verify boundaries')
  if not b.get('status'):errors.append('boundary status absent')
 for cap in record.get('caption_plan',[]):
  if cap.get('role')=='authored_visible_claim':
   a=check_pointer(cap.get('caption_check'),base,errors,'V2 '+cap.get('id','?'))
   if a and a.get('mode')!='caption_check':errors.append('V2 artifact mode mismatch')
  elif not cap.get('visual_agreement_reason'):errors.append('caption needs role/visual-check applicability reason')
 for d in record.get('deliverables',[]):
  a=check_pointer(d.get('vlm_qc'),base,errors,'V3 '+d.get('id','?'))
  rows={r.get('check'):r for r in d.get('visual_qc_rows',[])}
  for cid in V3_IDS:
   r=rows.get(cid)
   if not r:errors.append('missing V3 delivery row '+cid);continue
   if r.get('status') not in ['pass','fail','not_checked','not_applicable']:errors.append('invalid QC status '+cid)
   if r.get('status')=='not_checked' and not r.get('reason'):errors.append('missing not_checked reason '+cid)
   if r.get('status') in ['pass','fail'] and (not r.get('method') or not r.get('scope') or not r.get('evidence')):errors.append('QC claim lacks method/evidence/scope '+cid)
   if r.get('status')=='pass' and r.get('scope')=='all_frames' and r.get('method')=='VLM':errors.append('VLM cannot certify all-frame coverage')
   if r.get('status')=='pass' and 'vlm' in r.get('method','').lower() and record.get('purpose')!='synthetic_fixture_test' and record.get('vision_workflow',{}).get('capability_status') not in ('FEATURE-TESTED','APPROVED-FOR-PROJECT'):errors.append('untested VLM capability cannot supply a production QC pass')
  if a and a.get('mode')!='post_render_qc':errors.append('V3 artifact mode mismatch')
  if a and a.get('input',{}).get('sha256')!=d.get('sha256'):errors.append('V3 analyzed a different file hash')
 return errors
def main():
 p=argparse.ArgumentParser();p.add_argument('record',type=Path);p.add_argument('--phase',choices=['structure','paper_edit','delivery'],default='delivery');a=p.parse_args();errors=validate(json.loads(a.record.read_text()),a.record.parent,a.phase)
 print(json.dumps({'contract_valid':not errors,'errors':errors,'note':'Structure and evidence linkage only, not artistic, rights, language, or performance approval'},indent=2));return bool(errors)
if __name__=='__main__':raise SystemExit(main())
