# IM-VISION-01 — shared NVIDIA evidence adapter
- Implementation: `05_components/vlm_scan.py`, standard-library Python client plus existing FFmpeg/ffprobe for proxy preparation.
- Contract: `scan(input_path, mode, questions, out, approval) -> artifact.json + invocation.json`, video <=60s or ordered frame list <=60 images over <=60s; video mode supplies aligned complete silent MP4 + WAV when audio exists.
- Reusable modes: V1/pre_edit, V2/caption_check, V3/post_render_qc. It does not implement ASR alignment, all-frame visual recognition, a compositor or an NLE.
- Consumption implementation: `05_components/vision_contract.py`, source/paper-edit, caption-plan and output-hash/QC linkage validator. No automatic timeline rewrites.
- Failure behavior: unavailable auth/approval/media bounds, provider failure, malformed answer, out-of-bounds model times -> not_checked; save sanitized final answer where available. Existing evidence preserved; max two attempts, finite shared batch request budget.
- Offline tests: `tests/test_contracts.py` and `tests/offline_tests.log`. Mock responses are not NVIDIA integration evidence.
- Live fixture and reference results: `BUILD_RESULT.md`, `fixtures/FIXTURE_VERDICT.json`, per-invocation artifacts and request IDs. Runtime tested scope must be read, not inferred from this inventory entry.
- Existing scripts and catalogs preserved. This closes a specific evidence-pipeline gap, not all general video-editing capabilities.
