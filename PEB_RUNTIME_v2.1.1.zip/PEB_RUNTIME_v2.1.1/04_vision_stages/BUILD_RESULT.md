# Build result — executable V1/V2/V3 add-on, with honest test limits

## Completed
- Read the entire supplied 481-line brief and inspected all four actual attached reference drafts. Full decode checks succeeded; one-second contact sheets were viewed; actual file metadata/loudness and end-card stability candidates were measured.
- Executed four new NVIDIA joint audiovisual reference requests. They returned HTTP 200 but contained material errors; the source-backed review and rejected claims are preserved. No claimed performance success follows from those responses.
- Implemented one reusable video/ordered-frame adapter, V1/V2/V3 prompts, bounded failures and budget logging, downstream evidence-contract validation, project templates, registry/inventory/status records, synthetic fixtures and a paper freedom regression. The frozen original core and all original portable baseline files are preserved unchanged.
- Tested the adapter live in all three modes on two synthetic clips (six logical invocations). Dedicated V2 mismatch finding: **not checked / not passed**. V3 mismatch finding: **detected**. Overall fixture: **INCOMPLETE_NOT_PASSED**. See receipts, not an assumed green check.

## What the test does NOT establish
The model's action/time descriptions are not frame-accurate: V1 reported the actual 2.0-second end-card transition at 1.5 seconds (and 1.12 seconds in the other clip). The dedicated V2 mismatch request encountered two HTTP 503 responses and stopped; it was not an authentication rejection. That required fixture is not promoted to pass because another mode found the mismatch. V3 also mistook the false caption's red circle for the requested moving-object hook; that failed-hook judgement is rejected because the blue square is visibly present. The complete new capability remains INSTALLED; unproven/failed stages use scoped fallback. No new provider or further retry loop is proposed.

Twelve offline tests cover missing auth/approval, schema and time-bound failures, final-answer-only retention, evidence linkage, missing delivery rows, empty delivery, budget exhaustion and two-attempt ceiling. These are separate from real model comprehension tests. Transport success does not establish truthful captions, exact words, full language eligibility or human listening.

## Files and governance
- `01_master_prompt/PEB_VISION_STAGES_v1.0.md`: operative additive stage specification.
- `05_components/vlm_scan.py`, `vision_contract.py`: executable implementation.
- `09_project_templates/`: evidence pointers/roles/five V3 rows and OFF-by-default future approval template.
- `fixtures/`: two actual 3-second MP4s, selected source images, oracle, six live artifacts, local pixel measurements and verdict.
- `reference_review/`: full supplied brief (unverified advice), source identity manifest, contact sheets, exact sent derivative media, final model evidence and actionable learning report.
- `07_status/CORE_PATCH_LIST_PENDING.md`: four minimal tracked amendments supplied, **not applied to the frozen core**. Explicit module adoption is available through the new entry point and validator; no automatic background orchestration/NLE rewrite is claimed.

## Current project boundary
No new Cloudwhale/P02 production render, installation, batch or publication occurred. The latest Cloudwhale v02 output was described but not attached to this request, so this build does not claim V3 on that MP4. Existing project approvals and open rights/language/claim checks remain scoped; do not resurrect old stage blockers or manufacture new global ones.

## Why this is different from another prompt rewrite
The package now includes runnable shared review code, negative checks and reproducible evidence—not just a list of skills. It also separates the creative gap from the inspection gap: choose an evidence-backed promise, information progression and payoff before effects. Borrow test/contrast/escalation/story-explanation mechanisms only where their claims are true; reject invented personal use, unproved playability and guaranteed views. Actual engagement still requires actual audience evidence.
