# T-VISION — NVIDIA Nemotron Omni (one primary VLM)

Need: repeatable source/caption/final-output pixel evidence, not another effects engine.
Implementation: `05_components/vlm_scan.py`; alias `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning`; endpoint `https://integrate.api.nvidia.com/v1/chat/completions`. Hosted immutable model revision is not exposed. Frame input uses ordered images; video input sends silent MP4 plus corresponding complete WAV where present. Embedded MP4 audio handling is untested.

License/account class: ACCOUNT/CLOUD. Existing user approval covers supplied RexTrix project media and this explicit reference/fixture build; not other clients or an unrestricted new campaign. No local model/library install or fresh legal-terms clearance was performed. Future unapproved account/data use remains OFF pending G3/G4. No second VLM installed.

Four-state progression: DOCUMENTED (historical integration docs), INSTALLED (this exact client and existing media utilities present), FEATURE-TESTED only for passed scoped fixtures, APPROVED-FOR-PROJECT only within recorded operator scope after applicable tests. **Overall new three-stage capability currently: INSTALLED; fixture outcome: INCOMPLETE_NOT_PASSED.** `INCOMPLETE_NOT_PASSED` is a test outcome, not a fifth capability state.

Evidence date: 2026-10-29T09:28:05.426665+00:00. Fixture pointer: `fixtures/FIXTURE_VERDICT.json`; each invocation retains request ID, final answer, input hash/questions and limits. Offline tests and reference calls are separately recorded in `BUILD_RESULT.md` and `REQUEST_INDEX.json`.

Scope limits: observed blue-square/rightward action and ordinary caption agreement are narrow successful observations. Dedicated V2 negative check remains not_checked if unavailable; precise event/word times are NOT verified. Do not present the whole pipeline as feature-tested when one required fixture is incomplete. Fall back on available local source/claim review and disclose missing checks; no fabricated pass. No synthetic result clears campaign rights/language, intelligibility, humor, product truth or audience performance. On a contradictory output preserve it and resolve the actual source question, not a repeated generic summary.

Budget: this build ten logical calls, <=20 HTTP attempts, <=60 seconds/input call, max two attempts/call; actual counts in REQUEST_INDEX. Future project budgets and authorized source identities must be explicit. Preserve shared ledger across sessions. Credentials are runtime-only, stripped around edges, never logged or packaged. Sanitized final answer is retained, not hidden model reasoning/full HTTP response/payload.
