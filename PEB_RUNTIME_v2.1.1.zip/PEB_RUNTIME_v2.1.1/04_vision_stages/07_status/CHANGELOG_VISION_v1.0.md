# Additive vision integration changelog

- Added one shared NVIDIA adapter, ordered-frame/video input, three stage modes, sanitized final-answer evidence, provenance, bounded retries, explicit fallback and shared request budget.
- Added downstream source/paper-edit/caption/output evidence-contract validation and negative tests.
- Added module implementing V1, V2, V3 and four PENDING frozen-core insertion patches; no baseline core/file silently overwritten.
- Added project-record template with V1/V2/V3 pointers, caption roles, boundary evidence and five V3 delivery rows; existing template preserved.
- Added registry/inventory cards, fixture clips/oracle/prompts/live artifacts and honest fixture verdict, FRT paper regression and offline test logs.
- Read the entire supplied pasted text and inspected four actual supplied reference drafts, retaining source identities, sampled contact sheets, decode/loudness evidence and new NVIDIA answers. Extracted transferable mechanisms; rejected unsupported metrics, misleading personal claims and universal effects/loop mandates.
- Preserved original PEB portable v1.1.1 and earlier continuity records as historical; added a newer entry point rather than silently changing old project approval states.
- Credential/payload/internal-reasoning artifacts are excluded. Historical tests and latest build limitations are distinguished in BUILD_RESULT.md.
