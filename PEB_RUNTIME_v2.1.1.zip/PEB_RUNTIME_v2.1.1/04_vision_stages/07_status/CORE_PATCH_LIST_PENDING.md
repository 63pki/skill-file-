# Minimal frozen-core patches — PENDING application

The baseline core bytes are preserved. The module is usable alongside it by explicit adoption; these insertions are **not claimed applied**. No rule tiers are changed. Do not create a replacement master prompt.

1. **§5 source-index list**, after “and clean edit handles.” append: “Record `vlm_scan` artifact pointer, scope and status (or `not_checked` reason) under the adopted vision module.”
2. **§5 before `MOMENT SELECTION [MOM-1..4`**, insert `5-V VISION SCAN`: “When this module is adopted, run V1 after technical inspection and before moment selection. Candidate cards/paper edits cite the scan or scoped fallback. Model times are estimates; consequential cut boundaries require source-frame/PTS and appropriate speech evidence. Preserve operator/model conflicts. Apply `PEB_VISION_STAGES_v1.0.md` V1 and its evidence contract.”
3. **§11 after CAPTIONS paragraph**, before `INHERITED (SOURCE-BAKED) DEFECTS`: “Run V2 for authored captions/overlays making claims about visible content. Record visual-agreement status/evidence; distinguish transcript truth, offscreen narration and literal visible claims. Resolve supported mismatches by review, not model authority. Apply module V2; unavailable checks record reasons.”
4. **After §15.8 severity paragraph, before `16. VARIETY`**, insert `15.9 POST-RENDER VISUAL VERIFICATION`: “For each actual output hash run module V3 after technical checks. Retain five scoped rows: hook presence, pacing coherence, caption-visual match, visual defects, mandatory elements. Model evidence is provisional, not exact all-frame/speech/rights/performance verification. Existing §15.7 severity and §15.8 private-draft/human-review routing stand. No automatic timeline rewriting or unauthorized rerender.”

Required adoption record: core hash, module hash/version, project activation and permissions. Run evidence-contract validation and FRT. A future core merge must log these four amendments and retain the original baseline.

5. Proposed §6 insertion (PENDING): at new pilot/substantive reset apply CREATIVE_TREATMENT_GATE_v1.0, compare source-supported routes and one selected storyboard before rendering. Routine revisions reuse existing decisions. No automatic VO permission, tool quota or new tier.
