**v1.3.2 creative update:** read `../00_continuation/CREATIVE_TREATMENT_GATE_v1.0.md`. New pilots/substantive creative resets compare distinct routes and produce one selected storyboard before rendering. No new voiceover or render permission is granted.

**v1.3.1 rule update:** read `../00_continuation/AGENT1_LESSONS_AND_ROUTING_RULES_v1.0.md` first. Prefer an available suitable approved vision route; otherwise use the tested NVIDIA fallback and existing adapter. This archive contains no API key. No fixture outcome or production authorization was upgraded.

# V1 / V2 / V3 — executable PEB add-on

**Purpose:** add consistent source-vision, caption-claim and final-render review to the existing PEB system. It does not replace the core, select effects by quota, promise views, or silently approve footage.

## Read order (once)
1. `BUILD_RESULT.md` — actual tests, limitations and current state.
2. `01_master_prompt/PEB_VISION_STAGES_v1.0.md` — stages, evidence rules and fallback.
3. `reference_review/REFERENCE_LEARNING_AND_DECISIONS.md` — lessons from all four attached drafts and the complete pasted brief.
4. Registry/inventory and `07_status/CORE_PATCH_LIST_PENDING.md` — adoption and frozen-core boundary.
Then use the existing core and creative-direction addendum; do not regenerate them.

## Execute an already-authorized stage
Existing Python 3, FFmpeg/ffprobe and libx264 are required; Pillow is required only to regenerate fixture pictures. No pip/npm/model installation is performed. Set `NVIDIA_API_KEY` in the process environment using the available authorized runtime mechanism. A value absent in a fresh session is not an authentication failure. Do not copy keys into archives, prompts, receipts or replies.

```sh
python 05_components/vlm_scan.py \
  --input /path/to/authorized_span.mp4 --mode pre_edit \
  --questions prompts/pre_edit.txt --approval /path/to/project_approval.json \
  --out /path/to/new_unique_scan_directory
python 05_components/vision_contract.py /path/to/PROJECT_RECORD.json
```

The approval template defaults OFF; do not overwrite an existing scoped approval with it. Record the existing authorization in a project-specific copy, allowed source hashes/scope and finite request budget. The sibling `.budget.json` is the shared attempt ledger; retain it across resumes, do not reset it to evade limits. This build's signed-off scope is in `approval_this_build.json`, not a transferable approval for other client material. Source paths in historical invocation logs describe the tested session; source/fixture hashes, original attachments and proxy files permit reconstruction. When moved, use the current local path while verifying the recorded source identity.

Input video must be <=60 seconds. For longer sources extract approved intervals and record original offsets/context. Ordered frames use JSON `{ "duration_seconds": 3, "frames": [{"path":"frame.png", "time_seconds":0}] }` with paths relative to that JSON; this is sampled visual-only evidence. Do not pretend silence in a visual-only request proves there was no source speech.

Adapter exit 0 = schema-valid **model evidence returned**, not QC passed. Exit 2 = not_checked/failure with saved reason. Existing output directories are never overwritten. At most two HTTP attempts per invocation, with bounded transient retry. Tests with a mock transport explicitly say MOCK and do not count as live verification.

## Next editing action, not another system rewrite
For an authorized project: attach V1 evidence to candidate moments, choose one source-supported concept using the creative brief and relevant reference mechanism, validate caption claims with V2 when applicable, render within the user's existing scope, then run technical QC and V3 on that exact output. Hand off the file plus concise evidence-scoped findings. Preserve originals/versions and missing checks. No further production render, installation, batch or publication was performed by this build.
