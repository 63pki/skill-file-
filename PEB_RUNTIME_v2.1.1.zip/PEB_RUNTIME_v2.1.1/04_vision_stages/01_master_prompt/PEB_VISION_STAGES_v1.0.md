# PEB — Vision-verified stages v1.0 (additive; evidence-scoped)

## Authority, activation and what this fixes
Read alongside the preserved v3.1.1 TEST FREEZE core, tool registry and creative-direction addendum. The frozen core is not rewritten. Exact proposed §5/§11/§15.9 insertions are in `07_status/CORE_PATCH_LIST_PENDING.md`; applying them remains PENDING. This module is executable through the adapter and evidence contract, not an automatically patched NLE or autonomous timeline engine. Projects adopting this module use the new project record and run the contract validator at paper edit and delivery. No baseline gate or tier is silently changed.

Previous work did inspect pixels. The missing capability was a consistent, reproducible **pre-edit → caption → actual-export** evidence path and downstream consumption. More vision calls alone do not supply creative direction, honest product evidence or an audience result.

## Common adapter contract
`05_components/vlm_scan.py`: `scan(input_path, mode, questions, out, approval) -> artifact + invocation JSON`.
Modes: `pre_edit`, `caption_check`, `post_render_qc`. Input is a <=60-second video or an ordered frame manifest with explicit relative times (<=60 images, <=60 seconds). Longer material must be segmented explicitly; record global offsets, gaps and context handles outside the adapter. Never concatenate noncontiguous moments and pretend their times refer to the source.

NVIDIA Nemotron Omni is the one primary implementation, using the existing approved endpoint. For video, the adapter prepares the complete interval as silent H.264 plus separate 16kHz mono WAV when sound exists, in the same request. Embedded MP4 soundtrack handling remains untested. Frame-list mode is visual-only. Inputs are resized, not guaranteed frame-complete model perception. Provider internal sampling and immutable model revision are not exposed. A successful HTTP response is not transcription or exact-time verification.

Every invocation retains source/proxy hashes, preparation commands, times/durations, model alias, endpoint, actual questions/system prompt, final-answer verbatim, parsed final answer, request ID, HTTP attempts and returned usage. **Verbatim means final answer, not private reasoning, full raw provider response, authorization header or base64 payload.** Never save credentials. The adapter refuses redirects and keeps at most two attempts per logical call; malformed or contradictory evidence is surfaced, not repaired with an unlimited same-model loop. Errors/refusals/timeouts/unparseable answers = `not_checked` with reason. HTTP success with unusable output is not a pass.

Use a per-batch approved call/request budget. This build authorizes four supplied references plus two synthetic fixtures across three stages: ten logical calls, at most twenty HTTP attempts; no unlimited subsequent production usage. New projects record endpoint/model, allowed sources/hashes, privacy/terms authorization, cost/token budget when available and expiry/scope. Existing approval is reused within its scope; do not repeatedly ask permission for the same authorized action. An unset credential is an execution issue, not proof of rejected authentication; accept a runtime environment value with surrounding whitespace stripped, never fabricate a credential. Other providers/checker models are not installed or called by this module.

## V1 — end of §5 inspection, BEFORE moment selection / paper edit
1. After technical capture, call `pre_edit` for every **candidate actually under consideration**, respecting the batch budget. Include context, not just the desired cut. Ask for scene estimates, observable action/reveals/reactions and up to 3–5 genuine opening candidates where present, all visible text/locations, artifacts/watermarks/readability risks and uncertainty. Inferred emotions/causality are labeled inference. Do not force 5 hooks from weak material.
2. Link `<source_id>.vlm_scan.json` (adapter artifact may be copied under this name unchanged) and status in the source index. Record model-relative times and source interval offset separately.
3. Candidate cards and paper edit cite the scan artifact plus observation, or a scoped `not_checked` fallback. **Model timestamps are suggestions, never “VLM-verified” cut boundaries.** Verify consequential action edges against actual decoded frames/PTS; verify meaningful speech boundaries through an appropriate audio-aware route, preserving uncertainty. A picture cut or quiet waveform alone cannot certify complete words.
4. If operator, ASR, local pictures and model differ, record the values and evidence side-by-side. Resolve with the source where possible; escalate only the unresolved material span. Do not silently prioritize the model or discard the operator's time.
Fallback: keep available metadata, ASR, sampled/manual pixel inspection and audio measurements, label their actual coverage. `vlm_scan: not_checked (reason)` is acceptable, not a hidden approval or a default excuse to stop all authorized private work.

## V2 — append to §11, before caption/overlay lock
Captions retain transcript accuracy and source-to-output mapping. Additionally, **authored claims about visible content** must be checked against the relevant pictures/context. Batch only the relevant short spans in `caption_check`, not the entire library.
- Record caption ID/text, role, source/output span, source evidence, model quote/finding and agreement status.
- Spoken subtitles, offscreen speech, irony, metaphor and narrative description do not need a literal pictured referent at every instant. Separate dialogue accuracy from an authored on-screen factual claim; explain applicability rather than forcing a mismatch.
- A model disagreement triggers review of the caption AND its timing/context; the model is not automatically correct. On a supported material contradiction revise the authored claim or timing, not fabricate footage to fit it.
- Product capability, authorship (“I typed/made/tested”), timing/speed and personal experience require actual independent provenance/test evidence. Cinematic footage is not proof. VLM agreement cannot clear truth, language or rights.
Fallback: per-caption `not_checked` + reason; no invented caption text or assumed pass. Plain captions are conditional on comprehension, not a forced style/word-count preset.

## V3 — proposed §15.9, actual encoded file after technical checks, BEFORE release/delivery
Analyze the **delivered file hash**, not source or storyboard. Technical failures route to existing §15.3; a private provisional draft remains governed by §15.8, not a new automatic render veto.
Run `post_render_qc` and retain five rows per output:
1. `hook_presence`: intended opening content actually visible. Presence ≠ interest or retention.
2. `pacing_coherence`: observable information progression/cut relationships. Taste diagnostic (Tier 3); do not auto-rewrite the timeline. A/V assistance cannot certify exact mid-word safety from rough model times.
3. `caption_visual_match`: authored material claims on the FINAL render, with V2 references and transcript review kept distinct.
4. `visual_defects`: observed overlaps, unreadable text, unintended blanks/holds. Intentional silence, freeze frames or black branded cards are not defects merely because detected.
5. `mandatory_elements`: actual mandatory branding/CTA readable in the sampled pictures. Exact complete 4.5-second hold on every frame needs a separate all-frame/local check, not a model guess.
Each row: `pass | fail | not_checked | not_applicable`, method + invocation, evidence quote/artifact, exact scope/coverage and reason where missing. A provisional model-supported observation may support a scoped diagnostic, never “human listened,” “all frames clean,” full language clearance, approved rights or predicted performance. Separate local all-frame/PTS/frame-count/glyph/contrast checks where performed; no model can certify an unseen one-frame flash. A material contradiction confirmed by review follows existing Major/Critical rules; unreadable mandatory elements remain release-blocking. Pacing opinions do not acquire a new hard tier.
If revision is justified, propose itemized changes within existing authorization; do not auto-render. Re-run V3 on a revised file only when authorized; at most two revision cycles, then surface the precise unresolved issue for review. Do not make two revisions mandatory.

## Downstream consumption / reproducibility
`05_components/vision_contract.py PROJECT_RECORD.json` checks V1 pointers in paper edits, authored-claim V2 records, all five V3 rows, output-hash identity and methods for any asserted pass/fail. It rejects a bare VLM boundary “verification.” It does not establish creative quality or auto-clear release. See example record and tests. Run before paper-edit approval and final handoff; record contract failure rather than silently removing evidence fields.

## Creative use — references are a library, not universal orders
Read `reference_review/REFERENCE_LEARNING_AND_DECISIONS.md`. Choose one source-supported viewer promise and a meaningful payoff, then an applicable reference mechanism (test/proof, contrast, escalating discovery, explained story). Tools/skills are selected for the communication gap. No mandatory zooms, captions, split-screen, VO, silence ban, opening slide, beat-cut quota, ragebait or forced loop. Do not claim “working” or “million-view” templates without an actual post and analytics. Private source edits, campaign approval and audience performance stay separate.

## Regression freedom
The uninterrupted slow reveal, wordless visual moment and lightly treated dialogue joke remain legal when the campaign permits them. V1 can report no text, V2 can be not applicable, V3 can describe an intentional hold. Missing model confidence does not force decoration. See `tests/FREEDOM_REGRESSION.md`.

## Current fixture gate
Read `fixtures/FIXTURE_VERDICT.json` before adoption. The complete new capability is INSTALLED, fixture INCOMPLETE_NOT_PASSED: the dedicated V2 mismatch request stopped after two HTTP 503 responses. V1/V3 did flag the wrong caption, but V3 also misinterpreted the requested hook and model times were inaccurate. Until the missing/failed fixture needs are resolved, use scoped fallback and do not cite this new capability as a verified production QC pass. The existing authorized NVIDIA route remains available for provisional source evidence; this does not grant its output authority or revoke prior scoped user permission.
