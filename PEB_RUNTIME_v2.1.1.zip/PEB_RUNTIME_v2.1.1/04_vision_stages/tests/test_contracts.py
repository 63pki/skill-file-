import sys,json,tempfile,unittest,os
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'05_components'))
from vision_contract import validate,V3_IDS
from vlm_scan import scan,MODEL,ENDPOINT
class Tests(unittest.TestCase):
 def setup_input(self,d):
  (d/'frame.png').write_bytes(b'test fixture transport only; not sent externally')
  (d/'frames.json').write_text(json.dumps({'duration_seconds':3,'frames':[{'path':'frame.png','time_seconds':0}]}))
  (d/'approval.json').write_text(json.dumps({'upload_authorized':True,'model':MODEL,'endpoint':ENDPOINT,'max_attempts_per_call':2,'max_http_requests':2}))
 def test_missing_credential(self):
  with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{},clear=True):
   d=Path(t);self.setup_input(d);r=scan(d/'frames.json','pre_edit','describe',d/'out',d/'approval.json');self.assertEqual(r['status'],'not_checked');self.assertEqual(len(r['attempts']),0)
 def test_approval_off(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);self.setup_input(d);(d/'approval.json').write_text('{}');r=scan(d/'frames.json','pre_edit','describe',d/'out',d/'approval.json');self.assertEqual(r['reason'],'no_matching_upload_approval')
 def mocked_response(self,content):
  class Response:
   status=200;headers={'NVCF-REQID':'MOCK-NOT-EXTERNAL'}
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def read(self):return json.dumps({'id':'mock','choices':[{'finish_reason':'stop','message':{'content':content,'reasoning_content':'DO NOT SAVE INTERNAL REASONING'}}]}).encode()
  class Opener:
   def open(self,*a,**k):return Response()
  return Opener()
 def run_mock(self,text):
  with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'NVIDIA_API_KEY':'test-runtime-value'}),patch('urllib.request.build_opener',return_value=self.mocked_response(text)):
   d=Path(t);self.setup_input(d);r=scan(d/'frames.json','pre_edit','describe',d/'out',d/'approval.json');self.assertNotIn('DO NOT SAVE INTERNAL REASONING',(d/'out/artifact.json').read_text());return r
 def test_malformed_answer(self):self.assertEqual(self.run_mock('not JSON')['status'],'not_checked')
 def test_schema_failure(self):self.assertEqual(self.run_mock(json.dumps({'observations':[],'checks':[{'id':'x','finding':'unsupported','evidence':'x'}],'gaps':[]}))['status'],'not_checked')
 def test_out_of_bounds(self):self.assertEqual(self.run_mock(json.dumps({'observations':[{'start':4,'end':5}],'checks':[],'gaps':[]}))['status'],'not_checked')
 def test_verbatim_and_no_reasoning(self):
  text='{"observations":[],"checks":[],"gaps":["mock only"]}';r=self.run_mock(text);self.assertEqual(r['status'],'model_returned');self.assertEqual(r['final_answer_verbatim'],text)
 def test_no_bare_vlm_boundaries(self):
  r={'vision_sources':[{'source_id':'x','vlm_scan':{'status':'not_checked','reason':'offline'}}],'paper_edit':[{'source_id':'x','boundary_verification':{'status':'verified','method':'VLM','evidence':'estimated time'}}]};self.assertTrue(validate(r,Path('.')))
 def test_fallback_with_reason(self):
  rows=[{'check':cid,'status':'not_checked','reason':'offline'} for cid in V3_IDS]
  r={'vision_sources':[{'source_id':'x','vlm_scan':{'status':'not_checked','reason':'offline'}}],'deliverables':[{'id':'x','vlm_qc':{'status':'not_checked','reason':'offline'},'visual_qc_rows':rows}]};self.assertFalse(validate(r,Path('.')))
 def test_missing_delivery_rows(self):self.assertTrue(validate({'deliverables':[{'id':'x','vlm_qc':{'status':'not_checked','reason':'offline'}}]},Path('.')))
 def test_empty_delivery_rejected(self):self.assertTrue(validate({},Path('.'),'delivery'))
 def test_budget_exhausted_without_call(self):
  with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'NVIDIA_API_KEY':'test-runtime-value'}):
   d=Path(t);self.setup_input(d);a=json.loads((d/'approval.json').read_text());a['max_http_requests']=0;(d/'approval.json').write_text(json.dumps(a))
   r=scan(d/'frames.json','pre_edit','describe',d/'out',d/'approval.json');self.assertEqual(r['reason'],'batch_request_budget_exhausted');self.assertFalse(r['attempts'])
 def test_two_attempt_limit(self):
  import urllib.error
  class BadOpener:
   def open(self,*a,**k):raise urllib.error.HTTPError('https://example.invalid',500,'test',{},None)
  with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'NVIDIA_API_KEY':'test-runtime-value'}),patch('urllib.request.build_opener',return_value=BadOpener()),patch('time.sleep'):
   d=Path(t);self.setup_input(d);r=scan(d/'frames.json','pre_edit','describe',d/'out',d/'approval.json',max_attempts=99);self.assertEqual(len(r['attempts']),2);self.assertEqual(r['status'],'not_checked')
if __name__=='__main__':unittest.main()
