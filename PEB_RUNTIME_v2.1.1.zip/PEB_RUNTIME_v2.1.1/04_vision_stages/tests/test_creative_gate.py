import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'05_components'))
from creative_gate import validate,REQUIRED
class CreativeGateTests(unittest.TestCase):
 def plan(self):
  treatments=[dict(id='A',route='scene_led',status='feasible',**{k:'EXAMPLE evidence record, not real footage' for k in REQUIRED}),dict(id='B',route='narrative_led',status='requires_permission',reason='new VO',**{k:'EXAMPLE' for k in REQUIRED}),dict(id='C',route='demonstration_led',status='unavailable',reason='no actual product test')]
  return dict(trigger='new_pilot',treatments=treatments,selected_treatment_id='A',selection_reason='example',storyboard=[dict(beat_id='b',picture='example',sound='original',viewer_understanding='example',source_or_asset='example',treatment_reason='example')])
 def test_empty_rejected(self):self.assertTrue(validate({}))
 def test_honest_unavailable_route_allowed(self):self.assertFalse(validate(self.plan()))
 def test_pending_vo_not_renderable(self):
  p=self.plan();p.update(selected_treatment_id='B',execution_authorized=True,permission_clearance_reference='existing scope');self.assertTrue(validate(p,'render'))
 def test_routine_revision_no_restart(self):self.assertFalse(validate(dict(trigger='routine_revision',existing_approved_treatment='saved approved storyboard')))
 def test_render_authorization_required(self):self.assertTrue(validate(self.plan(),'render'))
if __name__=='__main__':unittest.main()
