from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json,hashlib
import argparse
p=argparse.ArgumentParser();p.add_argument('--out',required=True,type=Path);a=p.parse_args();root=a.out;root.mkdir(parents=True,exist_ok=False)
font=ImageFont.truetype('/usr/share/fonts/msttcore/arialbd.ttf',26)
for label,text in [('match','BLUE SQUARE MOVES RIGHT'),('mismatch','RED CIRCLE MOVES LEFT')]:
 d=root/label;d.mkdir(exist_ok=True)
 for n in range(90):
  im=Image.new('RGB',(640,360),'#202020');dr=ImageDraw.Draw(im)
  if n<60:
   dr.text((35,28),text,font=font,fill='white');x=35+int(n*7.5);dr.rectangle((x,150,x+70,220),fill=(20,90,245));dr.text((35,290),f'FRAME {n:03d}',font=font,fill='white')
  else:dr.text((235,160),'TEST CARD',font=font,fill='white')
  im.save(d/f'f{n:03d}.png')
 subprocess.run(['ffmpeg','-v','error','-framerate','30','-i',str(d/'f%03d.png'),'-f','lavfi','-i','anullsrc=r=16000:cl=mono','-frames:v','90','-t','3','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-y',str(d/'fixture.mp4')],check=True)
 for f in d.glob('f*.png'):
  if int(f.stem[1:]) not in [0,15,30,45,60,75,89]:f.unlink()
 (d/'frames.json').write_text(json.dumps({'duration_seconds':3,'frames':[{'path':f'f{n:03d}.png','time_seconds':n/30} for n in [0,15,30,45,60,75,89]]},indent=2))
(root/'ORACLE.json').write_text(json.dumps({'both_clips':{'duration_seconds':3,'frame_count':90,'fps':30,'action':'blue square moves right in frames [0,60)','endcard':'TEST CARD in frames [60,90)','audio':'generated silence; no speech'},'match':'burned-in claim agrees with action','mismatch':'RED CIRCLE MOVES LEFT conflicts with blue square moving right','purpose':'limited synthetic visual recognition and caption contradiction fixture; no lip-sync/speech/creative/rights/general performance validation'},indent=2))
for mode,q in {'pre_edit':'Describe visible action, direction, color and shape, all readable text, approximate scene changes and gaps. Check id action_description: does the burned-in statement describe the depicted action? No audio transcription if silence.', 'caption_check':'Check id caption_agreement: Does the authored action description agree with visible shape, color and direction? Quote the on-screen statement and describe the action independently. Distinguish text from action; do not assume words on screen are true.', 'post_render_qc':'Check ids hook_presence (moving object visible near opening), caption_agreement (burned-in action claim versus visible action), visual_defects (obscured text or unexpected blanks), endcard_readability (TEST CARD present/readable near ending). Report approximate intervals, observations and gaps. Do not infer speech from silent audio or certify all frames.'}.items():(root/f'{mode}.txt').write_text(q)
