# Paper freedom-regression check
- Uninterrupted slow reveal: V1 can identify the continuous reveal; V2 not applicable if no authored visual claim; V3 records the intended hold as intentional. No forced cut/effect or model pacing score blocks it.
- Wordless visual moment: frame-only V1 is allowed, audio absent recorded, no invented transcript. V2 may be not applicable. Mandatory project branding/language rules still apply.
- Dialogue joke with minimal graphics: preserve setup/response/payoff/reaction; captions conditional on verified words and comprehension. VLM timing never authorizes a mid-word cut. No mandatory caption or effect template.
Verdict: no new tier or style rule obstructs these. This is a paper governance regression, not paired production renders or proof of taste improvement. Core freeze remains; real creative performance is untested.
