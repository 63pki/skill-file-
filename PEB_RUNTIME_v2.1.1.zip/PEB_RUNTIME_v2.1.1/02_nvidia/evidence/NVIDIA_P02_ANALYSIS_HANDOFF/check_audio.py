import sys,json,base64,time
from pathlib import Path
import requests
D=Path('/data/nvidia_p02_test');key=sys.stdin.readline().strip()
prompt='''Transcribe this entire 23.8-second audio recording. Do not describe pictures or guess story context. Return JSON with language, segments:[{start_seconds,end_seconds,speaker,words,uncertain_words}], and non_speech_intervals. Give best-effort verbatim words in chronological order through the END of the recording. No timestamps may exceed 23.8. Mark uncertainty instead of inventing repetition. If a phrase is repeated, transcribe it only if actually heard more than once. No summaries in place of dialogue. Do not output private reasoning.'''
payload={'model':'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning','messages':[{'role':'user','content':[{'type':'audio_url','audio_url':{'url':'data:audio/wav;base64,'+base64.b64encode((D/'analysis_audio.wav').read_bytes()).decode()}},{'type':'text','text':prompt}]}],'max_tokens':8192,'reasoning_budget':2048,'temperature':0.2,'top_p':0.95,'stream':False}
(D/'audio_only_prompt.txt').write_text(prompt)
t=time.monotonic()
try:
 r=requests.post('https://integrate.api.nvidia.com/v1/chat/completions',headers={'Authorization':'Bearer '+key,'Content-Type':'application/json','Accept':'application/json'},json=payload,timeout=(30,240))
 body=r.text.replace(key,'[REDACTED]');(D/'audio_only_response.json').write_text(body)
 meta={'http_status':r.status_code,'elapsed_seconds':round(time.monotonic()-t,2),'request_id':r.headers.get('NVCF-REQID'),'mode':'audio-only consistency check','model':payload['model']};(D/'audio_only_receipt.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta))
 if r.ok:
  d=json.loads(body);c=d['choices'][0]['message'].get('content','');(D/'audio_only_transcript.txt').write_text(c or '');print(c);print('USAGE',json.dumps(d.get('usage')))
 else:print(body[:1500])
except requests.RequestException as e:print(type(e).__name__)
finally:key=''
