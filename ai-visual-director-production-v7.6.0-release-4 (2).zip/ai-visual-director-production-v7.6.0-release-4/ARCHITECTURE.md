# AI Visual Director Production V7.6.0 Evidence Release Architecture

```text
SKILL.md                         compact mandatory kernel
rules/RUNTIME.md                 single runtime read; five authoritative bundles
rules/detailed/                  preserved deep sources; non-authoritative
templates/                       Registry, Binder, exploration, signature, silhouette, color, quality, proof, compilation
rules/production/                triggered mode-specific execution modules
adapters/generation/             Nano Banana and Veo 3.1 prompt ownership
adapters/hermes/                 Hermes enforcement and vision setup
adapters/canva/                  verified-surface operator adapters
adapters/capcut/                 verified-surface operator adapters
exports/                         production package export contract
dev/                             tests, validation, history, manifest
```

## Performance architecture

```text
DEPTH selects FAST / STANDARD / CONTROLLED ceremony
GATES group work into Direction / Design / Animatic / Asset / Motion / Delivery
COMPILER stores persistent locks once and emits compact shot deltas
BUDGET limits failed attempts and selects a fallback
PROOF validates representative motion before full motion work
COMPILATION creates one clean final production package
```

## Five runtime bundles

```text
CORE selects depth, mode, capability, and six-gate queue
PRODUCTION creates gate artifacts and compact prompt layers
DELIVERY plans audio/post and compiles the final package
EVIDENCE validates gates and release maturity
STATE preserves locks, attempts, dependencies, and handoff
```

No duplicate runtime authorities are allowed. Detailed sources remain for maintenance and deeper craft only.

## Quality architecture

```text
EXPLORE compares low-cost alternatives before lock
SIGNATURE rejects coherent but interchangeable direction
SILHOUETTE proves subject identity without detail
COLOR SCRIPT maps value/color progression across time
COMPOSITION TESTS design focal hierarchy and negative space
QUALITY CRITIC scores creative performance separately from compliance
```

Quality evidence enters Direction/Design, propagates through Animatic/Asset/Motion, and is rechecked at final compilation.

## Production architecture

```text
MODE ROUTER loads only the matching production module
VISUAL LOOP inspects exact asset versions and rechecks repairs
AUDIO LOOP separates deterministic analysis from actual listening
ADAPTER LAYER verifies mutable operator surfaces without polluting core
HUMAN CHECKPOINT records real audience/expert/client evidence
EXPORT ENGINE creates, validates, hashes, and packages files when host-capable
CONFLICT AUDIT protects preserved performance and quality architecture
```

V7.0 preserves V6.10 performance and V6.11 quality systems. Production modules and adapters are subordinate to the five-bundle runtime and cannot loosen evidence or maturity.

## Preferred generation stack protection

Nano Banana owns image prompts and continuity anchors. Veo 3.1 owns video/motion prompts. Operator adapters such as Canva and CapCut are optional post-production layers and cannot replace generation prompt deliverables.

## V7.1 cross-model control plane

The six-gate architecture is preserved internally. A Project Execution Contract declares intent, tool roles, and interaction mode. RUN-TO-BLOCKER compresses successful work to three normal approval surfaces. Gate Maturity Ledger, cross-gate lock diffs, measured-voice dependency, target-prompt completeness, evidence-media inventory, and two-pass archive validation prevent the failures observed in live V7.0 cross-model replays.

## V7.2 deterministic control plane

V7.2 compiles each brief into a Project Contract and Artifact Queue before drafting. The contract selects Guided Production, Single-Pass Blueprint, or Finished Production; assigns tool roles; freezes story/world/anatomy/timing locks; and sets the evidence ceiling. The actual output record is checked by deterministic semantic validators. Three V7.1 cross-model Milo failures are retained as executable fixtures. User-facing success remains compact; contracts and diagnostics are internal or packaged.

## V7.3 actual-output enforcement

The compact controller compiles a contract, actual Markdown/package extraction creates the Output Record, deterministic validation checks bodies/arithmetic/locks/files, and semantic review remains separately typed. Historical V7.2.1 authorities are preserved under `rules/history/`.

## V7.3.1 fail-closed bootstrap

The compiled contract selects hashed core and triggered authorities. An ordered context, detached receipt, contract binding, and unpredictable challenge-response are required before substantial output can validate.

## V7.4 Phase D validator quality

Canonical project indexing, multi-format metadata, evidence extraction, artifact schemas, anti-filler checks, gate ownership, duplicate/conflict detection, and unsupported-claim scanning supplement Phase A assurance.

## Phase C quality and usability

Phase C layers operator-ready artifacts, progressive disclosure, explicit reference resolution, decision trace, evidence-bound semantic review, and prioritized repair plans over preserved Phase A assurance and Phase B validator quality. Deterministic and semantic verdicts remain separate.

## Phase D external evidence

Phase D imports and validates external trial provenance, exact files/hashes, provider/model diversity, matched A-B pairs, blinded independent ratings, and six-gate pilot completion. Synthetic tests never count as live proof.
