# QUICKSTART — V7.4 Phase D

## Verified Runtime

1. Fill `templates/ROUTING_CONTRACT.json`.
2. Run `python3 bootstrap/bootstrap_runtime.py ROUTING_CONTRACT.json --outdir SESSION_DIR`.
3. Inject `SESSION_DIR/RUNTIME_CONTEXT.md` completely.
4. Compile the full Project Contract from `templates/PROJECT_CONTRACT.json` and set its `routingContractSha256` from the preload receipt.
5. Run `python3 bootstrap/finalize_contract_binding.py ROUTING_CONTRACT.json PROJECT_CONTRACT.json SESSION_DIR/PRELOAD_RECEIPT.json --outdir SESSION_DIR`.
6. Copy the final runtime marker into the actual output.
7. Validate with `python3 validators/compile_and_validate.py PROJECT_CONTRACT.json RESPONSE.md --runtime-receipt SESSION_DIR/FINAL_RUNTIME_RECEIPT.json`.

## Portable Assurance

Use `templates/PROJECT_CONTRACT_PORTABLE.json` only when verified execution is unavailable. Show `ASSURANCE: PORTABLE · RUNTIME NOT CRYPTOGRAPHICALLY VERIFIED · VALIDATOR NOT EXECUTED`; maximum PLAN-PASS. Do not claim generated, inspected, approved, or released media without real evidence.

## Phase C operator flow

1. Set `qualityPolicy` and `usabilityProfile` in the Project Contract.
2. Author each required artifact with acceptance, repair action, stable IDs, and executable steps.
3. Run `compile_and_validate.py`; inspect compact `STATUS.txt`, then `REPAIR_PLAN.json`.
4. Run the separate semantic review and pass it with `--semantic-review` when evidence is available.
5. Never turn an unavailable creative/media dimension into a numeric score.

## Phase D external evidence

1. Copy `templates/EXTERNAL_EVIDENCE_CAMPAIGN.json`.
2. Register each real external run with provider/model/version, prompt hash, response/media path and hash, execution date, operator, and `LIVE_EXTERNAL`.
3. Add blind independent rating records without exposing variant labels.
4. Run `validate_external_evidence.py CAMPAIGN.json --root EVIDENCE_ROOT`.
5. Never relabel synthetic fixtures or dry runs as live evidence.
