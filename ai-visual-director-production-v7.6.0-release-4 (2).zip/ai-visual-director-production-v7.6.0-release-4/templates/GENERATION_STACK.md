# Generation Stack Profile

```text
GENERATION STACK
Project/version:
Image generator: Nano Banana
Image surface/model display/tier/region/date:
Video generator: Veo 3.1
Video surface/model display/tier/region/date:
Image-to-video handoff method:
Reference and first/last-frame support status:
Native audio status:

OPTIONAL POST ONLY
Canva: requested YES/NO; role:
CapCut: requested YES/NO; role:
Other editor/assembler:

RULE
Do not substitute optional post tools for Nano Banana or Veo prompt deliverables.
```
