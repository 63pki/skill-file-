# Nano Banana and Veo 3.1 Prompt Markers

Every required image prompt is enclosed in a Nano block:

```text
<!-- AVD:NANO_PROMPT id=CHAR-MILO-v01 framework=NB-F1 -->
Create a canonical character model sheet.
Subject: CHAR-MILO-v01, visible construction and locked identity.
Action/state: neutral turnaround and approved expressions.
Location/context: clean model-sheet field.
Composition: full body, front/side/three-quarter views, readable negative space.
Style and rendering: approved Mode B shape, silhouette, line, palette, and flat material system.
Output: approved aspect/resolution or ASSUMPTION — VERIFY.
Acceptance: identity, part count, silhouette, palette, line, and expression tests.
Excluded elements: photorealism, extra parts, text, watermark.
<!-- /AVD:NANO_PROMPT -->
```

Every moving shot is enclosed in a Veo block:

```text
<!-- AVD:VEO_PROMPT id=S01-v01 mode=V-F2 -->
Use FRAME-S01-v01 as the exact starting composition and identity anchor.
Cinematography: wide eye-level composition; one slow rightward drift ending on Milo.
Subject: CHAR-MILO-v01 with all approved locks.
Action: Milo anticipates, rises, reacts, settles, and holds.
Context: WORLD-VILLAGE-v01, fixed geography, morning atmosphere.
Style and ambiance: approved Mode B line, palette, staging, and gentle pacing.
End state: stable readable pose with edit handle.
Audio route: EXTERNAL_AUDIO_ATTACHMENT.
Dialogue: NONE.
SFX: soft wake chime aligned to the rise.
Ambient noise: gentle morning air.
Music: NONE in generated clip.
Acceptance: identity, action, camera, endpoint, continuity, and audio tests.
Fallback: simplify action, shorten, re-anchor, or split the shot.
<!-- /AVD:VEO_PROMPT -->
```

Do not include editor menus, keyframes, layers, easing, or app-specific operations inside generation prompts.
