#!/usr/bin/env python3
"""Canonical active-release consistency checks for V7.6.0 Release 4."""
from pathlib import Path
import json,re,sys
ACTIVE_TEXT=['SKILL.md','ARCHITECTURE.md','rules/RUNTIME.md','validators/README.md','dev/BUILD_VALIDATION.md']
def add(rows,code,message,path=''):rows.append({'code':code,'message':message,'path':path})
def validate(root:Path):
 e=[]
 try:r=json.loads((root/'release/RELEASE.json').read_text())
 except Exception as x:return [{'code':'RELEASE_METADATA_PARSE','message':type(x).__name__+': '+str(x),'path':'release/RELEASE.json'}]
 version=str(r.get('version',''));reg=r.get('regressionCatalog',{});last=reg.get('lastId');required=reg.get('requiredCount')
 if version!='7.6.0':add(e,'ACTIVE_VERSION_DRIFT',f'release version {version}','release/RELEASE.json')
 if (reg.get('firstId'),last,required)!=(1,570,570):add(e,'ACTIVE_REGRESSION_RANGE_DRIFT',str(reg),'release/RELEASE.json')
 if r.get('engineeringMaturity')!='STRUCTURALLY_VALIDATED':add(e,'ENGINEERING_MATURITY_DRIFT',str(r.get('engineeringMaturity')),'release/RELEASE.json')
 if r.get('operationalMaturity')!='CONTROLLED_BETA':add(e,'OPERATIONAL_MATURITY_DRIFT',str(r.get('operationalMaturity')),'release/RELEASE.json')
 live=r.get('liveEvidence',{});expected={'liveCrossModelReplay':'NOT_RUN','nanoVeoABGeneration':'NOT_RUN','completeProductionPilot':'NOT_RUN','beginnerOperatorPilot':'NOT_RUN','audienceComprehensionReview':'NOT_RUN','externalEvidenceClaimed':False}
 if live!=expected:add(e,'LIVE_EVIDENCE_STATUS_DRIFT',str(live),'release/RELEASE.json')
 try:
  m=json.loads((root/'bootstrap/runtime_load_manifest.json').read_text())
  if m.get('packageVersion')!=version or m.get('schemaVersion')!=version:add(e,'RUNTIME_RELEASE_DRIFT',str({'packageVersion':m.get('packageVersion'),'schemaVersion':m.get('schemaVersion')}),'bootstrap/runtime_load_manifest.json')
 except Exception as x:add(e,'RUNTIME_MANIFEST_PARSE',type(x).__name__+': '+str(x),'bootstrap/runtime_load_manifest.json')
 try:
  dm=json.loads((root/'dev/MANIFEST.json').read_text())
  if dm.get('version')!=version:add(e,'DEV_MANIFEST_VERSION_DRIFT',str(dm.get('version')),'dev/MANIFEST.json')
  if dm.get('regressions') not in ('R1-R570','R1–R570'):add(e,'ACTIVE_REGRESSION_RANGE_DRIFT',str(dm.get('regressions')),'dev/MANIFEST.json')
 except Exception as x:add(e,'DEV_MANIFEST_PARSE',type(x).__name__+': '+str(x),'dev/MANIFEST.json')
 expected_tokens={'SKILL.md':['version: 7.6.0','Operational maturity:** CONTROLLED_BETA'],'ARCHITECTURE.md':['V7.6.0 Evidence Release Architecture'],'rules/RUNTIME.md':['V7.6.0'],'validators/README.md':['V7.6.0 Evidence Release'],'dev/BUILD_VALIDATION.md':['V7.6.0 Evidence Release','R1–R570']}
 stale=re.compile(r'R1[–-]R(?:320|340|420|450|460|470|490|530)|version:\s*(?:7\.4\.[234]|7\.5\.0)|(?:V7\.4\.[234](?: Final| Immediate Hotfix| Portability Release)|V7\.5\.0 Production-Breadth Release)|Final Cumulative Release|Final Generation Enforcement')
 for rel in ACTIVE_TEXT:
  p=root/rel
  if not p.is_file():add(e,'ACTIVE_FILE_MISSING',rel,rel);continue
  text=p.read_text()
  for token in expected_tokens[rel]:
   if token not in text:add(e,'ACTIVE_VERSION_DRIFT',f'missing {token}',rel)
  hit=stale.search(text)
  if hit:add(e,'ACTIVE_REGRESSION_RANGE_DRIFT' if hit.group(0).startswith('R1') else 'ACTIVE_VERSION_DRIFT',hit.group(0),rel)
 ids=[int(x) for x in re.findall(r'^\| R(\d+) \|', (root/'dev/REGRESSION_TESTS.md').read_text(),re.M)]
 if len(ids)!=570 or sorted(ids)!=list(range(1,571)):add(e,'REGRESSION_CATALOG_DRIFT',str({'count':len(ids),'first':min(ids or [0]),'last':max(ids or [0])}),'dev/REGRESSION_TESTS.md')
 for rel in r.get('activeProductionModules',[]):
  if not (root/rel).is_file():add(e,'ACTIVE_MODULE_MISSING',rel,rel)
 return e
def main():
 root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
 errors=validate(root);out={'validator':'V7.6.0-RELEASE-CONSISTENCY','pass':not errors,'errors':errors,'proofBoundary':'Active release identity, regression metadata, maturity labels, live-evidence status, and declared module presence only.'};print(json.dumps(out,indent=2));raise SystemExit(0 if not errors else 1)
if __name__=='__main__':main()
