#!/usr/bin/env python3
"""Fail-closed Nano Banana and Veo 3.1 prompt validation for Mode B."""
from pathlib import Path
import re,sys
sys.path.insert(0,str(Path(__file__).parent))
from avd_parser import block_markers
NB={'NB-F1','NB-F2','NB-F3','NB-F4','NB-F5'};VF={'V-F1','V-F2','V-F3','V-F4','V-F5'}
def norm(x):return str(x).strip().upper().replace('-','_').replace(' ','_')
def issue(a,c,m,**x):a.append({'code':c,'message':m,**x})
def blocks(body,kind,errors,aid):
 rows,problems=block_markers(str(body),kind+'_PROMPT')
 for p in problems:issue(errors,p['code'],f'{aid}: {p["message"]}',artifactId=aid)
 return [(meta,text.strip()) for meta,text,_,_ in rows]
def has(text,label):return bool(re.search(rf'(?mi)^\s*(?:#+\s*)?{re.escape(label)}\s*:',text))
def validate(contract,output,errors):
 if norm(contract.get('mode'))!='B_ANIMATION':return
 policy=contract.get('generationPromptPolicy') if isinstance(contract.get('generationPromptPolicy'),dict) else {}
 queue=contract.get('artifactQueue',[]) if isinstance(contract.get('artifactQueue'),list) else []
 def tagged(spec,terms):
  s=norm(str(spec.get('artifactId',''))+' '+str(spec.get('artifactType','')))
  return any(x in s for x in terms)
 nano_specs=[s for s in queue if isinstance(s,dict) and s.get('required',True) and tagged(s,['CHARACTER_SHEET','ENVIRONMENT_PROMPT','IMAGE_PROMPT','ASSET_PROMPT','KEYFRAME_PROMPT','FIRST_LAST_FRAME'])]
 veo_specs=[s for s in queue if isinstance(s,dict) and s.get('required',True) and tagged(s,['ANIMATION_PROMPT','MOTION_PROMPT','VIDEO_PROMPT','VEO_PROMPT'])]
 active=bool(policy.get('modeBRequired')) or str(contract.get('schemaVersion','')).startswith(('7.4.1','7.4.2','7.4.3','7.4.4','7.5.0','7.6.0'))
 if not active:return
 tools=contract.get('tools',{}) if isinstance(contract.get('tools'),dict) else {}
 if norm(tools.get('stillGeneration'))!='NANO_BANANA':issue(errors,'MODE_B_REQUIRES_NANO_BANANA',str(tools.get('stillGeneration')))
 if norm(tools.get('videoGeneration'))!='VEO_3_1':issue(errors,'MODE_B_REQUIRES_VEO_3_1',str(tools.get('videoGeneration')))
 if not nano_specs:issue(errors,'NANO_PROMPT_ARTIFACT_REQUIRED','Mode B contract must queue character/environment/keyframe image prompts')
 if not veo_specs:issue(errors,'VEO_PROMPT_ARTIFACT_REQUIRED','Mode B contract must queue animation/video shot prompts')
 arts={a.get('artifactId'):a for a in output.get('artifacts',[]) if isinstance(a,dict) and a.get('artifactId')}
 editor=re.compile(r'\b(?:Canva|CapCut|keyframe diamond|timeline menu|layer track|combo animation)\b',re.I);seen=set()
 for spec in nano_specs:
  aid=spec.get('artifactId');body=str((arts.get(aid) or {}).get('body',''));bs=blocks(body,'NANO',errors,aid)
  if not bs:issue(errors,'NANO_PROMPT_BLOCK_MISSING',aid,artifactId=aid);continue
  for meta,text in bs:
   fw=str(meta.get('framework','')).upper();pid=str(meta.get('id',''))
   if not pid:issue(errors,'NANO_PROMPT_ID_MISSING',aid,artifactId=aid)
   elif ('NANO',pid) in seen:issue(errors,'DUPLICATE_GENERATION_PROMPT_ID',pid,artifactId=aid)
   else:seen.add(('NANO',pid))
   if fw not in NB:issue(errors,'NANO_FRAMEWORK_INVALID',f'{aid}.{pid}.{fw}',artifactId=aid)
   if not re.search(r'(?mi)^\s*(?:Create|Transform|Edit|Replace|Visualize|Translate|Retrieve)\b',text):issue(errors,'NANO_OPERATION_VERB',f'{aid}.{pid}',artifactId=aid)
   for field in ['Composition','Output','Acceptance']:
    if not has(text,field):issue(errors,'NANO_PROMPT_FIELD',f'{aid}.{pid}.{field}',artifactId=aid)
   if not (has(text,'Subject') or has(text,'References') or has(text,'Base image')):issue(errors,'NANO_PROMPT_FIELD',f'{aid}.{pid}.Subject/References',artifactId=aid)
   if not (has(text,'Style and rendering') or has(text,'Visual context/composition/style')):issue(errors,'NANO_PROMPT_FIELD',f'{aid}.{pid}.Style',artifactId=aid)
   if editor.search(text):issue(errors,'EDITOR_LANGUAGE_IN_GENERATION_PROMPT',f'{aid}.{pid}',artifactId=aid)
 for spec in veo_specs:
  aid=spec.get('artifactId');body=str((arts.get(aid) or {}).get('body',''));bs=blocks(body,'VEO',errors,aid)
  if not bs:issue(errors,'VEO_PROMPT_BLOCK_MISSING',aid,artifactId=aid);continue
  for meta,text in bs:
   mode=str(meta.get('mode','')).upper();pid=str(meta.get('id',''))
   if not pid:issue(errors,'VEO_PROMPT_ID_MISSING',aid,artifactId=aid)
   elif ('VEO',pid) in seen:issue(errors,'DUPLICATE_GENERATION_PROMPT_ID',pid,artifactId=aid)
   else:seen.add(('VEO',pid))
   if mode not in VF:issue(errors,'VEO_MODE_INVALID',f'{aid}.{pid}.{mode}',artifactId=aid)
   for field in ['Cinematography','Subject','Action','Context','Style and ambiance','End state','Acceptance','Fallback','Audio route','Dialogue','SFX','Ambient noise','Music']:
    if not has(text,field):issue(errors,'VEO_PROMPT_FIELD',f'{aid}.{pid}.{field}',artifactId=aid)
   if editor.search(text):issue(errors,'EDITOR_LANGUAGE_IN_GENERATION_PROMPT',f'{aid}.{pid}',artifactId=aid)
