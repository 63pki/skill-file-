# V7.6.0 Evidence Release Validation

Phase A assurance remains intact. Phase B adds canonical `PROJECT_INDEX.json` extraction, HTML/fenced/sidecar metadata, evidence-record ingestion, exact path/hash checks, artifact required-section/field schemas, anti-filler detection, gate-derived scope enforcement, duplicate/conflict detection, and unsupported completed-media claim scanning.

Package extraction does not recursively discover artifacts unless explicit recovery mode is enabled. Deterministic checks still do not prove semantic quality, perceptual media quality, audience comprehension, rights, or live cross-model performance.

## Phase C

`phase_c_usability.py` validates strict operator readiness and compiles repair plans. `validate_semantic_review.py` validates separately typed, evidence-bound quality reviews. Deterministic PASS and semantic quality remain distinct.

## Phase D

`validate_external_evidence.py` validates imported campaigns. Only `LIVE_EXTERNAL` records can advance live proof. `SIMULATED_TEST` and `DRY_RUN` validate tooling only.

## V7.6.0 Evidence Release generation enforcement

`validate_generation_prompts.py` requires Mode B Nano Banana and Veo 3.1 ownership, exact prompt blocks, official framework/mode IDs, required guide fields, separated audio lines, and rejection of editor-language substitution.
