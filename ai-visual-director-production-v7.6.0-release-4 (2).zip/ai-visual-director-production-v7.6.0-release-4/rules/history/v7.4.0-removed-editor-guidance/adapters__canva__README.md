# Canva Adapters

Load only the matching surface. These adapters are operation-level until the current UI is verified. Record version/date/evidence; never invent button paths or plan entitlements.
