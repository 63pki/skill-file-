# 34 CapCut and Canva Execution Recipes

Use when assembling in CapCut, designing in Canva, or guiding a beginner/intermediate operator. UI locations change; describe the operation and verify current controls instead of fixed button paths.

## Recipe format

```text
RECIPE / GOAL:
REQUIRED ASSETS:
TRACK/LAYER ORDER:
STEPS:
WHAT GOOD LOOKS/SOUNDS LIKE:
COMMON FAILURE / REPAIR:
OUTPUT / NEXT DEPENDENCY:
```

# CapCut

## 1. Build from storyboard

1. Create the project in the verified final orientation.
2. Place temporary cards/stills in storyboard order.
3. Add scratch/final VO first when narration controls timing.
4. Set card durations from the board.
5. Replace placeholders with approved clips without changing IDs.
6. Keep alternates above the main picture track.
7. Mark story turns, proof, CTA, silence, and music changes.

Good result: the story works before polish.

## 2. Track structure

```text
V1 main picture
V2 alternates / inserts / reactions
V3 overlays / masks / hybrid layers
V4 logo / CTA / UI / exact typography
V5 captions / accessibility
A1 dialogue / VO
A2 Foley / synchronized SFX
A3 ambience / room tone
A4 music
A5 transition/design SFX
```

Use fewer tracks for simple work, but keep ownership clear.

## 3. Trim unstable generated footage

- Inspect heads/tails for morphing, focus jumps, exposure changes, or unwanted motion.
- Mark the strongest stable fragment.
- Cut on action, reaction, information, or sound—not where generation ends.
- Cover missing duration with insert, reaction, environment, still hold, or designed transition.
- Do not hide major identity/geometry failure with effects.

## 4. Continuity and coverage

- Match action phase across cuts.
- Preserve screen direction and eyeline.
- Use inserts to prove mechanism/material or bridge defects.
- Use reactions to carry meaning.
- Use J/L audio overlap when it improves continuity.

## 5. Match generated clips

Match clips to one approved reference in this order:

1. exposure and black level;
2. white balance and temperature;
3. saturation and palette;
4. contrast/highlight roll-off;
5. sharpness/noise/grain appropriate to mode;
6. skin, product, and brand color.

Do not use grain to excuse broken geometry. Do not apply photoreal grain to Mode B/C unless intentionally declared.

## 6. Replace unwanted native audio

1. Decide whether native audio provides useful synchronization.
2. Mute/separate unusable dialogue, music, or ambience.
3. Establish one ambient bed per space.
4. Add Foley/SFX for visible or story-relevant actions.
5. Add music after dialogue and environment are clear.

## 7. Voice/music mix

- Make speech intelligible without music.
- Add ambience.
- Add music and duck under speech.
- Restore music for a motivated transition, release, or lift.
- Check headphones, phone speaker, and low volume.
- Verify current loudness/delivery requirements.

## 8. Captions

- Generate/import, then proofread.
- Break lines by meaning.
- Test at phone size.
- Maintain contrast over changing backgrounds.
- Respect current safe zones.
- Add speaker/SFX labels when required.
- Recheck timing after edit changes.

## 9. Multiple aspect ratios

- Duplicate the approved master.
- Reframe shot by shot, not one automatic crop.
- Protect faces, hands, products, captions, logo, CTA.
- Rebuild graphic layouts.
- Regenerate shots that cannot survive the crop.
- Recheck pacing because crop changes perceived speed/scale.

## 10. Final review

Watch without sound; listen without picture; watch at phone size; check cuts, captions, logo, claims, and audio transitions; verify export settings; watch the exported file completely.

# Canva

## 11. Mood/reference board

Use labeled regions:

```text
North-star | composition | light/material | production design |
performance | palette/type | edit/sound | anti-reference / do-not-copy
```

Explain each reference role; do not create an unlabeled image wall.

## 12. Storyboard presentation

Each frame includes shot ID/time, story function, image/placeholder, action/camera, VO/dialogue, SFX/music, reference IDs, and approval status.

## 13. Exact design assets

Use Canva for title cards, benefits, logo lockups, CTA, offer text, disclaimers, static UI/diagram labels, and thumbnail typography. Use authorized fonts/colors. Export transparency where supported and needed.

## 14. Thumbnail/cover

- One focal read.
- Text adds information rather than repeating the visual.
- Check actual thumbnail size.
- Run grayscale/contrast/safe-area tests.
- Verify current destination dimensions.
- Keep editable source for testing.

## 15. Treatment/portfolio board

```text
Brief and audience promise
Chosen concept + rejected clichés
Visual thesis + memory device + sound identity
Reference roles
Storyboard
Keyframe/motion approach
Typography/brand system
Sound/edit approach
Rights/disclosure notes
Deliverables
```

Do not invent client approval or performance.

# Handoff

```text
Asset ID | version | ratio | transparent/background | editable source |
font/license | intended track/layer | in/out time | approval status
```

When an element changes, update its version and dependent timeline instances.

## 16. Manual-recipe separation and decoration guard

A manual recipe is not an I2V prompt. Keep manual values in the manual channel owned by `00b`/`35`. Do not copy percentages, coordinates, scale values, easing curves, or editor properties into a generic natural-language motion prompt unless a tested tool explicitly supports that syntax.

Do not add crossfades, vignette, glow, numerical color adjustments, or decorative motion by default. Each effect must pass the motivated-effect gate in `12`. Technical export/audio/safe-zone values must be verified for the current destination and app surface or labeled **ASSUMPTION — VERIFY**.
