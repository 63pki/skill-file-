# CapCut Adapters

Load only Desktop or Mobile after the operator names the surface. Verify current controls and plan features. Core editing logic remains operation-based.
