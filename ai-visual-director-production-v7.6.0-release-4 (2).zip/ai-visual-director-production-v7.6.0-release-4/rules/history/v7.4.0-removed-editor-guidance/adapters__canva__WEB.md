# Canva Web Adapter

## Verification record

```text
Surface / device / OS:
App/browser version if visible:
Verification date:
Evidence source: direct UI | official help | operator report | unverified
Verified operations:
Unknown/plan-dependent operations:
Fallback:
```

## Production operations

- create the required canvas after destination ratio is verified;
- import approved references and preserve stable filenames;
- build editable layers/groups for subject, environment, overlays, and text;
- keep exact typography, captions, logos, legal copy, and UI editable;
- export test stills/layers only after format and transparency support are verified;
- visually inspect exported files rather than trusting the editor preview.

Do not provide exact menu paths unless they were verified for this surface/date.
