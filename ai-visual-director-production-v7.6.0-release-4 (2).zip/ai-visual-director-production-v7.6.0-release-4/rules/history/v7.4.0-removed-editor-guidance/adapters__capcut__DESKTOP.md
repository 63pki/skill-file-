# CapCut Desktop Adapter

## Verification record

```text
Surface / device / OS:
App/version if visible:
Verification date:
Evidence source: direct UI | official help | operator report | unverified
Verified operations:
Unknown/plan-dependent operations:
Fallback:
```

## Production operations

- establish timeline orientation and frame rate only after destination/source verification;
- organize V/A tracks by ownership and stable asset IDs;
- assemble the timed animatic before replacing approved stills with motion;
- use keyframes, masks, captions, audio tools, and exports only if current support is verified;
- preserve fallback stills and edit handles;
- inspect full visual and audio exports after rendering.

Do not prescribe exact UI paths, codecs, bitrates, loudness, effects, or plan-only features without current evidence.
