# Runtime Rules — V7.2.1

This is the single authoritative runtime read. It consolidates five bundles. Apply only triggered sections, but never bypass the kernel in `SKILL.md`.

# Bundle 1 — Core Execution

## 1. Operating level, depth, and mode

Operating level:

- **Quick Shot:** one narrow artifact or repair with no unresolved upstream dependency.
- **Production Sequence:** connected multi-shot or multi-deliverable work.
- **Campaign/Long Project:** recurring systems, chapters, markets, teams, or extensive batches.

Operating depth:

- **FAST:** default for Quick Shot and low-risk isolated work. Complete now; internal QA only.
- **STANDARD:** default for Production Sequence. Six approval gates, useful batching, compact user-facing state.
- **CONTROLLED:** Campaign/Long Project or high risk, fragile runtime, costly generation, regulated claims, complex recurrence, or explicit forensic audit. Smaller internal batches and explicit evidence detail.

Depth selection evidence:

```text
scope / recurrence / generation cost / rights or claim risk / runtime stability /
number of deliverable families / number of shots / approval complexity
```

Do not confuse operating depth with model capability profile FULL, CONTROLLED, or INSUFFICIENT.

Modes:

- **A Photoreal/Cinema:** physical light, perspective, material/contact, production design, camera/edit logic.
- **B Animation:** style family, silhouette, shape/line/shading/palette, pose, staging, anticipation/action/reaction/hold.
- **C Motion Graphics:** message, hierarchy, grid, exact editable type/data, layout states, easing/holds.
- **D Hybrid:** layer ownership, perspective/light/scale match, matte/occlusion/contact, entry/exit transition.

## 2. Deterministic Project Contract Compiler

Before creative drafting, compile `templates/PROJECT_CONTRACT.json` internally. The contract is the only active source for project-specific locks. It contains:

```text
project/version / delivery mode / production intent / operating mode/depth /
user profile / duration and shot budget / image generator / video generator /
post surfaces / audio path / host and human capabilities / required artifact IDs /
story mechanism and world rule / durable resolution / recurring-asset part schemas /
visual and sonic memory devices / measured-voice status / evidence ceiling /
package requirement / reversible assumptions / blockers
```

### Delivery-mode router

- **GUIDED PRODUCTION:** use when the user requests collaboration, approvals, testing, iteration, or stepwise production. Stop at meaningful Direction, Animatic, or Delivery approval only.
- **SINGLE-PASS BLUEPRINT:** use when the user requests all written planning deliverables now and does not request actual generated media. Complete the text package in one response. Mark direction choices, tests, audio timing, assets, and motion as provisional where evidence is absent. Maximum verdict is `PLAN-PASS`.
- **FINISHED PRODUCTION:** use when the user requests actual media and the host/human workflow can execute it. Evidence dependencies and gates remain binding.

Do not infer a mode from model confidence. If intent is ambiguous and the difference changes work materially, ask one compact choice; otherwise use the least irreversible mode and state the assumption.

### Tool-role compiler

Record exactly one owner for each role:

```text
still generation / video generation / optional post / audio / inspection / export
```

`UNASSIGNED` is valid for portable blueprints. Canva and CapCut are post/assembly surfaces unless a current verified surface explicitly provides the selected operation; they never silently replace an unassigned image/video generator. When Nano Banana/Veo 3.1 are selected, their full adapters remain mandatory. Compile with the official-guide framework selected in each adapter, record the guide snapshot date, and reverify volatile surface capabilities.

### Requirement compiler

Convert every trigger into:

```text
requirement ID / trigger evidence / artifact ID / required fields /
dependency / acceptance / fail-if / smallest repair
```

Create an Artifact Queue from those records. Before output, compare actual artifacts against the queue using `validators/validate_project.py`. Rules that did not compile to artifacts cannot be cited as completed.

### User-facing boundary

Successful beginner/standard output shows only one plain-language line, for example:

```text
Status: Plan ready; visuals, measured voice, and finished animation are not created yet.
```

Keep the JSON contract, receipts, and validator detail internal or in the package. Expose them only for a blocker, audit, final technical handoff, or FORENSIC mode.

## 3. Request-to-rule activation

| Request evidence | Required artifact before dependent work |
|---|---|
| substantial visual direction | Visual Exploration Matrix + Signature Test; generated/inspected low-cost tests when available |
| story/transformation/demo/before-after/claim | causal/mechanism chain + explicit world rule when behavior departs from ordinary physics + durable physical/system resolution |
| recurring character/product/world/effect/brand | stable ID + schema + silhouette comparison; complex recurrence → validated model sheet/reference |
| spoken words | exact word count + line windows + arithmetic validation + scratch/final recording status + measured duration before full motion |
| multi-shot work | mode-pure board + burden/split decisions |
| Nano Banana image generation | Nano Banana adapter + image prompt contract + reference/inspection loop |
| Veo 3.1 video generation | Veo 3.1 adapter + generation-mode prompt + continuity/audio/inspection loop |
| generator plus optional manual editor | generation prompt remains primary; manual recipe is separate and only when requested |
| audio matters | sonic thesis + cue-level roles + silence decision |
| children/expert/vulnerable/regulated/multilingual/accessibility | audience suitability receipt |
| factual/reconstruction | claim ledger + visual-status/disclosure plan |
| visual/media outputs supplied or generated | visual inspection record + repair/reinspection status |
| voice/music/SFX/mix supplied or generated | audio inspection record + perceptual/deterministic evidence split |
| Mode B rigged/cutout/frame production | triggered `rules/production/2D_ANIMATION.md` artifacts |
| Canva/CapCut execution | matching adapter verification record + operation-level fallback |
| child/expert/client/accessibility validation claimed | real human review record; no simulated testing |
| final delivery | artifact-queue completeness + semantic validator result + motivated edit + canonical filename + verified values + evidence-typed maturity + evidence-media inventory + two-pass archive record + consolidated package |

## 4. Six-gate queue

First STANDARD/CONTROLLED response creates planning only:

```text
DELIVERY MAP
Operating level / operating depth / capability profile / mode
Requested deliverable families
Activated sections and why
Blockers and reversible assumptions
Explicit exclusions

GATE QUEUE
G1 Direction → G2 Design → G3 Animatic → G4 Asset → G5 Motion → G6 Delivery
For each: dependencies / artifacts / acceptance / status
```

Gate contents:

- **G1 Direction:** brief, audience, mode, reference categories, concept territories, Visual Exploration Matrix plan, selected direction, story/mechanism closure, suitability, provisional Signature Test.
- **G2 Design:** generated/inspected low-cost style evidence when available, Signature Test pass, silhouette comparison, Style Bible, color script, composition system, asset/environment schemas, model-sheet plan, Registry locks.
- **G3 Animatic:** script, timing arithmetic, storyboard, durations, comprehension holds, color-script alignment, composition progression, rough sonic/edit rhythm.
- **G4 Asset:** canonical primary views, additional validated views/states, environment plates, reference evidence, visual inspection and repaired-asset reinspection.
- **G5 Motion:** representative motion proof first, triggered production module, motion/rig/layer/timing decisions, compact execution packs, visual-motion and audio inspection, fallbacks.
- **G6 Delivery:** edit/sound/assembly, adapter/spec verification, human review when triggered, final visual/audio/export inspection, automatic host-capable exports, mandatory final compilation.

In GUIDED PRODUCTION, proceed until the next meaningful approval, contradiction, missing evidence, risk escalation, or creative decision; plain `NEXT` authorizes the next READY internal gate. In SINGLE-PASS BLUEPRINT, complete all requested text artifacts in one response but preserve provisional labels and the evidence ceiling. In FINISHED PRODUCTION, generated work stops at missing evidence. Never expose micro-artifact commands.


### Evidence-typed gate verdicts

Use `templates/GATE_MATURITY_LEDGER.md`. Never emit bare `PASS`.

- **PLAN-PASS:** authored plan/prompt artifact passed deterministic checks only.
- **TEST-PASS:** named low-cost generated test/proof was inspected.
- **ASSET-PASS:** complete required asset family exists and approved versions were inspected.
- **MOTION-PASS:** project-specific motion from approved anchors, aligned to measured speech when applicable, was inspected.
- **RELEASE-PASS:** final synchronized export and all triggered reviews passed.
- **REVISE / BLOCKED:** failed acceptance or missing required evidence.

A higher gate may produce planning artifacts while retaining a lower evidence verdict. Never say `all gates complete`, `everything creative is finished`, or `final production package` when required evidence is pending; use the authorized maturity name.

## 5. Capability profile and workload

Unknown runtime = capability profile CONTROLLED.

- FULL may use larger internal batches inside one gate after objective probes pass.
- CONTROLLED uses explicit templates, moderate batches, repeated locks where necessary, and critic checks.
- INSUFFICIENT stops; it never lowers acceptance criteria.

The profile changes workload size, not the six-gate dependency order or quality threshold.

## 6. Internal governance / external clarity

Maintain internally after every gate:

- gate contract and acceptance;
- Project Asset Registry updates;
- Evidence Binder updates;
- deterministic checks;
- critic status;
- compiler result;
- invalidated dependencies;
- attempt-budget ledger.

Successful default response exposes only current gate artifact, meaningful decision, real blockers, and one next action. Show diagnostics when a gate fails, the user asks for an audit, evidence is missing, or final handoff is reached. Never hide a blocker to keep the response clean.

## 7. Internal policy precedence

```text
Safety/rights > user creative goal > verified capabilities > approved locks > runtime > detailed/optional material
```

All deliverables requested does not bypass gates. A multi-panel sheet is not proof. Self-critique is not independent final approval. Host vision configured does not mean an asset was inspected.

## 8. Triggered production modules

Load no module by habit. Load only after mode/workflow selection:

- User selects Nano Banana for image generation → `adapters/generation/NANO_BANANA.md`.
- User selects Veo 3.1 for video generation → `adapters/generation/VEO_3_1.md`.
- User selects both → `adapters/generation/NANO_BANANA_VEO_PIPELINE.md` plus both adapters.
- Mode B cutout, rigged, pose-to-pose, frame-by-frame, or limited 2D animation → `rules/production/2D_ANIMATION.md` when that production depth is requested; it supplements rather than replaces Veo prompts.
- Canva/CapCut adapters activate only when the user requests those surfaces for composition, assembly, captions, audio, or delivery.
- Additional future modules must declare trigger, owned artifacts, forbidden leakage, and runtime precedence.

A module supplies execution depth but cannot relax gates, quality floors, evidence requirements, attempt budgets, or maturity. If module language conflicts with runtime, runtime wins and the conflict enters the audit log.

# Bundle 2 — Direction and Production

## 1. Brief and direction contract

```text
Deliverable / duration / destination assumption
Audience and viewing context
Viewer start → end state
Story/information promise and desired action
Mode(s)
References and rights
Must show / must avoid
Budget/attempt/approval constraints
Blockers vs reversible assumptions
```

Without references, create north-star quality, construction/material, performance/staging, edit-rhythm, sound-identity, anti-reference, and style-test acceptance categories. For substantial concepts, create mechanically different Evidence, Tension, and World territories with one-frame thesis, turn/payoff, memory device, sonic idea, rejected clichés, control path, and project-specific reason.

### Visual Exploration Matrix

Use `templates/VISUAL_EXPLORATION_MATRIX.md` before locking substantial visual direction.

- FAST: one comparison only when originality risk is real.
- STANDARD: at least three genuinely discriminating low-cost tests across concept/style, silhouette, palette/value, composition, line/texture, negative space, or motion language. Choose the tests most likely to change the decision; do not create ceremonial variants.
- CONTROLLED: full matrix or documented N/A rows, with evidence IDs and rejection reasons.

When image generation and vision inspection are available, generate and inspect the selected low-cost tests. When unavailable, provide executable test prompts and mark the Design dependency `STYLE TEST REQUIRED`; prose is planning evidence, not visual-quality evidence.

### Signature Test

Use `templates/SIGNATURE_TEST.md`. A direction cannot PASS merely because it is coherent, attractive, feasible, or on-brand. It must identify:

- the one frame or visual event viewers should remember;
- a story/brief-specific visual rule or transformation;
- a recurring memory device;
- an intentional omission;
- a controlled surprise;
- character/product-specific shape, motion, or material rhythm;
- why the environment/composition carries meaning;
- how the result remains distinguishable with logo/title removed.

Reject directions that could describe ten interchangeable projects in the category.

## 2. Story/mechanism closure and suitability

```text
Initial state → cause/change → pursuit/response → discovery/reversal →
meaningful decision/action → visible consequence → durable resolution → final proof
```

Ask what keeps the solved state solved when the helper, temporary effect, narration, or final shot ends. Product/explainer adaptation: problem → mechanism → visible/sourced proof → consequence → CTA.

Audience card covers prior knowledge, vocabulary, emotional intensity, decision power, comprehension without narration, accessibility/localization, cultural/regulatory concerns, and pressure to avoid. Children require visible recovery, agency, demonstrated moral, comprehension holds, and no manipulative engagement or purchase CTA.


### Story-world contract

For stories with impossible or autonomous behavior, state the smallest child/audience-readable world rule before the behavior matters. The ending must show a durable physical or system solution before temporary help leaves. Emotional understanding alone cannot close an unchanged physical problem.

### Contract freeze and contradiction check

Freeze exact part counts, faces/limbs, personality/speech, prop ownership, geography, shade/light logic, story mechanism, ending state, shot count, tool roles, and evidence ceiling. Before every gate and final compilation, compare all active artifacts to the contract. Examples of blocking contradictions:

- `no arms` versus a later hand wave;
- faceless shadow versus facial-expression prompt;
- plant already under an awning versus shadow required for shade;
- temporary water versus unresolved heat after shade leaves;
- storyboard duration versus line-level speech windows;
- editor named as generator without verified assignment.

## 3. Design and Asset Registry

Use `templates/PROJECT_ASSET_REGISTRY.md`. Independent drifting entities receive stable IDs.

Canonical schema:

```text
ID/role
geometry/anatomy/part count
scale/material/palette/style
movement/gesture/deformation
contact/attachment points
allowed states/transitions
forbidden changes
reference precedence
```


### Cross-gate lock ledger

After every approved direction/design/animatic decision, record a lock snapshot:

```text
story mechanism / ending cause / character anatomy and part count / personality and speech /
prop ownership / environment geography / palette-line-material system / shot IDs and count /
tool roles / approved reference versions / measured timing status
```

Before each new gate, diff the proposed artifact against the snapshot. Silent changes—such as adding/removing arms, faces, pots, shadow speech, shot count, world rules, or generation tools—are `REVISE`. An intentional change creates a new lock version, invalidates affected dependents, and updates all prompt/board/package copies.

### Silhouette comparison

Before canonical-view lock for a principal recurring character, product, creature, prop, icon, or vehicle, use `templates/SILHOUETTE_COMPARISON.md`. Compare at least three materially different silhouettes when exploration is still reversible. Test thumbnail recognition, part-count clarity, role/emotion, pose/state range, negative space, scalability, continuity risk, and production feasibility. Do not treat color, facial detail, texture, or labels as silhouette evidence.

Complex recurrence then uses canonical-view-first validation: selected silhouette → primary view → validate → secondary views → validate → expression/state/action tests → assemble sheet. Do not treat a multi-panel proposal as proof.

### Color script

Time-based work uses `templates/COLOR_SCRIPT.md`. Map sequence/beat, story or information state, dominant/support/accent colors, value structure, saturation/temperature, contrast, transition trigger, emotional/informational purpose, continuity lock, and accessibility risk. A palette list alone cannot PASS the Design Gate for time-based work.

### Composition and visual hierarchy system

Define and test:

```text
primary focal read / secondary read / intentional omission
subject-ground separation / value and color hierarchy
negative-space function / shape and edge-density rhythm
depth or layer ownership / eyeline and screen-direction logic
entry path / hold area / exit path
repetition and break / motif placement
thumbnail and text-overlay resilience
how composition changes across the emotional/information arc
```

Reject centered/default staging, decorative depth, random asymmetry, indiscriminate detail, or camera movement used to manufacture importance. Every hero frame must survive a small-thumbnail, grayscale/value, silhouette, and narration-off test when applicable.

## 4. Animatic and timing

Universal board row:

```text
ID/time/function/start-end state/staging/action/camera or layout/audio/cut/reference IDs/mode/fallback/status
```

Split at independent discovery, reaction, decision, transformation, speaker, camera grammar, or layout-message change. Each generation clip needs one dominant action or deliberately ordered causal action, one camera intention, clean start/end, continuity, and fallback.

Speech calculation:

```text
estimated_seconds = word_count / assumed_WPM × 60
required_window = estimated_seconds + performance_pause + comprehension_hold
```

Show line and total calculations. Validate that shot durations sum to the target, each line's estimated speech plus required pause/hold fits its assigned window, and grouped timing rows sum consistently. A contradiction is `REVISE`, not a harmless estimate. Replace estimates with measured read/render duration before final motion lock.

For each sequence, check that color/value progression, focal hierarchy, shot-size rhythm, negative space, and visual density change with the story/information arc rather than remaining uniformly pleasant. The reveal, reversal, proof, or decision must have a designed compositional contrast from setup.

### Measured voice checkpoint

Use `templates/MEASURED_VOICE_CHECKPOINT.md` after script approval.

- A BLUEPRINT may continue to motion planning with word-count estimates, but its motion verdict remains `PLAN-PASS`.
- GENERATION PACKAGE or FINISHED MEDIA requires an actual scratch/final read or render with measured line and total durations before full motion generation.
- If voice is unavailable, freeze full motion, produce the recording script and measurement instructions, and identify which shots remain provisional.
- Never speed narration merely to protect an estimated shot table; revise words, holds, shots, or total duration.


## 5. Compact prompt compiler

Store once:

```text
PERSISTENT REFERENCE LOCK
approved asset IDs / identity and geometry / style and palette /
world continuity / forbidden mutations / reference precedence
```

Per shot author only:

```text
SHOT DELTA
shot ID / start state / principal action / performance beat /
end state / camera or layout / duration / audio relation
```

Keep manual execution separate:

```text
MANUAL RECIPE
layer / property / start-end / timing / easing / anchor-mask / purpose
```

Repair only the failure:

```text
REPAIR DELTA
KEEP / CHANGE / REASON / ACCEPT IF
```

Compile an expanded target prompt using the selected generation adapter. For Nano Banana, produce the official-framework image contract for every required asset/keyframe family. For Veo 3.1, produce the official five-part shot contract for every required shot or explicit reusable shot class, plus separated dialogue/SFX/ambience lines when audio is selected. These prompt libraries are required even when the host cannot execute the models. Lead with purpose/action, include only required locks, resolve every reference ID/version, and remove duplicated or contradictory prose. Never mix Canva/CapCut coordinates, easing, menu actions, or layer operations into Nano Banana or Veo prompts. Use positive target descriptions. Where an exclusion field is supported, list unwanted visual elements as concise nouns/adjectives rather than command phrases such as `no`, `do not`, or `don't`. Label exact technical values `CREATIVE DEFAULT`, `CALCULATED`, `VERIFIED`, or `ASSUMPTION — VERIFY`.

## 6. Attempt budgets and stop-loss

Set project-specific budgets during planning. Defaults when the user gives none:

| Item | Default maximum before fallback |
|---|---:|
| Style territory exploration | 3 |
| Canonical primary asset view | 4 |
| Secondary asset view/state | 3 |
| Representative motion proof | 3 |
| Individual shot regeneration | 2 |

Record attempt ID, changed variable, observed failure, accepted evidence, and next fallback. Never repeat an unchanged failed prompt. At the limit, switch to controlled compositing, cutout/still motion, manual editor construction, simplified action, different tool/model, or human specialist review.

## 7. Motion-proof-first

Before full shot motion packs or generation, select the highest-risk representative 2–4 second proof. It must test the project’s dominant continuity risks, such as identity, geometry, deformation, contact, outline/material stability, timing personality, camera/background stability, or layer interaction.

Use `templates/MOTION_PROOF.md`. Full motion work remains frozen until the proof passes or a fallback path is approved. A planning-only project may prepare the proof prompt but cannot claim proof success without generated and inspected evidence.

## 8. Visual production inspection loop

Use `templates/VISUAL_INSPECTION.md` for generated or supplied stills, clips, composites, typography, and exports.

```text
INGEST → declare actual access → identify asset/version → observe only visible evidence →
compare to approved locks → classify defects → choose ACCEPT / REPAIR IN POST /
REGENERATE / DISCARD → apply one controlled repair → RE-INSPECT repaired version
```

Inspect identity/geometry, silhouette, composition, palette/value, material/line, contact/occlusion, continuity, typography/text accuracy, motion stability, start/end editability, artifacts, and mode-specific craft only when visible. A still cannot prove motion. A frame sample cannot prove the entire clip. If the host cannot process the asset, use `OUTPUT NOT INSPECTED` and request evidence; do not infer.

Every blocking repair creates a new asset version. Approval attaches to the inspected version only. Parent and downstream references must be invalidated when the repaired property affects them.

# Bundle 3 — Audio, Post, and Delivery

## 1. Voice, sound, and edit

Choose native lip-sync only when necessary and verified. Prefer external VO for exact wording, continuity, localization, long narration, and revision control. Write for the ear, time mechanically, include pronunciation/performance, and preserve comprehension holds.

Define sonic thesis, signature motif/material source, ambience, leitmotifs, silence point, reveal cue, dialogue/music priority, and why the identity belongs to this project. Cue sheets identify time/beat, function, layer, source, entrance/exit, spatial relation, dialogue interaction, edit dependency, and status.

Cut on information, action, reaction, sound, match, contrast, or time—not generator endpoints. No universal crossfade, vignette, glow, LUT, gamma/lift, zoom, speed ramp, grain, or transition duration. Keep exact text, logos, legal copy, UI, and captions editable.

## 2. Audio production inspection loop

Use `templates/AUDIO_INSPECTION.md` for narration, dialogue, music, ambience, SFX, stems, mixes, and final exports.

Separate evidence types:

- **Deterministic:** duration, channels, sample rate, clipping/peak indicators, silence, file/container metadata, timing alignment where tools measure it.
- **Perceptual:** intelligibility, performance, pronunciation, masking, spatial balance, emotional fit, fatigue, continuity, and phone/speaker translation. Claim only when the host or a recorded human review actually listened.
- **Contextual:** rights, source, license, disclosure, language, audience, and destination requirements.

Loop: ingest → declare listen/analyze capability → identify version → inspect available evidence → compare to cue/voice/mix locks → classify severity → ACCEPT / EDIT / RE-RECORD / REDESIGN / DISCARD → re-inspect. Metadata or waveform analysis alone cannot authorize perceptual PASS. Final delivery requires a real listening record or `HUMAN LISTENING REQUIRED`.

## 3. Operator adapter verification

Nano Banana and Veo 3.1 are generation surfaces and use `adapters/generation/`. Canva and CapCut are not generation substitutes.

Only if the user requests Canva or CapCut for composition, assembly, captions, audio, or delivery, load the matching adapter under `adapters/canva/` or `adapters/capcut/`. Each operator adapter must state surface, device/OS, app/version if known, verification date, evidence source, verified operations, unknowns, and fallbacks.

- Never convert a generic operation into an invented button path.
- Never assume web/mobile/desktop parity, plan entitlement, transparency, keyframes, captions, masks, codecs, or export controls.
- If not verified, give an operation-level instruction plus where the operator should confirm it.
- Adapter facts cannot become portable core rules.

## 4. Human review checkpoint

Use `templates/HUMAN_REVIEW.md` when the project claims child comprehension, expert validity, client approval, accessibility, localization, or representative audience testing.

For child-directed work, require responsible adult/guardian and safeguarding appropriate to the context; collect minimal data; avoid manipulation, purchase/engagement pressure, sensitive personal questions, and unsupported diagnostic conclusions. Record exact asset version, participant context, neutral questions/tasks, observed behavior, direct quotes only with permission, comprehension/emotional-safety result, defects, and changes. An AI-simulated child is not test evidence.

Human review may be `PLANNED`, `COMPLETED`, `WAIVED BY AUTHORIZED REVIEWER`, or `REQUIRED BEFORE RELEASE`. Waiver does not become positive evidence.

## 5. Technical values and delivery

Classify each precise value as LOCKED CREATIVE, CALCULATED, VERIFIED SPEC with surface/date/evidence ID, or ASSUMPTION — VERIFY with check/fallback. Verify destination ratio, resolution, frame rate, codec, bitrate, safe zones, loudness, captions, disclosure, licensing, and platform policy before delivery claims.

Canonical filename:

```text
[project]_[sequence/chapter]_[shot/asset]_[stage]_[version]_[status].[ext]
```

## 6. Mandatory final compilation, evidence media, and exports

G6 cannot claim RELEASE-PASS until all requested approved artifacts are compiled into one clean authorized-maturity package using `templates/FINAL_COMPILATION.md` and `templates/EVIDENCE_MEDIA_INVENTORY.md`. Include every generated/inspected style test, canonical reference, keyframe, proof clip, contact sheet, and inspection record used to authorize a verdict. If unavailable, list the exact absent item and cap maturity.

Compilation rules:

- include latest approved artifacts only;
- remove repeated contracts, receipts, rejected drafts, stale IDs, and correction prose;
- preserve stable IDs and cross-references;
- include prompt library, Registry snapshot, board/shot table, voice/sound cue sheet, operator checklist, folder/filename plan, evidence/maturity summary, and honest limitations when relevant;
- run ID, duration, timing, dependency, filename, and technical-value checks;
- use `templates/EXPORT_MANIFEST.md` and `exports/README.md`;
- if the host can create files, generate the practical package automatically: master document, prompt library, Registry, board/shot table, cue sheet, operator checklist, evidence/quality summary, and machine-readable manifest in suitable requested formats;
- validate every created file; archive procedure: build files/hashes → create candidate archive → validate → write the validation result into the manifest → rebuild final archive → revalidate and calculate final hash; the manifest cannot remain `pending` after a claimed integrity PASS;
- if the host cannot create files, deliver a consolidated source plus export manifest without claiming files exist;
- compilation/export does not raise evidence maturity by itself.

# Bundle 4 — Evidence and Release

## 1. Evidence Binder and internal receipts

Use `templates/EVIDENCE_BINDER.md`. Distinguish direct observation, user report, calculation, verified capability, assumption, and not-yet-evidenced status.

For each gate maintain internally:

```text
GATE / artifacts / evidence IDs / critic independence /
PASS|REVISE|BLOCK|NO-SHIP / frozen dependencies /
smallest repair / acceptance / authorized next gate
```

No evidence means no PASS. Expose the receipt only on failure, audit request, missing evidence, or final handoff.

## 2. Quality-weighted creator/critic

Use `templates/QUALITY_SCORECARD.md` for substantial visual work. Compliance and creative quality are separate axes.

Default weighted dimensions:

| Dimension | Weight |
|---|---:|
| Story/information and emotional causality | 15 |
| Visual originality and signature | 15 |
| Character/product/design coherence | 12 |
| Composition and staging | 10 |
| Mode-specific performance/craft | 12 |
| Audience comprehension and suitability | 10 |
| Sound and editorial rhythm | 8 |
| Production feasibility and repairability | 8 |
| Continuity and technical control | 7 |
| Evidence integrity | 3 |

Score each 0–10 from named evidence. `N/A` requires redistribution before scoring. Default PASS requires weighted score at least 8.0/10 and no critical floor below 7.0 for originality/signature, story/emotional clarity, composition/staging, or applicable mode-specific performance. Raise or adapt floors for the brief; never lower them because compliance passed.

CONTROLLED capability profile uses creator pass plus critic pass. Prefer independent model, deterministic checker, or human. Self-critic is labeled and cannot authorize DELIVERY-READY. The critic must compare alternatives, name the strongest rejected option, identify what remains merely competent, and recommend the smallest change with the largest quality gain.

Mechanically check when supported:

- durations sum and board/prompt durations agree;
- all IDs resolve;
- timing rows exist;
- prompt layers/channels exist where required;
- no Draft/TBD/question/rejected option remains active;
- filename fields are complete;
- precise values are classified;
- ungenerated/uninspected items do not PASS;
- revisions invalidate dependents;
- gate queue and response boundary are correct;
- Visual Exploration Matrix and Signature Test exist when triggered;
- silhouettes are compared before principal canonical-view lock;
- time-based Design includes a color script;
- hero compositions pass thumbnail/value/silhouette checks when evidence exists;
- quality score meets weighted threshold and critical floors;
- visual/audio inspection records match exact asset versions;
- blocking repairs were re-inspected before approval;
- 2D production artifacts exist only when the Mode B workflow triggers them;
- adapter facts include verification status and do not conflict with core;
- human review claims have real session/report evidence;
- export manifest matches actual files and hashes when files were created;
- final compilation contains every requested approved family once.

## 3. Evidence review and maturity

Without accessible output: `PREFLIGHT ONLY` or `OUTPUT NOT INSPECTED`. With evidence: compare against approved references and acceptance; choose ACCEPT, REPAIR IN POST, REGENERATE, or DISCARD. Do not infer motion/audio/export quality from a still.

PLAN-READY → TEST-READY → ASSEMBLY-READY → DELIVERY-READY. Never jump levels. Final export must be watched/listened to as applicable, with rights/spec/caption checks, before DELIVERY-READY.


## 4. Actual-output validation

Before presenting or packaging a substantial result, create a machine-readable output record and run `validators/validate_project.py` when the host can execute files. Otherwise perform the same checks internally and mark `VALIDATOR NOT EXECUTED`.

Required checks:

- every required artifact ID is present or explicitly pending;
- shot durations sum to target duration;
- narration word counts and windows are arithmetically feasible;
- character/world locks match every active prompt and board row;
- world rule and durable resolution exist when triggered;
- tool roles are assigned or explicitly UNASSIGNED without post-tool substitution;
- evidence maturity does not exceed actual media/inspection evidence;
- used evidence media is inventoried;
- package and archive claims match created files.

A validator PASS proves only the checks it executed. Semantic/human/media evidence retains its own status.

# Bundle 5 — State, Continuity, and Handoff

## 1. Compact project state

Maintain internally after every gate:

```text
PROJECT STATE
project/version / operating level/depth / capability profile / mode /
current maturity / approved gates / active or next gate /
locked systems/assets/references / Registry and Binder versions /
open blockers/assumptions / frozen-invalidated dependencies /
attempt ledger / next authorized action
```

Show compact state only at planning, failure, audit request, model switch, or final handoff.

## 2. Gate compiler

Compiler rejects a missing Project Contract, unselected delivery mode, missing tool-role owner, missing requested artifact ID, undefined IDs, cross-gate lock drift, absent world rule for autonomous/impossible behavior, temporary closure, timing arithmetic contradictions, unmeasured speech that attempts to authorize full motion, mixed prompt layers/channels, incomplete selected Nano/Veo prompt libraries, post-tool generation substitution, unclassified numbers, invented platform/ownership claims, manipulative child CTA, generic automatic effects, interchangeable visual direction, missing triggered exploration/signature/silhouette/color evidence, below-floor quality scores, uninspected repair approval, perceptual audio PASS from metadata alone, untriggered mode leakage, simulated-human evidence, missing used evidence media, export claims without created files, invalid filename, exhausted attempt budget without fallback, full motion before proof, missing final compilation, off-scope audit/automation, bare PASS, or false completion. When execution is available, validator errors block release until repaired.

## 3. Revision behavior

```text
KEEP / CHANGE / WHY / DEPENDENCIES AFFECTED /
INVALIDATED ARTIFACTS / ATTEMPT COUNT / UPDATED VERSION
```

Freeze unrelated approved work. Replace active rows; never leave rejected drafts followed by correction prose.

## 4. Model-switch handoff

```text
MODEL-SWITCH HANDOFF
Project/version / operating depth / capability resets CONTROLLED /
approved gates / next READY gate / locked systems/assets/references /
approved board/timing / latest evidence / attempt ledger /
rejected decisions—do not restore / verified specs/assumptions /
open blockers / next authorized action
```

## 5. Scope closure

Complete only requested gate items. No unrequested skill audit, automation, cron, business coaching, or speculative future work. Project completion requires every requested gate PASS/N/A, final compilation complete, and maturity supported by evidence.
