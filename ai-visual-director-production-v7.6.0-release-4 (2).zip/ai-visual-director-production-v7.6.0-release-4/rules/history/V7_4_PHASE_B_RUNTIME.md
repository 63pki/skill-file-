# Runtime Rules — V7.4 Phase B

# Bundle 1 — Core Execution

## 0. Routing Contract and assurance profiles

The full Project Contract is never required before rule loading.

1. Compile the minimal Routing Contract: project class, Mode A/B/C/D, delivery mode, assurance profile, audience triggers, built-in/custom tool owners, requested output class, and host-execution availability.
2. `VERIFIED_RUNTIME`: bootstrap from the Routing Contract, verify selected SHA-256 values, inject the ordered context, compile the full Project Contract, finalize contract binding, and require the final challenge marker during output validation.
3. `PORTABLE_ASSURANCE`: proceed with useful text planning only when verified execution is unavailable. Display the unverified status; maximum PLAN-PASS; no cryptographic/deterministic/media/inspection/release claims.
4. Any change to routing fields after bootstrap invalidates the session and requires a new bootstrap. Any change to the final Project Contract requires rebinding before creative output.

Verified Runtime is fail-closed with `BLOCKED — VERIFIED RUNTIME REQUIREMENTS FAILED`. It proves runtime-context availability, selected-byte integrity, final-contract binding, and response linkage—not cognitive attention or behavioral compliance.

## 0B. Validator-quality contract

Each artifact queue item declares `artifactType`, `gate`, `sourcePath` or marker, `requiredSections`, and optional `requiredFields`. The extractor accepts HTML markers, fenced `avd-*` JSON, or host sidecars. Packages default to `PROJECT_INDEX.json`; recursive discovery is recovery-only. Duplicate IDs, source conflicts, missing paths, hash mismatches, generic repeated filler, missing required sections, later-gate leakage, malformed evidence, and unsupported media claims are errors. Evidence may come from `AVD:EVIDENCE`, fenced `avd-evidence`, or `evidence/EVIDENCE_RECORD.json`; file/version/hash/reinspection still determine maturity.

## 1. Route and contract

Choose Quick Shot, Production Sequence, or Campaign/Long Project; FAST, STANDARD, or CONTROLLED depth; Mode A/B/C/D; delivery mode; user profile; and capability profile. Unknown models are CONTROLLED. Capability changes batch size, never acceptance criteria.

After routing and rule loading, compile `templates/PROJECT_CONTRACT.json`. Required fields include delivery mode, intent, mode/depth, host profile, tool owners, audience, target duration, artifact queue, structured story/world closure, recurring locks, shot budget, actual-script timing rules, evidence ceiling, package requirement, assumptions, and blockers.

Every requirement compiles to:

```text
requirement ID / trigger / artifact ID / source marker or file /
minimum body / dependency / acceptance / fail-if / repair
```

A requirement without an artifact is not active compliance. A declared artifact without an extracted non-placeholder body is absent.

## 2. Delivery boundaries

- Guided Production: first response Direction Gate only. Stop again at Animatic and Delivery decisions or real blockers. Downstream placeholders are dependency notes, not deliverables.
- Single-Pass Blueprint: all requested text planning may be delivered together; maximum PLAN-PASS.
- Finished Production: continue only through available tools, approvals, measured voice, generated/inspected media, perceptual audio, and package evidence.

Default interaction is run-to-boundary within the selected mode. Do not require commands per shot or micro-artifact.

## 3. Model and host profiles

Model profile is demonstrated by constraint retention, contradiction detection, causal closure, arithmetic, evidence honesty, and ID integrity: FULL, CONTROLLED, or INSUFFICIENT.

Host profile separately records:

```text
filesystem / code execution / image generation / video generation /
visual inspection / motion inspection / audio playback-analysis /
archive-hash / export / Nano access / Veo access /
status and verification date per capability
```

Run `validators/probe_host.py` where possible. Installed utilities do not imply access to Nano/Veo or perceptual inspection. Missing capability selects an honest fallback or BLOCKED status.

## 4. Trigger-to-artifact routing

| Trigger | Required artifact |
|---|---|
| substantial visual direction | three territories or documented justified exception; Signature Test; composition/value tests |
| recurring subject | stable registry, canonical reference plan, silhouette alternatives, full lock schema |
| narrative/impossible behavior | structured world rule, causal chain, structured durable resolution, proof shot |
| spoken content | exact script lines, calculated word counts, shot windows, pause/hold budget, measured status |
| Nano Banana | selected NB-F1–NB-F5 prompt family, model/surface/date profile, references, acceptance, inspection path |
| Veo 3.1 | selected V-F1–V-F5 shot contracts, five-part formula, separated audio, endpoint, acceptance, fallback |
| children/accessibility | suitability artifact, caption/readability/contrast plan, human review status; no simulated evidence |
| final delivery | extracted output record, deterministic verdict, semantic review status, evidence inventory, package/file hashes |

Load only the triggered production module and adapters.

## 5. Gate queue

1. Direction: brief, audience, concepts, selected direction, mechanism, suitability.
2. Design: exploration, Signature Test, silhouettes, Style Bible, color script, registry, environment/asset locks.
3. Animatic: exact script, calculated timing, storyboard, holds, sound rhythm.
4. Asset: generated canonical assets and states, reference validation, visual inspection.
5. Motion: measured voice, representative proof, execution prompts/rig/timing, motion/audio inspection.
6. Delivery: assembly, captions, technical/human review as triggered, export inspection, final package.

Verdicts are evidence typed. A later gate cannot pass when a required upstream dependency is REVISE/BLOCKED.

# Bundle 2 — Direction and Production

## 1. Brief and visual authorship

Define purpose, audience, promise, tone, deliverables, exclusions, channel, duration, rights, tools, evidence, and acceptance. Generate comparative territories for substantial direction; reject with reasons. Test thumbnail, value, silhouette, narration-off readability, composition, and a project-specific memory device. Familiar coherence is not distinctiveness.

Mode A uses subject, light, material, lens/perspective only when relevant, environment, art direction, and post. Mode B uses shape, silhouette, pose, line, palette, staging, anticipation/action/reaction/settle/holds, deformation limits. Mode C uses hierarchy, type, graphic systems, transitions, data clarity. Mode D explicitly assigns layers and compositing boundaries.

## 2. Story/world and suitability

For narrative work record initial state, change, pursuit, discovery, decision, consequence, durable resolution, and proof. Structured world rule:

```text
rule / trigger / limit / return condition / proof shot
```

Structured durable resolution:

```text
original problem / temporary help / permanent change /
helper can leave / recurrence prevented / visual proof shot
```

Deterministic checks validate fields; the semantic critic asks whether the rule explains behavior and permanent change addresses the original cause. Label semantic results MODEL-REVIEWED. Emotional understanding cannot close an unchanged physical problem.

Children/audience work includes vocabulary, intensity, manipulation, sound, captions, accessibility, and real review status. Creator self-check is `PREFLIGHT`, not human audience PASS.

## 3. Locks and references

Registry locks include asset ID/version, part map/count, proportions, silhouette signature, palette IDs, outline/rendering, face/speech, personality, prop ownership, geography, screen direction, shade/light logic, mechanism, ending state, shot count, tool ownership, and reference relationships. Compare normalized values or hashes. Any intentional change creates a revision, invalidation list, and dependent updates.

Reference table:

```text
REFERENCE ID / ROLE / PRESERVE / MAY CHANGE / MUST NOT CONTROL
```

## 4. Actual script and timing

Store exact line text per shot, speaker, WPM estimate, required pause, comprehension hold, and measured status. Count words from the line; never trust a supplied count. Verify every line is assigned exactly once, no duplicate/omission, speech+pause fits the window, holds remain available, shot totals equal target, and grouped totals agree. Replace estimates with measured audio before full motion.

## 5. Prompt compilation and production

Separate persistent locks, shot delta, reference roles, generation prompt, manual recipe, fallback, and acceptance. Nano/Veo adapters are mandatory when selected. Do not mix editor UI/easing into generation prompts. Volatile values are VERIFIED or ASSUMPTION — VERIFY.

Use one representative high-risk motion proof. Attempt defaults: exploration 3, anchor repair 3, motion proof 3, shot repair 2, audio repair 2. Change one variable per repair. On exhaustion shorten, split, re-anchor, simplify, use still-motion/manual assembly, or block.

## 6. Inspection

Visual: observe, compare to locks, diagnose, repair, re-inspect. Motion: inspect full clip for identity, action, camera, contact/weight, endpoint, late degradation. A still cannot prove motion. Repaired version cannot inherit the prior pass.

# Bundle 3 — Audio, Post, and Delivery

## 1. Voice, sound, edit

Voice-first for spoken work. Record exact words, pronunciation, performance, pauses, measured duration, and version. Sound plan defines dialogue/narration, diegetic sound, ambience, music role, silence, motif, and mix hierarchy. Edit by story/information motivation, not generic effects.

Audio inspection separates metadata/waveform checks from human listening. Metadata cannot pass clarity, balance, distortion, pronunciation, sync, or emotional fit. Repairs need a new version and listen.

## 2. Post and adapters

Operator adapters are verified operation guidance, not invented UI. Canva/CapCut are post by default and cannot replace unassigned generation. Captions remain editable, proofread, timed, contrasted, and safe-area checked. Preserve track/layer ownership and reversible project sources.

## 3. Human and accessibility review

Human review records reviewer type, date, material/version, method, questions, findings, defects, repair, and recheck. Never simulate a child, client, expert, or accessibility reviewer. A creator preflight may check vocabulary, fright, captions, contrast, and clarity but is not audience validation and cannot support that claim.

## 4. Technical delivery and evidence

Classify values as CREATIVE DEFAULT, CALCULATED, VERIFIED, or ASSUMPTION — VERIFY. Verify actual duration, dimensions, fps, codec/container, channels, loudness method, captions, filename, and output existence where applicable.

Evidence records contain type, asset ID/version, path, SHA-256, inspection date/method, inspector, findings, defects, repair version, reinspection, and verdict. When files are accessible, verify existence/hash and ensure cited versions are used and packaged.

## 5. Final package

Use `templates/FINAL_COMPILATION.md`. Include actual artifacts, source markers/files, contract, extracted record, deterministic result, semantic review status, evidence inventory, generated/inspected media, prompts, fallbacks, missing items, manifest, archive verification, and compact status. A package manifest cannot claim files not created.

# Bundle 4 — Evidence and Release

## 1. Actual-output extraction

Prefer explicit source markers from `templates/ACTUAL_OUTPUT_MARKERS.md`; also support heading/file aliases. Run:

```text
python3 validators/compile_and_validate.py CONTRACT.json RESPONSE.md --runtime-receipt SESSION_DIR/FINAL_RUNTIME_RECEIPT.json
python3 validators/compile_and_validate.py CONTRACT.json PACKAGE_DIR --runtime-receipt SESSION_DIR/FINAL_RUNTIME_RECEIPT.json
```

The extractor creates the Output Record from actual bodies, file hashes, shot/script rows, status/claims, and evidence references. Manual output records may supplement but never replace extraction. Empty/placeholder/too-short bodies fail.

## 2. Deterministic validation

Validate schema, delivery boundary, artifact queue/body, IDs, tools, structured story/world fields, complete locks, shot/script arithmetic, maturity/evidence ceiling, file/hash evidence, package integrity, guide freshness status, and compact receipt. Errors block presentation/release when execution is available.

A deterministic PASS proves only executed checks. It does not prove taste, semantics, media quality, listening, comprehension, rights, or cross-model behavior.

## 3. Semantic review

Run `validators/semantic_review_template.json` through a capable model/human critic when triggered. Check causal closure, rule explanatory power, geography, contradiction, originality, emotional clarity, accessibility, and audience comprehension risks. Record evidence excerpts and uncertainty. Verdict is MODEL-REVIEWED or HUMAN-REVIEWED, never deterministic.

## 4. Maturity

- PLAN-PASS: coherent planning and prompts; no media proof.
- TEST-PASS: named low-cost generated test inspected.
- ASSET-PASS: complete required asset family inspected.
- MOTION-PASS: project motion using approved anchors and measured speech inspected.
- RELEASE-PASS: synchronized export, perceptual audio, captions, rights, technical, required human review, and package inspected.

No evidence type may be inferred from another.

## 5. Behavioral evidence

Static tests and fixtures are release prerequisites, not behavioral proof. Current live replay stores package hash, model/runtime, host, exact prompt, raw output, extracted record, validator result, artifacts, contradictions, false claims, and verdict. Nano/Veo A/B tests hold model/surface/references/settings constant. Production pilot requires actual style, assets, measured voice, motion proof, assembly, audio/caption/export inspection, and beginner operator record.

# Bundle 5 — State, Continuity, and Handoff

## 1. Compact state

```text
project/version / delivery mode / gate / maturity / host+model profile /
contract hash / approved assets / artifact queue / exact script+timing /
world+resolution / tools / attempts / evidence / validator / blockers / next boundary
```

Update after gates, repairs, invalidations, and model changes. Handoff includes only current locks, approvals, evidence, unresolved assumptions, failures, and next acceptance.

## 2. Revision and conflict policy

Authority: safety → root kernel → compact controller → runtime → selected production module → selected adapters → Project Contract → approved artifact versions. Detailed/history files cannot override. When recommendations conflict:

- compact receipt wins over full visible ceremony;
- real human review standard wins over an easier maturity label;
- deterministic checks and semantic review remain separate;
- compression may relocate text but cannot remove a capability or evidence floor;
- guide advice cannot override mode isolation, safety, or verified surface facts;
- a package claim requires actual file evidence.

## 3. Scope closure

Close the active boundary only. Do not append unrequested audits, automation, business coaching, or future promises. State blockers and the next meaningful action only when relevant.
