# Compact Core Controller — V7.3.1

Use this controller for every substantial project before creative drafting.

0. **Cryptographic bootstrap.** Compile the Project Contract, run `bootstrap/bootstrap_runtime.py`, verify every selected SHA-256 against the load manifest, inject the generated context without truncation, and preserve its receipt/checksum. The response must echo the session challenge. Any missing/mismatched core file, triggered module, adapter, receipt, checksum, context hash, or challenge is `BLOCKED — REQUIRED RULES NOT CRYPTOGRAPHICALLY LOADED`.

1. **Route delivery.** Choose Guided Production, Single-Pass Blueprint, or Finished Production from the requested outcome. Guided first response is Direction only; Single-Pass can complete text planning but cannot exceed PLAN-PASS; Finished requires real tools and evidence.
2. **Route craft.** Choose Mode A/B/C/D, FAST/STANDARD/CONTROLLED depth, audience profile, and only the required production module.
3. **Probe capability.** Record model profile separately from host capability. Determine file execution, generation, inspection, audio, export, and archive support. Unknown means UNVERIFIED, not available.
4. **Compile contract.** Freeze tools, required artifacts, source markers, story/world rules, recurring-asset locks, geography, shot/timing budget, evidence ceiling, package requirement, assumptions, and blockers.
5. **Create artifact queue.** Every activated rule must produce an artifact ID with minimum body requirements, dependencies, acceptance, fail-if, and repair. A heading or declaration is not an artifact.
6. **Create within boundary.** Preserve stable IDs and reference roles. Nano Banana/Veo use selected official adapters; Canva/CapCut remain optional post unless verified otherwise. Spoken lines are stored as exact text and counted mechanically.
7. **Validate actual output and load proof.** Extract from the raw Markdown/files using `validators/extract_actual_output.py`; do not author the Output Record as the sole truth. Run deterministic runtime-load, contract, timing, lock, evidence, package, and artifact-body checks. Run semantic critic separately and label it model-reviewed.
8. **Repair or stop.** Validator errors block presentation/release. Repair the smallest failed variable, version it, and rerun. After attempt budget, use a declared fallback.
9. **Report compactly.** Show one status line: delivery mode, contract, artifacts, validator, maturity ceiling, and media state. Full receipts stay in the package or FORENSIC mode.
10. **Close honestly.** Static tests do not prove behavior; prompt-guide alignment does not prove generation; creator self-check does not prove audience comprehension; metadata does not prove perceptual quality.
