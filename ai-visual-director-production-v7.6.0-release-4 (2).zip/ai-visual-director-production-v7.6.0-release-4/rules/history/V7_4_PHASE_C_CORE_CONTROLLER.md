# Compact Core Controller — V7.4 Phase C

Use this controller for every substantial project before creative drafting.

0. **Route before loading.** Create the minimal Routing Contract. Select `VERIFIED_RUNTIME` when execution/context injection/receipt retention exist; otherwise select `PORTABLE_ASSURANCE` and cap at PLAN-PASS.
1. **Load and bind.** In Verified Runtime, bootstrap from the Routing Contract, inject the verified context, then compile the full Project Contract and finalize its binding. Missing proof blocks. In Portable Assurance, show the unverified status and never imply deterministic execution.

2. **Route delivery.** Choose Guided Production, Single-Pass Blueprint, or Finished Production from the requested outcome. Guided first response is Direction only; Single-Pass can complete text planning but cannot exceed PLAN-PASS; Finished requires real tools and evidence.
3. **Route craft.** Choose Mode A/B/C/D, FAST/STANDARD/CONTROLLED depth, audience profile, and only the required production module.
4. **Probe capability.** Record model profile separately from host capability. Determine file execution, generation, inspection, audio, export, and archive support. Unknown means UNVERIFIED, not available.
5. **Compile full contract.** Freeze tools, required artifacts, source markers, story/world rules, recurring-asset locks, geography, shot/timing budget, evidence ceiling, package requirement, assumptions, and blockers.
6. **Create artifact queue.** Every activated rule must produce an artifact ID with gate, artifact type, exact source path/marker, required fields/sections, minimum body floor, dependencies, acceptance, fail-if, and repair. Character count is never the main quality test. A heading or declaration is not an artifact.
7. **Create within boundary.** Preserve stable IDs and reference roles. Nano Banana/Veo use selected official adapters; Canva/CapCut remain optional post unless verified otherwise. Spoken lines are stored as exact text and counted mechanically.
8. **Extract and validate actual output, evidence, claims, and assurance proof.** Extract from the raw Markdown/files using `validators/extract_actual_output.py`; do not author the Output Record as the sole truth. Run deterministic runtime-load, contract, timing, lock, evidence, package, and artifact-body checks. Run semantic critic separately and label it model-reviewed.
9. **Repair or stop.** Validator errors block presentation/release. Repair the smallest failed variable, version it, and rerun. After attempt budget, use a declared fallback.
10. **Report compactly.** Show one status line: delivery mode, contract, artifacts, validator, maturity ceiling, and media state. Full receipts stay in the package or FORENSIC mode.
11. **Close honestly.** Static tests do not prove behavior; prompt-guide alignment does not prove generation; creator self-check does not prove audience comprehension; metadata does not prove perceptual quality.

## Phase C quality and usability controller

11. **Apply progressive disclosure.** Default to compact status plus the current actionable artifact; retain full receipts in the package. Beginner mode expands definitions and exact next actions; expert mode stays concise without omitting gates.
12. **Run evidence-bound quality review.** Keep deterministic validation separate from model-reviewed taste, causality, originality, comprehension, feasibility, and coherence. Every score needs artifact/media evidence and uncertainty. Unavailable dimensions are `NOT_REVIEWED`, never guessed.
13. **Compile repairs.** Every error becomes one prioritized, gate-owned repair with target artifact/path, exact action, acceptance check, and revalidation command.
