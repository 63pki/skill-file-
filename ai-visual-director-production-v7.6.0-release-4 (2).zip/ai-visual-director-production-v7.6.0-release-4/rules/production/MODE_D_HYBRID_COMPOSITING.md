# Mode D — Hybrid Compositing Production Owner

## Trigger and isolation

Load for `D_HYBRID_COMPOSITING`. Every source layer must have declared provenance and ownership. Generated elements never become documentary evidence merely because they are composited with real footage.

## Required decisions

- Register plates, generated elements, graphics, mattes, depth, camera metadata, rights, and disclosure needs.
- Freeze plate version, frame range, lens/perspective evidence, camera path, lighting direction, occlusion order, contact surfaces, grain/noise behavior, and delivery color space.
- Assign generation, tracking, roto/mask, composite, grade, inspection, and export owners.

## Required artifacts

1. Source/provenance register
2. Plate and camera analysis
3. Tracking, mask, depth, and occlusion plan
4. Element-generation specifications
5. Composite shot map
6. Color/grain/contact integration checklist
7. Disclosure, inspection, and delivery record

## Quality gates

- **PLATE:** source, rights, and camera evidence are known.
- **PROOF:** hardest track, contact, reflection, occlusion, or scale problem is tested.
- **COMPOSITE:** perspective, light, contact, edge, grain, and motion blur are inspected.
- **DELIVERY:** disclosures, color, alpha, handles, audio, and exports pass.

## Fail conditions

Reject invented plate metadata, broken tracks, floating contact, impossible occlusion, disclosure loss, unlicensed sources, destructive source replacement, or claims based only on selected still frames.
