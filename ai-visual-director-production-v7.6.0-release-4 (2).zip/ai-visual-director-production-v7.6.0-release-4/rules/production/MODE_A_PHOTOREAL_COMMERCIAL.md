# Mode A — Photoreal and Commercial Production Owner

## Trigger and isolation

Load for `A_PHOTOREAL_COMMERCIAL`. Never apply its pores, lens, material, grain, or live-action lighting language to Mode B animation.

## Required decisions

- Declare product, subject, market, channel, ratio, rights, claim sensitivity, and required disclosures.
- Assign still/video owners explicitly; `UNASSIGNED` blocks execution but not an honest blueprint.
- Freeze product geometry, label text, materials, human anatomy, wardrobe, location, lighting direction, camera axis, and approved reference roles.
- Separate verified surface facts from `ASSUMPTION — VERIFY`.

## Required artifacts

1. Commercial brief and claim register
2. Product/subject lock sheet
3. Lighting, material, and camera plan
4. Shot or frame list with exact acceptance criteria
5. Generation or capture prompts for the selected owners
6. Inspection and rights checklist
7. Delivery manifest

## Quality gates

- **DESIGN:** brand, product, anatomy, label, and disclosure locks are approved.
- **PROOF:** hardest material, hand/product interaction, text, and reflection problem is tested.
- **PRODUCTION:** geometry, label, lighting, and continuity remain stable.
- **DELIVERY:** claims, rights, ratios, color, text, and exports are inspected.

## Fail conditions

Reject invented product features, unreadable or altered labels, impossible reflections, anatomy defects, unlicensed identity/style imitation, undisclosed reconstruction, unsupported claims, or fake evidence. Photoreal planning is not proof that media was generated or inspected.
