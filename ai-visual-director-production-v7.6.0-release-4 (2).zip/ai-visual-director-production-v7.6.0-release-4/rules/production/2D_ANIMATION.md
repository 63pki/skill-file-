# 2D Animation Production Module

## Trigger and boundary

Load only for Mode B projects using cutout, rigged, limited, pose-to-pose, frame-by-frame, or hybrid 2D animation. Do not apply limb rigs, exposure sheets, mouth charts, or frame terminology to still illustration, photoreal cinema, pure motion graphics, or unrelated hybrid work unless explicitly needed.

## Required production decision

```text
2D METHOD: cutout | rigged puppet | frame-by-frame | pose-to-pose | limited | mixed
Why this method fits style, performance, schedule, operator, and tool
Frame/timeline assumptions: CALCULATED | VERIFIED | ASSUMPTION — VERIFY
Asset ownership: generator | manual drawing | composited | mixed
Fallback method
```



## Beginner short-form profile

For a beginner short narrative, default limits are planning aids, not platform facts:

```text
characters: up to 3 recurring entities
locations: up to 3 principal locations
shots: 6–10 unless story/timing evidence requires more
voices: one narrator by default; dialogue only when it improves the story
visible approvals: at most Direction, Animatic, Delivery
reliable fallback: still-motion animatic in the selected editor
```

User-facing instructions answer: what to do, why, which asset/version to use, how to check it, and what to do if it fails. Keep gate IDs, registries, and validator receipts in the package appendix unless blocked or requested.

## Generation-native vs manual-editor lanes

Choose one primary lane per shot family:

- **Generation-native:** Nano Banana approved frame/keyframe → Veo 3.1 motion prompt. The rig/exposure module supplies silhouette, pose, deformation, timing, and continuity language but does not require manual cutout construction.
- **Manual-editor:** separated layers, pivots, replacement states, exposure/timing, and editor recipes when the user explicitly chooses manual animation.
- **Mixed:** declare exact layer/shot ownership. Never make Canva/CapCut reconstruction a prerequisite for Nano/Veo generation.

Keep Veo prompts and manual recipes as separate deliverables.

## Single-view puppet exception

A front-facing asset may omit side/back turnarounds only when the storyboard contains no meaningful turn, the identity is carried by front-view silhouette and replacement states, direction is shown through position/eyeline, and the exception is recorded. This reduces ceremonial asset work without weakening continuity.

## Feasibility budget

Before locking the animatic, compare shot count, distinct actions, character states, generated clips, voice windows, and operator experience. If the proposed method exceeds the user's production capacity, simplify actions/shots or choose generator-native motion; do not silently replace the user's selected tools with a lower-quality workflow.

## Construction and layer map

Use `templates/2D_RIG_SPEC.md`. Define exact layers, pivots, parent-child relations, draw order, masks, occlusion, contact, deformation zones, joint/rotation limits, replacement states, naming, and export grouping. Never create joints or limbs absent from the canonical schema.

## Pose-to-pose performance

For each important action define:

```text
story intention / line of action / silhouette read
key pose A / anticipation / key pose B / breakdown / overshoot / settle / reaction / hold
weight or buoyancy / center-of-mass path / arcs / spacing character
secondary action / eye or facial lead / contact and release / emotional change
```

The pose test must read at thumbnail size without dialogue where applicable.

## Timing, spacing, and exposure

Use `templates/EXPOSURE_SHEET.md`. Separate delivery frame rate from animation exposure. Never assume animation “on ones/twos/threes” without a verified timeline and style reason. Record shot timecode, frame range, pose/event, exposure, spacing, dialogue/phoneme, camera, FX, audio cue, hold, and edit handle.

## Character-specific motion grammar

Define idle, locomotion, turn, stop, take, reaction, gesture, deformation, overshoot/settle, blink/eye lead, and forbidden motion. Nonhuman/limbless assets require a deformation map with volume-preservation and recovery limits; generic scale pulsing is not performance.

## Mouth and dialogue

Only when visible dialogue requires it: define neutral/rest, closed consonants, open vowels, wide/narrow, teeth/lip constraints, emotion overlays, language variants, and substitution limits. Time against measured dialogue. Do not invent phoneme accuracy from untimed text.

## Cleanup and continuity

Check line weight, volume, part count, pivot drift, layer popping, color/palette, scale, screen direction, contact, occlusion, prop handoff, pose readability, cycle phase, camera relation, and start/end handles. Use onion-skin or overlay comparison only when the host/operator actually supports it.

## Motion proof and release

The representative proof must test the hardest identity/performance/contact problem. Inspect the full proof, not selected frames only. Full-shot production remains frozen until proof or fallback passes. Final animation maturity requires visual inspection of rendered motion and audio inspection of the synchronized export.

## Mandatory Nano Banana → Veo 3.1 delivery

For every required character, environment, asset state, keyframe, and first/last frame, emit one or more `AVD:NANO_PROMPT` blocks using exactly one NB-F1–NB-F5 framework from the active adapter. For every required moving shot, emit an `AVD:VEO_PROMPT` block using exactly one V-F1–V-F5 mode and the complete five-part Veo formula. Use approved Nano IDs as Veo references. Generic AI-video prompts and manual-editor motion recipes do not satisfy the animation-prompt deliverable. If model access is unavailable, still write the complete prompt libraries and mark execution `NOT_RUN`; do not reroute generation to an editor. Include `rules/production/AUDIO_ATTACHMENT.md` only for attaching approved narration, dialogue, SFX, ambience, or music to generated clips.
