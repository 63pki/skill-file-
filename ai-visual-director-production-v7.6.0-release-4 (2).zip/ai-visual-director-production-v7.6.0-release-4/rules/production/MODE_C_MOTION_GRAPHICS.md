# Mode C — Motion Graphics Production Owner

## Trigger and isolation

Load for `C_MOTION_GRAPHICS`. Do not import character-rig, exposure-sheet, photoreal-camera, or hybrid-plate requirements unless a declared combination requires them.

## Required decisions

- Freeze message hierarchy, brand system, typography licenses, grid, ratios, data source, duration, frame rate assumption, and delivery channels.
- Define motion grammar: entrances, exits, emphasis, transition families, easing, overshoot, holds, and reduced-motion behavior.
- Assign typography, design, animation, audio, inspection, and export owners.

## Required artifacts

1. Message and information hierarchy
2. Style frames and layout tokens
3. Typography and data-integrity register
4. Timed storyboard or beat sheet
5. Motion specification with easing and hold rules
6. Ratio/localization adaptations
7. Audio and export plan

## Quality gates

- **DESIGN:** hierarchy reads in still frames and brand tokens resolve.
- **ANIMATIC:** spoken/text timing and comprehension holds fit the duration.
- **MOTION:** easing, transitions, hierarchy, and reduced-motion variant are inspected.
- **DELIVERY:** text, data, safe areas, ratios, audio, and exports are verified.

## Fail conditions

Reject decorative motion that harms reading, invented data, unlicensed type, inconsistent easing, unsafe flashes, clipped text, unexplained ratio changes, or unsupported claims that animation/export occurred.
