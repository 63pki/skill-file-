# 23 Hooks, Packaging, and First-Frame Design

A hook is a concept-specific promise or tension—not a stock phrase.

## Hook construction

```text
Audience state → specific tension/desire → visible evidence → information gap → honest payoff
```

Generate at least three **mechanically different** options:

- evidence-first;
- contradiction;
- sensory transformation;
- question with visible stakes;
- character objective/obstacle;
- result first, mechanism withheld.

Avoid empty formulas such as “stop scrolling,” “nobody is talking about this,” or “the industry doesn’t want you to know” unless the statement is true, necessary, and specific.

## Hook test card

```text
Hook | visual evidence | read-aloud time | format fit | promise paid off? | cliché risk | select/reject
```

## Packaging system

Title, thumbnail/cover, and opening should add different information while making one honest promise.

### Thumbnail/cover

- one dominant read at small size;
- concept-specific object, face, or event;
- controlled contrast and negative space;
- minimal editable text only when it adds meaning;
- no misleading scale, fake result, or unsupported claim.

### First frame

Use `18`’s first-frame check. A static frame is valid when its stillness creates tension, luxury, scale, or contrast; do not ban static openings universally.

## A/B discipline

Change one packaging variable, choose the decision metric before looking, record sample/context, and call results local until repeated. Do not fabricate predicted CTR or retention.
