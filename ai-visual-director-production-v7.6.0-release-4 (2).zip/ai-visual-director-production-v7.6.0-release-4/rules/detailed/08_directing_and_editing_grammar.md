# 08 Directing and Editing Grammar

Camera movement is only one part of directing. Build shots for story function, spatial clarity, and the cut.

## Shot card

```text
Shot ID:
Story function: [orient / reveal / prove / react / transition / payoff]
Shot size + angle:
Lens perspective:
Subject and action:
Screen direction / eyeline:
Camera movement:
Foreground / midground / background:
Entry and exit frame:
Cut motivation:
Audio cue:
Reference IDs / generation mode:
```

## Shot sizes and functions

- **Extreme wide / wide:** geography, scale, isolation, world rules.
- **Medium:** behavior, interaction, product use.
- **Close-up:** emotion, evidence, mechanism.
- **Extreme close-up / insert:** tactile detail, proof, transition bridge.
- **Reaction:** meaning after an event; often more valuable than another action shot.

Use progression intentionally. A sequence of equally framed medium shots feels generated rather than directed.

## Perspective

- Wide perspective emphasizes space and movement but can distort near objects.
- Normal perspective reads naturally and is flexible for coverage.
- Long perspective compresses space and isolates details or faces.
- Macro reveals material truth but loses geography.

Keep perspective coherent across coverage unless the change expresses a story turn.

## Movement families

- **Locked:** lets action, performance, or design carry attention.
- **Push/pull:** changes emotional proximity or reveals context.
- **Pan/tilt:** redirects attention within a stable position.
- **Track/follow:** shares subject motion and screen direction.
- **Orbit/arc:** reveals form or changes relationship to background.
- **Rise/drop/crane:** reveals scale or hierarchy.
- **Handheld/POV:** subjective immediacy; control amplitude and purpose.
- **Focus/optical:** transfers attention without moving the camera.

Name direction, speed, endpoint, and what stays stable.

## Continuity rules

For continuous scenes:

- establish geography before complex coverage;
- preserve left/right screen direction across cuts;
- match eyelines and prop/hand state;
- respect the action axis unless the crossing is shown;
- cut on action or motivated sound when helpful;
- carry the previous endpoint into the next start frame;
- use inserts/cutaways to bridge unavoidable continuity defects.

## Edit grammar

Cut because one of these changes:

- information;
- emotion/reaction;
- action phase;
- location/time;
- scale/detail;
- sound beat;
- visual match or contrast.

Do not cut merely because a generated clip ended.

## Coverage templates

### 15-second product ad

```text
problem/evidence close-up → tactile reveal → mechanism/use → reaction/result → clean hero/CTA
```

### Dialogue beat

```text
establishing two-shot → speaker medium/close → listener reaction → insert if relevant → changed two-shot
```

### Cinematic scene

```text
geography → objective → obstacle evidence → action/reaction → turn → exit image
```

### Animation

Prioritize readable silhouette, staging, anticipation, action, reaction, and hold. Camera movement is optional; character staging can carry the shot.

## Intentional rule breaking

```text
Default being broken:
Creative reason:
Risk introduced:
Control/coverage fallback:
```
