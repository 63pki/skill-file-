# Generation adapters — V7.2.1

These adapters are active when the user selects the named generation stack.

- `NANO_BANANA.md`: official framework routing for text-to-image, reference generation, conversational editing, grounded current visualization, and typography/localization.
- `VEO_3_1.md`: official five-part video formula, text/image/ingredients/first-last/timestamp modes, separated audio direction, and negative-prompt syntax.
- `NANO_BANANA_VEO_PIPELINE.md`: guide-aligned keyframe-to-motion handoff.

Alignment snapshot: **2026-07-19**. Sources and requirement mapping are in `dev/OFFICIAL_PROMPT_GUIDE_ALIGNMENT.md`. Reverify volatile model and surface capabilities before use. Prompt-guide alignment is not successful-generation evidence.
