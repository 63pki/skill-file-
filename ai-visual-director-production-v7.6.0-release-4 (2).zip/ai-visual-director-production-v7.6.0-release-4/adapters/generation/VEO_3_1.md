# Veo 3.1 Official Prompt-Guide Adapter

## Alignment scope

Aligned on **2026-07-19** to:

- Google Cloud, **The ultimate prompting guide for Veo 3.1** (2025-10-15)
- Google Cloud, **Video generation prompt guide**
- Google AI for Developers, **Generate videos with Veo 3.1**

This is prompt-guide alignment, not a permanent guarantee of feature availability. Verify the exact Veo model, access surface, region, plan, modes, duration/aspect/output controls, references, audio, and safety behavior at use time.

## Surface verification

```text
Surface/provider:
Displayed model/version:
Date checked:
Text-to-video:
Image-to-video:
Ingredients/reference-to-video:
First-and-last-frame:
Timestamp/multi-shot prompting:
Native dialogue/SFX/ambience:
Duration/aspect/resolution controls:
Status: VERIFIED | ASSUMPTION — VERIFY
Fallback:
```

Do not invent universal limits, seeds, extensions, prices, reference counts, watermarks, or rights terms. Date-scoped official examples do not override the active surface.

## Select one generation mode

- **V-F1 text-to-video:** exploration or non-recurring identity.
- **V-F2 image-to-video:** animate one approved Nano Banana or supplied frame.
- **V-F3 ingredients/reference-to-video:** use verified character/object/scene/style ingredients with explicit roles.
- **V-F4 first-and-last-frame:** interpolate between two compatible approved frames.
- **V-F5 timestamp sequence:** direct a multi-shot timed sequence only when the active surface supports it and the project benefits from one generation containing multiple shots.

Do not mix incompatible mode contracts. Add/remove-object workflows must be routed to the model/surface currently exposing that operation; do not label a different model's operation as Veo 3.1.

## Official five-part prompt formula

Every Veo prompt resolves:

1. **Cinematography** — shot size/angle, composition, one camera movement, lens/focus when useful.
2. **Subject** — specific character/object and stable ID/reference role.
3. **Action** — ordered visible behavior, interaction, expression, contact, and performance.
4. **Context** — location, time, weather, atmosphere, and relevant geography.
5. **Style and ambiance** — visual style, lighting, mood, palette, and pacing.

## V-F1/V-F2 single-shot contract

```text
SHOT [ID] — [edit/story purpose]. [Veo mode].
Cinematography: [shot size/angle and composition]. [one camera movement with direction, speed character, and endpoint]. [lens/focus only if useful].
Subject: [specific asset ID, visible identity/construction, approved reference relationship].
Action: [one dominant action or ordered causal sequence with anticipation, contact/weight, reaction, settle/hold].
Context: [world ID, geography, time, weather, atmosphere, relevant secondary motion].
Style and ambiance: [approved mode, lighting, mood, palette, material/line/rendering language].
End state: [stable composition and edit handle].
Acceptance: [continuity, action, performance, camera, endpoint, and audio tests].
Excluded elements: [concise nouns/adjectives in the supported negative-prompt field; avoid command wording].
```

For V-F2, start with:

```text
Use [FRAME ID/version] as the exact starting composition and identity anchor. Preserve [identity, geometry/anatomy, part count, scale, environment geography, palette/style, and light direction].
```

## Audio direction

When native audio is verified and useful, write separate sentences:

```text
Dialogue: [ASSET ID] says, "[exact approved words]" in [delivery, emotion, pace, pronunciation].
SFX: [specific synchronized physical sound sources and timing].
Ambient noise: [specific background soundscape].
Music: [only when requested; role, instrumentation, energy, and entry/exit].
```

Quotation marks are mandatory for exact dialogue. Do not mix narration, dialogue, SFX, ambience, and music into one ambiguous sentence. Use external audio when exact long-form wording, timing, localization, stems, or revision control is more important than native generation.

## Negative-prompt compiler

First rewrite the wanted scene positively. Example: `an empty rural horizon with uninterrupted grassland` rather than an instruction to remove buildings.

If the surface provides a negative-prompt field, use a concise excluded-elements list:

```text
urban skyline, roads, utility poles, extra characters, subtitles, logo
```

Avoid instruction phrases such as `no`, `do not`, and `don't` inside the negative field. Keep safety requirements outside the creative negative list.

## V-F3 ingredients/reference-to-video

```text
INGREDIENT ID | ROLE | PRESERVE | MAY CHANGE | MUST NOT CONTROL
```

Prompt with explicit relationships: `Use CHAR-MILO-v03 for Milo's identity, WORLD-GARDEN-v02 for geography, and STYLE-v04 for rendering only.` Then apply the official five-part formula. Every ingredient must be verified as available on the active surface.

## V-F4 first-and-last-frame

```text
Start exactly on [FRAME A ID/version] and finish exactly on [FRAME B ID/version].
Cinematography: [one continuous camera/transition process linking the compositions].
Subject/action: [ordered middle behavior, contact, and transformation].
Context/style: preserve [world, light, palette, rendering, identity, and geometry invariants].
Audio: [separate dialogue/SFX/ambience sentences when verified].
Acceptance: exact endpoints, coherent middle, stable identity, plausible continuity, and intended audio.
Fallback: shorten, simplify, re-anchor, split, or use manual transition.
```

The prompt must direct the middle; restating the two endpoints is insufficient.

## V-F5 timestamp sequence

Use only when one generated clip intentionally contains multiple shots and the active Veo surface supports the workflow.

```text
[00:00-00:02] [cinematography + subject + action + context + style].
[00:02-00:04] [next intentional shot and action]. SFX: [timed sound].
[00:04-00:06] [next intentional shot and action]. Dialogue: [ASSET] says, "[line]".
[00:06-00:08] [final shot, end composition, hold]. Ambient noise: [soundscape].
```

Validate segment arithmetic against the verified clip duration. Do not use timestamp prompting merely to hide an overstuffed shot.

## Mode B animation language

Use shape, silhouette, pose, line, palette, staging, anticipation, action, reaction, overshoot, settle, deformation limits, and holds. Photoreal skin, physical camera hardware, film grain, or live-action optical terminology activates only when the approved animated/hybrid style requires it.

## Failure routing

- identity/morphing → stronger approved anchor/ingredient; simpler action; shorter clip;
- floaty motion → contact, weight/resistance, path, endpoint;
- camera chaos → one camera move; remove accidental shot changes;
- late degradation → use stable segment or split at an edit beat;
- dialogue/audio failure → simplify, mute-and-replace, reaction shot, or external audio;
- background drift → stronger world reference, simpler scene, or locked camera;
- endpoint failure → first/last-frame mode or manual transition.

Before handoff, verify: surface profile, official framework ID, complete five-part formula, stable references, one camera intention unless V-F5, separated audio sentences, supported negative-field syntax, end state, acceptance, and fallback. Inspect full motion and perceptual audio separately. A prompt is generation-ready; it is not evidence that Veo succeeded.
