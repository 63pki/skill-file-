# Nano Banana Official Prompt-Guide Adapter

## Alignment scope

Aligned on **2026-07-19** to:

- Google AI for Developers, **Nano Banana image generation**
- Google Cloud, **The ultimate Nano Banana prompting guide** (2026-03-05)

This is prompt-guide alignment, not permanent capability certification. Verify the displayed model ID, interface, region, plan, controls, and current official documentation before relying on model-specific limits.

## Model router

Record one verified model profile:

```text
Surface/provider:
Displayed model name and ID:
Nano Banana family: 2 Lite | 2 | Pro | legacy
Primary need: velocity/scale | general production | complex precision/brand/localization
Input/reference controls actually visible:
Grounding/search controls actually visible:
Output/aspect/resolution controls actually visible:
Date checked:
Status: VERIFIED | ASSUMPTION — VERIFY
Fallback:
```

Official family mapping at the alignment date:

- **Nano Banana 2 Lite / Gemini 3.1 Flash Lite Image:** velocity and scale; not the preferred route for multi-reference or sequential multi-turn editing.
- **Nano Banana 2 / Gemini 3.1 Flash Image:** versatile production workhorse; multiple references, consistency, text rendering, and higher-resolution workflows when exposed.
- **Nano Banana Pro / Gemini 3 Pro Image:** complex professional assets, precision control, brand consistency, localization, and difficult reasoning.
- **Nano Banana / Gemini 2.5 Flash Image:** legacy family member; do not silently route to it when a newer selected model is available.

Do not copy capability numbers from this adapter into a production claim. Verify current values on the active official model page.

## Official prompting principles

1. Start with a strong operation verb: `Create`, `Transform`, `Edit`, `Replace`, `Visualize`, or `Translate`.
2. Be specific about subject, action, context, composition, lighting, and style.
3. Describe the wanted image positively. Use an exclusion list only for observed high-risk failures.
4. Control viewpoint/camera where appropriate to the selected mode.
5. Iterate conversationally; preserve the prior approved image/interaction and change one variable at a time.
6. For Mode B animation, use animation-native shape, silhouette, staging, line, palette, and material language instead of irrelevant photoreal camera-body jargon.

## Select exactly one official framework

### NB-F1 — Text-to-image

Formula: **Subject + Action + Location/context + Composition + Style**.

```text
Create [purpose].
Subject: [specific subject/asset ID and visible construction].
Action/state: [one readable moment].
Location/context: [world ID, time, atmosphere, relevant geography].
Composition: [viewpoint, shot size, placement, depth, focal hierarchy, negative space].
Style and rendering: [approved mode, lighting, material/texture, line/shading, palette/color grade].
Output: [verified aspect/resolution or ASSUMPTION — VERIFY].
Acceptance: [observable identity, composition, continuity, and style tests].
Excluded elements: [concise nouns/adjectives only, if an exclusion field is available].
```

### NB-F2 — Multimodal generation with references

Formula: **References + Relationship instruction + New scenario**.

Create a relationship table before the prompt:

```text
REFERENCE ID | ROLE | PRESERVE | MAY CHANGE | MUST NOT CONTROL
```

```text
Create [purpose] using [REF ID] as [relationship/role], [REF ID] as [relationship/role], and only those assigned roles.
Preserve [identity, geometry, anatomy/part count, material, brand, style, or world locks by reference].
Place/perform the approved asset in [new scenario and visible state].
Composition: [viewpoint, placement, depth, focus, negative space].
Lighting/material/palette: [approved system].
Output: [verified control or ASSUMPTION — VERIFY].
Acceptance: [observable reference fidelity and scenario tests].
Excluded elements: [concise observed-risk list only].
```

### NB-F3 — Conversational editing / semantic masking / style transfer

Use the approved base image or previous interaction. State what changes and what stays identical.

```text
Edit [BASE IMAGE ID/version].
Change only [specific region/element] from [observed state] to [target state].
Keep exactly the same: [composition, identity, lighting, background, geometry, style, and other approved elements].
For a new reference, use [REF ID] only as [object/style/texture relationship].
Acceptance: [single-change visual test plus preserved-lock tests].
```

Continue from the prior interaction where the active surface supports it. Do not regenerate from scratch when a controlled conversational edit is the safer repair.

### NB-F4 — Grounded real-time visualization

Use only when the selected model/surface exposes current search grounding and the user needs current facts.

Formula: **Source/search request + Analytical task + Visual translation**.

```text
Retrieve [specific current source/data and date].
Analyze [exact comparison/calculation/classification required].
Visualize the result as [image type, hierarchy, labels, units, language, composition, and style].
Include source/date traceability outside the generated pixels when possible.
Acceptance: [factual checks plus visual readability checks].
```

If grounding is unavailable, mark `ASSUMPTION — VERIFY` or use supplied verified data. Never make a current-data image from memory and label it verified.

### NB-F5 — Text rendering and localization

Choose one path explicitly:

- **Generated typography path:** use when in-image text is the creative requirement and the selected model is suitable.
- **Editable post path:** use when legal copy, captions, brand lockups, localization scale, or revision control requires editable text.

Generated typography contract:

```text
Create [visual purpose].
Render the exact text "[approved text]".
Typography: [font family/style description, weight, case, color, hierarchy, placement, spacing].
Language/locale: [BCP-47 or plain-language target]; preserve exact spelling and punctuation.
Visual context/composition/style: [specific direction].
Acceptance: exact text, correct language, legibility, hierarchy, and no extra copy.
```

For complex copy, develop/approve the text first, then generate the image. Inspect every character before approval.

## Creative-director controls

Use only those that materially help the mode:

- lighting setup and emotional purpose;
- camera/viewpoint, lens/focus, or animation-native equivalent;
- color grading/film treatment where stylistically justified;
- materiality, texture, surface behavior, line, or shading;
- composition and focal hierarchy.

Exact camera hardware or f-stop is a creative instruction, not proof of physical capture.

## Controlled repair and handoff

```text
APPROVED BASE: [ID/version].
OBSERVED FAILURE: [evidence].
CHANGE ONLY: [one variable and target result].
KEEP EXACTLY THE SAME: [approved locks].
ACCEPTANCE: [observable test].
```

Before handoff, verify: model profile, official framework ID, prompt purpose, stable asset/reference IDs, relationship instructions, exact text route, positive target description, acceptance, fallback, and inspection status. A prompt is generation-ready; it is not proof of a successful image.
