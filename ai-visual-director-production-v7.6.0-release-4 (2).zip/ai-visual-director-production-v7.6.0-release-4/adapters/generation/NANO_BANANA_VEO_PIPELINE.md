# Nano Banana → Veo 3.1 Official-Guide Pipeline

## Stack ownership

```text
Nano Banana: style/concept tests, canonical assets, model sheets, environments, grounded visuals when verified, typography when selected, keyframes, first/last frames
Veo 3.1: text-to-video, image-to-video, verified ingredients/reference-to-video, first/last-frame motion, verified timestamp sequences, verified native audio
Audio attachment: use `rules/production/AUDIO_ATTACHMENT.md` only after clips exist; no editor is a generation substitute
```

## Guide-aligned sequence

1. Verify exact Nano and Veo model IDs, surfaces, date, and exposed controls.
2. Select one Nano official framework (`NB-F1`–`NB-F5`) per image task.
3. For every reference, record its relationship role and prohibited influence.
4. Write Nano prompts with a strong operation verb, specific positive target, composition/style controls, and observable acceptance.
5. Generate only through an actually available surface; inspect and repair conversationally one variable at a time.
6. Lock approved Nano frame IDs/versions and relationship roles.
7. Select one Veo mode (`V-F1`–`V-F5`) per shot/generation.
8. Compile the Veo five-part formula: cinematography, subject, action, context, style/ambiance.
9. Separate dialogue, SFX, ambient noise, and music sentences. Quote exact dialogue.
10. Use positive scene wording and concise excluded-element lists rather than negative commands.
11. Generate/inspect one highest-risk motion proof before the full set.
12. Repair one failed variable, version the result, and re-inspect.
13. Compile every required Nano family and Veo shot prompt even when execution is external.
14. Attach approved external audio to generated clips only when required; never substitute an editor for Nano Banana or Veo 3.1 generation.
15. Run contract, continuity, timing, evidence, and official-guide-alignment checks before handoff.

## Handoff row

```text
SHOT ID | NANO FRAME ID/VERSION | NB FRAMEWORK | REFERENCE ROLES | NANO INSPECTION |
VEO MODE | FIVE-PART PROMPT CHECK | AUDIO PATH | VEO PROMPT VERSION |
VEO OUTPUT VERSION | VISUAL VERDICT | AUDIO VERDICT | FALLBACK | STATUS
```

Undefined/unapproved Nano frames cannot anchor Veo. Official-guide alignment cannot exceed the active surface's verified capabilities.
