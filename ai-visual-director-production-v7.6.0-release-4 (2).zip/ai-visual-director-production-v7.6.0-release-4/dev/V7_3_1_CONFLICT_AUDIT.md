# V7.3.1 Bootstrap Conflict Audit

- **Arbitrary LLM enforcement versus physical limits:** models that omit the challenge fail validation; the package claims context availability and byte integrity, not unobservable cognitive attention.
- **Fail-closed enforcement versus broad tool support:** built-in Nano/Veo and post adapters are mapped; other generators require a hashed custom rule file rather than being prohibited or silently accepted.
- **Bootstrap before contract conflict:** a minimal Project Contract is compiled first; bootstrap occurs before creative drafting. Later contract changes invalidate the receipt by hash.
- **Receipt self-report conflict:** the receipt is produced by executable code, detached-hashed, contract-bound, manifest-bound, and challenge-linked.
- **Context compression conflict:** core files remain compact; triggered modules load only when selected; substantial mode cannot downgrade itself to Quick Shot.
- **Preservation conflict:** V7.3.0 authorities are archived byte-for-byte; prior files and Nano/Veo adapters remain unchanged.
- **Security versus usability:** normal users see one marker/status; cryptographic details stay in session/package records.
