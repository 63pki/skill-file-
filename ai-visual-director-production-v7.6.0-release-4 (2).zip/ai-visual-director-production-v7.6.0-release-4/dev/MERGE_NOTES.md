# V6.2 Merge Notes

## Kept from the uploaded V6.1 direction

- Correct safety-first precedence
- Quick Shot / Production Sequence / Campaign operating levels
- Smallest-useful-route principle
- Directing, reference intake, hybrid, motion-graphics, factual, audio, lint, and evidence concerns
- Detailed creative depth, curated rather than loaded as core

## Kept from Hybrid V6.1

- Unique canonical owners
- Evidence-based Green/Yellow/Red QA
- No global volatile specification table
- Detailed storyboard, sound/Foley, Mode C, Mode D, prompt-diff, session-memory, localization, and delivery systems
- Optional creative-depth libraries

## Added in V6.2

- Adaptive NEXT phases P0–P6
- Complete-prompt batching
- `NEXT [count]`, targeted revision, skip, and summary commands
- Dependency invalidation on revisions
- Mandatory project-state handoff for phased responses
- Concept-divergence and factual-visual canonical owners
