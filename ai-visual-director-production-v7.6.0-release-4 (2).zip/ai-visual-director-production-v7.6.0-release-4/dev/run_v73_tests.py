#!/usr/bin/env python3
import os
from pathlib import Path
import copy,hashlib,json,re,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
RESULTS=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));RESULTS.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'validators'))
from extract_actual_output import extract
from validate_project import result

def base_contract():
 return {
  'schemaVersion':'7.3.0','projectId':'TEST','deliveryMode':'SINGLE_PASS_BLUEPRINT','productionIntent':'BLUEPRINT','mode':'B_ANIMATION','depth':'STANDARD','currentGate':'DIRECTION','durationSeconds':45,
  'tools':{'stillGeneration':'NANO_BANANA','videoGeneration':'VEO_3_1','postSurfaces':['CapCut']},
  'story':{'isNarrative':True,'autonomousOrImpossibleBehavior':True},
  'locks':{'characters':[{'assetId':'CHAR_MILO','parts':{'arms':0,'legs':0,'eyes':2},'proportions':'wide','silhouetteSignature':'three scallops','paletteIds':['BLUE','NAVY'],'outlineBehavior':'soft navy','face':'DOT_EYES','speech':'NARRATOR_ONLY','personality':'kind curious','propOwnership':{},'referenceRelationships':['REF_MILO']}],'world':{'geography':'village-left garden-right','screenDirection':'left-to-right','shadeLightLogic':'shade cools plant','storyMechanism':'shadow helps when heat threatens','endingState':'leaf canopy remains'},'shotCount':9,'toolOwnership':{}},
  'artifactQueue':[{'artifactId':'STYLE_BIBLE','sourceAliases':['Style Bible'],'minimumChars':180,'required':True,'gate':'ANIMATIC'},{'artifactId':'ASSET_REGISTRY','sourceAliases':['Asset Registry'],'minimumChars':140,'required':True},{'artifactId':'STORYBOARD','sourceAliases':['Storyboard'],'minimumChars':180,'required':True},{'artifactId':'VOICE_PLAN','sourceAliases':['Voice Plan'],'minimumChars':140,'required':True},{'artifactId':'ANIMATION_PROMPTS','sourceAliases':['Animation Prompts'],'minimumChars':180,'required':True},{'artifactId':'ASSEMBLY_PLAN','sourceAliases':['Assembly Plan'],'minimumChars':140,'required':True}],
  'evidenceCeiling':'PLAN-PASS','guideAlignment':{'snapshotDate':'2026-07-19','maxAgeDays':3650}
 }

def body(label,n=240):
 parts=[f'Project-specific {label.lower()} rules define the intended result.',f'Acceptance criteria identify measurable completion for {label.lower()}.',f'Continuity controls preserve approved decisions through every downstream handoff.',f'Repair instructions name the owner, method, and revalidation step for defects.',f'Verification records bind each claim to the actual delivered artifact.',f'Exclusions prevent placeholders, generic filler, silent assumptions, and unsupported proof.',f'Implementation notes give concrete identifiers, values, and project-specific examples.']
 return f'## {label}\n'+(' '.join(parts)*2)[:n]
def valid_md():
 wr={'rule':'Shadows stretch away when nearby life needs shade.','trigger':'dangerous heat nearby','limit':'one nearby helper at a time','returnCondition':'durable shade exists','proofShot':'S07'}
 dr={'originalProblem':'sun overheats plant','temporaryHelp':'shadow shades plant','permanentChange':'broad leaf canopy secured','helperCanLeave':True,'recurrencePrevented':True,'visualProofShot':'S09'}
 parts=[]
 parts.append('<!-- AVD:STATUS delivery=SINGLE_PASS_BLUEPRINT maturity=PLAN-PASS media=NOT_GENERATED -->')
 parts.append('<!-- AVD:TOOL role=stillGeneration owner=NANO_BANANA -->')
 parts.append('<!-- AVD:TOOL role=videoGeneration owner=VEO_3_1 -->')
 parts.append("<!-- AVD:STRUCT kind=worldRule value='"+json.dumps(wr,separators=(',',':'))+"' -->")
 parts.append("<!-- AVD:STRUCT kind=durableResolution value='"+json.dumps(dr,separators=(',',':'))+"' -->")
 lock={'arms':0,'legs':0,'eyes':2}
 parts.append("<!-- AVD:LOCK asset=CHAR_MILO field=parts value='"+json.dumps(lock,separators=(',',':'))+"' -->")
 for k,v in [('proportions','wide'),('silhouetteSignature','three scallops'),('paletteIds',['BLUE','NAVY']),('outlineBehavior','soft navy'),('face','DOT_EYES'),('speech','NARRATOR_ONLY'),('personality','kind curious'),('propOwnership',{}),('referenceRelationships',['REF_MILO'])]:
  val=json.dumps(v,separators=(',',':'))
  parts.append(f"<!-- AVD:LOCK asset=CHAR_MILO field={k} value='{val}' -->")
 for aid,label,n in [('STYLE_BIBLE','Style Bible',300),('ASSET_REGISTRY','Asset Registry',260),('STORYBOARD','Storyboard',300),('VOICE_PLAN','Voice Plan',260),('ANIMATION_PROMPTS','Animation Prompts',320),('ASSEMBLY_PLAN','Assembly Plan',260)]:
  parts.append(f'<!-- AVD:ARTIFACT id={aid} -->\n{body(label,n)}\n<!-- /AVD:ARTIFACT -->')
 lines=['Milo wakes under a warm sky','His helpful shadow is missing today','Milo searches through the quiet village','A cool blue shape leads right','The plant waits beneath strong sunlight','Milo follows the shade toward garden','The shadow protects the little plant','Milo builds a broad leaf canopy','Kindness remains after helpers leave']
 for i,line in enumerate(lines,1):
  parts.append(f'<!-- AVD:SHOT id=S{i:02d} duration=5 speaker=Narrator wpm=120 pause=0.4 hold=0.4 -->\nLine: "{line}"\n<!-- /AVD:SHOT -->')
 return '\n'.join(parts)+'\n'

def codes(r): return {x['code'] for x in r['errors']}
def run_case(name,c,text,expect_pass,expected=()):
 with tempfile.TemporaryDirectory() as td:
  p=Path(td)/'response.md'; p.write_text(text); o=extract(c,p); r=result(c,o)
 ok=(r['pass']==expect_pass and set(expected)<=codes(r)); return {'case':name,'pass':ok,'validatorPass':r['pass'],'codes':sorted(codes(r))},o,r

results=[]
c=base_contract(); text=valid_md()
r,_,_=run_case('positive_blueprint',c,text,True); results.append(r)
# Mutations.
mutations=[]
mutations.append(('missing_artifact',re.sub(r'<!-- AVD:ARTIFACT id=STYLE_BIBLE -->.*?<!-- /AVD:ARTIFACT -->','',text,flags=re.S),['MISSING_ARTIFACT']))
mutations.append(('placeholder_artifact',text.replace('Project-specific style bible rules','TODO Project-specific style bible rules',1),['PLACEHOLDER_ARTIFACT']))
mutations.append(('shot_total',text.replace('id=S09 duration=5','id=S09 duration=4.94'),['SHOT_TOTAL']))
mutations.append(('duplicate_line',text.replace('Kindness remains after helpers leave','Milo wakes under a warm sky'),['DUPLICATE_SCRIPT_LINE']))
mutations.append(('voice_window',text.replace('Milo wakes under a warm sky','one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty'),['VOICE_WINDOW']))
mutations.append(('lock_drift',text.replace("field=parts value='{\"arms\":0", "field=parts value='{\"arms\":2",1),['LOCK_DRIFT']))
mutations.append(('post_as_generator',text.replace('role=stillGeneration owner=NANO_BANANA','role=stillGeneration owner=CapCut'),['POST_AS_GENERATOR','TOOL_ROLE_DRIFT']))
mutations.append(('world_rule_missing',re.sub(r'<!-- AVD:STRUCT kind=worldRule.*?-->','',text),['WORLD_RULE_FIELD']))
mutations.append(('durable_missing',re.sub(r'<!-- AVD:STRUCT kind=durableResolution.*?-->','',text),['DURABLE_RESOLUTION_FIELD']))
mutations.append(('maturity_inflation',text.replace('maturity=PLAN-PASS','maturity=RELEASE-PASS'),['EVIDENCE_CEILING','BLUEPRINT_MATURITY']))
for name,txt,exp in mutations:
 rr,_,_=run_case(name,c,txt,False,exp); results.append(rr)
# Guided scope leak.
g=base_contract(); g['deliveryMode']='GUIDED_PRODUCTION'; g['artifactQueue']=[{'artifactId':'STYLE_BIBLE','sourceAliases':['Style Bible'],'minimumChars':180,'required':True,'gate':'ANIMATIC'}]
gtext=text.replace('delivery=SINGLE_PASS_BLUEPRINT','delivery=GUIDED_PRODUCTION')
rr,_,_=run_case('guided_scope_leak',g,gtext,False,['GUIDED_SCOPE_LEAK']); results.append(rr)
# Non-narrative valid exception.
n=base_contract(); n['story']={'isNarrative':False,'autonomousOrImpossibleBehavior':False}; n['locks']['shotCount']=0; n['durationSeconds']=0
ntext=re.sub(r'<!-- AVD:STRUCT kind=.*?-->','',text); ntext=re.sub(r'<!-- AVD:SHOT.*?<!-- /AVD:SHOT -->','',ntext,flags=re.S)
rr,_,_=run_case('non_narrative_exception',n,ntext,True); results.append(rr)
# Guide staleness warning only.
s=base_contract(); s['guideAlignment']={'snapshotDate':'2020-01-01','maxAgeDays':30}
rr,_,res=run_case('guide_staleness_warning',s,text,True); rr['warningCodes']=sorted(x['code'] for x in res['warnings']); rr['pass']=rr['pass'] and 'GUIDE_ALIGNMENT_STALE' in rr['warningCodes']; results.append(rr)
# Evidence file/hash check via direct record mutation.
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'response.md'; p.write_text(text); o=extract(c,p); c2=copy.deepcopy(c); c2['deliveryMode']='FINISHED_PRODUCTION'; c2['evidenceCeiling']='RELEASE-PASS'; o['maturity']='RELEASE-PASS'; o['evidence']['visual']=[{'assetId':'A','version':'v1','path':'missing.png','sha256':'bad','inspectionDate':'2026-07-19','inspectionMethod':'vision','verdict':'ASSET-PASS'}]; o['evidence']['motion']=[{'assetId':'M','version':'v1','path':'missing.mp4','sha256':'bad','inspectionDate':'2026-07-19','inspectionMethod':'vision','verdict':'MOTION-PASS'}]; o['evidence']['audio']=[{'assetId':'X','version':'v1','path':'missing.wav','sha256':'bad','inspectionDate':'2026-07-19','inspectionMethod':'listen','verdict':'RELEASE-PASS'}]
 res=result(c2,o,td); results.append({'case':'evidence_file_missing','pass':'EVIDENCE_FILE_MISSING' in codes(res),'validatorPass':res['pass'],'codes':sorted(codes(res))})
# Structure/preservation.
rt=(ROOT/'rules/RUNTIME.md').read_text(); sk=(ROOT/'SKILL.md').read_text(); regs=(ROOT/'dev/REGRESSION_TESTS.md').read_text()
checks={'version':'version: 7.6.0' in sk,'fiveBundles':len(re.findall(r'^# Bundle [1-5] —',rt,re.M))==5,'coreController':(ROOT/'rules/CORE_CONTROLLER.md').is_file(),'extractor':(ROOT/'validators/extract_actual_output.py').is_file(),'compiler':(ROOT/'validators/compile_and_validate.py').is_file(),'hostProbe':(ROOT/'validators/probe_host.py').is_file(),'nanoVeo':all((ROOT/p).is_file() for p in ['adapters/generation/NANO_BANANA.md','adapters/generation/VEO_3_1.md','adapters/generation/NANO_BANANA_VEO_PIPELINE.md']),'detailed':len(list((ROOT/'rules/detailed').rglob('*.md')))>=52,'history':all((ROOT/p).is_file() for p in ['rules/history/V7_2_1_SKILL.md','rules/history/V7_2_1_RUNTIME.md']),'runtimeCompression':len(rt.split())<=3500}
out={'release':'7.6.0','scope':'actual extraction + deterministic positive/boundary/mutation tests','liveCrossModelProof':False,'liveNanoVeoProof':False,'productionPilotProof':False,'caseResults':results,'structuralChecks':checks,'pass':all(x['pass'] for x in results) and all(checks.values())}
(RESULTS/'V7_3_TEST_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2)); raise SystemExit(0 if out['pass'] else 1)
