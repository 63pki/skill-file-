#!/usr/bin/env python3
import runpy
runpy.run_path(str(__import__('pathlib').Path(__file__).with_name('run_finalization_tests.py')),run_name='__main__')
