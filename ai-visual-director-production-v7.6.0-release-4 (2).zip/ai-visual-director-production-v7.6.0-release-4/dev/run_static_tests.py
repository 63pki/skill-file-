#!/usr/bin/env python3
import os
from pathlib import Path
import re,json,sys
root=Path(__file__).resolve().parents[1]
RESULTS=Path(os.environ.get('AVD_RESULTS_DIR',str(root/'dev/results')));RESULTS.mkdir(parents=True,exist_ok=True)
def has(p,*terms):
 t=(root/p).read_text(); return all(x in t for x in terms)
rt=(root/'rules/RUNTIME.md').read_text(); sk=(root/'SKILL.md').read_text(); core=(root/'rules/CORE_CONTROLLER.md').read_text(); regs=(root/'dev/REGRESSION_TESTS.md').read_text(); release=json.loads((root/'release/RELEASE.json').read_text()); rr=release['regressionCatalog']
ids=[int(x) for x in re.findall(r'^\| R(\d+) \|',regs,re.M)]
checks={
 'version':f"version: {release['version']}" in sk,
 'compact_active_path':len(sk.split())+len(core.split())+len(rt.split())<=5200,
 'five_bundles':len(re.findall(r'^# Bundle [1-5] —',rt,re.M))==5,
 'delivery_modes':all(x in sk+rt for x in ['GUIDED PRODUCTION','SINGLE-PASS BLUEPRINT','FINISHED PRODUCTION']),
 'controller':all(x in core for x in ['Route delivery','Probe capability','Compile full contract','Extract and validate actual output']),
 'actual_extractor':(root/'validators/extract_actual_output.py').is_file(),
 'compile_validate':(root/'validators/compile_and_validate.py').is_file(),
 'semantic_separation':has('rules/RUNTIME.md','Semantic review','MODEL-REVIEWED','Deterministic validation'),
 'host_probe':(root/'validators/probe_host.py').is_file() and has('rules/RUNTIME.md','Model and host profiles'),
 'script_timing':has('rules/RUNTIME.md','Store exact line text','Count words from the line'),
 'structured_story':has('rules/RUNTIME.md','Structured world rule','Structured durable resolution'),
 'full_locks':has('rules/RUNTIME.md','silhouette signature','prop ownership','shade/light logic','ending state'),
 'evidence_integrity':has('rules/RUNTIME.md','SHA-256','reinspection'),
 'compact_receipt':has('SKILL.md','Status: [mode]','Do not expose a full activation receipt'),
 'nano_veo':all((root/p).is_file() for p in ['adapters/generation/NANO_BANANA.md','adapters/generation/VEO_3_1.md','adapters/generation/NANO_BANANA_VEO_PIPELINE.md']),
 'protocols':all((root/p).is_file() for p in ['dev/V7_3_LIVE_REPLAY_PROTOCOL.md','dev/NANO_VEO_AB_PROTOCOL.md','dev/PRODUCTION_PILOT_PROTOCOL.md']),
 'regressions_manifest_range':len(ids)==rr['requiredCount'] and set(ids)==set(range(rr['firstId'],rr['lastId']+1)),
 'phase_b_quality':all((root/p).is_file() for p in ['validators/phase_b_quality.py','validators/artifact_schemas.json','templates/PROJECT_INDEX.json','templates/EVIDENCE_RECORD.json']),
 'phase_c_quality':all((root/p).is_file() for p in ['validators/phase_c_usability.py','validators/validate_semantic_review.py','templates/REPAIR_PLAN.json','templates/USABILITY_PROFILE.json']),
 'phase_d_external':all((root/p).is_file() for p in ['validators/validate_external_evidence.py','templates/EXTERNAL_EVIDENCE_CAMPAIGN.json','templates/EXTERNAL_TRIAL_RECORD.json','templates/EXTERNAL_RATING_RECORD.json']),
 'dual_assurance_bootstrap':all((root/p).is_file() for p in ['templates/ROUTING_CONTRACT.json','templates/PROJECT_CONTRACT_PORTABLE.json','bootstrap/bootstrap_runtime.py','bootstrap/finalize_contract_binding.py','validators/validate_runtime_load.py']),
 'phase_a_order':all(x in sk+rt for x in ['ROUTING_CONTRACT.json','VERIFIED_RUNTIME','PORTABLE_ASSURANCE','PLAN-PASS']),
 'detailed_preserved':len(list((root/'rules/detailed').rglob('*.md')))>=52,
 'v721_authority_archived':all((root/p).is_file() for p in ['rules/history/V7_2_1_SKILL.md','rules/history/V7_2_1_RUNTIME.md']),
 'architecture_title':has('ARCHITECTURE.md','# AI Visual Director Production V7.6.0 Evidence Release Architecture'),
}
out={'release':release['version'],'scope':'static structure, preservation, and active-runtime compression','behavioralProof':False,'checks':checks,'pass':all(checks.values())}
(RESULTS/'V7_3_STATIC_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2)); sys.exit(0 if out['pass'] else 1)
