#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,os,stat,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'));sys.path.insert(0,str(ROOT/'bootstrap'))
from validate_instruction_compliance import validate as validate_receipt,STEPS
from validate_clean_zip import validate_archive
from runtime_selection import select_rules
from build_package_manifest import build
rows=[]
def check(n,v,d=''):rows.append({'case':n,'pass':bool(v),'detail':d})
def codes(r):return {x.get('code') for x in r.get('errors',[])}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def make_contract():
 c=json.loads((ROOT/'templates/PROJECT_CONTRACT_PORTABLE.json').read_text());c['schemaVersion']='7.4.2-final';c['projectId']='D-TEST';c['mode']='C_MOTION_GRAPHICS';c['tools']={'stillGeneration':'UNASSIGNED','videoGeneration':'UNASSIGNED','postSurfaces':[]};c['story']={'isNarrative':False,'autonomousOrImpossibleBehavior':False};c['runtimeLoad']={'required':False};c['artifactQueue']=[{'artifactId':'A','required':True,'acceptance':'Complete artifact','repairAction':'Repair source','minimumChars':1,'sourcePath':'deliverables/A.md'}];c['qualityPolicy']['semanticReviewRequired']=False;c['packageRequired']=True;return c
def make_receipt(c):
 m=json.loads((ROOT/'bootstrap/runtime_load_manifest.json').read_text());paths=select_rules(c,m)[0]
 return {'schemaVersion':'7.6.0','release':'7.6.0','projectId':c['projectId'],'model':{'provider':'TEST_PROVIDER','name':'TEST_MODEL','version':'1'},'userWorkflowAuthorized':True,'agentIdentityChanged':False,'systemOverrideAttempted':False,'untrustedInstructionsExecuted':False,'runtimeManifestSha256':sha(ROOT/'bootstrap/runtime_load_manifest.json'),'selectedFiles':[{'path':p,'sha256':sha(ROOT/p),'status':'LOADED'} for p in paths],'orderedSteps':[{'id':x,'status':'COMPLETE','artifact':x+'.json'} for x in STEPS],'cognitiveAttentionProven':False}
c=make_contract();receipt=make_receipt(c);r=validate_receipt(receipt,c);check('valid-receipt',r['pass'],repr(r['errors']))
for name,mut,code in [
 ('release-binding',lambda x:x.update(release='wrong'),'INSTRUCTION_RELEASE_MISMATCH'),('project-binding',lambda x:x.update(projectId='wrong'),'INSTRUCTION_PROJECT_MISMATCH'),('identity-boundary',lambda x:x.update(agentIdentityChanged=True),'INSTRUCTION_BOUNDARY_VIOLATION'),('system-boundary',lambda x:x.update(systemOverrideAttempted=True),'INSTRUCTION_BOUNDARY_VIOLATION'),('untrusted-boundary',lambda x:x.update(untrustedInstructionsExecuted=True),'INSTRUCTION_BOUNDARY_VIOLATION'),('cognitive-boundary',lambda x:x.update(cognitiveAttentionProven=True),'COGNITIVE_PROOF_OVERCLAIM')]:
 x=copy.deepcopy(receipt);mut(x);check(name,code in codes(validate_receipt(x,c)))
x=copy.deepcopy(receipt);x['selectedFiles'][0]['sha256']='0'*64;check('file-hash-binding','INSTRUCTION_FILE_HASH_MISMATCH' in codes(validate_receipt(x,c)))
x=copy.deepcopy(receipt);x['selectedFiles'][0]['status']='PENDING';check('loaded-status','INSTRUCTION_FILE_NOT_LOADED' in codes(validate_receipt(x,c)))
x=copy.deepcopy(receipt);x['orderedSteps'][0],x['orderedSteps'][1]=x['orderedSteps'][1],x['orderedSteps'][0];check('step-order','INSTRUCTION_STEP_ORDER' in codes(validate_receipt(x,c)))
# Compiler blocks before extraction when receipt is absent.
with tempfile.TemporaryDirectory() as td:
 d=Path(td);cp=d/'c.json';cp.write_text(json.dumps(c));p=subprocess.run([sys.executable,str(ROOT/'validators/compile_and_validate.py'),str(cp),str(d/'missing'),'--outdir',str(d/'out')],capture_output=True,text=True);data=json.loads(p.stdout);check('missing-receipt-blocks',p.returncode!=0 and 'INSTRUCTION_RECEIPT_REQUIRED' in codes(data) and (d/'out/OUTPUT_RECORD.extracted.json').is_file())
# Valid receipt flows into compiler status.
with tempfile.TemporaryDirectory() as td:
 d=Path(td);pkg=d/'pkg';pkg.mkdir();(pkg/'deliverables').mkdir();(pkg/'deliverables/A.md').write_text('complete artifact');(pkg/'RESPONSE.md').write_text('<!-- AVD:STATUS delivery=SINGLE_PASS_BLUEPRINT maturity=PLAN-PASS media=NOT_GENERATED -->');(pkg/'PROJECT_INDEX.json').write_text(json.dumps({'artifacts':[{'artifactId':'A','sourcePath':'deliverables/A.md'}]}));(pkg/'PACKAGE_MANIFEST.json').write_text(json.dumps(build(pkg),indent=2)+'\n');cp=d/'c.json';cp.write_text(json.dumps(c));rp=d/'receipt.json';rp.write_text(json.dumps(receipt));out=d/'out';p=subprocess.run([sys.executable,str(ROOT/'validators/compile_and_validate.py'),str(cp),str(pkg),'--instruction-receipt',str(rp),'--outdir',str(out)],capture_output=True,text=True);st=json.loads((out/'DELIVERY_STATUS.json').read_text());check('compiler-compliance-result',p.returncode==0 and (out/'INSTRUCTION_COMPLIANCE_RESULT.json').is_file(),p.stdout);check('status-compliance',st['instructionCompliance']=='PASS')
# Clean ZIP safety fixtures.
def write_required(z,root='release'):
 z.writestr(root+'/SKILL.md','x');z.writestr(root+'/release/RELEASE.json',json.dumps({'version':'7.6.0'}));z.writestr(root+'/bootstrap/runtime_load_manifest.json','{}');z.writestr(root+'/dev/MANIFEST.json','{}')
with tempfile.TemporaryDirectory() as td:
 d=Path(td);z=d/'ok.zip'
 with zipfile.ZipFile(z,'w') as q:write_required(q)
 check('clean-zip-basic',validate_archive(z)['pass'])
 z=d/'traversal.zip'
 with zipfile.ZipFile(z,'w') as q:write_required(q);q.writestr('../escape','x')
 check('zip-traversal','ZIP_PATH_TRAVERSAL' in codes(validate_archive(z)))
 z=d/'two.zip'
 with zipfile.ZipFile(z,'w') as q:write_required(q);q.writestr('other/file','x')
 check('zip-one-root','ZIP_ROOT_COUNT' in codes(validate_archive(z)))
 z=d/'temp.zip'
 with zipfile.ZipFile(z,'w') as q:write_required(q);q.writestr('release/x.tmp','x')
 check('zip-temp','ZIP_TEMP_FILE' in codes(validate_archive(z)))
 z=d/'case.zip'
 with zipfile.ZipFile(z,'w') as q:write_required(q);q.writestr('release/A.txt','x');q.writestr('release/a.TXT','x')
 check('zip-duplicate-case','ZIP_DUPLICATE_PATH' in codes(validate_archive(z)))
 z=d/'link.zip'
 with zipfile.ZipFile(z,'w') as q:
  write_required(q);i=zipfile.ZipInfo('release/link');i.create_system=3;i.external_attr=(stat.S_IFLNK|0o777)<<16;q.writestr(i,'target')
 check('zip-symlink','ZIP_SYMLINK' in codes(validate_archive(z)))
 chk=d/'bad.sha256';chk.write_text('0'*64+'  ok.zip\n');check('zip-checksum','ZIP_CHECKSUM_MISMATCH' in codes(validate_archive(d/'ok.zip',chk)))
# Preservation and proof boundary.
base=json.loads((ROOT/'release/V7_4_1_BASELINE_HASHES.json').read_text());ok=all(sha(ROOT/p)==base['files'][p]['sha256'] for p in base['immutablePaths']);check('nano-veo-preserved',ok);check('manuals-52',len(list((ROOT/'rules/detailed').rglob('*.md')))==52);live=json.loads((ROOT/'release/RELEASE.json').read_text())['liveEvidence'];check('live-evidence-honest',not live['externalEvidenceClaimed'] and all(v=='NOT_RUN' for k,v in live.items() if k!='externalEvidenceClaimed'))
out={'release':'7.6.0','scope':'cross-model instruction compliance and clean-ZIP safety','results':rows,'pass':all(x['pass'] for x in rows),'liveCrossModelProof':False};dest=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));dest.mkdir(parents=True,exist_ok=True);(dest/'V7_4_2_PHASE_D_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
