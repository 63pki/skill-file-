# V7.3 Test Plan

Executable tests cover actual Markdown extraction, valid positive projects, Guided scope, Single-Pass maturity, artifact minimum bodies/placeholders, structured world and durable resolution, actual-line timing, duplicate lines, tool substitution, full lock drift, guide freshness, evidence file/hash checks, malformed records, non-narrative exceptions, mutation testing, and preservation. Live cross-model, Nano/Veo A/B, and complete pilot protocols are present but remain NOT RUN until real external evidence is supplied.
