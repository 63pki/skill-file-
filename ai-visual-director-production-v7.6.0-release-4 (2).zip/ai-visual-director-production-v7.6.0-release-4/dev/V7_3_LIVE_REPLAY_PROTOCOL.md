# V7.3 Live Cross-Model Replay Protocol

Record exact package/archive SHA-256, model/runtime, date, host profile, exact prompt, complete raw response, extractor output, deterministic result, semantic review, artifacts/media inventory, contradictions, omissions, false claims, and final verdict. Use at least two materially different model levels and three clean runs for critical benchmarks. Include Milo and non-Milo Mode A/B/C/D, documentary/faceless, product, localization, and hybrid cases. Static or fixture PASS is not live proof.
