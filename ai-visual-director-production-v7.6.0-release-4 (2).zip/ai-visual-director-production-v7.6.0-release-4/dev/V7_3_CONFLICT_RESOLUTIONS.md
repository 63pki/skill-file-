# V7.3 Conflict Resolutions

- Actual-output enforcement versus beginner simplicity: machine markers are invisible comments; user sees one compact status line.
- Deterministic versus semantic validation: deterministic code checks structure/arithmetic/files; semantic critic is separately labelled MODEL/HUMAN-REVIEWED.
- Solo workflow versus human evidence: creator preflight is reachable but never mislabeled as child/audience validation.
- Compression versus preservation: V7.2.1 authorities are archived byte-for-byte under `rules/history/`; five bundles and all detailed manuals remain; active text is consolidated.
- Official guides versus mode craft: adapter framework is preserved, but mode isolation and verified surface facts outrank examples.
- Finished scope versus unavailable tools: host probe selects fallback or BLOCKED; protocols are included but live media is not falsely claimed.
- Manifest completeness versus self-reference: manifest declares its own exclusion and archive checksum is published externally.
