# V7.4.0 Finalization and Evidence Hardening

Implemented release identity consistency, prompt-file/hash validation, provenance tiers, configurable policy floors, selected campaign scopes, comparable repeated cross-model runs, immutable A-B controls, unique reviewers, unknown/duplicate rating rejection, reviewer conflicts, pilot chain binding, real media/inspection requirements, chronology, hash-bound semantic evidence, semantic floors, expanded claims, optional structured semantic metadata, triggered Phase D loading, and split distributions.

Preservation requirements: Phase A-D history, Nano Banana/Veo adapters, 52 detailed manuals, and historical validators remain present. Live evidence remains NOT_RUN and unclaimed.
