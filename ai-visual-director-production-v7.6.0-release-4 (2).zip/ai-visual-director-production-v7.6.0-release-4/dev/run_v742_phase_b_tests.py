#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,os,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'));sys.path.insert(0,str(ROOT/'bootstrap'))
from extract_actual_output import parse_text,extract
from validate_project import validate
from validate_generation_prompts import validate as validate_prompts
from runtime_selection import select_rules
rows=[]
def check(case,ok,detail=''):rows.append({'case':case,'pass':bool(ok),'detail':detail})
def codes(items):return {x.get('code') for x in items if isinstance(x,dict)}
# Parser failure modes.
r=parse_text('<!-- AVD:SHOT id=S01 duration=nope wpm=fast -->\nLine: Hi\n<!-- /AVD:SHOT -->');check('malformed-numeric','MALFORMED_NUMERIC_FIELD' in codes(r[8]))
r=parse_text('<!-- AVD:ARTIFACT id=A -->body');check('unclosed-artifact','UNCLOSED_ARTIFACT_MARKER' in codes(r[8]))
r=parse_text('<!-- AVD:ARTIFACT id=A --><!-- AVD:ARTIFACT id=B -->x<!-- /AVD:ARTIFACT -->');check('nested-artifact','NESTED_ARTIFACT_MARKER' in codes(r[8]))
r=parse_text('<!-- /AVD:ARTIFACT -->');check('orphan-artifact','ORPHAN_ARTIFACT_CLOSE' in codes(r[8]))
r=parse_text('<!-- AVD:STATUS maturity="PLAN-PASS media=NOT_GENERATED -->');check('malformed-attributes',bool(codes(r[8]) & {'MALFORMED_STATUS_ATTRIBUTES','UNCLOSED_AVD_COMMENT'}))
r=parse_text('```avd-artifact\n[1,{"artifactId":"A","body":"body"}]\n```');check('fenced-array-safe','INVALID_AVD_ARTIFACT_ITEM' in codes(r[8]) and any(x.get('artifactId')=='A' for x in r[0]))
r=parse_text('<!-- AVD:STATUS maturity=PLAN-PASS media=NOT_GENERATED --><!-- AVD:STATUS maturity=MOTION-PASS media=GENERATED -->');check('status-conflict','STATUS_METADATA_CONFLICT' in codes(r[8]))
r=parse_text('<!-- AVD:TOOL role=stillGeneration owner=NANO_BANANA --><!-- AVD:TOOL role=stillGeneration owner=OTHER -->');check('tool-conflict','TOOL_METADATA_CONFLICT' in codes(r[8]))
# Shared-source extraction.
base={'schemaVersion':'7.4.2-phase-b','projectId':'P','extractionPolicy':{'projectIndexRequiredForPackages':True},'artifactQueue':[]}
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'shared.md').write_text('<!-- AVD:ARTIFACT id=A -->Alpha body<!-- /AVD:ARTIFACT -->\n<!-- AVD:ARTIFACT id=B -->Beta body<!-- /AVD:ARTIFACT -->')
 idx={'artifacts':[{'artifactId':'A','sourcePath':'shared.md'},{'artifactId':'B','sourcePath':'shared.md'}]};(d/'PROJECT_INDEX.json').write_text(json.dumps(idx));o=extract(base,d);b={x['artifactId']:x['body'] for x in o['artifacts']};check('shared-marker-isolation',b=={'A':'Alpha body','B':'Beta body'},repr(b))
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'shared.md').write_text('plain body without selectors');idx={'artifacts':[{'artifactId':'A','sourcePath':'shared.md'},{'artifactId':'B','sourcePath':'shared.md'}]};(d/'PROJECT_INDEX.json').write_text(json.dumps(idx));o=extract(base,d);check('shared-selector-required','SHARED_SOURCE_SELECTOR_REQUIRED' in codes(o['extractionIssues']))
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'PROJECT_INDEX.json').write_text(json.dumps({'artifacts':[{'artifactId':'A','sourcePath':'../escape.md'}]}));o=extract(base,d);check('index-path-escape','INDEX_PATH_ESCAPE' in codes(o['extractionIssues']))
# Prompt parser robustness.
contract={'schemaVersion':'7.4.2-phase-b','mode':'B_ANIMATION','tools':{'stillGeneration':'NANO_BANANA','videoGeneration':'VEO_3_1'},'generationPromptPolicy':{'modeBRequired':True},'artifactQueue':[{'artifactId':'IMAGE_PROMPT','required':True},{'artifactId':'VIDEO_PROMPT','required':True}]}
out={'artifacts':[{'artifactId':'IMAGE_PROMPT','body':'<!-- AVD:NANO_PROMPT id=N1 framework=NB-F1 -->broken'},{'artifactId':'VIDEO_PROMPT','body':'<!-- AVD:VEO_PROMPT id=V1 mode=V-F1 -->broken'}]};e=[];validate_prompts(contract,out,e);check('unclosed-prompt-blocks',{'UNCLOSED_NANO_PROMPT_MARKER','UNCLOSED_VEO_PROMPT_MARKER'}<=codes(e),repr(codes(e)))
# Audience routing.
manifest=json.loads((ROOT/'bootstrap/runtime_load_manifest.json').read_text());routing=json.loads((ROOT/'templates/ROUTING_CONTRACT.json').read_text());selected,_,errs,_=select_rules(routing,manifest);check('audience-owner-loaded','rules/production/AUDIENCE_SUITABILITY.md' in selected and not errs,repr(errs));bad=copy.deepcopy(routing);bad['audienceTriggers']=['UNKNOWN'];_,_,errs,_=select_rules(bad,manifest);check('unknown-audience-blocked',any(x.startswith('UNKNOWN_AUDIENCE_TRIGGER') for x in errs),repr(errs))
# Compiler parse/preflight robustness.
with tempfile.TemporaryDirectory() as td:
 d=Path(td);c=d/'bad.json';c.write_text('{bad');src=d/'missing';outdir=d/'out';p=subprocess.run([sys.executable,str(ROOT/'validators/compile_and_validate.py'),str(c),str(src),'--outdir',str(outdir)],capture_output=True,text=True);data=json.loads(p.stdout);check('contract-json-structured',p.returncode!=0 and 'CONTRACT_JSON_PARSE_ERROR' in codes(data['errors']) and 'Traceback' not in p.stderr)
# Binding status and audience evidence.
c=json.loads((ROOT/'templates/PROJECT_CONTRACT_PORTABLE.json').read_text());c['schemaVersion']='7.4.2-phase-b';c['audience']={'type':'CHILDREN','ageRange':'6-9','humanReviewRequiredForClaims':True};c['runtimeLoad']={'required':False};c['artifactQueue']=[]
o={'artifacts':[],'artifactsPresent':[],'shots':[],'lockUses':[],'story':{},'toolUse':{},'evidence':{k:[] for k in ['visual','motion','audio','humanReview','technical']},'maturity':'PLAN-PASS','statusMetadata':{'delivery':'FINISHED_PRODUCTION','maturity':'PLAN-PASS','media':'NOT_GENERATED'},'unsupportedClaimSignals':[{'category':'AUDIENCE','text':'children understood'}],'extractionIssues':[],'duplicateArtifactIds':[],'conflictingArtifactIds':[],'packageFiles':[]};e,w=validate(c,o);check('status-delivery-drift','STATUS_DELIVERY_DRIFT' in codes(e));check('audience-human-review','AUDIENCE_CLAIM_REQUIRES_HUMAN_REVIEW' in codes(e))
# Preservation.
basehash=json.loads((ROOT/'release/V7_4_1_BASELINE_HASHES.json').read_text());ok=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==basehash['files'][p]['sha256'] for p in basehash['immutablePaths']);check('nano-veo-hashes',ok);check('manuals-52',len(list((ROOT/'rules/detailed').rglob('*.md')))==52)
out={'release':'7.6.0','scope':'parser and validator robustness','results':rows,'pass':all(x['pass'] for x in rows),'liveGenerationProof':False};dest=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));dest.mkdir(parents=True,exist_ok=True);(dest/'V7_4_2_PHASE_B_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
