#!/usr/bin/env python3
import runpy
runpy.run_path(__file__.replace('run_bootstrap_tests.py','run_phase_a_tests.py'),run_name='__main__')
