#!/usr/bin/env python3
import os
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'bootstrap'));sys.path.insert(0,str(ROOT/'validators'))
RESULTS=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));RESULTS.mkdir(parents=True,exist_ok=True)
from runtime_selection import select_rules
from validate_generation_prompts import validate

def codes(e):return {x['code'] for x in e}
def check(name,v,rows):rows.append({'case':name,'pass':bool(v)})
manifest=json.loads((ROOT/'bootstrap/runtime_load_manifest.json').read_text());rows=[]
contract={'projectClass':'SUBSTANTIAL','audienceTriggers':['GENERAL'],'mode':'B_ANIMATION','tools':{'stillGeneration':'NANO_BANANA','videoGeneration':'VEO_3_1','postSurfaces':['AUDIO_ATTACHMENT_ONLY']},'generationPromptPolicy':{'modeBRequired':True},'artifactQueue':[{'artifactId':'CHARACTER_SHEET_PROMPTS','artifactType':'CHARACTER_SHEETS','required':True},{'artifactId':'ENVIRONMENT_PROMPTS','artifactType':'ENVIRONMENT_PROMPTS','required':True},{'artifactId':'ANIMATION_PROMPTS','artifactType':'ANIMATION_PROMPTS','required':True}]}
sel,_,errs,_=select_rules(contract,manifest)
needed={'rules/production/2D_ANIMATION.md','adapters/generation/NANO_BANANA.md','adapters/generation/VEO_3_1.md','adapters/generation/NANO_BANANA_VEO_PIPELINE.md','rules/production/AUDIO_ATTACHMENT.md'}
check('mode-b-auto-activation',needed<=set(sel) and not errs,rows)
bad=json.loads(json.dumps(contract));bad['tools']['stillGeneration']='UNASSIGNED';bad['tools']['videoGeneration']='UNASSIGNED';_,_,errs,_=select_rules(bad,manifest);check('unassigned-generators-block',any('REQUIRES_NANO_BANANA' in x for x in errs) and any('REQUIRES_VEO_3_1' in x for x in errs),rows)
bad=json.loads(json.dumps(contract));bad['tools']['postSurfaces']=['CANVA','CAPCUT'];_,_,errs,_=select_rules(bad,manifest);check('editor-routing-block',any('EDITOR_GUIDE_REMOVED' in x for x in errs),rows)
nb='''<!-- AVD:NANO_PROMPT id=CHAR-MILO framework=NB-F1 -->
Create a canonical character sheet.
Subject: CHAR-MILO with stable construction.
Action/state: neutral turnaround.
Location/context: clean field.
Composition: full body views with negative space.
Style and rendering: Mode B shape, silhouette, line, palette.
Output: 16:9 creative default, verify surface.
Acceptance: identity, parts, palette, line.
Excluded elements: photorealism, text.
<!-- /AVD:NANO_PROMPT -->'''
veo='''<!-- AVD:VEO_PROMPT id=S01 mode=V-F2 -->
Cinematography: wide eye-level view, one slow drift ending on Milo.
Subject: CHAR-MILO with approved reference.
Action: anticipate, rise, react, settle, hold.
Context: WORLD-VILLAGE, morning, fixed geography.
Style and ambiance: Mode B line, palette, staging, gentle pacing.
End state: stable readable pose and edit handle.
Audio route: EXTERNAL_AUDIO_ATTACHMENT.
Dialogue: NONE.
SFX: soft wake chime.
Ambient noise: gentle morning air.
Music: NONE.
Acceptance: identity, action, camera, endpoint, audio.
Fallback: simplify, shorten, re-anchor, or split.
<!-- /AVD:VEO_PROMPT -->'''
out={'artifacts':[{'artifactId':'CHARACTER_SHEET_PROMPTS','body':nb},{'artifactId':'ENVIRONMENT_PROMPTS','body':nb.replace('CHAR-MILO','WORLD-VILLAGE')},{'artifactId':'ANIMATION_PROMPTS','body':veo}]}
e=[];validate(contract,out,e);check('guide-aligned-prompt-blocks',not e,rows)
bad=json.loads(json.dumps(out));bad['artifacts'][0]['body']='generic image prompt';e=[];validate(contract,bad,e);check('missing-nano-block-fails','NANO_PROMPT_BLOCK_MISSING' in codes(e),rows)
bad=json.loads(json.dumps(out));bad['artifacts'][2]['body']=bad['artifacts'][2]['body'].replace('Cinematography:','Camera:');e=[];validate(contract,bad,e);check('incomplete-veo-formula-fails','VEO_PROMPT_FIELD' in codes(e),rows)
bad=json.loads(json.dumps(out));bad['artifacts'][2]['body']=bad['artifacts'][2]['body'].replace('Fallback:','CapCut keyframe diamond.\nFallback:');e=[];validate(contract,bad,e);check('editor-language-in-prompt-fails','EDITOR_LANGUAGE_IN_GENERATION_PROMPT' in codes(e),rows)
active=[p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and 'history' not in p.parts and ('canva' in p.name.lower() or 'capcut' in p.name.lower())]
check('active-editor-guides-removed',not active,rows)
audio=(ROOT/'rules/production/AUDIO_ATTACHMENT.md').read_text();check('audio-attachment-only-guide',all(x in audio for x in ['Attach audio','KEEP_VERIFIED_NATIVE','MUTE_AND_REPLACE','Dialogue is intelligible']),rows)
baseline=json.loads((ROOT/'release/V7_4_1_BASELINE_HASHES.json').read_text())['files']
check('official-nano-guide-preserved',hashlib.sha256((ROOT/'adapters/generation/NANO_BANANA.md').read_bytes()).hexdigest()==baseline['adapters/generation/NANO_BANANA.md']['sha256'],rows)
check('official-veo-guide-preserved',hashlib.sha256((ROOT/'adapters/generation/VEO_3_1.md').read_bytes()).hexdigest()==baseline['adapters/generation/VEO_3_1.md']['sha256'],rows)
check('official-pipeline-preserved',hashlib.sha256((ROOT/'adapters/generation/NANO_BANANA_VEO_PIPELINE.md').read_bytes()).hexdigest()==baseline['adapters/generation/NANO_BANANA_VEO_PIPELINE.md']['sha256'],rows)
result={'release':'7.6.0','scope':'four-chat generation-stack correction','results':rows,'pass':all(x['pass'] for x in rows),'liveGenerationProof':False}
(RESULTS/'V7_4_1_GENERATION_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(0 if result['pass'] else 1)
