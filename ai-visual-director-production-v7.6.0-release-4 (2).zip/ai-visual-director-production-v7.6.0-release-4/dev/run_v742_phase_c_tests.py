#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,os,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'))
from validate_delivery_package import validate_package,delivery_state
from build_package_manifest import build
rows=[]
def check(n,v,d=''):rows.append({'case':n,'pass':bool(v),'detail':d})
def codes(e):return {x.get('code') for x in e}
def contract(mode='SINGLE_PASS_BLUEPRINT'):
 c=json.loads((ROOT/'templates/PROJECT_CONTRACT_PORTABLE.json').read_text());c['schemaVersion']='7.4.2-phase-c';c['deliveryMode']=mode;c['mode']='C_MOTION_GRAPHICS';c['story']={'isNarrative':False,'autonomousOrImpossibleBehavior':False};c['runtimeLoad']={'required':False};c['artifactQueue']=[{'artifactId':'A','required':True,'acceptance':'Complete','repairAction':'Repair','sourcePath':'deliverables/A.md','minimumChars':1}];c['packageRequired']=True;c['qualityPolicy']['semanticReviewRequired']=False;return c
def output(maturity='PLAN-PASS',media='NOT_GENERATED'):
 return {'maturity':maturity,'statusMetadata':{'delivery':'SINGLE_PASS_BLUEPRINT','maturity':maturity,'media':media},'artifactsPresent':['A']}
def makepkg(root):
 (root/'deliverables').mkdir();p=root/'deliverables/A.md';p.write_text('complete artifact');idx={'schemaVersion':'7.4.2-phase-c','projectId':'P','artifacts':[{'artifactId':'A','sourcePath':'deliverables/A.md','sourceSha256':hashlib.sha256(p.read_bytes()).hexdigest()}]};(root/'PROJECT_INDEX.json').write_text(json.dumps(idx));(root/'PACKAGE_MANIFEST.json').write_text(json.dumps(build(root),indent=2)+'\n')
with tempfile.TemporaryDirectory() as td:
 r=Path(td);makepkg(r);e=validate_package(contract(),output(),r);check('valid-package',not e,repr(e));(r/'deliverables/A.md').write_text('tampered');e=validate_package(contract(),output(),r);check('tamper-detected','PACKAGE_MANIFEST_HASH_MISMATCH' in codes(e))
with tempfile.TemporaryDirectory() as td:
 r=Path(td);(r/'deliverables').mkdir();(r/'deliverables/A.md').write_text('x');(r/'PROJECT_INDEX.json').write_text(json.dumps({'artifacts':[{'artifactId':'A','sourcePath':'deliverables/A.md'}]}));e=validate_package(contract(),output(),r);check('manifest-required','PACKAGE_MANIFEST_REQUIRED' in codes(e))
with tempfile.TemporaryDirectory() as td:
 r=Path(td);makepkg(r);(r/'extra.txt').write_text('unlisted');e=validate_package(contract(),output(),r);check('unlisted-file','PACKAGE_MANIFEST_UNLISTED_FILES' in codes(e));(r/'scratch.tmp').write_text('x');e=validate_package(contract(),output(),r);check('temporary-file','PACKAGE_TEMP_FILES' in codes(e))
check('directory-required','PACKAGE_DIRECTORY_REQUIRED' in codes(validate_package(contract(),output(),None)))
check('blueprint-state',delivery_state(contract(),output(),True)=='BLUEPRINT_COMPLETE')
check('blueprint-media-block',delivery_state(contract(),output('PLAN-PASS','GENERATED'),True)=='REPAIR_REQUIRED')
g=contract('GUIDED_PRODUCTION');check('guided-state',delivery_state(g,output(),True)=='AWAITING_APPROVAL')
f=contract('FINISHED_PRODUCTION');fo=output('RELEASE-PASS','FINAL');fo['statusMetadata']['delivery']='FINISHED_PRODUCTION';check('finished-state',delivery_state(f,fo,True)=='READY_FOR_DELIVERY');check('failed-state',delivery_state(f,fo,False)=='REPAIR_REQUIRED')
# Compiler must emit machine status and a self-excluding validation manifest.
with tempfile.TemporaryDirectory() as td:
 r=Path(td)/'pkg';r.mkdir();(r/'RESPONSE.md').write_text('<!-- AVD:STATUS delivery=SINGLE_PASS_BLUEPRINT maturity=PLAN-PASS media=NOT_GENERATED -->');makepkg(r);c=contract();cp=Path(td)/'c.json';cp.write_text(json.dumps(c));out=Path(td)/'validation';p=subprocess.run([sys.executable,str(ROOT/'validators/compile_and_validate.py'),str(cp),str(r),'--outdir',str(out)],capture_output=True,text=True);st=json.loads((out/'DELIVERY_STATUS.json').read_text());vm=json.loads((out/'VALIDATION_PACKAGE_MANIFEST.json').read_text());check('machine-delivery-status',st['deliveryState']=='BLUEPRINT_COMPLETE' and not st['deliveryClaimAllowed'],p.stdout);check('validation-manifest','VALIDATION_PACKAGE_MANIFEST.json' in vm['excludedPaths'] and all(x['path']!='VALIDATION_PACKAGE_MANIFEST.json' for x in vm['files']))
# Preservation.
base=json.loads((ROOT/'release/V7_4_1_BASELINE_HASHES.json').read_text());ok=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==base['files'][p]['sha256'] for p in base['immutablePaths']);check('nano-veo-preserved',ok);check('manuals-52',len(list((ROOT/'rules/detailed').rglob('*.md')))==52)
out={'release':'7.6.0','scope':'package, status and delivery enforcement','results':rows,'pass':all(x['pass'] for x in rows),'liveGenerationProof':False};d=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));d.mkdir(parents=True,exist_ok=True);(d/'V7_4_2_PHASE_C_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
