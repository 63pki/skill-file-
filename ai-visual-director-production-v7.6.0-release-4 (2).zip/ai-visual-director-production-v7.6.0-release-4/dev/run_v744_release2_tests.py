#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,os,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'))
from select_host_profile import select
from validate_portable_record import validate,STEPS
rows=[]
def check(name,value,detail=''):rows.append({'case':name,'pass':bool(value),'detail':detail})
def codes(e):return {x.get('code') for x in e}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
verified={k:True for k in ['coreReadable','structuredOutput','filesystem','codeExecution','hashing','persistentArtifacts','selectedOwnerReadable','limitationsDisclosable']};portable={k:True for k in ['coreReadable','structuredOutput','selectedOwnerReadable','limitationsDisclosable']};portable.update({'filesystem':False,'codeExecution':False,'hashing':False,'persistentArtifacts':False})
check('verified-routing',select(verified)=='VERIFIED_RUNTIME');check('portable-routing',select(portable)=='PORTABLE_REFERENCE');check('unsupported-routing',select({'coreReadable':False})=='UNSUPPORTED_EXECUTION')
pm=json.loads((ROOT/'profiles/PORTABLE_REFERENCE_MANIFEST.json').read_text());check('script-free-profile',all(pm[k] is False for k in ['requiresScripts','requiresFilesystem','requiresHashes','requiresPersistentState']))
modeb=['rules/production/2D_ANIMATION.md','adapters/generation/NANO_BANANA.md','adapters/generation/VEO_3_1.md','adapters/generation/NANO_BANANA_VEO_PIPELINE.md','rules/production/AUDIO_ATTACHMENT.md'];selected=['SKILL.md','rules/CORE_CONTROLLER.md','profiles/PORTABLE_REFERENCE.md']+modeb+['rules/production/AUDIENCE_SUITABILITY.md'];record={'schemaVersion':'7.6.0','release':'7.6.0','projectId':'PORTABLE-TEST','profile':'PORTABLE_REFERENCE','hostCapabilities':portable,'selectedFiles':selected,'selectedProductionOwner':modeb[0],'selectedAudienceOwners':['rules/production/AUDIENCE_SUITABILITY.md'],'selectedAdapters':modeb[1:4],'steps':[{'id':x,'status':'COMPLETE','artifact':x+'.md'} for x in STEPS],'assurance':'PORTABLE_REFERENCE','deterministicRuntimeVerification':'NOT_AVAILABLE','instructionCompliance':'NOT_VERIFIED','mediaEvidence':'NOT_RUN','externalEvidenceClaimed':False,'maturityCeiling':'PLAN-PASS','limitations':['No deterministic runtime verification'],'claims':['planning completed']}
check('portable-record-valid',not validate(record,ROOT),json.dumps(validate(record,ROOT)))
x=copy.deepcopy(record);x['deterministicRuntimeVerification']='PASS';check('deterministic-overclaim-rejected','PORTABLE_EVIDENCE_OVERCLAIM' in codes(validate(x,ROOT)))
x=copy.deepcopy(record);x['instructionCompliance']='PASS';check('instruction-overclaim-rejected','PORTABLE_EVIDENCE_OVERCLAIM' in codes(validate(x,ROOT)))
x=copy.deepcopy(record);x['mediaEvidence']='GENERATED';check('media-overclaim-rejected','PORTABLE_EVIDENCE_OVERCLAIM' in codes(validate(x,ROOT)))
x=copy.deepcopy(record);x['steps'][0],x['steps'][1]=x['steps'][1],x['steps'][0];check('step-order-rejected','PORTABLE_STEP_ORDER' in codes(validate(x,ROOT)))
x=copy.deepcopy(record);x['selectedFiles'].remove('SKILL.md');check('core-required','PORTABLE_CORE_FILE_MISSING' in codes(validate(x,ROOT)))
x=copy.deepcopy(record);x['selectedFiles'].remove(modeb[0]);check('owner-required','PORTABLE_OWNER_NOT_LOADED' in codes(validate(x,ROOT)))
for name,path in [('nano-required',modeb[1]),('veo-required',modeb[2]),('pipeline-required',modeb[3]),('audio-required',modeb[4])]:
 x=copy.deepcopy(record);x['selectedFiles'].remove(path);check(name,'PORTABLE_MODE_B_FILE_MISSING' in codes(validate(x,ROOT)))
x=copy.deepcopy(record);x['selectedFiles'].remove('rules/production/AUDIENCE_SUITABILITY.md');check('audience-required','PORTABLE_AUDIENCE_NOT_LOADED' in codes(validate(x,ROOT)))
am=json.loads((ROOT/'routing/ACTIVE_MODULE_MANIFEST.json').read_text());paths={m['path'] for m in am['modules']};check('active-manifest-owners',{'rules/production/2D_ANIMATION.md','rules/production/AUDIENCE_SUITABILITY.md'}<=paths)
check('references-not-mandatory',all(not str(x).startswith(('rules/detailed','rules/history')) for x in pm['requiredOrder']) and len(list((ROOT/'rules/detailed').rglob('*.md')))==52)
base=json.loads((ROOT/'release/V7_4_3_RELEASE_1_BASELINE_HASHES.json').read_text());current={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()};check('release1-paths-preserved',set(base['files'])<=current,f"missing={len(set(base['files'])-current)}")
check('protected-guide-hashes',all(sha(ROOT/p)==base['files'][p]['sha256'] for p in base['immutablePaths']))
out={'release':'7.6.0','scope':'Release 2 script-free portability and host routing','results':rows,'pass':all(x['pass'] for x in rows),'liveCrossModelProof':False,'liveNanoVeoProof':False,'productionPilotProof':False};dest=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));dest.mkdir(parents=True,exist_ok=True);(dest/'V7_4_4_RELEASE_2_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
