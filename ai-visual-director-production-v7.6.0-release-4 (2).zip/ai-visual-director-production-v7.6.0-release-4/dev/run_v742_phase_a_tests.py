#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,os,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'))
from validate_contract_schema import normalize_project_contract,validate_project_contract,validate_routing_contract
rows=[]
def check(case,ok,detail=''):rows.append({'case':case,'pass':bool(ok),'detail':detail})
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tree_hash(root):
 h=hashlib.sha256()
 for p in sorted(Path(root).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:
   h.update(p.relative_to(root).as_posix().encode());h.update(p.read_bytes())
 return h.hexdigest()
release=json.loads((ROOT/'release/RELEASE.json').read_text());base=json.loads((ROOT/'release/V7_4_1_BASELINE_HASHES.json').read_text())
check('canonical-release',release['version']=='7.6.0' and release['regressionCatalog']['lastId']==570)
check('baseline-self-contained',base['requiredPathCount']==len(base['files']) and all(sha(ROOT/p)==base['files'][p]['sha256'] for p in base['immutablePaths']))
scan='\n'.join(p.read_text(errors='ignore') for p in ROOT.rglob('*') if p.is_file() and 'history' not in p.parts and '__pycache__' not in p.parts)
forbidden='/data/ai-visual-director-production-'+'v7.4.0-final';check('no-external-baseline-path',forbidden not in scan)
for name in ['PROJECT_CONTRACT.json','PROJECT_CONTRACT_PORTABLE.json']:
 c=json.loads((ROOT/'templates'/name).read_text());check(name+'-schema',not validate_project_contract(c));check(name+'-canonical-repair',all('repairAction' in x and 'repair' not in x for x in c['artifactQueue']))
r=json.loads((ROOT/'templates/ROUTING_CONTRACT.json').read_text());check('routing-template-schema',not validate_routing_contract(r))
c=json.loads((ROOT/'templates/PROJECT_CONTRACT.json').read_text());c['locks']['characters']=['CHAR-MILO'];e=validate_project_contract(c);check('character-type-diagnostic',any(x['path']=='$.locks.characters[0]' for x in e))
c=json.loads((ROOT/'templates/PROJECT_CONTRACT.json').read_text());c['artifactQueue'][0].pop('repairAction');c['artifactQueue'][0]['repair']='legacy';n=normalize_project_contract(c);check('repair-alias-normalized',n['artifactQueue'][0]['repairAction']=='legacy' and not validate_project_contract(n))
check('field-guide',(ROOT/'templates/CONTRACT_FIELD_GUIDE.md').is_file())
oldpaths=set(base['files']);newpaths={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()};check('all-v741-paths-preserved',oldpaths<=newpaths,f'missing={len(oldpaths-newpaths)}')
check('manuals-52',len(list((ROOT/'rules/detailed').rglob('*.md')))==52)
manifest=json.loads((ROOT/'bootstrap/runtime_load_manifest.json').read_text());check('runtime-version',manifest['packageVersion']=='7.6.0')
# Current-source tests write externally and do not mutate source.
with tempfile.TemporaryDirectory() as td:
 before=tree_hash(ROOT);env=dict(os.environ,AVD_RESULTS_DIR=td)
 a=subprocess.run([sys.executable,str(ROOT/'dev/run_static_tests.py')],env=env,capture_output=True,text=True)
 b=subprocess.run([sys.executable,str(ROOT/'dev/run_v741_generation_tests.py')],env=env,capture_output=True,text=True)
 after=tree_hash(ROOT)
 check('external-results-static',a.returncode==0)
 check('external-results-generation',b.returncode==0)
 check('source-not-mutated',before==after)
 check('external-result-files',len(list(Path(td).glob('*.json')))>=2)
out={'release':'7.6.0','scope':'distribution and schema correctness','results':rows,'pass':all(x['pass'] for x in rows),'liveGenerationProof':False}
result_dir=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));result_dir.mkdir(parents=True,exist_ok=True);(result_dir/'V7_4_2_PHASE_A_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
