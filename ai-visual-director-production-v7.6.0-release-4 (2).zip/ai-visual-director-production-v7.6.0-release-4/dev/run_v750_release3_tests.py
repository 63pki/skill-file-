#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'bootstrap'))
from runtime_selection import select_rules
M=json.loads((ROOT/'bootstrap/runtime_load_manifest.json').read_text());rows=[]
def check(name,value,detail=''):rows.append({'case':name,'pass':bool(value),'detail':detail})
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def contract(mode='A_PHOTOREAL_COMMERCIAL',aud=None,prod=None):
 tools={'stillGeneration':'UNASSIGNED','videoGeneration':'UNASSIGNED','postSurfaces':[]}
 if mode=='B_ANIMATION':tools={'stillGeneration':'NANO_BANANA','videoGeneration':'VEO_3_1','postSurfaces':['AUDIO_ATTACHMENT_ONLY']}
 return {'projectClass':'SUBSTANTIAL','mode':mode,'audienceTriggers':aud or ['GENERAL'],'productionTriggers':prod or [],'tools':tools}
def route(c):
 s,_,e,_=select_rules(c,M);return set(s),set(e)
mode_paths={'A_PHOTOREAL_COMMERCIAL':'rules/production/MODE_A_PHOTOREAL_COMMERCIAL.md','B_ANIMATION':'rules/production/2D_ANIMATION.md','C_MOTION_GRAPHICS':'rules/production/MODE_C_MOTION_GRAPHICS.md','D_HYBRID_COMPOSITING':'rules/production/MODE_D_HYBRID_COMPOSITING.md'}
for mode,path in mode_paths.items():
 s,e=route(contract(mode));check('mode-'+mode,path in s and not e,','.join(sorted(e)))
s,e=route(contract('UNKNOWN_MODE'));check('unknown-mode-blocked',any(x.startswith('UNKNOWN_MODE_TRIGGER') for x in e))
s,e=route(contract('B_ANIMATION'));check('mode-b-isolation','rules/production/MODE_A_PHOTOREAL_COMMERCIAL.md' not in s and 'rules/production/MODE_C_MOTION_GRAPHICS.md' not in s)
s,e=route(contract('C_MOTION_GRAPHICS'));check('mode-c-isolation','rules/production/2D_ANIMATION.md' not in s and 'adapters/generation/NANO_BANANA.md' not in s)
s,e=route(contract('D_HYBRID_COMPOSITING'));check('mode-d-source-owner','rules/production/MODE_D_HYBRID_COMPOSITING.md' in s)
prod_paths={'FACTUAL_DOCUMENTARY':'rules/production/FACTUAL_DOCUMENTARY.md','LOCALIZATION':'rules/production/LOCALIZATION.md','ARCHITECTURAL_CONTINUITY':'rules/production/ARCHITECTURAL_CONTINUITY.md','UGC_ADVERTISING':'rules/production/UGC_ADVERTISING.md','CINEMATIC_SCENE':'rules/production/CINEMATIC_SCENE.md'}
for trig,path in prod_paths.items():
 mode='A_PHOTOREAL_COMMERCIAL';aud=['MULTILINGUAL'] if trig=='LOCALIZATION' else ['GENERAL'];s,e=route(contract(mode,aud,[trig]));check('production-'+trig,path in s and not e,','.join(sorted(e)))
s,e=route(contract('A_PHOTOREAL_COMMERCIAL',['GENERAL'],['LOCALIZATION']));check('localization-needs-multilingual','LOCALIZATION_REQUIRES_MULTILINGUAL_AUDIENCE' in e)
s,e=route(contract('B_ANIMATION',['GENERAL'],['ARCHITECTURAL_CONTINUITY']));check('architecture-needs-a-or-d','ARCHITECTURAL_REQUIRES_MODE_A_OR_D' in e)
s,e=route(contract('A_PHOTOREAL_COMMERCIAL',['GENERAL'],['UNKNOWN_OWNER']));check('unknown-production-blocked',any(x.startswith('UNKNOWN_PRODUCTION_TRIGGER') for x in e))
aud_paths={'CHILDREN_6_9':'rules/audience/CHILDREN_6_9.md','EXPERT':'rules/audience/EXPERT_TECHNICAL.md','VULNERABLE':'rules/audience/VULNERABLE_AUDIENCES.md','ACCESSIBILITY':'rules/audience/ACCESSIBILITY.md','MULTILINGUAL':'rules/audience/MULTILINGUAL.md','REGULATED':'rules/audience/REGULATED_CLAIMS.md'}
base='rules/production/AUDIENCE_SUITABILITY.md'
for trig,path in aud_paths.items():
 s,e=route(contract('A_PHOTOREAL_COMMERCIAL',[trig]));check('audience-'+trig,base in s and path in s and not e,','.join(sorted(e)))
s,e=route(contract('A_PHOTOREAL_COMMERCIAL',['GENERAL']));check('audience-general-baseline',base in s and not any(x in s for x in aud_paths.values()) and not e)
s,e=route(contract('A_PHOTOREAL_COMMERCIAL',['UNKNOWN_AUDIENCE']));check('unknown-audience-blocked',any(x.startswith('UNKNOWN_AUDIENCE_TRIGGER') for x in e))
s,e=route(contract('A_PHOTOREAL_COMMERCIAL',['ACCESSIBILITY','REGULATED']));check('multi-audience-combination',base in s and aud_paths['ACCESSIBILITY'] in s and aud_paths['REGULATED'] in s and not e)
content_checks={
 'factual-no-fake-evidence':('rules/production/FACTUAL_DOCUMENTARY.md','never present them as captured evidence'),
 'localization-locale-record':('rules/production/LOCALIZATION.md','Locale matrix'),
 'architecture-no-invented-features':('rules/production/ARCHITECTURAL_CONTINUITY.md','Never invent property features'),
 'ugc-no-fabricated-testimony':('rules/production/UGC_ADVERTISING.md','fabricated customer experience'),
 'cinematic-continuity':('rules/production/CINEMATIC_SCENE.md','eyelines'),
 'mode-a-claims-rights':('rules/production/MODE_A_PHOTOREAL_COMMERCIAL.md','claim register'),
 'mode-c-easing-reduced-motion':('rules/production/MODE_C_MOTION_GRAPHICS.md','reduced-motion'),
 'mode-d-tracking-disclosure':('rules/production/MODE_D_HYBRID_COMPOSITING.md','Tracking, mask, depth, and occlusion'),
 'children-no-simulated-review':('rules/audience/CHILDREN_6_9.md','Child comprehension remains `NOT_RUN`'),
 'accessibility-review-boundary':('rules/audience/ACCESSIBILITY.md','Automated checks are preflight'),
 'regulated-substantiation':('rules/audience/REGULATED_CLAIMS.md','claim ledger')}
for name,(path,token) in content_checks.items():check(name,token in (ROOT/path).read_text())
am=json.loads((ROOT/'routing/ACTIVE_MODULE_MANIFEST.json').read_text());active={x['path'] for x in am['modules']};expected=set(mode_paths.values())|set(prod_paths.values())|set(aud_paths.values())|{base};check('active-manifest-complete',expected<=active,f'missing={sorted(expected-active)}')
manifest_files=set(M['files']);check('runtime-manifest-complete',expected<=manifest_files,f'missing={sorted(expected-manifest_files)}')
basehash=json.loads((ROOT/'release/V7_4_4_RELEASE_2_BASELINE_HASHES.json').read_text());current={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()};check('release2-paths-preserved',set(basehash['files'])<=current,f"missing={len(set(basehash['files'])-current)}")
check('protected-guide-hashes',all(sha(ROOT/p)==basehash['files'][p]['sha256'] for p in basehash['immutablePaths']))
check('manuals-preserved',len(list((ROOT/'rules/detailed').rglob('*.md')))==52)
release=json.loads((ROOT/'release/RELEASE.json').read_text());check('release-range',release['version']=='7.6.0' and release['regressionCatalog']['lastId']==570)
out={'release':'7.6.0','scope':'Release 3 authoritative production breadth and specialist audiences','results':rows,'pass':all(x['pass'] for x in rows),'liveCrossModelProof':False,'liveNanoVeoProof':False,'productionPilotProof':False};dest=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));dest.mkdir(parents=True,exist_ok=True);(dest/'V7_5_0_RELEASE_3_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
