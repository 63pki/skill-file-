# V7.2 Deterministic Execution Tests

The three V7.1 Milo runs are encoded as failure fixtures. They verify tool substitution, missing artifacts/world rules, anatomy/face drift, and timing contradictions. These fixtures are concise evidence records, not claimed full-model replays.

`python3 dev/run_v72_tests.py` runs the deterministic validator against all fixtures and checks V7.2 structure. A live replay still requires exact prompts, model/runtime capture, complete outputs, and media evidence where applicable.
