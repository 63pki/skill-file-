# Official Prompt-Guide Alignment — V7.2.1

## Claim boundary

**Claim:** The V7.2.1 Nano Banana and Veo 3.1 prompt compilers cover the prompting frameworks and recommendations in the official sources below as reviewed on **2026-07-19**.

**Not claimed:** permanent future alignment, universal feature availability, API compatibility on every surface, successful generation, visual/audio quality, or live cross-model behavior.

## Official sources reviewed

1. Google AI for Developers — `https://ai.google.dev/gemini-api/docs/image-generation`
2. Google Cloud — `https://cloud.google.com/blog/products/ai-machine-learning/ultimate-prompting-guide-for-nano-banana` (2026-03-05)
3. Google Cloud — `https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/video/video-gen-prompt-guide`
4. Google Cloud — `https://cloud.google.com/blog/products/ai-machine-learning/ultimate-prompting-guide-for-veo-3-1` (2025-10-15)
5. Google AI for Developers — `https://ai.google.dev/gemini-api/docs/veo`

## Nano Banana coverage matrix

| Official recommendation | V7.2.1 implementation |
|---|---|
| Strong operation verb | Adapter principles and every framework template |
| Specific subject, lighting, composition | NB-F1/NB-F2 + creative-director controls |
| Positive framing | Principles + positive target + exclusion boundary |
| Camera/viewpoint control | Composition and creative-director controls |
| Conversational iteration | NB-F3 and controlled repair |
| Text-to-image narrative formula | NB-F1: subject + action + context + composition + style |
| Reference relationship instruction | NB-F2 relationship table |
| Semantic editing and preserve-the-rest | NB-F3 |
| Grounded current visualization | NB-F4 source + analysis + visual translation |
| Exact text, font, localization, text-first | NB-F5 |
| Lighting, lens/focus, grading, materiality | Creative-director controls |
| Model-family selection | Date-scoped model router with runtime verification |
| Nano-to-Veo keyframes | Guide-aligned pipeline |

## Veo coverage matrix

| Official recommendation | V7.2.1 implementation |
|---|---|
| Cinematography + subject + action + context + style/ambiance | Mandatory five-part compiler |
| Shot size, angle, movement, lens/focus | Cinematography field |
| Specific action and context | Subject/action/context fields |
| Dialogue in quotation marks | Separate audio compiler |
| Separate SFX and ambience | Separate `SFX:` / `Ambient noise:` sentences |
| Positive exclusions/negative prompt guidance | Positive rewrite + concise excluded-elements field |
| Image-to-video | V-F2 |
| Ingredients/reference consistency | V-F3 relationship table |
| First and last frame | V-F4 with directed middle |
| Timestamp prompting | V-F5 with arithmetic validation |
| Native audio when verified | Surface verification + audio path |
| Nano keyframe workflow | Guide-aligned pipeline |
| Failure repair | Failure routing and fallback |

## Conflict resolutions

- Official photographic examples do not leak into Mode B; animation-native language remains authoritative unless hybrid/photoreal style is selected.
- Exact capability numbers are volatile. The adapters route by verified model/surface instead of turning dated guide values into universal claims.
- The Google Cloud Veo guide notes that add/remove-object may route through another model. V7.2.1 does not mislabel that operation as Veo 3.1.
- Editable post text remains available, but generated typography is now a first-class official Nano route.
- Safety, rights, consent, evidence, and maturity rules remain above creative prompt guidance.
