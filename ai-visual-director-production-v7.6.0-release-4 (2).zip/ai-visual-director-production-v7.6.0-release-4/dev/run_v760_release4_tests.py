#!/usr/bin/env python3
from pathlib import Path
import copy,datetime,hashlib,json,os,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'))
from validate_external_evidence import validate as validate_external
from validate_human_evidence import validate as validate_human
from build_evidence_manifest import build as build_manifest
from validate_evidence_manifest import validate as validate_manifest
from compile_live_evidence_status import compile_status
rows=[]
def check(name,value,detail=''):rows.append({'case':name,'pass':bool(value),'detail':detail})
def codes(x):
 items=x if isinstance(x,list) else x.get('errors',[]) if isinstance(x,dict) else []
 return {e.get('code') for e in items if isinstance(e,dict)}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
release=json.loads((ROOT/'release/RELEASE.json').read_text());expected={'liveCrossModelReplay':'NOT_RUN','nanoVeoABGeneration':'NOT_RUN','completeProductionPilot':'NOT_RUN','beginnerOperatorPilot':'NOT_RUN','audienceComprehensionReview':'NOT_RUN','externalEvidenceClaimed':False};check('distribution-not-run',release['liveEvidence']==expected);check('no-external-claim',release['liveEvidence']['externalEvidenceClaimed'] is False)
empty={'release':'7.6.0','status':'NOT_RUN','campaignScope':['ALL_TRACKS'],'trials':[],'ratings':[]};ev=validate_external(empty);check('empty-external-honest',ev['pass'] and all(v=='NOT_PROVEN' for v in ev['trackStatus'].values()))
def trial(cls='DRY_RUN'):
 return {'trialId':'T1','track':'CROSS_MODEL_REPLAY','benchmarkId':'B','projectId':'P','provider':'Provider','model':'Model','modelVersion':'1','provenanceLevel':'DECLARED','promptPath':'p','promptSha256':'1'*64,'responsePath':'r','responseSha256':'2'*64,'settingsSha256':'3'*64,'rubricSha256':'4'*64,'skillArchiveSha256':'5'*64,'routingContractSha256':'6'*64,'projectContractSha256':'7'*64,'runtimeReceiptSha256':'8'*64,'executedAt':'2026-07-20T06:00:00Z','operatorId':'O','promptAuthorId':'A','evidenceClass':cls}
for cls,name in [('DRY_RUN','dry-run-no-advance'),('SIMULATED_TEST','simulation-no-advance')]:
 x=validate_external({'release':'7.6.0','status':'IN_PROGRESS','campaignScope':['CROSS_MODEL_REPLAY'],'trials':[trial(cls)],'ratings':[]});check(name,x['pass'] and x['liveTrialCount']==0 and x['trackStatus']['liveCrossModelReplay']=='NOT_PROVEN')
x=validate_external({'release':'7.6.0','status':'COMPLETE','campaignScope':['CROSS_MODEL_REPLAY'],'trials':[trial('DRY_RUN')],'ratings':[]});check('complete-needs-live','COMPLETE_WITHOUT_LIVE_EVIDENCE' in codes(x))
with tempfile.TemporaryDirectory() as td:
 root=Path(td);records=root/'records';records.mkdir()
 def session(i,track='BEGINNER_OPERATOR',cls='LIVE_EXTERNAL'):
  p=records/f'{track}-{i}.json';p.write_text(json.dumps({'session':i,'track':track})+'\n');return {'schemaVersion':'7.6.0','release':'7.6.0','sessionId':f'{track}-{i}','track':track,'projectId':'P','projectVersion':'v01','skillArchiveSha256':'a'*64,'operatorOrReviewerId':f'R{i}','independent':True,'relationshipToAuthor':'NONE','evidenceClass':cls,'startedAt':'2026-07-20T06:00:00Z','completedAt':'2026-07-20T06:30:00Z','completed':True,'recordPath':p.relative_to(root).as_posix(),'recordSha256':sha(p),'beginner':{'selfDeclaredBeginner':True,'taskCompleted':True,'repairCycles':1,'durationMinutes':30,'blockingErrors':[],'unsupportedClaims':[]},'audience':{'ageBand':'6-9','caregiverConsentRecorded':True,'privacySafe':True,'questionsAsked':['Why was the shadow gone?'],'responsesRecordedWithoutUnnecessaryPII':True,'comprehensionVerdict':'PASS'}}
 beginners=[session(i) for i in range(5)];audience=[session(i,'AUDIENCE_COMPREHENSION') for i in range(3)]
 campaign={'release':'7.6.0','status':'COMPLETE','campaignScope':['BEGINNER_OPERATOR','AUDIENCE_COMPREHENSION'],'minimums':{'beginnerOperator':{'completedIndependentSessions':5},'audienceComprehension':{'completedConsentedSessions':3}},'sessions':beginners+audience};hv=validate_human(campaign,root);check('human-live-floors',hv['pass'] and set(hv['trackStatus'].values())=={'PASS'},json.dumps(hv['errors']))
 sim=copy.deepcopy(campaign);sim['status']='IN_PROGRESS';
 for s in sim['sessions']:s['evidenceClass']='SIMULATED_TEST'
 sv=validate_human(sim,root);check('human-simulation-no-advance',sv['pass'] and all(v=='NOT_PROVEN' for v in sv['trackStatus'].values()))
 bad=copy.deepcopy(campaign);bad['sessions'][-1]['audience']['caregiverConsentRecorded']=False;bv=validate_human(bad,root);check('audience-consent-required','AUDIENCE_SAFEGUARD_MISSING' in codes(bv))
 bad=copy.deepcopy(campaign);bad['sessions'][-1]['audience']['privacySafe']=False;bv=validate_human(bad,root);check('audience-privacy-required','AUDIENCE_SAFEGUARD_MISSING' in codes(bv))
 bad=copy.deepcopy(campaign);bad['sessions'][0]['beginner']['unsupportedClaims']=['finished without evidence'];bv=validate_human(bad,root);check('beginner-claims-rejected','BEGINNER_UNSUPPORTED_CLAIM' in codes(bv))
 bad=copy.deepcopy(campaign);bad['sessions'][0]['recordPath']='../escape.json';bv=validate_human(bad,root);check('human-path-escape','HUMAN_PATH_ESCAPE' in codes(bv))
 bad=copy.deepcopy(campaign);bad['sessions'][0]['recordSha256']='0'*64;bv=validate_human(bad,root);check('human-hash-mismatch','HUMAN_HASH_MISMATCH' in codes(bv))
 # Evidence import manifest.
 m=build_manifest(root,campaign_id='H');mp=root/'EVIDENCE_IMPORT_MANIFEST.json';mp.write_text(json.dumps(m,indent=2)+'\n');check('evidence-manifest-valid',not validate_manifest(root,mp),json.dumps(validate_manifest(root,mp)))
 target=next(records.glob('*.json'));original=target.read_text();target.write_text(original+'tamper');check('evidence-manifest-tamper','EVIDENCE_MANIFEST_HASH' in codes(validate_manifest(root,mp)));target.write_text(original)
 extra=root/'unlisted.txt';extra.write_text('x');check('evidence-manifest-unlisted','EVIDENCE_MANIFEST_UNLISTED' in codes(validate_manifest(root,mp)));extra.unlink()
 temp=root/'bad.tmp';temp.write_text('x');tm=build_manifest(root,campaign_id='H');mp.write_text(json.dumps(tm,indent=2)+'\n');check('evidence-manifest-temp','EVIDENCE_MANIFEST_TEMP' in codes(validate_manifest(root,mp)));temp.unlink()
 compiled=compile_status({'pass':False,'trackStatus':{'liveCrossModelReplay':'PASS'}},{'pass':False,'trackStatus':{'beginnerOperatorPilot':'PASS'}});check('invalid-results-not-run',compiled['liveCrossModelReplay']=='NOT_RUN' and compiled['beginnerOperatorPilot']=='NOT_RUN' and not compiled['externalEvidenceClaimed'])
 compiled=compile_status({'pass':True,'trackStatus':{'liveCrossModelReplay':'PASS','nanoVeoABGeneration':'NOT_PROVEN','completeProductionPilot':'NOT_PROVEN'}},{'pass':True,'trackStatus':{'beginnerOperatorPilot':'PASS','audienceComprehensionReview':'NOT_PROVEN'}});check('validated-results-compile',compiled['liveCrossModelReplay']=='PASS' and compiled['beginnerOperatorPilot']=='PASS' and compiled['externalEvidenceClaimed'])
 check('compiled-proof-boundary','hidden provider behavior' in compiled['proofBoundary'])
base=json.loads((ROOT/'release/V7_5_0_RELEASE_3_BASELINE_HASHES.json').read_text());current={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()};check('release3-paths-preserved',set(base['files'])<=current,f"missing={len(set(base['files'])-current)}");check('protected-guide-hashes',all(sha(ROOT/p)==base['files'][p]['sha256'] for p in base['immutablePaths']));check('manuals-52',len(list((ROOT/'rules/detailed').rglob('*.md')))==52)
check('evidence-runbook',(ROOT/'rules/validation/LIVE_EVIDENCE_EXECUTION.md').is_file());check('release-range',release['version']=='7.6.0' and release['regressionCatalog']['lastId']==570)
out={'release':'7.6.0','scope':'Release 4 live-evidence import and validation infrastructure','results':rows,'pass':all(x['pass'] for x in rows),'liveEvidenceProduced':False,'liveCrossModelProof':False,'liveNanoVeoProof':False,'productionPilotProof':False,'beginnerPilotProof':False,'audienceProof':False};dest=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));dest.mkdir(parents=True,exist_ok=True);(dest/'V7_6_0_RELEASE_4_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
