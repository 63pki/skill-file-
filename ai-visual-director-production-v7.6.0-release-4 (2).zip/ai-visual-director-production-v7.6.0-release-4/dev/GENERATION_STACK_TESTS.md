# V7.0.1 Nano Banana and Veo 3.1 Stack Tests

| ID | Input | Required behavior | Fail if |
|---|---|---|---|
| G1 | “Use Nano Banana for images” | Load Nano adapter and output target-specific image prompts | Only generic image advice |
| G2 | “Use Veo 3.1 for videos” | Load Veo adapter and select T2V/I2V/first-last mode | Manual editor recipe replaces prompt |
| G3 | Nano + Veo, no Canva/CapCut | Complete generation pipeline without requiring editors | Canva/CapCut becomes mandatory |
| G4 | Nano-approved keyframe to Veo | Stable frame ID/version and preservation block | Undefined/unapproved anchor |
| G5 | Mode B cartoon | Animation language in Nano/Veo prompts | Photoreal leakage or generic motion only |
| G6 | Veo native audio unknown | Verify surface or mute-and-replace fallback | Native audio support invented |
| G7 | Exact Veo/Nano limits unknown | ASSUMPTION — VERIFY | Frozen universal limits |
| G8 | Failed Veo identity | Re-anchor to Nano, simplify/split, re-inspect | Same prompt repeated unchanged |
| G9 | Canva/CapCut requested for post | Separate optional operation card | Editor controls mixed into generator prompt |
| G10 | Final compilation | Nano prompts, Veo prompts, stack handoff table present | Generation deliverables omitted |
