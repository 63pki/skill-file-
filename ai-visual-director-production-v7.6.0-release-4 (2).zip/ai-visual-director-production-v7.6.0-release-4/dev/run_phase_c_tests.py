#!/usr/bin/env python3
import os
from pathlib import Path
import copy,json,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'validators'))
RESULTS=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));RESULTS.mkdir(parents=True,exist_ok=True)
from phase_c_usability import validate_usability,repair_plan,usability_summary
from validate_semantic_review import validate as semantic_validate

def base():
 return {'schemaVersion':'7.4.0-phase-d','projectId':'C','artifactQueue':[{'artifactId':'STYLE','gate':'DESIGN','required':True,'acceptance':'Named palette and line rules resolve to IDs.','repairAction':'Repair STYLE and revalidate.','operatorReady':True,'decisionTraceRequired':True}],'locks':{'characters':[{'assetId':'CHAR_1'}]},'qualityPolicy':{'strictUsability':True,'explicitReferences':True,'semanticReviewRequired':True},'usabilityProfile':{'operatorLevel':'BEGINNER','disclosure':'COMPACT_FIRST'}}
def output(body): return {'artifacts':[{'artifactId':'STYLE','body':body}],'artifactsPresent':['STYLE']}
def check(c,o):
 e=[];w=[];validate_usability(c,o,e,w);return e,w
def good_body(): return '''## Decision trace
Alternatives: angular and rounded.
Rejection reason: angular reads harsh.
Selected option: rounded.
Rationale: supports a safe tone.
[[AVD:ID id=PALETTE_1]]
[[AVD:REF id=CHAR_1]]
1. Input: approved character lock.
2. Action: apply PALETTE_1 and a navy outline.
3. Output: one operator-ready style frame.
4. Check: silhouette and palette IDs match.'''
results=[]; c=base(); e,w=check(c,output(good_body()));results.append({'case':'operator_ready_positive','pass':not e and any(x['code']=='SEMANTIC_REVIEW_REQUIRED' for x in w)})
x=base();x['artifactQueue'][0]['acceptance']='';e,w=check(x,output(good_body()));results.append({'case':'acceptance_required','pass':any(z['code']=='ARTIFACT_ACCEPTANCE_MISSING' for z in e)})
x=base();x['artifactQueue'][0]['repairAction']='';e,w=check(x,output(good_body()));results.append({'case':'repair_required','pass':any(z['code']=='ARTIFACT_REPAIR_MISSING' for z in e)})
e,w=check(c,output(good_body().split('1. Input:')[0]+'General descriptive prose without an executable sequence.'));results.append({'case':'steps_required','pass':any(z['code']=='OPERATOR_STEPS_MISSING' for z in e)})
e,w=check(c,output(good_body()+'\n[[AVD:REF id=MISSING_9]]'));results.append({'case':'reference_resolution','pass':any(z['code']=='UNRESOLVED_REFERENCE' for z in e)})
e,w=check(c,output(good_body()+'\nUse the same as above.'));results.append({'case':'vague_reference','pass':any(z['code']=='VAGUE_CROSS_REFERENCE' for z in e)})
e,w=check(c,output(good_body().replace('Rejection reason','Rejected because')));results.append({'case':'decision_trace','pass':any(z['code']=='DECISION_TRACE_MISSING' for z in e)})
x=base();x['usabilityProfile']['operatorLevel']='NOVICEISH';e,w=check(x,output(good_body()));results.append({'case':'operator_profile_enum','pass':any(z['code']=='OPERATOR_LEVEL_INVALID' for z in e)})
weights={'causality':15,'originality':15,'coherence':12,'composition':10,'modeCraft':12,'audienceComprehension':10,'soundRhythm':8,'feasibility':8,'continuity':7,'evidenceIntegrity':3}
dims=[{'id':k,'weight':v,'status':'PASS','score':8,'evidence':[{'artifactId':'STYLE','artifactSha256':'a'*64,'excerpt':'Concrete reviewed excerpt'}],'uncertainty':'Model review; no live audience test.'} for k,v in weights.items()]
review={'reviewType':'MODEL_REVIEWED','reviewedAt':'2026-07-19T08:00:00Z','requiredDimensions':list(weights),'dimensions':dims,'weightedScore':8,'verdict':'PASS','strongestRejectedAlternative':'Generic alternative','mostGenericRemainingElement':'Familiar palette','highestLeverageRepair':'Strengthen signature device','uncertainty':'No live audience test'}; sr=semantic_validate(review);results.append({'case':'semantic_evidence_positive','pass':sr['pass'] and sr['calculatedWeightedScore']==8})
bad=copy.deepcopy(review);bad['dimensions'][0]={'id':'causality','weight':15,'status':'NOT_REVIEWED','score':9,'evidence':[],'uncertainty':'Unavailable'};sr=semantic_validate(bad);results.append({'case':'no_invented_score','pass':any(z['code']=='INVENTED_SEMANTIC_SCORE' for z in sr['errors'])})
bad=copy.deepcopy(review);bad['dimensions'][0]['evidence']=[];sr=semantic_validate(bad);results.append({'case':'semantic_evidence_required','pass':any(z['code']=='SEMANTIC_EVIDENCE_MISSING' for z in sr['errors'])})
errors=[{'code':'UNRESOLVED_REFERENCE','message':'STYLE -> X','artifactId':'STYLE','gate':'DESIGN'}]; plan=repair_plan(c,errors,[]); summ=usability_summary(c,{'pass':False,'warnings':[]},plan);results.append({'case':'actionable_repair_plan','pass':plan['repairs'][0]['gate']=='DESIGN' and plan['repairs'][0]['acceptanceCheck'] and bool(summ['nextAction'])})
out={'release':'7.4.0-phase-d','scope':'progressive disclosure, operator readiness, explicit references, decision trace, evidence-bound semantic review, repair plans','results':results,'pass':all(bool(x['pass']) for x in results)};(RESULTS/'V7_4_PHASE_C_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
