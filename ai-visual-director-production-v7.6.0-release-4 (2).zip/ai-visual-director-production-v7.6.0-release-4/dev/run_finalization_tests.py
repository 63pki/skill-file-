#!/usr/bin/env python3
import os
from pathlib import Path
import copy,hashlib,json,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'))
RESULTS=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));RESULTS.mkdir(parents=True,exist_ok=True)
from validate_external_evidence import validate as ext
from validate_semantic_review import validate as sem
from extract_actual_output import parse_text

def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def codes(r):return {x['code'] for x in r['errors']}
def files(root,prefix):
 out={}
 for name,text in [('prompt',f'{prefix} prompt'),('response',f'{prefix} response'),('settings','fixed settings'),('rubric','fixed rubric')]:
  p=root/f'{prefix}-{name}.txt';p.write_text(text);out[name]=(p.name,h(p))
 return out
def trial(root,tid,track,**kw):
 f=files(root,tid);d={'trialId':tid,'track':track,'benchmarkId':'B1','projectId':'P1','provider':'A','model':'M1','modelVersion':'1','provenanceLevel':'HOST_CAPTURED','promptPath':f['prompt'][0],'promptSha256':f['prompt'][1],'responsePath':f['response'][0],'responseSha256':f['response'][1],'settingsPath':f['settings'][0],'settingsSha256':f['settings'][1],'rubricPath':f['rubric'][0],'rubricSha256':f['rubric'][1],'skillArchiveSha256':'1'*64,'routingContractSha256':'2'*64,'projectContractSha256':'3'*64,'runtimeReceiptSha256':'4'*64,'referenceSha256s':['5'*64],'executedAt':'2026-07-19T08:00:00Z','operatorId':'OP','promptAuthorId':'PA','evidenceClass':'LIVE_EXTERNAL'};d.update(kw);return d
def rate(tid,n):return {'ratingId':f'{tid}-R{n}','trialId':tid,'raterId':f'R{n}','reviewerRole':'independent critic','relationshipToOperator':'NONE','conflictDeclared':False,'independent':True,'blind':True,'variantSeen':'','hypothesisVisible':False,'reviewSessionId':f'S{tid}{n}','reviewedAt':'2026-07-19T09:00:00Z','verdict':'PASS','evidenceExcerpt':'fixture','uncertainty':'synthetic fixture'}
results=[]
def check(name,v):results.append({'case':name,'pass':bool(v)})
check('not-run honest',ext({'release':'7.4.0','status':'NOT_RUN','campaignScope':['ALL_TRACKS'],'trials':[],'ratings':[]})['pass'])
with tempfile.TemporaryDirectory() as td:
 r=Path(td);t=trial(r,'T','CROSS_MODEL_REPLAY');t['promptSha256']='f'*64;x=ext({'release':'7.4.0','status':'IN_PROGRESS','campaignScope':['CROSS_MODEL_REPLAY'],'trials':[t],'ratings':[]},r);check('prompt file hash','EXTERNAL_HASH_MISMATCH' in codes(x))
with tempfile.TemporaryDirectory() as td:
 r=Path(td);t=trial(r,'T','CROSS_MODEL_REPLAY');x=ext({'release':'7.4.0','status':'IN_PROGRESS','campaignScope':['CROSS_MODEL_REPLAY'],'trials':[t],'ratings':[rate('UNKNOWN',1)]},r);check('unknown rating trial','UNKNOWN_RATING_TRIAL' in codes(x))
with tempfile.TemporaryDirectory() as td:
 r=Path(td);t=trial(r,'T','CROSS_MODEL_REPLAY');rr=rate('T',1);x=ext({'release':'7.4.0','status':'IN_PROGRESS','campaignScope':['CROSS_MODEL_REPLAY'],'trials':[t],'ratings':[rr,rr]},r);check('duplicate rating id','DUPLICATE_RATING_ID' in codes(x) and 'DUPLICATE_RATER_TRIAL' in codes(x))
with tempfile.TemporaryDirectory() as td:
 r=Path(td);tr=[];shared=r/'shared-prompt.txt';shared.write_text('identical benchmark prompt');shared_hash=h(shared)
 for mi,(provider,model) in enumerate([('A','M1'),('A','M2'),('B','M3')]):
  for run in range(3):tr.append(trial(r,f'C{mi}{run}','CROSS_MODEL_REPLAY',provider=provider,model=model,promptPath=shared.name,promptSha256=shared_hash))
 x=ext({'release':'7.4.0','status':'COMPLETE','campaignScope':['CROSS_MODEL_REPLAY'],'minimums':{'crossModelReplay':{'models':3,'providers':2,'runsPerModel':3}},'trials':tr,'ratings':[]},r);check('comparable repeated runs',x['pass'] and x['trackStatus']['liveCrossModelReplay']=='PASS' and x['trackStatus']['nanoVeoABGeneration']=='NOT_APPLICABLE')
 bad=copy.deepcopy(tr);bad.pop();x=ext({'release':'7.4.0','status':'COMPLETE','campaignScope':['CROSS_MODEL_REPLAY'],'trials':bad,'ratings':[]},r);check('run floor enforced','EXTERNAL_CAMPAIGN_INCOMPLETE' in codes(x))
with tempfile.TemporaryDirectory() as td:
 r=Path(td);a=trial(r,'A','NANO_VEO_AB',pairId='PAIR',variant='BASELINE',abControlHash='d'*64);b=trial(r,'B','NANO_VEO_AB',pairId='PAIR',variant='CANDIDATE',abControlHash='d'*64);rs=[rate('A',1),rate('A',2),rate('B',1),rate('B',2)];x=ext({'release':'7.4.0','status':'COMPLETE','campaignScope':['NANO_VEO_AB'],'trials':[a,b],'ratings':rs},r);check('controlled ab',x['pass'] and x['trackStatus']['nanoVeoABGeneration']=='PASS')
 b['abControlHash']='e'*64;x=ext({'release':'7.4.0','status':'COMPLETE','campaignScope':['NANO_VEO_AB'],'trials':[a,b],'ratings':rs},r);check('ab control mismatch','EXTERNAL_CAMPAIGN_INCOMPLETE' in codes(x))
body='The shadow returns only after Milo shares the lantern.';bh=hashlib.sha256(body.encode()).hexdigest();arts=[{'artifactId':'STORY','body':body,'bodySha256':bh}]
dims=[]
for did,w in {'causality':15,'originality':15,'coherence':12,'modeCraft':12,'audienceComprehension':10}.items():dims.append({'id':did,'weight':w,'status':'PASS','score':8,'evidence':[{'artifactId':'STORY','artifactSha256':bh,'excerpt':'Milo shares the lantern.'}],'uncertainty':'Text-only judgment'})
review={'reviewType':'MODEL_REVIEWED','reviewedAt':'2026-07-19T09:00:00Z','requiredDimensions':[x['id'] for x in dims],'dimensions':dims,'weightedScore':8,'verdict':'PASS','strongestRejectedAlternative':'Dream ending','mostGenericRemainingElement':'Lantern device','highestLeverageRepair':'Strengthen choice','uncertainty':'No audience test'}
x=sem(review,arts);check('hash-bound semantic pass',x['pass'])
bad=copy.deepcopy(review);bad['dimensions'][0]['evidence'][0]['excerpt']='invented quote';x=sem(bad,arts);check('semantic excerpt binding','SEMANTIC_EXCERPT_NOT_FOUND' in codes(x))
bad=copy.deepcopy(review);bad['dimensions'][0]['score']=6;bad['weightedScore']=round(sum(d['score']*d['weight'] for d in bad['dimensions'])/sum(d['weight'] for d in bad['dimensions']),3);x=sem(bad,arts);check('critical floor','SEMANTIC_CRITICAL_FLOOR' in codes(x))
_,_,_,_,_,_,_,_,_,claims=parse_text('I inspected the animation. The voiceover sounds clear. Children understood the lesson. Rights are cleared.');cats={x['category'] for x in claims};check('expanded claim scanning',{'INSPECTION','AUDIO','AUDIENCE','RIGHTS'}<=cats)
out={'release':'7.4.0','syntheticOnly':True,'liveEvidenceProduced':False,'results':results,'pass':all(x['pass'] for x in results)};(RESULTS/'V7_4_FINALIZATION_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
