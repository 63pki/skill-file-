# V7.1 Cross-Model Reliability Tests

- CMR-01: production intent and tool roles declared before G1.
- CMR-02: default RUN-TO-BLOCKER keeps six internal gates but no six-response ceremony.
- CMR-03: explicit GUIDED preserves one-gate NEXT behavior.
- CMR-04: evidence-typed verdict rejects bare PASS and false completion.
- CMR-05: anatomy/personality/world/shot/tool drift triggers revision and invalidation.
- CMR-06: unmeasured voice allows motion planning only.
- CMR-07: Nano and Veo selected yields complete target-specific libraries even without execution.
- CMR-08: editor recipe cannot replace a Veo prompt.
- CMR-09: technical pixels/percentages/frames are classified.
- CMR-10: generation-native 2D lane does not force manual cutout.
- CMR-11: single-view puppet exception is explicit and bounded.
- CMR-12: final package includes used evidence media or caps maturity.
- CMR-13: archive integrity is recorded before final rebuild and revalidated.
- CMR-14: static test result does not claim live behavioral proof.
- CMR-15: all V6.10, V6.11, V7.0, and V7.0.1 files/capabilities remain.
