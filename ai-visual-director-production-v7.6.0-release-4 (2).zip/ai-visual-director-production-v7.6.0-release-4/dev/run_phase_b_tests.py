#!/usr/bin/env python3
import os
from pathlib import Path
import copy,hashlib,json,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'validators'))
RESULTS=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));RESULTS.mkdir(parents=True,exist_ok=True)
from extract_actual_output import extract
from validate_project import result
def codes(r): return {x['code'] for x in r['errors']}
def contract(): return {'schemaVersion':'7.4.0-phase-d','projectId':'B','deliveryMode':'SINGLE_PASS_BLUEPRINT','productionIntent':'BLUEPRINT','mode':'C_MOTION_GRAPHICS','assuranceProfile':'PORTABLE_ASSURANCE','tools':{'stillGeneration':'UNASSIGNED','videoGeneration':'UNASSIGNED','postSurfaces':[]},'story':{'isNarrative':False,'autonomousOrImpossibleBehavior':False},'locks':{'characters':[],'world':{},'shotCount':0},'artifactQueue':[{'artifactId':'STYLE_BIBLE','artifactType':'STYLE_BIBLE','gate':'DESIGN','sourceAliases':['Style Bible'],'minimumChars':150,'required':True,'requiredSections':['visual family','shape language','line','palette','composition','motion','signature','exclusions']}],'evidenceCeiling':'PLAN-PASS','runtimeLoad':{'required':False},'extractionPolicy':{'projectIndexRequiredForPackages':True,'recoveryMode':False}}
def good_body(): return '''## Visual family\nOriginal soft geometric system.\n## Shape language\nRounded subject forms and angular contrast.\n## Line\nConsistent navy outline.\n## Palette\nBlue, gold, cream identifiers.\n## Composition\nOne focal hierarchy and negative space.\n## Motion\nAnticipation, action, reaction, hold.\n## Signature\nProject-specific shadow blanket motif.\n## Exclusions\nNo realism, clutter, or borrowed studios.'''
def validate_text(c,text):
 with tempfile.TemporaryDirectory() as td:
  p=Path(td)/'x.md'; p.write_text(text); o=extract(c,p); return o,result(c,o)
results=[]; c=contract(); html='<!-- AVD:STATUS maturity=PLAN-PASS media=NOT_GENERATED -->\n<!-- AVD:ARTIFACT id=STYLE_BIBLE -->\n'+good_body()+'\n<!-- /AVD:ARTIFACT -->\n'; o,r=validate_text(c,html); results.append({'case':'schema_positive','pass':r['pass']})
o,r=validate_text(c,html.replace('## Signature','## Memory Device')); results.append({'case':'missing_required_section','pass':'ARTIFACT_REQUIRED_SECTION' in codes(r)})
filler='Repeated generic production sentence with acceptance and verification. '*12; o,r=validate_text(c,'<!-- AVD:ARTIFACT id=STYLE_BIBLE -->\n'+filler+'\n<!-- /AVD:ARTIFACT -->'); results.append({'case':'repeated_filler','pass':'GENERIC_REPEATED_FILLER' in codes(r)})
fenced='```avd-artifact\n'+json.dumps({'artifactId':'STYLE_BIBLE','body':good_body()})+'\n```\n'; o,r=validate_text(c,fenced); results.append({'case':'fenced_artifact','pass':r['pass'] and 'STYLE_BIBLE' in o['artifactsPresent']})
claim=html+'\nThe final video has been successfully inspected and approved.\n'; o,r=validate_text(c,claim); results.append({'case':'unsupported_claim','pass':'UNSUPPORTED_MEDIA_CLAIM' in codes(r)})
plan=html+'\nNext, generate and inspect the video after approval.\n'; o,r=validate_text(c,plan); results.append({'case':'planning_language_safe','pass':'UNSUPPORTED_MEDIA_CLAIM' not in codes(r)})
dup=html+'\n<!-- AVD:ARTIFACT id=STYLE_BIBLE -->\nDifferent conflicting body with palette and shape language.\n<!-- /AVD:ARTIFACT -->'; o,r=validate_text(c,dup); results.append({'case':'duplicate_conflict','pass':{'DUPLICATE_ARTIFACT_ID','ARTIFACT_SOURCE_CONFLICT'}<=codes(r)})
g=copy.deepcopy(c); g['deliveryMode']='GUIDED_PRODUCTION'; g['currentGate']='DIRECTION'; g['artifactQueue'][0]['artifactId']='CUSTOM_SHOT_MAP'; g['artifactQueue'][0]['gate']='ANIMATIC'; g['artifactQueue'][0]['requiredSections']=[]; gt=html.replace('STYLE_BIBLE','CUSTOM_SHOT_MAP'); o,r=validate_text(g,gt); results.append({'case':'gate_derived_scope','pass':'GUIDED_SCOPE_LEAK' in codes(r)})
# Evidence HTML extraction.
evc=copy.deepcopy(c); evt=html+'\n<!-- AVD:EVIDENCE type=visual assetId=CHAR_1 version=v01 path=asset.png sha256=abc inspectionDate=2026-07-19 inspectionMethod=vision verdict=ASSET-PASS -->\n'; o,r=validate_text(evc,evt); results.append({'case':'html_evidence_extract','pass':len(o['evidence']['visual'])==1 and o['evidence']['visual'][0]['assetId']=='CHAR_1'})
# Indexed package + evidence sidecar + no unrelated README discovery.
with tempfile.TemporaryDirectory() as td:
 root=Path(td); (root/'deliverables').mkdir(); (root/'evidence').mkdir(); artp=root/'deliverables/STYLE_BIBLE.md'; artp.write_text(good_body()); media=root/'evidence/test.bin'; media.write_bytes(b'evidence'); h=hashlib.sha256(media.read_bytes()).hexdigest(); idx={'artifactRoot':'deliverables','artifacts':[{'artifactId':'STYLE_BIBLE','artifactType':'STYLE_BIBLE','gate':'DESIGN','sourcePath':'deliverables/STYLE_BIBLE.md','sourceSha256':hashlib.sha256(artp.read_bytes()).hexdigest()}],'evidenceRecordPath':'evidence/EVIDENCE_RECORD.json'}; (root/'PROJECT_INDEX.json').write_text(json.dumps(idx)); rec={'records':[{'type':'visual','assetId':'A','version':'v1','path':'evidence/test.bin','sha256':h,'inspectionDate':'2026-07-19','inspectionMethod':'vision','verdict':'ASSET-PASS'}]}; (root/'evidence/EVIDENCE_RECORD.json').write_text(json.dumps(rec)); (root/'README.md').write_text('## Style Bible\nWRONG HISTORICAL CONTENT'); o=extract(c,root); r=result(c,o,root); results.append({'case':'indexed_package_sidecar','pass':not o['extractionIssues'] and len(o['evidence']['visual'])==1 and o['artifacts'][0]['sourcePath']=='deliverables/STYLE_BIBLE.md'})
# Missing index blocks package.
with tempfile.TemporaryDirectory() as td:
 root=Path(td); (root/'README.md').write_text(html); o=extract(c,root); r=result(c,o,root); results.append({'case':'project_index_required','pass':'PROJECT_INDEX_REQUIRED' in codes(r)})
out={'release':'7.4.0-phase-d','scope':'artifact schemas, anti-filler, gate ownership, indexed/multi-format extraction, evidence and claim checks','results':results,'pass':all(x['pass'] for x in results)}; (RESULTS/'V7_4_PHASE_B_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2)); raise SystemExit(0 if out['pass'] else 1)
