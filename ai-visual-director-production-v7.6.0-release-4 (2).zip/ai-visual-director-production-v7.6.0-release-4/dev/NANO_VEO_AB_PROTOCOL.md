# Nano Banana and Veo A/B Protocol

Hold model ID, surface, references, settings, prompt purpose, and evaluation rubric constant. Compare V7.1 versus V7.3 prompts. Nano: identity, reference-role fidelity, composition, text/localization, edit preservation, anatomy/style drift. Veo: action, continuity, camera, endpoint, audio/dialogue, unwanted additions, timestamp compliance. Store inputs, outputs, hashes, inspections, and limitations. Do not claim improvement without inspected generations.
