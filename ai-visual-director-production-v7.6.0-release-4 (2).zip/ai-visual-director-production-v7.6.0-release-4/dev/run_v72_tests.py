#!/usr/bin/env python3
import os
from pathlib import Path
import json,subprocess,sys,re
root=Path(__file__).resolve().parents[1]; errors=[]; results=[]
RESULTS=Path(os.environ.get('AVD_RESULTS_DIR',str(root/'dev/results')));RESULTS.mkdir(parents=True,exist_ok=True)
validator=root/'validators/history/validate_project_v72.py'
for name in ['chat1','chat2','chat3']:
 c=root/f'tests/fixtures/{name}_contract.json'; o=root/f'tests/fixtures/{name}_output.json'; e=json.loads((root/f'tests/fixtures/{name}_expected.json').read_text())
 p=subprocess.run([sys.executable,str(validator),str(c),str(o)],capture_output=True,text=True)
 try: data=json.loads(p.stdout)
 except Exception: errors.append(f'{name}: invalid historical validator output'); continue
 codes={x['code'] for x in data['errors']}; missing=set(e['expectedErrorCodes'])-codes
 if missing: errors.append(f'{name}: missing expected {sorted(missing)}')
 if data['pass']: errors.append(f'{name}: defective historical fixture passed')
 results.append({'case':name,'pass':not missing and not data['pass'],'errorCodes':sorted(codes)})
rt=(root/'rules/RUNTIME.md').read_text(); sk=(root/'SKILL.md').read_text(); regs=(root/'dev/REGRESSION_TESTS.md').read_text()
assertions={'currentVersion':'version: 7.6.0' in sk,'fiveBundles':len(re.findall(r'^# Bundle [1-5] —',rt,re.M))==5,'historicalValidator':validator.is_file(),'nanoVeo':all((root/x).exists() for x in ['adapters/generation/NANO_BANANA.md','adapters/generation/VEO_3_1.md']),'detailed':len(list((root/'rules/detailed').rglob('*.md')))>=52,'regressionsPreserved':all(f'R{i} |' in regs for i in range(95,140))}
for k,v in assertions.items():
 if not v: errors.append('assertion:'+k)
out={'release':'7.6.0','scope':'preserved V7.2 negative fixtures using archived V7.2 validator','behavioralProof':False,'fixtureResults':results,'assertions':assertions,'pass':not errors,'errors':errors}
(RESULTS/'V7_2_HISTORICAL_FIXTURE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2)); raise SystemExit(0 if not errors else 1)
