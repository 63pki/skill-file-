#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'));sys.path.insert(0,str(ROOT/'bootstrap'))
from validate_contract_schema import validate_project_contract,validate_routing_contract
from validate_delivery_package import validate_package
from validate_project import validate
from extract_actual_output import extract
from validate_instruction_compliance import validate as validate_receipt,STEPS
from runtime_selection import select_rules
rows=[]
def check(n,v,d=''):rows.append({'case':n,'pass':bool(v),'detail':d})
def codes(x):return {i.get('code') for i in x if isinstance(i,dict)}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
c=json.loads((ROOT/'templates/PROJECT_CONTRACT_PORTABLE.json').read_text());c['runtimeLoad']={'required':False,'profile':'SUBSTANTIAL'};r=json.loads((ROOT/'templates/ROUTING_CONTRACT.json').read_text());check('final-project-schema',not validate_project_contract(c));check('final-routing-schema',not validate_routing_contract(r))
# All Phase C+ package gates remain active under final schema.
check('final-package-gate','PACKAGE_DIRECTORY_REQUIRED' in codes(validate_package(c,{},None)))
# All Phase B+ status gates remain active.
o={'artifacts':[],'artifactsPresent':[],'shots':[],'lockUses':[],'story':{},'toolUse':{},'evidence':{k:[] for k in ['visual','motion','audio','humanReview','technical']},'maturity':'PLAN-PASS','statusMetadata':{'delivery':'FINISHED_PRODUCTION','maturity':'PLAN-PASS','media':'NOT_GENERATED'},'unsupportedClaimSignals':[],'extractionIssues':[],'duplicateArtifactIds':[],'conflictingArtifactIds':[],'packageFiles':[]};e,_=validate(c,o);check('final-status-gate','STATUS_DELIVERY_DRIFT' in codes(e))
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'x.md';p.write_text('plain output');x=extract(c,p);check('final-maturity-fail-closed',x['maturity']=='UNDECLARED')
# Final compliance receipt binds current runtime.
m=json.loads((ROOT/'bootstrap/runtime_load_manifest.json').read_text());paths=select_rules(c,m)[0];receipt={'schemaVersion':'7.6.0','release':'7.6.0','projectId':c['projectId'],'model':{'provider':'TEST','name':'TEST','version':'1'},'userWorkflowAuthorized':True,'agentIdentityChanged':False,'systemOverrideAttempted':False,'untrustedInstructionsExecuted':False,'runtimeManifestSha256':sha(ROOT/'bootstrap/runtime_load_manifest.json'),'selectedFiles':[{'path':p,'sha256':sha(ROOT/p),'status':'LOADED'} for p in paths],'orderedSteps':[{'id':x,'status':'COMPLETE','artifact':x+'.json'} for x in STEPS],'cognitiveAttentionProven':False};check('final-receipt',validate_receipt(receipt,c)['pass'])
with tempfile.TemporaryDirectory() as td:
 d=Path(td);cp=d/'c.json';cp.write_text(json.dumps(c));p=subprocess.run([sys.executable,str(ROOT/'validators/compile_and_validate.py'),str(cp),str(d/'missing'),'--outdir',str(d/'out')],capture_output=True,text=True);data=json.loads(p.stdout);check('final-receipt-required','INSTRUCTION_RECEIPT_REQUIRED' in codes(data['errors']))
release=json.loads((ROOT/'release/RELEASE.json').read_text());check('final-release-identity',release['version']=='7.6.0' and release['regressionCatalog']['lastId']==570);check('final-runtime-identity',m['packageVersion']=='7.6.0')
base=json.loads((ROOT/'release/V7_4_2_PHASE_D_BASELINE_HASHES.json').read_text());current={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()};check('phase-d-paths-preserved',set(base['files'])<=current,f"missing={len(set(base['files'])-current)}");check('immutable-guides',all(sha(ROOT/p)==base['files'][p]['sha256'] for p in base['immutablePaths']));check('manuals-52',len(list((ROOT/'rules/detailed').rglob('*.md')))==52)
out={'release':'7.6.0','scope':'final cumulative inheritance and preservation','results':rows,'pass':all(x['pass'] for x in rows),'liveCrossModelProof':False};dest=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));dest.mkdir(parents=True,exist_ok=True);(dest/'V7_4_2_FINAL_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
