#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,shutil,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'))
from validate_release_consistency import validate
rows=[]
def check(name,value,detail=''):rows.append({'case':name,'pass':bool(value),'detail':detail})
def codes(e):return {x.get('code') for x in e}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
check('canonical-release-consistency',not validate(ROOT),json.dumps(validate(ROOT)))
with tempfile.TemporaryDirectory() as td:
 r=Path(td)/'release';shutil.copytree(ROOT,r)
 p=r/'dev/BUILD_VALIDATION.md';p.write_text(p.read_text().replace('R1–R570','R1–R340'));check('stale-regression-rejected','ACTIVE_REGRESSION_RANGE_DRIFT' in codes(validate(r)))
with tempfile.TemporaryDirectory() as td:
 r=Path(td)/'release';shutil.copytree(ROOT,r)
 p=r/'SKILL.md';p.write_text(p.read_text().replace('version: 7.6.0','version: 7.4.2'));check('version-drift-rejected','ACTIVE_VERSION_DRIFT' in codes(validate(r)))
with tempfile.TemporaryDirectory() as td:
 r=Path(td)/'release';shutil.copytree(ROOT,r);h=r/'rules/history/V0_0_1_TEST.md';h.write_text('version: 7.4.2\nR1–R340\nFinal Cumulative Release\n');check('history-excluded',not validate(r),json.dumps(validate(r)))
release=json.loads((ROOT/'release/RELEASE.json').read_text());manifest=json.loads((ROOT/'bootstrap/runtime_load_manifest.json').read_text());check('runtime-release-identity',release['version']==manifest['packageVersion']==manifest['schemaVersion']=='7.6.0')
check('separate-maturity',release['engineeringMaturity']=='STRUCTURALLY_VALIDATED' and release['operationalMaturity']=='CONTROLLED_BETA')
check('live-evidence-honest',release['liveEvidence']=={'liveCrossModelReplay':'NOT_RUN','nanoVeoABGeneration':'NOT_RUN','completeProductionPilot':'NOT_RUN','beginnerOperatorPilot':'NOT_RUN','audienceComprehensionReview':'NOT_RUN','externalEvidenceClaimed':False})
base=json.loads((ROOT/'release/V7_4_2_BASELINE_HASHES.json').read_text());current={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()};check('v742-paths-preserved',set(base['files'])<=current,f"missing={len(set(base['files'])-current)}")
check('protected-guide-hashes',all(sha(ROOT/p)==base['files'][p]['sha256'] for p in base['immutablePaths']))
ids=[int(x.split('|')[1].strip()[1:]) for x in (ROOT/'dev/REGRESSION_TESTS.md').read_text().splitlines() if x.startswith('| R')];check('regressions-r1-r470',len(ids)==570 and sorted(ids)==list(range(1,571)))
out={'release':'7.6.0','scope':'Release 1 immediate correctness and maturity hotfix','results':rows,'pass':all(x['pass'] for x in rows),'liveCrossModelProof':False,'liveNanoVeoProof':False,'productionPilotProof':False};dest=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));dest.mkdir(parents=True,exist_ok=True);(dest/'V7_4_3_RELEASE_1_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
