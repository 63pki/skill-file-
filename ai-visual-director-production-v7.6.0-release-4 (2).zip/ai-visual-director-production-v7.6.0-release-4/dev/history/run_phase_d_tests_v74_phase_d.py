#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'validators'))
from validate_external_evidence import validate

def codes(r):return {x['code'] for x in r['errors']}
def trial(root,tid,track,provider='ProviderA',model='ModelA',**kw):
 p=root/f'{tid}.txt';p.write_text(f'synthetic validator fixture {tid}')
 d={'trialId':tid,'track':track,'provider':provider,'model':model,'modelVersion':'test-version','promptSha256':'a'*64,'responsePath':p.name,'responseSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'executedAt':'2026-07-19T08:00:00Z','operatorId':'OP_1','evidenceClass':'LIVE_EXTERNAL'};d.update(kw);return d
def rating(tid,rid):return {'trialId':tid,'raterId':rid,'independent':True,'blind':True,'variantSeen':'','reviewedAt':'2026-07-19T09:00:00Z','verdict':'PASS','evidenceExcerpt':'Synthetic fixture excerpt','uncertainty':'Test fixture only'}
results=[]
r=validate({'status':'NOT_RUN','trials':[],'ratings':[],'claims':[]});results.append({'case':'honest_not_run','pass':r['pass'] and all(x=='NOT_PROVEN' for x in r['trackStatus'].values())})
r=validate({'status':'COMPLETE','trials':[],'ratings':[]});results.append({'case':'complete_requires_live','pass':'COMPLETE_WITHOUT_LIVE_EVIDENCE' in codes(r)})
with tempfile.TemporaryDirectory() as td:
 root=Path(td); t=trial(root,'T1','CROSS_MODEL_REPLAY');del t['modelVersion'];r=validate({'status':'IN_PROGRESS','trials':[t],'ratings':[]},root);results.append({'case':'trial_provenance_fields','pass':'EXTERNAL_TRIAL_FIELD' in codes(r)})
with tempfile.TemporaryDirectory() as td:
 root=Path(td);t=trial(root,'T1','CROSS_MODEL_REPLAY');t['responseSha256']='b'*64;r=validate({'status':'IN_PROGRESS','trials':[t],'ratings':[]},root);results.append({'case':'response_hash','pass':'EXTERNAL_HASH_MISMATCH' in codes(r)})
with tempfile.TemporaryDirectory() as td:
 root=Path(td);t=trial(root,'T1','CROSS_MODEL_REPLAY');r=validate({'status':'IN_PROGRESS','trials':[t,t],'ratings':[]},root);results.append({'case':'duplicate_trial','pass':'DUPLICATE_TRIAL_ID' in codes(r)})
with tempfile.TemporaryDirectory() as td:
 root=Path(td);t=trial(root,'T1','CROSS_MODEL_REPLAY');rr=rating('T1','R1');rr['variantSeen']='CANDIDATE';r=validate({'status':'IN_PROGRESS','trials':[t],'ratings':[rr]},root);results.append({'case':'blinding_leak','pass':'BLINDING_LEAK' in codes(r)})
with tempfile.TemporaryDirectory() as td:
 root=Path(td);t=trial(root,'T1','CROSS_MODEL_REPLAY');rr=rating('T1','OP_1');r=validate({'status':'IN_PROGRESS','trials':[t],'ratings':[rr]},root);results.append({'case':'rater_independence','pass':'RATER_NOT_INDEPENDENT' in codes(r)})
with tempfile.TemporaryDirectory() as td:
 root=Path(td);t=trial(root,'T1','CROSS_MODEL_REPLAY');t['evidenceClass']='SIMULATED_TEST';r=validate({'status':'IN_PROGRESS','trials':[t],'ratings':[]},root);results.append({'case':'simulation_never_proves','pass':r['liveTrialCount']==0 and r['trackStatus']['liveCrossModelReplay']=='NOT_PROVEN'})
with tempfile.TemporaryDirectory() as td:
 root=Path(td);tr=[];rs=[]
 # Synthetic unit fixture exercises the full threshold algorithm; it is not retained as live evidence.
 tr += [trial(root,'C1','CROSS_MODEL_REPLAY','ProviderA','Model1'),trial(root,'C2','CROSS_MODEL_REPLAY','ProviderA','Model2'),trial(root,'C3','CROSS_MODEL_REPLAY','ProviderB','Model3')]
 tr += [trial(root,'A1','NANO_VEO_AB','Google','NanoBanana',pairId='P1',variant='BASELINE'),trial(root,'A2','NANO_VEO_AB','Google','NanoBanana',pairId='P1',variant='CANDIDATE')]
 stages=['BRIEF','DESIGN','ANIMATIC','ASSET','MOTION','DELIVERY']
 tr += [trial(root,'P'+str(i+1),'PRODUCTION_PILOT','Google','Veo3.1',pilotStage=st,mediaGenerated=(st=='DELIVERY')) for i,st in enumerate(stages)]
 for t in tr:
  if t['track']=='NANO_VEO_AB' or (t['track']=='PRODUCTION_PILOT' and t.get('pilotStage')=='DELIVERY'):rs += [rating(t['trialId'],'R1'),rating(t['trialId'],'R2')]
 camp={'status':'COMPLETE','trials':tr,'ratings':rs,'claims':[{'trackStatusKey':k,'verdict':'PASS'} for k in ['liveCrossModelReplay','nanoVeoABGeneration','completeProductionPilot']]};r=validate(camp,root);results.append({'case':'threshold_algorithm_fixture','pass':r['pass'] and all(x=='PASS' for x in r['trackStatus'].values())})
 bad=copy.deepcopy(camp);bad['trials']=[x for x in tr if x.get('pilotStage')!='MOTION'];r=validate(bad,root);results.append({'case':'complete_campaign_thresholds','pass':'EXTERNAL_CAMPAIGN_INCOMPLETE' in codes(r)})
 bad={'status':'IN_PROGRESS','trials':[],'ratings':[],'claims':[{'trackStatusKey':'liveCrossModelReplay','verdict':'PASS'}]};r=validate(bad);results.append({'case':'unsupported_external_claim','pass':'UNSUPPORTED_EXTERNAL_CLAIM' in codes(r)})
out={'release':'7.4.0-phase-d','scope':'external provenance, hashes, diversity, blinding, independence, A-B pairing, pilot gates, conservative claims','syntheticValidatorFixturesOnly':True,'liveEvidenceProduced':False,'liveCrossModelReplay':'NOT_RUN','nanoVeoABGeneration':'NOT_RUN','completeProductionPilot':'NOT_RUN','results':results,'pass':all(x['pass'] for x in results)};(ROOT/'dev/results/V7_4_PHASE_D_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
