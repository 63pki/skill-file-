#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
BOOT=ROOT/'bootstrap/bootstrap_runtime.py'; COMP=ROOT/'validators/compile_and_validate.py'; TEMPLATE=ROOT/'templates/PROJECT_CONTRACT.json'
def run(cmd): return subprocess.run([sys.executable,*map(str,cmd)],capture_output=True,text=True)
def jload(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
results=[]
with tempfile.TemporaryDirectory() as td:
 td=Path(td); c=jload(TEMPLATE); c['projectId']='BOOT-TEST'; c['tools']['stillGeneration']='NANO_BANANA'; c['tools']['videoGeneration']='VEO_3_1'; cp=td/'contract.json'; cp.write_text(json.dumps(c,indent=2)+'\n'); session=td/'session'
 p=run([BOOT,cp,'--outdir',session]); receipt=jload(session/'RUNTIME_LOAD_RECEIPT.json'); paths=[x['path'] for x in receipt['selectedFiles']]
 expected=['SKILL.md','rules/CORE_CONTROLLER.md','rules/RUNTIME.md','rules/production/2D_ANIMATION.md','adapters/generation/NANO_BANANA.md','adapters/generation/VEO_3_1.md','adapters/capcut/README.md','adapters/generation/NANO_BANANA_VEO_PIPELINE.md']
 results.append({'case':'selection_and_hashes','pass':p.returncode==0 and paths==expected})
 marker=(session/'RUNTIME_MARKER.txt').read_text().strip(); wr={'rule':'Helpful shadows move toward nearby heat danger.','trigger':'dangerous heat','limit':'one nearby life','returnCondition':'durable shade exists','proofShot':'S07'}; dr={'originalProblem':'plant overheats','temporaryHelp':'shadow shades it','permanentChange':'leaf canopy remains','helperCanLeave':True,'recurrencePrevented':True,'visualProofShot':'S09'}
 body=('Project-specific style, shape, palette, composition, continuity, exclusions, references, acceptance checks, repair rules, and production limits. '*6)
 text=marker+'\n<!-- AVD:STATUS delivery=SINGLE_PASS_BLUEPRINT maturity=PLAN-PASS media=NOT_GENERATED -->\n<!-- AVD:TOOL role=stillGeneration owner=NANO_BANANA -->\n<!-- AVD:TOOL role=videoGeneration owner=VEO_3_1 -->\n'+f"<!-- AVD:STRUCT kind=worldRule value='{json.dumps(wr,separators=(',',':'))}' -->\n"+f"<!-- AVD:STRUCT kind=durableResolution value='{json.dumps(dr,separators=(',',':'))}' -->\n"+'<!-- AVD:ARTIFACT id=STYLE_BIBLE -->\n## Style Bible\n'+body+'\n<!-- /AVD:ARTIFACT -->\n'; response=td/'response.md'; response.write_text(text)
 p=run([COMP,cp,response,'--runtime-receipt',session/'RUNTIME_LOAD_RECEIPT.json','--outdir',td/'valid']); data=json.loads(p.stdout); results.append({'case':'valid_challenge_response','pass':p.returncode==0 and data['pass']})
 p=run([COMP,cp,response,'--outdir',td/'missing']); data=json.loads(p.stdout); results.append({'case':'missing_receipt_blocks','pass':p.returncode!=0 and any(x['code']=='RUNTIME_RECEIPT_MISSING' for x in data['errors'])})
 bad=td/'wrong.md'; bad.write_text(text.replace(receipt['challenge'],'0'*48,1)); p=run([COMP,cp,bad,'--runtime-receipt',session/'RUNTIME_LOAD_RECEIPT.json','--outdir',td/'wrong']); data=json.loads(p.stdout); results.append({'case':'wrong_challenge_blocks','pass':p.returncode!=0 and any(x['code']=='RUNTIME_CHALLENGE_MISMATCH' for x in data['errors'])})
 dup=td/'dup.md'; dup.write_text(marker+'\n'+text); p=run([COMP,cp,dup,'--runtime-receipt',session/'RUNTIME_LOAD_RECEIPT.json','--outdir',td/'dupout']); data=json.loads(p.stdout); results.append({'case':'duplicate_marker_blocks','pass':p.returncode!=0 and any(x['code']=='RUNTIME_MARKER_COUNT' for x in data['errors'])})
 # Edited receipt with stale detached checksum.
 tr=td/'tampered.json'; obj=copy.deepcopy(receipt); obj['status']='FORGED'; tr.write_text(json.dumps(obj,indent=2)+'\n'); Path(str(tr)+'.sha256').write_text(sha(session/'RUNTIME_LOAD_RECEIPT.json')+'  tampered.json\n'); p=run([COMP,cp,response,'--runtime-receipt',tr,'--outdir',td/'tampered']); data=json.loads(p.stdout); results.append({'case':'tampered_receipt_blocks','pass':p.returncode!=0 and any(x['code']=='RUNTIME_RECEIPT_CHECKSUM_MISMATCH' for x in data['errors'])})
 # Unknown tool cannot silently proceed.
 uc=copy.deepcopy(c); uc['tools']['stillGeneration']='UNKNOWN_X'; up=td/'unknown.json'; up.write_text(json.dumps(uc,indent=2)+'\n'); p=run([BOOT,up,'--outdir',td/'unknown']); results.append({'case':'unmapped_tool_blocks','pass':p.returncode!=0 and 'UNMAPPED_TOOL_REQUIRES_CUSTOM_RULE' in p.stdout})
 # Contract mismatch blocks receipt reuse.
 c2=copy.deepcopy(c); c2['projectId']='OTHER'; c2p=td/'other.json'; c2p.write_text(json.dumps(c2,indent=2)+'\n'); p=run([COMP,c2p,response,'--runtime-receipt',session/'RUNTIME_LOAD_RECEIPT.json','--outdir',td/'other']); data=json.loads(p.stdout); results.append({'case':'receipt_contract_binding','pass':p.returncode!=0 and any(x['code']=='RUNTIME_CONTRACT_HASH_MISMATCH' for x in data['errors'])})
out={'release':'7.3.1','scope':'cryptographic bootstrap, trigger selection, receipt integrity, and challenge-response','proofBoundary':'Context availability and byte integrity; not private cognitive attention.','results':results,'pass':all(x['pass'] for x in results)}
(ROOT/'dev/results/V7_3_1_BOOTSTRAP_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2)); raise SystemExit(0 if out['pass'] else 1)
