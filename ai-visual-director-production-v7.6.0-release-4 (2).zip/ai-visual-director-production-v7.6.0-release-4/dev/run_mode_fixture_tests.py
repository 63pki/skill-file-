#!/usr/bin/env python3
import os
from pathlib import Path
import copy,json,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'validators'))
RESULTS=Path(os.environ.get('AVD_RESULTS_DIR',str(ROOT/'dev/results')));RESULTS.mkdir(parents=True,exist_ok=True)
from extract_actual_output import extract
from validate_project import result

def contract(pid,mode,delivery='SINGLE_PASS_BLUEPRINT'):
 return {'schemaVersion':'7.3.0','projectId':pid,'deliveryMode':delivery,'productionIntent':'BLUEPRINT','mode':mode,'depth':'FAST','currentGate':'DIRECTION','durationSeconds':0,'tools':{'stillGeneration':'UNASSIGNED','videoGeneration':'UNASSIGNED','postSurfaces':[]},'story':{'isNarrative':False,'autonomousOrImpossibleBehavior':False},'locks':{'characters':[],'world':{},'shotCount':0},'artifactQueue':[{'artifactId':'PRIMARY','sourceAliases':['Primary Artifact'],'minimumChars':160,'required':True}],'evidenceCeiling':'PLAN-PASS','guideAlignment':{'snapshotDate':'2026-07-19','maxAgeDays':3650}}
def md(mode): return f'''<!-- AVD:STATUS delivery=SINGLE_PASS_BLUEPRINT maturity=PLAN-PASS media=NOT_GENERATED -->
<!-- AVD:TOOL role=stillGeneration owner=UNASSIGNED -->
<!-- AVD:TOOL role=videoGeneration owner=UNASSIGNED -->
<!-- AVD:ARTIFACT id=PRIMARY -->
## Primary Artifact
Mode {mode} project-specific hierarchy, subject, composition, system, continuity, acceptance, fallback, evidence boundary, and repair instructions. This body is deliberately complete enough for extraction and avoids unsupported media claims.
<!-- /AVD:ARTIFACT -->
'''
cases=[('product_quickshot','A_PHOTOREAL'),('2d_animation','B_ANIMATION'),('motion_graphics','C_MOTION_GRAPHICS'),('hybrid_composite','D_HYBRID'),('faceless_documentary','D_HYBRID'),('localization_package','C_MOTION_GRAPHICS')]
results=[]
for name,mode in cases:
 with tempfile.TemporaryDirectory() as td:
  p=Path(td); (p/'deliverable.md').write_text(md(mode)); o=extract(contract(name,mode),p); r=result(contract(name,mode),o,p); results.append({'case':name,'mode':mode,'pass':r['pass'],'codes':[x['code'] for x in r['errors']]})
# Malformed marker safely fails without crash.
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'bad.md'; p.write_text('<!-- AVD:ARTIFACT id=PRIMARY -->\nTODO')
 try:
  o=extract(contract('bad','A_PHOTOREAL'),p); r=result(contract('bad','A_PHOTOREAL'),o); ok=(not r['pass'] and any(x['code']=='MISSING_ARTIFACT' for x in r['errors']))
 except Exception: ok=False
 results.append({'case':'malformed_marker','mode':'A_PHOTOREAL','pass':ok})
out={'release':'7.4.0-phase-d','scope':'positive non-Milo mode/package fixtures and malformed input','results':results,'pass':all(x['pass'] for x in results)}
(RESULTS/'V7_3_MODE_FIXTURE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2)); raise SystemExit(0 if out['pass'] else 1)
