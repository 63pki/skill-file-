#!/usr/bin/env python3
from pathlib import Path
import re

def norm(x):return re.sub(r'[^A-Z0-9]+','_',str(x).upper()).strip('_')
MODE_ALIASES={'A_PHOTOREAL':'A_PHOTOREAL_COMMERCIAL','A_COMMERCIAL':'A_PHOTOREAL_COMMERCIAL','D_HYBRID':'D_HYBRID_COMPOSITING'}
def select_rules(contract,manifest):
 profile=norm(contract.get('projectClass') or contract.get('runtimeLoad',{}).get('profile','SUBSTANTIAL'));profiles=manifest.get('profiles',{})
 if profile not in profiles:raise ValueError(f'UNKNOWN_RUNTIME_PROFILE:{profile}')
 selected=list(profiles[profile]);reasons={p:f'profile:{profile}' for p in selected};errors=[]
 mode=MODE_ALIASES.get(norm(contract.get('mode','')),norm(contract.get('mode','')));tools=contract.get('tools',{}) if isinstance(contract.get('tools',{}),dict) else {}
 audience=contract.get('audienceTriggers',[])
 if (not isinstance(audience,list) or not audience) and isinstance(contract.get('audience'),dict):
  a=contract['audience'];typ=norm(a.get('type',''));age=norm(a.get('ageRange',''));candidate=typ+'_'+age if typ and age else typ;audience=[candidate if candidate in manifest.get('audienceTriggers',{}) else typ] if typ else []
 if not isinstance(audience,list) or not audience:errors.append('AUDIENCE_TRIGGER_REQUIRED');audience=[]
 known_audience=manifest.get('audienceTriggers',{});audience_keys=[]
 for raw in audience:
  key=norm(raw);audience_keys.append(key);paths=known_audience.get(key)
  if paths is None:errors.append('UNKNOWN_AUDIENCE_TRIGGER:'+key);continue
  for path in paths:
   if path not in selected:selected.append(path)
   reasons[path]='audience:'+key
 known_modes=manifest.get('modeTriggers',{});mode_paths=known_modes.get(mode)
 if mode_paths is None:errors.append('UNKNOWN_MODE_TRIGGER:'+mode)
 else:
  for p in mode_paths:
   if p not in selected:selected.append(p)
   reasons[p]='mode:'+mode
 if mode=='B_ANIMATION':
  still=norm(tools.get('stillGeneration','UNASSIGNED'));video=norm(tools.get('videoGeneration','UNASSIGNED'))
  if still!='NANO_BANANA':errors.append('MODE_B_REQUIRES_NANO_BANANA:'+still)
  if video!='VEO_3_1':errors.append('MODE_B_REQUIRES_VEO_3_1:'+video)
  forbidden={norm(x) for x in (tools.get('postSurfaces',[]) or [])}&{'CANVA','CANVA_WEB','CANVA_MOBILE','CAPCUT','CAPCUT_DESKTOP','CAPCUT_MOBILE'}
  if forbidden:errors.append('EDITOR_GUIDE_REMOVED_AUDIO_ATTACHMENT_ONLY:'+','.join(sorted(forbidden)))
 triggers=contract.get('productionTriggers',[]) or []
 if not isinstance(triggers,list):errors.append('PRODUCTION_TRIGGERS_TYPE');triggers=[]
 known_production=manifest.get('productionTriggers',{});production_keys=[]
 for raw in triggers:
  key=norm(raw);production_keys.append(key);paths=known_production.get(key)
  if paths is None:errors.append('UNKNOWN_PRODUCTION_TRIGGER:'+key);continue
  for p in paths:
   if p not in selected:selected.append(p)
   reasons[p]='production:'+key
 if 'LOCALIZATION' in production_keys and 'MULTILINGUAL' not in audience_keys:errors.append('LOCALIZATION_REQUIRES_MULTILINGUAL_AUDIENCE')
 if 'ARCHITECTURAL_CONTINUITY' in production_keys and mode not in {'A_PHOTOREAL_COMMERCIAL','D_HYBRID_COMPOSITING'}:errors.append('ARCHITECTURAL_REQUIRES_MODE_A_OR_D')
 owners=[]
 for role in ['stillGeneration','videoGeneration']:
  owner=norm(tools.get(role,'UNASSIGNED'))
  if owner not in {'','UNASSIGNED','EXTERNAL_OR_UNASSIGNED','NONE'}:owners.append((role,owner))
 custom=contract.get('customRules') or contract.get('runtimeLoad',{}).get('customRules',[]) or [];custom_by_owner={norm(x.get('toolOwner')):x for x in custom if isinstance(x,dict) and x.get('toolOwner')};known=manifest.get('toolTriggers',{})
 for role,owner in owners:
  paths=known.get(owner)
  if paths:
   for p in paths:
    if p not in selected:selected.append(p)
    reasons[p]=f'{role}:{owner}'
  elif owner not in custom_by_owner:errors.append(f'UNMAPPED_TOOL_REQUIRES_CUSTOM_RULE:{role}:{owner}')
 for item in tools.get('postSurfaces',[]) or []:
  key=norm(item)
  for p in known.get(key,[]):
   if p not in selected:selected.append(p)
   reasons[p]=f'post:{key}'
 owner_set={x[1] for x in owners}
 for combo in manifest.get('combinationTriggers',[]):
  if set(combo.get('owners',[]))<=owner_set:
   for p in combo.get('files',[]):
    if p not in selected:selected.append(p)
    reasons[p]='combination:'+','.join(combo['owners'])
 return selected,reasons,errors,custom

def verify_custom_rules(custom,contract_dir):
 out=[];errors=[];import hashlib
 for x in custom:
  p=Path(x.get('path',''))
  if not p.is_absolute():p=(Path(contract_dir)/p).resolve()
  expected=str(x.get('sha256','')).lower()
  if not p.is_file():errors.append('CUSTOM_RULE_MISSING:'+str(p));continue
  actual=hashlib.sha256(p.read_bytes()).hexdigest()
  if not expected or actual!=expected:errors.append('CUSTOM_RULE_HASH_MISMATCH:'+str(p));continue
  out.append({'path':str(p),'sha256':actual,'toolOwner':x.get('toolOwner','CUSTOM')})
 return out,errors
