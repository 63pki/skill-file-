#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
profiles={'SUBSTANTIAL':['SKILL.md','rules/CORE_CONTROLLER.md','rules/RUNTIME.md'],'QUICK_SHOT':['SKILL.md','rules/CORE_CONTROLLER.md']}
base='rules/production/AUDIENCE_SUITABILITY.md'
audiences={
 'GENERAL':[base],
 'CHILDREN':[base,'rules/audience/CHILDREN_6_9.md'],
 'CHILDREN_6_9':[base,'rules/audience/CHILDREN_6_9.md'],
 'EXPERT':[base,'rules/audience/EXPERT_TECHNICAL.md'],
 'VULNERABLE':[base,'rules/audience/VULNERABLE_AUDIENCES.md'],
 'ACCESSIBILITY':[base,'rules/audience/ACCESSIBILITY.md'],
 'MULTILINGUAL':[base,'rules/audience/MULTILINGUAL.md'],
 'REGULATED':[base,'rules/audience/REGULATED_CLAIMS.md']}
modes={
 'A_PHOTOREAL_COMMERCIAL':['rules/production/MODE_A_PHOTOREAL_COMMERCIAL.md'],
 'B_ANIMATION':['rules/production/2D_ANIMATION.md','adapters/generation/NANO_BANANA.md','adapters/generation/VEO_3_1.md','adapters/generation/NANO_BANANA_VEO_PIPELINE.md','rules/production/AUDIO_ATTACHMENT.md'],
 'C_MOTION_GRAPHICS':['rules/production/MODE_C_MOTION_GRAPHICS.md'],
 'D_HYBRID_COMPOSITING':['rules/production/MODE_D_HYBRID_COMPOSITING.md']}
production={
 'FACTUAL_DOCUMENTARY':['rules/production/FACTUAL_DOCUMENTARY.md'],
 'LOCALIZATION':['rules/production/LOCALIZATION.md'],
 'ARCHITECTURAL_CONTINUITY':['rules/production/ARCHITECTURAL_CONTINUITY.md'],
 'UGC_ADVERTISING':['rules/production/UGC_ADVERTISING.md'],
 'CINEMATIC_SCENE':['rules/production/CINEMATIC_SCENE.md']}
tools={'NANO_BANANA':['adapters/generation/NANO_BANANA.md'],'VEO_3_1':['adapters/generation/VEO_3_1.md'],'AUDIO_ATTACHMENT_ONLY':['rules/production/AUDIO_ATTACHMENT.md']}
combos=[{'owners':['NANO_BANANA','VEO_3_1'],'files':['adapters/generation/NANO_BANANA_VEO_PIPELINE.md']}]
paths=[]
for seq in list(profiles.values())+list(audiences.values())+list(modes.values())+list(production.values())+list(tools.values())+[x['files'] for x in combos]:
 for p in seq:
  if p not in paths:paths.append(p)
files={}
for rel in paths:
 p=ROOT/rel
 if not p.is_file():raise SystemExit('Missing manifest source: '+rel)
 files[rel]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
out={'schemaVersion':'7.6.0','packageVersion':'7.6.0','hashAlgorithm':'SHA-256','proofBoundary':'Integrity and selection; challenge-response adds context availability, not cognitive-attention proof.','profiles':profiles,'audienceTriggers':audiences,'modeTriggers':modes,'productionTriggers':production,'toolTriggers':tools,'combinationTriggers':combos,'customToolPolicy':'Unmapped generation owners require runtimeLoad.customRules with an exact SHA-256.','files':files}
(ROOT/'bootstrap/runtime_load_manifest.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'manifestFiles':len(files),'profiles':list(profiles),'modeTriggers':list(modes),'productionTriggers':list(production),'audienceTriggers':list(audiences)},indent=2))
