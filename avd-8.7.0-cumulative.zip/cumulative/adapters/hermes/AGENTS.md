# Hermes Enforcement Adapter

**Entry point (v8.7.0 / D5).** This adapter previously documented **no invocation at all**, so a
host had to guess one. Recorded from a measured attempt (AI wiring battery, slot C): the
conventional `bin\hermes.exe` path **does not exist** in the shipped package. On Windows the
working entry point is the **`hermes.cmd`** shim (e.g. `hermes.cmd -p <profile>`); on
POSIX hosts use the corresponding launcher. The adapter is a **prompt-enforcement contract**,
not a generator: it never produces media, and it must not be mistaken for a backend.

Create the minimal Routing Contract before loading triggered rules. If execution, context injection, and receipt retention are available, use Verified Runtime: preload, inject context, compile the full Project Contract, finalize binding, and validate with the final receipt. If these capabilities are unavailable, use Portable Assurance, expose the unverified status, and cap at PLAN-PASS. Never claim cryptographic load, deterministic PASS, generated/inspected media, or RELEASE-PASS in Portable Assurance. Preserve complete Nano Banana Pro/Gemini Omni Flash adapters when selected and never substitute platform-neutral design surface/platform-neutral editing surface for generation.

## Phase C host behavior

Render compact status first. Keep forensic receipts in generated files. Show the highest-priority repair as the next action. Semantic quality review must be labeled model-reviewed or human-reviewed and may not invent unavailable media scores.

## Phase D evidence import

Do not infer live proof from chat text. Import external files and provenance explicitly. Keep all three external track statuses `NOT_PROVEN` when minimums are not met.
