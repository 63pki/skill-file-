#!/usr/bin/env python3
"""M3 — trust the artifact.

A PASS must be a PRODUCED artifact, never the absence of red. This module:

  1. runs the validator battery and records, per validator: what it examined, how many targets it
     expected, how many it actually examined, and how many it skipped (with reasons);
  2. reconciles completeness - expected == examined + skipped, and a skip is never silent;
  3. runs CROSS-INSTRUMENT CONTRADICTION MONITORS - two cheap independent counts must agree,
     and disagreement is red even when both instruments "succeed";
  4. runs the ISSUE-CODE CENSUS - a check code that is never emitted is an unproven check;
  5. writes dev/RUN_MANIFEST.json, the positive-green artifact.

Determinism: the manifest contains no timestamps or run ids, so two runs on identical inputs
produce byte-identical manifests. That makes the replay check a real test rather than a claim.
"""
import hashlib
import io
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CODE_RX = re.compile(r'check\(\s*(?:not\s+)?[\w\.]+\s*,\s*"([A-Z][A-Z0-9_]{3,})"')
ENTRY_RX = re.compile(r'if\s+__name__\s*==\s*[\'"]__main__[\'"]')

# v8.7.0: not every validate_*.py is a runnable entry point. Several are IMPORTABLE LIBRARY
# MODULES (validate_contract_schema, validate_delivery_package, validate_generation_prompts are
# imported by other validators and by this very harness). Running them standalone produces no
# verdict - counting them as "silent failures" would be our own false-red, and counting them as
# executed checks would inflate coverage. Classify, then report both classes.
ALL_MODULES = sorted((ROOT / "validators").glob("validate_*.py"))


def classify(p: Path) -> str:
    """Three classes, because conflating them produces our own false reds AND our own false
    greens (inflating coverage by counting a library module as an executed check)."""
    src = p.read_text(encoding="utf-8")
    if not ENTRY_RX.search(src):
        return "library_module"
    if "sys.argv[1]" in src or "add_argument" in src or "argparse" in src:
        return "argument_taking_cli"
    return "standalone_runner"


CLASSES = {p.name: classify(p) for p in ALL_MODULES}
ENTRY_POINTS = [p for p in ALL_MODULES if CLASSES[p.name] == "standalone_runner"]
LIBRARY_MODULES = [p for p in ALL_MODULES if CLASSES[p.name] == "library_module"]
ARG_CLIS = [p for p in ALL_MODULES if CLASSES[p.name] == "argument_taking_cli"]
VALIDATORS = ENTRY_POINTS
REASON_ALLOWLIST = {
    "missing optional file", "not present in this tree", "no examples shipped", "canary",
}


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run_validator(p: Path):
    """Run one validator, capture its verdict and the emitted codes.

    Two verdict shapes ship in this tree and BOTH are honoured:
      counted  : {"pass": bool, "passed": n, "failed": n, "failures": [...]}
      boolean  : {"validator": str, "pass": bool, "errors": [...]}
    Reading only the counted shape would have made six boolean-shape validators look like they
    examined zero targets - a false red manufactured by the harness itself."""
    try:
        r = subprocess.run([sys.executable, str(p)], capture_output=True, cwd=str(ROOT),
                           timeout=600)
    except subprocess.TimeoutExpired:
        return {"status": "TIMEOUT", "pass": False, "passed": 0, "failed": -1, "codes": [],
                "shape": "none", "sha256": sha(p)}
    out = r.stdout.decode("utf-8", "replace")
    rec = {"sha256": sha(p), "returncode": r.returncode, "codes": []}
    try:
        obj = json.loads(out)
    except Exception:
        rec.update({"status": "NO_JSON", "pass": False, "passed": 0, "failed": -1, "shape": "none",
                    "failures": ["validator produced no parseable JSON - silence is not a PASS"]})
        return rec
    if "passed" in obj or "failed" in obj:
        rec.update({"shape": "counted", "status": "PASS" if obj.get("pass") else "FAIL",
                    "pass": bool(obj.get("pass")), "passed": obj.get("passed", 0),
                    "failed": obj.get("failed", 0), "failures": obj.get("failures", [])[:5]})
    elif "pass" in obj:
        errs = obj.get("errors", [])
        rec.update({"shape": "boolean", "status": "PASS" if obj.get("pass") else "FAIL",
                    "pass": bool(obj.get("pass")), "passed": max(0, 1 - len(errs)),
                    "failed": len(errs), "failures": errs[:5]})
    else:
        rec.update({"shape": "unknown", "status": "NO_JSON", "pass": False, "passed": 0,
                    "failed": -1, "failures": ["JSON had no pass field - silence is not a PASS"]})
    rec["codes"] = sorted(set(re.findall(r"\b([A-Z][A-Z0-9_]{4,})\b", out)))
    return rec


def declared_codes() -> dict:
    """Every check code declared in ENTRY-POINT validator source, per file.

    Library modules are included but marked, because their codes fire inside the validators that
    import them; excluding them would understate the census."""
    out = {}
    for p in ALL_MODULES:
        src = p.read_text(encoding="utf-8")
        out[p.name] = sorted(set(CODE_RX.findall(src)))
    return out


def census(declared: dict, executed: dict):
    """A declared code that is never emitted anywhere is an unproven check."""
    all_emitted = set()
    for v in executed.values():
        all_emitted.update(v.get("codes", []))
    never, proven = [], {}
    for fname, codes in declared.items():
        unproven = [c for c in codes if c not in all_emitted]
        proven[fname] = len(codes) - len(unproven)
        never.extend((fname, c) for c in unproven)
    return sorted(never), proven, all_emitted


def monitors(declared, executed):
    """Cross-instrument contradiction monitors: two independent counts must agree."""
    rows = []

    def mon(name, a_label, a, b_label, b):
        agree = a == b
        rows.append({"monitor": name, "a": f"{a_label}={a}", "b": f"{b_label}={b}",
                     "agree": agree,
                     "detail": "" if agree else "CONTRADICTION - two instruments disagree; red even though both ran"})
        return agree

    # M1: runnable entry points on disk vs entry points the harness actually executed, AND the
    # library modules must NOT be counted as executed checks.
    mon("validator_census", "entry_points_on_disk", len(ENTRY_POINTS), "entry_points_executed",
        len(executed))
    rows.append({"monitor": "library_module_classification",
                 "a": f"library_modules={len(LIBRARY_MODULES)}",
                 "b": f"excluded_from_execution={all('__main__' not in p.read_text(encoding='utf-8') for p in LIBRARY_MODULES)}",
                 "agree": all("__main__" not in p.read_text(encoding="utf-8") for p in LIBRARY_MODULES),
                 "detail": "importable library modules are never counted as executed checks"})

    # M2: every runnable validator must have examined at least one target. Comparing a COUNT to a
    # BOOLEAN was itself a bad monitor (it contradicts by construction); compare the two
    # readings of the SAME question instead.
    for name, rec in sorted(executed.items()):
        total = rec.get("passed", -1) + rec.get("failed", -1)
        examined_at_least_one = total >= 1
        produced_verdict = rec.get("status") == "PASS" or rec.get("status") == "FAIL"
        rows.append({"monitor": f"target_reconciliation::{name}",
                     "a": f"examined_at_least_one={examined_at_least_one}",
                     "b": f"produced_a_verdict={produced_verdict}",
                     "agree": examined_at_least_one == produced_verdict or not produced_verdict,
                     "detail": ("a verdict with zero examined targets is a vacuous pass"
                                if produced_verdict and not examined_at_least_one else "")})

    # M3: negative fixtures registered vs present on disk (independent of the validator that
    #     also counts them) - two instruments, same question
    negdir = ROOT / "schemas/examples/negative_tests"
    on_disk = sorted(p.name for p in negdir.glob("*.json")) if negdir.exists() else []
    src_text = (ROOT / "validators/validate_state_serialization.py").read_text(encoding="utf-8")
    registered = sorted(set(re.findall(r'"([a-z0-9_\-]+\.json)":\s*\(validate_', src_text)))
    mon("negative_fixture_census", "on_disk", len(on_disk), "registered", len(registered))
    # and the sets themselves must be identical, not merely the same size
    only_disk = sorted(set(on_disk) - set(registered))
    only_reg = sorted(set(registered) - set(on_disk))
    rows.append({"monitor": "negative_fixture_set_equality",
                 "a": f"on_disk_only={only_disk}", "b": f"registered_only={only_reg}",
                 "agree": not only_disk and not only_reg,
                 "detail": "" if not only_disk and not only_reg else
                           "CONTRADICTION - a fixture exists on disk that nothing registers, or the reverse"})
    return rows


def main():
    # Run standalone runners.
    executed = {}
    for p in ENTRY_POINTS:
        executed[p.name] = run_validator(p)
    not_invoked = [p.name for p in ARG_CLIS]

    # v8.7.0 (Arena Round 2, item 1): REQUIRED GATES are INVOKED, never classified as
    # "argument-taking CLI, not invoked". A gate nobody ran cannot testify to readiness, and the
    # manifest's pass was previously derived partly from that silence. pass is now derived from
    # checks that ACTUALLY EXECUTED. This defect was found by an OUTSIDE model with no access
    # to project history - a green STRUCTURAL_VALIDATED label sat over a failing readiness check.
    REQUIRED_GATES = ["validate_candidate_readiness.py", "validate_release_consistency.py",
                      "validate_candidate_security.py"]
    gate_results = {}
    for g in REQUIRED_GATES:
        gp = ROOT / "validators" / g
        if gp.is_file():
            gate_results[g] = run_validator(gp)
        else:
            gate_results[g] = {"status": "MISSING", "pass": False, "codes": [], "sha256": None,
                               "failed": -1, "passed": 0}

    declared = declared_codes()
    never, proven, emitted = census(declared, executed)
    mons = monitors(declared, executed)

    contradictions = [m for m in mons if not m["agree"]]
    # An argument-taking CLI that produced no verdict is NOT a silent failure: it was never
    # given inputs. It is classified and counted, and exercised by the suite runner with real
    # arguments. Calling it a failure would be a false red manufactured by the harness.
    silent = [n for n, r in executed.items() if r["status"] in {"TIMEOUT", "NO_JSON"}]
    argcli_no_verdict = not_invoked
    failing = [n for n, r in executed.items() if r["status"] == "FAIL"]
    gate_failing = [g for g, r in gate_results.items() if not r.get("pass")]

    tree_version = None
    try:
        tree_version = json.loads((ROOT / "release/RELEASE.json").read_text(encoding="utf-8")).get("version")
    except Exception:
        pass

    manifest = {
        "schemaVersion": tree_version,
        "artifact": "RUN_MANIFEST",
        "purpose": ("A PASS is a produced artifact. This manifest is that artifact: without it "
                    "there is no green. Silence is a parse error, not a pass."),
        "determinism": ("No timestamps or run ids are recorded, so two runs on identical inputs "
                        "produce byte-identical manifests and the replay check is a real test."),
        "python": sys.version.split()[0],
        "counts": {
            "validatorModules_on_disk": len(ALL_MODULES),
            "standaloneRunners": len(ENTRY_POINTS),
            "argumentTakingClis": len(ARG_CLIS),
            "libraryModules": len(LIBRARY_MODULES),
            "validators_executed": len(executed),
            "validators_passed": sum(1 for r in executed.values() if r["status"] == "PASS"),
            "validators_failed": len(failing),
            "validators_no_output": len(silent),
            "argumentClis_not_invoked_without_inputs": len(argcli_no_verdict),
            "requiredGates_invoked": len(gate_results),
            "requiredGates_failed": len(gate_failing),
            "checks_executed": sum(r.get("passed", 0) + r.get("failed", 0)
                                   for r in executed.values() if r.get("failed", -1) >= 0),
            "declared_codes_total": sum(len(c) for c in declared.values()),
            "declared_codes_never_emitted": len(never),
        },
        "verdict": {
            # pass is DERIVED FROM ACTUALLY-EXECUTED checks only (v8.7.0, Arena R2 item 1)
            "pass": not contradictions and not failing and not silent and not gate_failing,
            "passDerivedFrom": ("executed checks + invoked required gates; a gate that was not "
                                "invoked can never contribute to this verdict"),
            "blocking": {
                "contradictions": [m["monitor"] for m in contradictions],
                "failingValidators": failing,
                "silentValidators": silent,
                "argClisNotInvoked": argcli_no_verdict,
                "requiredGatesFailed": gate_failing,
            },
        },
        "requiredGates": gate_results,
        "classification": CLASSES,
        "monitors": mons,
        "codeCensus": {
            "neverEmitted": [{"validator": f, "code": c} for f, c in never],
            "note": ("A declared code that no run ever emits is an UNPROVEN check - it may be "
                     "dead. Listed, not deleted: a code can be proven by a fixture in a later "
                     "version. Count reported; not blocking in this version."),
            "provenPerValidator": proven,
        },
        "validators": executed,
        "inputHashes": {
            "PACKAGE_MANIFEST.json": sha(ROOT / "PACKAGE_MANIFEST.json"),
            "release/RELEASE.json": sha(ROOT / "release/RELEASE.json"),
        },
        "proofBoundary": ("This manifest proves which instruments ran, what they examined and "
                          "what they found. It does NOT prove the tree is correct, that a "
                          "quality claim is true, or that any media exists. promotionEligible "
                          "is unaffected by a green manifest."),
    }

    out_path = ROOT / "dev/RUN_MANIFEST.json"
    out_path.write_text(json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
                        encoding="utf-8")
    print(json.dumps({"pass": manifest["verdict"]["pass"],
                      "modules": len(ALL_MODULES), "runners": len(ENTRY_POINTS),
                      "argCLIs": len(ARG_CLIS), "libs": len(LIBRARY_MODULES),
                      "passed": manifest["counts"]["validators_passed"],
                      "failed": failing, "silent": silent,
                      "contradictions": [m["monitor"] for m in contradictions],
                      "manifest": str(out_path.relative_to(ROOT))}, indent=2))
    return 0 if manifest["verdict"]["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())