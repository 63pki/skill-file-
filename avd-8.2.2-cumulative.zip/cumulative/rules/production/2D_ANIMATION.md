# Mode B — Animation Owner

**This is how to think about an animation brief, not a checklist.** Load it before planning Mode B work.

> **v8.2.2 — first/last-frame interpolation is a Veo 3.1 capability, NOT available on `gemini_omni_flash`** (docs-verified 2026-10-05; Google lists scene extension and last-frame control under Veo 3.1). This tree is locked to Omni. **Do not chain a last frame into a new clip.** The Omni substitute is a WIPE CUT: end clip A with something dark crossing the lens; start clip B from a FRESH start image out of that darkness. A fresh start resets drift; a chained last frame accumulates it.

## The question this mode exists to answer

**What moves, and what must stay exactly the same?** Animation fails on *continuity*: a character
or prop drifts between shots, and the audience reads drift as cheapness.

## The decision to make first

**Decide the motion vocabulary before the first frame.** Limited animation, hold-by-hold,
squash-and-stretch, or full animation? That single choice sets frame count, cost, and what the
style can forgive. Deciding per shot produces a sequence with no identity.

**Then lock the character/world bible.** Recurring characters, props, and environments need
explicit anatomy/movement schemas and true model-sheet prompts (`13`) *before* they animate.
Drift is almost always a missing lock, not a generation failure.

## The defaults to reject

| Default | Why it is wrong here |
|---|---|
| Full animation everywhere | Expensive and rarely what the story needs; holding on the important frames **is** craft |
| Interpolating between key poses unchanged | Reads as a machine moving, not a character acting — add arcs, overlaps, and a settle |
| Consistent volume across every frame | Squash with no stretch reads as a cartoon, not as weight |
| Redrawing backgrounds per shot | Backgrounds hold; only the acting layer moves |
| A "style" applied as a filter | Style is shape language and timing — `optional/02_animation_style_families.md` |

## Per moving shot, define before prompting

Intention · key-pose path · action · deformation · contact · camera · environmental motion · audio ·
endpoint · acceptance · **one-variable repair** · fallback. Narration overflow or an overloaded
shot **blocks motion** rather than truncating it.

## Lock before prompt

- Animation method and style family named, with its shape and timing rules.
- Asset IDs and expression/state set for every recurring element, approved once.
- Timing/pose plan; world rule; durable resolution — the story ends in a state, not mid-action.
- Shot plan with time, story function, visual, camera, audio per shot (`09`); dialogue read time
  plus comprehension allowance fits (`10`).

## Hard blocks

Anatomy defects · drifting recurring assets · a locked asset redrawn · identity misuse ·
**any claim of having inspected, watched, or heard media**.

## Repair order

**Identity, anatomy and continuity before anything aesthetic.** A beautiful shot with a drifting
hand is worth less than a plain shot that holds. Test the hardest identity/performance/contact
problem before full production.

**Out of scope here:** photoreal human likeness without approved references (Mode A's lock) and
layout/UI systems (Mode C).