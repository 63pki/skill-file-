# 04 Image Prompt Manual

## Role

Use the image stage for hero frames, products, characters, environments, thumbnails, design assets, reference sheets, and first/last frames.

## Mode gate

- **Photoreal:** physical light, lens perspective, materials, contact shadows, controlled imperfection.
- **Animation:** style family, silhouette, line, shape, shading, palette, on-model identity.
- **Motion graphics:** hierarchy, grid, palette, type, icon family, negative space.
- **Hybrid:** create clean plates and isolated layers for compositing.

Never leak photoreal skin/grain language into animation or flat design.

## Prompt order

```text
Output purpose → subject → reference roles → state/action → environment → composition →
mode-specific craft → critical constraints → canvas/aspect → post-production reservations
```

## The pasted prompt is PROSE; the field list is CONTROLLER-ONLY (v8.2.2)

**The field template above structures the work. It is not the artefact the generator receives.**

Write the **PASTE-BLOCK** as connected prose, in **the order the eye reads the frame**, and state
the **locks once, positively, at the end**. Move the field-by-field template into the
`CONTROLLER-ONLY` section.

### Why — a measured silent drop

The Arena coffee-hero strip test found the shot card carried **`scarred oak`** for the bench and a
**focus-falloff cue** for the cup. **Both existed on the card and both vanished between card and
paste block.** Decisions made and then dropped in translation are a **silent-drop defect in the
prompt pipeline** — the same class this project has now caught six times, and the most damning of
them because it happened in the last step before the generator sees anything.

### The rule

> **Every specific on the shot card reaches the paste block, or is deliberately dropped with a
> stated reason.** There is no third option.

```text
PASTE-BLOCK      connected prose, eye order: focal point → what touches it → room → edges → LOCKS
CONTROLLER-ONLY  the field list, acceptance, failure, one-variable repair
```

**Write position words, not cause words.** Generators draw `on, against, under, through, lit by,
reflected in, running out of frame, turned toward, next to its own dried ring`. They do not draw
`because, after, so that, every morning` — those live in the shot card, not the prompt.

**Mood words may not enter by default.** The bare word summons its own clichés. Keep the carrier;
add the mood word back only deliberately, at the end.

## Prompt levels

- **Seed:** subject + visual idea; for territory exploration.
- **Working:** adds composition, mode-specific craft, and canvas.
- **Locked:** adds approved reference roles and non-visible invariants.

More words are not inherently more control.

## Photoreal keyframe template

```text
Create a [purpose] keyframe of [subject] in [environment].
Use [REF ID] for [identity/geometry/material] only.
Composition: [shot size, placement, foreground/midground/background, movement/text space].
Lens perspective: [one coherent focal-length feel].
Light: [motivated source, direction, contrast/falloff].
Material behavior: [specific reflection/refraction/texture/contact].
Atmosphere/grade: [only what serves the concept].
Preserve: [load-bearing invariants].
Do not introduce: [short mode-specific suppression].
Canvas: [target aspect/orientation; verify support].
Reserve critical logo, CTA, legal copy, and subtitles for post.
```

## Reference-sheet template

```text
Create a neutral [turnaround/contact/location] sheet of the SAME [asset].
Views/panels: [list]. Vary only [named dimension].
Keep identity/geometry, scale, wardrobe/material, palette, and neutral light consistent.
No beautification, hybridization, new features, labels, or hero lighting.
Treat panel count and cross-panel consistency as targets to review, not guarantees.
```

## Typography

Generated text is exploratory. If short display text is useful, quote exact copy and define hierarchy and placement. Add logos, prices, CTA, subtitles, disclosures, and fine print in an editable design/post layer.

## Mode-aware suppression library

Use only relevant constraints:

```text
Product: no shape/part/count change; no alternate label; no extra logo.
Person: no identity/age/feature drift; no extra fingers; no beauty-filter smoothing.
Animation: no photoreal conversion; no line-weight/palette/outfit drift.
Design: no pseudo-text; no off-grid clutter; no inconsistent icon family.
Clean plate: no subject, text, watermark, baked shadow, or unwanted depth effect.
```

Long negative lists can introduce noise. Prefer one positive invariant plus a concise prohibition.
