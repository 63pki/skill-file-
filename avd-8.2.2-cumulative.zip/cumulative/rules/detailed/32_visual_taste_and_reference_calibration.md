# 32 Visual Taste and Reference Calibration

Use automatically for film-level, commercial-level, premium, portfolio, or client work when references exist or a quality bar must be established. Pair with `07` for intake, `26` for analysis, `31` for excellence gates, and `18` for evidence-based review.

Taste is not “make it beautiful.” It is the ability to identify what is specific, coherent, appropriate, and worth refusing.

## 1. Build a quality-bar board

Select 3–6 references with distinct jobs. Do not collect many images that all say the same thing.

```text
REF ID:
Reference category: [film frame / ad / photo / animation / design / edit / sound]
Rights/access status:
Use only for: [composition / light / material / production design / performance / color / edit / sound]
Specific value:
What must not be copied:
Compatibility with the brief:
```

Recommended roles:

- **North-star:** overall standard and emotional discipline.
- **Composition:** placement, depth, negative space, scale.
- **Light/material:** source logic, contrast, reflections, texture.
- **Production design:** location, props, wardrobe, history, detail.
- **Performance:** gesture, restraint, eyeline, reaction, timing.
- **Edit/sound:** rhythm, silence, Foley, transitions, music state.

## 2. Extract decisions, not adjectives

For every approved reference, record:

```text
Composition and hierarchy:
Shot size / perspective / lens character:
Light source, direction, hardness, falloff, practicals:
Palette and color relationships:
Material behavior and surface detail:
Production design / props / wardrobe / environment history:
Performance and staging:
Camera behavior:
Edit rhythm and transition logic:
Sound identity:
Why it works for this audience and promise:
```

Reject “cinematic,” “premium,” or “beautiful” unless translated into observable decisions.

## 3. Reference compatibility check

- Do realism/stylization levels agree?
- Do perspective and spatial scale agree?
- Do lighting direction and color temperature conflict?
- Do eras, cultures, architecture, wardrobe, or props contradict one another?
- Are animation shape, line, shading, and palette families compatible?
- Is the sound/edit reference appropriate for the duration and platform?
- Will the combination imitate one recognizable protected work?

If references conflict, assign separate roles or choose one owner. Do not average incompatible worlds.

## 4. Output comparison — and the TWO-WAY SPLIT (v8.6 Pillar 2)

Review only an attached output or explicit user observations.

**Before anything else, decide which of the two loops you are in. They have different rules, and
conflating them is how iteration turns into adjective escalation.**

| | **A — Fix what's broken** | **B — Make it better** |
|---|---|---|
| **Owner** | `17` (failure decisions) | **this section** |
| **Starting point** | a named defect or a failed gate | a *passing* output that reads as bland |
| **Question** | what is wrong? | what is undecided? |
| **Move** | **one variable**, the one the defect names | one rung of the taste ladder, one rung only |
| **Stops when** | the defect is gone | the next rung is a taste preference, not a defect |
| **Honest limit** | mechanical, verifiable | **judgement, not measurement** — never a score |

**Loop A never starts a creative change.** If the output passes and you want it better, you are in
Loop B. Spending Loop A's discipline on a taste improvement produces motion without progress.

**Loop B is not a defect list.** "Looks generic" is not a failure — it is the absence of a decision.
That is why it needs its own loop rather than being smuggled into repair.

### Loop B — make it better (the blandness playbook)

```text
Asset ID:            (the output you are improving)
It currently passes: which checks? 
BLAND BECAUSE:       what is undecided — name the specific absence, not an adjective
LADDER RUNG:         idea | composition | staging | light | material | camera | sound | polish   (ONE, the highest that is unresolved)
WHY THIS RUNG:       what decision is missing here, in one clause
MOVES CONSIDERED:    two named, concrete, in image terms (not "more cinematic")
CHANGE ONE:          the single variable you are changing
REVERT IF:           the rung did not resolve
NEXT RUNG:           what would come after this — or STOP, because you have run out of taste, not of attempts
```

**Three rules that keep Loop B honest:**

1. **One rung per change.** Climbing two rungs at once means you cannot attribute the result. v8.2.2 (Arena R2): the template previously listed 6 rungs while §5 defines 8 — sound and polish were missing. Loop B is what an operator actually fills in, so it now carries the full ladder.
2. **A move must be an image fact**, not an adjective. *"Shadow side falls to near-black"* is a
   move. *"More dramatic"* is not — it is a wish, and it cannot be evaluated.
3. **"Better" ends when the rungs are exhausted.** The honest next step is to stop and ask the
   operator, not to escalate adjectives. `24`'s translation table is the route for client-sourced
   "make it pop".

```text
Asset ID:
Reference expectation:
Direct observation / user report:
Matches:
Looks cheaper because:
Looks more generic because:      → Loop B (ladder rung), not a repair
Continuity or mode mismatch:     → Loop A (this IS a defect)
Sound/edit mismatch:             → Loop A
Highest-impact correction:
KEEP:
CHANGE ONE VARIABLE:
ACCEPT IF:
```

## 5. Taste ladder

Compare in order:

1. **Idea:** is it saying something specific?
2. **Composition:** is attention controlled immediately?
3. **Staging/performance:** does action or expression carry meaning?
4. **Light and production design:** does the world feel motivated and lived-in?
5. **Material/texture:** do surfaces behave correctly for the mode?
6. **Camera and edit:** does movement/cutting reveal information or emotion?
7. **Sound:** does the world have a specific acoustic identity?
8. **Polish:** grade, grain, typography, captions, delivery.

Do not polish a weak idea before fixing levels 1–3.

## 6. Delivery-size rejection test

- Is the focal read immediate?
- Does it feel intentional without prompt explanation?
- Is the difference from generic AI output visible?
- Are identity, geometry, typography, and contact credible?
- Does it belong to the approved world?

## 7. Verdict

- **CALIBRATED:** quality-bar references are coherent and translated into decisions.
- **REVISE BOARD:** references are weak, redundant, contradictory, or too close to protected expression.
- **REJECT OUTPUT:** asset misses the concept or quality bar structurally.
- **TARGETED REPAIR:** asset is usable; name one correction and acceptance condition.

Record active reference roles and verdict in `19_production_memory.md`.

## 8. No-reference calibration is still required

When the user supplies no references, do not silently invent a visual family and call it calibrated. Produce a reference-category plan:

```text
North-star quality category:
Construction/material category:
Performance/staging category:
Edit-rhythm category:
Sound-identity category:
Anti-reference categories:
Original combination rule:
What must be tested with a low-cost style tile:
```

The categories describe what to seek or evaluate; they are not fake citations. Return **CATEGORY PLAN — STYLE TEST REQUIRED** until a style tile or approved references establish the bar.
