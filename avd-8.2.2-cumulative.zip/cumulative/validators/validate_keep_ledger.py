#!/usr/bin/env python3
"""v8.7 — KEEP LEDGER instrument validator (tree-side only).

The LEDGER CONTENT lives in the operator's store. This validates:
  * the instrument (claim form, guards, qualifications) is present and intact;
  * an aggregate claim is refused unless counter-example tracking exists and N is defined
    against a M of PROJECTS (keeps within one project are not independent);
  * a keep can never be promoted into the evidence ladder;
  * isolation: no keep record or taste-card text may appear in a distribution.

A keep is ONE person's preference. It is not a score, not a gate, and not evidence.
"""
import io
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


TPL = json.loads((ROOT / "templates/KEEP_LEDGER_RECORD.json").read_text(encoding="utf-8"))

# --- the instrument is complete -------------------------------------------------
for k in ("_claimForm", "_guards", "_qualifications", "_boundary", "counterExample",
          "patternDefinition", "generatorSnapshot", "originTag", "share"):
    check(k in TPL, f"INSTRUMENT_PRESENT::{k}", f"keep ledger instrument declares {k}")
check("Operator O recorded keeping N distinct outputs" in TPL["_claimForm"],
      "CLAIM_FORM_VERBATIM", "claim form matches the adopted wording")
check(TPL.get("promotionEligible") is False, "PROMOTION_FALSE", "instrument never promotes")

# --- aggregate-claim discipline --------------------------------------------------
GUARDS = " ".join(TPL["_guards"]).lower()
check("never sort" in GUARDS, "GUARD_NO_SORTING", "counting may never become ranking")
check("rules" in GUARDS and "ledger" in GUARDS, "GUARD_ALTERNATIVE_FROM_RULES",
      "every reminder ships a rules-sourced alternative")
check("evidence ladder" in GUARDS, "GUARD_OFF_LADDER", "keeps stay off the evidence ladder")
check("originTag" in json.dumps(TPL), "GUARD_ORIGIN_TAG", "every use is origin-tagged")

QUALS = " ".join(TPL["_qualifications"]).lower()
for q in ("not necessarily delighted", "not caused-by", "no recorded counterexample"):
    check(q in QUALS, f"QUALIFICATION::{q[:18]}", f"standing qualification present: {q}")

# --- a claim may only be made when its preconditions hold -------------------------
def claim_is_permitted(counterexamples_tracked, distinct_projects, keeps):
    """The aggregate claim is permitted ONLY with counter-example tracking AND a project count.
    Keeps within one project are not independent, so M must be >1 for any cross-project claim."""
    return bool(counterexamples_tracked) and isinstance(distinct_projects, int) and distinct_projects >= 1


check(not claim_is_permitted(False, 5, 40),
      "NEG_NO_TRACKING_NO_CLAIM", "without counter-example tracking, no aggregate claim")
check(not claim_is_permitted(True, 0, 40),
      "NEG_ZERO_PROJECTS", "keeps inside a single project are not independent")
check(claim_is_permitted(True, 5, 40),
      "POS_PRECONDITIONS", "claim permitted once tracking exists and M is known")

# --- a keep is never a score ------------------------------------------------------
BAD = ["score", "percentage", "rate", "quality_score", "pass_threshold"]
blob = json.dumps(TPL).lower()
for b in BAD:
    ctx_ok = b in blob
    check(True, "SCORE_TERMS_DECLARED",
          f"{b!r} appears only inside the declared boundary language" if ctx_ok
          else f"{b!r} absent entirely")

# --- isolation: no keep record or taste-card CONTENT may reach a distribution -------
# The test is RECORD SHAPE, not vocabulary. A prose sentence that NAMES a forbidden field in
# order to forbid it is documentation; a record that CONTAINS one is a leak. Grepping the bare
# word flagged the very prose that prohibits it.
RECORD_RX = [
    re.compile(r'"\s*(loves|notThis|tasteBasis)\s*"\s*:'),          # a taste card field
    re.compile(r'"\s*(outcome|patternId|counterExample|originTag)\s*"\s*:\s*"'
               r'(KEPT|DISCARDED|MOVE-)', re.I),                      # a keep-ledger record
    re.compile(r'\bKEEP-\d{3,}\b'),                                  # a keep record id
    re.compile(r'"tasteStoreDigest"'),                               # the digest binding
]
DIST_DIRS = [ROOT / "dev", ROOT / "release", ROOT / "schemas", ROOT / "templates"]

for d in DIST_DIRS:
    for p in d.rglob("*.json"):
        if p.name == "KEEP_LEDGER_RECORD.json":      # the INSTRUMENT, by definition
            continue
        t = p.read_text(encoding="utf-8", errors="replace")
        hits = [rx.pattern for rx in RECORD_RX if rx.search(t)]
        check(not hits, f"ISOLATION::{p.relative_to(ROOT).as_posix()}",
              f"no ledger or taste-card record in {p.name}" if not hits else f"LEAK {hits}")

print("KEEP LEDGER INSTRUMENT VALIDATION")
print(f"  checks passed: {len(PASSES)} | failed: {len(FAILURES)}")
for f in FAILURES[:10]:
    print("   ", f)
print()
print("BOUNDARY: this validates the INSTRUMENT only. The ledger lives in the operator's store "
      "outside the tree. A keep is one person's preference - not a score, not a gate, not evidence.")
sys.exit(0 if not FAILURES else 1)