#!/usr/bin/env python3
"""Validate LEX_SENSORY (minimal slice) with the same discipline as LEX_MATERIAL.

Every row must carry a physical carrier, a LOCAL cause, and a VISIBLE EFFECT. A row without the
visible effect is a mood word pretending to be a technique, and is rejected.
"""
import io
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
P = ROOT / "dev/LEX_SENSORY.json"
PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


d = json.loads(P.read_text(encoding="utf-8"))
rows = d["rows"]

# POSITIVE CONTROL
good = rows[0]
check(all(good.get(k) for k in ("carrier", "localCause", "visibleEffect", "family", "id")),
      "POSCTRL_COMPLETE", "a well-formed sensory row carries all required fields")

REQUIRED = ("id", "family", "carrier", "localCause", "visibleEffect", "sizeNote",
            "appliesTo", "failsWhen", "lineage", "evidenceClass")
ids = []
for r in rows:
    miss = [k for k in REQUIRED if not r.get(k)]
    check(not miss, "ROW_COMPLETE", f"{r.get('id')} missing {miss}")
    ids.append(r["id"])
    # a carrier must be more than two plain words; a real carrier names a substance or object
    wc = len(r.get("carrier", "").split())
    check(wc >= 4, "CARRIER_PHYSICAL",
          f"{r['id']} names a physical object ({wc} words)")
    # the label may not assert a measurement it does not have
    ec = r.get("evidenceClass", "").lower()
    check(("observed-run" not in ec) or ("not observed" in ec),
          "NOT_OVERCLAIMED", f"{r['id']} does not claim a bare observed-run")
    check(r.get("family") in d["families"], "FAMILY_KNOWN", f"{r['id']} family={r.get('family')}")

check(len(ids) == len(set(ids)), "ID_UNIQUE", f"{len(ids)} rows, duplicates removed")
check(6 <= len(rows) <= 10, "SLICE_SIZE", f"{len(rows)} rows in the minimal slice")

# the strip test's missing specific must now have a carrier
blob = json.dumps(d).lower()
for need, label in [("dust", "dust in the beam"), ("steam", "steam against darkness"),
                    ("bead", "moisture beading"), ("cleared arc", "wiped arc in fogged glass")]:
    check(need in blob, f"SLICE_COVERS::{label}", f"carrier present for {label}")

# NEGATIVE CONTROLS - each must be rejected
def rejects(mutate, code, label):
    """Apply the mutation, then re-derive EVERY rule on the mutated lexicon.

    An earlier version asserted only on `visibleEffect` while the mutations touched
    localCause / carrier / evidenceClass — so three of four controls could never fire.
    """
    import copy
    bad = copy.deepcopy(d)
    mutate(bad)
    v = []
    for r in bad["rows"]:
        if not r.get("localCause", "").strip():
            v.append(f"{r.get('id')}:no-localCause")
        if not r.get("visibleEffect", "").strip():
            v.append(f"{r.get('id')}:no-visibleEffect")
        if len(r.get("carrier", "").split()) < 4:
            v.append(f"{r.get('id')}:carrier-too-thin")
        ec = r.get("evidenceClass", "").lower()
        if ("observed-run" in ec) and ("not observed" not in ec):
            v.append(f"{r.get('id')}:overclaims-observed-run")
    check(bool(v), f"NEG_{code}", f"{label} is rejected -> {v[:2]}")


def _no_cause(b):
    b["rows"][0].pop("localCause", None)


def _no_visible(b):
    b["rows"][0].pop("visibleEffect", None)


def _mood_only(b):
    b["rows"][0]["carrier"] = "warm"


def _overclaim(b):
    b["rows"][0]["evidenceClass"] = "observed-run"


rejects(_no_cause, "NO_CAUSE", "a row without a local cause")
rejects(_no_visible, "NO_VISIBLE", "a row without a visible effect")
rejects(_mood_only, "MOOD_NOT_CARRIER", "a mood word posing as a carrier")
rejects(_overclaim, "OVERCLAIM", "a row claiming observed-run")

print("LEX_SENSORY (minimal slice) VALIDATION")
print(f"  rows: {len(rows)} | families: {sorted(d['families'])}")
print(f"  checks passed: {len(PASSES)} | failed: {len(FAILURES)}")
for f in FAILURES[:8]:
    print("   ", f)
print()
print("SCOPE: this is the volumetric / condensation / thermal-trace slice only. The full lexicon")
print("(mood carriers, cannot-draw translations, blocklists) ships with v8.9.")
sys.exit(0 if not FAILURES else 1)