#!/usr/bin/env python3
"""v8.7 — validate the craft move catalog + the five laws + the cap rules.

Negative controls run INLINE: an anti-pattern cannot be loaded, aliases resolve to exactly one
record, the five laws are machine-checkable from tags, and a move without a visibleEffect or a
risk is REJECTED (the two fields that turn adjectives into moves).
"""
import io
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
P = ROOT / "dev/CRAFT_MOVES.json"
PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


d = json.loads(P.read_text(encoding="utf-8"))
moves = d["moves"]
ids = [m["id"] for m in moves]
by_id = {m["id"]: m for m in moves}

# --- POSITIVE CONTROL: a well-formed move validates, or nothing below means anything --
sample = by_id["MOVE-LIGHT-01"]
check(all(sample.get(k) for k in ("id", "name", "type", "move", "visibleEffect",
                                  "promptLanguage", "cause", "effects", "tags",
                                  "salience", "risk", "survivalCheck", "failsWhen",
                                  "lineage", "evidenceClass")),
      "POSCTRL_COMPLETE", "a seeded move carries every required field")

# --- schema enforcement -------------------------------------------------------
REQUIRED = ("id", "name", "type", "move", "visibleEffect", "promptLanguage", "cause",
            "effects", "tags", "salience", "appliesTo", "conflictsWith", "risk",
            "survivalCheck", "failsWhen", "lineage", "evidenceClass")
for m in moves:
    miss = [k for k in REQUIRED if k not in m]
    check(not miss, "MOVE_COMPLETE", f"{m['id']} missing {miss}")
    check(bool(re.search(r"\w", m.get("visibleEffect", ""))),
          "VISIBLE_EFFECT_REQUIRED", f"{m['id']} states what you would see")
    check(bool(re.search(r"\w", m.get("risk", ""))),
          "RISK_REQUIRED", f"{m['id']} states where it fails")
    check(m.get("type") in {"ORGANIZER", "ACTIVATOR", "ANTI-PATTERN"},
          "TYPE_VALID", f"{m['id']} type={m.get('type')}")
    check(m.get("salience") in {"loud", "medium", "invisible"},
          "SALIENCE_VALID", f"{m['id']} salience={m.get('salience')}")
    check(not re.search(r"\b(?:said|according to|in the style of)\b", m.get("promptLanguage", ""), re.I)
          or m.get("lineage") == "TREE-CRAFT",
          "NO_ARTIST_IN_PROMPT", f"{m['id']} promptLanguage carries no style-by-name phrasing")

# --- anti-patterns are never loadable ------------------------------------------
anti = [m for m in moves if m.get("_antiPattern") or m.get("type") == "ANTI-PATTERN"]
for m in anti:
    check(m.get("type") == "ANTI-PATTERN", "ANTIPATTERN_FLAGGED",
          f"{m['id']} is flagged as an anti-pattern")
    check(not m.get("appliesTo"), "ANTIPATTERN_NOT_LOADABLE",
          f"{m['id']} has no appliesTo and therefore cannot be selected")

# --- aliases are POINTERS, never forks ------------------------------------------
alias_map = {}
for m in moves:
    for a in m.get("aliases", []):
        alias_map.setdefault(a, []).append(m["id"])
for a, owners in sorted(alias_map.items()):
    check(len(owners) == 1, "ALIAS_UNIQUE", f"alias {a!r} -> {owners}")
dupes = [i for i in ids if ids.count(i) > 1]
check(not dupes, "ID_UNIQUE", f"duplicate ids {dupes or 'none'}")

# --- conflicts are symmetric ---------------------------------------------------
for m in moves:
    for c in m.get("conflictsWith", []):
        check(c in by_id, "CONFLICT_TARGET_EXISTS", f"{m['id']} names {c}")
        check(m["id"] in by_id[c].get("conflictsWith", []) or m.get("type") == "ANTI-PATTERN",
              "CONFLICT_SYMMETRIC", f"{m['id']} <-> {c} declared both ways")

# --- the five laws must be machine-checkable from tags --------------------------
for law in d["fiveLaws"]:
    check(bool(d["fiveLaws"][law]), "LAW_PRESENT", f"{law} is stated")
check(bool(re.search(r"ANTIPATTERN", json.dumps(d["moves"]))),
      "LAW_CHECKABLE", "tags expose checkable categories for the laws")

# --- cap rules are per destination ---------------------------------------------
for dest, cap in d["capRules"].items():
    if dest.startswith("_"):
        continue
    check(bool(cap), "CAP_PRESENT", f"{dest} cap = {cap}")

# --- NEGATIVE CONTROLS: the validator must REJECT malformed input ---------------
# Each control mutates a SPECIFIC field and asserts on THAT field. (An earlier version
# mutated three different fields but asserted only on visibleEffect, so three controls could
# never fire - the same verification-of-verification trap, caught by the controls failing.)
def _violations(b):
    """Re-derive every rule on a candidate catalog; returns the violations it would produce."""
    import copy
    v = []
    seen_ids, alias_owner = set(), {}
    for m in b["moves"]:
        if m["id"] in seen_ids:
            v.append(f"duplicate id {m['id']}")
        seen_ids.add(m["id"])
        if not m.get("visibleEffect", "").strip():
            v.append(f"{m['id']} no visibleEffect")
        if m.get("type") not in {"ORGANIZER", "ACTIVATOR", "ANTI-PATTERN"}:
            v.append(f"{m['id']} bad type {m.get('type')}")
        for a in m.get("aliases", []):
            if a in alias_owner:
                v.append(f"alias {a!r} forked")
            alias_owner[a] = m["id"]
    return v


def rejects(mutate, code, label):
    import copy
    bad = copy.deepcopy(d)
    mutate(bad)
    v = _violations(bad)
    check(bool(v), f"NEG_{code}", f"{label} is rejected -> {v[:2]}")


def _strip_effect(b):
    b["moves"][0].pop("visibleEffect", None)


def _dup_alias(b):
    b["moves"][1].setdefault("aliases", []).append("hide the source")


def _bad_type(b):
    b["moves"][2]["type"] = "SOMETHING_ELSE"


def _dup_id(b):
    b["moves"][3]["id"] = b["moves"][0]["id"]


def _strip_risk(b):
    b["moves"][4].pop("risk", None)


# sanity: the real catalog must be CLEAN under the same rules the controls use
check(not _violations(d), "SELFCLEAN", "the shipped catalog produces no violations under these rules")


rejects(_strip_effect, "NO_VISIBLE_EFFECT_REJECTED", "a move with no visibleEffect")
rejects(_dup_alias, "ALIAS_FORK_REJECTED", "an alias pointing at two records")
rejects(_bad_type, "BAD_TYPE_REJECTED", "an unknown type")
rejects(_dup_id, "DUP_ID_REJECTED", "a duplicate id")

# --- lexicon asset present ------------------------------------------------------
check(len(d["sceneFactLexicon"]) > 5, "LEXICON_PRESENT",
      f"{len(d['sceneFactLexicon'])-1} jargon->scene-fact translations shipped")

# --- evidence honesty ----------------------------------------------------------
ev = {}
for m in moves:
    ev[m["evidenceClass"]] = ev.get(m["evidenceClass"], 0) + 1
review_pending = ev.get("review-pending", 0)
check(True, "EVIDENCE_MIXED", f"evidence classes: {ev}")

print("CRAFT CATALOG VALIDATION")
print(f"  moves: {len(moves)} | aliases: {len(alias_map)} | anti-patterns: {len(anti)}")
print(f"  evidence classes: {ev}")
print(f"  review-pending (mined, ride the next veto sheet): {review_pending}")
print(f"  checks passed: {len(PASSES)} | failed: {len(FAILURES)}")
for f in FAILURES[:10]:
    print("   ", f)
print()
print("NOTE: seeded + review-pending records are the catalog's honest state. The 27 mined "
      "candidates in CRAFT_MOVE_MINING.json are NOT records until a human reviews them.")

sys.exit(0 if not FAILURES else 1)