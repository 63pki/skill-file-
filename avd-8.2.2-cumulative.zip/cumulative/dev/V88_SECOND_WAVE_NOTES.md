# v8.8 SECOND-WAVE CANDIDATES (design note, NOT built)

From Arena Round 3's craft-depth audit. These are **craft-depth gaps**, not missing process
steps — the archive names the subject but never supplies an actionable how-to. They are
**candidates for v8.8**, and none is built.

| Gap | What is missing | Which craft-engine wave it belongs to |
|---|---|---|
| **Macro optics and focus** | Working distance, depth-of-field tradeoffs, focus stacking, diffraction, close-focus distortion — central for small detailed objects | **Second wave.** `04` names the problem; no move supplies the method |
| **Colour science and grading logic** | A colour-management pipeline, gamut/display handling, highlight roll-off, constructing and evaluating a grade | **Second wave.** `12` has a Color Script *form* and no pipeline |
| **Brand typography and type composition** | Typeface selection, spacing, kerning, optical alignment, scale relationships, type as identity | **Second wave.** Exact copy is rightly reserved for post; type *as composition* is never taught |
| **Luxury semiotics and brand differentiation** | Distinguishing one luxury house, price tier or design lineage from another | **Second wave.** The tree can avoid gold-and-marble cliche and still produce generic luxury advertising |
| Reflective-object lighting setups | A working setup for a specific watch case, dial, cover, bevel; managing competing reflections | **PARTIALLY COVERED** — `MOVE-LIGHT-03 reflection architecture` supplies the principle, not the per-object recipe |
| Material/reflectance physics | Distinguishing brushed vs polished metal, coated glass, dial surfaces, leather, and their interaction with light | **PARTIALLY COVERED** — `MOVE-TEXTURE-01 material truth` names the rule, not the physics |
| Composition designed for a specific aspect ratio | How hierarchy, subject orientation and copy space change between square, vertical and wide frames | **Second wave.** `T4 destination matrix` from the production hunt is the adjacent open item |
| High-end still retouch and finishing | Product-retouch workflow: dust, surface cleanup, edge integrity, reflection reconstruction, focus blending, sharpening without falsifying material | **Second wave** |
| Product-specific concept derivation | Deriving an ownable idea from an actual product's design, use, audience or brand history | **PARTIALLY COVERED** — `MOVE-CONCEPT-01 one wrong thing` and `33B` Descent 1 are the mechanism; the domain craft is the operator's |
| Mechanical/horological design | Making a movement, dial, case or complication functionally credible | **OPERATOR DOMAIN KNOWLEDGE** — deliberately not a tree responsibility |

**Principle: the engine grows by moves the taste library can evidence, not by moves a reviewer
invents.** A second-wave candidate becomes a move only when a reference supports it — otherwise it
stays a documented gap, which is honest and still useful.
