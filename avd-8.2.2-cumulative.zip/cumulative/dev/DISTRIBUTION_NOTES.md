# Distribution notes

## What each distribution contains, and what it deliberately does not

### cumulative
The canonical release. Contains every shipped file **except** the dist-only artifacts named in
`PACKAGE_MANIFEST.json` `excluded` (the manifest itself, and this notes file's sibling
`DISTRIBUTION_MANIFEST.json`).

### Campaign evidence is NOT in any distribution (v8.2.2, declared after Arena Round 2)

The external-evidence campaign directory — including `validator-rated.result.json` — is **not
shipped**. Consequences, stated rather than implied:

* A reader of the cumulative dist **cannot independently inspect** the `nanoOmniABGeneration`
  PASS. The declaration in `release/RELEASE.json` is the authority; the underlying campaign
  artefacts are referenced by id only.
* This is deliberate. The evidence carries campaign ids, reviewer detail and operator project
  context, and a distribution built for upload to third-party models should not carry it.
* **Anyone auditing the A/B PASS needs the evidence directory, not the dist.** That limitation is
  named here so it is a declared boundary and not a silent omission.
