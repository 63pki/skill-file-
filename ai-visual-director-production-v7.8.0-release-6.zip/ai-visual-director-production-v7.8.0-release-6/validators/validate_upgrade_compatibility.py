#!/usr/bin/env python3
"""Validate path preservation and immutable-guide compatibility against V7.6.0."""
from pathlib import Path
import argparse,hashlib,json
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def validate(root):
 root=Path(root).resolve();e=[];bp=root/'release/V7_6_0_RELEASE_4_BASELINE_HASHES.json'
 if not bp.is_file():return [{'code':'CANDIDATE_BASELINE_MISSING','message':str(bp)}]
 try:b=json.loads(bp.read_text())
 except Exception as x:return [{'code':'CANDIDATE_BASELINE_PARSE','message':str(x)}]
 current={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};expected=set(b.get('files',{}))
 for rel in sorted(expected-current):e.append({'code':'CANDIDATE_BASELINE_PATH_MISSING','message':rel})
 for rel in b.get('immutablePaths',[]):
  p=root/rel;want=(b.get('files',{}).get(rel) or {}).get('sha256')
  if not p.is_file() or sha(p)!=want:e.append({'code':'CANDIDATE_IMMUTABLE_DRIFT','message':rel})
 return e
def main():
 a=argparse.ArgumentParser();a.add_argument('root',nargs='?',default=str(Path(__file__).resolve().parents[1]));n=a.parse_args();errors=validate(n.root);out={'validator':'V7.8.0-UPGRADE-COMPATIBILITY','pass':not errors,'errors':errors,'proofBoundary':'Path preservation and declared immutable hashes only; not semantic equivalence for every historical behavior.'};print(json.dumps(out,indent=2));raise SystemExit(0 if not errors else 1)
if __name__=='__main__':main()
