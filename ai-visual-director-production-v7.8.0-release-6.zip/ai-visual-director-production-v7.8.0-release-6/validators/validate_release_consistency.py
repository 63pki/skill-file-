#!/usr/bin/env python3
from pathlib import Path
import json,re,sys,hashlib
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
e=[]
def add(c,m,p=''): e.append({'code':c,'message':m,'path':p})
try:r=json.loads((ROOT/'release/RELEASE.json').read_text())
except Exception as x:r={};add('RELEASE_PARSE',str(x),'release/RELEASE.json')
if r.get('version')!='7.8.0':add('VERSION_DRIFT',str(r.get('version')))
stack=r.get('generationStack',{})
if stack.get('stillOwner')!='NANO_BANANA_PRO':add('STILL_OWNER_DRIFT',str(stack))
if stack.get('videoOwner')!='GEMINI_OMNI_FLASH':add('VIDEO_OWNER_DRIFT',str(stack))
if stack.get('mediaExecution')!='NOT_SUPPORTED':add('PROMPT_ONLY_DRIFT',str(stack))
try:m=json.loads((ROOT/'bootstrap/runtime_load_manifest.json').read_text())
except Exception as x:m={};add('RUNTIME_MANIFEST_PARSE',str(x))
if m.get('packageVersion')!='7.8.0':add('RUNTIME_VERSION_DRIFT',str(m.get('packageVersion')))
for rel,rec in m.get('files',{}).items():
 p=ROOT/rel
 if not p.is_file():add('RUNTIME_FILE_MISSING',rel,rel)
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=rec.get('sha256'):add('RUNTIME_HASH_MISMATCH',rel,rel)
ids=[int(x) for x in re.findall(r'^\| R(\d+) \|',(ROOT/'dev/REGRESSION_TESTS.md').read_text(),re.M)]
if len(ids)!=650 or sorted(ids)!=list(range(1,651)):add('REGRESSION_CATALOG_DRIFT',str({'count':len(ids),'first':min(ids or [0]),'last':max(ids or [0])}))
print(json.dumps({'validator':'V7.8.0-RELEASE-CONSISTENCY','pass':not e,'errors':e},indent=2));raise SystemExit(0 if not e else 1)
