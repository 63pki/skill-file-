# Official Prompt Guide Alignment — Snapshot 2026-07-21

## Nano Banana Pro

Sources:
- https://ai.google.dev/gemini-api/docs/image-generation
- https://cloud.google.com/blog/products/ai-machine-learning/ultimate-prompting-guide-for-nano-banana

Mapped capabilities: text-to-image, reference-based generation, conversational editing, controlled variations, text/localization, reference roles, aspect/resolution assumptions, acceptance and repair.

## Gemini Omni Flash

Sources:
- https://ai.google.dev/gemini-api/docs/omni
- https://ai.google.dev/gemini-api/docs/video
- https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/video/video-gen-prompt-guide

Mapped capabilities: text-to-video, image-to-video, reference-to-video, existing-video editing, stateful conversational editing, starting-image/reference roles, continuous-shot control, natural/timecode timing, native audio, exact text prompting and simple edit locks.

Mapped limitations: preview status, short-form surface limits, no extension, no first/last interpolation, no uploaded-audio reference, no voice editing, no multiple-video reasoning, no dedicated negative parameter, unreliable video-reference processing and consistency risk across scene changes or pans.

This mapping proves documentation alignment only, not successful media generation.
