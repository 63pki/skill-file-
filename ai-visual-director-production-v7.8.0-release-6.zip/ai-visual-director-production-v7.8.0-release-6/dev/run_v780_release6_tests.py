#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys
import json
import py_compile
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "bootstrap"))
sys.path.insert(0, str(ROOT / "validators"))
checks = []


def record(name, passed, **details):
    checks.append({"name": name, "pass": bool(passed), **details})


def run(name, command):
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    record(name, result.returncode == 0, stdout=result.stdout[-4000:], stderr=result.stderr[-2000:])


run("runtime-manifest-rebuild", [sys.executable, "bootstrap/build_runtime_manifest.py"])
run("forbidden-residue", [sys.executable, "validators/validate_forbidden_residue.py", str(ROOT)])
run("release-consistency", [sys.executable, "validators/validate_release_consistency.py", str(ROOT)])

compile_errors = []
for path in ROOT.rglob("*.py"):
    try:
        py_compile.compile(str(path), doraise=True)
    except Exception as error:
        compile_errors.append({"path": path.relative_to(ROOT).as_posix(), "error": str(error)})
record("python-compile", not compile_errors, errors=compile_errors)

required = [
    "adapters/generation/NANO_BANANA_PRO.md",
    "adapters/generation/GEMINI_OMNI_FLASH.md",
    "adapters/generation/NANO_BANANA_PRO_OMNI_FLASH_PIPELINE.md",
]
for mode_letter in "ABCD":
    required.extend([
        f"adapters/generation/modes/MODE_{mode_letter}_NANO_BANANA_PRO.md",
        f"adapters/generation/modes/MODE_{mode_letter}_OMNI_FLASH.md",
    ])
missing = [item for item in required if not (ROOT / item).is_file()]
record("cross-mode-adapters", not missing, missing=missing)

from runtime_selection import select_rules
manifest = json.loads((ROOT / "bootstrap/runtime_load_manifest.json").read_text())
mode_map = {
    "A_PHOTOREAL_COMMERCIAL": "MODE_A",
    "B_ANIMATION": "MODE_B",
    "C_MOTION_GRAPHICS": "MODE_C",
    "D_HYBRID_COMPOSITING": "MODE_D",
}
routing_errors = []
for mode, prefix in mode_map.items():
    contract = {
        "projectClass": "SUBSTANTIAL",
        "mode": mode,
        "audienceTriggers": ["GENERAL"],
        "tools": {"stillGeneration": "NANO_BANANA_PRO", "videoGeneration": "GEMINI_OMNI_FLASH"},
    }
    selected, _, errors, _ = select_rules(contract, manifest)
    if errors or not any(prefix in item and "NANO_BANANA_PRO" in item for item in selected) or not any(prefix in item and "OMNI_FLASH" in item for item in selected):
        routing_errors.append({"mode": mode, "errors": errors, "selected": selected})
record("cross-mode-routing-parity", not routing_errors, errors=routing_errors)

from validate_generation_prompts import validate as validate_prompts
prompt_errors = []
image_block = """<!-- AVD:NANO_PROMPT id=NBP-001 framework=NBP-F1 -->
Acceptance: identity and composition match.
First one-variable repair: strengthen only the identity lock.
<!-- /AVD:NANO_PROMPT -->"""
video_block = """<!-- AVD:OMNI_PROMPT id=OM-001 task=OM-F2 -->
Action: one controlled action.
Camera: static.
End condition: stable resolved frame.
Acceptance: identity and endpoint remain correct.
First one-variable repair: simplify only the action.
<!-- /AVD:OMNI_PROMPT -->"""
for mode in mode_map:
    errors = []
    validate_prompts(
        {"mode": mode, "tools": {"stillGeneration": "NANO_BANANA_PRO", "videoGeneration": "GEMINI_OMNI_FLASH"}},
        {"artifacts": [{"body": image_block + "\n" + video_block}]},
        errors,
    )
    if errors:
        prompt_errors.append({"mode": mode, "errors": errors})
record("cross-mode-prompt-validation", not prompt_errors, errors=prompt_errors)

owner_errors = []
validate_prompts(
    {"mode": "B_ANIMATION", "tools": {"stillGeneration": "UNASSIGNED", "videoGeneration": "UNASSIGNED"}},
    {"artifacts": []},
    owner_errors,
)
record("canonical-owner-rejection", {item.get("code") for item in owner_errors} == {"STILL_OWNER_DRIFT", "VIDEO_OWNER_DRIFT"}, errors=owner_errors)

from validate_shot_burden import validate as validate_burden
burden_errors = validate_burden([{"id": "SH-01", "burden": {"subjectActions": ["run", "jump"], "cameraChanges": 1, "textEvents": 1}}])
record("shot-burden-blocker", any(item.get("code") == "SHOT_BURDEN_OVERLOAD" for item in burden_errors), errors=burden_errors)

from validate_status_singularity import scan as scan_status
with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    (root / "STATUS.txt").write_text("Validator PENDING\n")
    (root / "validation").mkdir()
    (root / "validation/STATUS.txt").write_text("Validator PASS\n")
    (root / "validation/VALIDATION_RESULT.json").write_text(json.dumps({"pass": True}))
    conflicts = scan_status(root)
record("status-conflict-blocker", any(item.get("code") == "PACKAGE_STATUS_CONFLICT" for item in conflicts), errors=conflicts)

with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    (root / "STATUS.txt").write_text("Validator PASS\n")
    (root / "VALIDATION_RESULT.json").write_text(json.dumps({"pass": True}))
    clean_status = scan_status(root)
record("validator-evidence-packaging", not clean_status, errors=clean_status)

runtime_text = (ROOT / "rules/RUNTIME.md").read_text()
required_limitations = [
    "video extension unsupported",
    "first/last-frame interpolation unsupported",
    "uploaded audio references unsupported",
    "voice editing unsupported",
    "multiple-video reasoning unsupported",
    "dedicated negative-prompt parameter unsupported",
]
missing_limits = [item for item in required_limitations if item not in runtime_text]
record("omni-limitations-enforced", not missing_limits, missing=missing_limits)

out = {
    "suite": "V7.8.0-RELEASE-6",
    "pass": all(item["pass"] for item in checks),
    "checks": checks,
    "proofBoundary": "Structural and deterministic checks only; media and human evidence remain NOT_RUN.",
}
(ROOT / "dev/V7_8_0_RELEASE_6_RESULTS.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))
raise SystemExit(0 if out["pass"] else 1)
