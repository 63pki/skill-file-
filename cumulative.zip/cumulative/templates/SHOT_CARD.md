# SHOT CARD — the conception artifact (v8.6)

**Fill this before writing a single word of prompt.** It is a design record, not a quality claim.

> **Proof boundary.** A completed shot card documents **intent**, not outcome. It cannot predict
> what will be generated, it is not validated by any gate, and it proves nothing about the result.
> It is reviewable *before* spend — that is its entire value. **Never score it.** No
> "conception quality", no points, no percentage: anything scorable becomes something to game.

---

## STAKE SCALE — set before anything else

| Scale | Use when | Depth required |
|---|---|---|
| **SKETCH** | throwaway test, one shot, internal exploration | Descent 1 only. Name the intent in one line; skip the rest. |
| **STANDARD** | a real deliverable with a real audience | Full three descents. Element table required. |
| **CAMPAIGN** | multi-shot, multi-platform, someone will defend the decisions | Full + kill list + taste basis + every locked field signed. |

---

## DESCENT 1 — GOAL

*Before any image exists. Answers why, for whom, where — not what.*

```text
PURPOSE:     sell | explain | prove | recruit | orient          (one, not three)
VIEWER:      who, and what must they DO or FEEL in the first 2 seconds?
PLACE:       where does this live? feed | site hero | PDP | print | pitch | venue
SUCCESS:     how will we know it worked — and WHO says so?
BRIEF READ:  one sentence. If it cannot be written, the brief is not understood; prompting is premature.
```

**Facts vs latitude.** Split every element into the part that is **FACT** (window, hour, material,
dimensions, an approved reference) and the part you have **LATITUDE** on (framing, pacing, palette,
what to exclude). Facts are not decisions — record them, do not re-derive them every attempt.
Latitude is where the craft lives.

## DESCENT 2 — MOMENT

*Where the tree is quietest, and where the defaults are loudest.*

```text
THE MOMENT:   what is happening in this frame — and what just happened before it?
OFF-FRAME:    what exists just outside the frame that we know but do not show?
DECISION:     what has the subject just decided, or is about to?
TENSION:      what is unresolved at the cut?
WHY THIS FRAME: why this instant, not the one before or after?
```

**Stop when** it draws as one thumbnail with no labels. Territory is an idea; a *moment* is a frame
with a time inside it. "A mug on a table" is not a moment; "fresh out of the kiln, one hour before
sale" is.

## DESCENT 3 — ELEMENTS

*Every row: a decision with a reason, plus the default you rejected. An empty reason means the row
was not designed.*

| Element | Decision (image terms) | Why this serves the goal | **Default rejected** |
|---|---|---|---|
| Subject / pose | | | centred, posed, inert |
| Expression | | | stock pleasant affect |
| Environment | | | seamless void; generic office |
| Light logic | source, direction, reason | | even frontal fill |
| Palette | relationship + reason | | default neutral grade |
| Camera stance | level / above / below / distance | | default three-quarter hero angle |
| Props | which ONE carries meaning | | decorative clutter, evenly spread |
| Negative space | where the eye rests; where copy goes | | accidental balance |
| Material truth | what surface actually looks like | | pristine, flawless |
| Mood (3 words) | then converted to light/palette/staging | | "cinematic", "premium" |

**Every craft term pairs with its visible effect.** *"Negative fill"* → *"the shadow side falls to
near-black"*. A term you cannot show on camera is not a direction — it is a mood word.

## KILL LIST (required at CAMPAIGN; cheap everywhere)

**What this frame will NOT contain** — and why. This is the highest-value field on the card: a frame
reads as human when *someone chose to exclude something*, and every model tell is the absence of a
decision.

```text
EXCLUDED:            …
BECAUSE:              …
```

## TASTE BASIS (optional — never mandatory)

```text
TASTE BASIS:   R003, R011        (ids only — the tree never opens reference images)
CONFLICT:      R003 vs R011 on warmth — unreconciled (surfaced, never averaged)
TRANSFER:      "patient, not cold"     (the operator's words — carry verbatim, never paraphrase)
tasteBasis:    REFERENCES | LADDER_ONLY
```

`LADDER_ONLY` means no reference applied and the ladder decided alone. **It is not a failure and
never blocks** — but it must be stated, so a taste claim is never implied that was not applied.

## LOCKED — do not change without a new card

```text
LOCKED:        geometry · labels · approved references · cleared rights · exact copy
OPEN:          framing · timing · palette · supporting shots
```

## ACCEPTANCE TESTS

Run on the **output**, after generation — never on this card.

```text
[ ] SQUINT     — does it hold in greyscale? (tests whether composition carries the idea)
[ ] SOURCE     — can I name the light source and why?
[ ] ANYWHERE   — does this read as belonging to this brand/place, or generically?
[ ] SWAP       — would this frame still work with the subject replaced? (it shouldn't)
[ ] BEFORE/AFTER — is the difference attributable to ONE named decision?
```

## ANTI-DEFAULT CHECKLIST (from the merged tell inventories)

Named, current, and specific — these are the model's habits, not abstractions:

- [ ] AI-purple / generic gradient hero · centered subject on a sweep
- [ ] Three equal feature cards in a row · generic glassmorphism applied everywhere
- [ ] Even frontal light with no shadow story · plain backdrop with no place in it
- [ ] Perfectly clean surface with no evidence of use · evenly spaced objects
- [ ] Default three-quarter "hero" angle · neutral, slightly cool, low-contrast grade
- [ ] Something explaining everything inside the frame (nothing implied beyond it)
- [ ] **Banned words** — `stunning`, `epic`, `cinematic`, `8K`, `ultra-detailed`,
      `award-winning`, `breathtaking`, `masterpiece`. Anti-signals: they raise nothing.

---

**One line before you prompt:** what must this frame be true about, and what did you decide?