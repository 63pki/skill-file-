# AUDIO DESCRIPTION SCRIPT

**Shipped in** v8.0.3 (B2). For any deliverable carrying essential visual information that
speech does not convey. Rule 10 already requires mechanical word counts, pauses and estimated
fit for spoken content; this template applies the same discipline to description.

**Timing math (rule 10):** usable words ≈ duration_s × 2.2, then subtract pauses. A 6-second
clip carries ≈ 13 words before pauses — enough for one short clause, not a paragraph.

| Timecode | Visual (what the audience sees) | Description (what is spoken) | Words | Fits window? |
|---|---|---|---|---|
| 00:00–00:02 | REPLACE | REPLACE | 0 | — |
| 00:02–00:04 | REPLACE | REPLACE | 0 | — |
| 00:04–00:06 | REPLACE | REPLACE | 0 | — |

**Checklist**
- [ ] Describes only essential visual information, not what speech already conveys.
- [ ] Fits the window per the timing math above, pauses counted.
- [ ] Does not contradict the caption track (same words, same order).
- [ ] Placement decided: burned-in, sidecar, or separate track — recorded, not assumed.
- [ ] Contrast against the underlying frame meets `WCAG-2.1-SC-1.4.3` if burned in.

**Proof boundary:** a script is a plan. Whether it was read correctly is a human-review fact
this prompt-only tree cannot produce.