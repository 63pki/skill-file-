# ACCESSIBILITY MATRIX

**Required by** `rules/audience/ACCESSIBILITY.md`. **Shipped in** v8.0.3 (B2); before this
template the rule required an artifact no template implemented, so no project could satisfy it.

One row per applicable requirement. `Standard` must be an id from `dev/ACCESSIBILITY_STANDARDS.json`
(or an operator-owned PLATFORM SPEC with its source and date). A requirement with no row is
unmet; an ASSUMPTION row is not a pass.

| Requirement | Standard / source | Applied value | Deliverables affected | Test method | Status | Limitation | Human-review evidence |
|---|---|---|---|---|---|---|---|
| No hazardous flashing | WCAG-2.1-SC-2.3.1 | ≤3 flashes/second | REPLACE | frame-by-frame luminance scan | PROPOSED | none | REPLACE |
| Caption readability (contrast) | WCAG-2.1-SC-1.4.3 | 4.5:1 body text | REPLACE | overlay caption still over the darkest and brightest frames | PROPOSED | none | REPLACE |
| Captions present for speech | WCAG-2.1-SC-1.2.2 | full caption track | REPLACE | operator watch-through | PROPOSED | none | REPLACE |
| Broadcast loudness (delivery only) | EBU-R128 | −23 LUFS ±1 | REPLACE | measure the delivered master, not the generated clip | PROPOSED | generated media is not the master | REPLACE |
| Caption line length / reading rate | CEA-608 / CEA-708 | REPLACE (quote current doc) | REPLACE | measure captions against the source transcript | PROPOSED | none | REPLACE |

**Reduced motion** is a variant deliverable, not a footnote: it carries its own board rows and
its own row here, so the requirement is measurable rather than asserted.

**Proof boundary:** this matrix records *intended* handling. A row at PROPOSED is a plan; only
the test-method column, executed on real media by a human, converts it to a claim. The
prompt-only tree can fill this table; it cannot fill the evidence column.