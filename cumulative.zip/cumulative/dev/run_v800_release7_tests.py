#!/usr/bin/env python3
"""AVD v8.0.0 in-process regression suite.

Companion to dev/run_v780_release6_tests.py (which drives validators via
subprocess and remains the shipped Release 6 runner). This suite executes the
v8.0.0 additions IN-PROCESS: it imports each validator module and calls its
entry function directly, so it runs in restricted environments where spawning
subprocesses is unavailable. It also re-asserts the shipped in-process checks
that the Release 6 runner performs, so a green run here is the executable
evidence for regression rows R651-R687.

Exit 0 = all checks pass. Writes dev/V8_0_0_SUITE_RESULTS.json.
UTF-8; stdlib only.
"""
from pathlib import Path
import json
import py_compile
import sys
import shutil

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "bootstrap"))
sys.path.insert(0, str(ROOT / "validators"))

checks = []


def record(name, passed, **details):
    checks.append({"name": name, "pass": bool(passed), **details})


def main():
    # --- v8 validators, in-process -------------------------------------
    # These validators print JSON and exit via main(); SystemExit code is the verdict.
    import importlib
    mods = [
        ("R651-R656 state layer", "validate_state_serialization"),
        ("R657 gate DAG", "validate_gate_dag"),
        ("R658-R676 MCP contracts", "validate_mcp_contracts"),
        ("R682-R687 approval + versioning", "validate_approval_versioning"),
    ]
    for label, mod_name in mods:
        try:
            mod = importlib.import_module(mod_name)
            # these validators print JSON and exit via main(); guard against SystemExit
            try:
                mod.main()
            except SystemExit as ex:
                code = ex.code
            else:
                code = 0
            record(label, code == 0, exitCode=code)
        except Exception as ex:
            record(label, False, error=f"{type(ex).__name__}: {ex}")

    # signal_authority: --check all (prints; exit code)
    import signal_authority
    try:
        code = signal_authority.check_all()
    except Exception as ex:
        code = 1
        record("R677-R681 signal layer", False, error=f"{type(ex).__name__}: {ex}")
    else:
        record("R677-R681 signal layer", code == 0, exitCode=code)

    # --- shipped Release-6 in-process checks (subset re-asserted) -------
    # python-compile sweep
    compile_errors = []
    for path in ROOT.rglob("*.py"):
        try:
            py_compile.compile(str(path), doraise=True)
        except Exception as error:
            compile_errors.append({"path": path.relative_to(ROOT).as_posix(), "error": str(error)})
    record("python-compile", not compile_errors, errors=compile_errors)

    # cross-mode adapters present
    required = [
        "adapters/generation/NANO_BANANA_PRO.md",
        "adapters/generation/GEMINI_OMNI_FLASH.md",
        "adapters/generation/NANO_BANANA_PRO_OMNI_FLASH_PIPELINE.md",
    ]
    for mode_letter in "ABCD":
        required.extend([
            f"adapters/generation/modes/MODE_{mode_letter}_NANO_BANANA_PRO.md",
            f"adapters/generation/modes/MODE_{mode_letter}_OMNI_FLASH.md",
        ])
    missing = [item for item in required if not (ROOT / item).is_file()]
    record("cross-mode-adapters", not missing, missing=missing)

    # runtime routing parity
    from runtime_selection import select_rules
    manifest = json.loads((ROOT / "bootstrap/runtime_load_manifest.json").read_text(encoding="utf-8"))
    mode_map = {
        "A_PHOTOREAL_COMMERCIAL": "MODE_A",
        "B_ANIMATION": "MODE_B",
        "C_MOTION_GRAPHICS": "MODE_C",
        "D_HYBRID_COMPOSITING": "MODE_D",
    }
    routing_errors = []
    for mode, prefix in mode_map.items():
        contract = {
            "projectClass": "SUBSTANTIAL",
            "mode": mode,
            "audienceTriggers": ["GENERAL"],
            "tools": {"stillGeneration": "NANO_BANANA_PRO", "videoGeneration": "GEMINI_OMNI_FLASH"},
        }
        selected, _, errors, _ = select_rules(contract, manifest)
        if errors or not any(prefix in item and "NANO_BANANA_PRO" in item for item in selected) or not any(prefix in item and "OMNI_FLASH" in item for item in selected):
            routing_errors.append({"mode": mode, "errors": errors, "selected": selected})
    record("cross-mode-routing-parity", not routing_errors, errors=routing_errors)

    # prompt validation parity
    from validate_generation_prompts import validate as validate_prompts
    prompt_errors = []
    image_block = """<!-- AVD:NANO_PROMPT id=NBP-001 framework=NBP-F1 -->
Acceptance: identity and composition match.
First one-variable repair: strengthen only the identity lock.
<!-- /AVD:NANO_PROMPT -->"""
    video_block = """<!-- AVD:OMNI_PROMPT id=OM-001 task=OM-F2 -->
Action: one controlled action.
Camera: static.
End condition: stable resolved frame.
Acceptance: identity and endpoint remain correct.
First one-variable repair: simplify only the action.
<!-- /AVD:OMNI_PROMPT -->"""
    for mode in mode_map:
        errors = []
        validate_prompts(
            {"mode": mode, "tools": {"stillGeneration": "NANO_BANANA_PRO", "videoGeneration": "GEMINI_OMNI_FLASH"}},
            {"artifacts": [{"body": image_block + "\n" + video_block}]},
            errors,
        )
        if errors:
            prompt_errors.append({"mode": mode, "errors": errors})
    record("cross-mode-prompt-validation", not prompt_errors, errors=prompt_errors)

    # canonical owner rejection
    owner_errors = []
    validate_prompts(
        {"mode": "B_ANIMATION", "tools": {"stillGeneration": "UNASSIGNED", "videoGeneration": "UNASSIGNED"}},
        {"artifacts": []},
        owner_errors,
    )
    record("canonical-owner-rejection", {item.get("code") for item in owner_errors} == {"STILL_OWNER_DRIFT", "VIDEO_OWNER_DRIFT"}, errors=owner_errors)

    # shot burden blocker
    from validate_shot_burden import validate as validate_burden
    burden_errors = validate_burden([{"id": "SH-01", "burden": {"subjectActions": ["run", "jump"], "cameraChanges": 1, "textEvents": 1}}])
    record("shot-burden-blocker", any(item.get("code") == "SHOT_BURDEN_OVERLOAD" for item in burden_errors), errors=burden_errors)

    # status singularity — scratch dir INSIDE the workspace (sandbox-safe)
    import tempfile
    scratch_base = ROOT / "test" / "_suite_scratch"
    scratch_base.mkdir(parents=True, exist_ok=True)
    from validate_status_singularity import scan as scan_status
    troot = scratch_base / "conflict_case"
    if troot.exists():
        shutil.rmtree(troot, ignore_errors=True)
    troot.mkdir(parents=True)
    (troot / "STATUS.txt").write_text("Validator PENDING\n", encoding="utf-8")
    (troot / "validation").mkdir()
    (troot / "validation/STATUS.txt").write_text("Validator PASS\n", encoding="utf-8")
    (troot / "validation/VALIDATION_RESULT.json").write_text(json.dumps({"pass": True}), encoding="utf-8")
    conflicts = scan_status(troot)
    record("status-conflict-blocker", any(item.get("code") == "PACKAGE_STATUS_CONFLICT" for item in conflicts), errors=conflicts)
    shutil.rmtree(troot, ignore_errors=True)

    # regression fixtures
    from validate_project import result as project_result
    fixture_dir = ROOT / "tests" / "fixtures"
    fixture_names = sorted(p.name[: -len("_expected.json")] for p in fixture_dir.glob("*_expected.json"))
    fixture_failures = []
    for stem in fixture_names:
        contract = json.loads((fixture_dir / f"{stem}_contract.json").read_text(encoding="utf-8"))
        output = json.loads((fixture_dir / f"{stem}_output.json").read_text(encoding="utf-8"))
        expected = json.loads((fixture_dir / f"{stem}_expected.json").read_text(encoding="utf-8"))
        produced = {item["code"] for item in project_result(contract, output)["errors"]}
        missed = sorted(set(expected["expectedErrorCodes"]) - produced)
        forbidden = sorted(set(expected.get("forbiddenErrorCodes", [])) & produced)
        if missed or forbidden:
            fixture_failures.append({"fixture": stem, "missed": missed, "forbidden": forbidden})
    record("regression-fixture-coverage", bool(fixture_names) and not fixture_failures, fixtures=fixture_names, failures=fixture_failures)

    # NEXT-protocol agreement (Option C guard)
    sched = (ROOT / "rules/detailed/39_mandatory_next_step_protocol.md").read_text(encoding="utf-8")
    compiler = (ROOT / "rules/detailed/36_runtime_activation_compiler.md").read_text(encoding="utf-8")
    router = (ROOT / "rules/detailed/00a_router.md").read_text(encoding="utf-8")
    agreement = {
        "39 still claims to be archived": "non-authoritative" in sched,
        "39 missing its authority statement": "**Authority.**" not in sched,
        "36 no longer requires a STEP QUEUE": "no STEP QUEUE exists" not in compiler,
        "36 no longer names 39 as scheduler": "`39` schedules them" not in compiler,
        "router no longer makes 39 mandatory": "39_mandatory_next_step_protocol.md" not in router,
        "39 lost the sibling-batching rule": "Sibling batching is the default" not in sched,
        "39 still splits model sheets per asset": "model sheets may be one step per complex asset" in sched,
    }
    bad_agreement = [name for name, broken in agreement.items() if broken]
    record("next-protocol-authority-agreement", not bad_agreement, failures=bad_agreement)

    # snapshot agreement
    import re
    SNAPSHOT_DATE_RX = re.compile(r"20\d{2}-\d{2}-\d{2}")
    canonical_snapshot = json.loads((ROOT / "release/RELEASE.json").read_text(encoding="utf-8"))["officialGuideSnapshot"]
    snapshot_sites = {
        "release/RELEASE.json officialGuideSnapshot": canonical_snapshot,
        "dev/MANIFEST.json officialGuideSnapshot": json.loads((ROOT / "dev/MANIFEST.json").read_text(encoding="utf-8"))["officialGuideSnapshot"],
        "templates/PROJECT_CONTRACT.json guideAlignment.snapshotDate": json.loads((ROOT / "templates/PROJECT_CONTRACT.json").read_text(encoding="utf-8"))["guideAlignment"]["snapshotDate"],
        "templates/PROJECT_CONTRACT_PORTABLE.json guideAlignment.snapshotDate": json.loads((ROOT / "templates/PROJECT_CONTRACT_PORTABLE.json").read_text(encoding="utf-8"))["guideAlignment"]["snapshotDate"],
    }
    snapshot_drift = {site: found for site, found in snapshot_sites.items() if found is not None and found != canonical_snapshot}
    record("official-guide-snapshot-agreement", not snapshot_drift, failures=snapshot_drift)

    # v8-specific: version-label sweep over the same dirs as the state validator
    # (already inside validate_state_serialization; re-asserted here as a row)
    # canary integrity
    canary = json.loads((ROOT / "test/canary/stale_version_template.json").read_text(encoding="utf-8"))
    record("v8-canary-integrity", canary.get("schemaVersion") == "7.4.0", found=canary.get("schemaVersion"))

    # mcp tier map agreement (already inside signal_authority; row form)
    import mcp_tool_engines as eng
    import signal_authority as sa
    record("v8-tier-map-agreement", eng.TIER == sa.TIER_MAP, tiers=eng.TIER)

    # distributions classify: every file matches a rule (fail-closed check)
    sys.path.insert(0, str(ROOT / "dev"))
    import build_distributions as bd
    unclassified = []
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT).as_posix()
        if any(part in bd.SELF_EXCLUDE for part in p.parts) or rel in bd.CUMULATIVE_ONLY:
            continue
        dists = bd.classify(rel)
        if not dists:
            unclassified.append(rel)
    record("v8-distributions-classify", not unclassified, unclassified=unclassified[:50], unclassifiedCount=len(unclassified))

    out = {
        "suite": "V8.0.1-RELEASE-8",
        "pass": all(item["pass"] for item in checks),
        "checks": checks,
        "proofBoundary": "Structural and deterministic checks only; media and human evidence remain NOT_RUN.",
    }
    (ROOT / "dev/V8_0_0_SUITE_RESULTS.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(out, indent=2, ensure_ascii=False))
    raise SystemExit(0 if out["pass"] else 1)


if __name__ == "__main__":
    main()
