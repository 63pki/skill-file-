#!/usr/bin/env python3
"""v8.6 encoding lint — bans the platform-default read that silently misses everything.

`read_text()` with no `encoding=` decodes with the SYSTEM default. On Windows that is cp1252; a
UTF-16 file (what PowerShell's `>` writes) then decodes into null-interleaved text and EVERY
pattern in the file misses. The security scanner had 18 such call sites, and a file that decodes
wrongly is not "unscanned" — it is *scanned and empty*, which is worse.

This lint FAILS on any validator that reintroduces the loose form, so the fix cannot silently
regress. Run with the suite.
"""
import io
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VALIDATORS = sorted((ROOT / "validators").glob("*.py")) + sorted((ROOT / "bootstrap").glob("*.py"))

# read_text() / read_text(  with no encoding= argument. Tolerates a trailing comment and
# multi-line calls is NOT attempted — a lint that cannot fail is decoration.
LOOSE_RX = re.compile(r"\.read_text\(\s*\)")
ENCODED_RX = re.compile(r"\.read_text\(\s*encoding\s*=")

violations, encoded, checked = [], 0, 0
for p in VALIDATORS:
    src = p.read_text(encoding="utf-8")
    total = len(re.findall(r"\.read_text\(", src))
    loose = LOOSE_RX.findall(src)
    enc = len(ENCODED_RX.findall(src))
    checked += total
    encoded += enc
    if loose:
        violations.append((p.name, len(loose)))

# prove the lint itself can fire: a synthetic bad file must be caught
synthetic = ROOT / "tests/.lint_probe.py"
synthetic.write_text("x = open('a').read_text()\n", encoding="utf-8")
try:
    probe_src = synthetic.read_text(encoding="utf-8")
    probe_fires = bool(LOOSE_RX.findall(probe_src))
finally:
    synthetic.unlink()

print("encoding lint:")
print(f"  files scanned      : {len(VALIDATORS)}")
print(f"  read_text() calls  : {checked}")
print(f"  with encoding=     : {encoded}")
print(f"  LOOSE (platform default): {len(violations)} file(s)")

ok = True
if violations:
    print("  FAILING FILES:")
    for name, n in violations:
        print(f"     {name}: {n} loose read_text() call(s) - fix with strict_io.read_bytes_strict() "
              f"or add encoding='utf-8'")
    ok = False
if not probe_fires:
    print("  SELF-TEST FAILED: the lint did not match a known-bad synthetic file - it cannot fire")
    ok = False
else:
    print("  self-test: the lint matches a known-bad synthetic file (proven able to fire)")

print(f"\nENCODING_LINT: {'PASS' if ok else 'FAIL'}")
sys.exit(0 if ok else 1)