#!/usr/bin/env python3
"""Negative controls + positive control for validators/strict_io.py — run with the suite.

Pair protocol: the GOOD twin must be accepted, and the BAD twin rejected FOR THE RIGHT REASON.
A control that has never fired proves nothing, so each is exercised explicitly.
"""
import io
import json
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "validators"))
from strict_io import StrictInputError, read_bytes_strict, strict_loads  # noqa: E402

results = []


def case(label, fn, should_raise, must_contain=None):
    try:
        fn()
        raised, msg = False, ""
    except StrictInputError as e:
        raised, msg = True, str(e)
    except Exception as e:  # wrong exception type = wrong reason
        raised, msg = True, f"WRONG EXCEPTION {type(e).__name__}: {e}"
    ok = raised == should_raise and (not should_raise or (must_contain and must_contain in msg))
    results.append((label, ok, msg[:110]))
    print(f"  [{'OK  ' if ok else 'FAIL'}] {label}"
          + (f" -> {msg[:90]}" if raised else ""))


print("strict_io controls:")

# POSITIVE twin: valid JSON, UTF-8, no duplicates
case("positive: valid JSON accepted",
     lambda: strict_loads('{"a": 1, "b": [1,2]}'), False)

# BAD twins, each with a reason we assert on
case("duplicate key rejected for the right reason",
     lambda: strict_loads('{"a": 1, "a": 2}'), True, "duplicate JSON key")
case("NaN rejected for the right reason",
     lambda: strict_loads('{"x": NaN}'), True, "non-finite")
case("Infinity rejected",
     lambda: strict_loads('{"x": Infinity}'), True, "non-finite")
case("malformed JSON rejected",
     lambda: strict_loads('{"a": '), True, "invalid JSON")

tmp = ROOT / "tests/.strict_io_tmp"
tmp.mkdir(parents=True, exist_ok=True)
try:
    (tmp / "utf16.json").write_bytes('{"a":1}'.encode("utf-16"))
    case("UTF-16 (BOM) rejected, not silently mis-decoded",
         lambda: read_bytes_strict(tmp / "utf16.json"), True, "UTF-16")
    (tmp / "bom.json").write_bytes(b"\xef\xbb\xbf" + b'{"a":1}')
    case("UTF-8 BOM rejected",
         lambda: read_bytes_strict(tmp / "bom.json"), True, "BOM")
    (tmp / "binary.bin").write_bytes(b"\x00\x01\x02" * 500)
    case("binary/null-byte file rejected, not matched as text",
         lambda: read_bytes_strict(tmp / "binary.bin"), True, "null bytes")
    (tmp / "ok.json").write_bytes(b'{"a":1}')
    case("positive: plain UTF-8 file accepted",
         lambda: read_bytes_strict(tmp / "ok.json"), False)
finally:
    for f in tmp.glob("*"):
        f.unlink()
    tmp.rmdir()

failed = [r for r in results if not r[1]]
print(f"\nstrict_io: {len(results)-len(failed)}/{len(results)} controls passed")
sys.exit(1 if failed else 0)