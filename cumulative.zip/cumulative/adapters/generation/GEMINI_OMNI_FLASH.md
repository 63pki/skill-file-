# Gemini Omni Flash Video Prompt Adapter

**Owner:** `GEMINI_OMNI_FLASH`  
**Model identifier snapshot:** `gemini-omni-flash-preview`  
**Official snapshot:** 2026-07-21  
**Boundary:** prompt authoring only; preview capabilities require surface verification

## Task families

- `OM-F1 TEXT_TO_VIDEO`
- `OM-F2 IMAGE_TO_VIDEO`
- `OM-F3 REFERENCE_TO_VIDEO`
- `OM-F4 CONVERSATIONAL_EDIT`
- `OM-F5 EXISTING_VIDEO_EDIT`

## Required block

```text
AVD:OMNI_PROMPT id=... task=OM-F1|OM-F2|OM-F3|OM-F4|OM-F5
Task parameter:
Inputs and roles:
Subject:
Action:
Scene/context:
Camera:
Lens/focus:
Style, lighting and ambiance:
Temporal direction:
Audio:
Continuity invariants:
End condition:
Output assumption:
Acceptance:
First one-variable repair:
```

For one shot say `single continuous shot`, `single unbroken scene`, and `no scene cuts`. For a conversational edit, keep the instruction short and end with `Keep everything else the same.` Timing may use natural language or `[0-3s]` notation. Do not request extension, first/last interpolation, uploaded-audio reference use, voice editing, multiple-video reasoning, or a dedicated negative-prompt parameter.

## MCP Contract Binding + Hard-Fact Bindings (v8.0.0)

All Omni Flash video envelopes flow through the `avd_r6_generation_execute` tool contract (`mcp/tools/avd_r6_generation_execute.json`): ISSUE mints the copy-paste prompt envelope above; COLLECT registers `{uri, sha256}`; VERIFY runs the deterministic frame-consistency check against the R4 lock. The server is a PROMPT-ONLY controller — it never invokes a generation backend.

Hard facts are resolved at issue time from `mcp/resources/HARD_FACTS.json` by id, never inlined into prompts or contracts (Rule 03):

- **HF-VIDEO-NATIVE-CEILING** — output above the native ceiling is an upscaled platform-neutral finishing handoff, flagged at R0/R1; otherwise the tool refuses with AVD-E-4001.
- **HF-EDIT-CHAIN-MAX** — the conversational-edit chain per clip lineage is capped; exceeding it raises AVD-E-4002 and requires re-generation from the lineage root.
- **HF-REPAIR-BUDGET** — repairs are one-variable diffs (schema-enforced `maxProperties: 1`) with a reserved final slot requiring countersigned authorization; violations raise AVD-E-4003/4004.
