# Nano Banana Pro → Gemini Omni Flash Pipeline

1. Define story/product/message/composite intent and evidence ceiling.
2. Build immutable asset IDs and reference roles.
3. Generate Nano Banana Pro prompt libraries for anchors, assets, keyframes, edit variants, or critical text mockups.
4. Operator generates and inspects media externally; uninspected references cannot be called approved.
5. Route an approved image as starting image or reference to Omni Flash.
6. Compile one feasible motion beat with camera, environment, audio, end condition, acceptance, and repair.
7. Operator generates externally and records version-bound evidence.
8. Repair conversationally with one changed variable and `Keep everything else the same.`
9. Hand off approved clips through platform-neutral post specifications.

This pipeline never implies direct generation. It does not use unsupported extension or first/last interpolation.

## Gate-to-Tool Map (v8.0.0)

| Gate | Tool contract | Ops | Artifacts / receipts |
|---|---|---|---|
| R2 | `avd_r2_originality_verify` | ISSUE / COLLECT / VERIFY | originality worksheets; `mcp/worksheets/R2_ORIGINALITY.md` |
| R3 | `avd_r3_causality_check` | VERIFY | logic-map orphan-effect report |
| R4 | `avd_r4_model_sheet_lock` | ISSUE_ANCHOR / COLLECT / LOCK / DRIFT_CHECK | asset-anchor manifest + drift report |
| R5 | `avd_r5_timing_validate` | VERIFY | VO-beat vs EDL span report |
| R6 | `avd_r6_generation_execute` | ISSUE / COLLECT / VERIFY | Omni Flash envelope; collected `{uri, sha256}`; frame-consistency proof |
| R7 | `avd_r7_edit_assembly_verify` | VERIFY | timeline/assembly check |
| all gates | `validate_gate_evidence` | VERIFY | gate receipt with `tool_calls[]` citations |
| discovery | `avd_list_capabilities` | LIST | execution mode + routing source hash |
| approvals | `avd_request_approval` | MINT / COUNTERSIGN | approval marker files |

Under PORTABLE_REFERENCE the same worksheets run by hand with honest MANUAL/PORTABLE_REFERENCE labels, capped at PLAN-PASS — the gate-to-tool map degrades, it never disappears (CONSTANT_SURFACE_VARIABLE_MODE).
