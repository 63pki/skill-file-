# 33B — Scene Conception and the Shot Card

**Owner: conception.** This is what happens between *brief understood* and *prompt written* — the
phase a creative director does and a slot template cannot.

> **Credits and provenance.** The shot card's structure (locked fields, stakes-scaling, kill list,
> per-field "default rejected" column) follows an independently-authored anti-slop design skill,
> **MIT © 2026 Leonxlnx, `github.com/Leonxlnx/taste-skill`** — used as a design reference under
> its licence, with attribution travelling with anything mined. Its brief-inference layer
> independently reproduced this same architecture (goal → one-line read → one clarifying question
> → anti-defaults), which is recorded as **external validation** of the design, not as evidence of
> our output quality.

## When the shot card is required

| Work | Card? |
|---|---|
| A single throwaway exploration prompt | **No** — `SKETCH` in one line |
| Any real deliverable | **Yes**, `STANDARD` |
| Multi-shot, multi-platform, or someone will defend the decisions | **Yes**, `CAMPAIGN` |

The card does not scale with ambition for its own sake — it scales with **how expensive a wrong
direction is**.

## The three descents

1. **GOAL** — purpose, viewer, place, success. Stop when one sentence survives. Split every element
   into **FACT** (window, hour, material, approved reference — recorded, not re-derived) and
   **LATITUDE** (framing, palette, pacing, exclusion — where craft lives).
2. **MOMENT** — what is happening, what just happened, what is unresolved, why this frame and not
   the last one. **This is the step the rest of the tree was silent on**, and the step that supplies
   causality, asymmetry and narrative pressure a slot template cannot.
3. **ELEMENTS** — every row a decision with a reason *and the default it rejects*.

## The order that cannot be reordered

**idea → design → look.** The look library is a **finish**, consulted last. A family chosen before
the idea imports that family's genericness into work that had none.

**Facts carry the image, not vocabulary.** A model renders photographs, not lighting rigs. "Window
at four in the afternoon, low sun, hard falloff" does more than "negative fill". Every craft term
must pair with its visible effect or be cut.

## The honesty boundary — non-negotiable

- The card produces **intent**, never **proof**. It is not validated by any gate.
- **It is never scored.** No points, no percentage, no "conception quality". Anything measurable
  becomes something to game, and the tree's X14 discipline forbids it.
- Its honest limit: **fewer retries because more was decided is a hypothesis, measured** — by the
  pilot's `repairCycles` field — **not an assumption.**
- It adds a step, therefore time. That trade is a claim to be measured, not a fact.

## Wiring

| Connects to | How |
|---|---|
| `24` client-translation table | feeds Descent 1 (`premium`, `more energy` become decisions here) |
| `01` look library | selected at the END, per element row |
| `32` taste ladder | the element rows mirror the ladder's order |
| `17` repair | Loop A (**fix what's broken**) — never a creative change |
| `32` §4 | Loop B (**make it better**) — the creative sibling |
| taste references | `tasteBasis` field, ids only, operator's words verbatim |
| `STYLE_TRANSLATION.json` | named-artist input is translated here, never into the prompt |

## Hard boundaries

- **No named artist, franchise or protected work reaches the prompt.** Named references are legal
  *input* (`21`); descriptive craft language is the *output*.
- **Never claim the output was inspected when it was not.** The card is pre-generation by
  definition.
- **A reference image is never evidence** of anything except what the operator said about it.
- **`tasteBasis: LADDER_ONLY`** is a valid, non-blocking state — but it must be stated, so a taste
  claim is never implied that was not applied.