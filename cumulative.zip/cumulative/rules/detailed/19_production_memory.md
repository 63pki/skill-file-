# 19 Production Tracker, Continuity Memory, and Handoff

## One naming convention

```text
[project]_[sequence-or-chapter]_[shot-or-asset]_[stage]_[version]_[status].[ext]
```

Example: `launch_CH01_S03_video_v02_approved.mp4`.

Stages: brief, board, still, video, vo, sfx, music, edit, delivery. Never use competing `final_final` conventions.

## Asset tracker

```text
Asset ID | story function | mode | refs/tokens | stage | version/change |
evidence verdict | rights status | cost/attempts | owner | next action
```

## Project memory

```text
Project / deliverable / platform:
Approved brief and concept:
Active global tokens:
Active project tokens:
Approved references:
Storyboard version:
Approved assets:
Rejected attempts + reason:
Capability evidence IDs:
Rights/claims status:
Open issues / next controlled test:
```

## Long-form chapter checkpoint

```text
Chapter ID | purpose | first/last asset | identity/style drift | factual/source issues |
VO status | edit status | verdict | next chapter dependency
```

## Session handoff

Return this at the end of multi-session work:

```text
SESSION HANDOFF
Project:
Last approved stage / asset ID:
Brief + board version:
Active tokens and references:
Completed:
Rejected / do not repeat:
Open blockers:
Next exact action:
Files/context to paste at next session:
```

The skill has no guaranteed cross-session memory. Continuity depends on this record being preserved and supplied again.

## Gate receipt memory

For Production Sequences and Campaign/Long Projects, preserve the latest `35` gate receipt with the project state. Store which downstream assets were frozen by a failed gate and invalidate them explicitly after an upstream revision. Do not keep stale prompts “approved” after their concept, story, asset, timing, or delivery dependency changed.

## Filename compiler check

Before delivery, parse the filename into all six required fields: project, sequence/chapter, shot/asset, stage, version, status. A name such as `Project_MASTER_v1` fails because fields are missing. Example:

```text
milo-shadow_CH00_MASTER_delivery_v01_review.mp4
```

### Record the name that is actually on disk (v8.0.4)

Evidence records bind media by exact filename and SHA-256. Record the name **as it exists on
disk**, byte for byte — do not tidy it, expand it, or replace an abbreviation with what it was
probably meant to be.

Some generator download paths write a **truncated name containing a literal ellipsis character**
(`…`, U+2026) into the middle of the filename. Observed in campaign CAMPAIGN-T1-2026-09-13: a
video saved as `Ceramic_espresso_cup_static_pres…_20260916184815.mp4`. The ellipsis is part of
the real filename, so a record that reproduces the same string matches the hash, and a record
that "repairs" the name does not.

Two rules follow:
- the recorded name must equal the on-disk name exactly, ellipsis included — the hash binding is
  what proves it, and a silently expanded name breaks the binding with no visible error;
- if the truncation is itself the defect, say so in the evidence note rather than in the
  filename. A name that looks wrong and hashes correctly is a recorded fact; a name that looks
  right and hashes nothing is a broken record.

## Cross-model switch packet

```text
MODEL-SWITCH HANDOFF
Project/version:
Execution profile (new runtime resets to CONTROLLED):
Approved brief/mode:
Current STEP QUEUE and one ACTIVE/next READY step:
Locked Style/Brand Bible:
Active asset schemas and approved references:
Approved board/timing:
Latest gate and compiler receipts:
Rejected decisions — do not restore:
Verified specs / assumptions:
Open blockers:
Next authorized artifact only:
```

A new model may not infer completion from prose history or self-promote to FULL.

## v8.0.0 reset-exempt state (carry-forward invariants)

The CONTROLLED reset on model switch resets the EXECUTION PROFILE only. The following state classes are reset-exempt and MUST survive every session break and model switch, because they are facts about stakeholders, content hashes, and verified version lineage — not about the executing model:

- `approvalState` — stakeholder approvals bound to `(gate, artifact sha256[])`; they are never re-asked for unchanged bytes and never invalidated by the reset (see `35` §7.4 and `release/APPROVAL_ROLE_REGISTRY.json`).
- `versionMeta` — the artifact version lineage (line-2 `schemaVersion` + line-3 versionMeta).
- `dagState` — the gate-DAG execution state (`dag_state` per `schemas/artifacts/HANDOFF_PACKET.schema.json`): active/completed/pending nodes, feedback counters, parallel-group states.
- `assetLedger` — asset digests recorded at handoff time.
- `evidenceChain` — evidence references accumulated for the project.

A handoff packet that drops any declared reset-exempt class is INVALID. Serialization follows `schemas/artifacts/HANDOFF_PACKET.schema.json` (`resetExempt` array + matching blocks). The video attempt ledger is the one deliberate exception: it is always RECOMPUTED at switch time from the attempt ledger (see `schemas/artifacts/MODEL_SWITCH_PACKET.schema.json`), never copied from the outgoing model's records.
