# Creative-Depth Library Index

## Coverage disclosure (v8.6 — read this before assuming a domain is covered)

**What is domain-agnostic and genuinely supported for every brief:** planning structure, contracts
and gates, claim and media honesty, rights intake and declarations, revision mechanics, delivery
and handoff. These do not care what the visual is.

**What is craft vocabulary, and therefore uneven:** the look families, examples, and niche tables
below were built for **photographic and product-shaped work** — advertising, product, editorial
photography, short-form video. They are the strongest part of this tree.

**Named gaps, stated rather than implied:**

| Domain | Status |
|---|---|
| Music video | **No craft library.** Planning, gates and honesty still apply. |
| Editorial illustration | **No craft library.** Photographic vocabulary will not transfer cleanly. |
| Fashion campaign | Partial — a look family exists; no campaign craft. |
| Architectural visualisation | **No craft library.** (`ARCHITECTURAL_CONTECTIVITY` governs consistency across a set, not how to produce one.) |

**Naming a gap is the honest move.** A thin library that implies coverage teaches a reader to
trust a vocabulary that does not exist. If you work in one of these domains, say so, and work
from the scene facts instead of a family name.

## Loading (changed in v8.6)

Three of these are no longer optional — they load automatically because a reader cannot ask for
vocabulary they have never seen: `01_cinematic_look_library.md` (every visual direction decision),
`03_stack_prompt_cookbook.md` (any stack-specific prompt), and `32`'s reference-selection method
(whenever a reference is cited). **The look library is a finish, consulted last** — idea, then
design, then look.

The rest load only when deeper examples or vocabulary are genuinely needed.

| Need | File |
|---|---|
| Named cinematic look vocabulary — **auto-loads** | `01_cinematic_look_library.md` |
| Animation/style-family vocabulary | `02_animation_style_families.md` |
| Stack-specific prompt patterns — **auto-loads** | `03_stack_prompt_cookbook.md` |
| Product, UGC, food, fashion, real-estate examples | `04_examples_ads_and_products.md` |
| Film, animation, motion-graphics, hybrid examples | `05_examples_story_and_design.md` |
| Faceless and long-form examples | `06_examples_faceless_longform.md` |
| Niche-specific visual vocabulary | `07_niche_visual_vocabulary.md` |
| Hook starters and construction patterns | `08_hook_pattern_library.md` |

## Precedence

Core owners in `../00a_router.md` outrank every file listed here. Examples may illustrate a rule
but never establish a capability, safety decision, delivery specification, or canonical workflow.

## Honesty

- Examples are hypothetical production plans — **not generated results**.
- Look tokens are creative starting points — **not guaranteed model behaviour**.
- No fixed model IDs, prices, caps, or delivery specifications live here.
- Avoid copying protected campaigns, characters, living artists, or branded styles.
  **v8.6 note:** an operator may still *name* any style reference as input (including a named
  artist) and have it recorded — it is translated to descriptive craft language before it reaches
  the prompt (`STYLE_TRANSLATION.json`). What is prohibited is the imitation, not the conversation.
