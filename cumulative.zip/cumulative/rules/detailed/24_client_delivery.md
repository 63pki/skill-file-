# 24 Client Production Brief, Revisions, and Handoff

This file stays on visual-production scope. It does not provide monetization ladders, income claims, or career coaching.

## Client production brief

```text
Project / version / approver:
Business or story goal:
Audience and desired action:
Deliverables, lengths, platforms, ratios:
Mode, look references, anti-references:
Mandatories and post-only brand assets:
Claims/rights/consent status:
Deadline and approval gates:
Budget/stop-loss:
Revision rounds and usage scope:
```

Translate vague feedback into production variables:

- “premium” → restraint, material truth, spacing, light, pace, typography;
- “more energy” → cut rhythm, action amplitude, camera, music, performance;
- “on brand” → exact palette/type/logo/claim/voice deviations.

## Revision log

```text
Round | requested change | category | strategic/safety impact | exact variable |
approved by | resulting asset version
```

## Delivery pack

```text
approved masters | platform variants | captions/transcript | audio stems if required |
thumbnail/cover | prompt/board documentation if contracted | rights/source notes |
version log | known limitations | archive/handoff record
```

Use the single naming convention in `19`.

## v8.0.0 Multi-stakeholder approval (additive)

Single-approver delivery stays valid for solo projects. When the project declares multiple stakeholders, the approval overlay applies:

- **Registry.** Roles, scopes, evidence requirements, and typed veto classes live in `release/APPROVAL_ROLE_REGISTRY.json`. Every approval entry binds to `(gate, artifact sha256[])` — not to a session, a model, or a conversation. Unchanged bytes never need re-approval.
- **Typed vetoes.** `ABSOLUTE_LEGAL` > `ABSOLUTE_TECHNICAL_HARDFACT` > `ABSOLUTE_COMMERCIAL_SCOPE` > `OVERRIDABLE_CREATIVE`. Two ABSOLUTE vetoes of any class → BLOCK with no override path; the only exit is a scope change re-entering at R0/R1.
- **Silence never approves.** Every approval lane is DEFAULT-DENY: a stakeholder who does not respond in the agreed window has not approved.
- **Ledger.** Approvals are recorded in the append-only `templates/APPROVAL_LEDGER.json` (hash-chained; the head hash is the `ledgerRef` in the gate receipt). Reversals are new entries, never edits. The ledger is reset-exempt across model switches (`19`).
- **Version honesty.** A delivered artifact whose declared version differs from its structurally inferred version is a hard failure (see `templates/MIGRATION_REGISTRY.json` detection ladder) — the 7.4.0-defect class can never ship again.
