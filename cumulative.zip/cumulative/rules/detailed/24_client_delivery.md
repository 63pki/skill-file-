# 24 Client Production Brief, Revisions, and Handoff

This file stays on visual-production scope. It does not provide monetization ladders, income claims, or career coaching.

## Client production brief

```text
Project / version / approver:
Business or story goal:
Audience and desired action:
Deliverables, lengths, platforms, ratios:
Mode, look references, anti-references:
Mandatories and post-only brand assets:
Claims/rights/consent status:
Deadline and approval gates:
Budget/stop-loss:
Revision rounds and usage scope:
```

Translate vague feedback into production variables:

- “premium” → restraint, material truth, spacing, light, pace, typography;
- “more energy” → cut rhythm, action amplitude, camera, music, performance;
- “on brand” → exact palette/type/logo/claim/voice deviations.

## The extended feedback lexicon (v8.6)

**Four phrases cover most real client feedback. Each has more than one defensible reading, and
picking the wrong one silently is the expensive mistake** — it costs a round and teaches the client
that feedback does not work here.

| Client says | Most likely intent | FIRST move | Alternate reading |
|---|---|---|---|
| **“make it pop”** | the subject is not separated from its ground | **hero/background separation first** — separation, then colour, then polish | it is *too* loud → reduce, not increase |
| **“more premium”** | the frame is busy and shiny | **fewer props, more space, truer blacks** | it is the *material* that is unconvincing → surface truth, not staging |
| **“it feels cold”** | the light has no human source | **warm practical + one human trace** (a worn edge, a hand, a lived-in surface) | the *palette* is cool → warm the separation, not the whole frame |
| **“I don't love it”** | undecided, not defective | **one forced-choice question — never regenerate blind** | a specific defect they have not named → ask, do not guess |

**Two more, same shape:**

- **“it feels like AI”** → the tell inventory, not a filter. Name the specific tell; a decision
  replaces it. Adding film grain to an undecided frame makes it *more* convincing, not less.
- **“more energy”** → **cut rhythm and action amplitude first.** Energy is usually pacing; the
  commonest misreading is to raise contrast and get a louder version of the same frame.

### THE ONE-QUESTION RULE

When a phrase has more than one defensible reading, **ask exactly one question and do not guess.**

- **One** question. Never a multi-question dump — three questions get three partial answers and
  no decision.
- **Ask only when the readings diverge in effect.** If both readings lead to the same move, make
  the move and state which reading you took.
- **Make it a forced choice**, not an open question. Open questions get "whatever you think".
  *"Less shine, or more space?"* gets an answer; *"any thoughts?"* gets a shrug.
- **Never regenerate blind.** Re-shooting on an ambiguous phrase spends a round and returns the
  same disagreement.

```text
CLIENT SAID:      "more premium"
READINGS:          1. fewer props, more space      → variable: prop count down, margin up
                   2. truer blacks                  → variable: shadow floor down
                   3. material truth                → variable: surface detail up, gloss down
DISAMBIGUATED BY:  one question — "less shine, or more space?"
CHOSEN:            _
EXACT VARIABLE:    _            (ONE — never two at once)
ACCEPT IF:         _
ROUND:             n of cap
```

**Record the reading you took, not just the change.** Six rounds later the log is the only record
of why the work looks the way it does.

## Revision log

```text
Round | requested change | category | strategic/safety impact | exact variable |
approved by | resulting asset version
```

## Delivery pack

```text
approved masters | platform variants | captions/transcript | audio stems if required |
thumbnail/cover | prompt/board documentation if contracted | rights/source notes |
version log | known limitations | archive/handoff record
```

Use the single naming convention in `19`.

## v8.0.0 Multi-stakeholder approval (additive)

Single-approver delivery stays valid for solo projects. When the project declares multiple stakeholders, the approval overlay applies:

- **Registry.** Roles, scopes, evidence requirements, and typed veto classes live in `release/APPROVAL_ROLE_REGISTRY.json`. Every approval entry binds to `(gate, artifact sha256[])` — not to a session, a model, or a conversation. Unchanged bytes never need re-approval.
- **Typed vetoes.** `ABSOLUTE_LEGAL` > `ABSOLUTE_TECHNICAL_HARDFACT` > `ABSOLUTE_COMMERCIAL_SCOPE` > `OVERRIDABLE_CREATIVE`. Two ABSOLUTE vetoes of any class → BLOCK with no override path; the only exit is a scope change re-entering at R0/R1.
- **Silence never approves.** Every approval lane is DEFAULT-DENY: a stakeholder who does not respond in the agreed window has not approved.
- **Ledger.** Approvals are recorded in the append-only `templates/APPROVAL_LEDGER.json` (hash-chained; the head hash is the `ledgerRef` in the gate receipt). Reversals are new entries, never edits. The ledger is reset-exempt across model switches (`19`).
- **Version honesty.** A delivered artifact whose declared version differs from its structurally inferred version is a hard failure (see `templates/MIGRATION_REGISTRY.json` detection ladder) — the 7.4.0-defect class can never ship again.
