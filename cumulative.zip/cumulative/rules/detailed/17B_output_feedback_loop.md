# 17B — Output Feedback Loop (v8.6)

**Bring the output back. Run the acceptance tests. Change only what failed.**

> **Why this exists.** Everything else in this tree is pre-generation. Without a loop that accepts
> a returned output, "few retries" is a claim about luck. The operator pastes the output in; this
> rule turns observation into a **surgical** change — one locked variable, with a stated reason.

## The contract

**Input:** an attached output, or the operator's own description of one. **Never** a file the
skill has not actually been given — the skill is prompt-only and inspects nothing itself.

**Output:** exactly one of
- **CHANGED** — one variable changed, with the acceptance test that failed and the reason
- **NOT_APPLICABLE** — nothing here fails an acceptance test; the disagreement is a taste call, and
  taste calls route to `24`'s translation table or the operator, **not** to a regeneration
- **BLOCKED** — the output cannot be judged because a reference, lock, or fact is missing

**Never output "looks better now".** That sentence is unverifiable and this tree does not emit it.

## The four acceptance tests

Run these on the **output**, in this order. The first failure is the one you fix.

| Test | Question | Fails when |
|---|---|---|
| **SQUINT** | does it hold in greyscale? | the frame only works because of its colour |
| **SOURCE** | can I name the light source and why? | the light is unmotivated or inconsistent |
| **ANYWHERE** | does this belong to this brand/place? | it reads generically; swapped branding still works |
| **BEFORE/AFTER** | is the difference attributable to ONE named decision? | two things changed and neither can be attributed |

Plus the **targeted** tests from the shot card: exact copy present, geometry unaltered, safe areas
respected, no unapproved text or logo.

## The change card

```text
OUTPUT RECEIVED:   asset id, and HOW it was supplied (attached / described — never inspected by us)
ACCEPTANCE FAILED: which of the four, and the specific evidence
LOOP:              A fix what's broken  |  B make it better
ONE VARIABLE:      the single thing changed
REASON:            in image terms — a fact about the frame, not an adjective
ACCEPT IF:         the observable condition that closes this
REVERT IF:         it does not
```

## Repair outcome — the part that compounds (v8.5 → v8.6)

**Every repair records its outcome.** This is the single change that makes the tree learn instead
of merely check:

```text
OUTCOME:  WORKED | PARTIAL | FAILED | SUPERSEDED
EVIDENCE: hash of the output, or the operator's report
```

**Three rules, inherited unchanged from the delight loop:**
- **Promotion is always human.** A machine never promotes a repair recipe.
- **No rate, no score, no percentage — ever.** `repairConfidence` is an **n-of-m count**, never a
  percentage, and never a quality claim about the image.
- **`DELIGHT` never gates anything**, and neither does `repairConfidence`.

**Outcomes feed three consumers** — and the loop never writes to them directly:
1. `GENERATOR_DEFECT_TAXONOMY` — `repairConfidence` beside each class's `repairRecipe` (the
   recipe is the hypothesis; the count is what actually happened)
2. the co-pilot's move ranking — repairs that worked move their variable upward
3. this loop — a recipe with `n` outcomes is preferred over one with none

**A `FAILED` outcome is worth more than a `WORKED` one.** It is the only thing that stops the tree
repeating a repair that never worked.

## Hard boundaries

- **Never claim to have inspected, watched, or heard the media.** The operator supplies it; the
  skill reasons about what is described or attached.
- **Never regenerate on an ambiguous phrase** — `24`'s one-question rule applies here too.
- **A single output is one sample.** One `WORKED` is not evidence of a good recipe.
- **Missing input is `BLOCKED`, not `CHANGED`.** A guess dressed as a repair is the failure this
  whole tree is built to prevent.