# Mode C — Motion Graphics Owner

**This is how to think about a motion-graphics brief, not a checklist.**

## The question this mode exists to answer

**What is the one message, and what must a reader be able to read while moving?** Mode C fails on
two sides at once: unreadable motion, and readable text that was never verified.

## The decision to make first

**Message hierarchy before any layout.** Decide the one thing a viewer must retain after 5 seconds.
Everything else is subordinate, and subordinate elements that compete are defects.

**Then the exact-copy register.** Which strings are *exact* (logos, legal text, prices, data,
product names) and which are generated? Exact copy requires an editable handoff (`34`) — generated
text may only be used after inspection. This single distinction is the mode's whole risk surface.

## The defaults to reject

| Default | Why it is wrong here |
|---|---|
| Decorative motion everywhere | Motion that moves for its own sake competes with reading; every animation must earn its time |
| Generated text as final copy | Generated glyphs are never trustworthy; critical text gets an editable layer |
| One easing curve applied to everything | Easing is grammar — the same curve on every element reads as a machine |
| Motion that outruns the reading time | If a viewer cannot finish a line before it leaves, the message is lost |
| A grid that exists only on paper | Grid and tokens must be *used*; an unused grid is decoration |
| Data visualised for visual effect | Invented or dramatised data is a blocked claim |

## Lock before prompt

- Message hierarchy, reading order, and the timed board.
- Exact-copy register with owner and handoff path for each string.
- Grid, tokens, and style frames.
- Motion grammar: which elements move, on what easing, with what hold.
- **Reduced-motion variant** — planned, not retrofitted.
- Audio/caption handoff (`AUDIO_CAPTION_HANDOFF`).

## Hard blocks

Decorative motion that harms reading · **invented data** · clipped or unreadable text · unsafe
flashes · inconsistent easing · insufficient holds · critical text without an editable handoff ·
any claim that generated output was inspected when it was not.

## Repair order

**Readability before polish.** A frame that cannot be read is not improved by easing. Fix hierarchy
and timing first, then look at it again.

**Out of scope here:** photographic material (Mode A) and character performance (Mode B).