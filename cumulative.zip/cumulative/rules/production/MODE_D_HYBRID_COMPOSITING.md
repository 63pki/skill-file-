# Mode D — Hybrid Compositing Owner

**This is how to think about a compositing brief, not a checklist.**

## The question this mode exists to answer

**Which layer is real, and which layer may be invented?** A composite fails when a generated
element arrives with its own camera, its own light, and its own physics. Mode D's job is to keep
one layer authoritative so the other can be judged against it.

## The decision to make first

**Declare the authoritative layer before generating anything.** If real footage is authoritative,
it owns camera, perspective, lens character, light direction and grain — the generated element is
built to match it. **Never regenerate the scene to fit a generated element.** State this in one
sentence and put it in the receipt.

**Then the clean-plate plan.** Capture plates, guides, and reference frames first. A composite
attempted without a clean plate is a retake with extra steps.

## The defaults to reject

| Default | Why it is wrong here |
|---|---|
| A generated element with its own lighting | Two light directions in one frame is the single most obvious composite tell |
| Matching by eye, frame by frame | Perspective mismatches must be caught by the tracking/mask/occlusion map, not by eye |
| Uniform blur on all edges | Real depth of field is per-layer; a uniform blur reads as pasted |
| No grain match | Grain is a layer property; a clean generated element on film footage is instantly obvious |
| Full-scene regeneration to fix one element | Destroys authoritative footage to solve a local problem |
| Claiming alpha where none was verified | Alpha is an inspected fact, never an assumption |

## Lock before prompt

- **Authoritative-layer declaration** (real footage vs generated base).
- Capture and clean-plate plan; reference and guide frames.
- Tracking/mask/occlusion map — which object occludes which, and where contact happens.
- Integration recipe per shot; audio; neutral post handoff.

## The boundary that matters

**Stop at the advanced-compositor boundary.** This mode produces elements, plates and a map. It
does not perform the final composite, and it must not claim a composite was inspected when the
composite happened downstream and unseen.

## Hard blocks

Mismatched camera/perspective · edge, blur, spill, reflection or grain failures · impossible
occlusion · **unsupported alpha claims** · full-scene regeneration when real footage is
authoritative · any claim of having inspected the finished composite.

**Out of scope here:** generating the authoritative layer itself (Modes A/B/C own that).