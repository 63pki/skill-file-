# Mode A — Photoreal and Commercial Owner

**This is how to think about a photoreal brief, not a checklist.** Load it before planning Mode A work.

## The question this mode exists to answer

**What is true, and how will the image not lie about it?** Photoreal work fails commercially in
one direction: the image is beautiful and the product is wrong. Mode A's whole job is making
reality survive the frame.

## The decision to make first

**Hero frame first, shot list never.** One decisive frame, designed element by element — subject,
environment, light logic, palette, camera, props, exclusions — then the supporting shots derive
from it. A shot list written before the hero frame produces twelve competent images instead of
one image plus eleven derivatives.

**Conception order for a Mode A hero:** what must the viewer believe in 2 seconds → where does this
live → **what is the product's one true thing** → what in the scene proves it → what is excluded
and why.

## The defaults to reject (this mode's tells)

| Default | Why it is wrong here |
|---|---|
| Product dead-centre on a seamless sweep | Reads as a catalogue, not a decision; the frame has no place |
| Even frontal fill | Kills the material truth the mode exists to show |
| A pristine surface | New-in-box is a claim the product usually cannot make; one honest imperfection reads as *used and real* |
| Hands holding the product | Hands are the most-failed anatomy in generation; if not required, exclude them |
| Generic lifestyle context | Blurred people and laptops say nothing about *this* brand |
| Angle for its own sake | Three-quarter "hero angle" is the model's habit, not a decision — pick the angle that shows the thing that matters |

**Light does the selling.** Name the source and the reason: a low window from camera-left falling
to deep shadow right reads as material and craft; a soft frontal box reads as a catalogue clip.
Every craft term you use must pair with its visible effect (*"negative fill"* → *"the shadow side
falls to near-black"*).

## Lock before prompt

- Concept promise in one sentence, and the **claim boundary** — what this image may and may not assert.
- Product geometry, labels, proportions and materials **locked**; any unverified attribute is a question, not a guess.
- Identity lock: a named person or product you have approved references for.
- Assets the operator has actually cleared (`RIGHTS_DECLARATION.json` if declared — then do not re-ask).

## Hard blocks

Altered geometry or labels · fake features · anatomy defects · impossible contact or reflections ·
unsupported claims · identity misuse · **any claim of having inspected media** (`24`/`30` govern
the disclosure).

## Before scaling

Test the **hardest** shot first — the material, contact, or identity shot. If that one fails, the
other nine are not worth spending yet. Repair before you add, never after.

**Out of scope here:** motion, layout systems, UI, and anything where a human's face must be
recognisable without approved references. Those are Modes B/C/D and their own locks.