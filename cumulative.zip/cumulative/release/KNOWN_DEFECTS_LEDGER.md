# Known Defects Ledger (ships with the distributions)

**Why this file exists (8.0.2, minor-(c)):** the V8_0_0 baseline pin's
`pinningNotes.policy` points readers at `V8_SELF_AUDIT.md` for "the complete enumeration
of known defects at pin time" — but that ledger lives in the operator's workspace, outside
the package, and ships in **no** distribution zip. A dist consumer holding only the pin
had no route from the pin's own pointer to any record. This file is that record, carried
in-tree so every distribution (portable-core, validation-sdk, combined, cumulative) ships
it. The workspace ledger `V8_SELF_AUDIT.md` remains the full chronological audit; this is
the carried summary, not a replacement.

It is a record, not an endorsement: an entry below is not a claim that the defect is
still open in the tree you hold — check the "Status now" column and the era pin for the
tree you hold.

## Defect ledger (D-series, decision round and earlier) — summary

| ID | Class | Subject | Status now |
|----|-------|---------|-------------|
| D-7 / D-41 | CRITICAL | `release/RELEASE.json` baselineManifest pointed at the 7.6.0 pin; no 8.0.0 baseline existed | Fixed: `release/V8_0_0_RELEASE_7_BASELINE_HASHES.json` (8.0.0 pin) exists and is chained by hash |
| D-8b / D-19 | MAJOR | Schema `const` vs runtime fact resolution split-brain in the MCP layer; no avd-fact-mirror equality check | Fixed in the 8.0.0 layer (mirror check in `signal_authority`/`check_guide_staleness`) |
| D-9 | MAJOR | `validate_state_serialization` accepted all-zero / all-f SHA-256 digests as "computed" | Fixed in the 8.0.0 layer (null-placeholder regex). **Extended in 8.0.2**: a "computed" digest must also *recompute* against a bound artifact path (F-2) |
| D-14b | MINOR | Digest canonicalization labelled JCS-1 with no JCS implementation | Fixed in 8.0.0: label is the real stdlib form (JSON-SORTED-KEYS-UTF8) |
| D-31 | MAJOR | AV-sync acceptance band was symmetric, contradicting the asymmetry both cited sources state | Fixed in 8.0.0 (early ≤ −40 / late ≤ +60 provisional, enforced by `signal_authority.check_av_sync_asymmetry`). **8.0.2**: sign-convention note added — the m4 quotation and the pin's shorthand each render the citation under a different sign convention than the block's own; the adopted values follow m1's ITU detectability frame, not a literal read of m4's pair |
| D-38 | MINOR | `MIGRATION_REGISTRY` referenced a nonexistent ROLLBACK_PLAN overlay section | Fixed in 8.0.0: `overlayRollbackPolicy` now ships in `ROLLBACK_PLAN.json` and the validator requires it |
| D-39 | MINOR | `versionMeta` line-3 convention applied to 22/23 templates | Fixed in 8.0.1 (23/23) |
| D-42 | MAJOR | Version-detection ladder existed only as `MIGRATION_REGISTRY` prose | **Fixed in 8.0.1 for tiers 1–2** (declared-vs-structural `VERSION_IDENTITY_CONFLICT`, envelope checks, live catch: runtime manifest missing `versionMeta`). **8.0.2** completes the LM finding: tiers 3–4 remain declared-not-enforced and the proofBoundary no longer implies all four arms are code |
| D-49 | MINOR | `extract_upgrade_baseline` hardcoded 7.8.0 / Release 4 labels on every archive | Fixed in 8.0.1 (labels read from the archive's own RELEASE.json) |

## Independent-verification findings (LM round, adjudicated — 8.0.2 fix layer)

| ID | Class | Finding | Fix shipped in 8.0.2 |
|----|-------|---------|---------------------|
| F-1 | MAJOR | No JSON Schema engine runs anywhere; `roleApprovals` instance rules were declarative-only — one agent could sign three roles on a receipt with no valid hashes and pass every executable check | Receipt layer now *executes* the overlay contract: registered role, one entry per role, decision/veto enums, evidence on terminal decisions, DEFAULT-DENY, non-empty 64-hex binding list, registry veto typing, role↔gate scope ∧ DAG `requiredApprovals` roster, two-ABSOLUTE ⇒ status BLOCK, R8 cannot PASS with a CONDITIONAL approval carrying an open condition (R690–R692, R695). **Fixture status:** the arms were live in 8.0.2, but the five negative fixtures shipped as files that no validator or suite executed — the 8.0.2 workspace ledger overstated them as "rejected as designed by the fixture battery." From 8.0.3 all thirteen negative fixtures are registered in `validate_state_serialization.py`'s battery and genuinely execute, each producing exactly one recorded rejection. |
| F-2 | MAJOR | The state layer never recomputed any digest; a random 64-hex passed as "computed"; the post-D-9 `MARKER` grammar was dead code with no callers | A "computed" digest must carry a resolvable `artifactPath` and recompute to sha256 of those bytes (unbound/mismatch fail closed, R693); the embedded AVD:STATE marker sweep is now live with good/duplicate/null-hash probes, grammar templates exempted not falsified (R694) |
| F-13 | MAJOR | D-42 recorded "4-tier ladder as real code"; only tiers 1–2 are enforced | proofBoundary now names the two enforced arms; registry records tiers 3–4 as declared-not-enforced (R685 updated, R697) |
| minor a | MINOR | AV-sync note contradicted its own quoted EBU citation direction | Sign-convention note added to the catalog basis block; the 8.0.0 pin is an era record and is not edited |
| minor b | MINOR | Canary contract: `expectedTreeVersion 8.0.0` in an 8.0.1+ tree and a nonexistent baseline filename, read by no validator | Contract is now read: it must track `release/RELEASE.json`'s version and every baseline file it names must exist (R696) |
| minor c | MINOR | The pin pointed at a defect ledger that ships in no zip | This file (R697) |
| minor d | MINOR | R8 openConditionPolicy had zero code readers; a CONDITIONAL approval could hold R8 open with nothing enforcing it | Executed at the receipt layer (R695) |
| minor e | MINOR | A declared-inverse rollback re-introduced the FIX-NOW defects without telling the operator | `rollback_note` on the V801 layer and on the new V802 layer naming exactly what a restore returns (R697) |

## Open, disclosed, not fixed in 8.0.2

- **Live-evidence tracks remain NOT_RUN.** The five tracks are `NOT_RUN` in
  `dev/LIVE_EVIDENCE_STATUS.json` and `promotionEligible` is `false`. The 8.0.2 layer
  changed no gate to PASS and no promotion field.
- **Single-operator T1 round ceiling.** Campaign T1-2026-09-13 validated mechanically
  (`LIVE_EXTERNAL` trials, `DECLARED` provenance) with **zero blind independent ratings**;
  its A/B track therefore reads `NOT_PROVEN` inside the validator result and `NOT_RUN` in
  the compiled status, and the round was operator-attested by review-and-attest (method
  recorded). The 8.0.2 runtime-receipt minter closed the *binding* gap that made the round
  error out; it does not upgrade the round's evidence class.
- **D-31 thresholds remain provisional.** `CALIBRATION_REQUIRED`: cited-standard ranges,
  not measured on generator output. The 8.0.2 change is a sign-convention annotation, not
  a recalibration.

## How to read a pin against this file

1. Find your tree's pin under `release/*_BASELINE_HASHES.json`.
2. Its `pinningNotes.knownDefectsAtPin` lists what was known *at that pin* (defects
   included — a pin is a record, not an endorsement).
3. Compare the pin's `labelCheckExemptions` and `previousBaseline` to see which era
   records are exempt and which pin it chains to by hash.
4. The "Status now" column above tells you what later layers changed; the workspace
   ledger `V8_SELF_AUDIT.md` (not shipped) carries the full chronology and the LM
   adjudication verdicts.
