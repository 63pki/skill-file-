#!/usr/bin/env python3
"""Mint a runtime receipt for an external-evidence campaign round.

Why this exists (8.0.2, after T1): EXTERNAL_TRIAL_RECORD.runtimeReceiptSha256 is a
required binding field, but the tree shipped no minting path for EXTERNAL campaigns — the
pre-existing minting code (finalize_contract_binding.py) only serves in-tree runtime
finalization. The first live round (campaign T1-2026-09-13) therefore failed
EXTERNAL_TRIAL_FIELD on all six trials because no receipt existed to bind. This tool mints
one so the next round can close the field honestly.

What the receipt is, exactly: a campaign-round binding record. It names the tree release,
the package manifest hash, the runtime-load manifest hash, the campaign id, the minting
host, and the minting time. It binds the round to the tree/runtime state in force at mint
time. It does NOT prove provider behavior, media quality, audience response, or that any
generation actually happened. Those remain operator-declared (DECLARED provenance) or
proved by the external-evidence floor. A receipt with an UNCOMPUTED/placeholder hash is
invalid; this tool always computes the real sha256 of the bytes it writes.

Usage:
    python3 bootstrap/mint_campaign_runtime_receipt.py <campaign-json> --out <path> [--campaign-id ID]

The campaign JSON is read to carry its declared campaignId when --campaign-id is not
given. The receipt is written to <path> and its sha256 is printed for binding into each
trial's runtimeReceiptSha256. The file's own bytes are the binding artifact; store it
beside the campaign so a verifier can recompute.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, platform, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def mint(campaign_path: Path, out_path: Path, campaign_id: str | None = None) -> dict:
    if campaign_path.is_file():
        campaign = json.loads(campaign_path.read_text(encoding="utf-8"))
        cid = campaign_id or campaign.get("campaignId") or "UNNAMED-CAMPAIGN"
    else:
        cid = campaign_id or "UNNAMED-CAMPAIGN"
    release = json.loads((ROOT / "release/RELEASE.json").read_text(encoding="utf-8"))
    manifest = ROOT / "PACKAGE_MANIFEST.json"
    runtime = ROOT / "bootstrap/runtime_load_manifest.json"
    receipt = {
        "schemaVersion": "8.0.2",
        "versionMeta": {
            "ruleVersion": "8.0.2",
            "producerVersion": "ai-visual-director-production@8.0.2",
            "migratedFrom": "8.0.1",
        },
        "receiptType": "CAMPAIGN_RUNTIME",
        "campaignId": cid,
        "mintedAt": datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat(),
        "treeRelease": release.get("version"),
        "treeReleaseName": release.get("release"),
        "packageManifestSha256": sha256_bytes(manifest.read_bytes()) if manifest.is_file() else None,
        "runtimeLoadManifestSha256": sha256_bytes(runtime.read_bytes()) if runtime.is_file() else None,
        "mintedBy": {
            "tool": "bootstrap/mint_campaign_runtime_receipt.py",
            "host": platform.node(),
            "platform": platform.platform(),
        },
        "proofBoundary": (
            "Binds this campaign round to the tree release, package-manifest hash, and "
            "runtime-load-manifest hash in force at mint time. It does NOT prove provider "
            "behavior, media quality, audience response, rights, or that any generation "
            "occurred; trial provenance remains as declared. The receipt's own sha256 is the "
            "value bound into each trial's runtimeReceiptSha256."
        ),
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    body = json.dumps(receipt, indent=2, ensure_ascii=False) + "\n"
    out_path.write_text(body, encoding="utf-8")
    receipt["_selfSha256"] = sha256_bytes(out_path.read_bytes())
    return receipt


def main() -> int:
    ap = argparse.ArgumentParser(description="Mint an external-campaign runtime receipt.")
    ap.add_argument("campaign", help="campaign JSON path (read for campaignId), or '-' for none")
    ap.add_argument("--out", required=True, help="output receipt path")
    ap.add_argument("--campaign-id", default=None, help="override the campaignId")
    a = ap.parse_args()
    camp = Path(a.campaign) if a.campaign != "-" else None
    receipt = mint(camp if camp else Path("."), Path(a.out), a.campaign_id)
    print(json.dumps({
        "status": "PASS",
        "out": a.out,
        "campaignId": receipt["campaignId"],
        "runtimeReceiptSha256": receipt["_selfSha256"],
        "treeRelease": receipt["treeRelease"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
