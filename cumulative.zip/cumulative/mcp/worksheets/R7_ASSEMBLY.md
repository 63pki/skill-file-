# Worksheet R7_ASSEMBLY (PORTABLE_REFERENCE manual path - v8.0.0)
HONEST LABEL: every result produced from this worksheet MUST carry the label prefix
`MANUAL/PORTABLE_REFERENCE` and assurance capped at `PLAN-PASS` (never VERIFIED-PASS).
1. Resolve any bound hard facts by id from mcp/resources/HARD_FACTS.json (RULE 03: never from memory).
2. Perform the same deterministic checks the tool contract describes, by hand, writing each observation
   into the receipt as evidence {kind, uri, sha256 (compute with sha256sum), collector: operator}.
3. Fill the SAME output JSON shape as the tool outputSchema; status PASS requires at least one evidence row (X14).
4. Approval-required ops: the operator writes approvals/<key>.request.json and countersigns
   approvals/<key>.approval.json with approver, approver_role, approved_at, scope_sha256.
5. File the receipt under receipts/ per the AVD marker protocol. This path is a first-class citizen, not an error case.
