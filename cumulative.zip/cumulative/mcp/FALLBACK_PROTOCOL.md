# v8.0.0 Fallback Protocol (PORTABLE_REFERENCE, first-class)
Trigger: any AVD-E-5xxx, or avd_list_capabilities reporting execution_mode=PORTABLE_REFERENCE.
Ladder (mandatory order):
1. Call avd_list_capabilities (refresh_probe=true). If VERIFIED_RUNTIME is confirmed absent:
2. Re-invoke the SAME contract with execution_mode=PORTABLE_REFERENCE. The schema does not change.
3. Follow the tool's worksheet resource (avd://worksheets/...). The operator performs the wrapped
   validator's checks by hand and writes the identical output JSON shape.
4. HONEST LABELS: honest_label must begin with MANUAL/PORTABLE_REFERENCE; assurance is structurally
   capped at PLAN-PASS by every outputSchema (executed_mode=PORTABLE_REFERENCE => assurance != VERIFIED-PASS).
5. Never narrate a gate as executed. A gate without a receipt (tool or worksheet) did not happen.
Prohibited: inventing metrics, claiming VERIFIED-PASS, skipping approval markers, silent degradation.
