# v8.0.0 Tool Discovery Contract
1. MCP tools/list ALWAYS returns all nine contracts (CONSTANT_SURFACE_VARIABLE_MODE) - contracts never
   disappear on weaker hosts; they degrade to PORTABLE_REFERENCE.
2. Session start: agent calls avd_list_capabilities. It resolves routing/HOST_CAPABILITY_ROUTING.json
   (v8 "v8_mcp_contract_layer" block) + bootstrap/probe_host.py --probe mcp, and returns per-tool
   {available, execution_mode, assurance_ceiling, error_code?} plus routing_source {uri, sha256}.
3. Distribution mapping: portable-core => PORTABLE_REFERENCE (no Python, PLAN-PASS ceiling);
   validation-sdk/combined/cumulative => VERIFIED_RUNTIME when validators import cleanly, else fallback.
4. Any AVD-E-5xxx invalidates the cached capability view; re-discover before the next gate tool call.
5. Resources and prompts are enumerated via standard MCP resources/list and prompts/list from
   mcp/resources/RESOURCE_CATALOG.json and mcp/prompts/PROMPT_CATALOG.json.
