#!/usr/bin/env python3
"""AVD v8.0.0 guide/hard-facts staleness + fact-mirror checker (dependency-free, fail-closed).

Two deterministic, read-only modes:

1. Contract mode (v7.8.0 behavior, templates/PROJECT_CONTRACT*.json consumers):
     check_guide_staleness.py <contract.json> [--today YYYY-MM-DD]
   Reports guideAlignment snapshot age vs maxAgeDays; exit 1 when REVERIFY is due.
   A file without guideAlignment.snapshotDate is a structured error (exit 1),
   never a crash (audit D-50, positional leg).

2. Hard-facts mode (v8.0.0 — the invocation advertised in HARD_FACTS.json
   staleness.checker; regression R672; fixes audit D-50 and implements the D-19
   mirror doctrine / C-P2a resolution branch b):
     check_guide_staleness.py --hard-facts mcp/resources/HARD_FACTS.json [--today YYYY-MM-DD]
   HARD_FACTS.json is the single source of truth (Rule 03). Every other copy of
   the video-behavior numbers in the tree is equality-asserted against it at
   validation time:
     - schemas/artifacts/_avd_defs.schema.json policyConstants consts — each const
       annotated x-avd-fact-mirror {fact, field, normalize}; the checker resolves
       the annotation, reads the fact, applies the normalization, and asserts
       const == fact-derived value. Unannotated consts and unmirrored facts are
       divergences (fail-closed completeness).
     - schemas/PRODUCTION_STATE.schema.json policyConstants consts — asserted equal
       to the _avd_defs consts key by key; extra keys are divergences.
     - validators/validate_state_serialization.py POLICY dict — asserted per key.
     - validators/signal_authority.py + signal_provider_interface.py
       HARD_FACTS_VIDEO provenance dicts — asserted on their three historical keys.
   Facts staleness (last_reviewed/review_by) is REPORTED (AVD-E-3004 is an
   operational runtime-blocking condition for video-touching tools, not a tree
   invariant) and does not change this structural check's exit code.
   Exit 1 iff any mirror divergence or load failure; exit 0 = mirror OK.
   The checker itself contains no numeric policy values: values live in
   HARD_FACTS.json and in the copies being asserted; the mapping lives in the
   schema annotations. Stdlib only; UTF-8.
"""
from __future__ import annotations

import argparse
import datetime
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FACT_MIRROR_ANNOTATION = "x-avd-fact-mirror"

# Key-name bridge between the signal-layer provenance dicts (snake_case, three
# historical keys) and the _avd_defs policyConstants consts (camelCase). Names
# only — no values live here.
SIGNAL_KEY_TO_POLICY = {
    "video_native_ceiling": "nativeVideoCeiling",
    "edit_cap": "maxSequentialConversationalEditsPerClip",
    "repair_budget": "oneVariableRepairBudget",
}


def _load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _resolve_field(obj, dotted):
    cur = obj
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None, False
        cur = cur[part]
    return cur, True


def _norm_identity(raw):
    return raw


def _norm_append_p(raw):
    return "{}p".format(raw)


def _norm_at_least_one_true(raw):
    return isinstance(raw, int) and raw >= 1


def _norm_classification_flags_join(raw):
    cls = raw.get("classification", "") if isinstance(raw, dict) else ""
    flags = raw.get("must_flag_at", []) if isinstance(raw, dict) else []
    if not cls or not flags:
        return None
    return cls.lower().replace("_", "-") + "-flagged-" + "-".join(flags)


NORMALIZE_RULES = {
    "identity": _norm_identity,
    "append-p": _norm_append_p,
    "at-least-one-means-true": _norm_at_least_one_true,
    "classification-flags-join": _norm_classification_flags_join,
}


def check_hard_facts_mirror(facts_path, today=None, root=None):
    """Equality-assert every tree copy of the video-behavior numbers against HARD_FACTS.json.

    Returns a report dict; 'divergences' is the gate (empty = MIRROR-OK).
    Fail-closed on every load/import failure. Holds no numeric policy values.
    """
    root = Path(root) if root is not None else ROOT
    findings = []

    facts_path = Path(facts_path)
    if not facts_path.exists() and (root / facts_path).exists():
        facts_path = root / facts_path

    try:
        facts_doc = _load_json(facts_path)
    except Exception as e:
        return {
            "mode": "hard-facts-mirror", "factsFile": str(facts_path),
            "mirrorStatus": "DIVERGENT", "divergences": [
                {"surface": "HARD_FACTS.json", "kind": "load-failed",
                 "error": "{}: {}".format(type(e).__name__, e)}],
            "mirroredSurfaces": [], "staleness": {}, "exitCode": 1,
        }

    facts_list = facts_doc.get("facts")
    if not isinstance(facts_list, list):
        findings.append({"surface": "HARD_FACTS.json", "kind": "facts-not-a-list"})
        facts_list = []
    facts = {f.get("id"): f for f in facts_list if isinstance(f, dict)}

    # --- surface 1: _avd_defs policyConstants consts (annotated mirror) ---
    props = {}
    try:
        defs = _load_json(root / "schemas/artifacts/_avd_defs.schema.json")
        props = defs["$defs"]["policyConstants"]["properties"]
        if not isinstance(props, dict):
            raise ValueError("policyConstants.properties is not an object")
    except Exception as e:
        props = {}
        findings.append({"surface": "schemas/artifacts/_avd_defs.schema.json",
                         "kind": "load-failed",
                         "error": "{}: {}".format(type(e).__name__, e)})

    annotated = {}
    for key, spec in props.items():
        ann = spec.get(FACT_MIRROR_ANNOTATION) if isinstance(spec, dict) else None
        if not isinstance(ann, dict):
            findings.append({"surface": "_avd_defs.policyConstants." + key,
                             "kind": "missing-mirror-annotation"})
            continue
        annotated[key] = ann
        fid = ann.get("fact")
        field = ann.get("field", "value")
        fact = facts.get(fid)
        if fact is None:
            findings.append({"surface": "_avd_defs.policyConstants." + key,
                             "kind": "fact-missing", "fact": fid})
            continue
        raw, ok = _resolve_field(fact, field)
        if not ok:
            findings.append({"surface": "_avd_defs.policyConstants." + key,
                             "kind": "fact-field-missing", "fact": fid, "field": field})
            continue
        rule = ann.get("normalize", "identity")
        fn = NORMALIZE_RULES.get(rule)
        if fn is None:
            findings.append({"surface": "_avd_defs.policyConstants." + key,
                             "kind": "unknown-normalize-rule", "rule": rule})
            continue
        expected = fn(raw)
        if expected is None:
            findings.append({"surface": "_avd_defs.policyConstants." + key,
                             "kind": "normalize-failed", "fact": fid,
                             "field": field, "rule": rule})
            continue
        if spec.get("const") != expected:
            findings.append({"surface": "_avd_defs.policyConstants." + key,
                             "kind": "value-divergence", "fact": fid, "field": field,
                             "expectedFromFact": expected, "schemaConst": spec.get("const")})

    # completeness: every fact must be mirrored by at least one annotation
    used = {ann.get("fact") for ann in annotated.values()}
    for fid in facts:
        if fid not in used:
            findings.append({"surface": "HARD_FACTS.json", "kind": "fact-not-mirrored",
                             "fact": fid})

    # --- surface 2: PRODUCTION_STATE inline policyConstants (mirror of the mirror) ---
    ps_props = None
    try:
        ps = _load_json(root / "schemas/PRODUCTION_STATE.schema.json")
        ps_props = ps["properties"]["policyConstants"]["properties"]
        if not isinstance(ps_props, dict):
            raise ValueError("policyConstants.properties is not an object")
    except Exception as e:
        findings.append({"surface": "schemas/PRODUCTION_STATE.schema.json",
                         "kind": "load-failed",
                         "error": "{}: {}".format(type(e).__name__, e)})
    if isinstance(ps_props, dict):
        for key, spec in props.items():
            found = ps_props.get(key, {}).get("const")
            if found != spec.get("const"):
                findings.append({"surface": "PRODUCTION_STATE.policyConstants." + key,
                                 "kind": "value-divergence",
                                 "expectedFromAvdDefs": spec.get("const"), "found": found})
        for extra in sorted(set(ps_props) - set(props)):
            findings.append({"surface": "PRODUCTION_STATE.policyConstants." + extra,
                             "kind": "key-not-in-avd-defs"})

    # --- surface 3: validate_state_serialization.POLICY (enforcement copy) ---
    vdir = root / "validators"
    if str(vdir) not in sys.path:
        sys.path.insert(0, str(vdir))
    pol = None
    try:
        import validate_state_serialization as vss
        pol = getattr(vss, "POLICY", None)
        if not isinstance(pol, dict):
            findings.append({"surface": "validate_state_serialization.POLICY",
                             "kind": "policy-dict-missing"})
    except Exception as e:
        findings.append({"surface": "validators/validate_state_serialization.py",
                         "kind": "import-failed",
                         "error": "{}: {}".format(type(e).__name__, e)})
    if isinstance(pol, dict):
        for key, spec in props.items():
            if pol.get(key) != spec.get("const"):
                findings.append({"surface": "validate_state_serialization.POLICY." + key,
                                 "kind": "value-divergence",
                                 "expectedFromAvdDefs": spec.get("const"),
                                 "found": pol.get(key)})
        for extra in sorted(set(pol) - set(props)):
            findings.append({"surface": "validate_state_serialization.POLICY." + extra,
                             "kind": "key-not-in-avd-defs"})

    # --- surfaces 4/5: signal-layer HARD_FACTS_VIDEO provenance dicts ---
    for mod_name in ("signal_authority", "signal_provider_interface"):
        hf_video = None
        try:
            mod = __import__(mod_name)
            hf_video = getattr(mod, "HARD_FACTS_VIDEO", None)
            if not isinstance(hf_video, dict):
                findings.append({"surface": mod_name + ".HARD_FACTS_VIDEO",
                                 "kind": "dict-missing"})
        except Exception as e:
            findings.append({"surface": "validators/" + mod_name + ".py",
                             "kind": "import-failed",
                             "error": "{}: {}".format(type(e).__name__, e)})
        if isinstance(hf_video, dict):
            for skey, pkey in SIGNAL_KEY_TO_POLICY.items():
                spec = props.get(pkey)
                if not isinstance(spec, dict):
                    continue
                if hf_video.get(skey) != spec.get("const"):
                    findings.append({"surface": mod_name + ".HARD_FACTS_VIDEO." + skey,
                                     "kind": "value-divergence",
                                     "expectedFromAvdDefs": spec.get("const"),
                                     "found": hf_video.get(skey)})

    # --- staleness leg (reported, not gating — AVD-E-3004 is operational) ---
    st = facts_doc.get("staleness")
    if not isinstance(st, dict):
        st = {}
        findings.append({"surface": "HARD_FACTS.json staleness",
                         "kind": "staleness-block-missing"})
    try:
        today_d = datetime.date.fromisoformat(today) if today else datetime.date.today()
    except (TypeError, ValueError):
        return {"mode": "hard-facts-mirror", "error": "BAD_TODAY",
                "hint": "--today must be YYYY-MM-DD", "exitCode": 2}
    review_by = st.get("review_by")
    facts_stale = None
    if review_by:
        try:
            facts_stale = bool(today_d > datetime.date.fromisoformat(review_by))
        except (TypeError, ValueError):
            findings.append({"surface": "HARD_FACTS.json staleness.review_by",
                             "kind": "bad-date", "value": review_by})

    surfaces = [
        "schemas/artifacts/_avd_defs.schema.json#/$defs/policyConstants (x-avd-fact-mirror)",
        "schemas/PRODUCTION_STATE.schema.json#policyConstants",
        "validators/validate_state_serialization.py#POLICY",
        "validators/signal_authority.py#HARD_FACTS_VIDEO",
        "validators/signal_provider_interface.py#HARD_FACTS_VIDEO",
    ]
    return {
        "mode": "hard-facts-mirror",
        "factsFile": str(facts_path),
        "factsVersion": facts_doc.get("facts_version"),
        "doctrine": ("HARD_FACTS.json is the single source of truth (Rule 03); every tree "
                     "copy is equality-asserted against it at validation time "
                     "(D-19 mirror check, C-P2a branch b)."),
        "mirroredSurfaces": surfaces,
        "divergences": findings,
        "mirrorStatus": "DIVERGENT" if findings else "MIRROR-OK",
        "staleness": {
            "lastReviewed": st.get("last_reviewed"),
            "reviewBy": review_by,
            "checkedDate": str(today_d),
            "factsStale": facts_stale,
            "onStale": st.get("on_stale"),
            "note": ("factsStale is operational (AVD-E-3004 blocks video-touching tools "
                     "at runtime until re-verified); it is reported here and does not "
                     "change this structural check's exit code."),
        },
        "exitCode": 1 if findings else 0,
    }


def run_contract_mode(path, today):
    """v7.8.0 positional behavior: guideAlignment snapshot age vs maxAgeDays."""
    try:
        c = _load_json(path)
    except Exception as e:
        return {"contract": str(path), "error": "CONTRACT_JSON_PARSE_ERROR",
                "detail": "{}: {}".format(type(e).__name__, e)}, 1
    g = c.get("guideAlignment") if isinstance(c, dict) else None
    if not isinstance(g, dict) or not g.get("snapshotDate"):
        return {"contract": str(path),
                "error": "CONTRACT_MISSING_GUIDE_ALIGNMENT",
                "hint": ("positional mode expects a project contract with "
                         "guideAlignment.snapshotDate; hard-fact mirror checks use "
                         "--hard-facts PATH")}, 1
    try:
        snap = datetime.date.fromisoformat(g["snapshotDate"])
    except (TypeError, ValueError):
        return {"contract": str(path), "error": "BAD_SNAPSHOT_DATE",
                "value": g.get("snapshotDate")}, 1
    try:
        today_d = datetime.date.fromisoformat(today) if today else datetime.date.today()
    except (TypeError, ValueError):
        return {"contract": str(path), "error": "BAD_TODAY",
                "hint": "--today must be YYYY-MM-DD"}, 2
    age = (today_d - snap).days
    maxage = int(g.get("maxAgeDays", 90))
    out = {"snapshotDate": str(snap), "checkedDate": str(today_d), "ageDays": age,
           "maxAgeDays": maxage,
           "status": "REVERIFY" if age > maxage else "CURRENT",
           "warning": ("Current status requires official-source review; this script "
                       "does not fetch or approve guide changes.")}
    return out, (1 if out["status"] == "REVERIFY" else 0)


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="AVD guide/hard-facts staleness + fact-mirror checker")
    ap.add_argument("contract", nargs="?",
                    help="project contract JSON (guideAlignment mode)")
    ap.add_argument("--hard-facts", metavar="PATH",
                    help="HARD_FACTS.json to mirror-check (R672 / D-19 mode)")
    ap.add_argument("--today", metavar="YYYY-MM-DD", help="override the checked date")
    ns = ap.parse_args(argv)
    if ns.hard_facts is not None:
        report = check_hard_facts_mirror(ns.hard_facts, today=ns.today)
        code = report.get("exitCode", 1)
    elif ns.contract is not None:
        report, code = run_contract_mode(ns.contract, ns.today)
    else:
        report = {"mode": "none", "error": "NO_MODE",
                  "hint": ("pass a contract path (guideAlignment mode) or "
                           "--hard-facts PATH (mirror mode)")}
        code = 2
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
