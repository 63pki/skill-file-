#!/usr/bin/env python3
"""AVD v8.0.3 consistency wiring validator (B1; regression R702).

Why this exists (live-evidence root cause). Before v8.0.3:
  * locks.characters[] required only an assetId, so a recurring subject could be "locked"
    as {"assetId":"CHAR-MILO"} - RUNTIME §11's promise of "invariant fields, permitted
    variation, forbidden drift, and dependent prompt list" had no machine home;
  * references existed only as PROSE inside prompts ("Subject/references:", "Reference roles
    and precedence:") - the r6 ISSUE contract had no reference field at all, so nothing
    recorded which reference was attached and nothing forced one;
  * the identity descriptor was re-paraphrased per prompt, and paraphrase is what breaks
    multi-shot consistency.
Campaign T1-2026-09-13 measured the consequence: the P2 pair diverged in style detail with no
reference to diverge from, and no field in which to record it.

This validator makes the three wiring rules executable:
  DESCRIPTOR_LOCK_MISSING   - a prompt referencing a locked subject must contain that lock's
                              canonical descriptor VERBATIM;
  EMPTY_LOCK / lock substance - a recurring lock must carry identity anchors and a
                              forbidden-drift list, and palette tokens must be real hex;
  REFERENCE_NOT_BOUND       - a shot naming a locked subject must declare reference hashes.

Proof boundary: proves declared wiring (locks, descriptors, reference hashes) is internally
consistent between a contract, its prompts and its attempts. It does NOT prove a generator
honoured a reference, that two outputs look alike, or that a subject is visually consistent -
those are inspection verdicts on real media this prompt-only tree cannot produce.
"""
import io
import json
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent

PASSES, FAILURES = [], []
HEX64 = re.compile(r"^[a-f0-9]{64}$")
HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


def load(p):
    return json.loads((ROOT / p).read_text(encoding="utf-8"))


# --- the executable rules (importable so the fixture tests drive the same functions) ----
def lock_substance(lock):
    """Return reasons a lock does not hold substance; empty list = substantive."""
    bad = []
    if lock.get("recurring") is True:
        if not (lock.get("identityAnchors") or []):
            bad.append("EMPTY_IDENTITY_ANCHORS")
        if not (lock.get("forbiddenDrift") or []):
            bad.append("EMPTY_FORBIDDEN_DRIFT")
        if not str(lock.get("canonicalDescriptor", "")).strip():
            bad.append("NO_CANONICAL_DESCRIPTOR")
    for tok in (lock.get("paletteTokens") or []):
        if not isinstance(tok, dict) or not HEX_COLOR.match(str(tok.get("hex", ""))):
            bad.append("PALETTE_TOKEN_INVALID:" + str(tok.get("name", "?")))
    for w in (lock.get("wardrobe") or []):
        if not isinstance(w, dict) or not (w.get("validForShots") or []):
            bad.append("WARDROBE_SHOT_UNBOUNDED:" + str(w.get("item", "?")))
    return bad


def descriptor_present(prompt_text, lock):
    """True when the prompt carries the lock's canonical descriptor verbatim."""
    desc = str(lock.get("canonicalDescriptor", "")).strip()
    return bool(desc) and desc in prompt_text


def reference_binding(shot):
    """Return reasons a shot's reference binding is insufficient; empty = bound."""
    bad = []
    locked = str(shot.get("lockedSubjectRef", "")).strip()
    refs = shot.get("reference_inputs") or shot.get("referenceSha256s") or []
    if locked and not refs:
        bad.append("REFERENCE_NOT_BOUND:" + locked)
    for r in refs:
        h = r.get("sha256") if isinstance(r, dict) else r
        if not (isinstance(h, str) and HEX64.match(h)):
            bad.append("REFERENCE_HASH_INVALID:" + str(h))
    return bad


# --- 1. the shipped template demonstrates a substantive lock --------------------------
TPL = load("templates/PROJECT_CONTRACT.json")
locks = TPL.get("locks", {})
chars = locks.get("characters", []) if isinstance(locks, dict) else []
check(bool(chars), "TEMPLATE_HAS_CHARACTER_LOCK", f"template declares {len(chars)} character lock(s)")
for lock in chars:
    bad = lock_substance(lock)
    check(not bad, "TEMPLATE_LOCK_SUBSTANTIVE",
          f"{lock.get('assetId')}: substantive ({bad or 'ok'})")
    check(isinstance(lock.get("paletteTokens", []), list), "TEMPLATE_LOCK_PALETTE",
          f"{lock.get('assetId')}: paletteTokens well-formed")
check("brand" in locks or "product" in locks, "TEMPLATE_LOCK_BRAND_OR_PRODUCT",
      f"template declares a brand/product lock (keys={sorted(locks.keys())})")

# --- 2. the pre-fix hole is closed: an assetId-only lock is rejected -----------------
empty_lock = {"assetId": "CHAR-BARE", "recurring": True}
check(lock_substance(empty_lock) != [], "EMPTY_LOCK_REJECTED",
      f"an assetId-only recurring lock is unmet on {lock_substance(empty_lock)}")
ok_lock = {
    "assetId": "CHAR-OK", "recurring": True,
    "canonicalDescriptor": "A weathered surveyor in an ochre field jacket, 40s, steady gaze.",
    "identityAnchors": ["ochre field jacket", "steady gaze"],
    "forbiddenDrift": ["no hat", "no modern logos"],
    "paletteTokens": [{"name": "jacket", "hex": "#C08040"}],
    "wardrobe": [{"item": "field jacket", "state": "open", "validForShots": ["S01", "S02"]}],
}
check(lock_substance(ok_lock) == [], "SUBSTANTIVE_LOCK_ACCEPTED", "a full lock passes")
check(lock_substance({**ok_lock, "paletteTokens": [{"name": "jacket", "hex": "ochre"}]}) != [],
      "PALETTE_TOKEN_INVALID_REJECTED", "a non-hex palette token is rejected")

# --- 3. verbatim descriptor reuse ----------------------------------------------------
prompt_ok = ("PASTE-BLOCK-BEGIN\nSubject/references: CHAR-OK — "
             + ok_lock["canonicalDescriptor"] +
             "\nComposition: medium close-up.\nPASTE-BLOCK-END")
prompt_paraphrased = ("PASTE-BLOCK-BEGIN\nSubject/references: CHAR-OK — a surveyor wearing "
                      "an orange jacket, middle aged, looking ahead.\nPASTE-BLOCK-END")
check(descriptor_present(prompt_ok, ok_lock), "DESCRIPTOR_VERBATIM_PASSES",
      "a prompt carrying the canonical descriptor verbatim passes")
check(not descriptor_present(prompt_paraphrased, ok_lock), "DESCRIPTOR_PARAPHRASE_REJECTED",
      "a paraphrased descriptor is NOT verbatim and is rejected")

# --- 4. reference binding ------------------------------------------------------------
check(reference_binding({"lockedSubjectRef": "CHAR-OK", "reference_inputs": []}) != [],
      "REFERENCE_NOT_BOUND_REJECTED", "a locked shot with no reference is rejected")
check(reference_binding({"lockedSubjectRef": "CHAR-OK", "reference_inputs": [{"sha256": "a" * 64}]}) == [],
      "REFERENCE_BOUND_ACCEPTED", "a locked shot with a bound reference passes")
check(reference_binding({"lockedSubjectRef": "CHAR-OK", "reference_inputs": [{"sha256": "nope"}]}) != [],
      "REFERENCE_HASH_INVALID_REJECTED", "a malformed reference hash is rejected")
check(reference_binding({}) == [], "UNLOCKED_SHOT_OK", "an unlocked shot needs no reference")

# --- 5. the schemas and the contract agree on the lock's shape -----------------------
SCHEMA = load("schemas/PROJECT_CONTRACT.schema.json")
cl = SCHEMA["$defs"]["characterLock"]
for field in ["canonicalDescriptor", "identityAnchors", "forbiddenDrift", "permittedVariation",
              "paletteTokens", "wardrobe", "dependentPromptRefs", "recurring"]:
    check(field in cl.get("properties", {}), f"LOCK_FIELD_{field.upper()}",
          f"characterLock declares {field}")
check("recurring" in cl.get("required", []), "LOCK_REQUIRES_RECURRING",
      "characterLock must state whether the subject recurs (an unstated lock is an empty one)")
lockprops = SCHEMA["properties"]["locks"]["properties"]
check("brand" in lockprops and "product" in lockprops, "LOCK_BRAND_PRODUCT_PRESENT",
      "locks declares brand and product (LM G7)")
check(load("mcp/tools/avd_r6_generation_execute.json")["inputSchema"]["properties"]["issue"]["properties"]
      .get("reference_inputs") is not None, "R6_REFERENCE_INPUTS_PRESENT",
      "r6 ISSUE declares reference_inputs (hash-bound)")
check((ROOT / "schemas/artifacts/GENERATION_ATTEMPT.schema.json").is_file(),
      "GENERATION_ATTEMPT_SCHEMA_PRESENT", "the generation-side reference binding artifact ships")

print(json.dumps({
    "schemaVersion": "8.0.3",
    "validator": "validate_consistency_wiring.py",
    "pass": not FAILURES,
    "passed": len(PASSES),
    "failed": len(FAILURES),
    "failures": FAILURES,
    "proofBoundary": ("Proves declared consistency wiring - locks, verbatim descriptors, reference hashes - "
                      "is internally consistent between contract, prompts and attempts. It does NOT prove "
                      "a generator honoured a reference, that two outputs look alike, or that a subject is "
                      "visually consistent; those are inspection verdicts on real media."),
}, indent=2, ensure_ascii=False))
sys.exit(0 if not FAILURES else 1)