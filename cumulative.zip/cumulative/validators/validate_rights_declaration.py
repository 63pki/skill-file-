#!/usr/bin/env python3
"""AVD v8.5 operator rights declaration + style translation validator.

v8.5 (rights-declaration model). Two mechanisms:

  1. RIGHTS_DECLARATION - a one-time-per-project operator declaration. When present and
     valid, it DISCHARGES repeated rights/likeness re-checks for the assets it covers: the
     declaration IS the receipt. Projects WITHOUT one keep the existing per-asset
     rightsStatus behaviour unchanged (declared-absence, not a silent pass).

  2. STYLE_TRANSLATION - an operator may name ANY style reference as INPUT, including a
     named artist. The generated prompt carries descriptive craft language ONLY, and every
     translated term MUST pair with a visible effect.

This validator does NOT change the kernel and does NOT assert a legal clearance: it records
an operator responsibility. An empty `basis` is rejected, because an unsupported declaration
is worse than none.

Negative controls run INSIDE this validator (SELF-APPLICATION / M3): every good case is
proven positive before any bad case is trusted. If a negative control passes, this validator
fails itself.
"""
import io
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PASSES, FAILURES = [], []
SCOPES = {"likeness", "brandAndTrademark", "venueAndProperty", "musicAndAudio", "thirdPartyArtwork"}
SCOPE_VALUES = {"CLEARED", "NOT-IN-SCOPE", "SUPPLIED-BY-CLIENT", "LICENSED", "FAIR-DEALING-ASSESSED"}


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


def validate_declaration(d):
    """Return a list of problems. Empty list = valid."""
    bad = []
    if not isinstance(d, dict):
        return ["not an object"]
    for k in ("projectId", "declarationId", "declaredBy", "declaredAt", "statement"):
        if not str(d.get(k, "")).strip():
            bad.append(f"missing {k}")
    sc = d.get("scope")
    if not isinstance(sc, dict):
        bad.append("scope missing")
    else:
        unknown = set(sc) - SCOPES
        if unknown:
            bad.append(f"scope has unknown keys {sorted(unknown)}")
        missing = SCOPES - set(sc)
        if missing:
            bad.append(f"scope missing {sorted(missing)}")
        for k, v in sc.items():
            if str(v).upper() not in SCOPE_VALUES:
                bad.append(f"scope.{k} value {v!r} outside {sorted(SCOPE_VALUES)}")
    basis = d.get("basis")
    if not isinstance(basis, dict):
        bad.append("basis missing")
    else:
        text = " ".join(str(v) for k, v in basis.items() if not k.startswith("_")).strip()
        if not text:
            bad.append("basis is empty - an unsupported declaration is worse than none")
    covers = d.get("coversAssets")
    if not isinstance(covers, list) or not covers:
        bad.append("coversAssets must be a non-empty list")
    else:
        for i, c in enumerate(covers):
            if not isinstance(c, dict) or not str(c.get("assetIdOrPattern", "")).strip():
                bad.append(f"coversAssets[{i}] missing assetIdOrPattern")
    if d.get("transferable") is True:
        bad.append("transferable=true is not supported; a declaration never travels")
    if d.get("revokedAt"):
        bad.append("a revoked declaration does not discharge rights checks")
    return bad


def validate_translation(t):
    bad = []
    if not isinstance(t, dict):
        return ["not an object"]
    for k in ("projectId", "shotOrAssetId"):
        if not str(t.get(k, "")).strip():
            bad.append(f"missing {k}")
    src = t.get("sourceInspiration")
    if not isinstance(src, dict) or not str(src.get("asStatedByOperator", "")).strip():
        bad.append("sourceInspiration.asStatedByOperator missing")
    trs = t.get("translations")
    if not isinstance(trs, list) or not trs:
        bad.append("translations must be a non-empty list")
    else:
        for i, x in enumerate(trs):
            if not isinstance(x, dict):
                bad.append(f"translations[{i}] not an object")
                continue
            for k in ("sourceTerm", "outputTerm", "visibleEffect"):
                if not str(x.get(k, "")).strip():
                    bad.append(f"translations[{i}] missing {k}")
    chk = t.get("promptOutputCheck")
    if not isinstance(chk, dict):
        bad.append("promptOutputCheck missing")
    else:
        if chk.get("promptContainsSourceString") is not False:
            bad.append("prompt must not contain the source inspiration string")
        if chk.get("promptContainsOutputTerms") is not True:
            bad.append("prompt must contain the translated output terms")
    return bad


# --------------------------------------------------------------- negative controls
# A negative control that passes invalidates the corresponding check. Run every time.
def negative_controls():
    good_decl = {
        "projectId": "P1", "declarationId": "RD-1", "declaredBy": "OP", "declaredAt": "2026-01-01",
        "statement": "s",
        "scope": {k: "CLEARED" for k in SCOPES},
        "basis": {"writtenPermissions": "signed by talent 2026-01-01"},
        "coversAssets": [{"assetIdOrPattern": "ASSET-*"}],
        "transferable": False, "revokedAt": None,
    }
    good_tr = {
        "projectId": "P1", "shotOrAssetId": "S1",
        "sourceInspiration": {"asStatedByOperator": "Akira Kurosawa", "isNamedArtistOrProtectedWork": True},
        "translations": [{"sourceTerm": "Kurosawa", "outputTerm": "hard low sun",
                          "visibleEffect": "long raking shadows to camera-right",
                          "sceneFactAnchor": "single low window, late afternoon"}],
        "promptOutputCheck": {"promptContainsSourceString": False, "promptContainsOutputTerms": True},
    }
    # positive control: the good fixtures must PASS, or nothing below is meaningful
    check(validate_declaration(good_decl) == [], "NEGCTRL_POSITIVE_DECLARATION",
          "a well-formed declaration validates (proven positive before any negative is trusted)")
    check(validate_translation(good_tr) == [], "NEGCTRL_POSITIVE_TRANSLATION",
          "a well-formed style translation validates")

    # named-artist input must be ALLOWED (that is the point of v8.5)
    check(validate_translation(good_tr) == [], "NEGCTRL_ARTIST_INPUT_ALLOWED",
          "a named-artist source reference is accepted as INPUT")

    negatives = [
        ("empty basis is rejected", "declaration",
         {**good_decl, "basis": {"writtenPermissions": "", "licenseTerms": ""}}),
        ("unknown scope value is rejected", "declaration",
         {**good_decl, "scope": {**good_decl["scope"], "likeness": "probably fine"}}),
        ("transferable=true is rejected", "declaration", {**good_decl, "transferable": True}),
        ("revoked declaration is rejected", "declaration", {**good_decl, "revokedAt": "2026-06-01"}),
        ("empty coversAssets is rejected", "declaration", {**good_decl, "coversAssets": []}),
        ("translation without visible effect is rejected", "translation",
         {**good_tr, "translations": [{"sourceTerm": "a", "outputTerm": "b", "visibleEffect": ""}]}),
        ("prompt containing the source string is rejected", "translation",
         {**good_tr, "promptOutputCheck": {"promptContainsSourceString": True,
                                          "promptContainsOutputTerms": True}}),
    ]
    for label, kind, bad in negatives:
        got = validate_declaration(bad) if kind == "declaration" else validate_translation(bad)
        check(bool(got), f"NEGCTRL_{kind.upper()}", f"{label} (problems: {got[:2]})")


def template_shape(d, required):
    """A TEMPLATE is a blank form, not a filled artifact: its values are menus
    ("CLEARED | NOT-IN-SCOPE") and its text is empty. So a template is checked for FIELD
    PRESENCE only. Value validation applies to filled records (and to the negative controls,
    which use fully-populated fixtures)."""
    missing = [k for k in required if k not in d]
    if not isinstance(d, dict):
        return ["template is not an object"]
    sc = d.get("scope")
    if "scope" in required:
        if not isinstance(sc, dict):
            missing.append("scope")
        else:
            miss = SCOPES - set(sc)
            if miss:
                missing.append(f"scope.{sorted(miss)}")
    return missing


def main():
    negative_controls()

    # validate the shipped TEMPLATES as forms: field presence, not filled values
    tpl_d = json.loads((ROOT / "templates/RIGHTS_DECLARATION.json").read_text(encoding="utf-8"))
    tpl_t = json.loads((ROOT / "templates/STYLE_TRANSLATION.json").read_text(encoding="utf-8"))
    miss_d = template_shape(tpl_d, ["projectId", "declarationId", "declaredBy", "declaredAt",
                                    "statement", "scope", "basis", "coversAssets", "transferable",
                                    "revocationTriggers", "proofBoundary"])
    check(not miss_d, "TEMPLATE_DECLARATION_FORM_COMPLETE",
          f"templates/RIGHTS_DECLARATION.json carries every required field ({miss_d or 'complete'})")
    miss_t = template_shape(tpl_t, ["projectId", "shotOrAssetId", "sourceInspiration",
                                    "translations", "promptOutputCheck", "proofBoundary"])
    check(not miss_t, "TEMPLATE_TRANSLATION_FORM_COMPLETE",
          f"templates/STYLE_TRANSLATION.json carries every required field ({miss_t or 'complete'})")

    # any declarations present in a project are validated
    found = 0
    for p in sorted(ROOT.rglob("RIGHTS_DECLARATION*.json")):
        if p.name == "RIGHTS_DECLARATION.json":
            continue
        found += 1
        bad = validate_declaration(json.loads(p.read_text(encoding="utf-8")))
        check(not bad, "PROJECT_DECLARATION_VALID", f"{p.relative_to(ROOT)}: {bad or 'valid'}")
    for p in sorted(ROOT.rglob("STYLE_TRANSLATION*.json")):
        if p.name == "STYLE_TRANSLATION.json":
            continue
        found += 1
        bad = validate_translation(json.loads(p.read_text(encoding="utf-8")))
        check(not bad, "PROJECT_TRANSLATION_VALID", f"{p.relative_to(ROOT)}: {bad or 'valid'}")

    print(json.dumps({
        "schemaVersion": "8.1.0",
        "validator": "validate_rights_declaration.py",
        "pass": not FAILURES,
        "passed": len(PASSES),
        "failed": len(FAILURES),
        "failures": FAILURES,
        "projectRecordsChecked": found,
        "proofBoundary": ("Validates the SHAPE and internal consistency of an operator rights declaration and a "
                          "style-translation record, and runs its own negative controls. It does NOT verify "
                          "that any right, licence or clearance exists, does not give legal advice, and cannot "
                          "convert an unsupported operator statement into evidence. An empty basis is rejected "
                          "precisely because an unsupported declaration is worse than none."),
    }, indent=2, ensure_ascii=False))
    sys.exit(0 if not FAILURES else 1)


if __name__ == "__main__":
    main()