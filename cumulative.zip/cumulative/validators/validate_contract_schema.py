#!/usr/bin/env python3
"""Dependency-free fail-closed contract preflight.

v8.0.3 (A1): the version allowlist is now a single source of truth. Before this layer the
audience/claims arms were gated on startswith(('7.4.2-...','7.8.0')) while the caller
(compile_and_validate) accepted 8.0.x - so an 8.0.x contract with a destroyed audience
block validated clean (proved in the A1 investigation: 0 errors at 8.0.2, 3 at 7.8.0).
Consequences fixed here:
  * ACCEPTED is the only version list in the tree (validate_version_gate_coverage.py
    enforces that no other validator keeps a private copy);
  * audience / humanReviewRequiredForClaims / audienceTriggers arms are UNCONDITIONAL for
    every accepted version - a version bump can no longer switch a safety check off by
    omission;
  * an UNRECOGNISED version is an error, never a silent skip;
  * hard-fail cadence: humanReviewRequiredForClaims became a WARNING at 8.0.3 and is a hard
    ERROR from 8.0.4 (HARD_AUDIENCE_GATE_FROM). 8.0.3 warned so contracts authored before
    this layer were not retro-failed; 8.0.4 enforces it. The accept-set pre-admits 8.0.4
    so the claims arm fires rather than the version arm rejecting the file first.
"""
from pathlib import Path
import argparse, copy, json

# The single accepted-version set. Update here, never at a call site.
# 8.0.4 is admitted AHEAD of its release on purpose: HARD_AUDIENCE_GATE_FROM is 8.0.4, so an
# 8.0.4 contract must be accepted (and then hard-fail the claims arm) rather than trip the
# version arm first. Pre-admitting it is what makes the A1 cadence testable.
ACCEPTED = ('7.4.2-phase-b', '7.4.2-phase-c', '7.4.2-phase-d', '7.4.2-final', '7.4.3',
            '7.4.4', '7.5.0', '7.6.0', '7.8.0', '8.0.0', '8.0.1', '8.0.2', '8.0.3', '8.0.4',
            '8.0.5', '8.0.6', '8.1.0')
# Family forms: a bare version prefix ('7.4.2') accepts any 7.4.2-* or plain form.
FAMILIES = ('7.4.2', '7.4.3', '7.4.4', '7.5.0', '7.6.0', '7.8.0', '8.0.0', '8.0.1', '8.0.2',
            '8.0.3', '8.0.4', '8.0.5', '8.0.6', '8.1.0')
# Hard-fail threshold for the humanReviewRequiredForClaims arm (A1 cadence, operator-approved).
HARD_AUDIENCE_GATE_FROM = '8.0.4'

WARNINGS = []


def accepted(v):
    """True when a declared schemaVersion is in the single accept-set."""
    s = str(v or '')
    return any(s == a or s.startswith(a) for a in ACCEPTED) or s.startswith(FAMILIES)


def _tuple(v):
    """Comparable version tuple; non-numeric segments sort low but name-matching still accepts."""
    out = []
    for p in str(v or '').split('.')[:3]:
        digits = ''.join(ch for ch in p if ch.isdigit())
        out.append(int(digits) if digits else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def hard_audience_gate(v):
    """True when this contract's version enforces humanReviewRequiredForClaims as an error."""
    s = str(v or '')
    if not accepted(s):
        return True  # unrecognised versions fail closed on the version arm anyway
    return _tuple(s) >= _tuple(HARD_AUDIENCE_GATE_FROM)


def issue(errors, path, expected, actual, hint=''):
    errors.append({'code': 'CONTRACT_SCHEMA_ERROR', 'path': path, 'expected': expected, 'actual': actual, 'hint': hint})


def warn(path, expected, actual, hint=''):
    WARNINGS.append({'code': 'AUDIENCE_BLOCK_MISSING', 'path': path, 'expected': expected,
                     'actual': actual, 'hint': hint})


def normalize_project_contract(c):
    c = copy.deepcopy(c)
    for spec in c.get('artifactQueue', []) if isinstance(c.get('artifactQueue', []), list) else []:
        if isinstance(spec, dict) and not str(spec.get('repairAction', '')).strip() and str(spec.get('repair', '')).strip():
            spec['repairAction'] = spec['repair']
            spec['repairAliasMigrated'] = True
    return c


def validate_project_contract(c):
    e = []
    if not isinstance(c, dict):
        issue(e, '$', 'object', type(c).__name__)
        return e
    sv = str(c.get('schemaVersion', ''))
    # Unrecognised version: an error, not a silent skip (v8.0.3 / A1).
    if not accepted(sv):
        issue(e, '$.schemaVersion', 'accepted version set', sv,
              'Declare a version in ACCEPTED, or add it to validate_contract_schema.ACCEPTED in the same change.')
    for k in ['schemaVersion', 'projectId', 'deliveryMode', 'productionIntent', 'mode', 'tools', 'story', 'locks', 'artifactQueue', 'evidenceCeiling']:
        if k not in c:
            issue(e, f'$.{k}', 'required field', 'missing')
    tools = c.get('tools', {})
    if not isinstance(tools, dict):
        issue(e, '$.tools', 'object', type(tools).__name__)
    else:
        for k in ['stillGeneration', 'videoGeneration']:
            if not str(tools.get(k, '')).strip():
                issue(e, f'$.tools.{k}', 'non-empty string', repr(tools.get(k)))
        if not isinstance(tools.get('postSurfaces'), list):
            issue(e, '$.tools.postSurfaces', 'array', type(tools.get('postSurfaces')).__name__)
    story = c.get('story', {})
    if not isinstance(story, dict):
        issue(e, '$.story', 'object', type(story).__name__)
    # Audience / claims arm: UNCONDITIONAL for every accepted version (v8.0.3 / A1).
    audience = c.get('audience', {})
    if not isinstance(audience, dict):
        issue(e, '$.audience', 'object', type(audience).__name__)
    else:
        for k in ['type', 'ageRange']:
            if not str(audience.get(k, '')).strip():
                issue(e, f'$.audience.{k}', 'non-empty string', repr(audience.get(k)))
        hrr = audience.get('humanReviewRequiredForClaims')
        if not isinstance(hrr, bool):
            hint = ('Absent or ill-typed: a child-audience claims review is treated as not required.'
                    + ('' if hard_audience_gate(sv) else
                       ' WARNING-FIRST (A1): becomes a hard error at ' + HARD_AUDIENCE_GATE_FROM + '.'))
            if hard_audience_gate(sv):
                issue(e, '$.audience.humanReviewRequiredForClaims', 'boolean', type(hrr).__name__, hint)
            else:
                warn('$.audience.humanReviewRequiredForClaims', 'boolean', type(hrr).__name__, hint)
    locks = c.get('locks', {})
    if not isinstance(locks, dict):
        issue(e, '$.locks', 'object', type(locks).__name__)
        return e
    chars = locks.get('characters', [])
    if not isinstance(chars, list):
        issue(e, '$.locks.characters', 'array', type(chars).__name__)
    else:
        for i, x in enumerate(chars):
            if not isinstance(x, dict):
                issue(e, f'$.locks.characters[{i}]', 'object with assetId', type(x).__name__, 'Use {"assetId":"CHAR-ID", ...}, not a string.')
            elif not str(x.get('assetId', '')).strip():
                issue(e, f'$.locks.characters[{i}].assetId', 'non-empty string', repr(x.get('assetId')))
    q = c.get('artifactQueue', [])
    if not isinstance(q, list):
        issue(e, '$.artifactQueue', 'array', type(q).__name__)
    else:
        for i, x in enumerate(q):
            p = f'$.artifactQueue[{i}]'
            if not isinstance(x, dict):
                issue(e, p, 'object', type(x).__name__)
                continue
            for k in ['artifactId', 'acceptance', 'repairAction']:
                if not str(x.get(k, '')).strip():
                    issue(e, f'{p}.{k}', 'non-empty string', repr(x.get(k)), ('Use repairAction; repair remains a deprecated input alias.' if k == 'repairAction' else ''))
    return e


def validate_routing_contract(c):
    e = []
    if not isinstance(c, dict):
        issue(e, '$', 'object', type(c).__name__)
        return e
    sv = str(c.get('schemaVersion', ''))
    if not accepted(sv):
        issue(e, '$.schemaVersion', 'accepted version set', sv,
              'Declare a version in ACCEPTED, or add it to validate_contract_schema.ACCEPTED in the same change.')
    for k in ['schemaVersion', 'routingId', 'projectClass', 'assuranceProfile', 'mode', 'deliveryMode', 'tools']:
        if k not in c:
            issue(e, f'$.{k}', 'required field', 'missing')
    tools = c.get('tools', {})
    if not isinstance(tools, dict):
        issue(e, '$.tools', 'object', type(tools).__name__)
    triggers = c.get('audienceTriggers')
    # audienceTriggers arm: UNCONDITIONAL for every accepted version (v8.0.3 / A1).
    if not isinstance(triggers, list) or not triggers or any(not isinstance(x, str) or not x.strip() for x in (triggers or [])):
        issue(e, '$.audienceTriggers', 'non-empty array of strings', type(triggers).__name__)
    return e


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('contract')
    ap.add_argument('--type', choices=['project', 'routing'], required=True)
    ap.add_argument('--normalized-out')
    ns = ap.parse_args()
    del WARNINGS[:]
    raw = json.loads(Path(ns.contract).read_text(encoding='utf-8'))
    c = normalize_project_contract(raw) if ns.type == 'project' else raw
    e = validate_project_contract(c) if ns.type == 'project' else validate_routing_contract(c)
    if ns.normalized_out:
        Path(ns.normalized_out).write_text(json.dumps(c, indent=2) + '\n', encoding='utf-8')
    out = {'schemaVersion': '7.8.0', 'contractType': ns.type, 'pass': not e, 'errors': e,
           'warnings': list(WARNINGS), 'normalized': c != raw}
    print(json.dumps(out, indent=2))
    raise SystemExit(0 if not e else 1)


if __name__ == '__main__':
    main()