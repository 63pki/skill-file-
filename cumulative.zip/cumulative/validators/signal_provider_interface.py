"""
Signal Provider Abstraction — v8.0.0
Interface contract so any backend can plug in, evaluated against the two locked models.
Locked surfaces: nano-banana-pro:stills, gemini-omni-flash:video
Hard facts: 720p native ceiling, three-edit cap, two-repair budget on every video result.
Rule 03: providers advertise capabilities dynamically (surface/tier/date), never stale spec tables.
"""
from __future__ import annotations
import abc
import hashlib
import random
import time
from dataclasses import dataclass, field, asdict
from datetime import date, datetime, timezone
from typing import List, Dict, Any, Optional

TODAY = "2026-09-10"
LOCKED_SURFACES = ["nano-banana-pro:stills", "gemini-omni-flash:video"]
HARD_FACTS_VIDEO = {"video_native_ceiling": "720p", "edit_cap": 3, "repair_budget": 2}


@dataclass
class SignalResult:
    id: str
    value: Optional[float]
    confidence: str  # high|medium|low|unavailable
    provenance: Dict[str, Any]
    uncertainty: Optional[Dict[str, Any]] = None
    n: int = 1
    hard_facts: Optional[Dict[str, Any]] = None
    fallback: Optional[str] = None
    note: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        # drop None for clean JSON but keep explicit null for value when unavailable
        return {k: v for k, v in d.items() if v is not None or k == "value"}


class SignalProvider(abc.ABC):
    """Abstract contract — any backend that implements these three is pluggable."""

    @abc.abstractmethod
    def capabilities(self) -> Dict[str, Any]:
        """-> {signals: string[], surfaces: string[], tier: string, as_of: date, hard_facts?: object}"""
        ...

    @abc.abstractmethod
    def score(self, artifact: Dict[str, Any], prompt: str, options: Optional[Dict[str, Any]] = None) -> SignalResult:
        """Score one artifact. artifact={uri, type, hash}. Return SignalResult with confidence+uncertainty+provenance+hard_facts(video)."""
        ...

    @abc.abstractmethod
    def health(self) -> Dict[str, Any]:
        """-> {ok: bool, latency_ms: int, error?: string}"""
        ...

    # helpers
    def _provenance(self, artifact: Dict[str, Any], tier: str, provider_name: str, surface: str) -> Dict[str, Any]:
        return {
            "provider": provider_name,
            "surface": surface,
            "tier": tier,
            "as_of": TODAY,
            "artifact_hash": artifact.get("hash") or "sha256:" + hashlib.sha256(artifact.get("uri", "").encode()).hexdigest()[:16],
        }


# ---------------------------------------------------------------------------
# Mock providers for tests / offline use — deterministic, parity-checked (R662)
# ---------------------------------------------------------------------------

class MockNanoBananaProvider(SignalProvider):
    """Stills — Nano Banana Pro surface. Scores image signals."""

    SUPPORTED = ["clip_score", "aesthetic_predictor", "drift_delta", "text_image_alignment", "style_consistency", "temporal_coherence"]
    # temporal_coherence not meaningful for stills but provider returns unavailable gracefully

    def capabilities(self) -> Dict[str, Any]:
        return {
            "signals": self.SUPPORTED,
            "surfaces": ["nano-banana-pro:stills"],
            "tier": "clip",
            "as_of": TODAY,
        }

    def score(self, artifact: Dict[str, Any], prompt: str, options: Optional[Dict[str, Any]] = None) -> SignalResult:
        sig = (options or {}).get("signal_id") or "clip_score"
        if artifact.get("type") == "video" and sig in ("audio_visual_sync",):
            return SignalResult(id=sig, value=None, confidence="unavailable",
                                provenance=self._provenance(artifact, "clip", "mock-nano-banana", "nano-banana-pro:stills"),
                                hard_facts=None, fallback="qualitative_only", note="stills provider cannot score video AV sync")
        if sig == "temporal_coherence" and artifact.get("type") != "video":
            return SignalResult(id=sig, value=None, confidence="unavailable",
                                provenance=self._provenance(artifact, "clip", "mock-nano-banana", "nano-banana-pro:stills"),
                                fallback="qualitative_only", note="temporal requires video")
        # deterministic pseudo-score from hash(prompt+uri) so tests are stable
        h = int(hashlib.sha256((prompt + artifact.get("uri", "")).encode()).hexdigest()[:8], 16)
        rng = random.Random(h)
        table = {
            "clip_score": (0.22 + rng.random() * 0.13, "medium", [0.02, 0.04]),
            "aesthetic_predictor": (4.8 + rng.random() * 2.0, "medium", [0.3, 0.5]),
            "drift_delta": (0.06 + rng.random() * 0.20, "medium", [0.02, 0.03]),
            "text_image_alignment": (0.55 + rng.random() * 0.35, "medium", [0.05, 0.08]),
            "style_consistency": (0.04 + rng.random() * 0.10, "medium", [0.01, 0.02]),
        }
        val, conf, ci_w = table.get(sig, (0.5, "low", [0.1, 0.1]))
        ci = [round(val - ci_w[0], 3), round(val + ci_w[1], 3)]
        hard = None
        if artifact.get("type") == "video" or sig in ("temporal_coherence", "audio_visual_sync"):
            hard = {**HARD_FACTS_VIDEO, "surface": "nano-banana-pro:stills", "tier": "clip", "as_of": TODAY}
        return SignalResult(
            id=sig, value=round(val, 3), confidence=conf,
            provenance=self._provenance(artifact, "clip" if sig != "aesthetic_predictor" else "aesthetic-v2", "mock-nano-banana", "nano-banana-pro:stills"),
            uncertainty={"method": "heuristic", "ci95": ci}, n=1, hard_facts=hard,
        )

    def health(self) -> Dict[str, Any]:
        return {"ok": True, "latency_ms": 12}


class MockOmniFlashProvider(SignalProvider):
    """Video — Gemini Omni Flash surface. Scores video signals at 720p native."""

    SUPPORTED = ["temporal_coherence", "audio_visual_sync", "clip_score", "aesthetic_predictor", "style_consistency", "drift_delta", "text_image_alignment"]

    def capabilities(self) -> Dict[str, Any]:
        return {
            "signals": self.SUPPORTED,
            "surfaces": ["gemini-omni-flash:video"],
            "tier": "raft-warp",
            "as_of": TODAY,
            "hard_facts": HARD_FACTS_VIDEO,
        }

    def score(self, artifact: Dict[str, Any], prompt: str, options: Optional[Dict[str, Any]] = None) -> SignalResult:
        sig = (options or {}).get("signal_id") or "temporal_coherence"
        h = int(hashlib.sha256((prompt + artifact.get("uri", "") + sig).encode()).hexdigest()[:8], 16)
        rng = random.Random(h)
        table = {
            "temporal_coherence": (0.012 + rng.random() * 0.025, "medium", [0.004, 0.006]),
            "audio_visual_sync": (2.8 + rng.random() * 3.5, "medium", [0.5, 0.8]),
            "clip_score": (0.23 + rng.random() * 0.12, "medium", [0.02, 0.03]),
            "aesthetic_predictor": (4.9 + rng.random() * 1.8, "medium", [0.3, 0.4]),
            "style_consistency": (0.05 + rng.random() * 0.09, "medium", [0.01, 0.02]),
            "drift_delta": (0.07 + rng.random() * 0.18, "medium", [0.02, 0.03]),
        }
        val, conf, ci_w = table.get(sig, (0.5, "low", [0.1, 0.1]))
        ci = [round(val - ci_w[0], 3), round(val + ci_w[1], 3)]
        tier = {"temporal_coherence": "raft-warp", "audio_visual_sync": "syncnet-v2"}.get(sig, "clip")
        hard = {**HARD_FACTS_VIDEO, "surface": "gemini-omni-flash:video", "tier": tier, "as_of": TODAY} if sig in ("temporal_coherence", "audio_visual_sync") or artifact.get("type") == "video" else None
        # also attach hard_facts for any video artifact per R655
        if artifact.get("type") == "video" and hard is None:
            hard = {**HARD_FACTS_VIDEO, "surface": "gemini-omni-flash:video", "tier": tier, "as_of": TODAY}
        return SignalResult(
            id=sig, value=round(val, 3), confidence=conf,
            provenance=self._provenance(artifact, tier, "mock-omni-flash", "gemini-omni-flash:video"),
            uncertainty={"method": "heuristic", "ci95": ci}, n=1, hard_facts=hard,
        )

    def health(self) -> Dict[str, Any]:
        return {"ok": True, "latency_ms": 34}


class UnavailableProvider(SignalProvider):
    """Simulates outage — used to test graceful degradation (R654)."""

    def capabilities(self) -> Dict[str, Any]:
        return {"signals": [], "surfaces": [], "tier": "none", "as_of": TODAY}

    def score(self, artifact: Dict[str, Any], prompt: str, options: Optional[Dict[str, Any]] = None) -> SignalResult:
        sig = (options or {}).get("signal_id") or "clip_score"
        return SignalResult(id=sig, value=None, confidence="unavailable",
                            provenance=self._provenance(artifact, "none", "unavailable-provider", "nano-banana-pro:stills"),
                            fallback="qualitative_only", note="provider unavailable — graceful degradation to qualitative mode")

    def health(self) -> Dict[str, Any]:
        return {"ok": False, "latency_ms": 0, "error": "provider down — fallback to qualitative_only"}


# ---------------------------------------------------------------------------
# Composite scoring helper (Rule 32 §6.6)
# ---------------------------------------------------------------------------

def _sig_get(s, key):
    """Uniform accessor for SignalResult (attr) or dict (key)."""
    if isinstance(s, dict):
        return s.get(key)
    return getattr(s, key, None)

def composite_gate_probability(
    signals: List[Any],
    gate_id: str,
    live_evidence_status: Optional[Dict[str, Any]] = None,
    weights: Optional[List[float]] = None,
) -> Dict[str, Any]:
    """
    Advisory composite: p(pass)=sigmoid(w·z+b). Pre-calibration uses equal weights + p_calibration_pending=true.
    Never invents a calibrated claim while promotionEligible==false.
    Accepts List[SignalResult] OR List[dict] (graceful — test harnesses pass dicts via to_dict()).
    """
    import math
    # graceful fallback — no signals or all null
    if not signals or all(_sig_get(s, "value") is None for s in signals):
        return {"p_pass": None, "confidence": "unavailable", "method": "none", "p_calibration_pending": True, "fallback": "qualitative_only"}
    # filter null values
    signals_nz = [s for s in signals if _sig_get(s, "value") is not None]
    vals = [_sig_get(s, "value") for s in signals_nz]
    if not vals:
        return {"p_pass": None, "confidence": "unavailable", "method": "none", "p_calibration_pending": True, "fallback": "qualitative_only"}
    sigs_for_z = signals_nz
    if weights is None:
        weights = [1.0 / len(vals)] * len(vals)
    # z-score — per-signal type (provisional means, not measured)
    def z_for(v, sid):
        if sid == "clip_score": return (v - 0.30) / 0.08
        if sid == "aesthetic_predictor": return (v - 5.5) / 1.0
        if sid in ("drift_delta", "style_consistency"): return (0.10 - v) / 0.04
        if sid == "temporal_coherence": return (0.02 - v) / 0.01
        if sid == "audio_visual_sync": return (v - 4.0) / 1.5
        return 0
    z = [z_for(v, _sig_get(s, "id")) for v, s in zip(vals, sigs_for_z)]
    logit = sum(w * zi for w, zi in zip(weights, z)) * 1.2 - 0.2
    p = 1 / (1 + math.exp(-logit))
    # confidence is min of inputs
    conf_rank = {"high": 3, "medium": 2, "low": 1, "unavailable": 0}
    confs = [_sig_get(s, "confidence") for s in signals if _sig_get(s, "confidence") != "unavailable"]
    min_conf = min(confs, key=lambda c: conf_rank.get(c, 1)) if confs else "low"
    # calibration honesty
    promo = (live_evidence_status or {}).get("promotionEligible", False) if isinstance(live_evidence_status, dict) else False
    p_pending = not promo
    return {
        "p_pass": round(float(p), 3),
        "confidence": min_conf if min_conf != "unavailable" else "low",
        "method": "equal_weighted" if p_pending else "logistic",
        "p_calibration_pending": p_pending,
        "note": "provisional equal-weighted prior — not calibrated until live evidence" if p_pending else "calibrated logistic",
    }


def get_mock_provider(surface: str) -> SignalProvider:
    if surface.startswith("nano-banana"):
        return MockNanoBananaProvider()
    if surface.startswith("gemini-omni"):
        return MockOmniFlashProvider()
    return MockNanoBananaProvider()
