#!/usr/bin/env python3
"""Fail-closed universal prompt validation for all four modes.

v8.0.3 (A4): the prompt envelope is now split into a PASTE region and a CONTROLLER region.
Before this layer the adapter's required block put `Acceptance:` and `First one-variable
repair:` inside the same block the operator pastes, and this validator *required* them there
- so the only envelope shape that passed was one that injected controller instruction into
the generator (proved live in Track 1: all six campaign prompts carried those lines into the
generator surface). This layer keeps both obligations and separates them:
  * controller fields must be present in the ENVELOPE (unchanged contract), and
  * controller fields must be ABSENT from the PASTE region (new hazard arm), and
  * the craft fields the operator actually pastes must be present INSIDE the paste region.
Legacy unmarked bodies stay legal for one version (PASTE_BOUNDARY_LEGACY warning).
"""
import re


def norm(value):
    return re.sub(r"[^A-Z0-9]+", "_", str(value).upper()).strip("_")


def issue(errors, code, message, **extra):
    errors.append({"code": code, "message": message, **extra})


CONTROLLER_FIELDS = ["Acceptance:", "First one-variable repair:"]
IMAGE_CRAFT_FIELDS = ["Operation:", "Subject/references:", "Composition:", "Style and rendering:"]
VIDEO_CRAFT_FIELDS = ["Subject:", "Action:", "Camera:", "End condition:"]


def split_regions(body):
    """Return (paste_region, controller_region, marked)."""
    m = re.search(r"PASTE-BLOCK-BEGIN(.*?)PASTE-BLOCK-END", body, re.I | re.S)
    if not m:
        return body, "", False
    return m.group(1), body[:m.start()] + body[m.end():], True


def validate(contract, output, errors):
    mode = norm(contract.get("mode"))
    tools = contract.get("tools", {}) if isinstance(contract.get("tools"), dict) else {}
    if mode not in {"A_PHOTOREAL_COMMERCIAL", "B_ANIMATION", "C_MOTION_GRAPHICS", "D_HYBRID_COMPOSITING"}:
        return
    if norm(tools.get("stillGeneration")) != "NANO_BANANA_PRO":
        issue(errors, "STILL_OWNER_DRIFT", str(tools.get("stillGeneration")))
    video = norm(tools.get("videoGeneration", "GEMINI_OMNI_FLASH"))
    if video not in {"GEMINI_OMNI_FLASH", "NONE", "NOT_REQUIRED"}:
        issue(errors, "VIDEO_OWNER_DRIFT", str(tools.get("videoGeneration")))

    text = "\n".join(str(a.get("body", "")) for a in output.get("artifacts", []) if isinstance(a, dict))
    image_blocks = re.findall(r"<!--\s*AVD:NANO_PROMPT\s+([^>]*)-->(.*?)<!--\s*/AVD:NANO_PROMPT\s*-->", text, re.I | re.S)
    video_blocks = re.findall(r"<!--\s*AVD:OMNI_PROMPT\s+([^>]*)-->(.*?)<!--\s*/AVD:OMNI_PROMPT\s*-->", text, re.I | re.S)
    ids = set()

    def check_regions(value, body, craft_fields, prefix):
        paste, controller, marked = split_regions(body)
        if not marked:
            issue(errors, "PASTE_BOUNDARY_LEGACY", f"{value}: envelope has no PASTE-BLOCK markers (legacy shape accepted through 8.0.3)")
            return
        # controller instruction must not reach the generator surface
        for field in CONTROLLER_FIELDS:
            if field.lower() in paste.lower():
                issue(errors, "CONTROLLER_FIELD_IN_PASTE", f"{value}.{field} appears inside PASTE-BLOCK; controller instruction must not be pasted")
        # controller fields still required somewhere in the envelope
        for field in CONTROLLER_FIELDS:
            if field.lower() not in controller.lower() and field.lower() not in body.lower():
                issue(errors, f"{prefix}_FIELD_MISSING", f"{value}.{field}")
        # craft fields required inside the paste region
        for field in craft_fields:
            if field.lower() not in paste.lower():
                issue(errors, f"{prefix}_CRAFT_FIELD_MISSING", f"{value}.{field} is not inside the paste region")

    for metadata, body in image_blocks:
        prompt_id = re.search(r"\bid=([^\s]+)", metadata, re.I)
        framework = re.search(r"\bframework=(NBP-F[1-5])", metadata, re.I)
        if not prompt_id or not framework:
            issue(errors, "NANO_MARKER_INVALID", metadata)
            continue
        value = prompt_id.group(1)
        if value in ids:
            issue(errors, "DUPLICATE_PROMPT_ID", value)
        ids.add(value)
        check_regions(value, body, IMAGE_CRAFT_FIELDS, "NANO")

    for metadata, body in video_blocks:
        prompt_id = re.search(r"\bid=([^\s]+)", metadata, re.I)
        task = re.search(r"\btask=(OM-F[1-5])", metadata, re.I)
        if not prompt_id or not task:
            issue(errors, "OMNI_MARKER_INVALID", metadata)
            continue
        value = prompt_id.group(1)
        if value in ids:
            issue(errors, "DUPLICATE_PROMPT_ID", value)
        ids.add(value)
        check_regions(value, body, VIDEO_CRAFT_FIELDS, "OMNI")
        if task.group(1).upper() in {"OM-F4", "OM-F5"} and "keep everything else the same" not in body.lower():
            issue(errors, "EDIT_LOCK_MISSING", value)