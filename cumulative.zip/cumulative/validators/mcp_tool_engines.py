#!/usr/bin/env python3
"""AVD v8.0.0 MCP tool engines (dependency-free, fail-closed).

Deterministic engine primitives referenced by the mcp/ tool contracts.
Every check is structural/deterministic — none is live proof (X14).

- lint_contract_layer(root): structural lint of mcp/tools/*.json against the
  tool-contract meta schema shape (unique names, required keys, draft 2020-12,
  additionalProperties pinned, cost tier derived from rule 35 s6 catalog).
- check_logic_map(doc): orphan-effect detection over a logic-map document (R3).
- check_vo_timing(vo, edl, tolerance_ms): VO-beat vs EDL span mismatch (R5).
- check_timeline(timeline): track overlap + gap + caption/audio checks (R7).
- check_drift_manifest(anchor, observed): frame-consistency comparison of a
  collected clip against its R4 lock manifest (R6).
- check_tool_output_x14(output): X14 sweep over a tool result envelope
  (AVD-E-3001/3002/3003 semantics).

UTF-8 everywhere; stdlib only.
"""
from pathlib import Path
import json
import re

TIER = {
    "concept_rewrite": "LOW", "logic_map": "LOW", "style_tile": "MED",
    "model_sheet": "MED", "neutral_keyframe": "MED", "short_motion_proof": "HIGH",
    "scratch_vo_timing": "LOW", "editor_mockup": "LOW",
}
RANK = {"LOW": 0, "MED": 1, "HIGH": 2}
REQUIRED_META_KEYS = (
    "gate", "video_touching", "cost_tier", "diagnostic_binding",
    "hard_fact_bindings", "wraps_validators", "retry", "idempotency",
    "security", "fallback", "error_codes",
)


def lint_contract_layer(root="."):
    """Structural lint of the mcp contract layer. Returns violation dicts."""
    root = Path(root)
    violations = []
    tool_files = sorted((root / "mcp" / "tools").glob("*.json"))
    if len(tool_files) != 9:
        violations.append({"code": "AVD-E-1001", "path": "mcp/tools",
                           "expected": "9 tool contracts", "observed": len(tool_files),
                           "remedy": {"action": "fix_input"}})
    names = set()
    for p in tool_files:
        rel = f"mcp/tools/{p.name}"
        try:
            t = json.loads(p.read_text(encoding="utf-8"))
        except Exception as ex:
            violations.append({"code": "AVD-E-1001", "path": rel, "expected": "parsable JSON",
                               "observed": str(ex), "remedy": {"action": "fix_input"}})
            continue
        if not re.match(r"^[a-z][a-z0-9_]{0,63}$", str(t.get("name", ""))):
            violations.append({"code": "AVD-E-1001", "path": rel, "expected": "snake_case name",
                               "observed": t.get("name"), "remedy": {"action": "fix_input"}})
        if t.get("name") in names:
            violations.append({"code": "AVD-E-1001", "path": rel, "expected": "unique name",
                               "observed": t.get("name"), "remedy": {"action": "fix_input"}})
        names.add(t.get("name"))
        for k in ("inputSchema", "outputSchema", "annotations", "_meta"):
            if k not in t:
                violations.append({"code": "AVD-E-1001", "path": rel, "expected": f"{k} present",
                                   "observed": "missing", "remedy": {"action": "fix_input"}})
        meta = (t.get("_meta") or {}).get("io.avd/contract") or {}
        for k in REQUIRED_META_KEYS:
            if k not in meta:
                violations.append({"code": "AVD-E-1001", "path": rel, "expected": f"_meta.io.avd/contract.{k}",
                                   "observed": "missing", "remedy": {"action": "fix_input"}})
        for sk in ("inputSchema", "outputSchema"):
            s = t.get(sk) or {}
            if s.get("type") != "object" or s.get("additionalProperties") is not False:
                violations.append({"code": "AVD-E-1001", "path": f"{rel}#{sk}",
                                   "expected": "object with additionalProperties:false",
                                   "observed": (s.get("type"), s.get("additionalProperties")),
                                   "remedy": {"action": "fix_input"}})
        items = meta.get("diagnostic_binding", {}).get("items", [])
        try:
            want = "LOW" if not items else max((TIER[i] for i in items), key=lambda x: RANK[x])
            if meta.get("cost_tier") != want:
                violations.append({"code": "AVD-E-1001", "path": rel, "expected": f"cost_tier {want}",
                                   "observed": meta.get("cost_tier"), "remedy": {"action": "fix_input"}})
        except KeyError as ex:
            violations.append({"code": "AVD-E-1001", "path": rel, "expected": "rule 35 s6 catalog item",
                               "observed": str(ex), "remedy": {"action": "fix_input"}})
    return violations


def check_logic_map(doc):
    """R3: orphan-effect detection. An effect unreachable from any cause is an orphan."""
    nodes = doc.get("nodes", [])
    edges = doc.get("edges", [])
    adj = {}
    for e in edges:
        adj.setdefault(e.get("from"), []).append(e.get("to"))
    reach = set()
    stack = [n["id"] for n in nodes if n.get("type") == "cause"]
    while stack:
        n = stack.pop()
        if n in reach:
            continue
        reach.add(n)
        stack.extend(adj.get(n, []))
    orphans = [n["id"] for n in nodes if n.get("type") == "effect" and n["id"] not in reach]
    return {"reachable": sorted(reach), "orphans": orphans, "pass": not orphans}


def check_vo_timing(vo, edl, tolerance_ms=250):
    """R5: VO-beat vs EDL span mismatch beyond tolerance."""
    tol = int(tolerance_ms)
    spans = {e["beat_id"]: e["record_out_ms"] - e["record_in_ms"] for e in edl.get("events", [])}
    mismatches = []
    for b in vo.get("beats", []):
        span = spans.get(b["beat_id"])
        if span is None:
            mismatches.append({"beat_id": b["beat_id"], "reason": "no EDL event"})
            continue
        if abs(span - (b["end_ms"] - b["start_ms"])) > tol:
            mismatches.append({"beat_id": b["beat_id"], "reason": "span mismatch beyond tolerance"})
    return {"tolerance_ms": tol, "mismatches": mismatches, "pass": not mismatches}


def check_timeline(timeline):
    """R7: per-track time-order sanity + overlap detection across tracks."""
    issues = []
    for tr in timeline.get("tracks", []):
        events = sorted(tr.get("events", []), key=lambda e: e.get("in_ms", 0))
        for a, b in zip(events, events[1:]):
            if b.get("in_ms", 0) < a.get("out_ms", 0):
                issues.append({"track": tr.get("track"), "kind": "overlap",
                               "events": [a.get("event_id"), b.get("event_id")]})
    return {"issues": issues, "pass": not issues}


def compare_drift_manifest(anchor_manifest, observed_manifest):
    """R6: frame-consistency of a collected clip against its R4 lock manifest.
    Both manifests map sample-id -> {perceptualHash, anchorLockRef}. Comparison is
    exact-hash on locked samples (deterministic), producing CONSISTENT/DRIFT/INDETERMINATE."""
    anchor = {s["id"]: s for s in anchor_manifest.get("samples", [])}
    diffs = []
    indeterminate = []
    for s in observed_manifest.get("samples", []):
        a = anchor.get(s["id"])
        if a is None:
            indeterminate.append({"sample": s["id"], "reason": "not in anchor manifest"})
            continue
        if a.get("anchorLockRef") != s.get("anchorLockRef"):
            diffs.append({"sample": s["id"], "reason": "anchor lock mismatch"})
        elif a.get("perceptualHash") != s.get("perceptualHash"):
            diffs.append({"sample": s["id"], "reason": "hash drift vs locked anchor"})
    if diffs:
        verdict = "DRIFT"
    elif indeterminate:
        verdict = "INDETERMINATE"
    else:
        verdict = "CONSISTENT"
    return {"verdict": verdict, "drifted": diffs, "indeterminate": indeterminate, "pass": verdict == "CONSISTENT"}


def check_tool_output_x14(output):
    """X14 sweep over a tool result envelope.
    - AVD-E-3001: Score without evidence_uri/method/computed_by.
    - AVD-E-3002: status PASS with empty evidence.
    - AVD-E-3003: VERIFIED-PASS assurance under PORTABLE_REFERENCE mode.
    """
    violations = []

    def walk_scores(node, path):
        if isinstance(node, dict):
            keys = set(node)
            if "computed_by" in keys or "evidence_uri" in keys:
                for req in ("value", "method", "evidence_uri", "computed_by"):
                    if req not in node:
                        violations.append({"code": "AVD-E-3001", "path": path, "expected": f"Score.{req}",
                                           "observed": "missing", "remedy": {"action": "fix_input"}})
            for k, v in node.items():
                walk_scores(v, f"{path}.{k}")
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk_scores(v, f"{path}[{i}]")

    walk_scores(output, "$")
    if output.get("status") == "PASS" and not output.get("evidence"):
        violations.append({"code": "AVD-E-3002", "path": "$.evidence", "expected": "PASS => evidence minItems 1",
                           "observed": [], "remedy": {"action": "fix_input"}})
    if output.get("executed_mode") == "PORTABLE_REFERENCE" and output.get("assurance") == "VERIFIED-PASS":
        violations.append({"code": "AVD-E-3003", "path": "$.assurance", "expected": "PLAN-PASS or NONE under PORTABLE_REFERENCE",
                           "observed": "VERIFIED-PASS", "remedy": {"action": "fallback_portable_reference"}})
    return violations


def _self_test():
    """Deterministic self-tests (mirrored by the R658+ regression rows)."""
    lm = check_logic_map({"nodes": [{"id": "c1", "type": "cause"}, {"id": "m1", "type": "mechanism"},
                                    {"id": "e1", "type": "effect"}, {"id": "e2", "type": "effect"}],
                          "edges": [{"from": "c1", "to": "m1"}, {"from": "m1", "to": "e1"}]})
    assert lm["orphans"] == ["e2"]
    vt = check_vo_timing({"header": {"tolerance_ms": 250},
                          "beats": [{"beat_id": "b1", "start_ms": 0, "end_ms": 2000},
                                    {"beat_id": "b2", "start_ms": 2000, "end_ms": 4000}]},
                         {"events": [{"beat_id": "b1", "record_in_ms": 0, "record_out_ms": 2100},
                                     {"beat_id": "b2", "record_in_ms": 2100, "record_out_ms": 4900}]})
    assert [m["beat_id"] for m in vt["mismatches"]] == ["b2"]
    dm = compare_drift_manifest({"samples": [{"id": "s1", "perceptualHash": "aa", "anchorLockRef": "L1"}]},
                                {"samples": [{"id": "s1", "perceptualHash": "bb", "anchorLockRef": "L1"}]})
    assert dm["verdict"] == "DRIFT"
    x14 = check_tool_output_x14({"status": "PASS", "evidence": [], "executed_mode": "PORTABLE_REFERENCE",
                                 "assurance": "VERIFIED-PASS"})
    assert {v["code"] for v in x14} == {"AVD-E-3002", "AVD-E-3003"}
    return True


if __name__ == "__main__":
    ok = _self_test()
    print(json.dumps({"schemaVersion": "8.0.1", "validator": "mcp_tool_engines.py",
                      "pass": ok, "checks": ["logic-map orphan", "vo-timing mismatch",
                                             "drift manifest", "x14 sweep"]}, indent=2))
