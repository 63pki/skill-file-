#!/usr/bin/env python3
"""AVD v8.0.0 MCP contract-layer validator (dependency-free, fail-closed).

Covers the R658-R676 regression rows. Stdlib only; UTF-8; exit 1 on any failure.
Checks: manifest shape + separation, required contract fields, schema pinning,
cost-tier derivation from the rule 35 s6 catalog, hard-fact bindings on
video-touching tools, RULE 03 (no resolution numerals outside HARD_FACTS.json,
no hardcoded maximums beside fact bindings), banned backends absent, X14
schema enforcement, PORTABLE_REFERENCE caps, error registry actionability +
reference integrity, retry/idempotency semantics, security boundary agreement,
prompt-catalog model lock, worksheet coverage, hard-facts staleness hook,
one-variable repair + reserved final slot, meta-tool wraps-not-duplicates,
discovery contract, gate-receipt schema labels, and the engine self-tests.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "validators"))

FAILURES = []
PASSES = []


def check(cond, code, detail):
    if cond:
        PASSES.append(f"{code}: {detail}")
    else:
        FAILURES.append(f"{code}: {detail}")
    return cond


def load(rel):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


TIER = {"concept_rewrite": "LOW", "logic_map": "LOW", "style_tile": "MED", "model_sheet": "MED",
        "neutral_keyframe": "MED", "short_motion_proof": "HIGH", "scratch_vo_timing": "LOW", "editor_mockup": "LOW"}
RANK = {"LOW": 0, "MED": 1, "HIGH": 2}
HF = {"HF-VIDEO-NATIVE-CEILING", "HF-EDIT-CHAIN-MAX", "HF-REPAIR-BUDGET"}
GATE_TOOLS = {"avd_r2_originality_verify", "avd_r3_causality_check", "avd_r4_model_sheet_lock",
              "avd_r5_timing_validate", "avd_r6_generation_execute", "avd_r7_edit_assembly_verify",
              "validate_gate_evidence"}


def tools():
    out = []
    for p in sorted((ROOT / "mcp/tools").glob("*.json")):
        out.append((p.name, json.loads(p.read_text(encoding="utf-8"))))
    return out


def meta(t):
    return t["_meta"]["io.avd/contract"]


def main():
    # R658: manifest shape + tools/resources/prompts separation
    m = load("mcp/server/MCP_SERVER_MANIFEST.json")
    check(len(m.get("tools", [])) == 9 and m.get("protocolVersion") in ("2026-07-28", "2025-06-18"),
          "MCP_MANIFEST_SHAPE", "9 tools, known protocol")
    check(set(m.get("capabilities", {})) >= {"tools", "resources", "prompts"}, "MCP_SEPARATION", "tools/resources/prompts separated")
    names = {t["name"] for _, t in tools()}
    ruris = {r["uri"] for r in load("mcp/resources/RESOURCE_CATALOG.json")["resources"]}
    puris = {p["uri"] for p in load("mcp/prompts/PROMPT_CATALOG.json")["prompts"]}
    check(not (ruris & puris) and len(names) == 9, "MCP_URI_NAMESPACES", "resource/prompt URI sets disjoint; 9 unique tools")

    # R659: required contract fields
    for fn, t in tools():
        ok = re.match(r"^[a-z][a-z0-9_]{0,63}$", t.get("name", "")) is not None
        for k in ("inputSchema", "outputSchema", "annotations", "_meta"):
            ok = k in t and ok
        c = meta(t) if "_meta" in t else {}
        for k in ("gate", "video_touching", "cost_tier", "diagnostic_binding", "hard_fact_bindings",
                  "wraps_validators", "retry", "idempotency", "security", "fallback", "error_codes"):
            ok = k in c and ok
        if not ok:
            check(False, "MCP_CONTRACT_FIELDS", fn)
        else:
            check(True, "MCP_CONTRACT_FIELDS", fn)

    # R660: schemas are objects, draft 2020-12, additionalProperties pinned
    for fn, t in tools():
        ok = True
        for s in (t.get("inputSchema", {}), t.get("outputSchema", {})):
            if s.get("type") != "object" or s.get("additionalProperties") is not False:
                ok = False
            if not str(s.get("$schema", "")).endswith("2020-12/schema"):
                ok = False
        check(ok, "MCP_SCHEMA_PINNING", fn)

    # R661: cost tier == max tier of bound s6 diagnostics
    for fn, t in tools():
        c = meta(t)
        items = c.get("diagnostic_binding", {}).get("items", [])
        want = "LOW" if not items else max((TIER[i] for i in items), key=lambda x: RANK[x])
        check(c.get("cost_tier") == want, "MCP_COST_TIER", f"{fn}: {c.get('cost_tier')} == {want}")

    # R662: video-touching tools bind ALL three hard facts
    for fn, t in tools():
        c = meta(t)
        if c.get("video_touching"):
            check(set(c.get("hard_fact_bindings", [])) == HF, "MCP_HF_BINDINGS", fn)

    # R663: RULE 03 - no resolution numerals outside HARD_FACTS.json in mcp/
    pat = re.compile(r"\b(720|1080|2160|4320)\b|4k|8k|uhd", re.I)
    for p in (ROOT / "mcp").rglob("*"):
        if p.is_file() and p.name != "HARD_FACTS.json":
            check(pat.search(p.read_text(encoding="utf-8")) is None, "MCP_RULE03_NUMERALS", str(p.relative_to(ROOT)))

    # R664: banned backends absent everywhere in mcp/
    bad = re.compile(r"replicate|comfyui|runway|sdxl|stable.?diffusion", re.I)
    for p in (ROOT / "mcp").rglob("*"):
        if p.is_file():
            check(bad.search(p.read_text(encoding="utf-8")) is None, "MCP_BANNED_BACKENDS", str(p.relative_to(ROOT)))

    # R665: X14 structural - PASS=>evidence minItems 1; Score requires evidence
    for fn, t in tools():
        if t.get("name") not in GATE_TOOLS:
            continue
        s = json.dumps(t.get("outputSchema", {}))
        ok = '"const": "PASS"' in s and '"minItems": 1' in s
        for d in (t.get("outputSchema", {}).get("$defs", {}) or {}).values():
            if "evidence_uri" in d.get("properties", {}):
                ok = "evidence_uri" in d.get("required", []) and ok
        check(ok, "MCP_X14_SCHEMA", fn)

    # R666: PORTABLE_REFERENCE cap - fallback PLAN-PASS + conditional assurance
    for fn, t in tools():
        c = meta(t)
        ok = c.get("fallback", {}).get("portable_reference", {}).get("assurance_cap") == "PLAN-PASS"
        if t.get("name") in GATE_TOOLS:
            ok = '"const": "PORTABLE_REFERENCE"' in json.dumps(t.get("outputSchema", {})) and ok
        check(ok, "MCP_PORTABLE_CAP", fn)

    # R667: error codes referenced exist; registry machine-actionable
    reg = load("mcp/errors/ERROR_CODES.json")["codes"]
    for e in reg.values():
        if "retryable" not in e or "action" not in e.get("remedy", {}):
            check(False, "MCP_ERROR_REGISTRY", "remedy not actionable")
            break
    else:
        check(True, "MCP_ERROR_REGISTRY", "all remedies actionable")
    for fn, t in tools():
        for code in meta(t).get("error_codes", []):
            if code not in reg:
                check(False, "MCP_ERROR_REFS", f"{fn}: {code}")
    check(True, "MCP_ERROR_REFS", "all tool error codes registered")

    # R668: retry/idempotency semantics
    for fn, t in tools():
        c = meta(t)
        ok = c.get("idempotency", {}).get("divergence_error") == "AVD-E-6001"
        for op, r in c.get("retry", {}).items():
            if op.startswith(("ISSUE", "COLLECT", "LOCK", "MINT")):
                ok = r.get("mode") in ("AT_MOST_ONCE_PER_KEY", "COLLECT_ONCE", "CAS_RETRY") and ok
            if op in ("VERIFY", "DRIFT_CHECK", "LIST"):
                ok = r.get("mode") == "IDEMPOTENT_UNBOUNDED" and ok
        check(ok, "MCP_RETRY_SEMANTICS", fn)

    # R669: security - ISSUE/LOCK approval-required; verify autonomous
    sec = {(mrow["tool"], mrow["op"]): mrow["execution"] for mrow in load("mcp/security/SECURITY_BOUNDARY.json")["matrix"]}
    for fn, t in tools():
        c = meta(t)
        ok = True
        for op in c.get("retry", {}):
            if op.startswith(("ISSUE", "LOCK")):
                ok = op in c.get("security", {}).get("approval_required_ops", []) and ok
                ok = sec.get((t["name"], op), "").startswith("HUMAN_APPROVAL") and ok
        check(ok, "MCP_SECURITY_BOUNDARY", fn)

    # R670: prompt refs resolve; models locked to the two
    cat = load("mcp/prompts/PROMPT_CATALOG.json")["prompts"]
    uris = {p["uri"] for p in cat}
    ok = True
    for p in cat:
        pm = p.get("_meta", {}).get("io.avd/prompt", {})
        ok = pm.get("model") in ("nano_banana_pro", "gemini_omni_flash") and ok
    for fn, t in tools():
        for u in re.findall(r'"(avd://prompts/[^"]+)"', json.dumps(t)):
            ok = u in uris and ok
    check(ok, "MCP_PROMPT_LOCK", "prompt catalog locked to two models; all refs resolve")

    # R671: worksheets cover every fallback + honest labels
    ruris = {r["uri"] for r in load("mcp/resources/RESOURCE_CATALOG.json")["resources"]}
    ok = True
    for fn, t in tools():
        ws = meta(t).get("fallback", {}).get("portable_reference", {}).get("worksheet", "")
        ok = ws in ruris and ok
    for w in ("R2_ORIGINALITY", "R3_CAUSALITY", "R4_MODEL_SHEET", "R5_TIMING", "R6_GENERATION", "R7_ASSEMBLY", "META_GATE_EVIDENCE"):
        txt = (ROOT / f"mcp/worksheets/{w}.md").read_text(encoding="utf-8")
        ok = "MANUAL/PORTABLE_REFERENCE" in txt and "PLAN-PASS" in txt and ok
    check(ok, "MCP_WORKSHEETS", "worksheets exist, honest labels")

    # R672: hard-facts file shape + staleness hook + executable mirror check
    hf = load("mcp/resources/HARD_FACTS.json")
    check({f["id"] for f in hf["facts"]} == HF, "MCP_HF_FILE", "three fact ids")
    checker_cmd = hf.get("staleness", {}).get("checker", "")
    check("review_by" in hf.get("staleness", {}) and "check_guide_staleness.py" in checker_cmd
          and "--hard-facts" in checker_cmd,
          "MCP_HF_STALENESS", "staleness checker hook present and names the --hard-facts mode")
    # D-50/D-19 (C-P2a branch b): the checker hook is not a pointer, it is
    # executable. Run the advertised mirror check in-process (no subprocess;
    # suite-safe) and fail closed on any divergence between HARD_FACTS.json
    # and its copies (_avd_defs consts, PRODUCTION_STATE consts, the
    # serialization POLICY dict, and the two signal-layer provenance dicts).
    import check_guide_staleness as cgs
    mirror = cgs.check_hard_facts_mirror("mcp/resources/HARD_FACTS.json")

    def _div_detail(d):
        bits = [str(d.get("surface", "?")), str(d.get("kind", "?"))]
        for k in ("fact", "field", "rule", "expectedFromFact", "schemaConst",
                  "expectedFromAvdDefs", "found", "error"):
            if d.get(k) is not None:
                bits.append("{}={!r}".format(k, d[k]))
        return " ".join(bits)

    divs = mirror.get("divergences", [])
    check(mirror.get("mirrorStatus") == "MIRROR-OK" and not divs, "MCP_HF_MIRROR",
          "HARD_FACTS mirror equality-asserted across {} surfaces{}".format(
              len(mirror.get("mirroredSurfaces", [])),
              "; ".join(" | " + _div_detail(d) for d in divs) if divs
              else " (all copies equal HARD_FACTS.json)"))

    # R673: RULE 03 runtime binding - no hardcoded maximum beside fact bindings
    t6 = load("mcp/tools/avd_r6_generation_execute.json")

    def walk(o):
        if isinstance(o, dict):
            if "x-avd-fact-max" in o:
                check("maximum" not in o, "MCP_NO_HARDCODED_MAX", "fact-bound field carries no schema maximum")
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)

    walk(t6)
    check(True, "MCP_NO_HARDCODED_MAX", "sweep complete")

    # R674: one-variable repair + reserved final slot
    s = json.dumps(t6.get("inputSchema", {}))
    check('"maxProperties": 1' in s and "RESERVED_FINAL" in s and "final_slot_authorization" in s,
          "MCP_REPAIR_DISCIPLINE", "one-variable diff + final-slot guard")

    # R675: meta-tool wraps existing validators
    c = meta(load("mcp/tools/validate_gate_evidence.json"))
    check(any("compile_and_validate.py" in w for w in c["wraps_validators"]), "MCP_META_WRAPS", "wraps compile_and_validate")
    check(any("validate_instruction_compliance.py" in w for w in c["wraps_validators"]), "MCP_META_WRAPS", "wraps instruction compliance")

    # R676: discovery contract
    t = load("mcp/tools/avd_list_capabilities.json")
    check(t["outputSchema"]["properties"]["tools"]["minItems"] == 9, "MCP_DISCOVERY", "min 9 tools listed")
    check("sha256" in json.dumps(t["outputSchema"]["properties"]["routing_source"]), "MCP_DISCOVERY", "routing source hashed")
    check(any("probe_host.py" in w for w in meta(t)["wraps_validators"]), "MCP_DISCOVERY", "wraps probe_host")

    # R677 (engine self-tests, deterministic)
    try:
        import mcp_tool_engines as eng
        ok = eng._self_test()
        check(ok, "MCP_ENGINES_SELFTEST", "logic-map/vo-timing/drift/x14 self-tests pass")
    except Exception as ex:
        check(False, "MCP_ENGINES_SELFTEST", str(ex))

    # Gate receipt schema labels (shipped vocabulary; retired labels rejected)
    gs = load("mcp/schema/gate_receipt.schema.json")
    labels = gs["properties"]["gate_label"]["enum"]
    check("originality" in labels and "causality_mechanism" in labels, "MCP_RECEIPT_LABELS", "shipped gate labels")
    check("concept divergence" not in json.dumps(labels) and "reference calibration" not in json.dumps(labels),
          "MCP_RECEIPT_LABELS", "retired labels absent")
    check("tool_calls" in gs.get("required", []), "MCP_RECEIPT_TOOLCALLS", "receipt requires tool_calls")

    # Engine lint pass over the whole contract layer
    try:
        import mcp_tool_engines as eng
        v = eng.lint_contract_layer(ROOT)
        check(not v, "MCP_ENGINES_LINT", "contract layer lints clean" if not v else json.dumps(v)[:300])
    except Exception as ex:
        check(False, "MCP_ENGINES_LINT", str(ex))

    print(json.dumps({
        "schemaVersion": "8.0.1",
        "validator": "validate_mcp_contracts.py",
        "pass": not FAILURES,
        "passed": len(PASSES),
        "failed": len(FAILURES),
        "failures": FAILURES,
    }, indent=2, ensure_ascii=False))
    sys.exit(0 if not FAILURES else 1)


if __name__ == "__main__":
    main()
