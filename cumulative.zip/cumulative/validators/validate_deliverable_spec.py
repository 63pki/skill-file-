#!/usr/bin/env python3
"""AVD v8.0.3 deliverable-spec + accessibility-standards validator (B2; regression R703).

Why this exists. Rule 03 forbids stating frame rate, resolution, loudness target or
platform-safe area as a universal production fact, and rule 12 defers caption speed, safe
zones and loudness to "verify in the app". That is right for volatile PLATFORM SPECS and wrong
for STABLE STANDARDS - WCAG success criteria, EBU R128 and CEA-608/708 are citable, versioned
documents. The result (LM G12) was a skill that was silent about accessibility, plus an
ACCESSIBILITY.md requirement for an "accessibility matrix" that no template implemented.

This validator enforces the class system:
  * every spec field carries a tag (VERIFIED / STABLE-STANDARD / PLATFORM_SPEC / ASSUMPTION-VERIFY);
  * an ASSUMPTION-VERIFY row blocks PASS;
  * a STABLE-STANDARD row must cite a real id from dev/ACCESSIBILITY_STANDARDS.json - a
    fabricated or uncited standard is rejected (the X14 discipline applied to accessibility);
  * the allowlist itself stays dated and citable.

Proof boundary: proves deliverable intent is declared, tagged, and honestly classified, and that
every cited standard exists in the dated allowlist. It does NOT prove a deliverable meets any
standard, is accessible, or has the right geometry - those are inspection verdicts on real media
this prompt-only tree cannot produce.
"""
import io
import json
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent

PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


STD = json.loads((ROOT / "dev/ACCESSIBILITY_STANDARDS.json").read_text(encoding="utf-8"))
STD_IDS = {s.get("id") for s in STD.get("standards", [])}
SPEC = json.loads((ROOT / "templates/DELIVERABLE_SPEC.json").read_text(encoding="utf-8"))
TAGS = {"VERIFIED", "STABLE-STANDARD", "PLATFORM_SPEC", "ASSUMPTION-VERIFY"}
SPEC_FIELDS = ["aspectRatio", "resolutionClass", "durationS", "fpsClass", "audioClass",
               "captionFormat", "safeAreas"]


def spec_verdict(rows):
    """Return (errors, blocking) for a set of deliverable rows."""
    errors, blocking = [], []
    for d in rows:
        did = d.get("deliverableId", "?")
        for f in SPEC_FIELDS:
            cell = d.get(f)
            if not isinstance(cell, dict):
                errors.append(f"SPEC_FIELD_MISSING:{did}.{f}")
                continue
            tag = cell.get("tag")
            if tag not in TAGS:
                errors.append(f"SPEC_FIELD_UNTAGGED:{did}.{f}")
            if tag == "ASSUMPTION-VERIFY":
                blocking.append(f"{did}.{f}")
            if tag == "STABLE-STANDARD":
                ref = cell.get("standardRef")
                if ref is not None and ref not in STD_IDS:
                    errors.append(f"INVENTED_STANDARD_VALUE:{did}.{f}:{ref}")
            if tag == "PLATFORM_SPEC" and not str(cell.get("source", "")).strip():
                errors.append(f"PLATFORM_SPEC_NO_SOURCE:{did}.{f}")
    return errors, blocking


# --- 1. the allowlist is dated, citable, and closed ------------------------------------
check(len(STD_IDS) >= 4, "STANDARDS_PRESENT", f"{len(STD_IDS)} citable standards in the allowlist")
for s in STD.get("standards", []):
    check(bool(s.get("source")) and bool(s.get("lastReviewed")), "STANDARD_CITED_AND_DATED",
          f"{s.get('id')}: source + lastReviewed present")
check("STABLE_STANDARD" in STD.get("classes", {}), "CLASS_SYSTEM_DECLARED",
      "the STABLE_STANDARD / PLATFORM_SPEC / ASSUMPTION_VERIFY classes are declared")
for banned in ["platform's current upload spec", "generator's internal capability constant"]:
    check(any(banned in p for p in STD.get("prohibitedStill", [])), "PROHIBITION_PRESENT",
          f"prohibited: {banned}")

# --- 2. the shipped template is well-formed -------------------------------------------
rows = SPEC.get("deliverables", [])
check(len(rows) >= 2, "TEMPLATE_HAS_DELIVERABLES", f"{len(rows)} deliverable rows (a still and a video)")
errs, blocking = spec_verdict(rows)
check(not errs, "TEMPLATE_SPEC_WELL_FORMED", f"template rows carry valid tags ({errs or 'ok'})")
check(bool(blocking), "TEMPLATE_SIGNOFF_BLOCKS",
      f"the template's own ASSUMPTION-VERIFY rows block PASS until verified: {blocking}")

# --- 3. the enforcement rules bite ----------------------------------------------------
untagged = [dict(rows[0], aspectRatio={"value": "1:1"})]
check(spec_verdict(untagged)[0] != [], "UNTAGGED_FIELD_REJECTED",
      f"an untagged spec field is rejected: {spec_verdict(untagged)[0]}")
invented = [dict(rows[0], audioClass={"value": "x", "tag": "STABLE-STANDARD", "standardRef": "MADE-UP-STANDARD"})]
check(spec_verdict(invented)[0] != [], "INVENTED_STANDARD_REJECTED",
      f"a STABLE-STANDARD row citing an uncited standard is rejected: {spec_verdict(invented)[0]}")
real = [dict(rows[0], audioClass={"value": "muted", "tag": "STABLE-STANDARD", "standardRef": "WCAG-2.1-SC-1.2.2"})]
check(spec_verdict(real)[0] == [], "CITED_STANDARD_ACCEPTED", "a row citing a real allowlist id passes")
nosource = [dict(rows[0], aspectRatio={"value": "16:9", "tag": "PLATFORM_SPEC", "source": ""})]
check(spec_verdict(nosource)[0] != [], "PLATFORM_SPEC_NEEDS_SOURCE",
      "a PLATFORM_SPEC row without a source is rejected (it would be an invented platform fact)")

# --- 4. the accessibility artifact rule has a template (LM G12) ------------------------
tpl_names = {p.name for p in (ROOT / "templates").glob("*.md")}
check("ACCESSIBILITY_MATRIX.md" in tpl_names, "ACCESSIBILITY_MATRIX_TEMPLATE",
      "the ACCESSIBILITY.md required artifact now has a template")
check("AUDIO_DESCRIPTION_SCRIPT.md" in tpl_names, "AUDIO_DESCRIPTION_TEMPLATE",
      "an audio-description script template ships")
acc_rule = (ROOT / "rules/audience/ACCESSIBILITY.md").read_text(encoding="utf-8")
check("accessibility matrix" in acc_rule.lower(), "ACCESSIBILITY_RULE_STILL_REQUIRES_MATRIX",
      "rule 11 still requires the accessibility matrix - the template now satisfies it")

print(json.dumps({
    "schemaVersion": "8.0.3",
    "validator": "validate_deliverable_spec.py",
    "pass": not FAILURES,
    "passed": len(PASSES),
    "failed": len(FAILURES),
    "failures": FAILURES,
    "standards": sorted(STD_IDS),
    "proofBoundary": ("Proves deliverable intent is declared, tagged and honestly classified, and that every cited "
                      "standard exists in the dated allowlist. It does NOT prove a deliverable meets any standard, is "
                      "accessible, or has the right geometry; those are inspection verdicts on real media."),
}, indent=2, ensure_ascii=False))
sys.exit(0 if not FAILURES else 1)