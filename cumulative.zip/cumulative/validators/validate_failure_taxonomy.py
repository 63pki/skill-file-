#!/usr/bin/env python3
"""AVD v8.0.3 failure taxonomy + repair economics + attempt budget (B4; regression R704).

Why this exists. Three measured gaps, in the order they bite money:

1. The controller could not NAME its failures. The diagnostic catalog keys on workflow
   classes and rule 35 §6 forbids a 9th id, so "the still has six fingers / the label is
   gibberish / the clip simmers at the end" routed to neutral_keyframe by elimination, and
   "flicker" appeared nowhere in the rules. dev/GENERATOR_DEFECT_TAXONOMY.json is a LOOKUP
   over generator-artifact defect classes that maps each to repair channels, an EXISTING
   catalog id, and a budget cost - without inventing a diagnostic.

2. The one hard cost rule leaked. policyConstants caps conversational edits (3) and one-variable
   repairs (2), but rule 17's own escape hatch - "After 3, stop. Regenerate from a newly
   approved anchor" - had no counter, no cap and no authorization, and still-image attempts
   had no cap at all. This validator counts attempts and rerolls, RECOMPUTED from the ledger.

3. Diagnostics and generations shared one budget vocabulary while charging different things.
   DIAGNOSTIC_RESULT states "diagnostics never touch delivery edit/repair budgets"; this
   validator keeps the two ledgers separate instead of blending them.

Proof boundary: proves the taxonomy is well-formed against the real catalog, and that attempt
and reroll accounting recomputes correctly from a declared ledger. It does NOT judge whether
any output has any defect, does NOT spend or authorize a generation, and does NOT prove the
operator spent what the ledger says they did.
"""
import io
import json
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent

PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


def load(p):
    return json.loads((ROOT / p).read_text(encoding="utf-8"))


TAX = load("dev/GENERATOR_DEFECT_TAXONOMY.json")
MATRIX = load("dev/DIAGNOSTIC_MATRIX.json")
_catalog = MATRIX.get("catalog", {})
CATALOG_IDS = set(_catalog.keys()) if isinstance(_catalog, dict) else set()
if not CATALOG_IDS:
    # the catalog may be a list of diagnostic entries rather than an id-keyed map
    _catalog = MATRIX.get("catalog", {})
    CATALOG_IDS = {d.get("id") or d.get("diagnostic_id") for d in _catalog
                   if isinstance(d, dict)} if isinstance(_catalog, list) else set()
CATALOG_IDS = {c for c in CATALOG_IDS if c}

# --- 1. taxonomy well-formedness: every class maps to a REAL catalog id ---------------
classes = TAX.get("defectClasses", [])
check(len(classes) >= 8, "TAXONOMY_COVERAGE", f"{len(classes)} generator-artifact defect classes declared")
for dc in classes:
    did = dc.get("defectId", "?")
    mapped = set(dc.get("mapsToCatalog") or [])
    unknown = mapped - CATALOG_IDS
    check(not unknown, "TAXONOMY_MAPS_TO_EXISTING_CATALOG",
          f"{did} maps only to existing catalog ids ({sorted(mapped)}; unknown={sorted(unknown)})")
    chans = dc.get("channelOrder") or []
    check(bool(chans), "TAXONOMY_HAS_CHANNEL_ORDER", f"{did} declares a repair-channel order")
    for ch in chans:
        check(ch in TAX.get("channels", {}), "TAXONOMY_CHANNEL_KNOWN",
              f"{did}: channel {ch!r} is declared in the channel table")
    if dc.get("conversationallyFixable") is False:
        check("prompt_word" not in chans, "TAXONOMY_NO_WASTED_SLOT",
              f"{did}: non-conversational defects never open with a conversational repair")

# --- 2. geometry/audio drift classes must cite the ceiling hard fact -----------------
for did in ("DEF-GEOMETRY-DRIFT", "DEF-DURATION-DRIFT"):
    dc = next((c for c in classes if c.get("defectId") == did), {})
    check(bool(dc.get("hardFactRefs")), "TAXONOMY_DELIVERY_CITES_HARD_FACT",
          f"{did} cites the ceiling hard fact (rule 03: facts by reference, never inlined)")

# --- 3. the attempt budget: attempts and rerolls, recomputed from the ledger ---------
DEFAULT_ATTEMPT_BUDGET = {"stillsPerAsset": 3, "keyframeRegens": 2, "videoRerollsPerShot": 2, "projectRerollCap": None}


def attempt_ledger(entries):
    """Recompute attempts per asset and rerolls per lineage from raw entries."""
    per_asset, per_lineage = {}, {}
    for e in entries:
        per_asset[e.get("assetId", "?")] = per_asset.get(e.get("assetId", "?"), 0) + 1
        if str(e.get("kind", "generation")) == "regeneration":
            root = e.get("lineageRootId", "?")
            per_lineage[root] = per_lineage.get(root, 0) + 1
    return per_asset, per_lineage


def budget_verdict(entries, budget=None):
    """Return breach reasons; empty means within budget."""
    b = dict(DEFAULT_ATTEMPT_BUDGET)
    b.update(budget or {})
    per_asset, per_lineage = attempt_ledger(entries)
    bad = []
    for asset, n in per_asset.items():
        if n > b["stillsPerAsset"]:
            bad.append(f"ATTEMPT_CAP_EXCEEDED:{asset}={n}>{b['stillsPerAsset']}")
    for root, n in per_lineage.items():
        if n > b["videoRerollsPerShot"]:
            bad.append(f"REROLL_CAP_EXCEEDED:{root}={n}>{b['videoRerollsPerShot']}")
    total = sum(per_lineage.values())
    if b.get("projectRerollCap") is not None and total > b["projectRerollCap"]:
        bad.append(f"PROJECT_REROLL_CAP_EXCEEDED:{total}>{b['projectRerollCap']}")
    return bad


check(attempt_ledger([]) == ({}, {}), "LEDGER_EMPTY", "an empty ledger recomputes to zero attempts")
within = [{"assetId": "K1", "kind": "generation"}, {"assetId": "K1", "kind": "generation"}]
check(not budget_verdict(within), "BUDGET_WITHIN", f"2 still attempts within the cap of {DEFAULT_ATTEMPT_BUDGET['stillsPerAsset']}")
over = within + [{"assetId": "K1", "kind": "generation"}, {"assetId": "K1", "kind": "generation"}]
check(budget_verdict(over) != [], "ATTEMPT_CAP_ENFORCED",
      f"4 still attempts breach the cap: {budget_verdict(over)}")
rerolls = [{"assetId": "S1", "kind": "regeneration", "lineageRootId": "L1"} for _ in range(3)]
check(budget_verdict(rerolls) != [], "REROLL_CAP_ENFORCED",
      f"3 rerolls on one lineage breach the cap: {budget_verdict(rerolls)}")
spread = [{"assetId": f"S{i}", "kind": "regeneration", "lineageRootId": f"L{i}"} for i in range(3)]
check(budget_verdict(spread, {"projectRerollCap": 5}) == [], "PROJECT_CAP_HONOURED",
      "3 rerolls across 3 lineages are within a project cap of 5 (each lineage within its own cap)")
check(budget_verdict(spread, {"projectRerollCap": 2}) != [], "PROJECT_CAP_ENFORCED",
      f"the same 3 rerolls breach a project cap of 2: {budget_verdict(spread, {'projectRerollCap': 2})}")

# --- 4. the rule-17 escape hatch is now metered (the leak is closed) ----------------
rule17 = (ROOT / "rules/detailed/17_prompt_iteration_and_repair.md").read_text(encoding="utf-8")
if "regenerate" in rule17.lower():
    check(True, "RULE17_ESCAPE_DOCUMENTED", "rule 17's regenerate escape is documented; the budget now meters it")
else:
    check(False, "RULE17_ESCAPE_DOCUMENTED", "rule 17 escape text not found (review the meter)")

# --- 5. sampling policy is declared (B4: attempts counted, never planned) -----------
check("repairEconomics" in TAX, "REPAIR_ECONOMICS_PRESENT", "the channel cost table ships")
econ = TAX.get("repairEconomics", {})
check(bool(econ.get("channelCost")), "CHANNEL_COSTS_DECLARED", "each repair channel declares its generation cost")
check("postAcceptance" in econ, "POST_ACCEPTANCE_DOCUMENTED",
      "post-acceptance of an invisible defect is documented, not silent")

print(json.dumps({
    "schemaVersion": "8.0.3",
    "validator": "validate_failure_taxonomy.py",
    "pass": not FAILURES,
    "passed": len(PASSES),
    "failed": len(FAILURES),
    "failures": FAILURES,
    "catalogIds": sorted(CATALOG_IDS),
    "defectClasses": [c.get("defectId") for c in classes],
    "proofBoundary": ("Proves the defect taxonomy is well-formed against the real 8-diagnostic catalog and that "
                      "attempt/reroll accounting recomputes from a declared ledger. It does NOT judge whether any "
                      "output has any defect, does not spend or authorize a generation, and does not verify that "
                      "the operator spent what the ledger records."),
}, indent=2, ensure_ascii=False))
sys.exit(0 if not FAILURES else 1)