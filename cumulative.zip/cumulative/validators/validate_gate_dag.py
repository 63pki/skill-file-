#!/usr/bin/env python3
"""AVD v8.0.0 gate-DAG validator (dependency-free, fail-closed).

Validates rules/detailed/35_gate_dag_v800.json:
  1. Parses; declares schemaVersion 8.0.1.
  2. Node set: R0-R8 primary gates present with shipped names; R7/R8 sub-gates;
     join nodes carry no ACTIVE-slot consumption.
  3. Base graph (edges without feedback) is a DAG (topological sort succeeds).
  4. Feedback edges: bounded (maxIterations), target lower topological index,
     carry preserve/reset state, escalation, epoch semantics.
  5. Skip/early-start predicates reference allowed production_state fields only
     (Rule 03); no provider names as constants.
  6. Deadlock invariants I1-I5 present.
  7. Serialization contract points at HANDOFF_PACKET dag_state.
  8. Coupling sentinels: 36 section E still fails-without-STEP-QUEUE and still
     names 39 as scheduler; 00a still routes queue ownership to 39; the DAG
     file itself declares 39 as step-queue owner and does NOT reopen the
     deferred 28/39 consolidation.

Exit 0 = pass; 1 = failures. UTF-8 everywhere.
"""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
DAG = ROOT / "rules/detailed/35_gate_dag_v800.json"

FAILURES = []
PASSES = []


def check(cond, code, detail):
    if cond:
        PASSES.append(f"{code}: {detail}")
    else:
        FAILURES.append(f"{code}: {detail}")
    return cond


ALLOWED_PREDICATE_FIELDS = {
    "project_type", "asset_availability", "audio_assets_exist",
    "character_asset_count", "failure_type", "resolution_target",
    "edit_count", "repair_budget_consumed",
}
PRIMARY_GATES = ["R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"]


def toposort(nodes, edges):
    """Kahn's algorithm. Returns (order, cycle_found)."""
    indeg = {n: 0 for n in nodes}
    for src, dsts in edges.items():
        for d in dsts:
            if d in indeg:
                indeg[d] += 1
    queue = sorted([n for n, d in indeg.items() if d == 0])
    order = []
    while queue:
        n = queue.pop(0)
        order.append(n)
        for d in sorted(edges.get(n, [])):
            if d in indeg:
                indeg[d] -= 1
                if indeg[d] == 0:
                    queue.append(d)
        queue.sort()
    return order, len(order) != len(indeg)


def main():
    if not DAG.exists():
        print(json.dumps({"schemaVersion": "8.0.1", "validator": "validate_gate_dag.py", "pass": False,
                          "failures": ["DAG_FILE_MISSING: rules/detailed/35_gate_dag_v800.json"]}, indent=2))
        sys.exit(1)
    dag = json.loads(DAG.read_text(encoding="utf-8"))

    check(dag.get("schemaVersion") == "8.0.1", "DAG_VERSION", "schemaVersion 8.0.1")
    nodes = dag.get("nodes", {})
    edges = dag.get("edges", {})

    # 1. Primary gates with shipped semantics
    for g in PRIMARY_GATES:
        n = nodes.get(g)
        check(n is not None and n.get("type") == "primary_gate", "DAG_PRIMARY_GATE", f"{g} primary gate present")
    check("R7.TECH" in nodes and "R7.CLIENT" in nodes, "DAG_R7_SUBGATES", "R7 sub-gates present")
    check("R8.TECH" in nodes and "R8.CLIENT" in nodes, "DAG_R8_SUBGATES", "R8 sub-gates present")
    for g in ("R7.CLIENT", "R8.CLIENT"):
        check(nodes.get(g, {}).get("laneModel") == "ASYNC_EXTERNAL", "DAG_ASYNC_EXTERNAL", f"{g} ASYNC_EXTERNAL")
        check(nodes.get(g, {}).get("metadata", {}).get("consumesActiveSlot") is False, "DAG_NO_SLOT", f"{g} consumes no ACTIVE slot")
        check(nodes.get(g, {}).get("metadata", {}).get("timeoutPolicy") == "DEFAULT-DENY", "DAG_TIMEOUT_DENY", f"{g} default-deny timeout")

    # Hard facts on R0/R1 metadata
    r0m = nodes.get("R0", {}).get("metadata", {})
    check(r0m.get("resolutionCeiling") == "720p" and r0m.get("resolutionCeilingFlag") == "mandatory",
          "DAG_R0_CEILING", "R0 720p mandatory flag")
    r4m = nodes.get("R4", {}).get("metadata", {})
    check(r4m.get("repairBudgetTotal") == 2 and r4m.get("repairBudgetReserved") == 1, "DAG_R4_BUDGET", "R4 budget 2/reserved 1")

    # 2. Base graph is a DAG. The base graph is `edges` ALONE; feedback edges are
    # epoch-bounded scheduling directives, not graph edges (that is the acyclicity
    # trick), so they must NOT be added before topological sort.
    base_edges = {k: list(v) for k, v in edges.items()}
    node_ids = set(nodes) | set(edges) | {d for v in edges.values() for d in v}
    order, cycle = toposort(node_ids, base_edges)
    check(not cycle, "DAG_ACYCLIC", f"base graph topologically sorted ({len(order)} nodes)")
    topo_index = {n: i for i, n in enumerate(order)}

    # 3. Feedback edges bounded and backward
    for fb in dag.get("feedbackEdges", []):
        fid = fb.get("id", "?")
        check(isinstance(fb.get("maxIterations"), int) and fb.get("maxIterations") >= 1, "DAG_FB_BOUNDED", f"{fid} maxIterations")
        f, t = fb.get("from"), fb.get("to")
        check(f in topo_index and t in topo_index and topo_index[t] < topo_index[f],
              "DAG_FB_BACKWARD", f"{fid} targets lower topological index ({f} -> {t})")
        check(bool(fb.get("preserveState")) and bool(fb.get("resetState")), "DAG_FB_STATE", f"{fid} preserve/reset lists")
        check("epoch" in str(fb.get("epochSemantics", "")), "DAG_FB_EPOCH", f"{fid} epoch semantics declared")
        esc = fb.get("escalationOnExhaustion", {})
        check(esc.get("action") == "BLOCK", "DAG_FB_ESCALATION", f"{fid} escalates to BLOCK")

    # 4. Predicates: allowed fields only, no provider constants
    pred_specs = []
    for s in dag.get("conditionalSkipRules", []):
        pred_specs.append((s.get("id"), s.get("predicate", {})))
        check(s.get("result") == "N/A" and bool(s.get("reason")), "DAG_SKIP_NA_REASON", f"{s.get('id')} N/A with reason")
    for e in dag.get("earlyStartRules", []):
        pred_specs.append((e.get("id"), e.get("predicate", {})))
    for pid, pred in pred_specs:
        fld = pred.get("field")
        check(fld in ALLOWED_PREDICATE_FIELDS, "DAG_PREDICATE_FIELD", f"{pid}: field {fld} allowed")
    dag_text = DAG.read_text(encoding="utf-8")
    for bad in ("nano_banana", "gemini", "replicate", "comfyui", "runway", "sdxl", "openai", "anthropic"):
        check(bad not in dag_text.lower(), "DAG_NO_PROVIDER_CONSTANTS", f"no provider constant '{bad}' in predicates/graph")

    # 5. Deadlock invariants
    inv = " ".join(dag.get("deadlockPrevention", {}).get("invariants", []))
    for i in ("I1:", "I2:", "I3:", "I4:", "I5:"):
        check(i in inv, "DAG_INVARIANTS", f"invariant {i} present")

    # 6. Serialization
    ser = dag.get("serialization", {}).get("embedInHandoffPacket", {})
    check(ser.get("packetField") == "dag_state", "DAG_SERIALIZATION", "dag_state packet field")
    check("HANDOFF_PACKET" in ser.get("schemaRef", ""), "DAG_SER_REF", "points at HANDOFF_PACKET schema")

    # 7. Ownership + no consolidation reopen
    own = dag.get("ownership", {})
    check(own.get("stepQueueOwner", "").startswith("rules/detailed/39"), "DAG_QUEUE_OWNER", "39 owns the step queue")
    check("NOT reopened" in own.get("admissionProjection", ""), "DAG_NO_CONSOLIDATION_REOPEN", "28/39 consolidation not reopened")
    check("one-way" in own.get("admissionProjection", ""), "DAG_ONE_WAY", "admission projection is one-way")

    # 8. Coupling sentinels in the shipped rule files (36 §E intact + v8 extension)
    r36 = (ROOT / "rules/detailed/36_runtime_activation_compiler.md").read_text(encoding="utf-8")
    check("no STEP QUEUE exists" in r36, "COUPLING_36_STEPQUEUE", "36 §E still fails without STEP QUEUE")
    check("`39` schedules them" in r36, "COUPLING_36_SCHEDULER", "36 still names 39 as scheduler")
    check("E.1 v8.0.0 gate-DAG validation" in r36, "COUPLING_36_E1", "36 §E.1 v8 extension present")
    r00a = (ROOT / "rules/detailed/00a_router.md").read_text(encoding="utf-8")
    check("35_gate_dag_v800.json" in r00a, "COUPLING_00A_LOAD", "00a routes the DAG file")
    check("39_mandatory_next_step_protocol.md" in r00a, "COUPLING_00A_39", "00a still routes 39")
    r35 = (ROOT / "rules/detailed/35_reliability_gate_controller.md").read_text(encoding="utf-8")
    check("7. v8.0.0 gate-DAG mode" in r35, "COUPLING_35_DAG_SECTION", "35 §7 DAG mode present")
    check("OPEN is not ACTIVE" in r35, "COUPLING_35_OPEN_ACTIVE", "OPEN≠ACTIVE stated")
    check("Cross-model evidence rule" in r35, "COUPLING_35_EVIDENCE", "evidence rule intact")

    print(json.dumps({
        "schemaVersion": "8.0.1",
        "validator": "validate_gate_dag.py",
        "pass": not FAILURES,
        "passed": len(PASSES),
        "failed": len(FAILURES),
        "failures": FAILURES,
    }, indent=2, ensure_ascii=False))
    sys.exit(0 if not FAILURES else 1)


if __name__ == "__main__":
    main()
