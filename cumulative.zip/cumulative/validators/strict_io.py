#!/usr/bin/env python3
"""v8.6 strict input layer — shared by every validator.

Three silent-skip classes are closed here, all confirmed by execution against the 8.0.5 tree:

  1. DUPLICATE JSON KEYS. `json.loads('{"a":1,"a":2}')` keeps the LAST value. A file that reads
     FAIL then PASS, and PASSES, is the definition of a silent false-green. Now rejected.
  2. NaN / Infinity. `float('nan') > 600` is False, so NaN slips through numeric comparisons.
     Now rejected at parse time.
  3. ENCODING. `read_text()` without an encoding uses the platform default, so a UTF-16 file
     (what Windows PowerShell's `>` writes) decodes into null-interleaved text and EVERY pattern
     misses. Now: strict UTF-8, with BOM and UTF-16 detected and reported as themselves.

Stdlib only. No network. No learned model. Deterministic.
"""
import json


class StrictInputError(ValueError):
    """Raised for any input this tree refuses to guess about."""


def _no_duplicates(pairs):
    seen = {}
    for k, v in pairs:
        if k in seen:
            raise StrictInputError(f"duplicate JSON key: {k!r} (last value would silently win)")
        seen[k] = v
    return seen


def _no_constants(name):
    raise StrictInputError(f"non-finite JSON constant: {name} (NaN/Infinity break numeric comparisons)")


def strict_loads(text, where=""):
    """Strict JSON parse: duplicate keys and NaN/Infinity are errors, never silent values."""
    try:
        return json.loads(text, object_pairs_hook=_no_duplicates, parse_constant=_no_constants)
    except StrictInputError:
        raise
    except json.JSONDecodeError as e:
        raise StrictInputError(f"{where}: invalid JSON: {e}") from e


def read_bytes_strict(path, where=""):
    """Read raw bytes and decode as STRICT UTF-8.

    Detects and reports — rather than silently mis-decodes — the encodings that made the old
    `read_text()` default silently miss every pattern in the file.
    """
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        raise StrictInputError(f"{where}: UTF-8 BOM present; strip it before validation")
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        raise StrictInputError(f"{where}: UTF-16 file (BOM detected). A UTF-16 file decodes to "
                               f"null-interleaved text under a UTF-8 read, and EVERY pattern misses. "
                               f"Re-save as UTF-8.")
    if b"\x00" in raw[:4096]:
        raise StrictInputError(f"{where}: null bytes in the first 4KB — probably UTF-16 or binary, "
                               f"not text. Previously decoded silently and matched nothing.")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as e:
        raise StrictInputError(f"{where}: not valid UTF-8: {e}") from e


def read_json_strict(path, where=""):
    return strict_loads(read_bytes_strict(path, where), where)