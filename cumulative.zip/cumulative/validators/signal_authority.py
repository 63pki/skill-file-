#!/usr/bin/env python3
"""AVD v8.0.0 signal authority (advisory honesty engine) — NEW module.

This module implements the v8.0.0 advisory signal layer WITHOUT touching the
shipped validators/phase_b_quality.py (whose validate_artifact_quality /
validate_claims functions are imported by other validators). All v8 checks
live here and in this file only.

Checks (regression rows R677+):
  - check_x14: high numeric claim (>=0.90) without evidence -> REJECT (symmetric).
  - check_calibration_honesty: measured/empirical claims while promotionEligible
    ==false -> REJECT; honest provisional -> accept.
  - validate_signal_result: SignalResult shape + graceful degradation.
  - validate_graceful_fallback: no signals -> qualitative fallback, never invented.
  - check_hard_facts: video artifacts carry 720p/3/2.
  - check_rule03: thresholds cite surface/tier/as_of, never stale spec tables.
  - validate_matrix: 8-item catalog discipline, fallbacks in catalog, tiers
    match the canonical MCP tier map.
  - enforce_escalation: LOW x2 -> MED; MED fail -> BLOCK + human.
  - enforce_budget: per-gate and per-project budget caps.
  - validate_gate3_receipt: Rule 31 Gate 3 binary authoritative over signals.
  - validate_diagnostic_result: DIAGNOSTIC_RESULT shape (advisory-only).
  - authorize_diagnostic: matrix decision tree (gate x failure x signals).

Run standalone: validators/signal_authority.py --check all  (exit 0 = pass)
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
VALIDATORS_DIR = Path(__file__).resolve().parent
if str(VALIDATORS_DIR) not in sys.path:
    sys.path.insert(0, str(VALIDATORS_DIR))

LIVE_STATUS = ROOT / "dev" / "LIVE_EVIDENCE_STATUS.json"
MATRIX_PATH = ROOT / "dev" / "DIAGNOSTIC_MATRIX.json"
CATALOG_PATH = ROOT / "dev" / "QUALITY_SIGNALS_CATALOG.json"
STATE_PATH = ROOT / "validators" / "diagnostic_state.json"

HARD_FACTS_VIDEO = {"video_native_ceiling": "720p", "edit_cap": 3, "repair_budget": 2}
TODAY = date(2026, 9, 10)
ALLOWED_DIAGNOSTICS = ["concept_rewrite", "logic_map", "style_tile", "model_sheet", "neutral_keyframe", "short_motion_proof", "scratch_vo_timing", "editor_mockup"]
# Canonical tier map — MUST equal validators/mcp_tool_engines.py TIER and the
# MCP contract layer cost tiers. Derived from catalog budgets (the MCP layer's
# rule-35 §6 binding): style_tile/editor_mockup carry compute budgets and
# validate as MED/LOW respectively against the shipped contracts.
TIER_MAP = {
    "concept_rewrite": "LOW", "logic_map": "LOW", "style_tile": "MED",
    "model_sheet": "MED", "neutral_keyframe": "MED", "short_motion_proof": "HIGH",
    "scratch_vo_timing": "LOW", "editor_mockup": "LOW",
}


def load_json(p: Path) -> Any:
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def is_promotion_eligible() -> bool:
    j = load_json(LIVE_STATUS)
    if not j:
        return False
    return bool(j.get("promotionEligible"))


def parse_date(s: str) -> Optional[date]:
    try:
        return date.fromisoformat(str(s)[:10])
    except Exception:
        return None


def freshness_ok(as_of: str, provisional: bool = True) -> Tuple[bool, str]:
    d = parse_date(as_of)
    if not d:
        return False, f"invalid as_of '{as_of}'"
    delta = (TODAY - d).days
    window = 90 if provisional else 30
    if delta < 0:
        return False, f"as_of {as_of} is in future vs {TODAY}"
    if delta > window:
        return False, f"stale as_of {as_of} ({delta}d > {window}d window)"
    return True, "ok"


def confidence_rank(c: str) -> int:
    return {"high": 3, "medium": 2, "low": 1, "unavailable": 0}.get(c, -1)


# ---------------------------------------------------------------------------
# X14 symmetric: high score without evidence rejected
# ---------------------------------------------------------------------------

def check_x14(receipt: Dict[str, Any]) -> Tuple[bool, str]:
    numeric_score = receipt.get("numeric_score")
    gate_signals = receipt.get("gate_signals") if isinstance(receipt.get("gate_signals"), dict) else {}
    composite = receipt.get("composite") or gate_signals.get("composite") or {}
    p_pass = composite.get("p_pass") if isinstance(composite, dict) else None
    signals = receipt.get("signals") or receipt.get("advisory_signals") or gate_signals.get("signals") or []
    if signals is None:
        signals = []

    claims = []
    if isinstance(numeric_score, (int, float)) and numeric_score >= 0.90:
        claims.append(f"numeric_score {numeric_score}")
    if isinstance(p_pass, (int, float)) and p_pass >= 0.90:
        claims.append(f"composite.p_pass {p_pass}")
    if not claims:
        return True, "pass — no high score claim"

    if not signals:
        return False, f"REJECT X14: {', '.join(claims)} without signals[] — unsupported 9/10 without evidence"
    for s in signals:
        prov = s.get("provenance") or {}
        if not prov.get("artifact_hash"):
            return False, f"REJECT X14: signal {s.get('id')} missing provenance.artifact_hash for {', '.join(claims)}"
        unc = s.get("uncertainty") or {}
        if not unc.get("ci95") and unc.get("std") is None:
            if s.get("confidence") == "unavailable":
                return False, f"REJECT X14: signal {s.get('id')} confidence unavailable cannot support {', '.join(claims)}"
            if not unc:
                return False, f"REJECT X14: signal {s.get('id')} missing uncertainty (ci95/std) for {', '.join(claims)}"
        if s.get("confidence") == "unavailable" and s.get("value") is not None:
            return False, f"REJECT X14: signal {s.get('id')} value present with confidence unavailable — fabricated"
        as_of = prov.get("as_of")
        if as_of:
            ok, msg = freshness_ok(as_of, provisional=True)
            if not ok:
                return False, f"REJECT X14: stale provenance {msg}"
        else:
            return False, f"REJECT X14: signal {s.get('id')} missing provenance.as_of"
    return True, f"pass — high claim {', '.join(claims)} has evidence ({len(signals)} signals with provenance+CI)"


# ---------------------------------------------------------------------------
# Calibration honesty (R653-class)
# ---------------------------------------------------------------------------

def check_calibration_honesty(obj: Dict[str, Any], promotion_eligible: Optional[bool] = None) -> Tuple[bool, str]:
    if promotion_eligible is None:
        promotion_eligible = is_promotion_eligible()
    if promotion_eligible:
        return True, "pass — promotionEligible true, measured claims allowed"

    def walk(o: Any, path: str = "") -> Optional[str]:
        if isinstance(o, dict):
            if "provenance" in o and isinstance(o["provenance"], dict):
                prov = o["provenance"]
                if prov.get("measured") is True:
                    return f"{path}.provenance.measured==true while promotionEligible==false"
                if prov.get("threshold_source") in ("measured", "empirical"):
                    return f"{path}.provenance.threshold_source='{prov.get('threshold_source')}' while promotionEligible==false"
            if "composite" in o and isinstance(o["composite"], dict) and o["composite"].get("p_calibration_pending") is False:
                return f"{path}.composite.p_calibration_pending==false while promotionEligible==false"
            for k, v in o.items():
                if k in ("threshold_claim", "threshold_source", "note", "provenance") and isinstance(v, str):
                    low = v.lower()
                    if ("measured" in low or "empirically proven" in low or "proven pass threshold" in low) and "provisional" not in low and "calibration" not in low and "not_" not in low and "not " not in low:
                        return f"{path}.{k}='{v[:60]}' claims measured without calibration — reject"
                res = walk(v, f"{path}.{k}" if path else k)
                if res:
                    return res
        elif isinstance(o, list):
            for i, item in enumerate(o):
                res = walk(item, f"{path}[{i}]")
                if res:
                    return res
        return None

    reason = walk(obj)
    if reason:
        return False, f"REJECT calibration honesty: {reason} — thresholds are CALIBRATION PROCEDURES with provisional ranges only (promotionEligible==false)"
    return True, "pass — no measured/empirical claim while provisional (honest calibration procedure)"


# ---------------------------------------------------------------------------
# SignalResult / graceful degradation / hard facts
# ---------------------------------------------------------------------------

def validate_signal_result(s: Dict[str, Any]) -> Tuple[bool, str]:
    sid = s.get("id", "?")
    val = s.get("value")
    conf = s.get("confidence")
    prov = s.get("provenance") or {}
    if conf == "unavailable":
        if val is not None:
            return False, f"REJECT: signal {sid} value {val} with confidence unavailable — fabricated (must be null)"
        if s.get("fallback") != "qualitative_only":
            return False, f"REJECT: signal {sid} confidence unavailable requires fallback='qualitative_only'"
        return True, f"pass — {sid} unavailable with graceful fallback"
    if not prov.get("provider") or not prov.get("surface") or not prov.get("tier") or not prov.get("as_of"):
        return False, f"REJECT: signal {sid} missing provenance provider/surface/tier/as_of (Rule 03)"
    if not prov.get("artifact_hash"):
        return False, f"REJECT: signal {sid} missing provenance.artifact_hash"
    if sid in ("audio_visual_sync", "temporal_coherence"):
        hf = s.get("hard_facts")
        if not hf or hf.get("video_native_ceiling") != "720p" or hf.get("edit_cap") != 3 or hf.get("repair_budget") != 2:
            return False, f"REJECT: video signal {sid} missing hard_facts 720p/3/2"
    as_of = prov.get("as_of")
    ok, msg = freshness_ok(as_of, provisional=True)
    if not ok:
        return False, f"REJECT freshness: signal {sid} {msg}"
    if conf not in ("high", "medium", "low", "unavailable"):
        return False, f"REJECT: signal {sid} invalid confidence '{conf}'"
    return True, f"pass — {sid} valid"


def validate_graceful_fallback(receipt: Dict[str, Any]) -> Tuple[bool, str]:
    gate_signals = receipt.get("gate_signals") if isinstance(receipt.get("gate_signals"), dict) else {}
    signals = receipt.get("signals") or gate_signals.get("signals") or []
    composite = receipt.get("composite") or gate_signals.get("composite") or {}
    if not signals:
        if isinstance(composite, dict) and composite.get("confidence") == "unavailable":
            if composite.get("fallback") != "qualitative_only" and receipt.get("fallback") != "qualitative_only":
                if receipt.get("qualitative") or receipt.get("gate_3_verdict"):
                    return True, "pass — no signals but qualitative fallback present (graceful degradation)"
                return False, "REJECT: no signals but no fallback marker"
        if receipt.get("qualitative") and isinstance(receipt.get("qualitative"), dict) and receipt["qualitative"].get("reason"):
            return True, "pass — graceful degradation to qualitative_only (no signals, qualitative present)"
        if receipt.get("fallback") == "qualitative_only":
            return True, "pass — explicit qualitative_only fallback"
        return True, "pass — no signals, degraded to qualitative"
    for s in signals:
        ok, msg = validate_signal_result(s)
        if not ok:
            return False, msg
    return True, "pass — signals valid or gracefully degraded"


def check_hard_facts(obj: Dict[str, Any]) -> Tuple[bool, str]:
    signals = obj.get("signals") or obj.get("advisory_signals") or (obj.get("gate_signals", {}).get("signals") if isinstance(obj.get("gate_signals"), dict) else []) or []
    artifact_type = (obj.get("artifact") or {}).get("type") if isinstance(obj.get("artifact"), dict) else obj.get("artifact_type")
    gate_id = obj.get("gate_id") or obj.get("gate") or ""
    is_video = False
    if artifact_type == "video":
        is_video = True
    if any(s.get("id") in ("audio_visual_sync", "temporal_coherence") for s in signals if isinstance(s, dict)):
        is_video = True
    if any(s.get("hard_facts") for s in signals if isinstance(s, dict)):
        is_video = True
    if gate_id in ("R5", "R7") and obj.get("diagnostic_id") in ("short_motion_proof", "editor_mockup", "scratch_vo_timing"):
        is_video = True
    if not is_video:
        return True, "pass — not a video artifact, hard facts not required"
    hf = obj.get("hard_facts")
    if not hf:
        for s in signals:
            if isinstance(s, dict) and s.get("hard_facts"):
                hf = s["hard_facts"]
                break
    if not hf:
        return False, "REJECT: video artifact missing hard_facts {video_native_ceiling:720p, edit_cap:3, repair_budget:2}"
    if hf.get("video_native_ceiling") != "720p" or hf.get("edit_cap") != 3 or hf.get("repair_budget") != 2:
        return False, f"REJECT: video hard_facts malformed {hf} — must be 720p/3/2"
    return True, "pass — video hard facts present"


# ---------------------------------------------------------------------------
# Rule 03 stale-spec-table detection
# ---------------------------------------------------------------------------

def check_rule03(obj: Dict[str, Any]) -> Tuple[bool, str]:
    suspects = []
    # Descriptive prose that NAMES a banned spec to forbid it is not a spec table.
    # Only numeric threshold rows and capability claims require surface/tier/as_of.
    PROSE_KEYS = {"prohibition", "definition", "description", "formula", "note", "limitations", "video_native_note", "binding_notice", "meaning", "authorized_if", "reasoning", "calibration_procedure", "rule", "requirement", "note_"}

    def walk(o: Any, path: str = ""):
        if isinstance(o, dict):
            keys = set(o.keys())
            is_prose = bool(keys & PROSE_KEYS) and not (keys & {"provisional_range", "advisory_range_provisional", "advisory_threshold_provisional", "threshold_provisional"})
            if not is_prose:
                text = json.dumps(o).lower()
                if any(spec in text for spec in ["4k", "8k", "1080p", '"max_res"', "32k context", "context_length", "max_tokens"]):
                    if not (o.get("surface") and o.get("tier") and o.get("as_of")):
                        suspects.append(f"{path}: hardcodes spec without surface/tier/as_of")
                if ("advisory_range_provisional" in keys or "advisory_threshold_provisional" in keys or "provisional_range" in keys):
                    if not o.get("surface"):
                        if "signal_id" in keys or "signal" in keys:
                            suspects.append(f"{path}: threshold row missing surface (Rule 03)")
            for k, v in o.items():
                walk(v, f"{path}.{k}" if path else k)
        elif isinstance(o, list):
            for i, item in enumerate(o):
                walk(item, f"{path}[{i}]")

    walk(obj)
    if suspects:
        return False, f"REJECT Rule 03: {'; '.join(suspects)} — thresholds must cite surface/tier/as_of, never stale spec tables"
    return True, "pass — no stale spec tables, surface/tier/date present"


def check_av_sync_asymmetry(catalog: Dict[str, Any]) -> Tuple[bool, str]:
    """D-31: AV-sync acceptance tolerance must be ASYMMETRIC (audio-early tighter).

    m1 (prompt-4 corpus L85, ITU-R BT.1359-1 class): audio-late +125 / audio-early
    -45 ms detectability; 'Human perception is asymmetric - audio-early is far
    worse'; 'a symmetric |dt| threshold is a design bug'. m4 (L5835): 'EBU R37
    +40/-60 ms' broadcast basis. The as-shipped catalog carried only a symmetric
    correlation SEARCH window [-200, +200] ms and NO acceptance tolerance.
    """
    for sig in catalog.get("signals", []):
        if sig.get("id") != "audio_visual_sync":
            continue
        tol = sig.get("av_offset_tolerance_provisional")
        if not isinstance(tol, dict):
            return False, "REJECT D-31: audio_visual_sync has no av_offset_tolerance_provisional block (as shipped: symmetric search window only, no acceptance tolerance)"
        if not isinstance(tol.get("audio_early_ms_max"), (int, float)) or not isinstance(tol.get("audio_late_ms_max"), (int, float)):
            return False, "REJECT D-31: av_offset_tolerance_provisional missing numeric audio_early_ms_max / audio_late_ms_max"
        if tol.get("audio_early_ms_max") >= tol.get("audio_late_ms_max"):
            return False, f"REJECT D-31: symmetric-or-inverted tolerance early={tol.get('audio_early_ms_max')} late={tol.get('audio_late_ms_max')} - audio-early must be TIGHTER (m1: 'audio-early is far worse')"
        if "ITU-R BT.1359-1" not in str(tol.get("basis", "")) or "EBU R37" not in str(tol.get("basis", "")):
            return False, "REJECT D-31: tolerance basis must cite both sources (ITU-R BT.1359-1 class frame m1; EBU R37 m4)"
        if tol.get("status") != "provisional":
            return False, "REJECT D-31: tolerance must be status provisional (CALIBRATION_REQUIRED - thresholds are cited-standard provisional ranges, not measured)"
        return True, f"pass — asymmetric AV tolerance early<=/{tol.get('audio_early_ms_max')}ms < late/{tol.get('audio_late_ms_max')}ms, both sources cited, provisional"
    return False, "REJECT D-31: audio_visual_sync signal missing from catalog"


# ---------------------------------------------------------------------------
# Matrix discipline: 8-item catalog, canonical tiers
# ---------------------------------------------------------------------------

def validate_matrix(matrix: Dict[str, Any]) -> Tuple[bool, str]:
    catalog_ids = set(ALLOWED_DIAGNOSTICS)
    edges = matrix.get("edges") or []
    for i, e in enumerate(edges):
        fallback = e.get("fallback_authorized")
        if fallback and fallback not in catalog_ids:
            return False, f"REJECT: edge {i} ({e.get('gate_id')}x{e.get('failure_type')}) fallback_authorized '{fallback}' not in 8-item catalog"
        for field in ("authorized_diagnostic", "diagnostic_id", "candidates"):
            if field in e:
                vals = e[field] if isinstance(e[field], list) else [e[field]]
                for v in vals:
                    if v not in catalog_ids and v is not None:
                        return False, f"REJECT: edge {i} field {field}='{v}' not in catalog"
        txt = json.dumps(e).lower()
        for bad in ["full_motion_generation", "full_motion", "upscale_inspection", "reshoot"]:
            if bad in txt:
                return False, f"REJECT: edge {i} contains invented diagnostic '{bad}' — only 8 catalog ids allowed"
        if e.get("hard_facts_required") and e.get("gate_id") in ("R5", "R7") and not e.get("hard_facts"):
            return False, f"REJECT: edge {i} ({e.get('gate_id')}x{e.get('failure_type')}) hard_facts_required but no hard_facts block"
    catalog = matrix.get("catalog") or []
    for c in catalog:
        cid = c.get("id")
        if cid not in catalog_ids:
            return False, f"REJECT: catalog id '{cid}' not in allowed 8"
        want = TIER_MAP.get(cid)
        if c.get("cost_tier") != want:
            return False, f"REJECT: catalog id '{cid}' cost_tier {c.get('cost_tier')} != canonical {want} (MCP layer agreement)"
    return True, f"pass — {len(edges)} edges, all diagnostics in 8-item catalog, tiers canonical"


# ---------------------------------------------------------------------------
# Escalation + budget
# ---------------------------------------------------------------------------

def enforce_escalation(state: Dict[str, Any], gate_id: str, diagnostic_id: str) -> Tuple[bool, str, str]:
    gate_state = state.get(gate_id) or {}
    if gate_state.get("blocked"):
        return False, f"BLOCKED gate {gate_id} already blocked — human escalation required", "block_human"
    attempts = (gate_state.get("attempts") or {}).get(diagnostic_id, 0)
    tier = TIER_MAP.get(diagnostic_id, "LOW")
    if tier == "LOW" and attempts >= 2:
        return False, f"ESCALATE LOWx2: {diagnostic_id} failed {attempts} times at {gate_id} -> must escalate to MED", "escalate_tier"
    if tier == "MED" and attempts >= 1:
        if diagnostic_id in (gate_state.get("failures") or []):
            return False, f"BLOCK: MED diagnostic {diagnostic_id} failed at {gate_id} -> BLOCK + human escalation", "block_human"
    return True, f"allowed — {diagnostic_id} attempt {attempts+1} at {gate_id}", "re_gate"


def enforce_budget(state: Dict[str, Any], gate_id: str, diagnostic_id: str, matrix: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
    if matrix is None:
        matrix = load_json(MATRIX_PATH) or {}
    catalog = {c["id"]: c for c in matrix.get("catalog", [])}
    per_gate_caps: Dict[str, Dict[str, int]] = {}
    for g in ["R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"]:
        edges = [e for e in matrix.get("edges", []) if e.get("gate_id") == g]
        candidates = set()
        for e in edges:
            candidates.update(e.get("candidates") or [])
        max_h, max_c = 0, 0
        for cid in candidates:
            mb = catalog.get(cid, {}).get("max_budget", {})
            max_h = max(max_h, mb.get("human_minutes", 0))
            max_c = max(max_c, mb.get("compute_cents", 0))
        if max_h == 0:
            max_h = 60
        if max_c == 0:
            max_c = 200
        per_gate_caps[g] = {"human_minutes": max_h * 2, "compute_cents": max_c * 2}
    if gate_id not in per_gate_caps:
        per_gate_caps[gate_id] = {"human_minutes": 120, "compute_cents": 600}
    project_cap_h = int(sum(v["human_minutes"] for v in per_gate_caps.values()) * 0.7)
    project_cap_c = int(sum(v["compute_cents"] for v in per_gate_caps.values()) * 0.7)

    gate_state = state.get(gate_id, {})
    if isinstance(gate_state.get("spend"), dict):
        gate_h = gate_state["spend"].get("human_minutes", 0)
        gate_c = gate_state["spend"].get("compute_cents", 0)
    else:
        gate_h = gate_state.get("spend_human_minutes", 0)
        gate_c = gate_state.get("spend_cents", 0)

    mb = catalog.get(diagnostic_id, {}).get("max_budget", {"human_minutes": 30, "compute_cents": 150})
    req_h = mb.get("human_minutes", 30)
    req_c = mb.get("compute_cents", 150)

    proj_h, proj_c = req_h, req_c
    for gid, gs in state.items():
        if isinstance(gs, dict) and gid.startswith("R"):
            if isinstance(gs.get("spend"), dict):
                proj_h += gs["spend"].get("human_minutes", 0)
                proj_c += gs["spend"].get("compute_cents", 0)
            else:
                proj_h += gs.get("spend_human_minutes", 0)
                proj_c += gs.get("spend_cents", 0)

    cap_h = per_gate_caps[gate_id]["human_minutes"]
    cap_c = per_gate_caps[gate_id]["compute_cents"]
    if gate_h + req_h > cap_h or gate_c + req_c > cap_c:
        return False, f"REJECT budget: gate {gate_id} spend {gate_h}+{req_h}min / {gate_c}+{req_c}c would exceed cap {cap_h}min / {cap_c}c — BLOCK + human escalation"
    if proj_h > project_cap_h or proj_c > project_cap_c:
        return False, f"REJECT budget: project spend {proj_h}min / {proj_c}c would exceed project cap {project_cap_h}min / {project_cap_c}c — BLOCK"
    return True, f"pass — gate {gate_id} spend ok ({gate_h}+{req_h} <= {cap_h}; {gate_c}+{req_c} <= {cap_c}), project {proj_h}<={project_cap_h}"


# ---------------------------------------------------------------------------
# Gate 3 (Rule 31) + DiagnosticResult
# ---------------------------------------------------------------------------

def validate_gate3_receipt(receipt: Dict[str, Any]) -> Tuple[bool, str]:
    verdict = receipt.get("gate_3_verdict") or (receipt.get("gate_3") or {}).get("verdict") or receipt.get("verdict")
    qual = receipt.get("qualitative") or (receipt.get("gate_3") or {}).get("qualitative") or {}
    reason = qual.get("reason") or (receipt.get("qualitative") or {}).get("reason") or receipt.get("reason") or ""
    has_generic = any(kw in str(reason).lower() for kw in ["generic", "stock", "template", "interchangeable", "swap"])
    if has_generic and verdict == "pass":
        override = receipt.get("override") or {}
        if not override.get("applied"):
            return False, "REJECT Gate 3: qualitative cites generic content but verdict is pass — signals are advisory, binary is authoritative (no override logged)"
    ok, msg = check_calibration_honesty(receipt)
    if not ok:
        return False, msg
    ok, msg = check_hard_facts(receipt)
    if not ok:
        return False, msg
    if (receipt.get("override") or {}).get("applied") and not receipt["override"].get("reason"):
        return False, "REJECT: Gate 3 override applied without reason (must cite Rule 32 §5 ladder anchor)"
    return True, "pass — Gate 3 binary authoritative, signals advisory"


def validate_diagnostic_result(res: Dict[str, Any]) -> Tuple[bool, str]:
    for field in ("diagnostic_id", "gate_id", "qualitative", "success_criteria_met", "attempt", "cost", "hard_facts", "next_action"):
        if field not in res:
            return False, f"REJECT diagnostic result: missing '{field}'"
    if res["diagnostic_id"] not in ALLOWED_DIAGNOSTICS:
        return False, f"REJECT: diagnostic_id '{res['diagnostic_id']}' not in 8-item catalog"
    if res["next_action"] not in ("re_gate", "escalate_tier", "block_human"):
        return False, f"REJECT: invalid next_action '{res['next_action']}'"
    if "tier" not in res["cost"]:
        return False, "REJECT: cost.tier missing"
    want_tier = TIER_MAP.get(res["diagnostic_id"])
    if res["cost"].get("tier") != want_tier:
        return False, f"REJECT: cost.tier {res['cost'].get('tier')} != canonical {want_tier} for {res['diagnostic_id']}"
    if res["diagnostic_id"] in ("short_motion_proof", "editor_mockup", "scratch_vo_timing"):
        hf = res.get("hard_facts") or {}
        if hf.get("video_native_ceiling") != "720p" or hf.get("edit_cap") != 3 or hf.get("repair_budget") != 2:
            return False, f"REJECT: diagnostic {res['diagnostic_id']} missing video hard facts 720p/3/2"
    if res["success_criteria_met"] is True and (res.get("qualitative") or {}).get("verdict") == "fail":
        return False, "REJECT: success_criteria_met true but qualitative verdict fail — inconsistent"
    for s in res.get("signals") or []:
        ok, msg = validate_signal_result(s)
        if not ok:
            return False, msg
    ok, msg = check_calibration_honesty(res)
    if not ok:
        return False, msg
    return True, "pass — diagnostic result schema valid"


# ---------------------------------------------------------------------------
# Matrix decision tree
# ---------------------------------------------------------------------------

def authorize_diagnostic(gate_id: str, failure_type: str, signals: List[Dict[str, Any]], state: Optional[Dict[str, Any]] = None, matrix: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if matrix is None:
        matrix = load_json(MATRIX_PATH) or {}
    if state is None:
        state = load_json(STATE_PATH) or {}
    edges = [e for e in matrix.get("edges", []) if e.get("gate_id") == gate_id and e.get("failure_type") == failure_type]
    if not edges:
        return {"authorized_diagnostic": None, "error": f"no matrix edge for {gate_id}x{failure_type}", "fallback": "qualitative_only"}
    edge = edges[0]
    candidates = edge.get("candidates") or []
    fallback = edge.get("fallback_authorized") or (candidates[0] if candidates else None)
    usable = [s for s in signals if s.get("confidence") not in ("unavailable", None) and s.get("value") is not None] if signals else []
    if not usable:
        return {"authorized_diagnostic": fallback, "reasoning": "no usable signals — graceful degradation to lowest-cost candidate (Rule 32 §5 ladder)", "fallback": True, "edge": edge}
    cond = edge.get("signal_condition") or {}
    sig_id = cond.get("signal")
    if sig_id:
        match = next((s for s in usable if s.get("id") == sig_id), None)
        if match:
            val = match["value"]
            if gate_id == "R4" and failure_type == "asset_inconsistency":
                if val > 0.10:
                    return {"authorized_diagnostic": "model_sheet", "reasoning": f"style_consistency sigma {val} >0.10 -> model_sheet (provisional)", "fallback": False, "signal_used": match}
                if val > 0.08:
                    return {"authorized_diagnostic": "neutral_keyframe", "reasoning": f"sigma {val} 0.08-0.10 -> neutral_keyframe", "fallback": False, "signal_used": match}
                return {"authorized_diagnostic": "neutral_keyframe", "reasoning": f"sigma {val} <=0.08 but qualitative fail — neutral_keyframe (override possible)", "fallback": False, "signal_used": match}
            return {"authorized_diagnostic": fallback, "reasoning": f"signal {sig_id}={val} available — authorized {fallback} per edge {gate_id}x{failure_type} (provisional threshold)", "fallback": False, "signal_used": match}
    return {"authorized_diagnostic": candidates[0] if candidates else fallback, "reasoning": f"candidates {candidates} — no tie-break needed, chose first (signals advisory)", "fallback": False}


# ---------------------------------------------------------------------------
# Full runner
# ---------------------------------------------------------------------------

def check_all() -> int:
    ok_all = True
    print("=== signal_authority --check all (v8.0.1) ===")
    print(f"promotionEligible={is_promotion_eligible()}  today={TODAY}  hard_facts=720p/3/2")
    mat = load_json(MATRIX_PATH)
    if mat:
        ok, msg = validate_matrix(mat)
        print(f"[matrix] {msg} — {'PASS' if ok else 'FAIL'}")
        ok_all = ok_all and ok
    else:
        print(f"[matrix] MISSING {MATRIX_PATH} — FAIL")
        ok_all = False
    cat = load_json(CATALOG_PATH)
    if cat:
        ok, msg = check_rule03(cat)
        print(f"[Rule03 catalog] {msg} — {'PASS' if ok else 'FAIL'}")
        ok_all = ok_all and ok
        ok, msg = check_calibration_honesty(cat)
        print(f"[calibration catalog] {msg} — {'PASS' if ok else 'FAIL'}")
        ok_all = ok_all and ok
        ok, msg = check_av_sync_asymmetry(cat)
        print(f"[AV sync asymmetry] {msg} — {'PASS' if ok else 'FAIL'}")
        ok_all = ok_all and ok
    else:
        print(f"[catalog] MISSING {CATALOG_PATH} — FAIL")
        ok_all = False
    # X14: unsupported 9/10 rejected
    ok, msg = check_x14({"gate_id": "R6", "numeric_score": 0.92, "signals": [], "qualitative": {"reason": "looks great"}, "hard_facts": HARD_FACTS_VIDEO})
    passed = not ok
    print(f"[X14 unsupported 9/10] {'PASS (correctly REJECTED)' if passed else 'FAIL (should have rejected)'} — {msg}")
    ok_all = ok_all and passed
    # calibration: measured claim while NOT_RUN rejected
    ok, msg = check_calibration_honesty({"gate_id": "R1", "signals": [{"id": "clip_score", "value": 0.31, "provenance": {"provider": "clip-vit-l14", "surface": "nano-banana-pro:stills", "tier": "clip", "as_of": "2026-09-10", "measured": True, "artifact_hash": "sha256:abc123def4567890"}}], "composite": {"p_pass": 0.7, "confidence": "medium", "method": "logistic", "p_calibration_pending": False}})
    passed = not ok
    print(f"[measured while NOT_RUN] {'PASS (correctly REJECTED)' if passed else 'FAIL'} — {msg}")
    ok_all = ok_all and passed
    # honest provisional passes
    ok, msg = check_calibration_honesty({"gate_id": "R1", "signals": [{"id": "clip_score", "value": 0.31, "confidence": "medium", "uncertainty": {"ci95": [0.27, 0.35]}, "provenance": {"provider": "clip-vit-l14", "surface": "nano-banana-pro:stills", "tier": "clip", "as_of": "2026-09-10", "artifact_hash": "sha256:abc123def4567890"}}], "composite": {"p_pass": 0.64, "confidence": "medium", "method": "equal_weighted", "p_calibration_pending": True, "note": "provisional range 0.26-0.32"}})
    print(f"[honest provisional] {'PASS' if ok else 'FAIL'} — {msg}")
    ok_all = ok_all and ok
    # graceful degradation
    ok, msg = validate_graceful_fallback({"gate_id": "R4", "signals": [], "composite": {"p_pass": None, "confidence": "unavailable", "method": "none", "fallback": "qualitative_only"}, "qualitative": {"reason": "no signal but ladder L5 cited"}, "fallback": "qualitative_only"})
    print(f"[graceful] {'PASS' if ok else 'FAIL'} — {msg}")
    ok_all = ok_all and ok
    # hard facts present / missing
    ok, msg = check_hard_facts({"gate_id": "R5", "artifact": {"type": "video"}, "signals": [{"id": "temporal_coherence", "value": 0.02, "confidence": "medium", "provenance": {"provider": "raft-warp", "surface": "gemini-omni-flash:video", "tier": "raft-warp", "as_of": "2026-09-10", "artifact_hash": "sha256:aaa"}, "hard_facts": HARD_FACTS_VIDEO}]})
    print(f"[hard facts present] {'PASS' if ok else 'FAIL'} — {msg}")
    ok_all = ok_all and ok
    ok, msg = check_hard_facts({"gate_id": "R5", "artifact": {"type": "video"}, "signals": [{"id": "temporal_coherence", "value": 0.02, "confidence": "medium", "provenance": {"provider": "raft-warp", "surface": "gemini-omni-flash:video", "tier": "raft-warp", "as_of": "2026-09-10", "artifact_hash": "sha256:aaa"}}]})
    passed = not ok
    print(f"[missing hard facts correctly REJECTED] {'PASS' if passed else 'FAIL'} — {msg}")
    ok_all = ok_all and passed
    # escalation ladder (concept_rewrite is a genuine LOW diagnostic)
    ok, msg, nxt = enforce_escalation({"R4": {"attempts": {"concept_rewrite": 2}, "failures": ["concept_rewrite"]}}, "R4", "concept_rewrite")
    passed = (not ok) and nxt == "escalate_tier"
    print(f"[LOWx2 -> MED] {'PASS' if passed else 'FAIL'} — {msg} next={nxt}")
    ok_all = ok_all and passed
    ok, msg, nxt = enforce_escalation({"R5": {"attempts": {"model_sheet": 1}, "failures": ["model_sheet"]}}, "R5", "model_sheet")
    passed = (not ok) and nxt == "block_human"
    print(f"[MED fail -> BLOCK] {'PASS' if passed else 'FAIL'} — {msg} next={nxt}")
    ok_all = ok_all and passed
    # budget
    state = load_json(STATE_PATH) or {}
    ok, msg = enforce_budget(state, "R5", "short_motion_proof", mat)
    print(f"[budget R5 short_motion_proof] {'PASS' if ok else 'FAIL'} — {msg}")
    ok_all = ok_all and ok
    # matrix decision tree
    r = authorize_diagnostic("R4", "asset_inconsistency", [{"id": "style_consistency", "value": 0.12, "confidence": "medium"}], state, mat)
    passed = r.get("authorized_diagnostic") == "model_sheet"
    print(f"[authorize R4 asset_inconsistency] {'PASS' if passed else 'FAIL'} — {r.get('reasoning')}")
    ok_all = ok_all and passed
    # providers
    try:
        from signal_provider_interface import MockNanoBananaProvider, MockOmniFlashProvider, composite_gate_probability
        p1 = MockNanoBananaProvider().score({"uri": "test://a.png", "type": "image", "hash": "sha256:aaaa"}, "hero product shot")
        p2 = MockOmniFlashProvider().score({"uri": "test://b.mp4", "type": "video", "hash": "sha256:bbbb"}, "product reveal", {"signal_id": "temporal_coherence"})
        ok1, m1 = validate_signal_result(p1.to_dict())
        ok2, m2 = validate_signal_result(p2.to_dict())
        passed = ok1 and ok2
        print(f"[provider parity] {'PASS' if passed else 'FAIL'} — {m1}; {m2}")
        ok_all = ok_all and passed
        comp = composite_gate_probability([p1, p2], "R6")
        passed = comp.get("p_calibration_pending") is True and comp.get("method") == "equal_weighted"
        print(f"[composite pending] {'PASS' if passed else 'FAIL'} — {json.dumps(comp)[:120]}")
        ok_all = ok_all and passed
    except Exception as ex:
        print(f"[provider parity] FAIL — {ex}")
        ok_all = False
    # catalog/matrix tier agreement with MCP layer
    try:
        import mcp_tool_engines as eng
        passed = eng.TIER == TIER_MAP
        print(f"[tier agreement with MCP layer] {'PASS' if passed else 'FAIL'} — {eng.TIER == TIER_MAP}")
        ok_all = ok_all and passed
    except Exception as ex:
        print(f"[tier agreement] FAIL — {ex}")
        ok_all = False
    print("=" * 60)
    print("ALL CHECKS PASS" if ok_all else "SOME CHECKS FAILED")
    return 0 if ok_all else 1


def main():
    ap = argparse.ArgumentParser(description="signal_authority v8.0.0 advisory honesty engine")
    ap.add_argument("--check", choices=["all", "x14", "calibration_honesty", "gate3", "hard_facts", "rule03", "matrix", "signal", "diagnostic_result", "budget", "escalation", "authorize"], default="all")
    ap.add_argument("--receipt", type=str)
    ap.add_argument("--gate", type=str, default="R4")
    ap.add_argument("--failure", type=str, default="asset_inconsistency")
    args = ap.parse_args()
    if args.check == "all":
        sys.exit(check_all())
    if args.check == "x14":
        data = load_json(Path(args.receipt)) if args.receipt else {"numeric_score": 0.92, "signals": []}
        ok, msg = check_x14(data)
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "calibration_honesty":
        data = load_json(Path(args.receipt)) if args.receipt else {"composite": {"p_calibration_pending": False}}
        ok, msg = check_calibration_honesty(data)
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "gate3":
        data = load_json(Path(args.receipt)) if args.receipt else {}
        ok, msg = validate_gate3_receipt(data)
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "hard_facts":
        data = load_json(Path(args.receipt)) if args.receipt else {}
        ok, msg = check_hard_facts(data)
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "rule03":
        data = load_json(Path(args.receipt)) if args.receipt else load_json(CATALOG_PATH) or {}
        ok, msg = check_rule03(data)
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "matrix":
        ok, msg = validate_matrix(load_json(MATRIX_PATH) or {})
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "signal":
        data = load_json(Path(args.receipt)) if args.receipt else {}
        ok, msg = validate_signal_result(data)
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "diagnostic_result":
        data = load_json(Path(args.receipt)) if args.receipt else {}
        ok, msg = validate_diagnostic_result(data)
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "budget":
        ok, msg = enforce_budget(load_json(STATE_PATH) or {}, args.gate, "short_motion_proof")
        print(msg); sys.exit(0 if ok else 1)
    if args.check == "escalation":
        ok, msg, nxt = enforce_escalation(load_json(STATE_PATH) or {}, args.gate, "style_tile")
        print(f"{msg} next={nxt}"); sys.exit(0 if ok else 1)
    if args.check == "authorize":
        r = authorize_diagnostic(args.gate, args.failure, [])
        print(json.dumps(r, indent=2, default=str)); sys.exit(0)
    print("unknown check"); sys.exit(2)


if __name__ == "__main__":
    main()
