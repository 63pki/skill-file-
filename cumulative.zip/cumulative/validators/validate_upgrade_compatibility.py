#!/usr/bin/env python3
"""Validate path preservation and immutable-guide compatibility against V7.6.0.

A baseline path that is absent from the current tree is not automatically a defect.
Between Release 4 and Release 6 the generation stack was deliberately replaced
(NANO_BANANA/VEO_3_1 -> NANO_BANANA_PRO/GEMINI_OMNI_FLASH) and the per-version test
runners were consolidated. Those are documented migrations, not losses.

So the baseline may carry a ``retiredPaths`` record: path -> {reason, successor}.
A missing path is tolerated only when it is declared retired with a non-empty reason.
Anything else still fails as CANDIDATE_BASELINE_PATH_MISSING, so accidental deletion
remains a blocker.

A path may not be both immutable and retired; that contradiction fails closed.
"""
from pathlib import Path
import argparse, hashlib, json, re

# ====================================================================
# v8.0.0 additions (D-42) - version-detection ladder as real code.
# The 4-tier ladder and the VERSION_IDENTITY_CONFLICT rule were prose in
# MIGRATION_REGISTRY.json; nothing executable enforced them (audit D-42).
# Implemented here per m1's check_schema_version_labels (prompt-5 corpus
# L219-239), adapted to the shipped tree:
#   - m1 read a `versionEnvelope` key; that key never shipped. The shipped
#     envelope is `versionMeta` (same required fields: ruleVersion,
#     producerVersion). The check reads the shipped name.
#   - m1's `--state`/`--lane` artifact validation requires jsonschema and
#     schemas/dist bundles; neither exists in this tree. Out of scope here.
# Tier semantics (MIGRATION_REGISTRY.version_detection_ladder):
#   tier 1 DECLARED         - line-2 schemaVersion
#   tier 2 STRUCTURAL       - versionMeta at line 3 (8.0.0-only structural key)
#   tier 3 SEMANTIC         - value domains (not enumerable structurally; the
#                             sweep's staleness arm covers the label arm)
#   tier 4 EXPLICIT_MARKERS - versionMeta.transformChain/priorDeclaredVersions
# Conflict rule: declared != inferred (tier 1 vs tier 2) is HARD FAILURE.
# ====================================================================

_SV_LINE2 = re.compile(r'^\s*"schemaVersion"\s*:\s*"([^"]+)"\s*,?\s*$')


def _vt(v):
    try:
        return tuple(int(x) for x in v.split('.'))
    except (ValueError, AttributeError):
        return None


def read_line2_schema_version(path):
    """Tier 1 DECLARED: read the line-2 schemaVersion claim."""
    with Path(path).open('r', encoding='utf-8', errors='replace') as f:
        _ = f.readline()
        line2 = f.readline()
    m = _SV_LINE2.match(line2)
    return m.group(1) if m else None


def _package_version(root):
    """Single source of truth for the package version (D-15): RELEASE.json."""
    try:
        return json.loads((root / 'release/RELEASE.json').read_text(encoding='utf-8')).get('version')
    except Exception:
        return None


def infer_structural_version(obj):
    """Tier 2 STRUCTURAL: versionMeta at the head is the 8.0.0 marker."""
    if not isinstance(obj, dict):
        return None, None
    keys = list(obj.keys())
    if 'versionMeta' not in obj:
        return None, keys
    vm = obj.get('versionMeta') or {}
    return (vm.get('ruleVersion') if isinstance(vm, dict) else None), keys


def check_version_labels(root, baseline, package_version):
    """Ladder tier-1/tier-2 sweep + conflict rule over every pinned JSON.

    Exemptions: baseline.labelCheckExemptions (canary, era records, negative
    fixtures, schema-definition catalogs, RELEASE.json itself). The canary is
    exempt by its own canaryContract (mustNeverAppearIn this validator's
    candidate set) and by MIGRATION_REGISTRY hybrid_operation_rules.exemptions.
    """
    findings = []
    exempt = {e.get('path') for e in baseline.get('labelCheckExemptions', []) if isinstance(e, dict)}
    pkg = _vt(package_version or '')
    for rel in sorted(baseline.get('files', {})):
        if not rel.endswith('.json') or rel in exempt:
            continue
        p = root / rel
        if not p.exists():
            continue  # path loss is CANDIDATE_BASELINE_PATH_MISSING (existing check)
        sv = read_line2_schema_version(p)
        if sv is None:
            # Out-of-convention files (schema definitions with $id, MCP contracts
            # with x-avd, catalogs, dev results records) never carried the line-2
            # convention; the VSS R651-class sweep's precedent treats only files
            # whose line-2 HAS a schemaVersion as in-convention, and this check
            # follows that precedent. Recorded as an adaptation of m1's spec,
            # which flagged MISSING on every JSON; in this tree that would demand
            # retro-labeling ~50 files whose designs predate the convention.
            continue
        svt = _vt(sv)
        if svt is None:
            findings.append({'code': 'ARTIFACT_SCHEMA_VERSION_MALFORMED',
                             'message': f'{rel}: schemaVersion {sv!r} is not semver'})
            continue
        if pkg is None:
            findings.append({'code': 'PACKAGE_VERSION_UNREADABLE',
                             'message': 'release/RELEASE.json version field missing/unparsable'})
            continue
        if svt > pkg:
            findings.append({'code': 'ARTIFACT_VERSION_FUTURE',
                             'message': f'{rel}: schemaVersion {sv} > package {package_version}'})
            continue
        try:
            obj = json.loads(p.read_text(encoding='utf-8'))
        except Exception as x:
            findings.append({'code': 'ARTIFACT_UNPARSABLE', 'message': f'{rel}: {x}'})
            continue
        structural, _keys = infer_structural_version(obj)
        # conflict rule: tier-1 declared vs tier-2 structural inference
        if svt >= (8, 0, 0) and structural is None:
            findings.append({'code': 'ARTIFACT_ENVELOPE_MISSING',
                             'message': f'{rel}: schemaVersion {sv} >= 8.0.0 requires versionMeta (D-39 convention; m1 envelope check)'})
        if structural is not None:
            if svt < (8, 0, 0):
                findings.append({'code': 'VERSION_IDENTITY_CONFLICT',
                                 'message': f'{rel}: tier-1 declared {sv} < 8.0.0 but tier-2 structural versionMeta present (undocumented upgrade shape) - registry conflict rule'})
            elif structural != sv:
                findings.append({'code': 'VERSION_IDENTITY_CONFLICT',
                                 'message': f'{rel}: tier-1 declared {sv} != tier-2 versionMeta.ruleVersion {structural} - registry conflict rule'})
            vm = obj.get('versionMeta') or {}
            if isinstance(vm, dict) and 'producerVersion' not in vm:
                findings.append({'code': 'ARTIFACT_ENVELOPE_INCOMPLETE',
                                 'message': f'{rel}: versionMeta missing producerVersion'})
        if svt < (8, 0, 0) and structural is None and rel not in exempt:
            # era label on a non-exempt file: the pin records 7.8.0 for the
            # V7.6.0 pin (exempt); anything else stale needs an exemption or a bump
            findings.append({'code': 'ARTIFACT_SCHEMA_VERSION_STALE',
                             'message': f'{rel}: label {sv} < package {package_version}; exempt via labelCheckExemptions or bump'})
    return findings


def check_baseline_chain(root, baseline):
    """m1 L242-248: previousBaseline {path, sha256} must exist and hash-match."""
    prev = baseline.get('previousBaseline')
    if not prev:
        return [{'code': 'BASELINE_CHAIN_BROKEN', 'message': 'baseline pin previousBaseline {path, sha256} missing'}]
    p = root / prev.get('path', '')
    if not p.is_file():
        return [{'code': 'BASELINE_CHAIN_BROKEN', 'message': f'previous baseline file missing: {prev.get("path")}'}]
    actual = hashlib.sha256(p.read_bytes()).hexdigest()
    return [] if actual == prev.get('sha256') else [
        {'code': 'BASELINE_CHAIN_BROKEN',
         'message': f'{prev.get("path")}: sha256 mismatch (pin declares {prev.get("sha256")}, file is {actual})'}]


def check_ladder_registry_agreement(registry):
    """The code's tier map must equal MIGRATION_REGISTRY's declared ladder."""
    want = {1: 'DECLARED', 2: 'STRUCTURAL', 3: 'SEMANTIC', 4: 'EXPLICIT_MARKERS'}
    try:
        tiers = {t['tier']: t['name'] for t in registry['version_detection_ladder']['tiers']}
    except Exception:
        return [{'code': 'LADDER_REGISTRY_MALFORMED', 'message': 'MIGRATION_REGISTRY version_detection_ladder unreadable'}]
    if tiers != want:
        return [{'code': 'LADDER_REGISTRY_DISAGREEMENT',
                 'message': f'registry tiers {tiers} != implemented {want} (D-42: code may not invent a different ladder)'}]
    if 'VERSION_IDENTITY_CONFLICT' not in str(registry.get('version_detection_ladder', {}).get('conflict_rule', '')):
        return [{'code': 'LADDER_CONFLICT_RULE_MISSING', 'message': 'registry conflict rule must name VERSION_IDENTITY_CONFLICT (the code enforces it)'}]
    return []




def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


BASELINE_RX = re.compile(r'^V(\d+)_(\d+)_(\d+)_RELEASE_(\d+)_BASELINE_HASHES\.json$')


def locate_baseline(root):
    """Find the predecessor baseline: explicit pointer first, then highest version.

    Prefers release/RELEASE.json ``baselineManifest`` so the active baseline is
    declared rather than inferred. Falls back to the highest versioned baseline
    file so the gate keeps working if the pointer is absent.
    """
    rel = root / 'release/RELEASE.json'
    try:
        declared = json.loads(rel.read_text()).get('baselineManifest')
    except Exception:
        declared = None
    if declared:
        p = root / declared
        if p.is_file():
            return p
    cands = []
    for f in (root / 'release').glob('*_BASELINE_HASHES.json'):
        m = BASELINE_RX.match(f.name)
        if m:
            cands.append((tuple(int(g) for g in m.groups()), f))
    if cands:
        return max(cands)[1]
    return root / 'release'


def validate(root):
    root = Path(root).resolve()
    e = []
    advisories = []
    bp = locate_baseline(root)
    if not bp.is_file():
        return [{'code': 'CANDIDATE_BASELINE_MISSING', 'message': str(bp)}]
    try:
        b = json.loads(bp.read_text())
    except Exception as x:
        return [{'code': 'CANDIDATE_BASELINE_PARSE', 'message': str(x)}]

    files = b.get('files', {})
    retired = b.get('retiredPaths', {})
    if not isinstance(retired, dict):
        e.append({'code': 'CANDIDATE_RETIRED_TYPE', 'message': type(retired).__name__})
        retired = {}

    # A retirement must state why. An empty reason is an undocumented deletion.
    for rel, rec in sorted(retired.items()):
        if not isinstance(rec, dict) or not str(rec.get('reason', '')).strip():
            e.append({'code': 'CANDIDATE_RETIREMENT_UNJUSTIFIED', 'message': rel})
        if rel not in files:
            e.append({'code': 'CANDIDATE_RETIREMENT_UNKNOWN_PATH', 'message': rel})

    # Nothing may be declared both immutable and retired.
    for rel in b.get('immutablePaths', []):
        if rel in retired:
            e.append({'code': 'CANDIDATE_IMMUTABLE_AND_RETIRED', 'message': rel})

    current = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    expected = set(files)

    for rel in sorted(expected - current):
        if rel in retired:
            advisories.append({
                'code': 'CANDIDATE_PATH_RETIRED',
                'message': rel,
                'reason': retired[rel].get('reason', ''),
                'successor': retired[rel].get('successor'),
            })
        else:
            e.append({'code': 'CANDIDATE_BASELINE_PATH_MISSING', 'message': rel})

    for rel in b.get('immutablePaths', []):
        p = root / rel
        want = (files.get(rel) or {}).get('sha256')
        if not p.is_file() or sha(p) != want:
            e.append({'code': 'CANDIDATE_IMMUTABLE_DRIFT', 'message': rel})

    # ---- v8.0.0 additions (D-42): ladder as code -------------------------
    release = json.loads((root / 'release/RELEASE.json').read_text(encoding='utf-8'))
    pkg = release.get('version')
    e += check_baseline_chain(root, b)
    registry = None
    reg_path = root / 'templates/MIGRATION_REGISTRY.json'
    if reg_path.is_file():
        registry = json.loads(reg_path.read_text(encoding='utf-8'))
        e += check_ladder_registry_agreement(registry)
    e += check_version_labels(root, b, pkg)

    validate.advisories = advisories
    return e


def main():
    a = argparse.ArgumentParser(description='V8.0.0 upgrade-compatibility gate: baseline paths + version-detection ladder.')
    a.add_argument('root', nargs='?', default=str(Path(__file__).resolve().parents[1]))
    ns = a.parse_args()
    validate.advisories = []
    errors = validate(ns.root)
    out = {
        'validator': 'V8.0.0-UPGRADE-COMPATIBILITY',
        'pass': not errors,
        'errors': errors,
        'retiredPathsAccepted': validate.advisories,
        'proofBoundary': 'Path preservation, declared immutable hashes, and the four-tier '
                         'version-detection ladder (tier-1 declared vs tier-2 structural, '
                         'VERSION_IDENTITY_CONFLICT on mismatch; baseline chain). Declared '
                         'retirements are accepted on their stated reason and are not '
                         'semantic equivalence for every historical behavior.',
    }
    print(json.dumps(out, indent=2))
    raise SystemExit(0 if not errors else 1)


if __name__ == '__main__':
    main()
