#!/usr/bin/env python3
"""AVD v8.0.0 state-layer validator (dependency-free, fail-closed).

Validates:
  1. The five artifact schemas + _avd_defs + PRODUCTION_STATE manifest parse and
     satisfy structural rules (no network resolution; intra-repo refs only).
  2. Example instances under schemas/examples/ conform (hand-rolled checks mirroring
     the schema constraints - the tree's validators are dependency-free by doctrine).
  3. Negative fixtures under schemas/examples/negative_tests/ FAIL as expected.
  4. Embedded AVD:STATE markers parse; duplicate markers in one host fail.
  5. X14: promotionEligible is false everywhere it appears; digests honor
     computed/uncomputed discipline.

Exit code 0 = all pass; 1 = any failure. UTF-8 everywhere.
"""
from pathlib import Path
import json
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

FAILURES = []
PASSES = []


def check(condition, code, detail):
    if condition:
        PASSES.append(f"{code}: {detail}")
    else:
        FAILURES.append(f"{code}: {detail}")
    return condition


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


SEMVER = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
# D-9: a computed digest may never be a placeholder. All-zero and all-f are the
# canonical null-hash placeholders (the pre-binding genesis convention uses all-zero
# in boundArtifactSha256, a DIFFERENT field); a digest claiming digestStatus
# "computed" with either string is a fabricated measurement, not a hash.
SHA256 = re.compile(r"^(?!0{64}$)(?!f{64}$)[0-9a-f]{64}$")
MARKER = re.compile(
    r"<!-- AVD:STATE id=([0-9a-zA-Z-]{4,24}) schema=([^ ]+) version=([^ ]+) "
    r"artifact=([^ ]+) path=([^ ]+) sha256=((?!0{64}$)(?!f{64}$)[0-9a-f]{64}|UNCOMPUTED) -->"
)
FILENAME = re.compile(
    r"^[A-Za-z0-9._-]+_[A-Za-z0-9._-]+_[A-Za-z0-9._-]+_[A-Za-z0-9._-]+_v[0-9]+_(PASS|REVISE|BLOCK|DRAFT|RETIRED)\.[a-z0-9]+$"
)
GATES = {"R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"}
STATUSES = {"PASS", "REVISE", "BLOCK", "NO-SHIP", "N/A", "PENDING"}
CATALOG = {
    "concept-rewrite", "logic-map", "style-tile", "model-sheet",
    "neutral-keyframe", "short-motion-proof", "scratch-vo-timing", "editor-mockup",
}
POLICY = {
    "nativeVideoCeiling": "720p",
    "aboveCeilingPolicy": "upscaled-platform-neutral-finishing-handoff-flagged-R0-R1",
    "maxSequentialConversationalEditsPerClip": 3,
    "oneVariableRepairBudget": 2,
    "finalSlotReserved": True,
}


def validate_policy_constants(obj, where):
    pc = obj.get("policyConstants")
    if not isinstance(pc, dict):
        return check(False, "STATE_POLICY_MISSING", f"{where}: policyConstants object missing")
    ok = True
    for k, v in POLICY.items():
        if pc.get(k) != v:
            ok = check(False, "STATE_POLICY_VALUE", f"{where}.policyConstants.{k} = {pc.get(k)!r}, expected {v!r}") and ok
    return ok


def validate_digest(obj, where):
    # D-9: SHA256 above rejects all-zero/all-f placeholders when digestStatus is
    # "computed" - a claimed measurement must be a real hash, never a null value.
    d = obj.get("digest")
    if not isinstance(d, dict):
        return check(False, "STATE_DIGEST_MISSING", f"{where}: digest object missing")
    # D-14b: the label names the exact stdlib form digests cover (sorted-keys
    # compact UTF-8), not RFC 8785/JCS - the tree never implemented JCS.
    ok = d.get("digestAlgorithm") == "sha256" and d.get("canonicalization") == "JSON-SORTED-KEYS-UTF8"
    status = d.get("digestStatus")
    if status == "computed":
        ok = bool(SHA256.match(str(d.get("digest", "")))) and ok
    elif status == "uncomputed":
        ok = "digest" not in d and ok
    else:
        ok = False
    return check(ok, "STATE_DIGEST_INVALID", f"{where}: digest {json.dumps(d)[:120]}")


def validate_marker(m, where):
    ok = SEMVER.match(m.get("schemaVersion", "")) is not None
    ok = m.get("markerId", "").startswith("AVD-STATE-") and ok
    ok = bool(m.get("schemaId")) and bool(m.get("artifactId")) and bool(m.get("path")) and ok
    return check(ok, "STATE_MARKER_INVALID", f"{where}: marker {json.dumps(m)[:120]}")


def validate_gate_receipt(r, where):
    ok = r.get("gate") in GATES
    ok = r.get("status") in STATUSES and ok
    if r.get("status") == "N/A" and not str(r.get("naReason", "")).strip():
        ok = False
    ok = validate_policy_constants(r, where) and ok
    ok = validate_digest(r.get("artifactRequired", {}), f"{where}.artifactRequired") and ok
    ok = r.get("promotionEligible") is False and ok
    ok = r.get("promotionEligibleInfluence") == "NONE" and ok
    ra = r.get("roleApprovals")
    if isinstance(ra, list) and ra:
        ok = bool(str(r.get("approvedBy", "")).strip()) and ok
        for i, a in enumerate(ra):
            if a.get("decision") in {"APPROVED", "REJECTED", "CONDITIONAL"} and not a.get("evidenceRefs"):
                ok = False
            if a.get("timeoutPolicy") != "DEFAULT-DENY":
                ok = False
    # over-budget video ledger: an explicit request beyond policy caps is a hard fail
    vl = r.get("videoLedgerOverBudget") or r.get("videoLedger")
    if isinstance(vl, dict):
        if vl.get("chainDepth", 0) > 3 or vl.get("repairsUsed", 0) > 2 or vl.get("fourthEditRequested"):
            ok = False
    return check(ok, "STATE_RECEIPT_INVALID", f"{where}: gate receipt violations")


def validate_asset_entry(a, where):
    ok = a.get("status") in {"PASS", "REVISE", "BLOCK", "DRAFT", "RETIRED"}
    ok = FILENAME.match(str(a.get("filename", ""))) is not None and ok
    ok = validate_digest(a, where) and ok
    ok = validate_policy_constants(a, where) and ok
    if a.get("assetClass") == "video":
        vl = a.get("videoLedger")
        ok = isinstance(vl, dict) and vl.get("chainDepth", 99) <= 3 and vl.get("repairsUsed", 99) <= 2 and ok
    ok = a.get("promotionEligible") is False and ok
    return check(ok, "STATE_ASSET_INVALID", f"{where}: asset entry violations")


def validate_handoff(h, where):
    ok = bool(str(h.get("producerVersion", "")).strip())
    ok = h.get("executionProfile") in {"FULL", "CONTROLLED", "INSUFFICIENT"} and ok
    re_ok = set(h.get("resetExempt", [])) <= {"approvalState", "versionMeta", "dagState", "assetLedger", "evidenceChain"}
    ok = re_ok and ok
    if "approvalState" in h.get("resetExempt", []) and h.get("approvalState") is None:
        ok = False
    ok = validate_policy_constants(h, where) and ok
    ok = h.get("promotionEligible") is False and ok
    return check(ok, "STATE_HANDOFF_INVALID", f"{where}: handoff packet violations")


def validate_switch(s, where):
    ok = s.get("fromModel") in {"nano_banana_pro", "gemini_omni_flash"}
    ok = s.get("toModel") in {"nano_banana_pro", "gemini_omni_flash"} and ok
    ok = s.get("executionProfileAfter") == "CONTROLLED" and ok
    vl = s.get("videoLedger", {})
    ok = vl.get("recomputed") is True and ok
    ok = vl.get("chainDepth", 99) <= 3 and ok
    ok = vl.get("repairsUsed", 99) <= 2 and ok
    ok = validate_policy_constants(s, where) and ok
    ok = s.get("promotionEligible") is False and ok
    return check(ok, "STATE_SWITCH_INVALID", f"{where}: model switch packet violations")


def validate_diagnostic(d, where):
    ok = d.get("catalogItem") in CATALOG
    ok = d.get("costTier") in {"LOW", "MED", "HIGH"} and ok
    ok = d.get("promotable") is False and ok
    ok = d.get("gateDecisionAuthority") == "QUALITATIVE_ONLY" and ok
    bl = d.get("budgetLedger", {})
    ok = bl.get("deliveryBudgetTouched") is False and ok
    for i, sr in enumerate(d.get("signalReadings", []) or []):
        if sr.get("authorityClass") != "C_PERCEPTUAL_PROVISIONAL":
            ok = False
        if sr.get("calibrationStatus") != "CALIBRATION_REQUIRED":
            ok = False
        if sr.get("value") is not None and not sr.get("evidenceRefs"):
            ok = False
    ok = validate_policy_constants(d, where) and ok
    ok = d.get("promotionEligible") is False and ok
    return check(ok, "STATE_DIAGNOSTIC_INVALID", f"{where}: diagnostic result violations")


def main():
    # 1. Schemas parse and are structurally sound
    schema_files = [
        "schemas/artifacts/_avd_defs.schema.json",
        "schemas/artifacts/GATE_RECEIPT.schema.json",
        "schemas/artifacts/ASSET_TRACKER_ENTRY.schema.json",
        "schemas/artifacts/HANDOFF_PACKET.schema.json",
        "schemas/artifacts/MODEL_SWITCH_PACKET.schema.json",
        "schemas/artifacts/DIAGNOSTIC_RESULT.schema.json",
        "schemas/PRODUCTION_STATE.schema.json",
    ]
    for sf in schema_files:
        p = ROOT / sf
        if not p.exists():
            check(False, "STATE_SCHEMA_MISSING", sf)
            continue
        try:
            s = load_json(p)
            check(s.get("$schema", "").endswith("2020-12/schema"), "STATE_SCHEMA_DRAFT", f"{sf}: $schema must be 2020-12")
            check("$id" in s, "STATE_SCHEMA_ID", f"{sf}: $id present")
        except Exception as ex:
            check(False, "STATE_SCHEMA_PARSE", f"{sf}: {ex}")

    # no network resolution: refs must be local
    for sf in schema_files:
        p = ROOT / sf
        if not p.exists():
            continue
        text = p.read_text(encoding="utf-8")
        for m in re.finditer(r'"\$ref"\s*:\s*"([^"]+)"', text):
            ref = m.group(1)
            check(not ref.startswith(("http://", "https://")), "STATE_REF_EXTERNAL", f"{sf}: external ref {ref}")

    # 2. Manifest integrity
    try:
        man = load_json(ROOT / "schemas/PRODUCTION_STATE.schema.json")
        arts = man["properties"]["artifactSchemas"]["properties"]
        for k, v in arts.items():
            check((ROOT / v["const"]).exists(), "STATE_MANIFEST_PATH", f"artifactSchemas.{k} -> {v['const']}")
        ccs = man["properties"]["composedContractSchemas"]["properties"]
        for k, v in ccs.items():
            check((ROOT / v["properties"]["path"]["const"]).exists(), "STATE_MANIFEST_CONTRACT", f"composedContractSchemas.{k}")
        check(man["properties"]["promotionLane"]["const"] == "withheld-in-8.0.0", "STATE_LANE", "promotionLane withheld")
    except Exception as ex:
        check(False, "STATE_MANIFEST_INVALID", f"PRODUCTION_STATE.schema.json: {ex}")

    # 3. Positive examples conform
    exdir = ROOT / "schemas/examples"
    validators = {
        "gate-receipt.example.json": validate_gate_receipt,
        "asset-tracker-entry.example.json": validate_asset_entry,
        "handoff-packet.example.json": validate_handoff,
        "model-switch-packet.example.json": validate_switch,
        "diagnostic-result.example.json": validate_diagnostic,
    }
    if exdir.exists():
        for fn, val in validators.items():
            p = exdir / fn
            if not p.exists():
                check(False, "STATE_EXAMPLE_MISSING", fn)
                continue
            try:
                obj = load_json(p)
                check(SEMVER.match(str(obj.get("schemaVersion", ""))) is not None, "STATE_EXAMPLE_VERSION", fn)
                val(obj, fn)
            except Exception as ex:
                check(False, "STATE_EXAMPLE_PARSE", f"{fn}: {ex}")

    # 4. Negative fixtures must FAIL the right check
    negdir = ROOT / "schemas/examples/negative_tests"
    expected_fail = {
        "receipt_over_budget.json": "budget",
        "receipt_score_no_evidence.json": "evidence",
        "switch_hardcoded_cap.json": "cap",
        "asset_bad_name.json": "name",
        "handoff_not_self_describing.json": "producer",
        "digest_placeholder_zero.json": "digest",
        "digest_placeholder_ff.json": "digest",
    }
    if negdir.exists():
        for fn in negdir.glob("*.json"):
            try:
                obj = load_json(fn)
            except Exception as ex:
                check(False, "STATE_NEG_PARSE", f"{fn}: {ex}")
                continue
            if fn.name in expected_fail:
                # fixture must violate its target rule: run the matching validator and require a failure
                vmap = {
                    "receipt_over_budget.json": (validate_gate_receipt, "policy/budget"),
                    "receipt_score_no_evidence.json": (validate_gate_receipt, "evidence"),
                    "switch_hardcoded_cap.json": (validate_switch, "policy/cap"),
                    "asset_bad_name.json": (validate_asset_entry, "policy/name"),
                    "handoff_not_self_describing.json": (validate_handoff, "producer"),
                    # D-9 fixtures: digested directly by validate_digest (no receipt
                    # wrapper) so exactly ONE failure is recorded and popped - the
                    # harness pops a single entry per expected failure. The fixture
                    # object is a bare digestStatusObject.
                    "digest_placeholder_zero.json": (validate_digest, "digest/placeholder-zero"),
                    "digest_placeholder_ff.json": (validate_digest, "digest/placeholder-ff"),
                }
                vf, _ = vmap[fn.name]
                before = len(FAILURES)
                vf(obj, fn.name)
                after = len(FAILURES)
                check(after > before, "STATE_NEG_MUST_FAIL", f"{fn.name}: expected violation, fixture passed")
                # pop the recorded failure so negatives don't poison the tally
                if after > before:
                    FAILURES.pop()
                    PASSES.append(f"STATE_NEG_EXPECTED_FAIL: {fn.name} rejected as designed")

    # 5. Canary: the stale canary must declare 7.4.0 and stay in the tree.
    #    Canary declares 7.4.0 BY DESIGN - a canary that matches the tree version
    #    has been repaired and is a defect.
    canary = ROOT / "test/canary/stale_version_template.json"
    if canary.exists():
        c = load_json(canary)
        check(c.get("schemaVersion") == "7.4.0", "STATE_CANARY_VERSION", "canary must stay stale at 7.4.0 (repaired canary = defect)")
        check(c.get("canaryContract", {}).get("expectedDeclaredVersion") == "7.4.0", "STATE_CANARY_CONTRACT", "canary contract intact")

    # 6. Tree-wide stale-label sweep (R651-class): every shipped JSON under templates/,
    #    schemas/, validators/, dev/ with a line-2 schemaVersion must declare the tree
    #    version. EXEMPT: the canary (immutable fixture) and release/ historical
    #    records (baseline files are era records; rewriting their labels would
    #    falsify history - the retired-names-as-provenance doctrine).
    tree_version = "8.0.1"
    sweep_dirs = ["templates", "schemas", "validators", "dev", "rules"]
    for sd in sweep_dirs:
        base = ROOT / sd
        if not base.exists():
            continue
        for p in base.rglob("*.json"):
            if p == canary:
                continue
            try:
                first = p.read_text(encoding="utf-8").splitlines()
            except Exception:
                continue
            if len(first) >= 2 and "schemaVersion" in first[1]:
                m = re.search(r'"schemaVersion"\s*:\s*"([^"]+)"', first[1])
                if m and m.group(1) != tree_version:
                    # versionMeta migratedFrom may explain a stale label only when the
                    # label was repaired in place (line 2 already bumped). Line-2 stale
                    # labels are hard failures.
                    check(False, "STATE_STALE_LABEL", f"{p.relative_to(ROOT)}: line-2 schemaVersion {m.group(1)} != {tree_version}")

    print(json.dumps({
        "schemaVersion": "8.0.1",
        "validator": "validate_state_serialization.py",
        "pass": not FAILURES,
        "passed": len(PASSES),
        "failed": len(FAILURES),
        "failures": FAILURES,
    }, indent=2, ensure_ascii=False))
    sys.exit(0 if not FAILURES else 1)


if __name__ == "__main__":
    main()
