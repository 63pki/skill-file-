#!/usr/bin/env python3
"""AVD v8.0.0 approval & versioning validator (dependency-free, fail-closed).

Phase 3b regression rows R682+:
  - APPROVAL_ROLE_REGISTRY vs GATE_RECEIPT.schema.json enum agreement
    (roles, vetoClass, decisions; default_gate_assignment covers R0-R8).
  - Approval ledger: append-only discipline, hash chain shape, DEFAULT-DENY,
    UNCOMPUTED digests allowed only in the empty template (never in real entries).
  - Two-ABSOLUTE-veto rule encoded; reversal protocol.
  - reset-exemption: approvalState among rule 19 carry-forward classes.
  - Version detection ladder: 4 tiers present; declared != inferred is HARD
    FAILURE (VERSION_IDENTITY_CONFLICT); canary exempt-forever.
  - Migration registry: declarative transforms with inverses; lossless
    definition = inverse replay reproduces preMigrationSha256; v8->v7 rollback
    BLOCKED for overlay-carrying receipts.
  - videoPolicySnapshot present on video-touching state artifacts
    (MODEL_SWITCH_PACKET carries videoLedger.recomputed=true; HANDOFF_PACKET
    carries the policyConstants block).
  - Evidence validator version sets include 8.0.0 (external + human).
  - compile_and_validate startswith tuples include 8.0.0.
  - (8.0.1: acceptance sets GROW to include 8.0.1; the 8.0.0 literal stays for
    historical artifacts.)

Exit 0 = pass; 1 = failures. UTF-8; stdlib only.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FAILURES = []
PASSES = []


def check(cond, code, detail):
    if cond:
        PASSES.append(f"{code}: {detail}")
    else:
        FAILURES.append(f"{code}: {detail}")
    return cond


def load(rel):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def main():
    reg = load("release/APPROVAL_ROLE_REGISTRY.json")
    receipt = load("schemas/artifacts/GATE_RECEIPT.schema.json")
    ledger = load("templates/APPROVAL_LEDGER.json")
    mig = load("templates/MIGRATION_REGISTRY.json")

    # R682: registry <-> receipt schema enum agreement
    ra = receipt["properties"]["roleApprovals"]["items"]["properties"]
    roles_schema = set(ra["role"]["enum"])
    vetoes_schema = set(ra["vetoClass"]["enum"])
    roles_reg = set(reg["roles"])
    check(roles_schema == roles_reg, "APPROVAL_ENUM_ROLES", f"registry roles == schema enum ({len(roles_reg)} roles)")
    declared_veto_classes = {v["vetoClass"] for v in reg["roles"].values()}
    check(declared_veto_classes <= vetoes_schema - {"NONE"}, "APPROVAL_ENUM_VETO", "every role's vetoClass is in the schema enum")
    check(set(reg["authority_doctrine"]["vetoClasses"]) == vetoes_schema - {"NONE"}, "APPROVAL_VETO_SET", "authority doctrine lists exactly the four veto classes")
    gates_covered = {a["gateId"] for a in reg["default_gate_assignment"]}
    check(gates_covered == {"R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"}, "APPROVAL_GATE_COVERAGE", "default assignment covers R0-R8")
    for a in reg["default_gate_assignment"]:
        for r in a["roles"]:
            check(r in roles_reg, "APPROVAL_ASSIGN_ROLES", f"{a['gateId']}: {r} registered")
    check(reg["gate_to_dag_lane"].get("R7.CLIENT") == "client" and reg["gate_to_dag_lane"].get("R8.CLIENT") == "client",
          "APPROVAL_DAG_LANE", "client lanes match DAG ASYNC_EXTERNAL nodes")

    # R683: veto semantics
    check("Two ABSOLUTE" in reg["authority_doctrine"]["twoAbsoluteRule"], "APPROVAL_TWO_ABSOLUTE", "two-ABSOLUTE rule encoded")
    check(reg["authority_doctrine"]["timeoutPolicy"] == "DEFAULT-DENY", "APPROVAL_DEFAULT_DENY", "DEFAULT-DENY timeout")
    check("promotionEligible" in reg["authority_doctrine"]["promotionDiscipline"], "APPROVAL_NO_PROMO", "approvals never influence promotion")
    check("influence: NONE" in reg["authority_doctrine"]["promotionDiscipline"], "APPROVAL_NO_PROMO", "influence NONE stated")

    # R684: ledger discipline
    check(ledger["protocol"]["appendOnly"] is True, "LEDGER_APPEND_ONLY", "append-only")
    check("prevHash" in ledger["protocol"]["hashChain"], "LEDGER_CHAIN", "hash chain declared")
    check(ledger["protocol"]["timeoutPolicy"] == "DEFAULT-DENY", "LEDGER_DEFAULT_DENY", "DEFAULT-DENY")
    check("REVERSED" in ledger["protocol"]["reversal"], "LEDGER_REVERSAL", "reversal protocol")
    check("UNCOMPUTED" in ledger["digestNote"], "LEDGER_HONESTY", "digests computed at fill time, never fabricated")
    for ent in ledger["entries"]:
        if ent.get("prevHash") == "GENESIS":
            check(ent.get("ledgerHash") == "UNCOMPUTED", "LEDGER_TEMPLATE_DIGEST", "template entry stays UNCOMPUTED (no fabricated hash)")
            check(bool(ent.get("evidenceRefs")), "LEDGER_EVIDENCE", "entry carries evidence refs")
        else:
            check(ent.get("ledgerHash") != "UNCOMPUTED", "LEDGER_REAL_DIGEST", "non-genesis entry has computed hash")
    check(re.fullmatch(r"[0-9a-f]{64}", ledger["entries"][0]["boundArtifactSha256"][0]) is None or ledger["entries"][0]["boundArtifactSha256"][0] == "0" * 64,
          "LEDGER_TEMPLATE_ZERO_HASH", "template binds the all-zero example hash, never an invented real-looking one")

    # R685: version detection ladder
    ladder = mig["version_detection_ladder"]
    tiers = {t["tier"]: t["name"] for t in ladder["tiers"]}
    check(tiers == {1: "DECLARED", 2: "STRUCTURAL", 3: "SEMANTIC", 4: "EXPLICIT_MARKERS"}, "MIGRATION_LADDER", "four-tier ladder present")
    check("HARD FAILURE VERSION_IDENTITY_CONFLICT" in ladder["conflict_rule"], "MIGRATION_CONFLICT", "declared != inferred is hard failure")
    check("canary" in json.dumps(ladder.get("example_catches", [])) or "7.4.0-defect" in json.dumps(ladder.get("example_catches", [])),
          "MIGRATION_DEFECT_CLASS", "ladder documents the 7.4.0-defect class")
    canary = load("test/canary/stale_version_template.json")
    check(canary.get("schemaVersion") == "7.4.0", "MIGRATION_CANARY", "canary stays 7.4.0 forever")
    check("canary" in json.dumps(mig["hybrid_operation_rules"]["exemptions"]), "MIGRATION_CANARY_EXEMPT", "canary listed as permanent exemption")

    # R686: lossless definition + rollback honesty
    check("preMigrationSha256" in mig["lossless_definition"], "MIGRATION_LOSSLESS", "lossless = inverse replay reproduces preMigrationSha256")
    v8v7 = mig["deterministic_field_mappings"]["v8_to_v7"]
    check("BLOCKED" in v8v7["note"], "MIGRATION_ROLLBACK_HONESTY", "overlay-carrying receipts cannot collapse losslessly to v7.8.0")
    semrev = load("templates/SEMANTIC_REVIEW.json")
    tc = semrev.get("versionMeta", {}).get("transformChain", [])
    check("T-V800-SCHEMA-VERSION-BUMP-TO-8-0-0" in tc, "MIGRATION_SEMREV_CHAIN", "SEMANTIC_REVIEW carries the executed transform chain")
    dp = semrev.get("versionMeta", {}).get("defectProvenance", {})
    check(dp.get("priorDeclaredVersions") == ["7.4.0"], "MIGRATION_SEMREV_PRIOR", "priorDeclaredVersions honest")

    # R686b: template version-convention sweep (D-39 — 22/23 became 23/23;
    # as shipped, no in-tree check could detect the gap)
    tpl_dir = ROOT / "templates"
    tpl_files = sorted(p.name for p in tpl_dir.glob("*.json"))
    check(len(tpl_files) == 23, "TPL_SWEEP_COUNT", f"{len(tpl_files)} templates swept")
    for name in tpl_files:
        obj = json.loads((tpl_dir / name).read_text(encoding="utf-8"))
        keys_head = list(obj.keys())[:3] if isinstance(obj, dict) else []
        check(obj.get("schemaVersion") == "8.0.1", "TPL_SCHEMA_VERSION", f"{name}: line-2 schemaVersion 8.0.1")
        check("versionMeta" in obj, "TPL_VERSIONMETA", f"{name}: line-3 versionMeta present")
        vm = obj.get("versionMeta", {})
        check(keys_head[:1] == ["schemaVersion"] and keys_head[1:2] == ["versionMeta"],
              "TPL_HEAD_ORDER", f"{name}: schemaVersion then versionMeta head the file")
        check(vm.get("ruleVersion") == "8.0.1" and vm.get("producerVersion") == "ai-visual-director-production@8.0.1"
              and vm.get("migratedFrom") in ("7.4.0", "7.6.0", "7.8.0", "8.0.0"),
              "TPL_VERSIONMETA_SHAPE", f"{name}: versionMeta shape (ruleVersion/producerVersion/migratedFrom)")

    # R687: videoPolicySnapshot discipline
    switch = load("schemas/artifacts/MODEL_SWITCH_PACKET.schema.json")
    vl = json.dumps(switch)
    check('"videoLedger"' in vl and '"recomputed"' in vl and "true" in vl.lower(), "VIDEOPOLICY_SWITCH", "MODEL_SWITCH_PACKET recomputes videoLedger at switch")
    handoff = load("schemas/artifacts/HANDOFF_PACKET.schema.json")
    hp = json.dumps(handoff)
    check("resetExempt" in hp, "VIDEOPOLICY_RESET_EXEMPT", "HANDOFF_PACKET declares reset-exempt classes")
    check("dagState" in hp, "VIDEOPOLICY_DAG", "HANDOFF_PACKET carries dagState")
    # approvalState among reset-exempt classes (rule 19)
    rule19 = (ROOT / "rules/detailed/19_production_memory.md").read_text(encoding="utf-8")
    check("`approvalState`" in rule19 and "reset-exempt" in rule19, "VIDEOPOLICY_19_EXEMPT", "rule 19 lists approvalState as reset-exempt")

    # R688: version acceptance sets include 8.0.0 (and, from 8.0.1, 8.0.1)
    ext = (ROOT / "validators/validate_external_evidence.py").read_text(encoding="utf-8")
    check("'8.0.0'" in ext and "'8.0.1'" in ext, "VERSION_SETS_EXTERNAL", "external evidence validator accepts 8.0.0 and 8.0.1")
    hum = (ROOT / "validators/validate_human_evidence.py").read_text(encoding="utf-8")
    check("'8.0.0'" in hum and "'8.0.1'" in hum, "VERSION_SETS_HUMAN", "human evidence validator accepts 8.0.0 and 8.0.1")
    cav = (ROOT / "validators/compile_and_validate.py").read_text(encoding="utf-8")
    check(cav.count("'8.0.1'") >= 4, "VERSION_SETS_COMPILE", f"compile_and_validate startswith tuples include 8.0.1 ({cav.count(chr(39)+'8.0.1'+chr(39))} sites)")

    # registry format discipline
    for rid, r in reg["roles"].items():
        check(re.fullmatch(r"[a-z][a-z0-9_]{2,31}", rid) is not None, "APPROVAL_ROLE_ID", f"{rid} id pattern")
        check("role_id" not in r or r.get("role_id", rid) == rid, "APPROVAL_ROLE_ID", f"{rid} self-consistent")

    print(json.dumps({
        "schemaVersion": "8.0.1",
        "validator": "validate_approval_versioning.py",
        "pass": not FAILURES,
        "passed": len(PASSES),
        "failed": len(FAILURES),
        "failures": FAILURES,
    }, indent=2, ensure_ascii=False))
    sys.exit(0 if not FAILURES else 1)


if __name__ == "__main__":
    main()
