#!/usr/bin/env python3
"""AVD v8.0.3 model-sheet craft gate (A3; regression R700).

Why this exists: rule 13 §"True model-sheet gate" required a model-sheet prompt to request
eight elements (front/three-quarter/side/back views; neutral pose and consistent scale;
expression row; action/gesture row; palette and outline/shading reference;
shadow/contact/attachment point; identity anchors and forbidden-change list; neutral
background). The r4 contract's `views` enum could express only six members and had
minItems 1, so a recurring character could LOCK on views:[FRONT] while the craft gate
returned REVISE CHARACTER SCHEMA. This validator makes the craft gate executable and binds
the enum to it: a LOCK is refused when the view set cannot satisfy the gate for the declared
subject kind.

Proof boundary: proves the declared view set satisfies rule 13's element list for the declared
subject kind. It does NOT prove the generated sheet has one consistent silhouette, anatomy,
proportion, palette or style rule - that is an inspection verdict on real media, which this
prompt-only tree cannot produce.
"""
import io
import json
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent

PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


def load(p):
    return json.loads((ROOT / p).read_text(encoding="utf-8"))


R4 = load("mcp/tools/avd_r4_model_sheet_lock.json")
issue_anchor = R4["inputSchema"]["properties"]["issue_anchor"]["properties"]
ENUM = set(issue_anchor["views"]["items"]["enum"])
SUBJECT_KINDS = set(issue_anchor["subject_kind"]["enum"])

# Rule 13's element list, expressed against the widened enum. Each entry is one craft
# element and the enum members that can express it.
CRAFT_ELEMENTS = {
    "view_angles": {"FRONT", "THREE_QUARTER", "SIDE", "BACK"},
    "expression_row": {"EXPRESSION_ROW"},
    "action_gesture_row": {"ACTION_GESTURE_ROW"},
    "palette_outline": {"PALETTE_OUTLINE_ROW"},
    "contact_shadow": {"CONTACT_ATTACHMENT"},
    "label_macro": {"LABEL_MACRO"},
    "detail_mechanism": {"DETAIL_MECHANISM"},
    "scale_reference": {"SCALE_REFERENCE"},
}
# Side-view aliases: the craft rule says "side"; both spellings satisfy the element.
ALIASES = {"SIDE": {"SIDE", "PROFILE"}, "PROFILE": {"PROFILE", "SIDE"}}

# Which elements each subject kind must carry. Rule 13's eight-element list governs a
# recurring CHARACTER; a Mode A product needs the label/mechanism/scale elements instead
# (before v8.0.3 no enum member existed for those at all).
REQUIRED_BY_KIND = {
    "character": ["view_angles", "expression_row", "action_gesture_row", "palette_outline", "contact_shadow"],
    "product": ["view_angles", "label_macro", "detail_mechanism", "scale_reference"],
    "environment": ["view_angles"],
}
MINIMUM_SETS = REQUIRED_BY_KIND  # the required set IS the minimum set, per element


def satisfies(views, kind):
    """Return the craft elements this declared view set fails to express, for this kind."""
    present = set(views)
    unmet = []
    for element in REQUIRED_BY_KIND[kind]:
        options = CRAFT_ELEMENTS[element]
        ok = any((ALIASES.get(o, {o}) & present) for o in options)
        if not ok:
            unmet.append(element)
    return unmet


# --- 1. the enum can express rule 13's craft elements -------------------------------
for element, options in CRAFT_ELEMENTS.items():
    check(bool(options & ENUM), f"ENUM_EXPRESSES_{element.upper()}",
          f"craft element {element} is expressible (needs one of {sorted(options)})")
check(bool(ALIASES["SIDE"] & ENUM) and bool(ALIASES["PROFILE"] & ENUM),
      "ENUM_SIDE_ALIASES", "SIDE and PROFILE both accepted for the craft rule's side view")

# --- 2. the pre-fix hole is closed: a one-view lock no longer passes -----------------
unmet_frontend = satisfies(["FRONT"], "character")
check(bool(unmet_frontend), "SINGLE_VIEW_LOCK_REJECTED",
      f"views:[FRONT] for a character is unmet on {sorted(unmet_frontend)}")

# --- 3. a complete craft set passes ---------------------------------------------------
full_character = ["FRONT", "THREE_QUARTER", "SIDE", "BACK", "EXPRESSION_ROW",
                  "ACTION_GESTURE_ROW", "PALETTE_OUTLINE_ROW", "CONTACT_ATTACHMENT"]
check(not satisfies(full_character, "character"), "FULL_CHARACTER_SET_PASSES",
      "a character sheet carrying rule 13's view/row/contact elements passes")
check(not satisfies(["FRONT", "THREE_QUARTER", "BACK", "LABEL_MACRO", "DETAIL_MECHANISM",
                     "SCALE_REFERENCE"], "product"), "FULL_PRODUCT_SET_PASSES",
      "a product sheet with label macro + mechanism detail + scale passes")
check(bool(satisfies(["FRONT", "BACK"], "product")), "PRODUCT_LABEL_MACRO_REQUIRED",
      "a product sheet without LABEL_MACRO is unmet (Mode A could not request one before 8.0.3)")

# --- 4. the craft rule and the enum agree (no drift) ---------------------------------
rule13 = (ROOT / "rules/detailed/13_animation_manual.md").read_text(encoding="utf-8")
for phrase in ["front, three-quarter, side, and back", "expression row", "action/gesture row",
               "palette and outline/shading reference", "shadow/contact/attachment point",
               "identity anchors and forbidden-change list"]:
    check(phrase.lower() in rule13.lower(), "RULE13_ELEMENT_PRESENT",
          f"rule 13 still declares: {phrase!r}")
check("REVISE CHARACTER SCHEMA" in rule13, "RULE13_VERDICT_TOKENS",
      "rule 13's machine-verdict token is present for the validator to quote")

# --- 5. subject_kind is a closed enum the minimum sets cover -------------------------
check(SUBJECT_KINDS == set(MINIMUM_SETS), "MINIMUM_SETS_COVER_SUBJECT_KINDS",
      f"every subject kind has a minimum set ({sorted(SUBJECT_KINDS)})")
check(bool(issue_anchor.get("subject_kind", {}).get("enum")), "SUBJECT_KIND_PRESENT",
      "issue_anchor declares subject_kind")

print(json.dumps({
    "schemaVersion": "8.0.3",
    "validator": "validate_model_sheet_gate.py",
    "pass": not FAILURES,
    "passed": len(PASSES),
    "failed": len(FAILURES),
    "failures": FAILURES,
    "enumSize": len(ENUM),
    "requiredByKind": {k: list(v) for k, v in REQUIRED_BY_KIND.items()},
    "proofBoundary": ("Proves the declared view set satisfies rule 13's element list for the declared "
                      "subject kind, and that the enum can express every craft element. It does NOT "
                      "prove the generated sheet has one consistent silhouette, anatomy, proportion, "
                      "palette or style rule - that is an inspection verdict on real media this "
                      "prompt-only tree cannot produce."),
}, indent=2, ensure_ascii=False))
sys.exit(0 if not FAILURES else 1)