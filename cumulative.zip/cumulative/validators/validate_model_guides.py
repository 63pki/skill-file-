#!/usr/bin/env python3
"""AVD v8.0.3 model-guide registry validator (B6; regression R706).

Why this exists. The kernel's locked-model rule was hardcoded as literal tuples inside
validator code (validate_mcp_contracts L180, validate_state_serialization L304-305), so a new
model was a code edit rather than data. Separately, a second literal namespace was shipped
WRONG and unvalidated: templates/PROJECT_CONTRACT.json declared nanoBananaFrameworks
NB-F1..NB-F5 and omniTasks V-F1..V-F5, while the adapters and the prompt validator use
NBP-F1..F5 and OM-F1..F5 - the contract that configures prompt validation named ids the
validator rejects, and nothing checked.

This validator makes both namespaces data-resolved:
  * every id in the guide registry must appear in the adapter it claims to come from;
  * the contract template's declared ids must equal the registry's (no second hand-typed copy);
  * every model needs an official guide, a snapshot date and surface facts with dates;
  * no validator may still carry a hardcoded model-name tuple (grep-equivalence guard).

Proof boundary: proves the registry, the adapters and the contract template agree on ids, and
that every locked model has a dated guide. It does NOT prove a model exists, that its snapshot
is current, or that the surface behaves as declared - capability verification is a runtime
step and a stale snapshot is declared staleness.
"""
import io
import json
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent

PASSES, FAILURES = [], []


def check(ok, code, msg):
    (PASSES if ok else FAILURES).append(f"{code}: {msg}")


GUIDES = json.loads((ROOT / "mcp/model_guides/LOCKED_MODELS.json").read_text(encoding="utf-8"))
models = GUIDES.get("lockedModels", [])

# --- 1. every declared id must actually appear in the adapter it cites ---------------
for m in models:
    mid = m.get("modelId", "?")
    adapter = ROOT / m.get("adapterUri", "")
    check(adapter.is_file(), "GUIDE_FILE_EXISTS", f"{mid}: adapter {m.get('adapterUri')} exists")
    if adapter.is_file():
        text = adapter.read_text(encoding="utf-8")
        for key, label in (("frameworkIds", "framework"), ("taskIds", "task")):
            for ident in m.get(key, []) or []:
                check(ident in text, "GUIDE_ID_IN_ADAPTER",
                      f"{mid}: {label} id {ident} appears in {adapter.name}")
    check(bool(m.get("officialGuideUri")), "GUIDE_URI_DECLARED", f"{mid}: official guide uri declared")
    check(bool(re.match(r"^\d{4}-\d{2}-\d{2}$", str(m.get("snapshotDate", "")))),
          "GUIDE_SNAPSHOT_DATED", f"{mid}: snapshotDate {m.get('snapshotDate')} is an ISO date")
    facts = m.get("surfaceFacts") or []
    check(bool(facts), "GUIDE_SURFACE_FACTS", f"{mid}: declares surface facts")
    for f in facts:
        check(bool(f.get("asOf")), "SURFACE_FACT_DATED",
              f"{mid}: surface {f.get('surface')} carries asOf {f.get('asOf')}")
        check(f.get("verifyAtRuntime") is True, "SURFACE_FACT_VERIFY_FLAGGED",
              f"{mid}: surface {f.get('surface')} is flagged verifyAtRuntime (rule 03)")

# --- 2. slots are complete and disjoint ----------------------------------------------
slots = [m.get("slot") for m in models]
check(set(slots) == {"still", "video"}, "SLOTS_COVERED", f"locked slots: {sorted(slots)}")
check(len(slots) == len(set(slots)), "SLOTS_DISJOINT", "no model owns two slots")

# --- 3. the contract template's id namespace must equal the registry's ----------------
tpl = json.loads((ROOT / "templates/PROJECT_CONTRACT.json").read_text(encoding="utf-8"))
pol = tpl.get("generationPromptPolicy", {})
reg_nbp = next((m.get("frameworkIds", []) for m in models if m.get("modelId") == "nano_banana_pro"), [])
reg_om = next((m.get("taskIds", []) for m in models if m.get("modelId") == "gemini_omni_flash"), [])
check(pol.get("nanoBananaFrameworks") == reg_nbp, "CONTRACT_NBP_IDS_MATCH_REGISTRY",
      f"template nanoBananaFrameworks {pol.get('nanoBananaFrameworks')} == registry {reg_nbp}")
check(pol.get("omniTasks") == reg_om, "CONTRACT_OMNI_IDS_MATCH_REGISTRY",
      f"template omniTasks {pol.get('omniTasks')} == registry {reg_om}")

# --- 4. no validator may still hardcode a model-name tuple ---------------------------
MODEL_LITERAL = re.compile(r"[\(\{][\"'](?:nano_banana_pro|gemini_omni_flash)[\"']")
EXEMPT = {"validate_model_guides.py"}
hardcoded = []
for p in sorted((ROOT / "validators").rglob("*.py")):
    if p.name in EXEMPT:
        continue
    for m in MODEL_LITERAL.finditer(p.read_text(encoding="utf-8")):
        hardcoded.append((p.relative_to(ROOT).as_posix(), m.group(0)))
for rel, lit in hardcoded:
    check(False, "MODEL_LITERAL_IN_CODE", f"{rel}: {lit} resolves models as data, not code")
check(not hardcoded, "MODELS_RESOLVED_FROM_DATA",
      f"no validator hardcodes a model name ({len(hardcoded)} found)")

print(json.dumps({
    "schemaVersion": "8.0.3",
    "validator": "validate_model_guides.py",
    "pass": not FAILURES,
    "passed": len(PASSES),
    "failed": len(FAILURES),
    "failures": FAILURES,
    "lockedModels": [m.get("modelId") for m in models],
    "proofBoundary": ("Proves the registry, adapters and contract template agree on ids, and that every locked model "
                      "has a dated guide. It does NOT prove a model exists, that its snapshot is current, or that "
                      "the surface behaves as declared."),
}, indent=2, ensure_ascii=False))
sys.exit(0 if not FAILURES else 1)